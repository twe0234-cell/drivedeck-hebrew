.class public final synthetic Lc/f8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:Lc/r0;

.field public final synthetic b:Z

.field public final synthetic c:I

.field public final synthetic d:I

.field public final synthetic e:Lc/o0;

.field public final synthetic f:F

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(Lc/r0;ZIILc/o0;FI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/f8;->a:Lc/r0;

    iput-boolean p2, p0, Lc/f8;->b:Z

    iput p3, p0, Lc/f8;->c:I

    iput p4, p0, Lc/f8;->d:I

    iput-object p5, p0, Lc/f8;->e:Lc/o0;

    iput p6, p0, Lc/f8;->f:F

    iput p7, p0, Lc/f8;->g:I

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, Lc/r0;

    move-object/from16 v9, p2

    check-cast v9, Lc/r0;

    iget-object v10, v0, Lc/f8;->a:Lc/r0;

    iget-object v11, v0, Lc/f8;->e:Lc/o0;

    iget-boolean v12, v0, Lc/f8;->b:Z

    iget v13, v0, Lc/f8;->c:I

    iget v14, v0, Lc/f8;->d:I

    iget v15, v0, Lc/f8;->f:F

    iget v8, v0, Lc/f8;->g:I

    move-object v2, v10

    move v3, v12

    move v4, v13

    move v5, v14

    move-object v6, v11

    move v7, v15

    move/from16 v16, v8

    invoke-static/range {v1 .. v8}, Lc/k6;->m0(Lc/r0;Lc/r0;ZIILc/o0;FI)I

    move-result v1

    move-object v2, v9

    move-object v3, v10

    move v4, v12

    move v5, v13

    move v6, v14

    move-object v7, v11

    move v8, v15

    move/from16 v9, v16

    invoke-static/range {v2 .. v9}, Lc/k6;->m0(Lc/r0;Lc/r0;ZIILc/o0;FI)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Integer;->compare(II)I

    move-result v1

    return v1
.end method
