.class public final Lc/A0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:Lc/r4;

.field public final synthetic d:I


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lru/drivedeck/launcher/MainActivity;Lc/r4;I)V
    .locals 0

    iput-object p2, p0, Lc/A0;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/A0;->c:Lc/r4;

    iput p4, p0, Lc/A0;->d:I

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lc/A0;->a:Landroid/graphics/Paint;

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    iget-object v3, v0, Lc/A0;->b:Lru/drivedeck/launcher/MainActivity;

    const/high16 v4, 0x41000000    # 8.0f

    invoke-static {v3, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    int-to-float v3, v3

    iget-object v12, v0, Lc/A0;->a:Landroid/graphics/Paint;

    iget-object v4, v0, Lc/A0;->c:Lc/r4;

    iget v5, v4, Lc/r4;->e:I

    invoke-virtual {v12, v5}, Landroid/graphics/Paint;->setColor(I)V

    iget v13, v4, Lc/r4;->h:I

    iget v14, v4, Lc/r4;->d:I

    iget v4, v0, Lc/A0;->d:I

    const/4 v5, 0x1

    const/high16 v15, 0x40000000    # 2.0f

    if-ne v4, v5, :cond_0

    sub-float v8, v2, v3

    move-object/from16 v4, p1

    move v5, v3

    move v6, v3

    move v7, v8

    move v9, v3

    move v10, v3

    move-object v11, v12

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setColor(I)V

    add-float v14, v2, v3

    const v4, 0x3fb33333    # 1.4f

    mul-float v6, v3, v4

    sub-float v16, v1, v3

    mul-float v17, v3, v15

    div-float v15, v3, v15

    move-object/from16 v4, p1

    move v5, v14

    move/from16 v7, v16

    move/from16 v8, v17

    move v9, v15

    move v10, v15

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v4, 0x40400000    # 3.0f

    mul-float v6, v3, v4

    sub-float v7, v1, v17

    const v1, 0x40666666    # 3.6f

    mul-float v8, v3, v1

    move-object/from16 v4, p1

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    sub-float v6, v2, v17

    const/high16 v1, 0x3fc00000    # 1.5f

    mul-float/2addr v3, v1

    sub-float v8, v2, v3

    move/from16 v7, v16

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    goto :goto_0

    :cond_0
    sub-float v16, v1, v3

    const v4, 0x3f0a3d71    # 0.54f

    mul-float v8, v2, v4

    move-object/from16 v4, p1

    move v5, v3

    move v6, v3

    move/from16 v7, v16

    move v9, v3

    move v10, v3

    move-object v11, v12

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    const v4, 0x3f266666    # 0.65f

    mul-float v6, v2, v4

    const v4, 0x3f35c28f    # 0.71f

    mul-float v8, v2, v4

    div-float v10, v3, v15

    move-object/from16 v4, p1

    move v9, v10

    invoke-virtual/range {v4 .. v11}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    invoke-virtual {v12, v14}, Landroid/graphics/Paint;->setColor(I)V

    div-float/2addr v1, v15

    const v4, 0x3f5c28f6    # 0.86f

    mul-float/2addr v2, v4

    const v4, 0x3f4ccccd    # 0.8f

    mul-float/2addr v3, v4

    move-object/from16 v4, p1

    invoke-virtual {v4, v1, v2, v3, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    :goto_0
    return-void
.end method
