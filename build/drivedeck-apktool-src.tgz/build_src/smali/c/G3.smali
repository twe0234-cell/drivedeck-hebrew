.class public final synthetic Lc/G3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/P3;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(Lc/P3;Ljava/lang/String;Landroid/graphics/Bitmap;I)V
    .locals 0

    iput p4, p0, Lc/G3;->a:I

    iput-object p1, p0, Lc/G3;->b:Lc/P3;

    iput-object p2, p0, Lc/G3;->c:Ljava/lang/String;

    iput-object p3, p0, Lc/G3;->d:Landroid/graphics/Bitmap;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/G3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/G3;->b:Lc/P3;

    iget-object v1, v0, Lc/P3;->p1:Ljava/lang/String;

    iget-object v2, p0, Lc/G3;->c:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lc/G3;->d:Landroid/graphics/Bitmap;

    iput-object v1, v0, Lc/P3;->q1:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Lc/P3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/G3;->b:Lc/P3;

    iget-object v1, v0, Lc/P3;->r1:Ljava/lang/String;

    iget-object v2, p0, Lc/G3;->c:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    iget-object v1, p0, Lc/G3;->d:Landroid/graphics/Bitmap;

    iput-object v1, v0, Lc/P3;->s1:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Lc/P3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
