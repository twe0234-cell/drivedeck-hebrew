.class public final synthetic Lc/Y6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lorg/json/JSONObject;

.field public final synthetic c:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic d:Lc/r4;

.field public final synthetic e:Lc/T5;


# direct methods
.method public synthetic constructor <init>(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/Y6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Y6;->b:Lorg/json/JSONObject;

    iput-object p2, p0, Lc/Y6;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/Y6;->d:Lc/r4;

    iput-object p4, p0, Lc/Y6;->e:Lc/T5;

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Lorg/json/JSONObject;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/Y6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Y6;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/Y6;->d:Lc/r4;

    iput-object p3, p0, Lc/Y6;->e:Lc/T5;

    iput-object p4, p0, Lc/Y6;->b:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/Y6;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/Y6;->b:Lorg/json/JSONObject;

    invoke-static {v0}, Lc/b7;->e(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "Id"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    iget-object v1, p0, Lc/Y6;->d:Lc/r4;

    iget-object v2, p0, Lc/Y6;->e:Lc/T5;

    iget-object v3, p0, Lc/Y6;->c:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0, v3, v1, v2}, Lc/b7;->g(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/Y6;->b:Lorg/json/JSONObject;

    iget-object v1, p0, Lc/Y6;->c:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, p0, Lc/Y6;->d:Lc/r4;

    iget-object v3, p0, Lc/Y6;->e:Lc/T5;

    invoke-static {v0, v1, v2, v3}, Lc/b7;->g(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
