.class public final Lc/B6;
.super Landroid/widget/ListView;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/H6;


# direct methods
.method public constructor <init>(Lc/H6;Landroid/app/Activity;)V
    .locals 0

    iput-object p1, p0, Lc/B6;->a:Lc/H6;

    invoke-direct {p0, p2}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x1

    iget-object v2, p0, Lc/B6;->a:Lc/H6;

    if-nez v0, :cond_0

    iput-boolean v1, v2, Lc/H6;->Q:Z

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x3

    :try_start_0
    invoke-super {p0, p1}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eq v0, v1, :cond_1

    if-ne v0, v4, :cond_2

    :cond_1
    iput-boolean v3, v2, Lc/H6;->Q:Z

    iget-object v0, v2, Lc/H6;->m0:Landroid/os/Handler;

    iget-object v1, v2, Lc/H6;->p0:Lc/q6;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    return p1

    :catchall_0
    move-exception p1

    if-eq v0, v1, :cond_3

    if-ne v0, v4, :cond_4

    :cond_3
    iput-boolean v3, v2, Lc/H6;->Q:Z

    iget-object v0, v2, Lc/H6;->m0:Landroid/os/Handler;

    iget-object v1, v2, Lc/H6;->p0:Lc/q6;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_4
    throw p1
.end method
