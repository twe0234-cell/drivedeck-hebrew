.class public final synthetic Lc/l4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/LauncherAccessibilityService;

.field public final synthetic b:J

.field public final synthetic c:Ljava/util/ArrayList;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLjava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/l4;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iput-wide p2, p0, Lc/l4;->b:J

    iput-object p4, p0, Lc/l4;->c:Ljava/util/ArrayList;

    iput-object p5, p0, Lc/l4;->d:Ljava/lang/String;

    iput-object p6, p0, Lc/l4;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    iget-object v2, p0, Lc/l4;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-wide v3, p0, Lc/l4;->b:J

    invoke-virtual {v2, v3, v4}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.syu.user.split.screen"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.fyt.screenbutton"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    iget-object v0, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v9, Lc/k4;

    iget-object v5, p0, Lc/l4;->c:Ljava/util/ArrayList;

    iget-object v6, p0, Lc/l4;->d:Ljava/lang/String;

    iget-object v7, p0, Lc/l4;->e:Ljava/lang/String;

    const/4 v8, 0x1

    move-object v1, v9

    invoke-direct/range {v1 .. v8}, Lc/k4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLjava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;I)V

    const-wide/16 v1, 0x384

    invoke-virtual {v0, v9, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_0
    return-void
.end method
