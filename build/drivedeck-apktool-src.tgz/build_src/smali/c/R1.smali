.class public final Lc/R1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static d:Lc/R1;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;


# direct methods
.method public static b(Landroid/content/Context;)V
    .locals 5

    sget-object v0, Lc/R1;->d:Lc/R1;

    if-nez v0, :cond_0

    new-instance v0, Lc/R1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    iput-object p0, v0, Lc/R1;->a:Ljava/lang/Object;

    const-string v1, "window"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager;

    iput-object v1, v0, Lc/R1;->b:Ljava/lang/Object;

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string v1, "car_mode"

    invoke-static {v1}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    new-instance v2, Lc/O4;

    new-instance v3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v4, 0x1

    invoke-direct {v2, v0, v3, v4}, Lc/O4;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    const/4 v3, 0x0

    invoke-virtual {p0, v1, v3, v2}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    sput-object v0, Lc/R1;->d:Lc/R1;

    :cond_0
    sget-object p0, Lc/R1;->d:Lc/R1;

    invoke-virtual {p0}, Lc/R1;->a()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 11

    new-instance v0, Lc/n1;

    iget-object v1, p0, Lc/R1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    const-string v2, "dimmer_dark_only"

    iget-object v3, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    invoke-interface {v3, v2, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    const/4 v5, 0x1

    if-nez v2, :cond_1

    const-string v2, "auto"

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Lc/n1;->d0()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    move v2, v4

    goto :goto_1

    :cond_1
    :goto_0
    move v2, v5

    :goto_1
    invoke-virtual {v0}, Lc/n1;->k()I

    move-result v6

    invoke-virtual {v0}, Lc/n1;->j0()Z

    move-result v7

    const-string v8, "dimmer_by_headlights"

    invoke-interface {v3, v8, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    const/4 v8, -0x1

    :try_start_0
    iget-object v0, v0, Lc/n1;->c:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v9, "car_mode"

    invoke-static {v0, v9, v8}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_2

    if-ne v0, v5, :cond_3

    :cond_2
    move v8, v0

    :catch_0
    :cond_3
    if-eqz v3, :cond_5

    if-ne v8, v5, :cond_6

    :cond_4
    move v4, v6

    goto :goto_2

    :cond_5
    if-eqz v2, :cond_4

    if-eqz v7, :cond_4

    :cond_6
    :goto_2
    iget-object v0, p0, Lc/R1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/WindowManager;

    if-eqz v4, :cond_9

    invoke-static {v1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_7

    goto :goto_4

    :cond_7
    iget-object v2, p0, Lc/R1;->c:Ljava/lang/Object;

    check-cast v2, Landroid/view/View;

    const/high16 v3, 0x42c80000    # 100.0f

    if-nez v2, :cond_8

    new-instance v2, Landroid/view/View;

    invoke-direct {v2, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x2

    invoke-virtual {v2, v1}, Landroid/view/View;->setImportantForAccessibility(I)V

    const/high16 v1, -0x1000000

    invoke-virtual {v2, v1}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    const/4 v7, -0x1

    const/16 v8, 0x7f6

    const/4 v6, -0x1

    const/16 v9, 0x318

    const/4 v10, -0x3

    move-object v5, v1

    invoke-direct/range {v5 .. v10}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const v5, 0x800033

    iput v5, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    int-to-float v4, v4

    div-float/2addr v4, v3

    iput v4, v1, Landroid/view/WindowManager$LayoutParams;->alpha:F

    const-string v3, "DriveDeck dimmer"

    invoke-virtual {v1, v3}, Landroid/view/WindowManager$LayoutParams;->setTitle(Ljava/lang/CharSequence;)V

    :try_start_1
    invoke-interface {v0, v2, v1}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iput-object v2, p0, Lc/R1;->c:Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception v0

    const-string v1, "DriveDeckDimmer"

    const-string v2, "Cannot attach dimmer"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_3

    :cond_8
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager$LayoutParams;

    int-to-float v2, v4

    div-float/2addr v2, v3

    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->alpha:F

    iget-object v2, p0, Lc/R1;->c:Ljava/lang/Object;

    check-cast v2, Landroid/view/View;

    invoke-interface {v0, v2, v1}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_3
    return-void

    :cond_9
    :goto_4
    iget-object v1, p0, Lc/R1;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/View;

    if-eqz v1, :cond_a

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/R1;->c:Ljava/lang/Object;

    :cond_a
    return-void
.end method

.method public c()V
    .locals 1

    const-string v0, ""

    iput-object v0, p0, Lc/R1;->a:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lc/R1;->b:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lc/R1;->c:Ljava/lang/Object;

    return-void
.end method
