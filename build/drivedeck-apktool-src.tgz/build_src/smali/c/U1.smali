.class public final synthetic Lc/U1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/b2;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/b2;II)V
    .locals 0

    iput p3, p0, Lc/U1;->a:I

    iput-object p1, p0, Lc/U1;->b:Lc/b2;

    iput p2, p0, Lc/U1;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    iget v0, p0, Lc/U1;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lc/W3;

    iget-object v0, p0, Lc/U1;->b:Lc/b2;

    iget v1, v0, Lc/b2;->s:I

    iget v2, p0, Lc/U1;->c:I

    if-ne v2, v1, :cond_0

    iput-object p1, v0, Lc/b2;->o:Lc/W3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_0
    return-void

    :pswitch_0
    check-cast p1, Landroid/graphics/Bitmap;

    const/4 v0, 0x0

    iget-object v1, p0, Lc/U1;->b:Lc/b2;

    iput-boolean v0, v1, Lc/b2;->v:Z

    iget v0, v1, Lc/b2;->w:I

    iget v2, p0, Lc/U1;->c:I

    if-ne v2, v0, :cond_3

    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    if-eqz p1, :cond_4

    iget-object v0, v1, Lc/b2;->u:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    :cond_2
    iput-object p1, v1, Lc/b2;->u:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-eqz p1, :cond_4

    invoke-virtual {v1}, Lc/b2;->j()V

    goto :goto_1

    :cond_3
    :goto_0
    if-eqz p1, :cond_4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->recycle()V

    :cond_4
    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
