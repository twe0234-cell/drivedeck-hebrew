.class public final synthetic Lc/h9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/l9;


# direct methods
.method public synthetic constructor <init>(Lc/l9;I)V
    .locals 0

    iput p2, p0, Lc/h9;->a:I

    iput-object p1, p0, Lc/h9;->b:Lc/l9;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const/4 v0, 0x0

    iget-object v1, p0, Lc/h9;->b:Lc/l9;

    iget v2, p0, Lc/h9;->a:I

    packed-switch v2, :pswitch_data_0

    iget-boolean v0, v1, Lc/l9;->l:Z

    if-eqz v0, :cond_1

    iget-boolean v0, v1, Lc/l9;->d:Z

    if-nez v0, :cond_1

    iget-object v0, v1, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, v1, Lc/l9;->q:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_1
    :goto_1
    return-void

    :pswitch_0
    invoke-virtual {v1}, Lc/l9;->a()V

    invoke-virtual {v1}, Lc/l9;->c()V

    return-void

    :pswitch_1
    invoke-virtual {v1}, Lc/l9;->c()V

    return-void

    :pswitch_2
    iput-boolean v0, v1, Lc/l9;->e:Z

    iput-boolean v0, v1, Lc/l9;->d:Z

    iget-boolean v0, v1, Lc/l9;->l:Z

    if-eqz v0, :cond_2

    invoke-virtual {v1}, Lc/l9;->d()V

    :cond_2
    return-void

    :pswitch_3
    iget-boolean v2, v1, Lc/l9;->l:Z

    if-eqz v2, :cond_5

    iget-object v2, v1, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->isShowing()Z

    move-result v2

    if-nez v2, :cond_3

    goto :goto_3

    :cond_3
    iput-boolean v0, v1, Lc/l9;->d:Z

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v2

    iget-object v3, v1, Lc/l9;->b:Lc/k9;

    if-nez v2, :cond_4

    goto :goto_2

    :cond_4
    iget-object v2, v3, Lc/k9;->b:Lc/j9;

    invoke-virtual {v2}, Landroid/view/View;->getRotation()F

    move-result v2

    sget-object v4, Landroid/view/View;->ROTATION:Landroid/util/Property;

    const/high16 v5, 0x44340000    # 720.0f

    add-float/2addr v5, v2

    const/4 v6, 0x2

    new-array v6, v6, [F

    aput v2, v6, v0

    const/4 v0, 0x1

    aput v5, v6, v0

    iget-object v0, v3, Lc/k9;->b:Lc/j9;

    invoke-static {v0, v4, v6}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    iput-object v0, v1, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    const-wide/16 v4, 0x1770

    invoke-virtual {v0, v4, v5}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v0, v1, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    new-instance v2, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v2}, Landroid/view/animation/LinearInterpolator;-><init>()V

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object v0, v1, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    const/4 v2, -0x1

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    iget-object v0, v1, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    :goto_2
    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    :cond_5
    :goto_3
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
