.class public final Lc/h;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/RectF;

.field public final c:[I

.field public final synthetic d:Z

.field public final synthetic e:Landroid/content/Context;

.field public final synthetic f:Lc/r4;

.field public final synthetic g:[Lc/W3;


# direct methods
.method public constructor <init>(Landroid/content/Context;ZLandroid/content/Context;Lc/r4;[Lc/W3;)V
    .locals 0

    iput-boolean p2, p0, Lc/h;->d:Z

    iput-object p3, p0, Lc/h;->e:Landroid/content/Context;

    iput-object p4, p0, Lc/h;->f:Lc/r4;

    iput-object p5, p0, Lc/h;->g:[Lc/W3;

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    iput-object p1, p0, Lc/h;->a:Landroid/graphics/Paint;

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lc/h;->b:Landroid/graphics/RectF;

    const/4 p1, 0x2

    new-array p1, p1, [I

    iput-object p1, p0, Lc/h;->c:[I

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 14

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onDraw(Landroid/graphics/Canvas;)V

    iget-boolean v0, p0, Lc/h;->d:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/h;->c:[I

    invoke-virtual {p0, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget-object v2, p0, Lc/h;->e:Landroid/content/Context;

    instance-of v3, v2, Landroid/app/Activity;

    if-eqz v3, :cond_1

    move-object v3, v2

    check-cast v3, Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v3

    :goto_0
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v4, 0x0

    aget v5, v0, v4

    neg-int v5, v5

    int-to-float v5, v5

    const/4 v6, 0x1

    aget v0, v0, v6

    neg-int v0, v0

    int-to-float v0, v0

    invoke-virtual {p1, v5, v0}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v7, p0, Lc/h;->a:Landroid/graphics/Paint;

    iget-object v8, p0, Lc/h;->b:Landroid/graphics/RectF;

    iget-object v0, p0, Lc/h;->f:Lc/r4;

    iget v9, v0, Lc/r4;->a:I

    iget-object v5, p0, Lc/h;->g:[Lc/W3;

    aget-object v10, v5, v4

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v4

    if-lez v4, :cond_2

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v4

    :goto_1
    int-to-float v4, v4

    move v11, v4

    goto :goto_2

    :cond_2
    iget v4, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    goto :goto_1

    :goto_2
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v4

    if-lez v4, :cond_3

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v1

    :goto_3
    int-to-float v1, v1

    move v12, v1

    goto :goto_4

    :cond_3
    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    goto :goto_3

    :goto_4
    new-instance v1, Lc/n1;

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Lc/n1;->S()I

    move-result v1

    int-to-float v1, v1

    invoke-static {v2, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v13

    move-object v6, p1

    invoke-static/range {v6 .. v13}, Lc/s3;->a(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/RectF;ILc/W3;FFF)V

    iget-boolean v0, v0, Lc/r4;->m:Z

    if-eqz v0, :cond_4

    const/high16 v0, -0x67000000

    goto :goto_5

    :cond_4
    const/high16 v0, 0x66000000

    :goto_5
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method
