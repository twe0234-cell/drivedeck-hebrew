.class public final synthetic Lc/w0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/k3;Lc/n1;Landroid/widget/Switch;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/w0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/w0;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/w0;->b:Ljava/lang/Object;

    iput-object p3, p0, Lc/w0;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p4, p0, Lc/w0;->a:I

    iput-object p1, p0, Lc/w0;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/w0;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/w0;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    iget p1, p0, Lc/w0;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/w0;->b:Ljava/lang/Object;

    check-cast p1, Lc/C6;

    iget-object p1, p1, Lc/C6;->a:Lc/H6;

    iget-object v0, p1, Lc/H6;->c:Lc/T5;

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    iget-object v2, p0, Lc/w0;->c:Ljava/lang/Object;

    check-cast v2, Lc/j6;

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lc/w0;->d:Ljava/lang/Object;

    check-cast v1, Lc/i6;

    iget-object v1, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, p2, v1}, Lc/T5;->c1(ZLjava/lang/String;)V

    invoke-virtual {p1}, Lc/H6;->A()V

    :goto_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/w0;->b:Ljava/lang/Object;

    check-cast p1, Lc/H6;

    iget-object v0, p1, Lc/H6;->c:Lc/T5;

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    iget-object v2, p0, Lc/w0;->c:Ljava/lang/Object;

    check-cast v2, Lc/j6;

    if-eq v1, v2, :cond_1

    goto :goto_1

    :cond_1
    iget-object v1, p0, Lc/w0;->d:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, p2, v1}, Lc/T5;->c1(ZLjava/lang/String;)V

    invoke-virtual {p1}, Lc/H6;->A()V

    invoke-virtual {p1}, Lc/H6;->u()V

    :goto_1
    return-void

    :pswitch_1
    iget-object p1, p0, Lc/w0;->b:Ljava/lang/Object;

    check-cast p1, Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/w0;->c:Ljava/lang/Object;

    check-cast v0, Lc/a;

    iget-object v1, v0, Lc/a;->a:Ljava/lang/String;

    xor-int/lit8 v2, p2, 0x1

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    invoke-virtual {p1, v2, v1}, Lc/n1;->z0(ZLjava/lang/String;)V

    if-eqz p2, :cond_2

    const/4 p1, 0x1

    goto :goto_2

    :cond_2
    const/4 p1, 0x3

    :goto_2
    iget-object p2, p0, Lc/w0;->d:Ljava/lang/Object;

    check-cast p2, Lc/u;

    invoke-virtual {p2, v0, p1}, Lc/u;->a(Lc/a;I)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/w0;->d:Ljava/lang/Object;

    check-cast p1, Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/w0;->b:Ljava/lang/Object;

    check-cast v0, Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "home_edge_fade_oval"

    invoke-virtual {v0, v2}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-eqz p2, :cond_3

    const-string p2, "\u041e\u0432\u0430\u043b"

    goto :goto_3

    :cond_3
    const-string p2, "\u041f\u0440\u044f\u043c\u043e\u0443\u0433\u043e\u043b\u044c\u043d\u0438\u043a"

    :goto_3
    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lc/w0;->c:Ljava/lang/Object;

    check-cast v0, Landroid/widget/Switch;

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_4
    return-void

    :pswitch_3
    iget-object p1, p0, Lc/w0;->b:Ljava/lang/Object;

    check-cast p1, Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "music_controls_auto_hide"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/w0;->c:Ljava/lang/Object;

    check-cast p1, Landroid/widget/Switch;

    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    iget-object p1, p0, Lc/w0;->d:Ljava/lang/Object;

    check-cast p1, Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
