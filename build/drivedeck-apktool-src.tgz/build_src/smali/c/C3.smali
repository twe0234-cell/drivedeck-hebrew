.class public final Lc/C3;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/P3;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/P3;)V
    .locals 0

    iput-object p2, p0, Lc/C3;->a:Lc/P3;

    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setWillNotDraw(Z)V

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 30

    move-object/from16 v0, p0

    invoke-super/range {p0 .. p1}, Landroid/widget/LinearLayout;->onDraw(Landroid/graphics/Canvas;)V

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWindowVisibility()I

    move-result v1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iget-object v4, v0, Lc/C3;->a:Lc/P3;

    invoke-virtual {v4}, Lc/P3;->R()Landroid/graphics/Bitmap;

    move-result-object v5

    iget-object v6, v4, Lc/P3;->c0:Lc/r4;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v7

    int-to-float v7, v7

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v8

    int-to-float v14, v8

    iget-object v4, v4, Lc/P3;->M1:Lc/b5;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v8

    if-eqz v5, :cond_2

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v10

    if-eqz v10, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getGenerationId()I

    move-result v10

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v10, 0x0

    :goto_2
    iget-object v11, v4, Lc/b5;->p:Lc/r4;

    iget-object v15, v4, Lc/b5;->f:[I

    iget-object v13, v4, Lc/b5;->e:[I

    iget-object v12, v4, Lc/b5;->d:[I

    iget-object v2, v4, Lc/b5;->c:[Landroid/graphics/Shader;

    if-ne v11, v6, :cond_4

    iget-object v3, v4, Lc/b5;->h:Landroid/graphics/Bitmap;

    if-ne v3, v5, :cond_4

    iget v3, v4, Lc/b5;->j:I

    if-eq v3, v10, :cond_3

    goto :goto_3

    :cond_3
    move v3, v1

    move/from16 v18, v7

    move-wide v5, v8

    move/from16 v19, v14

    const/4 v1, 0x0

    goto/16 :goto_11

    :cond_4
    :goto_3
    if-nez v11, :cond_5

    const/4 v3, 0x1

    goto :goto_4

    :cond_5
    const/4 v3, 0x0

    :goto_4
    invoke-virtual {v4, v8, v9, v1}, Lc/b5;->d(JZ)F

    move-result v11

    move/from16 v18, v7

    const/4 v0, 0x0

    :goto_5
    array-length v7, v12

    if-ge v0, v7, :cond_6

    aget v7, v13, v0

    move/from16 v19, v14

    aget v14, v12, v0

    invoke-static {v11, v7, v14}, Lc/b5;->a(FII)I

    move-result v7

    aput v7, v13, v0

    add-int/lit8 v0, v0, 0x1

    move/from16 v14, v19

    goto :goto_5

    :cond_6
    move/from16 v19, v14

    iget v0, v4, Lc/b5;->n:I

    iget v7, v4, Lc/b5;->m:I

    invoke-static {v11, v0, v7}, Lc/b5;->a(FII)I

    move-result v0

    iput v0, v4, Lc/b5;->n:I

    iput-object v6, v4, Lc/b5;->p:Lc/r4;

    iput-object v5, v4, Lc/b5;->h:Landroid/graphics/Bitmap;

    iput v10, v4, Lc/b5;->j:I

    const/4 v0, 0x0

    :goto_6
    const/4 v7, 0x3

    if-ge v0, v7, :cond_d

    iget v7, v6, Lc/r4;->f:I

    iget-object v11, v4, Lc/b5;->g:[F

    if-eqz v5, :cond_a

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v14

    if-nez v14, :cond_a

    const/high16 v14, -0x40800000    # -1.0f

    move/from16 v21, v7

    const/4 v10, 0x0

    :goto_7
    const/16 v7, 0x8

    if-ge v10, v7, :cond_9

    move/from16 v23, v1

    const/4 v7, 0x0

    :goto_8
    const/4 v1, 0x4

    if-ge v7, v1, :cond_8

    :try_start_0
    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    const/16 v17, 0x1

    add-int/lit8 v1, v1, -0x1

    mul-int/lit8 v24, v0, 0x4

    add-int v24, v24, v7

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v25
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    mul-int v24, v24, v25

    move-wide/from16 v25, v8

    :try_start_1
    div-int/lit8 v8, v24, 0xc

    invoke-static {v1, v8}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v8

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    invoke-virtual {v5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v9

    mul-int/2addr v9, v10

    const/16 v22, 0x8

    div-int/lit8 v9, v9, 0x8

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v8

    invoke-virtual {v5, v1, v8}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v1

    invoke-static {v1, v11}, Landroid/graphics/Color;->colorToHSV(I[F)V

    const/4 v8, 0x1

    aget v9, v11, v8

    const/4 v8, 0x2

    aget v24, v11, v8

    mul-float v9, v9, v24

    invoke-static {v1}, Landroid/graphics/Color;->alpha(I)I

    move-result v8
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1

    int-to-float v8, v8

    const/high16 v24, 0x437f0000    # 255.0f

    div-float v8, v8, v24

    mul-float/2addr v8, v9

    cmpl-float v9, v8, v14

    if-lez v9, :cond_7

    move/from16 v21, v1

    move v14, v8

    :cond_7
    add-int/lit8 v7, v7, 0x1

    move-wide/from16 v8, v25

    goto :goto_8

    :catch_0
    move-wide/from16 v25, v8

    :catch_1
    iget v7, v6, Lc/r4;->f:I

    goto :goto_9

    :cond_8
    move-wide/from16 v25, v8

    add-int/lit8 v10, v10, 0x1

    move/from16 v1, v23

    goto :goto_7

    :cond_9
    move/from16 v23, v1

    move-wide/from16 v25, v8

    move/from16 v7, v21

    goto :goto_9

    :cond_a
    move/from16 v23, v1

    move-wide/from16 v25, v8

    :goto_9
    invoke-static {v7, v11}, Landroid/graphics/Color;->colorToHSV(I[F)V

    iget-boolean v1, v6, Lc/r4;->m:Z

    if-eqz v1, :cond_b

    const/high16 v7, 0x3f000000    # 0.5f

    :goto_a
    const/4 v8, 0x1

    goto :goto_b

    :cond_b
    const v7, 0x3f47ae14    # 0.78f

    goto :goto_a

    :goto_b
    aget v9, v11, v8

    const v10, 0x3dcccccd    # 0.1f

    invoke-static {v10, v9}, Ljava/lang/Math;->max(FF)F

    move-result v9

    invoke-static {v7, v9}, Ljava/lang/Math;->min(FF)F

    move-result v7

    aput v7, v11, v8

    if-eqz v1, :cond_c

    const v1, 0x3f70a3d7    # 0.94f

    :goto_c
    const/4 v7, 0x2

    goto :goto_d

    :cond_c
    const v1, 0x3ec28f5c    # 0.38f

    goto :goto_c

    :goto_d
    aput v1, v11, v7

    invoke-static {v11}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result v1

    aput v1, v12, v0

    aput v1, v15, v0

    aget v1, v12, v0

    invoke-static {v1}, Lc/b5;->c(I)Landroid/graphics/RadialGradient;

    move-result-object v1

    aput-object v1, v2, v0

    add-int/lit8 v0, v0, 0x1

    move/from16 v1, v23

    move-wide/from16 v8, v25

    goto/16 :goto_6

    :cond_d
    move/from16 v23, v1

    move-wide/from16 v25, v8

    iget v0, v6, Lc/r4;->a:I

    const/4 v1, 0x0

    aget v5, v12, v1

    iget-boolean v1, v6, Lc/r4;->m:Z

    if-eqz v1, :cond_e

    const v1, 0x3e6147ae    # 0.22f

    goto :goto_e

    :cond_e
    const v1, 0x3e99999a    # 0.3f

    :goto_e
    invoke-static {v1, v0, v5}, Lc/b5;->a(FII)I

    move-result v0

    iput v0, v4, Lc/b5;->m:I

    if-eqz v3, :cond_f

    array-length v0, v12

    const/4 v1, 0x0

    invoke-static {v12, v1, v13, v1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v0, v4, Lc/b5;->m:I

    iput v0, v4, Lc/b5;->n:I

    goto :goto_f

    :cond_f
    const/4 v1, 0x0

    :goto_f
    if-eqz v3, :cond_10

    const-wide/16 v5, 0x0

    goto :goto_10

    :cond_10
    move-wide/from16 v5, v25

    :goto_10
    iput-wide v5, v4, Lc/b5;->o:J

    move/from16 v3, v23

    move-wide/from16 v5, v25

    :goto_11
    invoke-virtual {v4, v5, v6, v3}, Lc/b5;->d(JZ)F

    move-result v0

    iget v7, v4, Lc/b5;->n:I

    iget v8, v4, Lc/b5;->m:I

    invoke-static {v0, v7, v8}, Lc/b5;->a(FII)I

    move-result v7

    move-object/from16 v14, p1

    invoke-virtual {v14, v7}, Landroid/graphics/Canvas;->drawColor(I)V

    if-eqz v3, :cond_11

    long-to-double v5, v5

    const-wide v7, 0x408f400000000000L    # 1000.0

    div-double/2addr v5, v7

    :goto_12
    move/from16 v7, v18

    move/from16 v11, v19

    goto :goto_13

    :cond_11
    const-wide/16 v5, 0x0

    goto :goto_12

    :goto_13
    invoke-static {v7, v11}, Ljava/lang/Math;->max(FF)F

    move-result v8

    const v9, 0x3f051eb8    # 0.52f

    mul-float v10, v8, v9

    :goto_14
    array-length v8, v2

    iget-object v9, v4, Lc/b5;->a:Landroid/graphics/Paint;

    if-ge v1, v8, :cond_13

    aget v8, v13, v1

    move-object/from16 v16, v13

    aget v13, v12, v1

    invoke-static {v0, v8, v13}, Lc/b5;->a(FII)I

    move-result v8

    aget v13, v15, v1

    if-eq v13, v8, :cond_12

    aput v8, v15, v1

    invoke-static {v8}, Lc/b5;->c(I)Landroid/graphics/RadialGradient;

    move-result-object v8

    aput-object v8, v2, v1

    :cond_12
    move-object/from16 v17, v12

    int-to-double v12, v1

    const-wide v18, 0x40010a3d70a3d70aL    # 2.13

    mul-double v18, v18, v12

    const-wide v20, 0x3f9fbe76c8b43958L    # 0.031

    mul-double v20, v20, v12

    const-wide v22, 0x3fbeb851eb851eb8L    # 0.12

    add-double v20, v20, v22

    mul-double v20, v20, v5

    add-double v20, v20, v18

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->sin(D)D

    move-result-wide v20

    const-wide v22, 0x3fdb851eb851eb85L    # 0.43

    mul-double v20, v20, v22

    const-wide/high16 v24, 0x3fe0000000000000L    # 0.5

    add-double v20, v20, v24

    const-wide v26, 0x3fb2b020c49ba5e3L    # 0.073

    mul-double v26, v26, v5

    add-double v26, v26, v18

    invoke-static/range {v26 .. v27}, Ljava/lang/Math;->sin(D)D

    move-result-wide v26

    const-wide v28, 0x3fc3333333333333L    # 0.15

    mul-double v26, v26, v28

    move-object/from16 v28, v15

    add-double v14, v26, v20

    double-to-float v8, v14

    mul-float/2addr v8, v7

    const-wide v14, 0x3f9ba5e353f7ced9L    # 0.027

    mul-double/2addr v12, v14

    const-wide v14, 0x3fb999999999999aL    # 0.1

    add-double/2addr v12, v14

    mul-double/2addr v12, v5

    add-double v12, v12, v18

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    mul-double v12, v12, v22

    add-double v12, v12, v24

    const-wide v14, 0x3faf3b645a1cac08L    # 0.061

    mul-double/2addr v14, v5

    sub-double v14, v14, v18

    invoke-static {v14, v15}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    const-wide v18, 0x3fc1eb851eb851ecL    # 0.14

    mul-double v14, v14, v18

    add-double/2addr v14, v12

    double-to-float v12, v14

    mul-float v14, v11, v12

    iget-object v12, v4, Lc/b5;->b:Landroid/graphics/Matrix;

    invoke-virtual {v12, v10, v10}, Landroid/graphics/Matrix;->setScale(FF)V

    invoke-virtual {v12, v8, v14}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    aget-object v8, v2, v1

    invoke-virtual {v8, v12}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    aget-object v8, v2, v1

    invoke-virtual {v9, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/16 v8, 0xe1

    invoke-virtual {v9, v8}, Landroid/graphics/Paint;->setAlpha(I)V

    const/4 v12, 0x0

    const/4 v13, 0x0

    move-object/from16 v8, p1

    move-object v14, v9

    move v9, v13

    move v15, v10

    move v10, v12

    move/from16 v18, v11

    move v11, v7

    move/from16 v12, v18

    move-object v13, v14

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v1, v1, 0x1

    move-object/from16 v14, p1

    move v10, v15

    move-object/from16 v13, v16

    move-object/from16 v12, v17

    move/from16 v11, v18

    move-object/from16 v15, v28

    goto/16 :goto_14

    :cond_13
    move-object v14, v9

    const/4 v0, 0x0

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/16 v0, 0xff

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    if-eqz v3, :cond_14

    const-wide/16 v0, 0x40

    move-object/from16 v2, p0

    invoke-virtual {v2, v0, v1}, Landroid/view/View;->postInvalidateDelayed(J)V

    goto :goto_15

    :cond_14
    move-object/from16 v2, p0

    :goto_15
    return-void
.end method
