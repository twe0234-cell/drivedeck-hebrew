.class public final Lc/j5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:Ljava/util/regex/Pattern;


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "(?iu)(\\d+(?:[.,]\\d+)?)\\s*(\u043a\u043c|km|\u043c\u0435\u0442\u0440\u043e\u0432|\u043c\u0435\u0442\u0440\u0430|\u043c\u0435\u0442\u0440|\u043c|m)\\b"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lc/j5;->e:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/j5;->a:I

    iput-object p2, p0, Lc/j5;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/j5;->c:Ljava/lang/String;

    iput-object p4, p0, Lc/j5;->d:Ljava/lang/String;

    return-void
.end method

.method public static varargs a(Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 4

    array-length v0, p1

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    if-ge v2, v0, :cond_1

    aget-object v3, p1, v2

    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    const/4 p0, 0x1

    return p0

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Lc/j5;
    .locals 17

    const-string v0, ""

    if-nez p0, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    move-object/from16 v1, p0

    :goto_0
    if-nez p1, :cond_1

    move-object v2, v0

    goto :goto_1

    :cond_1
    move-object/from16 v2, p1

    :goto_1
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x451

    const/16 v6, 0x435

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v4

    const-string v5, "\u0432\u043b\u0435\u0432\u043e"

    const-string v6, "\u043b\u0435\u0432\u0435\u0435"

    const-string v7, "\u043d\u0430\u043b\u0435\u0432\u043e"

    const-string v8, "\u043b\u0435\u0432\u043e\u0439"

    const-string v9, "left"

    filled-new-array {v7, v5, v6, v8, v9}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    const-string v6, "\u0432\u043f\u0440\u0430\u0432\u043e"

    const-string v7, "\u043f\u0440\u0430\u0432\u0435\u0435"

    const-string v8, "\u043d\u0430\u043f\u0440\u0430\u0432\u043e"

    const-string v9, "\u043f\u0440\u0430\u0432\u043e\u0439"

    const-string v10, "right"

    filled-new-array {v8, v6, v7, v9, v10}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v6

    const-string v7, "\u0440\u0430\u0437\u0432\u0435\u0440"

    const-string v8, "u-turn"

    const-string v9, "\u0440\u0430\u0437\u0432\u043e\u0440"

    const-string v10, "u turn"

    const-string v11, "uturn"

    filled-new-array {v9, v7, v8, v10, v11}, [Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v7

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v7, :cond_3

    if-eqz v6, :cond_2

    if-nez v5, :cond_2

    const/16 v4, 0xc

    goto/16 :goto_2

    :cond_2
    const/16 v4, 0xb

    goto/16 :goto_2

    :cond_3
    const-string v7, "roundabout"

    const-string v10, "\u043a\u0440\u0443\u0433\u043e\u0432"

    const-string v11, "\u043a\u043e\u043b\u044c\u0446"

    filled-new-array {v10, v11, v7}, [Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v4, 0xe

    goto/16 :goto_2

    :cond_4
    const-string v13, "\u0444\u0438\u043d\u0438\u0448"

    const-string v14, "you have arrived"

    const-string v10, "\u0432\u044b \u043f\u0440\u0438\u0431\u044b\u043b\u0438"

    const-string v11, "\u043f\u0443\u043d\u043a\u0442 \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f"

    const-string v12, "\u043c\u0435\u0441\u0442\u043e \u043d\u0430\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f"

    const-string v15, "destination"

    const-string v16, "finish"

    filled-new-array/range {v10 .. v16}, [Ljava/lang/String;

    move-result-object v7

    invoke-static {v4, v7}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_5

    const/16 v4, 0xf

    goto/16 :goto_2

    :cond_5
    if-eq v5, v6, :cond_f

    const-string v6, "\u0441\u044a\u0435\u0437\u0434"

    const-string v7, "\u0441\u044a\u0435\u0437\u0436"

    const-string v10, "exit"

    const-string v11, "ramp"

    filled-new-array {v6, v7, v10, v11}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_7

    if-eqz v5, :cond_6

    const/16 v4, 0x9

    goto/16 :goto_2

    :cond_6
    const/16 v4, 0xa

    goto/16 :goto_2

    :cond_7
    const-string v12, "\u0440\u0430\u0437\u0432\u0438\u043b"

    const-string v13, "keep"

    const-string v10, "\u0434\u0435\u0440\u0436\u0438\u0442"

    const-string v11, "\u043f\u0440\u0438\u0434\u0435\u0440\u0436"

    const-string v14, "fork"

    const-string v15, "bear"

    filled-new-array/range {v10 .. v15}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_9

    if-eqz v5, :cond_8

    const/4 v4, 0x7

    goto :goto_2

    :cond_8
    const/16 v4, 0x8

    goto :goto_2

    :cond_9
    const-string v6, "\u0440\u0435\u0437\u043a"

    const-string v7, "\u043a\u0440\u0443\u0442\u043e"

    const-string v10, "sharp"

    const-string v11, "hard"

    filled-new-array {v6, v7, v10, v11}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_b

    if-eqz v5, :cond_a

    const/4 v4, 0x5

    goto :goto_2

    :cond_a
    const/4 v4, 0x6

    goto :goto_2

    :cond_b
    const-string v6, "\u0441\u043b\u0435\u0433\u043a\u0430"

    const-string v7, "\u043d\u0435\u0431\u043e\u043b\u044c\u0448"

    const-string v10, "\u043f\u043b\u0430\u0432\u043d"

    const-string v11, "slight"

    const-string v12, "gentle"

    filled-new-array {v10, v6, v7, v11, v12}, [Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_d

    if-eqz v5, :cond_c

    const/4 v4, 0x3

    goto :goto_2

    :cond_c
    const/4 v4, 0x4

    goto :goto_2

    :cond_d
    if-eqz v5, :cond_e

    move v4, v9

    goto :goto_2

    :cond_e
    move v4, v8

    goto :goto_2

    :cond_f
    if-nez v5, :cond_10

    const-string v5, "\u043f\u0440\u044f\u043c\u043e"

    const-string v6, "straight"

    filled-new-array {v5, v6}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v4, v5}, Lc/j5;->a(Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_10

    const/16 v4, 0xd

    goto :goto_2

    :cond_10
    const/16 v4, 0x10

    :goto_2
    sget-object v5, Lc/j5;->e:Ljava/util/regex/Pattern;

    invoke-virtual {v5, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-eqz v6, :cond_13

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " "

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "\u043a"

    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_12

    invoke-virtual {v5, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    const-string v5, "km"

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_11

    goto :goto_3

    :cond_11
    const-string v3, "\u043c"

    goto :goto_4

    :cond_12
    :goto_3
    const-string v3, "\u043a\u043c"

    :goto_4
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_13
    new-instance v3, Lc/j5;

    invoke-direct {v3, v4, v0, v2, v1}, Lc/j5;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-object v3
.end method
