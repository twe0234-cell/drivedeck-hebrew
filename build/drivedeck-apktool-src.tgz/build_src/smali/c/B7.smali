.class public final synthetic Lc/B7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/O7;


# direct methods
.method public synthetic constructor <init>(Lc/O7;I)V
    .locals 0

    iput p2, p0, Lc/B7;->a:I

    iput-object p1, p0, Lc/B7;->b:Lc/O7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget p1, p0, Lc/B7;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/B7;->b:Lc/O7;

    iget-object v0, p1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    iget v2, v1, Lc/e8;->e:I

    const/4 v3, 0x3

    if-ne v2, v3, :cond_0

    new-instance v1, Lc/E3;

    const/4 v2, 0x3

    invoke-direct {v1, p1, v2}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Lc/Z7;->o(Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_0
    invoke-virtual {v1}, Lc/e8;->d()Z

    move-result v1

    if-eqz v1, :cond_1

    new-instance v1, Lc/E3;

    const/4 v2, 0x3

    invoke-direct {v1, p1, v2}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Lc/Z7;->j(Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_1
    iget-object v0, p1, Lc/O7;->d:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lc/E3;

    const/4 v2, 0x3

    invoke-direct {v1, p1, v2}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    iget-object p1, p1, Lc/O7;->b:Lc/Z7;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_3

    iget-object v2, p1, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v2}, Lc/e8;->b()Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    invoke-virtual {p1, v2, v0, v1}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_3
    :goto_0
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, p1}, Lc/E3;->accept(Ljava/lang/Object;)V

    :goto_1
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/B7;->b:Lc/O7;

    iget-object p1, p1, Lc/O7;->q:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
