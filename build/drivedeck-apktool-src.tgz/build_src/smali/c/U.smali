.class public abstract synthetic Lc/U;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static bridge synthetic a(Landroid/appwidget/AppWidgetProviderInfo;)I
    .locals 0

    iget p0, p0, Landroid/appwidget/AppWidgetProviderInfo;->maxResizeWidth:I

    return p0
.end method

.method public static bridge synthetic b(Landroid/appwidget/AppWidgetHostView;Landroid/os/Bundle;Ljava/util/List;)V
    .locals 0

    invoke-virtual {p0, p1, p2}, Landroid/appwidget/AppWidgetHostView;->updateAppWidgetSize(Landroid/os/Bundle;Ljava/util/List;)V

    return-void
.end method

.method public static bridge synthetic c(Landroid/appwidget/AppWidgetProviderInfo;)I
    .locals 0

    iget p0, p0, Landroid/appwidget/AppWidgetProviderInfo;->maxResizeHeight:I

    return p0
.end method
