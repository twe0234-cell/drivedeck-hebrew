.class public final Lc/k5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e:[Ljava/lang/String;

.field public static final f:Ljava/util/regex/Pattern;

.field public static final g:Ljava/util/regex/Pattern;

.field public static final h:Ljava/util/regex/Pattern;

.field public static final i:Ljava/lang/Object;

.field public static j:J

.field public static volatile k:Lc/k5;

.field public static volatile l:I

.field public static volatile m:J


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Z

.field public final d:J


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const-string v0, "speedlimitview_guidance"

    const-string v1, "view_speedlimit_frame"

    const-string v2, "speed_limit_primary_text"

    const-string v3, "text_speedlimit"

    const-string v4, "speed_limit_image"

    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/k5;->e:[Ljava/lang/String;

    const-string v0, "(?<!\\d)([1-9]\\d?|1\\d\\d)(?!\\d)"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lc/k5;->f:Ljava/util/regex/Pattern;

    const-string v0, "(?iu)(?:(?:\u0432\u043f\u0435\u0440\u0435\u0434\u0438|ahead|warning|distance|\u0434\u0438\u0441\u0442\u0430\u043d\u0446\\p{L}*|\u0434\u043e\u0440\u043e\u0436\u043d\\p{L}*|road)[\\p{Z}\\p{Punct}]{0,20}(?<![\\p{L}])(?:\u043a\u0430\u043c\u0435\u0440(?:\u0430|\u044b|\u0443|\u0435|\u043e\u0439|\u0430\u043c\u0438|\u0430\u0445)?|\u0440\u0430\u0434\u0430\u0440(?:\u044b|\u0430|\u0443|\u043e\u043c|\u0430\u043c\u0438|\u0430\u0445)?|cameras?|radars?)(?![\\p{L}])|(?<![\\p{L}])(?:\u043a\u0430\u043c\u0435\u0440(?:\u0430|\u044b|\u0443|\u0435|\u043e\u0439|\u0430\u043c\u0438|\u0430\u0445)?|\u0440\u0430\u0434\u0430\u0440(?:\u044b|\u0430|\u0443|\u043e\u043c|\u0430\u043c\u0438|\u0430\u0445)?|cameras?|radars?)(?![\\p{L}])[\\p{Z}\\p{Punct}]{0,20}(?:\u0447\u0435\u0440\u0435\u0437|\u0432\u043f\u0435\u0440\u0435\u0434\u0438|ahead|warning|distance|\u0434\u0438\u0441\u0442\u0430\u043d\u0446\\p{L}*|(?:\u043a\u043e\u043d\u0442\u0440\u043e\u043b|\u043e\u0433\u0440\u0430\u043d\u0438\u0447|\u0444\u0438\u043a\u0441\u0430\u0446)\\p{L}*\\s+(?:(?:\u0441\u0440\u0435\u0434\u043d\\p{L}*\\s+)?(?:\u0441\u043a\u043e\u0440\u043e\u0441\u0442|\u0434\u0432\u0438\u0436\u0435\u043d|\u043f\u043e\u043b\u043e\u0441|\u043d\u0430\u0440\u0443\u0448\u0435\u043d)\\p{L}*|(?:average\\s+)?speed)|\u0441\u043a\u043e\u0440\u043e\u0441\u0442\\p{L}*\\s+(?:\u043a\u043e\u043d\u0442\u0440\u043e\u043b|\u043e\u0433\u0440\u0430\u043d\u0438\u0447)\\p{L}*|\u0441\u0440\u0435\u0434\u043d\\p{L}*\\s+\u0441\u043a\u043e\u0440\u043e\u0441\u0442\\p{L}*|(?:control|enforcement)(?:\\s+of)?\\s+(?:average\\s+)?speed|(?:\u043d\u0430|\u043f\u043e)\\s+(?:\u0434\u043e\u0440\u043e\u0433|\u0442\u0440\u0430\u0441\u0441|\u043c\u0430\u0440\u0448\u0440\u0443\u0442)\\p{L}*|on\\s+(?:the\\s+)?road|speed\\s+(?:limit|camera)|\\d+\\s*(?:\u043c|\u043c\u0435\u0442\u0440\\p{L}*|\u043a\u043c|km|m)\\b)|(?:speed|traffic|enforcement|average\\s+speed|speed\\s+enforcement)\\s+(?<![\\p{L}])(?:\u043a\u0430\u043c\u0435\u0440(?:\u0430|\u044b|\u0443|\u0435|\u043e\u0439|\u0430\u043c\u0438|\u0430\u0445)?|\u0440\u0430\u0434\u0430\u0440(?:\u044b|\u0430|\u0443|\u043e\u043c|\u0430\u043c\u0438|\u0430\u0445)?|cameras?|radars?)(?![\\p{L}]))"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lc/k5;->g:Ljava/util/regex/Pattern;

    const-string v0, "(?iu)(?:\u043f\u0430\u0440\u043a\u043e\u0432\\p{L}*|\u0441\u0442\u043e\u044f\u043d\\p{L}*|\u043f\u0430\u0440\u043a\u0438\u043d\u0433\\p{L}*|parking|car\\s+park(?:ing)?|parking\\s+lot)"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lc/k5;->h:Ljava/util/regex/Pattern;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lc/k5;->i:Ljava/lang/Object;

    const/4 v0, -0x1

    sput v0, Lc/k5;->l:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .line 1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/4 v3, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Lc/k5;-><init>(Ljava/lang/String;Ljava/lang/String;ZJ)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZJ)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lc/k5;->a:Ljava/lang/String;

    iput-object p2, p0, Lc/k5;->b:Ljava/lang/String;

    iput-boolean p3, p0, Lc/k5;->c:Z

    .line 4
    iput-wide p4, p0, Lc/k5;->d:J

    return-void
.end method

.method public static a()V
    .locals 5

    sget-object v0, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-wide v1, Lc/k5;->j:J

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    sput-wide v1, Lc/k5;->j:J

    const/4 v1, 0x0

    sput-object v1, Lc/k5;->k:Lc/k5;

    const/4 v1, -0x1

    sput v1, Lc/k5;->l:I

    const-wide/16 v1, 0x0

    sput-wide v1, Lc/k5;->m:J

    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public static b(J)V
    .locals 3

    sget-object v0, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-wide v1, Lc/k5;->j:J

    cmp-long p0, p0, v1

    if-eqz p0, :cond_0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_0
    const-wide/16 p0, 0x1

    add-long/2addr v1, p0

    sput-wide v1, Lc/k5;->j:J

    const/4 p0, 0x0

    sput-object p0, Lc/k5;->k:Lc/k5;

    const/4 p0, -0x1

    sput p0, Lc/k5;->l:I

    const-wide/16 p0, 0x0

    sput-wide p0, Lc/k5;->m:J

    monitor-exit v0

    return-void

    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public static c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ru.yandex.yandexnavi:id/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    const-string p1, ""

    if-nez p0, :cond_0

    return-object p1

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_5

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;

    const/16 v2, 0x40

    if-ge v0, v2, :cond_3

    if-eqz v1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-nez v3, :cond_2

    :cond_1
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v2

    :cond_2
    if-eqz v2, :cond_3

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    :cond_3
    if-eqz v1, :cond_4

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    return-object p1
.end method

.method public static d(Landroid/view/accessibility/AccessibilityNodeInfo;)Z
    .locals 3

    const/4 v0, 0x0

    if-eqz p0, :cond_4

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    if-nez v1, :cond_0

    const-string v1, ""

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    :goto_0
    const-string v2, "ru.yandex.yandexnavi"

    invoke-virtual {v2, v1}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_2

    :cond_1
    const-string v1, "ru.yandex.yandexnavi:id/activity_search_map_view"

    invoke-virtual {p0, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->findAccessibilityNodeInfosByViewId(Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    if-eqz p0, :cond_2

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    const/4 v0, 0x1

    :cond_2
    if-eqz p0, :cond_4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_3
    :goto_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    goto :goto_1

    :cond_4
    :goto_2
    return v0
.end method

.method public static e(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 12

    sget-object v0, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-wide v1, Lc/k5;->j:J

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-nez p0, :cond_0

    invoke-static {v1, v2}, Lc/k5;->b(J)V

    return-void

    :cond_0
    const-string v0, "ru.yandex.yandexnavi"

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v3

    if-nez v3, :cond_1

    const-string v3, ""

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v3

    :goto_0
    invoke-virtual {v0, v3}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-static {v1, v2}, Lc/k5;->b(J)V

    return-void

    :cond_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v9

    invoke-static {p0}, Lc/k5;->d(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-static {v1, v2}, Lc/k5;->b(J)V

    return-void

    :cond_3
    sget-object v0, Lc/k5;->e:[Ljava/lang/String;

    const/4 v3, 0x0

    move v4, v3

    :goto_1
    const/4 v5, 0x5

    const/4 v6, -0x1

    if-ge v4, v5, :cond_7

    aget-object v7, v0, v4

    invoke-static {p0, v7}, Lc/k5;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_4

    goto :goto_2

    :cond_4
    sget-object v8, Lc/k5;->f:Ljava/util/regex/Pattern;

    invoke-virtual {v8, v7}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    :catch_0
    :cond_5
    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v8

    if-eqz v8, :cond_6

    const/4 v8, 0x1

    :try_start_1
    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    if-lt v8, v5, :cond_5

    const/16 v11, 0xc7

    if-gt v8, v11, :cond_5

    move v6, v8

    :cond_6
    :goto_2
    if-lez v6, :cond_8

    :cond_7
    move v0, v6

    goto :goto_3

    :cond_8
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :goto_3
    const-string v4, "image_maneuverballoon_maneuver"

    invoke-static {p0, v4}, Lc/k5;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "text_maneuverballoon_distance"

    invoke-static {p0, v5}, Lc/k5;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "text_maneuverballoon_metrics"

    invoke-static {p0, v6}, Lc/k5;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "text_nextstreet"

    invoke-static {p0, v7}, Lc/k5;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x40

    filled-new-array {v8}, [I

    move-result-object v8

    invoke-static {p0, v3, v8}, Lc/k5;->f(Landroid/view/accessibility/AccessibilityNodeInfo;I[I)Z

    move-result p0

    const-string v3, ".*[0-9].*"

    invoke-virtual {v5, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_d

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_9

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_9

    goto :goto_7

    :cond_9
    new-instance v11, Lc/k5;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_a

    const-string v5, ""

    goto :goto_4

    :cond_a
    const-string v5, " "

    invoke-virtual {v5, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_4
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_b

    const-string v4, ""

    goto :goto_5

    :cond_b
    const-string v5, " \u00b7 "

    invoke-virtual {v5, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_5
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    move-object v3, v11

    move-object v5, v7

    move v6, p0

    move-wide v7, v9

    invoke-direct/range {v3 .. v8}, Lc/k5;-><init>(Ljava/lang/String;Ljava/lang/String;ZJ)V

    sget-object v3, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v3

    :try_start_2
    sget-wide v4, Lc/k5;->j:J

    cmp-long p0, v1, v4

    if-eqz p0, :cond_c

    monitor-exit v3

    return-void

    :catchall_0
    move-exception p0

    goto :goto_6

    :cond_c
    sput v0, Lc/k5;->l:I

    sput-wide v9, Lc/k5;->m:J

    sput-object v11, Lc/k5;->k:Lc/k5;

    monitor-exit v3

    return-void

    :goto_6
    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0

    :cond_d
    :goto_7
    sget-object v11, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v11

    :try_start_3
    sget-wide v3, Lc/k5;->j:J

    cmp-long v1, v1, v3

    if-eqz v1, :cond_e

    monitor-exit v11

    return-void

    :catchall_1
    move-exception p0

    goto :goto_9

    :cond_e
    sput v0, Lc/k5;->l:I

    sput-wide v9, Lc/k5;->m:J

    if-eqz p0, :cond_f

    new-instance p0, Lc/k5;

    const-string v4, ""

    const-string v5, ""

    const/4 v6, 0x1

    move-object v3, p0

    move-wide v7, v9

    invoke-direct/range {v3 .. v8}, Lc/k5;-><init>(Ljava/lang/String;Ljava/lang/String;ZJ)V

    goto :goto_8

    :cond_f
    const/4 p0, 0x0

    :goto_8
    sput-object p0, Lc/k5;->k:Lc/k5;

    monitor-exit v11

    return-void

    :goto_9
    monitor-exit v11
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw p0

    :catchall_2
    move-exception p0

    :try_start_4
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    throw p0
.end method

.method public static f(Landroid/view/accessibility/AccessibilityNodeInfo;I[I)Z
    .locals 7

    const/4 v0, 0x0

    if-eqz p0, :cond_a

    const/16 v1, 0x8

    if-gt p1, v1, :cond_a

    aget v1, p2, v0

    add-int/lit8 v2, v1, -0x1

    aput v2, p2, v0

    if-lez v1, :cond_a

    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_4

    :cond_0
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_1

    move-object v1, v2

    goto :goto_0

    :cond_1
    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_0
    sget-object v3, Lc/k5;->g:Ljava/util/regex/Pattern;

    sget-object v4, Lc/k5;->h:Ljava/util/regex/Pattern;

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    invoke-virtual {v4, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    move-result v6

    if-nez v6, :cond_2

    invoke-virtual {v3, v1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-eqz v1, :cond_2

    move v1, v5

    goto :goto_1

    :cond_2
    move v1, v0

    :goto_1
    if-eqz v1, :cond_3

    return v5

    :cond_3
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v1

    if-nez v1, :cond_4

    goto :goto_2

    :cond_4
    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_2
    if-eqz v2, :cond_5

    invoke-virtual {v4, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-nez v1, :cond_5

    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-eqz v1, :cond_5

    return v5

    :cond_5
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v1

    aget v2, p2, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    move v2, v0

    :goto_3
    if-ge v2, v1, :cond_a

    invoke-virtual {p0, v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    add-int/lit8 v4, p1, 0x1

    :try_start_0
    invoke-static {v3, v4, p2}, Lc/k5;->f(Landroid/view/accessibility/AccessibilityNodeInfo;I[I)Z

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v4, :cond_7

    if-eqz v3, :cond_6

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_6
    return v5

    :cond_7
    if-eqz v3, :cond_8

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_8
    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :catchall_0
    move-exception p0

    if-eqz v3, :cond_9

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_9
    throw p0

    :cond_a
    :goto_4
    return v0
.end method
