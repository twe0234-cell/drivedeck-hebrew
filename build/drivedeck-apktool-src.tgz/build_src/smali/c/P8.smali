.class public final Lc/P8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Landroid/widget/Button;

.field public final synthetic b:Landroid/widget/TextView;

.field public final synthetic c:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic d:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>(Landroid/widget/Button;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/P8;->a:Landroid/widget/Button;

    iput-object p2, p0, Lc/P8;->b:Landroid/widget/TextView;

    iput-object p3, p0, Lc/P8;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p4, p0, Lc/P8;->d:Landroid/widget/LinearLayout;

    return-void
.end method
