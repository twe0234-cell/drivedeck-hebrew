.class public final Lc/b6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:Z


# direct methods
.method public constructor <init>(IILjava/lang/String;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc/b6;->a:Ljava/lang/String;

    iput p1, p0, Lc/b6;->b:I

    iput-boolean p4, p0, Lc/b6;->d:Z

    iput p2, p0, Lc/b6;->c:I

    return-void
.end method
