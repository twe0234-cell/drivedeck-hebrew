.class public final Lc/v5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:D


# direct methods
.method public constructor <init>(Ljava/lang/String;IIIID)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/v5;->a:Ljava/lang/String;

    iput p2, p0, Lc/v5;->b:I

    iput p3, p0, Lc/v5;->c:I

    iput p4, p0, Lc/v5;->d:I

    iput p5, p0, Lc/v5;->e:I

    iput-wide p6, p0, Lc/v5;->f:D

    return-void
.end method


# virtual methods
.method public final a([B)D
    .locals 4

    iget v0, p0, Lc/v5;->b:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    if-eqz p1, :cond_0

    array-length v0, p1

    iget v2, p0, Lc/v5;->d:I

    iget v3, p0, Lc/v5;->e:I

    add-int/2addr v3, v2

    if-lt v0, v3, :cond_0

    aget-byte v0, p1, v2

    and-int/lit16 v0, v0, 0xff

    mul-int/lit16 v0, v0, 0x100

    add-int/2addr v2, v1

    aget-byte p1, p1, v2

    and-int/lit16 p1, p1, 0xff

    add-int/2addr v0, p1

    int-to-double v0, v0

    iget-wide v2, p0, Lc/v5;->f:D

    mul-double/2addr v0, v2

    return-wide v0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Incomplete builtin response"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Value requires the matching live provider"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
