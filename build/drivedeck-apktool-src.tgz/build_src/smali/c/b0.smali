.class public final Lc/b0;
.super Landroid/appwidget/AppWidgetHost;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:Lc/e0;


# direct methods
.method public constructor <init>(Lc/e0;Landroid/app/Activity;Lru/drivedeck/launcher/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lc/b0;->b:Lc/e0;

    iput-object p3, p0, Lc/b0;->a:Lru/drivedeck/launcher/MainActivity;

    const p1, 0x135283d

    invoke-direct {p0, p2, p1}, Landroid/appwidget/AppWidgetHost;-><init>(Landroid/content/Context;I)V

    return-void
.end method


# virtual methods
.method public final onProvidersChanged()V
    .locals 3

    new-instance v0, Lc/X;

    iget-object v1, p0, Lc/b0;->b:Lc/e0;

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lc/X;-><init>(Lc/e0;I)V

    iget-object v1, p0, Lc/b0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
