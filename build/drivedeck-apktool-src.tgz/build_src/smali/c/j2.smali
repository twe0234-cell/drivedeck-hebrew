.class public final synthetic Lc/j2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Landroid/view/ViewGroup;


# direct methods
.method public synthetic constructor <init>(Landroid/view/ViewGroup;II)V
    .locals 0

    iput p3, p0, Lc/j2;->a:I

    iput-object p1, p0, Lc/j2;->c:Landroid/view/ViewGroup;

    iput p2, p0, Lc/j2;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 3

    iget v0, p0, Lc/j2;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Lc/j2;->c:Landroid/view/ViewGroup;

    check-cast v0, Lc/N7;

    iget-object v1, v0, Lc/N7;->j:Lc/O7;

    invoke-virtual {v1}, Lc/O7;->l()Z

    move-result v1

    if-eqz v1, :cond_1

    iget v1, v0, Lc/N7;->b:I

    iget v2, p0, Lc/j2;->b:I

    if-eq v1, v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/N7;->i:Lc/f1;

    iput-object p1, v0, Lc/f1;->c:Ljava/lang/Object;

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    check-cast p1, Lc/W3;

    iget-object v0, p0, Lc/j2;->c:Landroid/view/ViewGroup;

    check-cast v0, Lc/Q3;

    iget v1, v0, Lc/Q3;->H:I

    iget v2, p0, Lc/j2;->b:I

    if-eq v2, v1, :cond_2

    goto :goto_1

    :cond_2
    iget-object v1, v0, Lc/Q3;->t:Lc/P3;

    iput-object p1, v1, Lc/P3;->a:Lc/W3;

    invoke-virtual {v0}, Lc/Q3;->J()V

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    :goto_1
    return-void

    :pswitch_1
    check-cast p1, Lc/W3;

    iget-object v0, p0, Lc/j2;->c:Landroid/view/ViewGroup;

    check-cast v0, Lc/m2;

    iget v1, v0, Lc/m2;->C:I

    iget v2, p0, Lc/j2;->b:I

    if-eq v2, v1, :cond_3

    goto :goto_2

    :cond_3
    iput-object p1, v0, Lc/m2;->B:Lc/W3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
