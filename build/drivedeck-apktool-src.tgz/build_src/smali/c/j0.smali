.class public final synthetic Lc/j0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p5, p0, Lc/j0;->a:I

    iput-object p1, p0, Lc/j0;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/j0;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/j0;->e:Ljava/lang/Object;

    iput-object p4, p0, Lc/j0;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 13

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object v2, p0, Lc/j0;->b:Ljava/lang/Object;

    iget-object v3, p0, Lc/j0;->e:Ljava/lang/Object;

    iget-object v4, p0, Lc/j0;->d:Ljava/lang/Object;

    iget-object v5, p0, Lc/j0;->c:Ljava/lang/Object;

    iget v6, p0, Lc/j0;->a:I

    packed-switch v6, :pswitch_data_0

    check-cast v5, Lc/n1;

    iget-object p1, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v6, "test_update_channels_unlocked_10"

    invoke-interface {p1, v6, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-nez p1, :cond_1

    check-cast v4, [I

    aget p1, v4, v1

    add-int/2addr p1, v0

    aput p1, v4, v1

    const/16 v4, 0xa

    if-ge p1, v4, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-static {p1, v6, v0}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    check-cast v3, Landroid/widget/Switch;

    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    check-cast v2, Landroid/widget/Switch;

    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    check-cast v5, Lc/H6;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/LinearLayout;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_2

    const/16 p1, 0x8

    goto :goto_1

    :cond_2
    move p1, v1

    :goto_1
    invoke-virtual {v4, p1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_3

    goto :goto_2

    :cond_3
    move v0, v1

    :goto_2
    const/16 p1, 0xc

    invoke-virtual {v5, p1}, Lc/H6;->g(I)I

    move-result v1

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    move v6, p1

    goto :goto_3

    :cond_4
    move v6, v4

    :goto_3
    invoke-virtual {v5, v6}, Lc/H6;->g(I)I

    move-result v6

    invoke-virtual {v5, p1}, Lc/H6;->g(I)I

    move-result v7

    if-eqz v0, :cond_5

    goto :goto_4

    :cond_5
    move p1, v4

    :goto_4
    invoke-virtual {v5, p1}, Lc/H6;->g(I)I

    move-result p1

    check-cast v3, Landroid/widget/LinearLayout;

    invoke-virtual {v3, v1, v6, v7, p1}, Landroid/view/View;->setPadding(IIII)V

    check-cast v2, Lc/C2;

    invoke-virtual {v2}, Lc/C2;->run()V

    invoke-virtual {v5}, Lc/H6;->p()V

    iget-object p1, v5, Lc/H6;->m0:Landroid/os/Handler;

    iget-object v0, v5, Lc/H6;->r0:Lc/q6;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v1, 0x12c

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :pswitch_1
    check-cast v5, Lc/n1;

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v5, v4}, Lc/n1;->H0(Ljava/lang/String;)V

    check-cast v3, Lc/t2;

    invoke-virtual {v3}, Lc/t2;->I()V

    check-cast v2, Lc/C2;

    invoke-virtual {v2}, Lc/C2;->run()V

    return-void

    :pswitch_2
    check-cast v5, Lc/k3;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/ImageButton;

    invoke-virtual {v4, v1}, Landroid/view/View;->setEnabled(Z)V

    new-instance p1, Lc/a3;

    check-cast v3, Landroid/widget/TextView;

    invoke-direct {p1, v5, v3, v4, v0}, Lc/a3;-><init>(Lc/k3;Landroid/widget/TextView;Landroid/view/View;I)V

    sget-object v0, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "voice-language-"

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v2}, Ld/a;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iget-object v0, v5, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    new-instance v9, Lc/Z6;

    invoke-direct {v9, v4, p1}, Lc/Z6;-><init>(Landroid/view/View;Ljava/lang/Object;)V

    new-instance p1, Lc/b1;

    const/4 v0, 0x3

    invoke-direct {p1, v0}, Lc/b1;-><init>(I)V

    invoke-virtual {v9, p1, v1}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    new-instance p1, Lc/F5;

    const/4 v11, 0x1

    const/4 v12, 0x6

    move-object v6, p1

    invoke-direct/range {v6 .. v12}, Lc/F5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    sget-object v0, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_3
    move-object v0, v5

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v7, Lc/C2;

    check-cast v4, Ljava/lang/String;

    move-object v5, v2

    check-cast v5, Landroid/widget/LinearLayout;

    move-object v6, v3

    check-cast v6, Lc/a;

    const/4 v8, 0x1

    move-object v1, v7

    move-object v2, v0

    move-object v3, v4

    move-object v4, v6

    move v6, v8

    invoke-direct/range {v1 .. v6}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p1, v7}, Lc/k3;->p0(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void

    :pswitch_4
    check-cast v5, Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lc/y9;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    if-nez v6, :cond_6

    const-string p1, "\u0423\u043a\u0430\u0436\u0438\u0442\u0435 \u043d\u0430\u0441\u0435\u043b\u0451\u043d\u043d\u044b\u0439 \u043f\u0443\u043d\u043a\u0442 \u0434\u043e 80 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432"

    invoke-static {v4, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Landroid/widget/TextView;->setError(Ljava/lang/CharSequence;)V

    goto :goto_6

    :cond_6
    invoke-static {p1}, Lc/y9;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_7

    move p1, v1

    goto :goto_5

    :cond_7
    invoke-static {v4}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v6

    invoke-static {v4, v6, p1}, Lc/y9;->k(Lru/drivedeck/launcher/MainActivity;ZLjava/lang/String;)Z

    move-result p1

    :goto_5
    if-nez p1, :cond_8

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0435\u043b\u0451\u043d\u043d\u044b\u0439 \u043f\u0443\u043d\u043a\u0442"

    invoke-static {v4, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Landroid/widget/TextView;->setError(Ljava/lang/CharSequence;)V

    goto :goto_6

    :cond_8
    check-cast v3, Lc/i;

    invoke-virtual {v3}, Lc/i;->run()V

    invoke-static {v4, v3, v0, v1}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    check-cast v2, Landroid/app/Dialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->dismiss()V

    :goto_6
    return-void

    :pswitch_5
    check-cast v5, Lc/n1;

    invoke-virtual {v5}, Lc/n1;->i()Lc/u0;

    move-result-object p1

    new-instance v0, Lc/u0;

    iget v6, p1, Lc/u0;->a:I

    iget-object v7, p1, Lc/u0;->b:Ljava/lang/Object;

    check-cast v7, Lc/Q1;

    check-cast v4, Lc/q0;

    iget-object p1, p1, Lc/u0;->d:Ljava/lang/Object;

    check-cast p1, Ljava/util/List;

    invoke-direct {v0, v7, v4, p1, v6}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    invoke-virtual {v5, v0, v1, v1}, Lc/n1;->B0(Lc/u0;ZZ)Z

    move-result p1

    if-eqz p1, :cond_9

    check-cast v3, Lc/J1;

    invoke-virtual {v3}, Lc/J1;->run()V

    check-cast v2, Landroid/app/Dialog;

    invoke-virtual {v2}, Landroid/app/Dialog;->dismiss()V

    :cond_9
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
