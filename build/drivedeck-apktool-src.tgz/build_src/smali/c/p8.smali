.class public final Lc/p8;
.super Landroid/graphics/drawable/Drawable;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/t8;


# direct methods
.method public constructor <init>(Lc/t8;)V
    .locals 0

    iput-object p1, p0, Lc/p8;->a:Lc/t8;

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    return-void
.end method


# virtual methods
.method public final draw(Landroid/graphics/Canvas;)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v0, Lc/p8;->a:Lc/t8;

    iget-object v2, v2, Lc/t8;->b:Lc/r8;

    if-eqz v2, :cond_13

    iget-object v3, v2, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->isShown()Z

    move-result v3

    if-nez v3, :cond_0

    goto/16 :goto_8

    :cond_0
    new-instance v3, Landroid/graphics/Rect;

    iget-object v4, v2, Lc/r8;->c:Landroid/graphics/Rect;

    invoke-direct {v3, v4}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    iget-object v4, v2, Lc/r8;->a:Landroid/view/View;

    instance-of v5, v4, Lc/q8;

    if-eqz v5, :cond_1

    check-cast v4, Lc/q8;

    iget v5, v2, Lc/r8;->b:I

    invoke-interface {v4, v5, v3}, Lc/q8;->a(ILandroid/graphics/Rect;)Z

    move-result v4

    if-nez v4, :cond_1

    return-void

    :cond_1
    iget-object v4, v0, Lc/p8;->a:Lc/t8;

    iget-object v4, v4, Lc/t8;->c:Lc/r8;

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v4, :cond_f

    invoke-virtual {v4, v2}, Lc/r8;->a(Lc/r8;)Z

    move-result v4

    if-eqz v4, :cond_f

    iget-object v4, v2, Lc/r8;->a:Landroid/view/View;

    check-cast v4, Lc/s8;

    check-cast v4, Lc/t2;

    invoke-virtual {v4}, Lc/t2;->Y()Z

    move-result v8

    if-nez v8, :cond_2

    goto/16 :goto_7

    :cond_2
    invoke-virtual {v4}, Lc/t2;->y()I

    move-result v8

    iget-object v9, v4, Lc/t2;->u:Ljava/lang/String;

    sget-object v10, Lc/m8;->b:Lc/n1;

    if-eqz v10, :cond_3

    iget v11, v10, Lc/n1;->a:I

    if-ne v11, v8, :cond_3

    iget-object v8, v10, Lc/n1;->b:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_3

    sget-object v8, Lc/m8;->c:Lc/r5;

    goto :goto_0

    :cond_3
    const/4 v8, 0x0

    :goto_0
    if-nez v8, :cond_4

    goto/16 :goto_7

    :cond_4
    iget-object v9, v4, Lc/t2;->d:Lc/v7;

    iget-object v10, v9, Lc/v7;->i:Landroid/view/View;

    if-eqz v10, :cond_5

    goto :goto_1

    :cond_5
    iget-object v10, v9, Lc/v7;->h:Landroid/view/TextureView;

    :goto_1
    if-nez v10, :cond_6

    new-instance v8, Landroid/graphics/RectF;

    invoke-direct {v8}, Landroid/graphics/RectF;-><init>()V

    goto/16 :goto_6

    :cond_6
    new-array v11, v5, [I

    invoke-virtual {v10, v11}, Landroid/view/View;->getLocationOnScreen([I)V

    new-instance v12, Landroid/graphics/Rect;

    iget v13, v9, Lc/v7;->v:I

    iget v14, v9, Lc/v7;->w:I

    invoke-direct {v12, v7, v7, v13, v14}, Landroid/graphics/Rect;-><init>(IIII)V

    new-instance v13, Landroid/graphics/Rect;

    aget v14, v11, v7

    aget v15, v11, v6

    invoke-virtual {v10}, Landroid/view/View;->getWidth()I

    move-result v16

    add-int v7, v16, v14

    aget v11, v11, v6

    invoke-virtual {v10}, Landroid/view/View;->getHeight()I

    move-result v10

    add-int/2addr v10, v11

    invoke-direct {v13, v14, v15, v7, v10}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v7, v9, Lc/v7;->i:Landroid/view/View;

    if-eqz v7, :cond_7

    move v7, v6

    goto :goto_2

    :cond_7
    const/4 v7, 0x0

    :goto_2
    sget-object v9, Lc/m8;->a:Landroid/os/Handler;

    new-instance v9, Landroid/graphics/RectF;

    iget-object v10, v8, Lc/r5;->a:Ljava/lang/Object;

    check-cast v10, Landroid/graphics/Rect;

    invoke-direct {v9, v10}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    if-eqz v7, :cond_9

    iget-object v7, v8, Lc/r5;->b:Ljava/lang/Object;

    check-cast v7, Landroid/graphics/Rect;

    invoke-virtual {v12, v7}, Landroid/graphics/Rect;->contains(Landroid/graphics/Rect;)Z

    move-result v7

    if-eqz v7, :cond_8

    goto :goto_3

    :cond_8
    iget v7, v13, Landroid/graphics/Rect;->left:I

    neg-int v7, v7

    int-to-float v7, v7

    iget v8, v13, Landroid/graphics/Rect;->top:I

    neg-int v8, v8

    int-to-float v8, v8

    invoke-virtual {v9, v7, v8}, Landroid/graphics/RectF;->offset(FF)V

    goto :goto_4

    :cond_9
    :goto_3
    invoke-virtual {v12}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_c

    new-instance v7, Landroid/graphics/RectF;

    invoke-direct {v7, v12}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    invoke-virtual {v9, v7}, Landroid/graphics/RectF;->intersect(Landroid/graphics/RectF;)Z

    move-result v7

    if-nez v7, :cond_a

    goto :goto_5

    :cond_a
    iget v7, v12, Landroid/graphics/Rect;->left:I

    neg-int v7, v7

    int-to-float v7, v7

    iget v8, v12, Landroid/graphics/Rect;->top:I

    neg-int v8, v8

    int-to-float v8, v8

    invoke-virtual {v9, v7, v8}, Landroid/graphics/RectF;->offset(FF)V

    iget v7, v9, Landroid/graphics/RectF;->left:F

    invoke-virtual {v13}, Landroid/graphics/Rect;->width()I

    move-result v8

    int-to-float v8, v8

    mul-float/2addr v7, v8

    invoke-virtual {v12}, Landroid/graphics/Rect;->width()I

    move-result v8

    int-to-float v8, v8

    div-float/2addr v7, v8

    iget v8, v9, Landroid/graphics/RectF;->top:F

    invoke-virtual {v13}, Landroid/graphics/Rect;->height()I

    move-result v10

    int-to-float v10, v10

    mul-float/2addr v8, v10

    invoke-virtual {v12}, Landroid/graphics/Rect;->height()I

    move-result v10

    int-to-float v10, v10

    div-float/2addr v8, v10

    iget v10, v9, Landroid/graphics/RectF;->right:F

    invoke-virtual {v13}, Landroid/graphics/Rect;->width()I

    move-result v11

    int-to-float v11, v11

    mul-float/2addr v10, v11

    invoke-virtual {v12}, Landroid/graphics/Rect;->width()I

    move-result v11

    int-to-float v11, v11

    div-float/2addr v10, v11

    iget v11, v9, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v13}, Landroid/graphics/Rect;->height()I

    move-result v14

    int-to-float v14, v14

    mul-float/2addr v11, v14

    invoke-virtual {v12}, Landroid/graphics/Rect;->height()I

    move-result v12

    int-to-float v12, v12

    div-float/2addr v11, v12

    invoke-virtual {v9, v7, v8, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    :goto_4
    invoke-virtual {v13}, Landroid/graphics/Rect;->width()I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v13}, Landroid/graphics/Rect;->height()I

    move-result v8

    int-to-float v8, v8

    const/4 v10, 0x0

    invoke-virtual {v9, v10, v10, v7, v8}, Landroid/graphics/RectF;->intersect(FFFF)Z

    move-result v7

    if-nez v7, :cond_b

    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    :cond_b
    move-object v8, v9

    goto :goto_6

    :cond_c
    :goto_5
    new-instance v7, Landroid/graphics/RectF;

    invoke-direct {v7}, Landroid/graphics/RectF;-><init>()V

    move-object v8, v7

    :goto_6
    invoke-virtual {v8}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_d

    goto :goto_7

    :cond_d
    iget-object v7, v4, Lc/t2;->d:Lc/v7;

    invoke-virtual {v7}, Landroid/view/View;->getMatrix()Landroid/graphics/Matrix;

    move-result-object v7

    invoke-virtual {v7, v8}, Landroid/graphics/Matrix;->mapRect(Landroid/graphics/RectF;)Z

    iget-object v7, v4, Lc/t2;->b:Landroid/widget/FrameLayout;

    invoke-virtual {v7}, Landroid/view/View;->getLeft()I

    move-result v7

    iget-object v9, v4, Lc/t2;->d:Lc/v7;

    invoke-virtual {v9}, Landroid/view/View;->getLeft()I

    move-result v9

    add-int/2addr v9, v7

    int-to-float v7, v9

    iget-object v9, v4, Lc/t2;->b:Landroid/widget/FrameLayout;

    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    move-result v9

    iget-object v10, v4, Lc/t2;->d:Lc/v7;

    invoke-virtual {v10}, Landroid/view/View;->getTop()I

    move-result v10

    add-int/2addr v10, v9

    int-to-float v9, v10

    invoke-virtual {v8, v7, v9}, Landroid/graphics/RectF;->offset(FF)V

    new-instance v7, Landroid/graphics/Rect;

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    new-instance v9, Landroid/graphics/Rect;

    invoke-direct {v9}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v8, v7}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    invoke-virtual {v4, v9}, Landroid/view/View;->getLocalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v4

    if-eqz v4, :cond_f

    invoke-virtual {v7, v9}, Landroid/graphics/Rect;->intersect(Landroid/graphics/Rect;)Z

    move-result v4

    if-nez v4, :cond_e

    goto :goto_7

    :cond_e
    invoke-virtual {v3, v7}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    :cond_f
    :goto_7
    iget-object v4, v2, Lc/r8;->a:Landroid/view/View;

    instance-of v7, v4, Landroid/widget/AbsListView;

    if-eqz v7, :cond_11

    check-cast v4, Landroid/widget/AbsListView;

    iget v7, v2, Lc/r8;->b:I

    invoke-virtual {v4}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result v8

    sub-int/2addr v7, v8

    invoke-virtual {v4, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    if-nez v4, :cond_10

    return-void

    :cond_10
    invoke-virtual {v4, v3}, Landroid/view/View;->getHitRect(Landroid/graphics/Rect;)V

    :cond_11
    new-array v4, v5, [I

    new-array v7, v5, [I

    iget-object v8, v0, Lc/p8;->a:Lc/t8;

    iget-object v8, v8, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v8, v4}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-object v8, v2, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {v8, v7}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v8, 0x0

    aget v9, v7, v8

    aget v10, v4, v8

    sub-int/2addr v9, v10

    aget v7, v7, v6

    aget v8, v4, v6

    sub-int/2addr v7, v8

    invoke-virtual {v3, v9, v7}, Landroid/graphics/Rect;->offset(II)V

    new-instance v7, Landroid/graphics/Rect;

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    iget-object v8, v2, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {v8, v7}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v8

    if-nez v8, :cond_12

    return-void

    :cond_12
    new-array v5, v5, [I

    iget-object v2, v2, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, v5}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v2, 0x0

    aget v8, v5, v2

    aget v2, v4, v2

    sub-int/2addr v8, v2

    aget v2, v5, v6

    aget v4, v4, v6

    sub-int/2addr v2, v4

    invoke-virtual {v7, v8, v2}, Landroid/graphics/Rect;->offset(II)V

    iget-object v2, v0, Lc/p8;->a:Lc/t8;

    iget-object v2, v2, Lc/t8;->i:Landroid/graphics/Paint;

    invoke-virtual {v2}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v2

    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4, v3}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    invoke-virtual {v4, v2, v2}, Landroid/graphics/RectF;->inset(FF)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {v1, v7}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    const/high16 v3, 0x40400000    # 3.0f

    mul-float/2addr v2, v3

    iget-object v3, v0, Lc/p8;->a:Lc/t8;

    iget-object v3, v3, Lc/t8;->i:Landroid/graphics/Paint;

    invoke-virtual {v1, v4, v2, v2, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    :cond_13
    :goto_8
    return-void
.end method

.method public final getOpacity()I
    .locals 1

    const/4 v0, -0x3

    return v0
.end method

.method public final setAlpha(I)V
    .locals 1

    iget-object v0, p0, Lc/p8;->a:Lc/t8;

    iget-object v0, v0, Lc/t8;->i:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public final setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 1

    iget-object v0, p0, Lc/p8;->a:Lc/t8;

    iget-object v0, v0, Lc/t8;->i:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method
