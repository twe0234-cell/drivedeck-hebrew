.class public final Lc/y8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Landroid/media/AudioManager;

.field public final c:Landroid/os/Handler;

.field public final d:Z

.field public final e:I

.field public final f:I

.field public final g:I

.field public h:I

.field public i:Ljava/lang/Integer;

.field public j:Ljava/lang/Integer;

.field public k:Z

.field public final l:Lc/O;

.field public m:Landroid/os/IBinder;

.field public n:Z

.field public o:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const-string v0, "com.syu.ms"

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Lc/y8;->c:Landroid/os/Handler;

    const/4 v1, -0x1

    iput v1, p0, Lc/y8;->h:I

    new-instance v2, Lc/O;

    const/4 v3, 0x4

    invoke-direct {v2, p0, v3}, Lc/O;-><init>(Landroid/content/ServiceConnection;I)V

    iput-object v2, p0, Lc/y8;->l:Lc/O;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    iput-object v2, p0, Lc/y8;->a:Landroid/content/Context;

    const-string v3, "audio"

    invoke-virtual {p1, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Lc/y8;->b:Landroid/media/AudioManager;

    const/4 p1, 0x0

    const/4 v3, 0x1

    :try_start_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v0, p1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move v2, v3

    goto :goto_0

    :catch_0
    move v2, p1

    :goto_0
    iput-boolean v2, p0, Lc/y8;->d:Z

    if-eqz v2, :cond_0

    :try_start_1
    iget-object v2, p0, Lc/y8;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v0, p1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v2, v0, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->uid:I
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    :try_start_2
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_1

    :catch_1
    move v2, v1

    :catch_2
    move v0, p1

    goto :goto_1

    :cond_0
    move v0, p1

    move v2, v1

    :goto_1
    iput v2, p0, Lc/y8;->e:I

    iput v0, p0, Lc/y8;->g:I

    const v2, 0x7e9ac067

    if-ne v0, v2, :cond_1

    const/16 v1, 0x24

    :cond_1
    iput v1, p0, Lc/y8;->f:I

    iget-object v0, p0, Lc/y8;->b:Landroid/media/AudioManager;

    if-eqz v0, :cond_4

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->isStreamMute(I)Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lc/y8;->b:Landroid/media/AudioManager;

    if-nez v0, :cond_2

    move v0, p1

    goto :goto_2

    :cond_2
    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    :goto_2
    if-nez v0, :cond_4

    :cond_3
    move p1, v3

    :cond_4
    iput-boolean p1, p0, Lc/y8;->o:Z

    return-void
.end method


# virtual methods
.method public final a(ZLc/F3;)V
    .locals 3

    iget-object v0, p0, Lc/y8;->b:Landroid/media/AudioManager;

    if-nez v0, :cond_0

    return-void

    :cond_0
    if-nez v0, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "input keyevent "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz p1, :cond_2

    const/16 v2, 0x18

    goto :goto_1

    :cond_2
    const/16 v2, 0x19

    :goto_1
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/j8;->e(Ljava/lang/String;)V

    iget-object v1, p0, Lc/y8;->c:Landroid/os/Handler;

    new-instance v2, Lc/Q7;

    invoke-direct {v2, p0, v0, p1, p2}, Lc/Q7;-><init>(Lc/y8;IZLc/F3;)V

    const-wide/16 p1, 0x118

    invoke-virtual {v1, v2, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final b()V
    .locals 8

    iget-object v0, p0, Lc/y8;->i:Ljava/lang/Integer;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-ltz v0, :cond_5

    const/16 v1, 0x64

    if-gt v0, v1, :cond_5

    iget v1, p0, Lc/y8;->f:I

    if-ltz v1, :cond_5

    int-to-double v2, v1

    int-to-double v4, v0

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    div-double/2addr v4, v6

    mul-double/2addr v4, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    long-to-int v0, v2

    const/4 v2, 0x0

    iput-object v2, p0, Lc/y8;->i:Ljava/lang/Integer;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iput-object v3, p0, Lc/y8;->j:Ljava/lang/Integer;

    iget-object v3, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 v4, 0x0

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v3

    :try_start_0
    const-string v5, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v3, v5}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Landroid/os/Parcel;->writeInt(I)V

    filled-new-array {v0}, [I

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/os/Parcel;->writeIntArray([I)V

    invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeFloatArray([F)V

    invoke-virtual {v3, v2}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    iget-object v5, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 v6, 0x1

    invoke-interface {v5, v6, v3, v2, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v4
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-virtual {v3}, Landroid/os/Parcel;->recycle()V

    throw v0

    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "SYU target="

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " sent="

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string v5, "DriveDeckAudio"

    invoke-static {v5, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    if-nez v4, :cond_2

    iput-object v2, p0, Lc/y8;->j:Ljava/lang/Integer;

    invoke-virtual {p0}, Lc/y8;->d()V

    goto :goto_1

    :cond_2
    iget v3, p0, Lc/y8;->h:I

    if-ne v3, v0, :cond_3

    iput-object v2, p0, Lc/y8;->j:Ljava/lang/Integer;

    invoke-virtual {p0, v0, v1}, Lc/y8;->e(II)V

    :cond_3
    :goto_1
    iget-boolean v0, p0, Lc/y8;->k:Z

    if-eqz v0, :cond_4

    iget-object v0, p0, Lc/y8;->c:Landroid/os/Handler;

    new-instance v1, Lc/x8;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lc/x8;-><init>(Lc/y8;I)V

    const-wide/16 v2, 0x2bc

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    return-void

    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Invalid volume range"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final c()Z
    .locals 4

    iget-boolean v0, p0, Lc/y8;->d:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/y8;->o:Z

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    iget-object v1, p0, Lc/y8;->b:Landroid/media/AudioManager;

    if-eqz v1, :cond_3

    const/4 v2, 0x3

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->isStreamMute(I)Z

    move-result v3

    if-nez v3, :cond_2

    if-nez v1, :cond_1

    move v1, v0

    goto :goto_0

    :cond_1
    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v1

    :goto_0
    if-nez v1, :cond_3

    :cond_2
    const/4 v0, 0x1

    :cond_3
    :goto_1
    return v0
.end method

.method public final d()V
    .locals 4

    iget-boolean v0, p0, Lc/y8;->d:Z

    const-string v1, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0432 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u0430\u0445: \u0432\u0435\u0440\u0441\u0438\u044f \u0441\u043b\u0443\u0436\u0431\u044b \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u044b \u043f\u043e\u043a\u0430 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f ("

    if-eqz v0, :cond_0

    iget v0, p0, Lc/y8;->f:I

    if-gez v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, p0, Lc/y8;->g:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ")"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    const-string v0, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0432 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u0430\u0445: \u043d\u0435\u0442 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d\u0438\u044f \u043e\u0442 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u044b"

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    iget-object v3, p0, Lc/y8;->a:Landroid/content/Context;

    if-eqz v2, :cond_1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x47

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_1
    invoke-static {v3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_1
    const/4 v1, 0x1

    invoke-static {v3, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method public final e(II)V
    .locals 4

    const/4 v0, 0x1

    if-lt p2, v0, :cond_4

    if-ltz p1, :cond_4

    if-gt p1, p2, :cond_4

    int-to-double v0, p1

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    int-to-double p1, p2

    div-double/2addr v2, p1

    mul-double/2addr v2, v0

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide p1

    long-to-int p1, p1

    if-ltz p1, :cond_3

    const/16 p2, 0x64

    if-gt p1, p2, :cond_3

    iget-object p2, p0, Lc/y8;->a:Landroid/content/Context;

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    sget-object v0, Lc/n9;->g:Landroid/widget/Toast;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/widget/Toast;->cancel()V

    const/4 v0, 0x0

    sput-object v0, Lc/n9;->g:Landroid/widget/Toast;

    :cond_0
    invoke-static {p2}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    :try_start_0
    sget-object v0, Lc/n9;->f:Lc/n9;

    if-nez v0, :cond_1

    new-instance v0, Lc/n9;

    invoke-direct {v0, p2}, Lc/n9;-><init>(Landroid/content/Context;)V

    sput-object v0, Lc/n9;->f:Lc/n9;

    :cond_1
    sget-object v0, Lc/n9;->f:Lc/n9;

    invoke-virtual {v0, p1}, Lc/n9;->b(I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    sget-object v0, Lc/n9;->f:Lc/n9;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lc/n9;->a()V

    :cond_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c"

    invoke-static {p2, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "%"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p2, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    sput-object p1, Lc/n9;->g:Landroid/widget/Toast;

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Invalid percentage"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Invalid volume range"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final f()V
    .locals 5

    iget-boolean v0, p0, Lc/y8;->d:Z

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lc/y8;->n:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    iget-object v0, p0, Lc/y8;->a:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "com.syu.ms.sound"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v2, Landroid/content/ComponentName;

    const-string v3, "com.syu.ms"

    const-string v4, "app.ModuleService"

    invoke-direct {v2, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p0, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/y8;->n:Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/y8;->n:Z

    :cond_1
    :goto_0
    return-void
.end method

.method public final g()V
    .locals 3

    iget-object v0, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {p0, v1}, Lc/y8;->h(Z)V

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 v2, -0x1

    iput v2, p0, Lc/y8;->h:I

    iput-object v0, p0, Lc/y8;->j:Ljava/lang/Integer;

    iget-boolean v0, p0, Lc/y8;->n:Z

    if-nez v0, :cond_1

    return-void

    :cond_1
    iput-boolean v1, p0, Lc/y8;->n:Z

    :try_start_0
    iget-object v0, p0, Lc/y8;->a:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public final h(Z)V
    .locals 4

    iget-object v0, p0, Lc/y8;->m:Landroid/os/IBinder;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const-string v1, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    iget-object v1, p0, Lc/y8;->l:Lc/O;

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    if-eqz p1, :cond_1

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_1
    :goto_0
    iget-object v2, p0, Lc/y8;->m:Landroid/os/IBinder;

    if-eqz p1, :cond_2

    const/4 p1, 0x3

    goto :goto_1

    :cond_2
    const/4 p1, 0x4

    :goto_1
    const/4 v3, 0x0

    invoke-interface {v2, p1, v0, v3, v1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_3

    :goto_2
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1

    :goto_3
    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 0

    iget-boolean p1, p0, Lc/y8;->n:Z

    if-nez p1, :cond_0

    return-void

    :cond_0
    iput-object p2, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lc/y8;->h(Z)V

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lc/y8;->m:Landroid/os/IBinder;

    const/4 p1, -0x1

    iput p1, p0, Lc/y8;->h:I

    return-void
.end method
