.class public final synthetic Lc/T7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/Z7;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:J


# direct methods
.method public synthetic constructor <init>(Lc/Z7;Ljava/lang/String;ILjava/lang/String;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/T7;->a:Lc/Z7;

    iput-object p2, p0, Lc/T7;->b:Ljava/lang/String;

    iput p3, p0, Lc/T7;->c:I

    iput-object p4, p0, Lc/T7;->d:Ljava/lang/String;

    iput-wide p5, p0, Lc/T7;->e:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 16

    move-object/from16 v0, p0

    iget-wide v5, v0, Lc/T7;->e:J

    iget-object v7, v0, Lc/T7;->a:Lc/Z7;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v8, 0x0

    :try_start_0
    iget-wide v2, v7, Lc/Z7;->H:J
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_3

    cmp-long v2, v2, v8

    iget-object v3, v0, Lc/T7;->b:Ljava/lang/String;

    iget v4, v0, Lc/T7;->c:I

    iget-object v10, v0, Lc/T7;->d:Ljava/lang/String;

    iget-object v11, v7, Lc/Z7;->e:Lc/z7;

    const/4 v12, 0x3

    const/4 v13, 0x2

    if-lez v2, :cond_2

    :try_start_1
    iget-object v2, v7, Lc/Z7;->F:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    if-lt v4, v13, :cond_0

    iget-object v2, v7, Lc/Z7;->G:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    iget-object v2, v7, Lc/Z7;->G:Ljava/lang/String;

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_0

    :catch_0
    const/4 v1, 0x0

    goto/16 :goto_7

    :cond_0
    :goto_0
    iget-boolean v2, v7, Lc/Z7;->I:Z

    if-eqz v2, :cond_1

    iget-boolean v2, v7, Lc/Z7;->J:Z

    if-nez v2, :cond_1

    iget-wide v14, v7, Lc/Z7;->H:J

    iget-object v2, v7, Lc/Z7;->G:Ljava/lang/String;

    invoke-virtual {v11, v14, v15, v2, v12}, Lc/z7;->f(JLjava/lang/String;I)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    const/4 v2, 0x0

    :goto_1
    :try_start_2
    iput-wide v8, v7, Lc/Z7;->H:J
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1

    move v14, v2

    goto :goto_3

    :catch_1
    :goto_2
    move v1, v2

    goto/16 :goto_7

    :cond_2
    const/4 v14, 0x0

    :goto_3
    :try_start_3
    iget-wide v1, v7, Lc/Z7;->H:J

    cmp-long v1, v1, v8

    if-nez v1, :cond_6

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_6

    if-eq v4, v12, :cond_3

    if-ne v4, v13, :cond_6

    :cond_3
    iput-object v3, v7, Lc/Z7;->F:Ljava/lang/String;

    iput-object v10, v7, Lc/Z7;->G:Ljava/lang/String;

    if-ne v4, v12, :cond_4

    const/4 v1, 0x1

    goto :goto_4

    :cond_4
    const/4 v1, 0x0

    :goto_4
    iput-boolean v1, v7, Lc/Z7;->I:Z

    const/4 v2, 0x0

    iput-boolean v2, v7, Lc/Z7;->J:Z

    iget-object v2, v7, Lc/Z7;->e:Lc/z7;

    if-eqz v1, :cond_5

    const/4 v4, 0x1

    goto :goto_5

    :cond_5
    move v4, v13

    :goto_5
    move-object v1, v2

    move-object v2, v3

    move-object v3, v10

    invoke-virtual/range {v1 .. v6}, Lc/z7;->e(Ljava/lang/String;Ljava/lang/String;IJ)J

    move-result-wide v1

    iput-wide v1, v7, Lc/Z7;->H:J

    const/4 v14, 0x1

    goto :goto_9

    :catch_2
    move v1, v14

    goto :goto_7

    :cond_6
    iget-wide v1, v7, Lc/Z7;->H:J

    cmp-long v1, v1, v8

    if-lez v1, :cond_9

    const/4 v1, 0x4

    if-ne v4, v1, :cond_7

    const/4 v1, 0x1

    iput-boolean v1, v7, Lc/Z7;->J:Z

    goto :goto_6

    :cond_7
    const/4 v1, 0x1

    :goto_6
    iget-object v2, v7, Lc/Z7;->G:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_9

    iput-object v10, v7, Lc/Z7;->G:Ljava/lang/String;

    iget-wide v2, v7, Lc/Z7;->H:J

    iget-boolean v4, v7, Lc/Z7;->I:Z

    if-eqz v4, :cond_8

    move v13, v1

    :cond_8
    invoke-virtual {v11, v2, v3, v10, v13}, Lc/z7;->f(JLjava/lang/String;I)V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_2

    goto :goto_8

    :catch_3
    const/4 v2, 0x0

    goto :goto_2

    :goto_7
    iput-wide v8, v7, Lc/Z7;->H:J

    :goto_8
    move v14, v1

    :cond_9
    :goto_9
    if-eqz v14, :cond_a

    iget-object v1, v7, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v2, Lc/P7;

    const/4 v3, 0x2

    invoke-direct {v2, v7, v3}, Lc/P7;-><init>(Lc/Z7;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_a
    return-void
.end method
