.class public final synthetic Lc/A4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J

.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Landroid/view/View;

.field public final synthetic e:J

.field public final synthetic f:Z

.field public final synthetic g:F

.field public final synthetic h:F


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;JLandroid/view/View;Landroid/view/View;JZFF)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/A4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/A4;->b:J

    iput-object p4, p0, Lc/A4;->c:Landroid/view/View;

    iput-object p5, p0, Lc/A4;->d:Landroid/view/View;

    iput-wide p6, p0, Lc/A4;->e:J

    iput-boolean p8, p0, Lc/A4;->f:Z

    iput p9, p0, Lc/A4;->g:F

    iput p10, p0, Lc/A4;->h:F

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v0, p0

    iget-object v10, v0, Lc/A4;->a:Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v10, Lru/drivedeck/launcher/MainActivity;->k:J

    iget-wide v11, v0, Lc/A4;->b:J

    cmp-long v1, v11, v1

    iget-object v13, v0, Lc/A4;->c:Landroid/view/View;

    iget-object v14, v0, Lc/A4;->d:Landroid/view/View;

    iget-wide v8, v0, Lc/A4;->e:J

    if-eqz v1, :cond_0

    const-string v4, "stale"

    move-object v1, v10

    move-wide v2, v11

    move-object v5, v13

    move-object v6, v14

    move-wide v7, v8

    invoke-virtual/range {v1 .. v8}, Lru/drivedeck/launcher/MainActivity;->q(JLjava/lang/String;Landroid/view/View;Landroid/view/View;J)V

    goto :goto_0

    :cond_0
    new-instance v15, Lc/E4;

    iget-boolean v7, v0, Lc/A4;->f:Z

    move-object v1, v15

    move-object v2, v10

    move-wide v3, v11

    move v5, v7

    move-object v6, v13

    move/from16 v16, v7

    move-object v7, v14

    invoke-direct/range {v1 .. v9}, Lc/E4;-><init>(Lru/drivedeck/launcher/MainActivity;JZLandroid/view/View;Landroid/view/View;J)V

    if-eqz v16, :cond_1

    iget v1, v0, Lc/A4;->g:F

    iget v2, v0, Lc/A4;->h:F

    mul-float v3, v1, v2

    const/4 v6, 0x0

    move-object v1, v10

    move-object v2, v13

    move-wide v4, v11

    invoke-virtual/range {v1 .. v6}, Lru/drivedeck/launcher/MainActivity;->d(Landroid/view/View;FJLc/E4;)V

    const/4 v3, 0x0

    move-object v2, v14

    move-object v6, v15

    invoke-virtual/range {v1 .. v6}, Lru/drivedeck/launcher/MainActivity;->d(Landroid/view/View;FJLc/E4;)V

    goto :goto_0

    :cond_1
    invoke-virtual {v15}, Lc/E4;->run()V

    :goto_0
    return-void
.end method
