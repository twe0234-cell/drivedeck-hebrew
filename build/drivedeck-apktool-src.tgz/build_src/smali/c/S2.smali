.class public final synthetic Lc/S2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;


# direct methods
.method public synthetic constructor <init>(Lc/k3;I)V
    .locals 0

    iput p2, p0, Lc/S2;->a:I

    iput-object p1, p0, Lc/S2;->b:Lc/k3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 13

    const/16 v0, 0x8

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v3, p0, Lc/S2;->a:I

    packed-switch v3, :pswitch_data_0

    const-string v0, ""

    iget-object v1, p0, Lc/S2;->b:Lc/k3;

    invoke-virtual {v1, v0}, Lc/k3;->e(Ljava/lang/String;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/S2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lc/N1;->d()Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    sget-object v1, Lc/N1;->X:Lc/N1;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, v1, Lc/N1;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Lc/H;

    const/4 v4, 0x3

    invoke-direct {v3, v1, v0, v4}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_1
    iput-boolean v2, v0, Lc/k3;->K:Z

    invoke-virtual {v0}, Lc/k3;->X()V

    new-instance v2, Lc/u2;

    invoke-direct {v2, v0, v1}, Lc/u2;-><init>(Lc/k3;I)V

    sget-object v0, Lc/N1;->X:Lc/N1;

    if-nez v0, :cond_2

    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    :cond_2
    iget-object v3, v0, Lc/N1;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v4, Lc/H;

    invoke-direct {v4, v0, v2, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_0
    return-void

    :pswitch_1
    iget-object v1, p0, Lc/S2;->b:Lc/k3;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lc/N1;->C()J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-nez v3, :cond_4

    sget-object v3, Lc/N1;->X:Lc/N1;

    if-nez v3, :cond_3

    goto :goto_1

    :cond_3
    const-wide/32 v7, 0x927c0

    invoke-static {v7, v8, v7, v8}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v7

    const-wide/16 v9, 0x3e8

    invoke-static {v9, v10, v7, v8}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    add-long/2addr v9, v7

    iget-object v4, v3, Lc/N1;->F:Ljava/lang/Object;

    monitor-enter v4

    :try_start_0
    iput-boolean v2, v3, Lc/N1;->K:Z

    iput-boolean v2, v3, Lc/N1;->L:Z

    iput-wide v9, v3, Lc/N1;->N:J

    iget-object v11, v3, Lc/N1;->b:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "enabled"

    invoke-interface {v11, v12, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "send_consent"

    invoke-interface {v11, v12, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v11, "timed_until"

    invoke-interface {v2, v11, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v11, "retry_at"

    invoke-interface {v2, v11, v5, v6}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iput-wide v5, v3, Lc/N1;->O:J

    const-string v2, "\u0421\u0431\u043e\u0440 \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0438 \u0432\u043a\u043b\u044e\u0447\u0451\u043d \u043d\u0430 10 \u043c\u0438\u043d\u0443\u0442"

    iput-object v2, v3, Lc/N1;->R:Ljava/lang/String;

    invoke-virtual {v3, v9, v10}, Lc/N1;->z(J)V

    monitor-exit v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object v2, Lc/N1;->W:Landroid/os/Handler;

    new-instance v4, Lc/D1;

    invoke-direct {v4, v3, v0}, Lc/D1;-><init>(Lc/N1;I)V

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v0, v3, Lc/N1;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lc/E1;

    invoke-direct {v2, v7, v8, v3}, Lc/E1;-><init>(JLc/N1;)V

    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_1
    const-string v0, "\u0421\u0431\u043e\u0440 \u043b\u043e\u0433\u043e\u0432 \u0432\u043a\u043b\u044e\u0447\u0451\u043d \u043d\u0430 10 \u043c\u0438\u043d\u0443\u0442"

    invoke-virtual {v1, v0}, Lc/k3;->J(Ljava/lang/String;)V

    invoke-virtual {v1}, Lc/k3;->X()V

    goto :goto_2

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :cond_4
    :goto_2
    return-void

    :pswitch_2
    iget-object v1, p0, Lc/S2;->b:Lc/k3;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    iget-object v1, v1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v3, :cond_5

    const-string v0, "\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442\u0441\u044f"

    invoke-static {v1, v0}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_3

    :cond_5
    new-instance v3, Landroid/app/Dialog;

    invoke-direct {v3, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    invoke-static {v1, v4}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    const-string v5, "\u041f\u0440\u0435\u0441\u0435\u0442\u044b \u0445\u0440\u0430\u043d\u044f\u0442\u0441\u044f \u0432 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0438 \u0438 \u0432\u043a\u043b\u044e\u0447\u0430\u044e\u0442\u0441\u044f \u0432 \u0444\u0430\u0439\u043b \u0440\u0435\u0437\u0435\u0440\u0432\u043d\u043e\u0439 \u043a\u043e\u043f\u0438\u0438."

    invoke-static {v1, v5}, Lc/q4;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v5, Lc/J1;

    const/4 v6, 0x6

    invoke-direct {v5, v1, v6}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-string v6, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432 \u0444\u0430\u0439\u043b"

    invoke-static {v1, v3, v4, v6, v5}, Lc/q4;->m(Landroid/app/Activity;Landroid/app/Dialog;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v5, Lc/J1;

    const/4 v6, 0x7

    invoke-direct {v5, v1, v6}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-string v6, "\u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0438\u0437 \u0444\u0430\u0439\u043b\u0430"

    invoke-static {v1, v3, v4, v6, v5}, Lc/q4;->m(Landroid/app/Activity;Landroid/app/Dialog;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v5, Lc/J1;

    invoke-direct {v5, v1, v0}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-string v0, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430"

    invoke-static {v1, v3, v4, v0, v5}, Lc/q4;->m(Landroid/app/Activity;Landroid/app/Dialog;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v0, Lc/J1;

    const/16 v5, 0x9

    invoke-direct {v0, v1, v5}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-string v5, "\u041f\u0440\u0438\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442"

    invoke-static {v1, v3, v4, v5, v0}, Lc/q4;->m(Landroid/app/Activity;Landroid/app/Dialog;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/Runnable;)V

    new-instance v0, Lc/J1;

    const/16 v5, 0xa

    invoke-direct {v0, v1, v5}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-string v5, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442"

    invoke-static {v1, v3, v4, v5, v0}, Lc/q4;->m(Landroid/app/Activity;Landroid/app/Dialog;Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/Runnable;)V

    const-string v0, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    invoke-static {v1, v3, v0}, Lc/q4;->g(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    new-array v2, v2, [Landroid/view/View;

    const/4 v5, 0x0

    aput-object v0, v2, v5

    const-string v0, "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f \u0438 \u043f\u0440\u0435\u0441\u0435\u0442\u044b"

    invoke-static {v3, v1, v0, v4, v2}, Lc/q4;->q(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;[Landroid/view/View;)V

    :goto_3
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
