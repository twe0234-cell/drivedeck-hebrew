.class public final Lc/D3;
.super Landroid/app/Dialog;
.source "SourceFile"


# virtual methods
.method public final onBackPressed()V
    .locals 2

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const-string v1, "music-screen-surface"

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lc/P3;

    if-eqz v0, :cond_0

    iget-object v1, v0, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/P3;->p()V

    return-void

    :cond_0
    invoke-super {p0}, Landroid/app/Dialog;->onBackPressed()V

    return-void
.end method
