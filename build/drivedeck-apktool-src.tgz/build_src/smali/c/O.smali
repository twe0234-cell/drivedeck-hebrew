.class public final Lc/O;
.super Landroid/os/Binder;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/ServiceConnection;


# direct methods
.method public synthetic constructor <init>(Landroid/content/ServiceConnection;I)V
    .locals 0

    iput p2, p0, Lc/O;->a:I

    iput-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    return-void
.end method


# virtual methods
.method public final onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 9

    iget v0, p0, Lc/O;->a:I

    packed-switch v0, :pswitch_data_0

    const p4, 0x5f4e5446

    const-string v0, "com.syu.ipc.IModuleCallback"

    const/4 v1, 0x1

    if-ne p1, p4, :cond_0

    if-eqz p3, :cond_3

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_1

    :cond_0
    const/4 p3, 0x0

    if-ne p1, v1, :cond_2

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result p1

    iget-object p4, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p4, Lc/y8;

    iget v2, p4, Lc/y8;->e:I

    if-eq p1, v2, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v0

    invoke-virtual {p2}, Landroid/os/Parcel;->createFloatArray()[F

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    const/4 p2, 0x2

    if-ne p1, p2, :cond_3

    if-eqz v0, :cond_3

    array-length p1, v0

    if-ne p1, v1, :cond_3

    aget p1, v0, p3

    if-ltz p1, :cond_3

    iget p2, p4, Lc/y8;->f:I

    if-gt p1, p2, :cond_3

    iget-object p2, p4, Lc/y8;->c:Landroid/os/Handler;

    new-instance p3, Lc/w;

    const/16 p4, 0xc

    invoke-direct {p3, p0, p1, p4}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    :cond_2
    :goto_0
    move v1, p3

    :cond_3
    :goto_1
    return v1

    :pswitch_0
    const v0, 0x5f4e5446

    const-string v1, "com.syu.ipc.IModuleCallback"

    const/4 v2, 0x1

    if-ne p1, v0, :cond_4

    if-eqz p3, :cond_8

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_5

    :cond_4
    if-eq p1, v2, :cond_5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    goto :goto_5

    :cond_5
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v6

    invoke-virtual {p2}, Landroid/os/Parcel;->createFloatArray()[F

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_7

    array-length p2, p1

    if-eqz p2, :cond_7

    const/4 p2, 0x0

    aget-object p1, p1, p2

    if-nez p1, :cond_6

    goto :goto_3

    :cond_6
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    :goto_2
    move-object v7, p1

    goto :goto_4

    :cond_7
    :goto_3
    const-string p1, ""

    goto :goto_2

    :goto_4
    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/g8;

    iget-object p1, p1, Lc/g8;->c:Landroid/os/Handler;

    new-instance p2, Lc/N;

    const/16 v8, 0xb

    move-object v3, p2

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lc/N;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_8
    :goto_5
    return v2

    :pswitch_1
    const v0, 0x5f4e5446

    const-string v1, "com.syu.ipc.IModuleCallback"

    const/4 v2, 0x1

    if-ne p1, v0, :cond_9

    if-eqz p3, :cond_b

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_6

    :cond_9
    if-eq p1, v2, :cond_a

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    goto :goto_6

    :cond_a
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v6

    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v8

    invoke-virtual {p2}, Landroid/os/Parcel;->createFloatArray()[F

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v7

    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/Z7;

    iget-object v5, p1, Lc/Z7;->k:Landroid/os/IBinder;

    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/Z7;

    iget-object p1, p1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance p2, Lc/F5;

    move-object v3, p2

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lc/F5;-><init>(Lc/O;Landroid/os/IBinder;I[Ljava/lang/String;[I)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_b
    :goto_6
    return v2

    :pswitch_2
    const v0, 0x5f4e5446

    const/4 v1, 0x1

    if-ne p1, v0, :cond_c

    if-eqz p3, :cond_f

    const-string p1, "ru.dublgis.api.IUpdateCallback"

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_8

    :cond_c
    if-eq p1, v1, :cond_d

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1

    goto :goto_8

    :cond_d
    const-string p1, "ru.dublgis.api.IUpdateCallback"

    invoke-virtual {p2, p1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    move-object v0, p1

    check-cast v0, Lc/o1;

    monitor-enter v0

    :try_start_0
    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/o1;

    iget-object p2, p1, Lc/o1;->e:Landroid/os/Handler;

    if-eqz p2, :cond_e

    iget-object p1, p1, Lc/o1;->k:Lc/i;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/o1;

    iget-object p2, p1, Lc/o1;->e:Landroid/os/Handler;

    iget-object p1, p1, Lc/o1;->k:Lc/i;

    invoke-virtual {p2, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_7

    :catchall_0
    move-exception p1

    goto :goto_9

    :cond_e
    :goto_7
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p3, :cond_f

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    :cond_f
    :goto_8
    return v1

    :goto_9
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :pswitch_3
    const v0, 0x5f4e5446

    const-string v1, "com.syu.ipc.IModuleCallback"

    const/4 v2, 0x1

    if-ne p1, v0, :cond_10

    if-eqz p3, :cond_13

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_c

    :cond_10
    if-eq p1, v2, :cond_11

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    goto :goto_c

    :cond_11
    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result v5

    invoke-virtual {p2}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v6

    invoke-virtual {p2}, Landroid/os/Parcel;->createFloatArray()[F

    invoke-virtual {p2}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_12

    array-length p2, p1

    if-lez p2, :cond_12

    const/4 p2, 0x0

    aget-object p1, p1, p2

    if-eqz p1, :cond_12

    :goto_a
    move-object v7, p1

    goto :goto_b

    :cond_12
    const-string p1, ""

    goto :goto_a

    :goto_b
    iget-object p1, p0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast p1, Lc/P;

    iget-object p1, p1, Lc/P;->c:Landroid/os/Handler;

    new-instance p2, Lc/N;

    const/4 v8, 0x0

    move-object v3, p2

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lc/N;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_13
    :goto_c
    return v2

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
