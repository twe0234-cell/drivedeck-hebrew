.class public final Lc/B3;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/P3;

.field public final synthetic b:Lc/u0;

.field public final synthetic c:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic d:Lc/n1;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/P3;Lc/u0;Lru/drivedeck/launcher/MainActivity;Lc/n1;)V
    .locals 0

    iput-object p2, p0, Lc/B3;->a:Lc/P3;

    iput-object p3, p0, Lc/B3;->b:Lc/u0;

    iput-object p4, p0, Lc/B3;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p5, p0, Lc/B3;->d:Lc/n1;

    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/B3;->a:Lc/P3;

    iget-object v1, v0, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    invoke-virtual {v1, v2, v3}, Lc/a5;->c(FF)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {v0}, Lc/P3;->p()V

    :cond_0
    invoke-super {p0, p1}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final onSizeChanged(IIII)V
    .locals 8

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    if-lez p1, :cond_1

    if-gtz p2, :cond_0

    goto :goto_0

    :cond_0
    sget-object p3, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object p3, p0, Lc/B3;->a:Lc/P3;

    invoke-virtual {p3}, Lc/P3;->p()V

    iget-object p4, p0, Lc/B3;->c:Lru/drivedeck/launcher/MainActivity;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {p4, v0}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p4

    invoke-virtual {p4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p4

    iget v5, p4, Landroid/util/DisplayMetrics;->density:F

    iget-object p4, p0, Lc/B3;->d:Lc/n1;

    invoke-virtual {p4}, Lc/n1;->C()I

    invoke-virtual {p4}, Lc/n1;->B()I

    iget-object p4, p0, Lc/B3;->b:Lc/u0;

    const/4 v6, 0x1

    const/4 v7, 0x0

    move-object v1, p4

    move v2, p1

    move v3, p2

    invoke-static/range {v1 .. v7}, Lc/G8;->k(Lc/u0;IIFFZZ)Lc/o0;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p3, p4, p1, p2}, Lc/P3;->g0(Lc/u0;Lc/o0;Lc/m0;)V

    :cond_1
    :goto_0
    return-void
.end method
