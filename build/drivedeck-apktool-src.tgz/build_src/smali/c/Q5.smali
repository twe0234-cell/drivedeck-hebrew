.class public final Lc/Q5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/Double;

.field public final f:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lc/S5;Lc/i6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q5;->a:Ljava/lang/String;

    iput-object p2, p0, Lc/Q5;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/Q5;->c:Ljava/lang/String;

    const/4 p1, 0x0

    if-nez p4, :cond_0

    move-object p2, p1

    goto :goto_0

    :cond_0
    iget-wide p2, p4, Lc/S5;->a:D

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p2

    :goto_0
    iput-object p2, p0, Lc/Q5;->e:Ljava/lang/Double;

    if-nez p5, :cond_1

    const/4 p2, 0x0

    goto :goto_1

    :cond_1
    if-nez p4, :cond_2

    iget p2, p5, Lc/i6;->o:I

    goto :goto_1

    :cond_2
    invoke-virtual {p4, p5}, Lc/S5;->a(Lc/i6;)I

    move-result p2

    :goto_1
    iput p2, p0, Lc/Q5;->f:I

    if-eqz p4, :cond_4

    if-nez p5, :cond_3

    goto :goto_2

    :cond_3
    iget-wide p1, p4, Lc/S5;->a:D

    invoke-virtual {p5, p1, p2}, Lc/i6;->f(D)Ljava/lang/String;

    move-result-object p1

    :cond_4
    :goto_2
    iput-object p1, p0, Lc/Q5;->d:Ljava/lang/String;

    return-void
.end method
