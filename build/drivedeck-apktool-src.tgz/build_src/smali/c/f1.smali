.class public final Lc/f1;
.super Landroid/widget/BaseAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lc/O7;Lc/N7;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lc/f1;->a:I

    .line 1
    iput-object p1, p0, Lc/f1;->d:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 2
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    .line 3
    iput-object p1, p0, Lc/f1;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/f1;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lc/g1;Ljava/util/ArrayList;Lc/r4;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lc/f1;->a:I

    .line 4
    iput-object p1, p0, Lc/f1;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/f1;->b:Ljava/lang/Object;

    iput-object p3, p0, Lc/f1;->c:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCount()I
    .locals 1

    iget v0, p0, Lc/f1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/f1;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    return v0

    :pswitch_0
    iget-object v0, p0, Lc/f1;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final getItem(I)Ljava/lang/Object;
    .locals 1

    iget v0, p0, Lc/f1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/f1;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :pswitch_0
    iget-object v0, p0, Lc/f1;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final getItemId(I)J
    .locals 2

    iget v0, p0, Lc/f1;->a:I

    packed-switch v0, :pswitch_data_0

    int-to-long v0, p1

    return-wide v0

    :pswitch_0
    iget-object v0, p0, Lc/f1;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/s0;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    int-to-long v0, p1

    return-wide v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 18

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v8, v0, Lc/f1;->d:Ljava/lang/Object;

    iget-object v9, v0, Lc/f1;->b:Ljava/lang/Object;

    iget v10, v0, Lc/f1;->a:I

    packed-switch v10, :pswitch_data_0

    iget-object v2, v0, Lc/f1;->c:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/y7;

    check-cast v9, Lc/N7;

    iget-object v2, v9, Lc/N7;->d:Ljava/lang/String;

    sget v10, Lc/O7;->G:I

    check-cast v8, Lc/O7;

    invoke-virtual {v8}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v10

    const/4 v11, 0x6

    invoke-virtual {v8, v11}, Lc/O7;->g(I)I

    move-result v12

    const/16 v13, 0xa

    invoke-virtual {v8, v13}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v8, v11}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v8, v13}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v10, v12, v14, v11, v15}, Landroid/view/View;->setPadding(IIII)V

    const/16 v11, 0x4c

    invoke-virtual {v8, v11}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "phone-contact:"

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v12, v1, Lc/y7;->b:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v11, Lc/l;

    const/16 v12, 0x8

    invoke-direct {v11, v0, v1, v2, v12}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v11, v1, Lc/y7;->a:Ljava/lang/String;

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v12

    move v14, v7

    :goto_0
    iget-object v15, v8, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v13, v1, Lc/y7;->b:Ljava/lang/String;

    if-ge v14, v12, :cond_1

    invoke-virtual {v11, v14}, Ljava/lang/String;->codePointAt(I)I

    move-result v16

    invoke-static/range {v16 .. v16}, Ljava/lang/Character;->isWhitespace(I)Z

    move-result v17

    if-nez v17, :cond_0

    goto :goto_2

    :cond_0
    invoke-static/range {v16 .. v16}, Ljava/lang/Character;->charCount(I)I

    move-result v13

    add-int/2addr v14, v13

    const/16 v13, 0xa

    goto :goto_0

    :cond_1
    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v11

    move v12, v7

    :goto_1
    if-ge v12, v11, :cond_3

    invoke-virtual {v13, v12}, Ljava/lang/String;->codePointAt(I)I

    move-result v14

    invoke-static {v14}, Ljava/lang/Character;->isWhitespace(I)Z

    move-result v16

    if-nez v16, :cond_2

    move-object v11, v13

    goto :goto_2

    :cond_2
    invoke-static {v14}, Ljava/lang/Character;->charCount(I)I

    move-result v14

    add-int/2addr v12, v14

    goto :goto_1

    :cond_3
    const-string v11, "\u041d\u043e\u043c\u0435\u0440 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    invoke-static {v15, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :goto_2
    invoke-virtual {v11, v7, v6}, Ljava/lang/String;->offsetByCodePoints(II)I

    move-result v12

    invoke-virtual {v11, v7, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v12

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v12

    const/16 v14, 0x13

    invoke-virtual {v8, v14, v12, v6}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v12

    const/16 v14, 0x11

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v3, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    iget-object v4, v8, Lc/O7;->c:Lc/r4;

    iget-boolean v5, v4, Lc/r4;->m:Z

    if-eqz v5, :cond_4

    iget v5, v4, Lc/r4;->c:I

    goto :goto_3

    :cond_4
    iget v5, v4, Lc/r4;->b:I

    :goto_3
    invoke-static {v4}, Lc/k6;->a(Lc/r4;)I

    move-result v7

    iget-boolean v6, v4, Lc/r4;->m:Z

    if-eqz v6, :cond_5

    const v6, 0x3df5c28f    # 0.12f

    goto :goto_4

    :cond_5
    const v6, 0x3da3d70a    # 0.08f

    :goto_4
    invoke-static {v6, v5, v7}, Lc/k6;->m(FII)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-static {v4}, Lc/k6;->a(Lc/r4;)I

    move-result v5

    invoke-virtual {v12, v5}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v12, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x28

    invoke-virtual {v8, v5}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v8, v5}, Lc/O7;->g(I)I

    move-result v7

    invoke-direct {v3, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v12, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v8}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v3

    const/4 v6, 0x1

    invoke-virtual {v8, v14, v11, v6}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v7, v6}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v3, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-wide/16 v11, 0x0

    move-object v7, v6

    iget-wide v5, v1, Lc/y7;->d:J

    cmp-long v11, v5, v11

    if-lez v11, :cond_6

    new-instance v12, Lc/n1;

    invoke-direct {v12, v15}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v12}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v12

    const-string v14, "dMMMHHmm"

    invoke-static {v12, v14}, Landroid/text/format/DateFormat;->getBestDateTimePattern(Ljava/util/Locale;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    new-instance v15, Ljava/text/SimpleDateFormat;

    invoke-direct {v15, v14, v12}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v12, Ljava/util/Date;

    invoke-direct {v12, v5, v6}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v15, v12}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v5

    goto :goto_5

    :cond_6
    move-object v5, v13

    :goto_5
    const/16 v6, 0xd

    const/4 v12, 0x0

    invoke-virtual {v8, v6, v5, v12}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    const/4 v6, 0x3

    iget v12, v1, Lc/y7;->f:I

    if-ne v12, v6, :cond_7

    invoke-static {v4}, Lc/k6;->y(Lc/r4;)I

    move-result v14

    goto :goto_6

    :cond_7
    iget v14, v4, Lc/r4;->e:I

    :goto_6
    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v14, 0x1

    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    if-lez v11, :cond_b

    const/4 v7, 0x2

    if-ne v12, v7, :cond_8

    const v7, 0x7f03005a

    goto :goto_7

    :cond_8
    const v7, 0x7f030058

    :goto_7
    if-ne v12, v6, :cond_9

    invoke-static {v4}, Lc/k6;->y(Lc/r4;)I

    move-result v6

    goto :goto_8

    :cond_9
    iget-boolean v6, v4, Lc/r4;->m:Z

    if-eqz v6, :cond_a

    const v6, -0xff9066

    goto :goto_8

    :cond_a
    invoke-static {v4}, Lc/k6;->a(Lc/r4;)I

    move-result v6

    :goto_8
    invoke-virtual {v8, v7, v6}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const/4 v7, 0x0

    invoke-virtual {v5, v6, v7, v7, v7}, Landroid/widget/TextView;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x4

    invoke-virtual {v8, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    :cond_b
    invoke-virtual {v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x0

    const/4 v7, -0x2

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v5, v6, v7, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v6, 0xa

    invoke-virtual {v8, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v10, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v3, 0x30

    if-nez v11, :cond_f

    const v5, 0x7f03005b

    const v6, 0x7f03005c

    iget-boolean v7, v1, Lc/y7;->c:Z

    if-eqz v7, :cond_c

    move v11, v6

    goto :goto_9

    :cond_c
    move v11, v5

    :goto_9
    new-instance v12, Lc/K7;

    invoke-direct {v12, v0, v2, v1}, Lc/K7;-><init>(Lc/f1;Ljava/lang/String;Lc/y7;)V

    const-string v14, "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u044b\u0435"

    invoke-virtual {v8, v11, v12, v14}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v11

    if-eqz v7, :cond_d

    move v5, v6

    :cond_d
    if-eqz v7, :cond_e

    invoke-static {v4}, Lc/k6;->a(Lc/r4;)I

    move-result v6

    goto :goto_a

    :cond_e
    iget v6, v4, Lc/r4;->e:I

    :goto_a
    invoke-virtual {v8, v5, v6}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-virtual {v11, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "phone-favorite:"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v5, 0x0

    invoke-virtual {v11, v5}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8, v3}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v8, v3}, Lc/O7;->g(I)I

    move-result v7

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_f
    new-instance v5, Lc/K7;

    invoke-direct {v5, v0, v1, v2}, Lc/K7;-><init>(Lc/f1;Lc/y7;Ljava/lang/String;)V

    const-string v6, "\u041f\u043e\u0437\u0432\u043e\u043d\u0438\u0442\u044c"

    const v7, 0x7f030053

    invoke-virtual {v8, v7, v5, v6}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v11, "phone-contact-call:"

    invoke-direct {v6, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-static {v4}, Lc/k6;->a(Lc/r4;)I

    move-result v4

    invoke-virtual {v8, v7, v4}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x0

    invoke-virtual {v5, v4}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v4, v8, Lc/O7;->b:Lc/Z7;

    iget-object v4, v4, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v4}, Lc/e8;->b()Z

    move-result v4

    if-eqz v4, :cond_10

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_10

    const/4 v6, 0x1

    goto :goto_b

    :cond_10
    const/4 v6, 0x0

    :goto_b
    invoke-virtual {v5, v6}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v5}, Landroid/view/View;->isEnabled()Z

    move-result v4

    if-eqz v4, :cond_11

    const/high16 v4, 0x3f800000    # 1.0f

    goto :goto_c

    :cond_11
    const v4, 0x3ecccccd    # 0.4f

    :goto_c
    invoke-virtual {v5, v4}, Landroid/view/View;->setAlpha(F)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x28

    invoke-virtual {v8, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v8, v3}, Lc/O7;->g(I)I

    move-result v3

    invoke-direct {v4, v6, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget v3, v9, Lc/N7;->a:I

    if-nez v3, :cond_12

    new-instance v3, Lc/J7;

    invoke-direct {v3, v8, v10, v1, v2}, Lc/J7;-><init>(Lc/O7;Landroid/widget/LinearLayout;Lc/y7;Ljava/lang/String;)V

    move-object v10, v3

    :cond_12
    return-object v10

    :pswitch_0
    instance-of v3, v2, Landroid/widget/LinearLayout;

    iget-object v4, v0, Lc/f1;->c:Ljava/lang/Object;

    check-cast v4, Lc/r4;

    check-cast v8, Lc/g1;

    if-eqz v3, :cond_13

    check-cast v2, Landroid/widget/LinearLayout;

    const/4 v7, 0x0

    goto/16 :goto_d

    :cond_13
    new-instance v2, Landroid/widget/LinearLayout;

    iget-object v3, v8, Lc/g1;->a:Lc/P3;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v8}, Lc/g1;->x()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v11, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v3, v4, Lc/r4;->c:I

    invoke-virtual {v11, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {v8, v3}, Lc/g1;->h(F)F

    move-result v5

    invoke-virtual {v11, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v5, Landroid/graphics/drawable/InsetDrawable;

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v8, v6}, Lc/g1;->h(F)F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v12

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v8, v7}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-virtual {v8, v6}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v14

    invoke-virtual {v8, v7}, Lc/g1;->h(F)F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v15

    move-object v10, v5

    invoke-direct/range {v10 .. v15}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {v8, v5}, Lc/g1;->h(F)F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-virtual {v8, v6}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    invoke-virtual {v8, v5}, Lc/g1;->h(F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v8, v6}, Lc/g1;->h(F)F

    move-result v6

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {v2, v7, v10, v5, v6}, Landroid/view/View;->setPadding(IIII)V

    new-instance v5, Landroid/widget/ImageView;

    iget-object v6, v8, Lc/g1;->a:Lc/P3;

    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v5, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x2

    invoke-virtual {v5, v7}, Landroid/view/View;->setImportantForAccessibility(I)V

    sget-object v7, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v5, v7}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x42000000    # 32.0f

    invoke-virtual {v8, v10}, Lc/g1;->h(F)F

    move-result v11

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    invoke-virtual {v8, v10}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    invoke-direct {v7, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Landroid/widget/TextView;

    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/high16 v6, 0x41900000    # 18.0f

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextSize(F)V

    iget v6, v4, Lc/r4;->d:I

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v6, 0x2

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x0

    const/4 v10, -0x2

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v3}, Lc/g1;->h(F)F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    iput v3, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v2, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_d
    check-cast v9, Ljava/util/ArrayList;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/s0;

    invoke-virtual {v2, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageView;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    const v6, 0x7f030046

    packed-switch v5, :pswitch_data_1

    :pswitch_1
    const v6, 0x7f03004c

    goto :goto_e

    :pswitch_2
    const v6, 0x7f0300c8

    goto :goto_e

    :pswitch_3
    const v6, 0x7f030052

    goto :goto_e

    :pswitch_4
    const v6, 0x7f030050

    goto :goto_e

    :pswitch_5
    const v6, 0x7f03004b

    goto :goto_e

    :pswitch_6
    const v6, 0x7f030040

    goto :goto_e

    :pswitch_7
    const v6, 0x7f03004e

    goto :goto_e

    :pswitch_8
    const v6, 0x7f030042

    goto :goto_e

    :pswitch_9
    const v6, 0x7f030041

    :goto_e
    :pswitch_a
    invoke-virtual {v3, v6}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v4, v4, Lc/r4;->d:I

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    iget-object v4, v8, Lc/g1;->a:Lc/P3;

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v1, v1, Lc/s0;->a:Ljava/lang/String;

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-object v2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_a
        :pswitch_a
        :pswitch_5
        :pswitch_1
        :pswitch_4
        :pswitch_3
        :pswitch_2
    .end packed-switch
.end method
