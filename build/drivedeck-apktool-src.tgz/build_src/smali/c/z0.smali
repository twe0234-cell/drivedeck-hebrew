.class public final synthetic Lc/z0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/n1;

.field public final synthetic b:I

.field public final synthetic c:Lc/F3;

.field public final synthetic d:[Landroid/widget/TextView;

.field public final synthetic e:[Ljava/lang/String;

.field public final synthetic f:Lc/r4;

.field public final synthetic g:[I


# direct methods
.method public synthetic constructor <init>(Lc/n1;ILc/F3;[Landroid/widget/TextView;[Ljava/lang/String;Lc/r4;[I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/z0;->a:Lc/n1;

    iput p2, p0, Lc/z0;->b:I

    iput-object p3, p0, Lc/z0;->c:Lc/F3;

    iput-object p4, p0, Lc/z0;->d:[Landroid/widget/TextView;

    iput-object p5, p0, Lc/z0;->e:[Ljava/lang/String;

    iput-object p6, p0, Lc/z0;->f:Lc/r4;

    iput-object p7, p0, Lc/z0;->g:[I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget-object p1, p0, Lc/z0;->a:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v0, 0x2

    iget v1, p0, Lc/z0;->b:I

    const/4 v2, 0x0

    const-string v3, "music_text_size"

    invoke-static {v0, v1, v2, p1, v3}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object p1, p0, Lc/z0;->c:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    move p1, v2

    :goto_0
    iget-object v0, p0, Lc/z0;->d:[Landroid/widget/TextView;

    const/4 v3, 0x3

    if-ge p1, v3, :cond_1

    aget-object v0, v0, p1

    iget-object v3, p0, Lc/z0;->e:[Ljava/lang/String;

    aget-object v3, v3, p1

    iget-object v4, p0, Lc/z0;->g:[I

    aget v4, v4, p1

    if-ne v4, v1, :cond_0

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    move v4, v2

    :goto_1
    iget-object v5, p0, Lc/z0;->f:Lc/r4;

    invoke-static {v0, v3, v5, v4}, Lc/G8;->T0(Landroid/widget/TextView;Ljava/lang/String;Lc/r4;Z)V

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
