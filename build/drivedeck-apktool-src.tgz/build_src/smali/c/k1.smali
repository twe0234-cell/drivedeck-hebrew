.class public final synthetic Lc/k1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;JLjava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, Lc/k1;->a:I

    iput-object p1, p0, Lc/k1;->c:Ljava/lang/Object;

    iput-wide p2, p0, Lc/k1;->b:J

    iput-object p4, p0, Lc/k1;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;JI)V
    .locals 0

    .line 2
    iput p5, p0, Lc/k1;->a:I

    iput-object p1, p0, Lc/k1;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/k1;->d:Ljava/lang/Object;

    iput-wide p3, p0, Lc/k1;->b:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget v0, p0, Lc/k1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-wide v1, p0, Lc/k1;->b:J

    iget-object v3, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Runnable;

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    :try_start_0
    invoke-static {v0}, Lc/A8;->c(Landroid/content/Context;)Lc/A8;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    sget-object v7, Lc/A8;->s:Ljava/lang/Object;

    monitor-enter v7

    :try_start_1
    sget-object v8, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v8

    cmp-long v1, v8, v1

    if-nez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    move v1, v6

    :goto_0
    if-eqz v1, :cond_1

    sput-object v0, Lc/A8;->v:Lc/A8;

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_3

    :cond_1
    :goto_1
    if-eqz v1, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    :cond_2
    sput-wide v4, Lc/A8;->w:J

    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    sget-object v0, Lc/A8;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    if-eqz v3, :cond_6

    :goto_2
    sget-object v0, Lc/A8;->r:Landroid/os/Handler;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_7

    :goto_3
    :try_start_2
    monitor-exit v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :catchall_1
    move-exception v0

    sget-object v7, Lc/A8;->s:Ljava/lang/Object;

    monitor-enter v7

    :try_start_3
    sget-object v8, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v8

    cmp-long v1, v8, v1

    if-nez v1, :cond_3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    goto :goto_4

    :catchall_2
    move-exception v0

    goto :goto_5

    :cond_3
    :goto_4
    sput-wide v4, Lc/A8;->w:J

    monitor-exit v7
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    sget-object v1, Lc/A8;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    if-eqz v3, :cond_4

    sget-object v1, Lc/A8;->r:Landroid/os/Handler;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_4
    throw v0

    :goto_5
    :try_start_4
    monitor-exit v7
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    throw v0

    :catch_0
    sget-object v0, Lc/A8;->s:Ljava/lang/Object;

    monitor-enter v0

    :try_start_5
    sget-object v7, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v7

    cmp-long v1, v7, v1

    if-nez v1, :cond_5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    goto :goto_6

    :catchall_3
    move-exception v1

    goto :goto_8

    :cond_5
    :goto_6
    sput-wide v4, Lc/A8;->w:J

    monitor-exit v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    sget-object v0, Lc/A8;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    if-eqz v3, :cond_6

    goto :goto_2

    :cond_6
    :goto_7
    return-void

    :goto_8
    :try_start_6
    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    throw v1

    :pswitch_0
    iget-object v0, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v1, Lc/Z7;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    iget-object v2, v1, Lc/Z7;->e:Lc/z7;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_7
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_1

    if-nez v3, :cond_7

    const-wide/16 v3, 0x0

    iget-wide v5, p0, Lc/k1;->b:J

    cmp-long v3, v5, v3

    if-lez v3, :cond_7

    :try_start_8
    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v3

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "calls"

    const-string v5, "device=? AND id=?"

    invoke-virtual {v2, v4, v5, v3}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_8
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_1

    :cond_7
    iget-object v2, v1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v3, Lc/W7;

    const/4 v4, 0x1

    invoke-direct {v3, v1, v0, v4}, Lc/W7;-><init>(Lc/Z7;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :catch_1
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-wide v0, v0, Lru/drivedeck/launcher/MainActivity;->k:J

    iget-wide v2, p0, Lc/k1;->b:J

    cmp-long v0, v2, v0

    if-nez v0, :cond_8

    iget-object v0, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v0, Lc/E4;

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Lc/E4;->run()V

    :cond_8
    return-void

    :pswitch_2
    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iget-object v2, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v2, [Landroid/app/Dialog;

    const/4 v3, 0x0

    aget-object v2, v2, v3

    if-ne v1, v2, :cond_9

    const/4 v1, 0x0

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iput-boolean v3, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    :cond_9
    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-wide v3, p0, Lc/k1;->b:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_a

    goto :goto_9

    :cond_a
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    new-instance v2, Lc/J1;

    const/16 v3, 0x1c

    invoke-direct {v2, v0, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v3, 0xb4

    invoke-virtual {v1, v2, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_9
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-wide v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->c:J

    iget-wide v3, p0, Lc/k1;->b:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_b

    goto :goto_a

    :cond_b
    const/4 v1, 0x0

    iput-boolean v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->d:Z

    new-instance v1, Lc/z;

    invoke-direct {v1, v0}, Lc/z;-><init>(Landroid/content/Context;)V

    iget-object v2, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/z;->h(Ljava/lang/String;)Z

    iget-object v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v1, :cond_c

    new-instance v2, Lc/n1;

    invoke-direct {v2, v0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v1, v0}, Lc/S1;->d(Ljava/util/ArrayList;)V

    :cond_c
    :goto_a
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Lc/t2;

    iget-wide v1, p0, Lc/k1;->b:J

    iget-object v3, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v0, v1, v2, v3}, Lc/t2;->p0(JLjava/lang/String;)V

    return-void

    :pswitch_5
    iget-object v0, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v0, Lc/t2;

    iget-wide v1, v0, Lc/t2;->c0:J

    iget-wide v3, p0, Lc/k1;->b:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_d

    const/4 v1, 0x0

    iput-object v1, v0, Lc/t2;->d0:Lc/H;

    iget-object v2, v0, Lc/t2;->f0:Lc/i2;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-object v1, v0, Lc/t2;->e0:Lc/v7;

    :cond_d
    iget-object v0, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    if-eqz v0, :cond_e

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_e
    return-void

    :pswitch_6
    iget-object v0, p0, Lc/k1;->d:Ljava/lang/Object;

    check-cast v0, Landroid/os/IBinder;

    iget-object v1, p0, Lc/k1;->c:Ljava/lang/Object;

    check-cast v1, Lc/o1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v3, 0x0

    :try_start_9
    invoke-static {v0, v2, v3}, Lc/o1;->e(Landroid/os/IBinder;ILandroid/os/Binder;)Landroid/os/Parcel;

    move-result-object v2
    :try_end_9
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_9} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_9} :catch_2

    :try_start_a
    invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I

    move-result v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    :try_start_b
    invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V

    const/4 v2, 0x2

    if-ne v3, v2, :cond_f

    iget-object v3, v1, Lc/o1;->l:Lc/O;

    invoke-static {v0, v2, v3}, Lc/o1;->e(Landroid/os/IBinder;ILandroid/os/Binder;)Landroid/os/Parcel;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v1}, Lc/o1;->b()V

    goto :goto_b

    :cond_f
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v2, "Unsupported 2GIS dashboard API"

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_4
    move-exception v0

    invoke-virtual {v2}, Landroid/os/Parcel;->recycle()V

    throw v0
    :try_end_b
    .catch Landroid/os/RemoteException; {:try_start_b .. :try_end_b} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_b .. :try_end_b} :catch_2

    :catch_2
    iget-object v0, v1, Lc/o1;->c:Landroid/os/Handler;

    new-instance v2, Lc/l1;

    iget-wide v3, p0, Lc/k1;->b:J

    const/4 v5, 0x0

    invoke-direct {v2, v1, v3, v4, v5}, Lc/l1;-><init>(Ljava/lang/Object;JI)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_b
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
