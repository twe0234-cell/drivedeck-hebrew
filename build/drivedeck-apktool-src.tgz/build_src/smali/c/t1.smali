.class public final Lc/t1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[[J

.field public b:J

.field public final c:[Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x9

    .line 2
    new-array v0, v0, [Lc/u1;

    iput-object v0, p0, Lc/t1;->c:[Ljava/lang/Object;

    const/16 v0, 0x8

    .line 3
    new-array v0, v0, [[J

    iput-object v0, p0, Lc/t1;->a:[[J

    const/4 v0, 0x0

    .line 4
    :goto_0
    iget-object v1, p0, Lc/t1;->c:[Ljava/lang/Object;

    check-cast v1, [Lc/u1;

    array-length v2, v1

    if-ge v0, v2, :cond_0

    new-instance v2, Lc/u1;

    invoke-direct {v2}, Lc/u1;-><init>()V

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public constructor <init>([[J[[JJ)V
    .locals 0

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    iput-object p1, p0, Lc/t1;->a:[[J

    iput-object p2, p0, Lc/t1;->c:[Ljava/lang/Object;

    iput-wide p3, p0, Lc/t1;->b:J

    return-void
.end method


# virtual methods
.method public declared-synchronized a()Lc/t1;
    .locals 5

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lc/t1;->c:[Ljava/lang/Object;

    check-cast v0, [Lc/u1;

    array-length v0, v0

    new-array v1, v0, [[J

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    iget-object v3, p0, Lc/t1;->c:[Ljava/lang/Object;

    check-cast v3, [Lc/u1;

    aget-object v3, v3, v2

    invoke-virtual {v3}, Lc/u1;->c()[J

    move-result-object v3

    aput-object v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    new-instance v0, Lc/t1;

    iget-object v2, p0, Lc/t1;->a:[[J

    invoke-virtual {v2}, [[J->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [[J

    iget-wide v3, p0, Lc/t1;->b:J

    invoke-direct {v0, v1, v2, v3, v4}, Lc/t1;-><init>([[J[[JJ)V

    iget-object v1, p0, Lc/t1;->a:[[J

    const/4 v2, 0x0

    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lc/t1;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
