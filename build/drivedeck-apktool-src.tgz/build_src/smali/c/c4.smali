.class public final synthetic Lc/c4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Landroid/os/Handler;

.field public final synthetic d:Landroid/content/Context;

.field public final synthetic e:J

.field public final synthetic f:Lc/v1;

.field public final synthetic g:Landroid/content/ComponentName;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/String;Landroid/os/Handler;Landroid/content/Context;JLc/v1;Landroid/content/ComponentName;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/c4;->a:I

    iput-object p2, p0, Lc/c4;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/c4;->c:Landroid/os/Handler;

    iput-object p4, p0, Lc/c4;->d:Landroid/content/Context;

    iput-wide p5, p0, Lc/c4;->e:J

    iput-object p7, p0, Lc/c4;->f:Lc/v1;

    iput-object p8, p0, Lc/c4;->g:Landroid/content/ComponentName;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 18

    move-object/from16 v0, p0

    sget v1, Lc/G8;->B:I

    iget v7, v0, Lc/c4;->a:I

    if-eq v7, v1, :cond_0

    goto :goto_0

    :cond_0
    sget-object v1, Lc/G8;->C:Ljava/lang/String;

    iget-object v12, v0, Lc/c4;->b:Ljava/lang/String;

    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    sput-object v12, Lc/G8;->C:Ljava/lang/String;

    const/4 v1, 0x1

    new-array v13, v1, [Landroid/media/browse/MediaBrowser;

    new-array v1, v1, [Ljava/lang/Runnable;

    new-instance v14, Lc/g4;

    iget-object v15, v0, Lc/c4;->c:Landroid/os/Handler;

    iget-object v11, v0, Lc/c4;->d:Landroid/content/Context;

    iget-wide v8, v0, Lc/c4;->e:J

    iget-object v10, v0, Lc/c4;->f:Lc/v1;

    move-object v2, v14

    move-object v3, v15

    move-object v4, v1

    move-object v5, v12

    move-object v6, v11

    move-object/from16 v16, v10

    move-object v10, v13

    move-object/from16 v17, v15

    move-object v15, v11

    move-object/from16 v11, v16

    invoke-direct/range {v2 .. v11}, Lc/g4;-><init>(Landroid/os/Handler;[Ljava/lang/Runnable;Ljava/lang/String;Landroid/content/Context;IJ[Landroid/media/browse/MediaBrowser;Lc/v1;)V

    new-instance v2, Landroid/media/browse/MediaBrowser;

    iget-object v3, v0, Lc/c4;->g:Landroid/content/ComponentName;

    const/4 v4, 0x0

    invoke-direct {v2, v15, v3, v14, v4}, Landroid/media/browse/MediaBrowser;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/media/browse/MediaBrowser$ConnectionCallback;Landroid/os/Bundle;)V

    const/4 v3, 0x0

    aput-object v2, v13, v3

    new-instance v2, Lc/H;

    const/16 v5, 0x10

    invoke-direct {v2, v12, v13, v5}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    aput-object v2, v1, v3

    const-wide/16 v5, 0x7530

    move-object/from16 v7, v17

    invoke-virtual {v7, v2, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :try_start_0
    aget-object v2, v13, v3

    invoke-virtual {v2}, Landroid/media/browse/MediaBrowser;->connect()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    aget-object v1, v1, v3

    invoke-virtual {v7, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v1, Lc/G8;->C:Ljava/lang/String;

    invoke-virtual {v12, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    sput-object v4, Lc/G8;->C:Ljava/lang/String;

    :cond_2
    aget-object v1, v13, v3

    invoke-virtual {v1}, Landroid/media/browse/MediaBrowser;->disconnect()V

    :goto_0
    return-void
.end method
