.class public final synthetic Lc/x6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/widget/LinearLayout;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Landroid/view/KeyEvent$Callback;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/H6;Landroid/widget/Spinner;Landroid/widget/Button;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/x6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/x6;->d:Landroid/view/KeyEvent$Callback;

    iput-object p2, p0, Lc/x6;->e:Ljava/lang/Object;

    iput-object p3, p0, Lc/x6;->f:Ljava/lang/Object;

    iput-object p4, p0, Lc/x6;->g:Ljava/lang/Object;

    iput-object p5, p0, Lc/x6;->b:Landroid/widget/LinearLayout;

    iput-object p6, p0, Lc/x6;->h:Ljava/lang/Object;

    iput-object p7, p0, Lc/x6;->c:Landroid/widget/TextView;

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lc/T5;Ljava/lang/String;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/x6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/x6;->d:Landroid/view/KeyEvent$Callback;

    iput-object p2, p0, Lc/x6;->e:Ljava/lang/Object;

    iput-object p3, p0, Lc/x6;->f:Ljava/lang/Object;

    iput-object p4, p0, Lc/x6;->g:Ljava/lang/Object;

    iput-object p5, p0, Lc/x6;->h:Ljava/lang/Object;

    iput-object p6, p0, Lc/x6;->b:Landroid/widget/LinearLayout;

    iput-object p7, p0, Lc/x6;->c:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget v0, p0, Lc/x6;->a:I

    packed-switch v0, :pswitch_data_0

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lc/x6;->d:Landroid/view/KeyEvent$Callback;

    move-object v5, v1

    check-cast v5, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v5}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c PID?"

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    iget-object v1, p0, Lc/x6;->e:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v9, Lc/U6;

    iget-object v7, p0, Lc/x6;->b:Landroid/widget/LinearLayout;

    iget-object v8, p0, Lc/x6;->c:Landroid/widget/TextView;

    iget-object v2, p0, Lc/x6;->f:Ljava/lang/Object;

    move-object v3, v2

    check-cast v3, Lc/T5;

    iget-object v2, p0, Lc/x6;->g:Ljava/lang/Object;

    move-object v4, v2

    check-cast v4, Ljava/lang/String;

    iget-object v2, p0, Lc/x6;->h:Ljava/lang/Object;

    move-object v6, v2

    check-cast v6, Lc/r4;

    move-object v2, v9

    invoke-direct/range {v2 .. v8}, Lc/U6;-><init>(Lc/T5;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    invoke-virtual {v0, v1, v9}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/x6;->d:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lc/H6;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/x6;->e:Ljava/lang/Object;

    check-cast v1, Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v1

    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    move v4, v3

    goto :goto_0

    :cond_0
    move v4, v2

    :goto_0
    iget-object v5, p0, Lc/x6;->f:Ljava/lang/Object;

    check-cast v5, Landroid/widget/Button;

    invoke-virtual {v5, v4}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x1

    if-ne v1, v4, :cond_1

    move v5, v3

    goto :goto_1

    :cond_1
    move v5, v2

    :goto_1
    iget-object v6, p0, Lc/x6;->g:Ljava/lang/Object;

    check-cast v6, Landroid/widget/Switch;

    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    if-nez v1, :cond_2

    move v5, v2

    goto :goto_2

    :cond_2
    move v5, v3

    :goto_2
    iget-object v6, p0, Lc/x6;->b:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    const/4 v5, 0x2

    if-ne v1, v5, :cond_3

    move v2, v3

    :cond_3
    iget-object v3, p0, Lc/x6;->h:Ljava/lang/Object;

    check-cast v3, Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/view/View;->setVisibility(I)V

    if-nez v1, :cond_4

    const-string v1, "\u0410\u0432\u0442\u043e\u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e. \u041f\u043e\u0441\u043b\u0435 \u043f\u0430\u0440\u043a\u043e\u0432\u043a\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0430\u0439\u0442\u0435\u0441\u044c \u0432\u0440\u0443\u0447\u043d\u0443\u044e."

    goto :goto_3

    :cond_4
    if-ne v1, v4, :cond_5

    const-string v1, "\u0421\u0438\u0433\u043d\u0430\u043b ACC \u0438\u043b\u0438 \u043f\u043e\u0442\u0435\u0440\u044f \u043f\u0438\u0442\u0430\u043d\u0438\u044f \u043e\u0442\u043a\u043b\u044e\u0447\u0430\u044e\u0442 OBD. \u0421\u0438\u0433\u043d\u0430\u043b \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435. \u0414\u0430\u0442\u0447\u0438\u043a \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u044f: 0 \u2014 \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e, \u0434\u0440\u0443\u0433\u043e\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u2014 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u043e. \u042d\u043a\u0440\u0430\u043d \u0443\u0447\u0438\u0442\u044b\u0432\u0430\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0451\u043d\u043d\u043e\u0439 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0435. \u0411\u0435\u0437 \u0441\u0438\u0433\u043d\u0430\u043b\u0430 \u043f\u0440\u043e\u0431\u0443\u0436\u0434\u0435\u043d\u0438\u044f \u043f\u043e\u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044f \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c\u0441\u044f \u0432\u0440\u0443\u0447\u043d\u0443\u044e \u0438\u043b\u0438 \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0440\u0435\u0436\u0438\u043c \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u044f."

    goto :goto_3

    :cond_5
    if-ne v1, v5, :cond_6

    const-string v1, "\u0414\u043b\u044f \u0431\u043e\u043a\u0441\u043e\u0432 \u0431\u0435\u0437 \u0441\u0438\u0433\u043d\u0430\u043b\u0430 \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u044f. \u041f\u0440\u0438 \u043d\u0438\u0437\u043a\u043e\u043c \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0438 \u043f\u043e\u0441\u043b\u0435 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0438 \u043f\u0440\u0435\u043a\u0440\u0430\u0449\u0430\u044e\u0442\u0441\u044f \u0437\u0430\u043f\u0440\u043e\u0441\u044b \u043a \u042d\u0411\u0423. \u041e\u0441\u0442\u0430\u0451\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 ELM \u0440\u0430\u0437 \u0432 15 \u0441\u0435\u043a\u0443\u043d\u0434. \u0415\u0441\u043b\u0438 ELM \u0443\u0441\u043d\u0443\u043b, \u0440\u0430\u0437 \u0432 \u043c\u0438\u043d\u0443\u0442\u0443 \u043f\u0440\u043e\u0432\u0435\u0440\u044f\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u0430\u0434\u0430\u043f\u0442\u0435\u0440, \u0431\u0435\u0437 \u042d\u0411\u0423. \u0414\u0432\u0430 \u0437\u0430\u043c\u0435\u0440\u0430 \u0432\u044b\u0448\u0435 \u043f\u043e\u0440\u043e\u0433\u0430 \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u044e\u0442 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435. \u041f\u043e\u0440\u043e\u0433 \u043f\u0440\u043e\u0431\u0443\u0436\u0434\u0435\u043d\u0438\u044f \u043c\u0438\u043d\u0438\u043c\u0443\u043c \u043d\u0430 0,3 \u0412 \u0432\u044b\u0448\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f. \u041f\u043e\u0434\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u043e\u0440\u043e\u0433\u0438 \u043f\u043e\u0434 \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044c: \u0443\u043c\u043d\u0430\u044f \u0437\u0430\u0440\u044f\u0434\u043a\u0430 \u0438 \u0433\u0438\u0431\u0440\u0438\u0434\u043d\u044b\u0439 DC/DC \u043c\u043e\u0433\u0443\u0442 \u043c\u0435\u043d\u044f\u0442\u044c \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u043f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0451\u043d\u043d\u043e\u043c \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u0435."

    goto :goto_3

    :cond_6
    const-string v1, "\u0422\u043e\u043b\u044c\u043a\u043e \u0434\u043b\u044f \u0414\u0412\u0421 \u0431\u0435\u0437 \u0441\u0442\u0430\u0440\u0442-\u0441\u0442\u043e\u043f\u0430. \u041f\u043e\u0441\u043b\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u044e\u0449\u0435\u0433\u043e \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b\u044f: \u043d\u0443\u043b\u0435\u0432\u044b\u0435 \u043e\u0431\u043e\u0440\u043e\u0442\u044b \u0438\u043b\u0438 \u0438\u0445 \u043f\u043e\u0442\u0435\u0440\u044f \u043f\u0440\u0438 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043d\u043d\u043e\u0439 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0435 \u0437\u0430\u043f\u0443\u0441\u043a\u0430\u044e\u0442 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0443. \u0414\u043b\u044f \u0433\u0438\u0431\u0440\u0438\u0434\u043e\u0432 \u0438 \u0441\u0442\u0430\u0440\u0442-\u0441\u0442\u043e\u043f\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u0435 \u043b\u0438\u0431\u043e \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435. \u041f\u043e\u0432\u0442\u043e\u0440\u043d\u043e\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u2014 \u043f\u043e ACC/\u043f\u0438\u0442\u0430\u043d\u0438\u044e \u0438\u043b\u0438 \u0432\u0440\u0443\u0447\u043d\u0443\u044e."

    :goto_3
    iget-object v0, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/x6;->c:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
