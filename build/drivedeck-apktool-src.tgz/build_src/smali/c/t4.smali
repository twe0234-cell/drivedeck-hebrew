.class public final synthetic Lc/t4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Predicate;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/t4;->a:I

    iput-object p1, p0, Lc/t4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final test(Ljava/lang/Object;)Z
    .locals 5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object v2, p0, Lc/t4;->b:Lru/drivedeck/launcher/MainActivity;

    iget v3, p0, Lc/t4;->a:I

    check-cast p1, Ljava/lang/String;

    packed-switch v3, :pswitch_data_0

    sget v3, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    :catch_0
    :goto_0
    move v3, v0

    goto :goto_1

    :cond_0
    :try_start_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    invoke-virtual {v4, v3, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_1
    move v3, v1

    :goto_1
    if-nez v3, :cond_2

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-static {p1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    goto :goto_2

    :cond_1
    :try_start_1
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, p1, v0}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_3

    goto :goto_2

    :catch_2
    :cond_2
    move v0, v1

    :catch_3
    :cond_3
    :goto_2
    return v0

    :pswitch_0
    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-static {p1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v3

    if-eqz v3, :cond_4

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_5

    iget-object v2, v2, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-static {p1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p1

    if-nez p1, :cond_5

    :cond_4
    move v0, v1

    :cond_5
    return v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
