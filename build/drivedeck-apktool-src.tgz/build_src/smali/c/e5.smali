.class public final Lc/e5;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:F

.field public final synthetic b:Lc/g5;


# direct methods
.method public constructor <init>(Lc/g5;F)V
    .locals 0

    iput-object p1, p0, Lc/e5;->b:Lc/g5;

    iput p2, p0, Lc/e5;->a:F

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 5

    iget-object p1, p0, Lc/e5;->b:Lc/g5;

    const/4 v0, 0x0

    iput-object v0, p1, Lc/g5;->J:Landroid/animation/ValueAnimator;

    iget v1, p0, Lc/e5;->a:F

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    iget-object v2, p1, Lc/g5;->a:Lc/P3;

    if-nez v1, :cond_0

    const/4 v1, 0x0

    iput-boolean v1, p1, Lc/g5;->C:Z

    iget-object v3, p1, Lc/g5;->v:[Lc/f5;

    if-eqz v3, :cond_1

    const/4 v4, 0x1

    aget-object v3, v3, v4

    iget-object v3, v3, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v3, p1, Lc/g5;->v:[Lc/f5;

    iput-object v3, p1, Lc/g5;->u:[Lc/f5;

    iput-object v0, p1, Lc/g5;->v:[Lc/f5;

    iput-boolean v1, p1, Lc/g5;->E:Z

    iget-object p1, p1, Lc/g5;->H:Lc/d5;

    invoke-virtual {v2, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lc/g5;->d()V

    iget-boolean v0, p1, Lc/g5;->C:Z

    if-eqz v0, :cond_1

    const-wide/16 v0, 0x898

    iget-object p1, p1, Lc/g5;->K:Lc/d5;

    invoke-virtual {v2, p1, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    :goto_0
    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    return-void
.end method
