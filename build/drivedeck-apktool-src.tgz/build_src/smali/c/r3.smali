.class public final Lc/r3;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final o:Ljava/util/concurrent/ExecutorService;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Landroid/location/LocationManager;

.field public final c:Lc/F3;

.field public final d:Landroid/os/Handler;

.field public final e:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public f:J

.field public g:Z

.field public h:Z

.field public i:Lc/q3;

.field public j:Landroid/location/Location;

.field public k:I

.field public l:I

.field public m:Ljava/lang/String;

.field public final n:Lc/e1;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lc/o3;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc/o3;-><init>(I)V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lc/r3;->o:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/r3;->d:Landroid/os/Handler;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    iput-object v0, p0, Lc/r3;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, -0x1

    iput v0, p0, Lc/r3;->k:I

    const/high16 v0, -0x80000000

    iput v0, p0, Lc/r3;->l:I

    const-string v0, ""

    iput-object v0, p0, Lc/r3;->m:Ljava/lang/String;

    new-instance v0, Lc/e1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/r3;->n:Lc/e1;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lc/r3;->a:Landroid/content/Context;

    const-string v0, "location"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/location/LocationManager;

    iput-object p1, p0, Lc/r3;->b:Landroid/location/LocationManager;

    iput-object p2, p0, Lc/r3;->c:Lc/F3;

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 6

    iget v0, p0, Lc/r3;->k:I

    if-ltz v0, :cond_0

    return v0

    :cond_0
    iget-object v0, p0, Lc/r3;->j:Landroid/location/Location;

    const/4 v1, -0x1

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/location/Location;->hasSpeed()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getSpeed()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->isFinite(F)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getSpeed()F

    move-result v0

    const/4 v2, 0x0

    cmpg-float v0, v0, v2

    if-gez v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v2

    iget-object v0, p0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-ltz v0, :cond_3

    const-wide v4, 0x12a05f200L

    cmp-long v0, v2, v4

    if-lez v0, :cond_2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Landroid/location/Location;->getSpeed()F

    move-result v0

    const v1, 0x40666666    # 3.6f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0

    :cond_3
    :goto_0
    return v1
.end method

.method public final b()V
    .locals 3

    invoke-virtual {p0}, Lc/r3;->a()I

    move-result v0

    iget v1, p0, Lc/r3;->k:I

    if-ltz v1, :cond_0

    const-string v1, "\u0421\u0438\u043c\u0443\u043b\u044f\u0446\u0438\u044f GPS"

    goto :goto_1

    :cond_0
    iget-object v1, p0, Lc/r3;->a:Landroid/content/Context;

    const-string v2, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v1, v2}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_1

    const-string v1, "\u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u0430 \u043a GPS"

    goto :goto_1

    :cond_1
    :try_start_0
    iget-object v1, p0, Lc/r3;->b:Landroid/location/LocationManager;

    if-eqz v1, :cond_4

    const-string v2, "gps"

    invoke-virtual {v1, v2}, Landroid/location/LocationManager;->isProviderEnabled(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Lc/r3;->a()I

    move-result v1

    if-gez v1, :cond_3

    const-string v1, "\u041e\u0436\u0438\u0434\u0430\u043d\u0438\u0435 GPS"

    goto :goto_1

    :cond_3
    const-string v1, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c GPS"

    goto :goto_1

    :cond_4
    :goto_0
    :try_start_1
    const-string v1, "GPS \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d"
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    const-string v1, "GPS \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    :goto_1
    iget v2, p0, Lc/r3;->l:I

    if-ne v0, v2, :cond_5

    iget-object v2, p0, Lc/r3;->m:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    return-void

    :cond_5
    iput v0, p0, Lc/r3;->l:I

    iput-object v1, p0, Lc/r3;->m:Ljava/lang/String;

    iget-object v0, p0, Lc/r3;->c:Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    return-void
.end method
