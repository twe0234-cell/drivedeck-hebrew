.class public final synthetic Lc/d2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/d2;->a:I

    iput-object p1, p0, Lc/d2;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/d2;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget p1, p0, Lc/d2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/d2;->b:Ljava/lang/Object;

    check-cast p1, Lc/l9;

    iget-boolean p2, p1, Lc/l9;->n:Z

    if-eqz p2, :cond_0

    invoke-virtual {p1}, Lc/l9;->a()V

    iget-object p1, p0, Lc/d2;->c:Ljava/lang/Object;

    check-cast p1, Ljava/util/function/IntConsumer;

    invoke-interface {p1, p3}, Ljava/util/function/IntConsumer;->accept(I)V

    :cond_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/d2;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/ArrayList;

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lc/a;

    iget-object p2, p2, Lc/a;->a:Ljava/lang/String;

    const-string p4, "package"

    filled-new-array {p4, p2}, [Ljava/lang/Object;

    move-result-object p2

    const-string p4, "app_grid_selection"

    invoke-static {p4, p2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/a;

    iget-object p2, p0, Lc/d2;->c:Ljava/lang/Object;

    check-cast p2, Lc/r2;

    invoke-virtual {p2, p1}, Lc/r2;->a(Lc/a;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
