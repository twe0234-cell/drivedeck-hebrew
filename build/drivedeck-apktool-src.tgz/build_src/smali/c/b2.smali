.class public final Lc/b2;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Lc/q8;


# static fields
.field public static final x0:Landroid/graphics/Typeface;


# instance fields
.field public final A:Lc/v8;

.field public final B:Landroid/graphics/RectF;

.field public C:Z

.field public D:Z

.field public E:Ljava/lang/Runnable;

.field public F:Ljava/lang/Runnable;

.field public final G:Landroid/graphics/RectF;

.field public final H:Landroid/graphics/RectF;

.field public final I:Landroid/graphics/RectF;

.field public final J:Landroid/graphics/RectF;

.field public final K:Landroid/graphics/RectF;

.field public final L:Landroid/graphics/RectF;

.field public final M:Ljava/util/ArrayList;

.field public N:I

.field public final O:Ljava/util/ArrayList;

.field public final P:Landroid/graphics/RectF;

.field public Q:Lc/v8;

.field public R:Ljava/lang/String;

.field public S:Ljava/lang/String;

.field public T:Z

.field public U:Z

.field public V:Ljava/lang/String;

.field public W:I

.field public final a:Landroid/graphics/RectF;

.field public a0:F

.field public final b:Landroid/graphics/Rect;

.field public b0:F

.field public c:Z

.field public c0:Landroid/animation/ValueAnimator;

.field public d:Ljava/util/function/Consumer;

.field public d0:Ljava/util/ArrayList;

.field public e:F

.field public final e0:Lc/n1;

.field public f:Landroid/animation/ValueAnimator;

.field public final f0:Ljava/text/SimpleDateFormat;

.field public final g:Lc/E;

.field public final g0:Ljava/util/Date;

.field public final h:Lc/W1;

.field public h0:F

.field public i:Z

.field public i0:F

.field public j:I

.field public j0:J

.field public k:Z

.field public k0:Z

.field public final l:[F

.field public l0:Z

.field public final m:[I

.field public m0:Z

.field public n:Z

.field public n0:Z

.field public o:Lc/W3;

.field public o0:Z

.field public final p:Landroid/graphics/Path;

.field public p0:Z

.field public final q:Landroid/graphics/RectF;

.field public final q0:Lc/o5;

.field public final r:[I

.field public final r0:Z

.field public s:I

.field public final s0:Landroid/os/Handler;

.field public t:Landroid/graphics/Bitmap;

.field public final t0:Lc/E;

.field public u:Landroid/graphics/Bitmap;

.field public final u0:Lc/e1;

.field public v:Z

.field public v0:Landroid/graphics/Bitmap;

.field public w:I

.field public final w0:Landroid/graphics/Paint;

.field public final x:Landroid/graphics/Paint;

.field public final y:Landroid/graphics/Paint;

.field public final z:Lc/z;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "sans"

    const/4 v1, 0x1

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lc/b2;->x0:Landroid/graphics/Typeface;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;)V
    .locals 7

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    .line 1
    invoke-direct/range {v0 .. v6}, Lc/b2;-><init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;ZZ)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;ZZ)V
    .locals 4

    .line 2
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 3
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/b2;->a:Landroid/graphics/RectF;

    .line 4
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lc/b2;->b:Landroid/graphics/Rect;

    .line 5
    new-instance v0, Lc/E;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lc/E;-><init>(Lc/b2;I)V

    iput-object v0, p0, Lc/b2;->g:Lc/E;

    .line 6
    new-instance v0, Lc/W1;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/W1;-><init>(Landroid/view/View;I)V

    iput-object v0, p0, Lc/b2;->h:Lc/W1;

    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lc/b2;->i:Z

    const/16 v1, 0x9

    .line 8
    new-array v1, v1, [F

    iput-object v1, p0, Lc/b2;->l:[F

    const/4 v1, 0x2

    .line 9
    new-array v2, v1, [I

    iput-object v2, p0, Lc/b2;->m:[I

    .line 10
    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    iput-object v2, p0, Lc/b2;->p:Landroid/graphics/Path;

    .line 11
    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/b2;->q:Landroid/graphics/RectF;

    .line 12
    new-array v1, v1, [I

    iput-object v1, p0, Lc/b2;->r:[I

    .line 13
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lc/b2;->x:Landroid/graphics/Paint;

    .line 14
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lc/b2;->y:Landroid/graphics/Paint;

    .line 15
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->B:Landroid/graphics/RectF;

    .line 16
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->G:Landroid/graphics/RectF;

    .line 17
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->H:Landroid/graphics/RectF;

    .line 18
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->I:Landroid/graphics/RectF;

    .line 19
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->J:Landroid/graphics/RectF;

    .line 20
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->K:Landroid/graphics/RectF;

    .line 21
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->L:Landroid/graphics/RectF;

    .line 22
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lc/b2;->M:Ljava/util/ArrayList;

    .line 23
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, Lc/b2;->O:Ljava/util/ArrayList;

    .line 24
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/b2;->P:Landroid/graphics/RectF;

    const/4 v1, -0x1

    .line 25
    iput v1, p0, Lc/b2;->W:I

    .line 26
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string v2, "HH:mm"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v1, p0, Lc/b2;->f0:Ljava/text/SimpleDateFormat;

    .line 27
    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    iput-object v1, p0, Lc/b2;->g0:Ljava/util/Date;

    .line 28
    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v1, p0, Lc/b2;->s0:Landroid/os/Handler;

    .line 29
    new-instance v1, Lc/E;

    const/4 v2, 0x3

    invoke-direct {v1, p0, v2}, Lc/E;-><init>(Lc/b2;I)V

    iput-object v1, p0, Lc/b2;->t0:Lc/E;

    .line 30
    new-instance v1, Lc/e1;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v1, p0, Lc/b2;->u0:Lc/e1;

    .line 31
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lc/b2;->w0:Landroid/graphics/Paint;

    .line 32
    iput-object p2, p0, Lc/b2;->z:Lc/z;

    .line 33
    iput-object p4, p0, Lc/b2;->A:Lc/v8;

    .line 34
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2, p3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object p2, p0, Lc/b2;->d0:Ljava/util/ArrayList;

    .line 35
    new-instance p2, Lc/n1;

    invoke-direct {p2, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lc/b2;->e0:Lc/n1;

    .line 36
    iput-boolean p5, p0, Lc/b2;->p0:Z

    .line 37
    iput-boolean p6, p0, Lc/b2;->r0:Z

    const/4 p1, 0x0

    if-eqz p6, :cond_0

    move-object p2, p1

    goto :goto_0

    .line 38
    :cond_0
    new-instance p2, Lc/o5;

    .line 39
    invoke-direct {p2, p0, p1}, Lc/o5;-><init>(Landroid/view/View;Lc/F3;)V

    .line 40
    :goto_0
    iput-object p2, p0, Lc/b2;->q0:Lc/o5;

    .line 41
    invoke-virtual {p0, v0, p1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    const/high16 p1, 0x40c00000    # 6.0f

    .line 42
    invoke-virtual {p0, p1}, Lc/b2;->m(F)F

    move-result p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setElevation(F)V

    .line 43
    new-instance p1, Lc/Z1;

    const/4 p2, 0x0

    invoke-direct {p1, p0, p2}, Lc/Z1;-><init>(Landroid/view/View;I)V

    invoke-virtual {p0, p1}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    .line 44
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string p2, "\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u0434\u043e\u043a DriveDeck"

    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public static H(FII)F
    .locals 1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    const/high16 p1, 0x40000000    # 2.0f

    div-float/2addr p0, p1

    return p0

    :cond_0
    rem-int/lit8 p2, p2, 0x2

    if-nez p2, :cond_1

    const/high16 p1, 0x3e800000    # 0.25f

    goto :goto_0

    :cond_1
    const/high16 p1, 0x3f400000    # 0.75f

    :goto_0
    mul-float/2addr p0, p1

    return p0
.end method


# virtual methods
.method public final A()V
    .locals 8

    iget-object v0, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->f0()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/b2;->r0:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/b2;->v:Z

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-lez v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    if-lez v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    instance-of v0, v0, Landroid/app/Activity;

    if-nez v0, :cond_0

    goto/16 :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    check-cast v0, Landroid/app/Activity;

    iget-object v1, p0, Lc/b2;->r:[I

    invoke-virtual {p0, v1}, Landroid/view/View;->getLocationInWindow([I)V

    const/4 v2, 0x0

    aget v3, v1, v2

    int-to-float v3, v3

    invoke-virtual {p0}, Landroid/view/View;->getTranslationX()F

    move-result v4

    sub-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    const/4 v4, 0x1

    aget v1, v1, v4

    int-to-float v1, v1

    invoke-virtual {p0}, Landroid/view/View;->getTranslationY()F

    move-result v5

    sub-float/2addr v1, v5

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    new-instance v5, Landroid/graphics/Rect;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v6

    add-int/2addr v6, v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v7

    add-int/2addr v7, v1

    invoke-direct {v5, v3, v1, v6, v7}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual {v5, v2, v2, v1, v3}, Landroid/graphics/Rect;->intersect(IIII)Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    :try_start_0
    invoke-virtual {v5}, Landroid/graphics/Rect;->width()I

    move-result v1

    div-int/lit8 v1, v1, 0x6

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v5}, Landroid/graphics/Rect;->height()I

    move-result v3

    div-int/lit8 v3, v3, 0x6

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    sget-object v6, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v3, v6}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_1

    iput-boolean v4, p0, Lc/b2;->v:Z

    iget v3, p0, Lc/b2;->w:I

    add-int/2addr v3, v4

    iput v3, p0, Lc/b2;->w:I

    :try_start_1
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    new-instance v4, Lc/T1;

    invoke-direct {v4, p0, v1, v3}, Lc/T1;-><init>(Lc/b2;Landroid/graphics/Bitmap;I)V

    iget-object v3, p0, Lc/b2;->s0:Landroid/os/Handler;

    invoke-static {v0, v5, v1, v4, v3}, Landroid/view/PixelCopy;->request(Landroid/view/Window;Landroid/graphics/Rect;Landroid/graphics/Bitmap;Landroid/view/PixelCopy$OnPixelCopyFinishedListener;Landroid/os/Handler;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->recycle()V

    iput-boolean v2, p0, Lc/b2;->v:Z

    :catch_1
    :cond_2
    :goto_0
    return-void
.end method

.method public final B()V
    .locals 4

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget v0, p0, Lc/b2;->s:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/b2;->s:I

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Lc/U1;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v0, v3}, Lc/U1;-><init>(Lc/b2;II)V

    invoke-static {v1, v2}, Lc/X3;->f(Landroid/content/Context;Ljava/util/function/Consumer;)V

    return-void
.end method

.method public final C(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V
    .locals 7

    const/4 v0, -0x3

    if-ne p2, v0, :cond_0

    iget-boolean v0, p0, Lc/b2;->c:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4, p3}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    iget-boolean p3, p0, Lc/b2;->D:Z

    const/4 v0, 0x0

    if-eqz p3, :cond_2

    :cond_1
    move-object v6, v0

    goto :goto_1

    :cond_2
    const/4 p3, -0x1

    iget-object v1, p0, Lc/b2;->A:Lc/v8;

    if-ne p2, p3, :cond_3

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p3, Lc/Y1;

    const/4 v0, 0x0

    invoke-direct {p3, v1, v0}, Lc/Y1;-><init>(Lc/v8;I)V

    :goto_0
    move-object v6, p3

    goto :goto_1

    :cond_3
    const/4 p3, -0x2

    if-ne p2, p3, :cond_1

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p3, Lc/Y1;

    const/4 v0, 0x1

    invoke-direct {p3, v1, v0}, Lc/Y1;-><init>(Lc/v8;I)V

    goto :goto_0

    :goto_1
    new-instance v5, Lc/H;

    const/4 p3, 0x6

    invoke-direct {v5, p0, v4, p3}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object v1, p1

    move-object v2, p0

    move v3, p2

    invoke-static/range {v1 .. v6}, Lc/t8;->b(Ljava/util/ArrayList;Landroid/view/View;ILandroid/graphics/RectF;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    return-void
.end method

.method public final D(Ljava/util/ArrayList;)V
    .locals 1

    invoke-virtual {p0}, Lc/b2;->B()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v0, p0, Lc/b2;->d0:Ljava/util/ArrayList;

    invoke-virtual {p0}, Landroid/view/View;->invalidateOutline()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final E(Z)V
    .locals 1

    iput-boolean p1, p0, Lc/b2;->n0:Z

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/b2;->o0:Z

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0, p1, v0}, Lc/b2;->g(FF)I

    move-result p1

    invoke-virtual {p0, p1}, Lc/b2;->v(I)V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final F(Z)V
    .locals 1

    iget-boolean v0, p0, Lc/b2;->D:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Lc/b2;->D:Z

    const/4 p1, 0x0

    iput-boolean p1, p0, Lc/b2;->l0:Z

    iput-boolean p1, p0, Lc/b2;->k0:Z

    iget-object p1, p0, Lc/b2;->s0:Landroid/os/Handler;

    iget-object v0, p0, Lc/b2;->t0:Lc/E;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/b2;->I:Landroid/graphics/RectF;

    invoke-virtual {p1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final G()F
    .locals 4

    iget-boolean v0, p0, Lc/b2;->i:Z

    const/high16 v1, 0x41200000    # 10.0f

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->g0()Z

    move-result v0

    const/high16 v2, 0x42940000    # 74.0f

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/b2;->r0:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-nez v0, :cond_1

    iget v0, p0, Lc/b2;->e:F

    const/4 v3, 0x0

    cmpl-float v0, v0, v3

    if-lez v0, :cond_1

    move v1, v2

    :cond_1
    return v1

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Lc/E;

    const/4 v3, 0x1

    invoke-direct {v1, p0, v3}, Lc/E;-><init>(Lc/b2;I)V

    invoke-static {v0, v1}, Lc/A8;->d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;

    move-result-object v0

    iget-boolean v1, v0, Lc/A8;->e:Z

    iget-boolean v3, v0, Lc/A8;->b:Z

    add-int/2addr v1, v3

    iget-boolean v3, v0, Lc/A8;->c:Z

    add-int/2addr v1, v3

    iget-boolean v3, v0, Lc/A8;->d:Z

    add-int/2addr v1, v3

    const/4 v3, 0x2

    if-le v1, v3, :cond_3

    const/high16 v2, 0x430e0000    # 142.0f

    goto :goto_0

    :cond_3
    iget-object v1, v0, Lc/A8;->h:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v0, v0, Lc/A8;->i:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    :cond_4
    const/high16 v2, 0x42b40000    # 90.0f

    :cond_5
    :goto_0
    return v2
.end method

.method public final I(II)F
    .locals 1

    const/4 v0, 0x2

    if-le p1, v0, :cond_0

    if-lt p2, v0, :cond_0

    const/high16 p1, 0x42d00000    # 104.0f

    goto :goto_0

    :cond_0
    const/high16 p1, 0x424c0000    # 51.0f

    :goto_0
    invoke-virtual {p0, p1}, Lc/b2;->m(F)F

    move-result p1

    return p1
.end method

.method public final J(F)F
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final K()V
    .locals 5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v2

    iget-object v3, p0, Lc/b2;->b:Landroid/graphics/Rect;

    invoke-virtual {v2, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    sget-boolean v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->q:Z

    if-nez v2, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    move-result v3

    sub-int/2addr v2, v3

    int-to-float v2, v2

    const/high16 v3, 0x43160000    # 150.0f

    invoke-virtual {p0, v3}, Lc/b2;->m(F)F

    move-result v3

    cmpl-float v2, v2, v3

    if-lez v2, :cond_0

    goto :goto_0

    :cond_0
    move v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    move v2, v0

    :goto_1
    iget-boolean v3, p0, Lc/b2;->c:Z

    if-ne v3, v2, :cond_2

    return-void

    :cond_2
    iput-boolean v2, p0, Lc/b2;->c:Z

    iget-object v3, p0, Lc/b2;->d:Ljava/util/function/Consumer;

    if-eqz v3, :cond_3

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    invoke-interface {v3, v4}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_3
    iget-object v3, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    if-eqz v3, :cond_4

    invoke-virtual {v3}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_4
    if-eqz v2, :cond_5

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_2

    :cond_5
    const/4 v2, 0x0

    :goto_2
    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v3

    if-nez v3, :cond_6

    iput v2, p0, Lc/b2;->e:F

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :cond_6
    iget v3, p0, Lc/b2;->e:F

    const/4 v4, 0x2

    new-array v4, v4, [F

    aput v3, v4, v1

    aput v2, v4, v0

    invoke-static {v4}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    iput-object v0, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    const-wide/16 v2, 0x104

    invoke-virtual {v0, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v0, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object v0, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    new-instance v2, Lc/X1;

    invoke-direct {v2, p0, v1}, Lc/X1;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object v0, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    return-void
.end method

.method public final d(Ljava/util/ArrayList;)V
    .locals 2

    iget-boolean v0, p0, Lc/b2;->r0:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/b2;->a:Landroid/graphics/RectF;

    const/4 v1, -0x3

    invoke-virtual {p0, p1, v1, v0}, Lc/b2;->C(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    iget-object v0, p0, Lc/b2;->B:Landroid/graphics/RectF;

    const/4 v1, -0x2

    invoke-virtual {p0, p1, v1, v0}, Lc/b2;->C(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    iget-object v0, p0, Lc/b2;->G:Landroid/graphics/RectF;

    const/4 v1, -0x1

    invoke-virtual {p0, p1, v1, v0}, Lc/b2;->C(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Lc/b2;->N:I

    if-ge v0, v1, :cond_1

    iget-object v1, p0, Lc/b2;->M:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    invoke-virtual {p0, p1, v0, v1}, Lc/b2;->C(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public final f(F)F
    .locals 3

    const/high16 v0, 0x42400000    # 48.0f

    invoke-virtual {p0, v0}, Lc/b2;->J(F)F

    move-result v0

    const/high16 v1, 0x42800000    # 64.0f

    invoke-virtual {p0, v1}, Lc/b2;->J(F)F

    move-result v1

    iget-object v2, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->m()I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v1, v2

    const/high16 v2, 0x42c80000    # 100.0f

    div-float/2addr v1, v2

    invoke-static {p1, v1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    return p1
.end method

.method public final g(FF)I
    .locals 7

    const/high16 v0, 0x42800000    # 64.0f

    invoke-virtual {p0, v0}, Lc/b2;->J(F)F

    move-result v0

    invoke-virtual {p0}, Lc/b2;->x()Z

    move-result v1

    const/high16 v2, 0x41800000    # 16.0f

    if-eqz v1, :cond_0

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v1

    sub-float v1, p2, v1

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v1

    sub-float v1, p1, v1

    :goto_0
    invoke-virtual {p0, v1}, Lc/b2;->f(F)F

    move-result v1

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v3

    add-float/2addr v3, v1

    invoke-virtual {p0}, Lc/b2;->x()Z

    move-result v1

    const/high16 v4, 0x41200000    # 10.0f

    const/high16 v5, 0x41400000    # 12.0f

    if-eqz v1, :cond_3

    iget-boolean p2, p0, Lc/b2;->i:Z

    if-eqz p2, :cond_1

    invoke-virtual {p0}, Lc/b2;->z()F

    move-result p2

    goto :goto_1

    :cond_1
    const/4 p2, 0x0

    :goto_1
    invoke-virtual {p0, v4}, Lc/b2;->m(F)F

    move-result v1

    invoke-virtual {p0, v5}, Lc/b2;->m(F)F

    move-result v4

    invoke-virtual {p0}, Lc/b2;->y()Z

    move-result v5

    add-float v6, v1, v0

    if-eqz v5, :cond_2

    add-float/2addr v6, v4

    goto :goto_2

    :cond_2
    move v6, v1

    :goto_2
    add-float/2addr v6, v0

    add-float/2addr v6, v4

    sub-float/2addr p1, v1

    sub-float/2addr p1, p2

    sub-float/2addr p1, v4

    sub-float/2addr p1, v6

    goto :goto_3

    :cond_3
    invoke-virtual {p0}, Lc/b2;->G()F

    move-result p1

    add-float/2addr p1, v4

    invoke-virtual {p0, p1}, Lc/b2;->m(F)F

    move-result p1

    sub-float/2addr p2, p1

    sub-float/2addr p2, v0

    invoke-virtual {p0, v5}, Lc/b2;->m(F)F

    move-result p1

    sub-float p1, p2, p1

    invoke-virtual {p0}, Lc/b2;->y()Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-virtual {p0, v5}, Lc/b2;->m(F)F

    move-result p2

    add-float/2addr p2, v0

    sub-float/2addr p1, p2

    :cond_4
    :goto_3
    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result p2

    add-float/2addr p2, p1

    div-float/2addr p2, v3

    float-to-double p1, p2

    invoke-static {p1, p2}, Ljava/lang/Math;->floor(D)D

    move-result-wide p1

    double-to-int p1, p1

    const/4 p2, 0x1

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    return p1
.end method

.method public final h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V
    .locals 1

    iget-object v0, p0, Lc/b2;->y:Landroid/graphics/Paint;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object p5, Lc/b2;->x0:Landroid/graphics/Typeface;

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p5

    const/high16 p6, 0x40000000    # 2.0f

    div-float/2addr p5, p6

    sub-float/2addr p3, p5

    invoke-virtual {p1, p2, p3, p4, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final i(FF)I
    .locals 5

    iget v0, p0, Lc/b2;->N:I

    if-nez v0, :cond_0

    const/4 p1, -0x1

    return p1

    :cond_0
    invoke-virtual {p0}, Lc/b2;->x()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    move p1, p2

    :goto_0
    const/4 p2, 0x0

    const v1, 0x7f7fffff    # Float.MAX_VALUE

    move v2, v1

    move v1, p2

    :goto_1
    iget v3, p0, Lc/b2;->N:I

    if-ge p2, v3, :cond_4

    iget-object v3, p0, Lc/b2;->M:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    if-eqz v0, :cond_2

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    goto :goto_2

    :cond_2
    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    :goto_2
    sub-float v3, p1, v3

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    cmpg-float v4, v3, v2

    if-gez v4, :cond_3

    move v1, p2

    move v2, v3

    :cond_3
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_4
    return v1
.end method

.method public final j()V
    .locals 1

    iget-object v0, p0, Lc/b2;->u:Landroid/graphics/Bitmap;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/b2;->t:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    :cond_1
    iget-object v0, p0, Lc/b2;->u:Landroid/graphics/Bitmap;

    iput-object v0, p0, Lc/b2;->t:Landroid/graphics/Bitmap;

    const/4 v0, 0x0

    iput-object v0, p0, Lc/b2;->u:Landroid/graphics/Bitmap;

    return-void
.end method

.method public final k(FFFI)F
    .locals 3

    iget-object v0, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->m()I

    move-result v0

    add-int/lit8 v0, v0, -0x64

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    const/high16 v2, 0x42a00000    # 80.0f

    div-float/2addr v0, v2

    int-to-float v2, p4

    mul-float/2addr v2, p2

    sub-float/2addr p1, v2

    const/4 p2, 0x1

    sub-int/2addr p4, p2

    invoke-static {v1, p4}, Ljava/lang/Math;->max(II)I

    move-result v1

    int-to-float v1, v1

    mul-float/2addr v1, p3

    sub-float/2addr p1, v1

    const/4 v1, 0x0

    invoke-static {v1, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    mul-float/2addr p1, v0

    invoke-static {p2, p4}, Ljava/lang/Math;->max(II)I

    move-result p2

    int-to-float p2, p2

    div-float/2addr p1, p2

    add-float/2addr p1, p3

    return p1
.end method

.method public final l(FFFI)F
    .locals 2

    add-int/lit8 v0, p4, -0x1

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    mul-float/2addr v0, p3

    sub-float/2addr p2, v0

    const/4 p3, 0x1

    invoke-static {p3, p4}, Ljava/lang/Math;->max(II)I

    move-result p3

    int-to-float p3, p3

    div-float/2addr p2, p3

    const/high16 p3, 0x42580000    # 54.0f

    invoke-virtual {p0, p3}, Lc/b2;->m(F)F

    move-result p3

    iget-object p4, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {p4}, Lc/n1;->m()I

    move-result p4

    int-to-float p4, p4

    mul-float/2addr p3, p4

    const/high16 p4, 0x42c80000    # 100.0f

    div-float/2addr p3, p4

    invoke-static {p1, p2}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {p3, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-static {p2, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    return p1
.end method

.method public final m(F)F
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final n(Landroid/graphics/Canvas;FF)V
    .locals 9

    iget-boolean v0, p0, Lc/b2;->C:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/b2;->x:Landroid/graphics/Paint;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    iget v1, v1, Lc/r4;->j:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v1, 0x40200000    # 2.5f

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result v2

    sub-float v2, p2, v2

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result v3

    sub-float v3, p3, v3

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result v4

    add-float/2addr v4, p2

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result p2

    add-float v5, p2, p3

    const/high16 p2, 0x40c00000    # 6.0f

    invoke-virtual {p0, p2}, Lc/b2;->m(F)F

    move-result v6

    invoke-virtual {p0, p2}, Lc/b2;->m(F)F

    move-result v7

    move-object v1, p1

    move-object v8, v0

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    sget-object p1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void

    :cond_0
    const/high16 v0, 0x42400000    # 48.0f

    invoke-virtual {p0, v0}, Lc/b2;->m(F)F

    move-result v6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iget v7, v0, Lc/r4;->j:I

    const v3, 0x7f030017

    move-object v1, p0

    move-object v2, p1

    move v4, p2

    move v5, p3

    invoke-virtual/range {v1 .. v7}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    return-void
.end method

.method public final o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V
    .locals 3

    iget-boolean v0, p0, Lc/b2;->D:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v1, p3, Lc/r4;->j:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    iget-boolean p3, p3, Lc/r4;->m:Z

    if-eqz p3, :cond_1

    const/16 p3, 0xc

    goto :goto_0

    :cond_1
    const/16 p3, 0x14

    :goto_0
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setAlpha(I)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result p3

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr p3, v1

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v1

    invoke-virtual {p1, p2, p3, v2, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/16 p1, 0xff

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 2

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    invoke-virtual {p0}, Lc/b2;->B()V

    iget-boolean v0, p0, Lc/b2;->r0:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/b2;->q0:Lc/o5;

    invoke-virtual {v0}, Lc/o5;->a()V

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->r:Ljava/util/HashSet;

    iget-object v1, p0, Lc/b2;->g:Lc/E;

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iget-object v1, p0, Lc/b2;->h:Lc/W1;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    invoke-virtual {p0}, Lc/b2;->K()V

    iget-object v0, p0, Lc/b2;->s0:Landroid/os/Handler;

    iget-object v1, p0, Lc/b2;->u0:Lc/e1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 4

    iget v0, p0, Lc/b2;->w:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/b2;->w:I

    iget-object v0, p0, Lc/b2;->t:Landroid/graphics/Bitmap;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    iput-object v1, p0, Lc/b2;->t:Landroid/graphics/Bitmap;

    :cond_0
    iget-object v0, p0, Lc/b2;->u:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    iput-object v1, p0, Lc/b2;->u:Landroid/graphics/Bitmap;

    :cond_1
    iget-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_2
    iget-object v0, p0, Lc/b2;->f:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_3
    const/4 v0, 0x0

    iput v0, p0, Lc/b2;->e:F

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/b2;->c:Z

    iget-object v1, p0, Lc/b2;->s0:Landroid/os/Handler;

    iget-object v2, p0, Lc/b2;->t0:Lc/E;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v0, p0, Lc/b2;->l0:Z

    iput-boolean v0, p0, Lc/b2;->k0:Z

    iget-object v2, p0, Lc/b2;->I:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v2, p0, Lc/b2;->u0:Lc/e1;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v1, Lru/drivedeck/launcher/LauncherAccessibilityService;->r:Ljava/util/HashSet;

    iget-object v2, p0, Lc/b2;->g:Lc/E;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    iget-object v2, p0, Lc/b2;->h:Lc/W1;

    invoke-virtual {v1, v2}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_4
    iget-object v1, p0, Lc/b2;->q0:Lc/o5;

    if-eqz v1, :cond_6

    iget-object v2, v1, Lc/o5;->b:Landroid/net/ConnectivityManager;

    if-eqz v2, :cond_6

    iget-boolean v3, v1, Lc/o5;->c:Z

    if-nez v3, :cond_5

    goto :goto_0

    :cond_5
    :try_start_0
    iget-object v3, v1, Lc/o5;->f:Lc/n5;

    invoke-virtual {v2, v3}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iput-boolean v0, v1, Lc/o5;->c:Z

    iput-boolean v0, v1, Lc/o5;->d:Z

    :cond_6
    :goto_0
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 53

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget-object v0, v7, Lc/b2;->f0:Ljava/text/SimpleDateFormat;

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    iget-object v1, v7, Lc/b2;->P:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, v7, Lc/b2;->a:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v9, v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v10, v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v11

    iget v1, v11, Lc/r4;->j:I

    iput v1, v7, Lc/b2;->j:I

    iget-object v1, v7, Lc/b2;->Q:Lc/v8;

    iget-object v3, v7, Lc/b2;->r:[I

    iget-object v15, v7, Lc/b2;->e0:Lc/n1;

    const/high16 v16, 0x40000000    # 2.0f

    iget v4, v11, Lc/r4;->b:I

    if-eqz v1, :cond_1

    :cond_0
    :goto_0
    move-object/from16 v23, v0

    move/from16 v25, v9

    move/from16 v26, v10

    move-object/from16 v24, v11

    move-object/from16 v28, v15

    goto/16 :goto_a

    :cond_1
    invoke-virtual {v15}, Lc/n1;->f0()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, v7, Lc/b2;->t:Landroid/graphics/Bitmap;

    goto :goto_1

    :cond_2
    iget-object v1, v7, Lc/b2;->o:Lc/W3;

    if-nez v1, :cond_3

    const/4 v1, 0x0

    goto :goto_1

    :cond_3
    iget-object v1, v1, Lc/W3;->c:Landroid/graphics/Bitmap;

    :goto_1
    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v17

    if-eqz v17, :cond_4

    goto :goto_0

    :cond_4
    invoke-virtual {v7, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v6

    iget-object v2, v7, Lc/b2;->m:[I

    invoke-virtual {v6, v2}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getWidth()I

    move-result v12

    invoke-static {v6, v12}, Ljava/lang/Math;->max(II)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v12

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Landroid/view/View;->getHeight()I

    move-result v14

    invoke-static {v12, v14}, Ljava/lang/Math;->max(II)I

    move-result v12

    int-to-float v12, v12

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v14

    int-to-float v14, v14

    div-float v14, v6, v14

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    int-to-float v5, v5

    div-float v5, v12, v5

    invoke-static {v14, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    invoke-virtual {v15}, Lc/n1;->f0()Z

    move-result v14

    invoke-virtual/range {p0 .. p0}, Lc/b2;->x()Z

    move-result v22

    if-eqz v22, :cond_5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v13

    int-to-float v13, v13

    move-object/from16 v23, v0

    const/high16 v0, 0x435c0000    # 220.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    invoke-static {v13, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    goto :goto_2

    :cond_5
    move-object/from16 v23, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    :goto_2
    invoke-virtual/range {p0 .. p0}, Lc/b2;->x()Z

    move-result v13

    if-eqz v13, :cond_6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v13

    int-to-float v13, v13

    goto :goto_3

    :cond_6
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v13

    int-to-float v13, v13

    const/high16 v8, 0x43160000    # 150.0f

    invoke-virtual {v7, v8}, Lc/b2;->m(F)F

    move-result v8

    invoke-static {v13, v8}, Ljava/lang/Math;->min(FF)F

    move-result v13

    :goto_3
    move-object/from16 v24, v11

    const/4 v8, 0x0

    :goto_4
    const/4 v11, 0x3

    move/from16 v25, v9

    iget-object v9, v7, Lc/b2;->l:[F

    if-ge v8, v11, :cond_9

    move/from16 v26, v10

    const/4 v10, 0x0

    :goto_5
    if-ge v10, v11, :cond_8

    add-int/lit8 v11, v10, 0x1

    move-object/from16 v28, v15

    int-to-float v15, v11

    mul-float/2addr v15, v0

    const/high16 v22, 0x40800000    # 4.0f

    div-float v15, v15, v22

    move/from16 v29, v0

    add-int/lit8 v0, v8, 0x1

    int-to-float v0, v0

    mul-float/2addr v0, v13

    div-float v0, v0, v22

    if-eqz v14, :cond_7

    move/from16 v30, v11

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v11

    int-to-float v11, v11

    mul-float/2addr v15, v11

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v11

    int-to-float v11, v11

    div-float/2addr v15, v11

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v11

    int-to-float v11, v11

    mul-float/2addr v0, v11

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v11

    int-to-float v11, v11

    div-float/2addr v0, v11

    move/from16 v31, v13

    goto :goto_6

    :cond_7
    move/from16 v30, v11

    move/from16 v31, v13

    const/4 v11, 0x0

    aget v13, v3, v11

    int-to-float v13, v13

    add-float/2addr v15, v13

    aget v13, v2, v11

    int-to-float v11, v13

    sub-float/2addr v15, v11

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v11

    int-to-float v11, v11

    mul-float/2addr v11, v5

    sub-float/2addr v11, v6

    div-float v11, v11, v16

    add-float/2addr v11, v15

    div-float v15, v11, v5

    const/4 v11, 0x1

    aget v13, v3, v11

    int-to-float v13, v13

    add-float/2addr v0, v13

    aget v13, v2, v11

    int-to-float v11, v13

    sub-float/2addr v0, v11

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v11

    int-to-float v11, v11

    mul-float/2addr v11, v5

    sub-float/2addr v11, v12

    div-float v11, v11, v16

    add-float/2addr v11, v0

    div-float v0, v11, v5

    :goto_6
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v11

    const/4 v13, 0x1

    sub-int/2addr v11, v13

    float-to-int v15, v15

    invoke-static {v11, v15}, Ljava/lang/Math;->min(II)I

    move-result v11

    const/4 v15, 0x0

    invoke-static {v15, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v19

    add-int/lit8 v15, v19, -0x1

    float-to-int v0, v0

    invoke-static {v15, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v13, 0x0

    invoke-static {v13, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {v1, v11, v0}, Landroid/graphics/Bitmap;->getPixel(II)I

    move-result v0

    invoke-static {v0}, Landroid/graphics/Color;->red(I)I

    move-result v11

    mul-int/lit16 v11, v11, 0xcc

    invoke-static {v4}, Landroid/graphics/Color;->red(I)I

    move-result v13

    mul-int/lit8 v13, v13, 0x33

    add-int/2addr v13, v11

    const/16 v11, 0xff

    div-int/2addr v13, v11

    invoke-static {v0}, Landroid/graphics/Color;->green(I)I

    move-result v15

    mul-int/lit16 v15, v15, 0xcc

    invoke-static {v4}, Landroid/graphics/Color;->green(I)I

    move-result v20

    mul-int/lit8 v20, v20, 0x33

    add-int v15, v20, v15

    div-int/2addr v15, v11

    invoke-static {v0}, Landroid/graphics/Color;->blue(I)I

    move-result v0

    mul-int/lit16 v0, v0, 0xcc

    invoke-static {v4}, Landroid/graphics/Color;->blue(I)I

    move-result v20

    mul-int/lit8 v20, v20, 0x33

    add-int v0, v20, v0

    div-int/2addr v0, v11

    invoke-static {v13, v15, v0}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    mul-int/lit8 v11, v8, 0x3

    add-int/2addr v11, v10

    invoke-static {v0}, Landroid/graphics/Color;->luminance(I)F

    move-result v0

    aput v0, v9, v11

    move-object/from16 v15, v28

    move/from16 v0, v29

    move/from16 v10, v30

    move/from16 v13, v31

    const/4 v11, 0x3

    goto/16 :goto_5

    :cond_8
    move/from16 v29, v0

    move/from16 v31, v13

    move-object/from16 v28, v15

    add-int/lit8 v8, v8, 0x1

    move/from16 v9, v25

    move/from16 v10, v26

    goto/16 :goto_4

    :cond_9
    move/from16 v26, v10

    move-object/from16 v28, v15

    invoke-static {v9}, Ljava/util/Arrays;->sort([F)V

    const/4 v0, 0x4

    aget v0, v9, v0

    iget-boolean v1, v7, Lc/b2;->k:Z

    if-nez v1, :cond_b

    const v1, 0x3e3851ec    # 0.18f

    cmpg-float v0, v0, v1

    if-gez v0, :cond_a

    const/4 v0, 0x1

    goto :goto_7

    :cond_a
    const/4 v0, 0x0

    :goto_7
    iput-boolean v0, v7, Lc/b2;->n:Z

    const/4 v1, 0x1

    iput-boolean v1, v7, Lc/b2;->k:Z

    goto :goto_8

    :cond_b
    const/4 v1, 0x1

    const v2, 0x3e0f5c29    # 0.14f

    cmpg-float v2, v0, v2

    if-gez v2, :cond_c

    iput-boolean v1, v7, Lc/b2;->n:Z

    goto :goto_8

    :cond_c
    const v1, 0x3e6147ae    # 0.22f

    cmpl-float v0, v0, v1

    if-lez v0, :cond_d

    const/4 v0, 0x0

    iput-boolean v0, v7, Lc/b2;->n:Z

    :cond_d
    :goto_8
    iget-boolean v0, v7, Lc/b2;->n:Z

    if-eqz v0, :cond_e

    const/4 v0, -0x1

    goto :goto_9

    :cond_e
    const v0, -0xe8ded5

    :goto_9
    iput v0, v7, Lc/b2;->j:I

    :goto_a
    iget-object v8, v7, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual/range {v28 .. v28}, Lc/n1;->f0()Z

    move-result v1

    if-nez v1, :cond_f

    iget-object v2, v7, Lc/b2;->o:Lc/W3;

    if-eqz v2, :cond_f

    invoke-virtual/range {v28 .. v28}, Lc/n1;->a0()Z

    move-result v2

    if-eqz v2, :cond_f

    const/4 v2, 0x1

    goto :goto_b

    :cond_f
    const/4 v2, 0x0

    :goto_b
    iget-object v5, v7, Lc/b2;->q:Landroid/graphics/RectF;

    const/4 v9, 0x0

    move/from16 v10, v25

    move/from16 v11, v26

    invoke-virtual {v5, v9, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v6, 0x42000000    # 32.0f

    invoke-virtual {v7, v6}, Lc/b2;->m(F)F

    move-result v6

    iget-object v12, v7, Lc/b2;->Q:Lc/v8;

    if-eqz v12, :cond_10

    move-object/from16 v12, v24

    iget v1, v12, Lc/r4;->c:I

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    move-object/from16 v13, p1

    invoke-virtual {v13, v5, v6, v6, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :goto_c
    move/from16 v29, v10

    move-object/from16 v27, v12

    const/4 v9, 0x0

    goto/16 :goto_d

    :cond_10
    move-object/from16 v13, p1

    move-object/from16 v12, v24

    iget-object v14, v7, Lc/b2;->p:Landroid/graphics/Path;

    const/high16 v15, 0x33000000

    const v24, 0xffffff

    if-eqz v1, :cond_12

    iget-object v1, v7, Lc/b2;->t:Landroid/graphics/Bitmap;

    if-eqz v1, :cond_11

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    invoke-virtual {v14}, Landroid/graphics/Path;->rewind()V

    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v14, v5, v6, v6, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual {v13, v14}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v2, -0x1

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v2, 0x1

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    iget-object v2, v7, Lc/b2;->t:Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    invoke-virtual {v13, v2, v3, v5, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    invoke-virtual {v13, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_11
    and-int v1, v4, v24

    or-int/2addr v1, v15

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v13, v5, v6, v6, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    goto :goto_c

    :cond_12
    if-eqz v2, :cond_14

    invoke-virtual {v7, v3}, Landroid/view/View;->getLocationOnScreen([I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/view/View;->getHeight()I

    move-result v9

    int-to-float v9, v9

    cmpg-float v25, v2, v10

    if-gtz v25, :cond_13

    iget v2, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v2, v2

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v9, v1

    :cond_13
    iget-object v1, v7, Lc/b2;->o:Lc/W3;

    iget-object v1, v1, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float v1, v2, v1

    iget-object v15, v7, Lc/b2;->o:Lc/W3;

    iget-object v15, v15, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v15}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v15

    int-to-float v15, v15

    div-float v15, v9, v15

    invoke-static {v1, v15}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iget-object v15, v7, Lc/b2;->o:Lc/W3;

    iget-object v15, v15, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v15}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v15

    int-to-float v15, v15

    mul-float/2addr v15, v1

    move-object/from16 v27, v12

    iget-object v12, v7, Lc/b2;->o:Lc/W3;

    iget-object v12, v12, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v12}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v12

    int-to-float v12, v12

    mul-float/2addr v12, v1

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    invoke-virtual {v14}, Landroid/graphics/Path;->rewind()V

    move/from16 v29, v10

    sget-object v10, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v14, v5, v6, v6, v10}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual {v13, v14}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v6, -0x1

    invoke-virtual {v8, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v6, 0x1

    invoke-virtual {v8, v6}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    sub-float v10, v2, v15

    div-float v10, v10, v16

    const/4 v14, 0x0

    aget v6, v3, v14

    int-to-float v6, v6

    sub-float/2addr v10, v6

    sub-float v18, v9, v12

    div-float v18, v18, v16

    const/16 v19, 0x1

    aget v3, v3, v19

    int-to-float v3, v3

    sub-float v14, v18, v3

    add-float/2addr v2, v15

    div-float v2, v2, v16

    sub-float/2addr v2, v6

    add-float/2addr v9, v12

    div-float v9, v9, v16

    sub-float/2addr v9, v3

    invoke-virtual {v5, v10, v14, v2, v9}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v2, v7, Lc/b2;->o:Lc/W3;

    iget-object v2, v2, Lc/W3;->c:Landroid/graphics/Bitmap;

    const/4 v9, 0x0

    invoke-virtual {v13, v2, v9, v5, v8}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    and-int v2, v4, v24

    const/high16 v3, 0x33000000

    or-int/2addr v2, v3

    invoke-virtual {v13, v2}, Landroid/graphics/Canvas;->drawColor(I)V

    invoke-virtual {v13, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_d

    :cond_14
    move/from16 v29, v10

    move-object/from16 v27, v12

    move v3, v15

    const/4 v9, 0x0

    and-int v1, v4, v24

    or-int/2addr v1, v3

    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v13, v5, v6, v6, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :goto_d
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x42800000    # 64.0f

    invoke-virtual {v7, v0}, Lc/b2;->J(F)F

    move-result v10

    const/high16 v0, 0x42580000    # 54.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move/from16 v12, v29

    invoke-virtual {v7, v12, v11}, Lc/b2;->g(FF)I

    move-result v14

    invoke-virtual {v7, v14}, Lc/b2;->v(I)V

    invoke-virtual/range {p0 .. p0}, Lc/b2;->x()Z

    move-result v0

    iget-object v15, v7, Lc/b2;->J:Landroid/graphics/RectF;

    iget-object v6, v7, Lc/b2;->O:Ljava/util/ArrayList;

    iget-object v5, v7, Lc/b2;->H:Landroid/graphics/RectF;

    iget-object v4, v7, Lc/b2;->B:Landroid/graphics/RectF;

    iget-object v3, v7, Lc/b2;->G:Landroid/graphics/RectF;

    iget-object v1, v7, Lc/b2;->M:Ljava/util/ArrayList;

    const/high16 v18, 0x437f0000    # 255.0f

    iget-boolean v9, v7, Lc/b2;->r0:Z

    move/from16 v25, v14

    iget-object v14, v7, Lc/b2;->g0:Ljava/util/Date;

    move-object/from16 v31, v1

    const/high16 v2, 0x41200000    # 10.0f

    iget-object v1, v7, Lc/b2;->z:Lc/z;

    if-eqz v0, :cond_34

    iget-boolean v0, v7, Lc/b2;->i:Z

    if-eqz v0, :cond_15

    invoke-virtual/range {p0 .. p0}, Lc/b2;->z()F

    move-result v0

    goto :goto_e

    :cond_15
    const/4 v0, 0x0

    :goto_e
    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v8

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v20

    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v2

    move-object/from16 v36, v1

    add-float v1, v8, v10

    if-eqz v2, :cond_16

    add-float v2, v1, v20

    move/from16 v21, v1

    goto :goto_f

    :cond_16
    move/from16 v21, v1

    move v2, v8

    :goto_f
    add-float v1, v2, v10

    add-float v22, v1, v20

    sub-float v25, v12, v8

    sub-float v25, v25, v0

    move/from16 v37, v2

    sub-float v2, v25, v20

    move/from16 v20, v1

    iget-boolean v1, v7, Lc/b2;->i:Z

    if-eqz v1, :cond_24

    move/from16 v25, v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v14, v1, v2}, Ljava/util/Date;->setTime(J)V

    move-object/from16 v1, v23

    invoke-virtual {v1, v14}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v7, Lc/b2;->y:Landroid/graphics/Paint;

    iget v14, v7, Lc/b2;->j:I

    invoke-virtual {v2, v14}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v14, 0x41b80000    # 23.0f

    invoke-virtual {v7, v14}, Lc/b2;->m(F)F

    move-result v14

    invoke-virtual {v2, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v14, Lc/b2;->x0:Landroid/graphics/Typeface;

    invoke-virtual {v2, v14}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v14

    int-to-float v14, v14

    move-object/from16 v23, v3

    const/high16 v3, 0x41200000    # 10.0f

    invoke-virtual {v7, v3}, Lc/b2;->m(F)F

    move-result v3

    sub-float/2addr v14, v3

    sub-float/2addr v14, v0

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v7, v3}, Lc/b2;->m(F)F

    move-result v33

    add-float v3, v33, v14

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v33

    invoke-virtual/range {v28 .. v28}, Lc/n1;->g0()Z

    move-result v35

    if-eqz v35, :cond_17

    move-object/from16 v35, v4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    div-float v4, v4, v16

    invoke-virtual {v2}, Landroid/graphics/Paint;->ascent()F

    move-result v38

    invoke-virtual {v2}, Landroid/graphics/Paint;->descent()F

    move-result v39

    add-float v39, v39, v38

    div-float v39, v39, v16

    sub-float v4, v4, v39

    invoke-virtual {v13, v1, v3, v4, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto :goto_10

    :cond_17
    move-object/from16 v35, v4

    :goto_10
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Lc/E;

    const/4 v4, 0x1

    invoke-direct {v2, v7, v4}, Lc/E;-><init>(Lc/b2;I)V

    invoke-static {v1, v2}, Lc/A8;->d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;

    move-result-object v4

    const v1, 0x41eaaaab

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v30

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float v2, v2, v16

    invoke-virtual/range {v28 .. v28}, Lc/n1;->g0()Z

    move-result v34

    if-eqz v34, :cond_18

    add-float v3, v3, v33

    add-float/2addr v3, v1

    div-float v0, v30, v16

    add-float/2addr v0, v3

    :goto_11
    move v14, v0

    goto :goto_12

    :cond_18
    div-float v0, v0, v16

    add-float/2addr v0, v14

    goto :goto_11

    :goto_12
    if-nez v9, :cond_1a

    iget-object v0, v7, Lc/b2;->Q:Lc/v8;

    if-eqz v0, :cond_19

    goto :goto_13

    :cond_19
    iget v0, v7, Lc/b2;->e:F

    move v9, v0

    const/4 v0, 0x0

    goto :goto_14

    :cond_1a
    :goto_13
    const/4 v0, 0x0

    const/4 v9, 0x0

    :goto_14
    cmpl-float v33, v9, v0

    if-lez v33, :cond_1b

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v3, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v1, v0

    mul-float v0, v9, v18

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v34

    const/16 v38, 0x0

    const/16 v39, 0x0

    move-object/from16 v0, p1

    move-object/from16 v40, v15

    move/from16 v43, v20

    move/from16 v42, v21

    move-object/from16 v41, v36

    const/high16 v15, 0x3f800000    # 1.0f

    move/from16 v20, v1

    move/from16 v1, v38

    move v15, v2

    move/from16 v45, v25

    move/from16 v44, v37

    move/from16 v2, v39

    move-object/from16 v46, v23

    move-object/from16 v48, v4

    move-object/from16 v47, v35

    move/from16 v4, v20

    move/from16 v29, v12

    move-object v12, v5

    move/from16 v5, v34

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->saveLayerAlpha(FFFFI)I

    move-result v0

    move-object/from16 v5, v27

    invoke-virtual {v7, v13, v14, v15, v5}, Lc/b2;->r(Landroid/graphics/Canvas;FFLc/r4;)V

    invoke-virtual {v13, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_15

    :cond_1b
    move-object/from16 v48, v4

    move/from16 v29, v12

    move-object/from16 v40, v15

    move/from16 v43, v20

    move/from16 v42, v21

    move-object/from16 v46, v23

    move/from16 v45, v25

    move-object/from16 v47, v35

    move-object/from16 v41, v36

    move/from16 v44, v37

    move v15, v2

    move-object v12, v5

    move-object/from16 v5, v27

    :goto_15
    invoke-virtual/range {v28 .. v28}, Lc/n1;->g0()Z

    move-result v0

    if-nez v0, :cond_1c

    move-object/from16 v49, v5

    move-object/from16 v27, v6

    move-object/from16 v23, v12

    const/16 v17, 0x0

    goto/16 :goto_1a

    :cond_1c
    if-lez v33, :cond_1d

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v3, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v4, v0

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float v1, v0, v9

    mul-float v1, v1, v18

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v9

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object/from16 v0, p1

    move-object/from16 v49, v5

    move v5, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->saveLayerAlpha(FFFFI)I

    move-result v0

    :goto_16
    move v9, v0

    move-object/from16 v5, v48

    goto :goto_17

    :cond_1d
    move-object/from16 v49, v5

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    goto :goto_16

    :goto_17
    iget-boolean v0, v5, Lc/A8;->e:Z

    const/high16 v4, 0x41c80000    # 25.0f

    const/high16 v3, 0x42200000    # 40.0f

    if-eqz v0, :cond_1f

    iget v2, v7, Lc/b2;->j:I

    iget v0, v5, Lc/A8;->f:I

    invoke-static {v0}, Lc/A8;->a(I)I

    move-result v18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v19, v2

    move/from16 v2, v18

    move-object/from16 v23, v12

    move v12, v3

    move v3, v14

    move v12, v4

    move v4, v15

    move-object v12, v5

    move/from16 v5, v30

    move-object/from16 v27, v6

    const/16 v17, 0x0

    move/from16 v6, v19

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    iget-object v2, v12, Lc/A8;->h:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1e

    const/high16 v0, 0x41c80000    # 25.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v1

    add-float v4, v1, v15

    const/high16 v0, 0x41100000    # 9.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    invoke-virtual/range {v0 .. v6}, Lc/b2;->h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V

    :cond_1e
    const/high16 v0, 0x42200000    # 40.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v1

    add-float/2addr v14, v1

    goto :goto_18

    :cond_1f
    move-object/from16 v27, v6

    move-object/from16 v23, v12

    const/16 v17, 0x0

    move-object v12, v5

    :goto_18
    iget-boolean v0, v12, Lc/A8;->b:Z

    if-eqz v0, :cond_21

    iget v0, v12, Lc/A8;->g:I

    invoke-static {v0}, Lc/A8;->e(I)I

    move-result v2

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move v4, v15

    move/from16 v5, v30

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    iget-object v2, v12, Lc/A8;->i:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_20

    const/high16 v0, 0x41c80000    # 25.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    add-float v4, v0, v15

    const/high16 v0, 0x41100000    # 9.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    invoke-virtual/range {v0 .. v6}, Lc/b2;->h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V

    :cond_20
    const/high16 v0, 0x42200000    # 40.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v1

    add-float/2addr v14, v1

    :cond_21
    iget-boolean v0, v12, Lc/A8;->c:Z

    if-eqz v0, :cond_22

    const v2, 0x7f0300a0

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move v4, v15

    move/from16 v5, v30

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    const/high16 v0, 0x42200000    # 40.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    add-float/2addr v0, v14

    move v3, v0

    goto :goto_19

    :cond_22
    move v3, v14

    :goto_19
    iget-boolean v0, v12, Lc/A8;->d:Z

    if-eqz v0, :cond_23

    const v2, 0x7f030092

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v15

    move/from16 v5, v30

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    :cond_23
    invoke-virtual {v13, v9}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_1a

    :cond_24
    move/from16 v45, v2

    move-object/from16 v46, v3

    move-object/from16 v47, v4

    move-object/from16 v23, v5

    move/from16 v29, v12

    move-object/from16 v40, v15

    move/from16 v43, v20

    move/from16 v42, v21

    move-object/from16 v49, v27

    move-object/from16 v41, v36

    move/from16 v44, v37

    const/16 v17, 0x0

    move-object/from16 v27, v6

    :goto_1a
    sub-float v0, v11, v10

    div-float v0, v0, v16

    add-float/2addr v10, v11

    div-float v10, v10, v16

    move/from16 v1, v43

    move/from16 v2, v44

    move-object/from16 v12, v47

    invoke-virtual {v12, v2, v0, v1, v10}, Landroid/graphics/RectF;->set(FFFF)V

    iget v0, v12, Landroid/graphics/RectF;->top:F

    iget v1, v12, Landroid/graphics/RectF;->bottom:F

    move/from16 v10, v42

    move-object/from16 v15, v46

    invoke-virtual {v15, v8, v0, v10, v1}, Landroid/graphics/RectF;->set(FFFF)V

    move-object/from16 v6, v23

    invoke-virtual {v6, v15}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v0

    move-object/from16 v8, v49

    if-eqz v0, :cond_25

    invoke-virtual {v7, v13, v15, v8}, Lc/b2;->o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_1b

    :cond_25
    invoke-virtual {v15}, Landroid/graphics/RectF;->setEmpty()V

    :goto_1b
    invoke-virtual {v7, v13, v12, v8}, Lc/b2;->o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    invoke-virtual {v7, v13, v8}, Lc/b2;->s(Landroid/graphics/Canvas;Lc/r4;)V

    iget-object v0, v7, Lc/b2;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v5, 0x0

    :goto_1c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_29

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, v41

    invoke-virtual {v4, v2}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v2

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_26

    invoke-static {v1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v6

    goto :goto_1d

    :cond_26
    move-object/from16 v6, v17

    :goto_1d
    if-eqz v2, :cond_28

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_27

    if-eqz v6, :cond_28

    :cond_27
    add-int/lit8 v5, v5, 0x1

    :cond_28
    move-object/from16 v41, v4

    goto :goto_1c

    :cond_29
    move/from16 v1, v29

    move-object/from16 v4, v41

    invoke-virtual {v7, v1, v11}, Lc/b2;->g(FF)I

    move-result v0

    invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/high16 v1, 0x40c00000    # 6.0f

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v1

    move/from16 v2, v45

    sub-float v3, v2, v22

    const/4 v5, 0x0

    invoke-static {v5, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    const/high16 v5, 0x41800000    # 16.0f

    invoke-virtual {v7, v5}, Lc/b2;->m(F)F

    move-result v6

    sub-float v10, v11, v6

    invoke-virtual {v7, v10}, Lc/b2;->f(F)F

    move-result v6

    add-float v9, v3, v1

    add-float v10, v6, v1

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-static {v14, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    div-float/2addr v9, v10

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->floor(D)D

    move-result-wide v9

    double-to-int v9, v9

    const/4 v10, 0x0

    invoke-static {v10, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-static {v0, v9}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-virtual {v7, v5}, Lc/b2;->m(F)F

    move-result v5

    sub-float v5, v11, v5

    invoke-virtual {v7, v5, v3, v1, v0}, Lc/b2;->l(FFFI)F

    move-result v9

    invoke-static {v6, v9}, Ljava/lang/Math;->max(FF)F

    move-result v5

    invoke-virtual {v7, v3, v5, v1, v0}, Lc/b2;->k(FFFI)F

    move-result v1

    if-nez v0, :cond_2a

    move v6, v5

    goto :goto_1e

    :cond_2a
    add-float v6, v5, v1

    :goto_1e
    int-to-float v14, v0

    mul-float/2addr v14, v6

    sub-float/2addr v14, v1

    sub-float/2addr v3, v14

    div-float v3, v3, v16

    const/4 v1, 0x0

    invoke-static {v1, v3}, Ljava/lang/Math;->max(FF)F

    move-result v1

    add-float v1, v1, v22

    iput v10, v7, Lc/b2;->N:I

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->clear()V

    iget-object v3, v7, Lc/b2;->d0:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1f
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_30

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-lt v14, v0, :cond_2b

    goto/16 :goto_22

    :cond_2b
    invoke-static {v10}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v4, v14}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v14

    invoke-static {v10}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v18

    if-eqz v18, :cond_2c

    move/from16 v18, v0

    invoke-static {v10}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    goto :goto_20

    :cond_2c
    move/from16 v18, v0

    move-object/from16 v0, v17

    :goto_20
    if-eqz v14, :cond_2d

    invoke-static {v10}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_2e

    if-nez v0, :cond_2e

    :cond_2d
    move/from16 v0, v18

    goto :goto_1f

    :cond_2e
    move-object/from16 v19, v3

    iget v3, v7, Lc/b2;->N:I

    move-object/from16 v41, v4

    add-int/lit8 v4, v3, 0x1

    iput v4, v7, Lc/b2;->N:I

    move-object/from16 v4, v31

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v4, v6

    add-float/2addr v4, v1

    sub-float v20, v11, v5

    move/from16 v21, v1

    div-float v1, v20, v16

    move/from16 v20, v6

    add-float v6, v4, v5

    invoke-static {v6, v2}, Ljava/lang/Math;->min(FF)F

    move-result v6

    add-float v22, v11, v5

    move/from16 v45, v2

    div-float v2, v22, v16

    invoke-virtual {v3, v4, v1, v6, v2}, Landroid/graphics/RectF;->set(FFFF)V

    move-object/from16 v4, v27

    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    div-float v2, v9, v16

    sub-float/2addr v1, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    sub-float/2addr v6, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v22

    add-float v4, v22, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v22

    add-float v2, v22, v2

    move/from16 v23, v11

    move-object/from16 v11, v40

    invoke-virtual {v11, v1, v6, v4, v2}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v14, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_2f

    invoke-static {v13, v1, v11, v8}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_21

    :cond_2f
    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v13, v1, v0, v11}, Lc/s;->c(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;)V

    :goto_21
    invoke-virtual {v7, v13, v3, v10, v8}, Lc/b2;->q(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;Lc/r4;)V

    move-object/from16 v40, v11

    move/from16 v0, v18

    move-object/from16 v3, v19

    move/from16 v6, v20

    move/from16 v1, v21

    move/from16 v11, v23

    move-object/from16 v4, v41

    move/from16 v2, v45

    goto/16 :goto_1f

    :cond_30
    :goto_22
    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v0

    if-eqz v0, :cond_32

    iget-boolean v0, v7, Lc/b2;->D:Z

    if-nez v0, :cond_32

    iget-boolean v0, v7, Lc/b2;->p0:Z

    if-eqz v0, :cond_31

    invoke-virtual {v15}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v15}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x42180000    # 38.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v8, Lc/r4;->j:I

    const v2, 0x7f03009e

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_23

    :cond_31
    invoke-virtual {v15}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v15}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x42100000    # 36.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    const v2, 0x7f030094

    iget v6, v8, Lc/r4;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    :cond_32
    :goto_23
    iget-boolean v0, v7, Lc/b2;->D:Z

    if-eqz v0, :cond_33

    invoke-virtual {v7, v13, v8}, Lc/b2;->u(Landroid/graphics/Canvas;Lc/r4;)V

    goto :goto_24

    :cond_33
    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    invoke-virtual {v7, v13, v0, v1}, Lc/b2;->n(Landroid/graphics/Canvas;FF)V

    :goto_24
    invoke-virtual {v7, v13, v8, v9}, Lc/b2;->p(Landroid/graphics/Canvas;Lc/r4;F)V

    return-void

    :cond_34
    move-object/from16 v41, v1

    move-object/from16 v19, v8

    move-object/from16 v40, v15

    move-object/from16 v1, v23

    const/high16 v0, 0x42180000    # 38.0f

    const/4 v8, 0x0

    const/16 v17, 0x0

    move-object v15, v3

    move/from16 v23, v11

    move-object/from16 v11, v27

    move v3, v2

    move-object/from16 v27, v6

    const/high16 v2, 0x41400000    # 12.0f

    move-object v6, v5

    const/high16 v5, 0x41800000    # 16.0f

    move/from16 v52, v12

    move-object v12, v4

    move/from16 v4, v52

    sub-float v29, v4, v10

    div-float v8, v29, v16

    iget-boolean v0, v7, Lc/b2;->i:Z

    if-eqz v0, :cond_41

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v14, v2, v3}, Ljava/util/Date;->setTime(J)V

    invoke-virtual {v1, v14}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v28 .. v28}, Lc/n1;->g0()Z

    move-result v0

    if-eqz v0, :cond_35

    div-float v3, v4, v16

    const/high16 v0, 0x41e80000    # 29.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v14

    const/high16 v0, 0x41b80000    # 23.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v29

    iget v1, v7, Lc/b2;->j:I

    move-object/from16 v46, v15

    const/high16 v15, 0x42180000    # 38.0f

    move-object/from16 v0, p0

    move/from16 v32, v1

    move-object/from16 v1, p1

    move v15, v4

    move-object/from16 v50, v31

    move-object/from16 v51, v41

    move v4, v14

    move v14, v5

    move/from16 v5, v29

    move-object v14, v6

    move/from16 v6, v32

    invoke-virtual/range {v0 .. v6}, Lc/b2;->h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V

    goto :goto_25

    :cond_35
    move-object v14, v6

    move-object/from16 v46, v15

    move-object/from16 v50, v31

    move-object/from16 v51, v41

    move v15, v4

    :goto_25
    if-nez v9, :cond_37

    iget-object v0, v7, Lc/b2;->Q:Lc/v8;

    if-eqz v0, :cond_36

    goto :goto_26

    :cond_36
    iget v0, v7, Lc/b2;->e:F

    move/from16 v26, v0

    const/4 v9, 0x0

    goto :goto_27

    :cond_37
    :goto_26
    const/4 v9, 0x0

    const/16 v26, 0x0

    :goto_27
    cmpl-float v6, v26, v9

    if-lez v6, :cond_38

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v3, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v4, v0

    mul-float v0, v26, v18

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v5

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->saveLayerAlpha(FFFFI)I

    move-result v0

    div-float v1, v15, v16

    invoke-virtual/range {p0 .. p0}, Lc/b2;->G()F

    move-result v2

    const/high16 v3, 0x42180000    # 38.0f

    add-float/2addr v2, v3

    const/high16 v3, 0x40800000    # 4.0f

    sub-float/2addr v2, v3

    div-float v2, v2, v16

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v2

    invoke-virtual {v7, v13, v1, v2, v11}, Lc/b2;->r(Landroid/graphics/Canvas;FFLc/r4;)V

    invoke-virtual {v13, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_38
    invoke-virtual/range {v28 .. v28}, Lc/n1;->g0()Z

    move-result v0

    if-nez v0, :cond_39

    move-object/from16 v49, v11

    move-object/from16 v47, v12

    move-object/from16 v33, v14

    goto/16 :goto_2c

    :cond_39
    if-lez v6, :cond_3a

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v3, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v4, v0

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float v1, v0, v26

    mul-float v1, v1, v18

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v5

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object/from16 v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->saveLayerAlpha(FFFFI)I

    move-result v0

    :goto_28
    move v6, v0

    goto :goto_29

    :cond_3a
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    goto :goto_28

    :goto_29
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v1, Lc/E;

    const/4 v2, 0x1

    invoke-direct {v1, v7, v2}, Lc/E;-><init>(Lc/b2;I)V

    invoke-static {v0, v1}, Lc/A8;->d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;

    move-result-object v5

    iget-boolean v0, v5, Lc/A8;->e:Z

    iget-boolean v4, v5, Lc/A8;->b:Z

    add-int/2addr v0, v4

    iget-boolean v3, v5, Lc/A8;->c:Z

    add-int/2addr v0, v3

    iget-boolean v2, v5, Lc/A8;->d:Z

    add-int v1, v0, v2

    const v0, 0x41eaaaab

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v18

    iget-boolean v0, v5, Lc/A8;->e:Z

    if-eqz v0, :cond_3c

    const/4 v0, 0x0

    invoke-static {v15, v1, v0}, Lc/b2;->H(FII)F

    move-result v22

    invoke-virtual {v7, v1, v0}, Lc/b2;->I(II)F

    move-result v28

    iget v0, v7, Lc/b2;->j:I

    iget v9, v5, Lc/A8;->f:I

    invoke-static {v9}, Lc/A8;->a(I)I

    move-result v9

    move/from16 v30, v0

    move-object/from16 v0, p0

    move-object/from16 v49, v11

    move v11, v1

    move-object/from16 v1, p1

    move/from16 v31, v2

    move v2, v9

    move v9, v3

    move/from16 v3, v22

    move/from16 v32, v4

    move/from16 v4, v28

    move-object/from16 v33, v14

    move-object v14, v5

    move/from16 v5, v18

    move-object/from16 v47, v12

    move v12, v6

    move/from16 v6, v30

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    iget-object v2, v14, Lc/A8;->h:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3b

    const/high16 v0, 0x41d80000    # 27.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v1

    add-float v4, v1, v28

    const/high16 v0, 0x41100000    # 9.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v22

    invoke-virtual/range {v0 .. v6}, Lc/b2;->h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V

    :cond_3b
    const/4 v5, 0x1

    goto :goto_2a

    :cond_3c
    move/from16 v31, v2

    move v9, v3

    move/from16 v32, v4

    move-object/from16 v49, v11

    move-object/from16 v47, v12

    move-object/from16 v33, v14

    move v11, v1

    move-object v14, v5

    move v12, v6

    const/4 v5, 0x0

    :goto_2a
    if-eqz v32, :cond_3e

    invoke-static {v15, v11, v5}, Lc/b2;->H(FII)F

    move-result v22

    add-int/lit8 v28, v5, 0x1

    invoke-virtual {v7, v11, v5}, Lc/b2;->I(II)F

    move-result v30

    iget v0, v14, Lc/A8;->g:I

    invoke-static {v0}, Lc/A8;->e(I)I

    move-result v2

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v22

    move/from16 v4, v30

    move/from16 v5, v18

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    iget-object v2, v14, Lc/A8;->i:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3d

    const/high16 v0, 0x41d80000    # 27.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    add-float v4, v0, v30

    const/high16 v0, 0x41100000    # 9.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v7, Lc/b2;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v22

    invoke-virtual/range {v0 .. v6}, Lc/b2;->h(Landroid/graphics/Canvas;Ljava/lang/String;FFFI)V

    :cond_3d
    move/from16 v14, v28

    goto :goto_2b

    :cond_3e
    move v14, v5

    :goto_2b
    if-eqz v9, :cond_3f

    invoke-static {v15, v11, v14}, Lc/b2;->H(FII)F

    move-result v3

    invoke-virtual {v7, v11, v14}, Lc/b2;->I(II)F

    move-result v4

    iget v6, v7, Lc/b2;->j:I

    const v2, 0x7f0300a0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v5, v18

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    add-int/lit8 v14, v14, 0x1

    :cond_3f
    if-eqz v31, :cond_40

    invoke-static {v15, v11, v14}, Lc/b2;->H(FII)F

    move-result v3

    invoke-virtual {v7, v11, v14}, Lc/b2;->I(II)F

    move-result v4

    iget v6, v7, Lc/b2;->j:I

    const v2, 0x7f030092

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v5, v18

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    :cond_40
    invoke-virtual {v13, v12}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_2c

    :cond_41
    move-object/from16 v33, v6

    move-object/from16 v49, v11

    move-object/from16 v47, v12

    move-object/from16 v46, v15

    move-object/from16 v50, v31

    move-object/from16 v51, v41

    move v15, v4

    :goto_2c
    sub-float v0, v23, v10

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v2

    sub-float/2addr v0, v2

    add-float v2, v8, v10

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v1

    sub-float v1, v23, v1

    move-object/from16 v9, v47

    invoke-virtual {v9, v8, v0, v2, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget v0, v9, Landroid/graphics/RectF;->top:F

    const/high16 v11, 0x41400000    # 12.0f

    invoke-virtual {v7, v11}, Lc/b2;->m(F)F

    move-result v1

    sub-float/2addr v0, v1

    sub-float v1, v0, v10

    move-object/from16 v10, v46

    invoke-virtual {v10, v8, v1, v2, v0}, Landroid/graphics/RectF;->set(FFFF)V

    move-object/from16 v8, v33

    invoke-virtual {v8, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v0

    if-eqz v0, :cond_42

    move-object/from16 v12, v49

    invoke-virtual {v7, v13, v10, v12}, Lc/b2;->o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_2d

    :cond_42
    move-object/from16 v12, v49

    invoke-virtual {v10}, Landroid/graphics/RectF;->setEmpty()V

    :goto_2d
    invoke-virtual {v7, v13, v9, v12}, Lc/b2;->o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    invoke-virtual {v7, v13, v12}, Lc/b2;->s(Landroid/graphics/Canvas;Lc/r4;)V

    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v0

    if-eqz v0, :cond_44

    iget-boolean v0, v7, Lc/b2;->D:Z

    if-nez v0, :cond_44

    iget-boolean v0, v7, Lc/b2;->p0:Z

    if-eqz v0, :cond_43

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x42180000    # 38.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    iget v6, v12, Lc/r4;->j:I

    const v2, 0x7f03009e

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_2e

    :cond_43
    invoke-virtual {v10}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x42100000    # 36.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    const v2, 0x7f030094

    iget v6, v12, Lc/r4;->j:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    :cond_44
    :goto_2e
    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v0

    if-eqz v0, :cond_45

    iget v0, v12, Lc/r4;->j:I

    move-object/from16 v6, v19

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/16 v0, 0x28

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v1

    invoke-virtual {v6, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget v0, v8, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x40c00000    # 6.0f

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v2

    sub-float v4, v0, v2

    div-float v0, v15, v16

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v2

    sub-float v2, v0, v2

    invoke-virtual {v7, v1}, Lc/b2;->m(F)F

    move-result v3

    add-float/2addr v3, v0

    move-object/from16 v0, p1

    move v1, v2

    move v2, v4

    move-object v5, v6

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/16 v0, 0xff

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    goto :goto_2f

    :cond_45
    move-object/from16 v6, v19

    :goto_2f
    iget-object v0, v7, Lc/b2;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v5, 0x0

    :goto_30
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_49

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v3, v51

    invoke-virtual {v3, v2}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v2

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_46

    invoke-static {v1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v4

    goto :goto_31

    :cond_46
    move-object/from16 v4, v17

    :goto_31
    if-eqz v2, :cond_48

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_47

    if-eqz v4, :cond_48

    :cond_47
    add-int/lit8 v5, v5, 0x1

    :cond_48
    move-object/from16 v51, v3

    goto :goto_30

    :cond_49
    move/from16 v1, v25

    move-object/from16 v3, v51

    invoke-static {v1, v5}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lc/b2;->G()F

    move-result v4

    invoke-virtual {v7, v4}, Lc/b2;->m(F)F

    move-result v4

    invoke-virtual/range {p0 .. p0}, Lc/b2;->y()Z

    move-result v5

    if-eqz v5, :cond_4a

    iget v5, v8, Landroid/graphics/RectF;->top:F

    goto :goto_32

    :cond_4a
    iget v5, v9, Landroid/graphics/RectF;->top:F

    :goto_32
    invoke-virtual {v7, v11}, Lc/b2;->m(F)F

    move-result v8

    sub-float/2addr v5, v8

    const/high16 v8, 0x41800000    # 16.0f

    invoke-virtual {v7, v8}, Lc/b2;->m(F)F

    move-result v11

    sub-float v11, v15, v11

    sub-float v14, v5, v4

    invoke-virtual {v7, v11, v14, v2, v0}, Lc/b2;->l(FFFI)F

    move-result v11

    invoke-virtual {v7, v8}, Lc/b2;->m(F)F

    move-result v8

    sub-float v8, v15, v8

    invoke-virtual {v7, v8}, Lc/b2;->f(F)F

    move-result v8

    invoke-static {v8, v11}, Ljava/lang/Math;->max(FF)F

    move-result v8

    sub-float/2addr v15, v8

    div-float v15, v15, v16

    invoke-virtual {v7, v14, v8, v2, v0}, Lc/b2;->k(FFFI)F

    move-result v2

    if-nez v0, :cond_4b

    const/4 v0, 0x0

    goto :goto_33

    :cond_4b
    int-to-float v14, v0

    mul-float/2addr v14, v8

    const/16 v18, 0x1

    add-int/lit8 v0, v0, -0x1

    int-to-float v0, v0

    mul-float/2addr v0, v2

    add-float/2addr v0, v14

    :goto_33
    add-float/2addr v5, v4

    sub-float/2addr v5, v0

    div-float v5, v5, v16

    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/4 v4, 0x0

    iput v4, v7, Lc/b2;->N:I

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->clear()V

    iget-object v4, v7, Lc/b2;->d0:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_34
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->size()I

    move-result v14

    if-lt v14, v1, :cond_4d

    :cond_4c
    move-object/from16 v19, v6

    move-object/from16 v46, v10

    move/from16 v23, v11

    goto/16 :goto_38

    :cond_4d
    invoke-static {v5}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v3, v14}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v14

    invoke-static {v5}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v18

    move/from16 v25, v1

    if-eqz v18, :cond_4e

    invoke-static {v5}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v1

    goto :goto_35

    :cond_4e
    move-object/from16 v1, v17

    :goto_35
    if-eqz v14, :cond_4f

    invoke-static {v5}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v18

    if-eqz v18, :cond_50

    if-nez v1, :cond_50

    :cond_4f
    move-object/from16 v41, v3

    move-object/from16 v18, v4

    move-object/from16 v19, v6

    move-object/from16 v46, v10

    move/from16 v23, v11

    move/from16 v22, v15

    move-object/from16 v6, v40

    move-object/from16 v31, v50

    goto :goto_37

    :cond_50
    move-object/from16 v41, v3

    iget v3, v7, Lc/b2;->N:I

    move-object/from16 v18, v4

    move-object/from16 v4, v50

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    move-object/from16 v31, v4

    add-float v4, v15, v8

    move-object/from16 v46, v10

    add-float v10, v0, v8

    invoke-virtual {v3, v15, v0, v4, v10}, Landroid/graphics/RectF;->set(FFFF)V

    iget v4, v7, Lc/b2;->N:I

    const/4 v10, 0x1

    add-int/2addr v4, v10

    iput v4, v7, Lc/b2;->N:I

    move-object/from16 v4, v27

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v19

    div-float v20, v11, v16

    sub-float v10, v19, v20

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v19

    sub-float v4, v19, v20

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v19

    move/from16 v22, v15

    add-float v15, v19, v20

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v19

    move/from16 v23, v11

    add-float v11, v19, v20

    move-object/from16 v19, v6

    move-object/from16 v6, v40

    invoke-virtual {v6, v10, v4, v15, v11}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v4, v14, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_51

    invoke-static {v13, v4, v6, v12}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_36

    :cond_51
    iget-object v1, v1, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v13, v4, v1, v6}, Lc/s;->c(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;)V

    :goto_36
    invoke-virtual {v7, v13, v3, v5, v12}, Lc/b2;->q(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;Lc/r4;)V

    add-float v1, v8, v2

    add-float/2addr v0, v1

    :goto_37
    move-object/from16 v40, v6

    move-object/from16 v4, v18

    move-object/from16 v6, v19

    move/from16 v15, v22

    move/from16 v11, v23

    move/from16 v1, v25

    move-object/from16 v50, v31

    move-object/from16 v3, v41

    move-object/from16 v10, v46

    goto/16 :goto_34

    :goto_38
    iget-boolean v0, v7, Lc/b2;->D:Z

    if-eqz v0, :cond_52

    invoke-virtual {v7, v13, v12}, Lc/b2;->u(Landroid/graphics/Canvas;Lc/r4;)V

    goto :goto_39

    :cond_52
    invoke-virtual {v9}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v9}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    invoke-virtual {v7, v13, v0, v1}, Lc/b2;->n(Landroid/graphics/Canvas;FF)V

    :goto_39
    iget-boolean v0, v7, Lc/b2;->k0:Z

    if-nez v0, :cond_54

    iget-boolean v0, v7, Lc/b2;->l0:Z

    if-nez v0, :cond_54

    :cond_53
    :goto_3a
    move/from16 v0, v23

    goto/16 :goto_3c

    :cond_54
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iget-wide v2, v7, Lc/b2;->j0:J

    sub-long/2addr v0, v2

    long-to-float v0, v0

    const/high16 v1, 0x44020000    # 520.0f

    div-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v6

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    move-object/from16 v8, v19

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x40200000    # 2.5f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v0, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iget v0, v0, Lc/r4;->j:I

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget-object v1, v7, Lc/b2;->L:Landroid/graphics/RectF;

    iget-boolean v0, v7, Lc/b2;->l0:Z

    if-eqz v0, :cond_55

    move-object/from16 v4, v46

    goto :goto_3b

    :cond_55
    move-object v4, v9

    :goto_3b
    invoke-virtual {v1, v4}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v2

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    invoke-virtual {v1, v2, v0}, Landroid/graphics/RectF;->inset(FF)V

    const/high16 v0, 0x43b40000    # 360.0f

    mul-float v3, v6, v0

    const/4 v4, 0x0

    const/high16 v2, -0x3d4c0000    # -90.0f

    move-object/from16 v0, p1

    move-object v5, v8

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x3f800000    # 1.0f

    cmpg-float v0, v6, v0

    if-gez v0, :cond_53

    const-wide/16 v0, 0x10

    invoke-virtual {v7, v0, v1}, Landroid/view/View;->postInvalidateDelayed(J)V

    goto :goto_3a

    :goto_3c
    invoke-virtual {v7, v13, v12, v0}, Lc/b2;->p(Landroid/graphics/Canvas;Lc/r4;F)V

    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    iget-boolean v0, p0, Lc/b2;->D:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/b2;->G:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    new-instance v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0412\u0438\u0434\u0436\u0435\u0442\u044b"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const v2, 0x1020003

    invoke-direct {v0, v2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;-><init>(ILjava/lang/CharSequence;)V

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    :cond_0
    iget-boolean v0, p0, Lc/b2;->D:Z

    if-eqz v0, :cond_1

    new-instance v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const v2, 0x1020019

    invoke-direct {v0, v2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;-><init>(ILjava/lang/CharSequence;)V

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    new-instance v0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0413\u043e\u0442\u043e\u0432\u043e"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const v2, 0x102001a

    invoke-direct {v0, v2, v1}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;-><init>(ILjava/lang/CharSequence;)V

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    :cond_1
    return-void
.end method

.method public final onSizeChanged(IIII)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    int-to-float p1, p1

    int-to-float p2, p2

    invoke-virtual {p0, p1, p2}, Lc/b2;->g(FF)I

    move-result p1

    invoke-virtual {p0, p1}, Lc/b2;->v(I)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 16

    move-object/from16 v0, p0

    iget-boolean v1, v0, Lc/b2;->r0:Z

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    iget-object v1, v0, Lc/b2;->Q:Lc/v8;

    if-eqz v1, :cond_0

    invoke-virtual/range {p0 .. p1}, Lc/b2;->w(Landroid/view/MotionEvent;)Z

    move-result v1

    if-eqz v1, :cond_0

    move v2, v3

    :cond_0
    return v2

    :cond_1
    iget-object v1, v0, Lc/b2;->Q:Lc/v8;

    if-eqz v1, :cond_2

    invoke-virtual/range {p0 .. p1}, Lc/b2;->w(Landroid/view/MotionEvent;)Z

    move-result v1

    if-eqz v1, :cond_2

    return v3

    :cond_2
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    iget-object v4, v0, Lc/b2;->M:Ljava/util/ArrayList;

    iget-object v5, v0, Lc/b2;->a:Landroid/graphics/RectF;

    iget-object v6, v0, Lc/b2;->s0:Landroid/os/Handler;

    iget-object v7, v0, Lc/b2;->G:Landroid/graphics/RectF;

    iget-object v8, v0, Lc/b2;->B:Landroid/graphics/RectF;

    iget-object v9, v0, Lc/b2;->I:Landroid/graphics/RectF;

    iget-object v10, v0, Lc/b2;->t0:Lc/E;

    if-nez v1, :cond_c

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iput v1, v0, Lc/b2;->h0:F

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v0, Lc/b2;->i0:F

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    iput-wide v11, v0, Lc/b2;->j0:J

    iput-boolean v2, v0, Lc/b2;->m0:Z

    iget v1, v0, Lc/b2;->h0:F

    iget v11, v0, Lc/b2;->i0:F

    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v5, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v12

    if-eqz v12, :cond_3

    invoke-virtual {v9, v5}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_3
    invoke-virtual {v8, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-virtual {v9, v8}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_4
    invoke-virtual {v7, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-virtual {v9, v7}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_5
    move v5, v2

    :goto_0
    iget v12, v0, Lc/b2;->N:I

    if-ge v5, v12, :cond_7

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/graphics/RectF;

    invoke-virtual {v12, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v13

    if-nez v13, :cond_6

    add-int/2addr v5, v3

    goto :goto_0

    :cond_6
    invoke-virtual {v9, v12}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_7
    :goto_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    iget-boolean v1, v0, Lc/b2;->D:Z

    if-nez v1, :cond_8

    iget v1, v0, Lc/b2;->h0:F

    iget v4, v0, Lc/b2;->i0:F

    invoke-virtual {v8, v1, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_8

    move v1, v3

    goto :goto_2

    :cond_8
    move v1, v2

    :goto_2
    iput-boolean v1, v0, Lc/b2;->k0:Z

    iget-boolean v1, v0, Lc/b2;->D:Z

    if-nez v1, :cond_9

    iget v1, v0, Lc/b2;->h0:F

    iget v4, v0, Lc/b2;->i0:F

    invoke-virtual {v7, v1, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_9

    move v2, v3

    :cond_9
    iput-boolean v2, v0, Lc/b2;->l0:Z

    iget-boolean v1, v0, Lc/b2;->k0:Z

    if-nez v1, :cond_a

    if-eqz v2, :cond_b

    :cond_a
    invoke-virtual {v6, v10}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v1, 0x208

    invoke-virtual {v6, v10, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    :cond_b
    return v3

    :cond_c
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v11, 0x3

    if-ne v1, v11, :cond_d

    iput-boolean v2, v0, Lc/b2;->l0:Z

    iput-boolean v2, v0, Lc/b2;->k0:Z

    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v6, v10}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v3

    :cond_d
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v11, 0x2

    if-ne v1, v11, :cond_14

    invoke-virtual {v9}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    const/high16 v4, 0x41900000    # 18.0f

    if-nez v1, :cond_f

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v5

    invoke-virtual {v9, v1, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iget v5, v0, Lc/b2;->h0:F

    sub-float/2addr v1, v5

    float-to-double v11, v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v5, v0, Lc/b2;->i0:F

    sub-float/2addr v1, v5

    float-to-double v13, v1

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v11

    invoke-virtual {v0, v4}, Lc/b2;->m(F)F

    move-result v1

    float-to-double v13, v1

    cmpl-double v1, v11, v13

    if-lez v1, :cond_f

    :cond_e
    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    :cond_f
    iget-boolean v1, v0, Lc/b2;->k0:Z

    if-nez v1, :cond_10

    iget-boolean v1, v0, Lc/b2;->l0:Z

    if-eqz v1, :cond_13

    :cond_10
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iget v5, v0, Lc/b2;->h0:F

    sub-float/2addr v1, v5

    float-to-double v11, v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v5, v0, Lc/b2;->i0:F

    sub-float/2addr v1, v5

    float-to-double v13, v1

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v11

    invoke-virtual {v0, v4}, Lc/b2;->m(F)F

    move-result v1

    float-to-double v4, v1

    cmpl-double v1, v11, v4

    if-gtz v1, :cond_12

    iget-boolean v1, v0, Lc/b2;->l0:Z

    if-eqz v1, :cond_11

    goto :goto_3

    :cond_11
    move-object v7, v8

    :goto_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-virtual {v7, v1, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-nez v1, :cond_13

    :cond_12
    iput-boolean v2, v0, Lc/b2;->l0:Z

    iput-boolean v2, v0, Lc/b2;->k0:Z

    invoke-virtual {v6, v10}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    :cond_13
    return v3

    :cond_14
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-eq v1, v3, :cond_15

    return v3

    :cond_15
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v11

    invoke-virtual {v9}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_16

    invoke-virtual {v9, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v12

    if-eqz v12, :cond_16

    move v12, v3

    goto :goto_4

    :cond_16
    move v12, v2

    :goto_4
    iput-boolean v2, v0, Lc/b2;->l0:Z

    iput-boolean v2, v0, Lc/b2;->k0:Z

    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v6, v10}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    invoke-super/range {p0 .. p0}, Landroid/view/View;->performClick()Z

    iget-boolean v6, v0, Lc/b2;->m0:Z

    if-eqz v6, :cond_17

    return v3

    :cond_17
    if-eqz v12, :cond_1a

    iget-boolean v6, v0, Lc/b2;->c:Z

    if-eqz v6, :cond_1a

    invoke-virtual {v5, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_1a

    sget-object v1, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v1, :cond_18

    invoke-virtual {v1, v3}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    move-result v1

    if-nez v1, :cond_19

    :cond_18
    const-string v1, "input keyevent 4"

    invoke-static {v1}, Lc/j8;->e(Ljava/lang/String;)V

    :cond_19
    return v3

    :cond_1a
    if-nez v12, :cond_1b

    return v3

    :cond_1b
    iget-boolean v5, v0, Lc/b2;->D:Z

    if-eqz v5, :cond_1c

    invoke-virtual {v8, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_1c

    iget-object v1, v0, Lc/b2;->F:Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    return v3

    :cond_1c
    iget-boolean v5, v0, Lc/b2;->D:Z

    if-eqz v5, :cond_1d

    invoke-virtual {v7, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_1d

    iget-object v1, v0, Lc/b2;->E:Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    return v3

    :cond_1d
    invoke-virtual {v8, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    const-string v6, "action"

    iget-object v8, v0, Lc/b2;->A:Lc/v8;

    const-string v9, "dock_action"

    if-eqz v5, :cond_1e

    const-string v1, "all_apps"

    filled-new-array {v6, v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-static {v9, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget v1, v8, Lc/v8;->a:I

    packed-switch v1, :pswitch_data_0

    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/y;

    iget-object v1, v1, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->H()V

    goto :goto_5

    :pswitch_0
    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/M4;

    iget-object v1, v1, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->H()V

    goto :goto_5

    :pswitch_1
    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/S1;

    iget-object v1, v1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    const-string v2, "ru.drivedeck.launcher.ALL_APPS"

    invoke-virtual {v1, v2}, Lru/drivedeck/launcher/LauncherAccessibilityService;->h(Ljava/lang/String;)V

    :goto_5
    return v3

    :cond_1e
    invoke-virtual {v7, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_23

    const-string v1, "home_mode"

    filled-new-array {v6, v1}, [Ljava/lang/Object;

    move-result-object v1

    invoke-static {v9, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget v1, v8, Lc/v8;->a:I

    packed-switch v1, :pswitch_data_1

    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/y;

    sget v2, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v1, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->k()Z

    move-result v2

    if-eqz v2, :cond_1f

    goto :goto_6

    :cond_1f
    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v2, :cond_20

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->S()V

    goto :goto_6

    :cond_20
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->m0()V

    goto :goto_6

    :pswitch_2
    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/M4;

    sget v2, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v1, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->k()Z

    move-result v2

    if-eqz v2, :cond_21

    goto :goto_6

    :cond_21
    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v2, :cond_22

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->S()V

    goto :goto_6

    :cond_22
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->m0()V

    goto :goto_6

    :pswitch_3
    iget-object v1, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Lc/S1;

    iget-object v2, v1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    new-instance v2, Landroid/content/Intent;

    iget-object v4, v1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    const-class v5, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v2, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v4, "ru.drivedeck.launcher.extra.HOME_MODE"

    invoke-virtual {v2, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v2

    const/high16 v4, 0x14000000

    invoke-virtual {v2, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    iget-object v4, v1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v4, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {v1}, Lc/S1;->c()V

    :goto_6
    return v3

    :cond_23
    move v5, v2

    :goto_7
    iget v7, v0, Lc/b2;->N:I

    if-ge v5, v7, :cond_28

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/RectF;

    invoke-virtual {v7, v1, v11}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v7

    if-eqz v7, :cond_27

    iget-object v1, v0, Lc/b2;->O:Ljava/util/ArrayList;

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_26

    invoke-static {v1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const-string v11, "pair"

    const-string v12, "left"

    const-string v10, "action"

    const-string v14, "right"

    filled-new-array/range {v10 .. v15}, [Ljava/lang/Object;

    move-result-object v4

    invoke-static {v9, v4}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {v1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v1

    iget v6, v8, Lc/v8;->a:I

    packed-switch v6, :pswitch_data_2

    iget-object v2, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/y;

    iget-object v2, v2, Lc/y;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2, v4, v5, v1}, Lru/drivedeck/launcher/MainActivity;->J(Ljava/lang/String;Ljava/lang/String;F)V

    goto :goto_8

    :pswitch_4
    iget-object v2, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/M4;

    iget-object v2, v2, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2, v4, v5, v1}, Lru/drivedeck/launcher/MainActivity;->J(Ljava/lang/String;Ljava/lang/String;F)V

    goto :goto_8

    :pswitch_5
    new-instance v6, Lc/n1;

    iget-object v7, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v7, Lc/S1;

    iget-object v8, v7, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-direct {v6, v8}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6}, Lc/n1;->o0()Z

    move-result v8

    if-nez v8, :cond_24

    goto :goto_8

    :cond_24
    invoke-virtual {v6, v4, v5, v1}, Lc/n1;->Q0(Ljava/lang/String;Ljava/lang/String;F)Z

    move-result v1

    iget-object v4, v7, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez v1, :cond_25

    const-string v1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u0432 \u0434\u0440\u0443\u0433\u043e\u043c \u043e\u043a\u043d\u0435"

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_8

    :cond_25
    invoke-virtual {v6, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v5

    invoke-static {v4, v1, v2, v5}, Lru/drivedeck/launcher/LauncherAccessibilityService;->f(Landroid/content/ContextWrapper;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_8

    :cond_26
    const-string v2, "app"

    const-string v4, "package"

    filled-new-array {v6, v2, v4, v1}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v9, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget v2, v8, Lc/v8;->a:I

    packed-switch v2, :pswitch_data_3

    iget-object v2, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/y;

    invoke-virtual {v2, v1}, Lc/y;->b(Ljava/lang/String;)V

    goto :goto_8

    :pswitch_6
    iget-object v2, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/M4;

    iget-object v2, v2, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2, v1}, Lru/drivedeck/launcher/MainActivity;->I(Ljava/lang/String;)V

    goto :goto_8

    :pswitch_7
    iget-object v2, v8, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/S1;

    iget-object v2, v2, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v2, v1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->g(Ljava/lang/String;)V

    :goto_8
    return v3

    :cond_27
    add-int/2addr v5, v3

    goto/16 :goto_7

    :cond_28
    return v3

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x2
        :pswitch_3
        :pswitch_2
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x2
        :pswitch_5
        :pswitch_4
    .end packed-switch

    :pswitch_data_3
    .packed-switch 0x2
        :pswitch_7
        :pswitch_6
    .end packed-switch
.end method

.method public final onVisibilityChanged(Landroid/view/View;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/view/View;->onVisibilityChanged(Landroid/view/View;I)V

    if-nez p2, :cond_0

    invoke-virtual {p0}, Lc/b2;->j()V

    :cond_0
    return-void
.end method

.method public final p(Landroid/graphics/Canvas;Lc/r4;F)V
    .locals 9

    iget-boolean v0, p0, Lc/b2;->U:Z

    if-eqz v0, :cond_4

    iget-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    if-eqz v0, :cond_4

    iget v0, p0, Lc/b2;->W:I

    if-ltz v0, :cond_4

    iget v1, p0, Lc/b2;->N:I

    if-lt v0, v1, :cond_0

    goto/16 :goto_3

    :cond_0
    iget-object v1, p0, Lc/b2;->M:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/graphics/RectF;

    iget-object v1, p0, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v3, p2, Lc/r4;->f:I

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/16 v3, 0x2d

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setAlpha(I)V

    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {p0, v3}, Lc/b2;->m(F)F

    move-result v4

    invoke-virtual {p0, v3}, Lc/b2;->m(F)F

    move-result v5

    invoke-virtual {p1, v0, v4, v5, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/16 v4, 0xff

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {p0, v4}, Lc/b2;->m(F)F

    move-result v5

    invoke-virtual {v1, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0, v3}, Lc/b2;->m(F)F

    move-result v5

    invoke-virtual {p0, v3}, Lc/b2;->m(F)F

    move-result v3

    invoke-virtual {p1, v0, v5, v3, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    invoke-static {v0}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/b2;->z:Lc/z;

    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v6

    iget-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    invoke-static {v0}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    invoke-static {v0}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    :goto_0
    move-object v7, v0

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    goto :goto_0

    :goto_1
    if-eqz v6, :cond_4

    iget-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    invoke-static {v0}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    if-nez v7, :cond_2

    goto :goto_3

    :cond_2
    iget-object v8, p0, Lc/b2;->J:Landroid/graphics/RectF;

    iget v0, p0, Lc/b2;->a0:F

    div-float v1, p3, v4

    sub-float v2, v0, v1

    iget v3, p0, Lc/b2;->b0:F

    sub-float v4, v3, v1

    add-float/2addr v0, v1

    add-float/2addr v3, v1

    invoke-virtual {v8, v2, v4, v0, v3}, Landroid/graphics/RectF;->set(FFFF)V

    iget v1, v8, Landroid/graphics/RectF;->left:F

    iget v2, v8, Landroid/graphics/RectF;->top:F

    iget v3, v8, Landroid/graphics/RectF;->right:F

    iget v4, v8, Landroid/graphics/RectF;->bottom:F

    const/16 v5, 0xdc

    move-object v0, p1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->saveLayerAlpha(FFFFI)I

    move-result v0

    iget-object v1, v6, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    if-nez v7, :cond_3

    invoke-static {p1, v1, v8, p2}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_2

    :cond_3
    iget-object v2, v7, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {p1, v1, v2, v8}, Lc/s;->c(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;)V

    :goto_2
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_4
    :goto_3
    return-void
.end method

.method public final performAccessibilityAction(ILandroid/os/Bundle;)Z
    .locals 3

    iget-boolean v0, p0, Lc/b2;->D:Z

    const/4 v1, 0x1

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/b2;->G:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    const v0, 0x1020003

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lc/b2;->A:Lc/v8;

    invoke-virtual {p1}, Lc/v8;->d()V

    return v1

    :cond_0
    iget-boolean v0, p0, Lc/b2;->D:Z

    if-eqz v0, :cond_1

    const v2, 0x1020019

    if-ne p1, v2, :cond_1

    iget-object p1, p0, Lc/b2;->E:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return v1

    :cond_1
    if-eqz v0, :cond_2

    const v0, 0x102001a

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lc/b2;->F:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return v1

    :cond_2
    invoke-super {p0, p1, p2}, Landroid/view/View;->performAccessibilityAction(ILandroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public final performClick()Z
    .locals 1

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 v0, 0x1

    return v0
.end method

.method public final q(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;Lc/r4;)V
    .locals 10

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/b2;->R:Ljava/lang/String;

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_0

    goto :goto_0

    :cond_0
    const/high16 p3, 0x41e00000    # 28.0f

    invoke-virtual {p0, p3}, Lc/b2;->m(F)F

    move-result p3

    iget-object v0, p0, Lc/b2;->P:Landroid/graphics/RectF;

    iget v1, p2, Landroid/graphics/RectF;->right:F

    sub-float v2, v1, p3

    iget p2, p2, Landroid/graphics/RectF;->top:F

    add-float/2addr p3, p2

    invoke-virtual {v0, v2, p2, v1, p3}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object p2, p0, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object p3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 p3, -0x1

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result p3

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr p3, v1

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v1

    invoke-virtual {p1, v0, p3, v2, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v7

    const/high16 p2, 0x41b00000    # 22.0f

    invoke-virtual {p0, p2}, Lc/b2;->m(F)F

    move-result v8

    iget v9, p4, Lc/r4;->k:I

    const v5, 0x7f0300c3

    move-object v3, p0

    move-object v4, p1

    invoke-virtual/range {v3 .. v9}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final r(Landroid/graphics/Canvas;FFLc/r4;)V
    .locals 9

    const/high16 v0, 0x42300000    # 44.0f

    invoke-virtual {p0, v0}, Lc/b2;->J(F)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    invoke-virtual {p0}, Lc/b2;->x()Z

    move-result v1

    const/high16 v2, 0x42180000    # 38.0f

    if-nez v1, :cond_0

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v1

    sub-float v1, p3, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    :cond_0
    iget-object v1, p0, Lc/b2;->a:Landroid/graphics/RectF;

    sub-float v3, p2, v0

    sub-float v4, p3, v0

    add-float v5, p2, v0

    add-float v6, p3, v0

    invoke-virtual {v1, v3, v4, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {p0, p1, v1, p4}, Lc/b2;->o(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v1

    const/high16 v2, 0x3fc00000    # 1.5f

    mul-float/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v7

    iget v8, p4, Lc/r4;->j:I

    const v4, 0x7f030018

    move-object v2, p0

    move-object v3, p1

    move v5, p2

    move v6, p3

    invoke-virtual/range {v2 .. v8}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    return-void
.end method

.method public final s(Landroid/graphics/Canvas;Lc/r4;)V
    .locals 4

    iget-object v0, p0, Lc/b2;->I:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v2, p2, Lc/r4;->j:I

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    iget-boolean p2, p2, Lc/r4;->m:Z

    if-eqz p2, :cond_1

    const/16 p2, 0x1e

    goto :goto_0

    :cond_1
    const/16 p2, 0x28

    :goto_0
    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setAlpha(I)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result p2

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr p2, v2

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v3

    div-float/2addr v3, v2

    invoke-virtual {p1, v0, p2, v3, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/16 p1, 0xff

    invoke-virtual {v1, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public final t(Landroid/graphics/Canvas;IFFFI)V
    .locals 3

    iget-object v0, p0, Lc/b2;->K:Landroid/graphics/RectF;

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr p5, v1

    sub-float v1, p3, p5

    sub-float v2, p4, p5

    add-float/2addr p3, p5

    add-float/2addr p4, p5

    invoke-virtual {v0, v1, v2, p3, p4}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    invoke-static {p3, p1, p2, p6, v0}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    return-void
.end method

.method public final u(Landroid/graphics/Canvas;Lc/r4;)V
    .locals 16

    move-object/from16 v7, p0

    iget-object v0, v7, Lc/b2;->G:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x42300000    # 44.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v5

    move-object/from16 v0, p2

    iget v6, v0, Lc/r4;->j:I

    const v2, 0x7f0300bf

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/b2;->t(Landroid/graphics/Canvas;IFFFI)V

    iget-object v15, v7, Lc/b2;->x:Landroid/graphics/Paint;

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/16 v0, 0xff

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setAlpha(I)V

    const/4 v0, -0x1

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v0, 0x41a00000    # 20.0f

    invoke-virtual {v7, v0}, Lc/b2;->m(F)F

    move-result v0

    iget-object v1, v7, Lc/b2;->B:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    invoke-virtual {v7, v3}, Lc/b2;->m(F)F

    move-result v4

    sub-float/2addr v2, v4

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v14

    iget v0, v1, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x40a00000    # 5.0f

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v4

    sub-float v9, v0, v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    sub-float v10, v0, v14

    iget v0, v1, Landroid/graphics/RectF;->right:F

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v2

    add-float v11, v2, v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    add-float v12, v0, v14

    move-object/from16 v8, p1

    move v13, v14

    invoke-virtual/range {v8 .. v15}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    iget-object v0, v7, Lc/b2;->y:Landroid/graphics/Paint;

    const/16 v2, 0x28

    const/16 v4, 0x17

    const/16 v5, 0x22

    invoke-static {v4, v5, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v7, v2}, Lc/b2;->m(F)F

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v4, "\u0413\u043e\u0442\u043e\u0432\u043e"

    invoke-static {v2, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v5

    div-float/2addr v5, v3

    sub-float/2addr v4, v5

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    invoke-virtual {v0}, Landroid/graphics/Paint;->ascent()F

    move-result v5

    invoke-virtual {v0}, Landroid/graphics/Paint;->descent()F

    move-result v6

    add-float/2addr v6, v5

    div-float/2addr v6, v3

    sub-float/2addr v1, v6

    move-object/from16 v3, p1

    invoke-virtual {v3, v2, v4, v1, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final v(I)V
    .locals 2

    :goto_0
    iget-object v0, p0, Lc/b2;->M:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v1, p1, :cond_0

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final w(Landroid/view/MotionEvent;)Z
    .locals 12

    const/4 v0, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    iget-object v2, p0, Lc/b2;->O:Ljava/util/ArrayList;

    iget-object v3, p0, Lc/b2;->M:Ljava/util/ArrayList;

    iget-object v4, p0, Lc/b2;->P:Landroid/graphics/RectF;

    const/4 v5, -0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-nez v1, :cond_6

    iget-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_0
    iput-boolean v7, p0, Lc/b2;->U:Z

    iput-object v6, p0, Lc/b2;->V:Ljava/lang/String;

    iput v5, p0, Lc/b2;->W:I

    iput-object v6, p0, Lc/b2;->S:Ljava/lang/String;

    iput-boolean v7, p0, Lc/b2;->T:Z

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lc/b2;->h0:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    iput v0, p0, Lc/b2;->i0:F

    invoke-virtual {v4}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    iget v0, p0, Lc/b2;->h0:F

    iget v1, p0, Lc/b2;->i0:F

    invoke-virtual {v4, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/b2;->R:Ljava/lang/String;

    iput-object v0, p0, Lc/b2;->S:Ljava/lang/String;

    iput-boolean v8, p0, Lc/b2;->T:Z

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0, v8}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_1
    return v8

    :cond_2
    move v0, v7

    :goto_0
    iget v1, p0, Lc/b2;->N:I

    if-ge v0, v1, :cond_5

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    iget v4, p0, Lc/b2;->h0:F

    iget v5, p0, Lc/b2;->i0:F

    invoke-virtual {v1, v4, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iput-object v0, p0, Lc/b2;->S:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0, v8}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_3
    return v8

    :cond_4
    add-int/2addr v0, v8

    goto :goto_0

    :cond_5
    return v7

    :cond_6
    iget-object v9, p0, Lc/b2;->S:Ljava/lang/String;

    if-nez v9, :cond_7

    return v7

    :cond_7
    const/4 v9, 0x3

    if-ne v1, v9, :cond_9

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_8

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0, v7}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_8
    iput-object v6, p0, Lc/b2;->S:Ljava/lang/String;

    iput-boolean v7, p0, Lc/b2;->U:Z

    iput-object v6, p0, Lc/b2;->V:Ljava/lang/String;

    iput v5, p0, Lc/b2;->W:I

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return v8

    :cond_9
    if-ne v1, v0, :cond_b

    iget-boolean v0, p0, Lc/b2;->T:Z

    if-nez v0, :cond_a

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v1, p0, Lc/b2;->h0:F

    sub-float/2addr v0, v1

    float-to-double v0, v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    iget v3, p0, Lc/b2;->i0:F

    sub-float/2addr v2, v3

    float-to-double v2, v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v0

    const/high16 v2, 0x41900000    # 18.0f

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v2

    float-to-double v2, v2

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_a

    iput-boolean v8, p0, Lc/b2;->U:Z

    iget-object v0, p0, Lc/b2;->S:Ljava/lang/String;

    iput-object v0, p0, Lc/b2;->V:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lc/b2;->a0:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    iput v0, p0, Lc/b2;->b0:F

    iget v1, p0, Lc/b2;->a0:F

    invoke-virtual {p0, v1, v0}, Lc/b2;->i(FF)I

    move-result v0

    iput v0, p0, Lc/b2;->W:I

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_a
    return v8

    :cond_b
    if-eq v1, v8, :cond_c

    return v8

    :cond_c
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-eqz v1, :cond_d

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1, v7}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_d
    iget-object v9, p0, Lc/b2;->S:Ljava/lang/String;

    iput-object v6, p0, Lc/b2;->S:Ljava/lang/String;

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    iget-boolean v1, p0, Lc/b2;->T:Z

    if-eqz v1, :cond_f

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    invoke-virtual {v4, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-eqz v0, :cond_e

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    iget-object v0, v0, Lc/v8;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0, v9}, Lc/k3;->W(Ljava/lang/String;)V

    :cond_e
    return v8

    :cond_f
    iget-boolean v1, p0, Lc/b2;->U:Z

    if-nez v1, :cond_10

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    iget-object v0, v0, Lc/v8;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0, v9}, Lc/k3;->m0(Ljava/lang/String;)V

    return v8

    :cond_10
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-virtual {p0, v1, v4}, Lc/b2;->i(FF)I

    move-result v1

    if-gez v1, :cond_11

    iput-boolean v7, p0, Lc/b2;->U:Z

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return v8

    :cond_11
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v7

    iput v1, p0, Lc/b2;->W:I

    new-array v0, v0, [F

    fill-array-data v0, :array_0

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v0

    iput-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    const-wide/16 v1, 0xb4

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object v10, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    new-instance v11, Lc/V1;

    move-object v0, v11

    move-object v1, p0

    move v2, v3

    move v3, v5

    move v5, v7

    invoke-direct/range {v0 .. v5}, Lc/V1;-><init>(Lc/b2;FFFF)V

    invoke-virtual {v10, v11}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    new-instance v1, Lc/a2;

    invoke-direct {v1, p0, v9, v6}, Lc/a2;-><init>(Lc/b2;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    iget-object v0, p0, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    return v8

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public final x()Z
    .locals 2

    iget-boolean v0, p0, Lc/b2;->o0:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/b2;->n0:Z

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    invoke-static {v0, v1}, Lc/G8;->M(II)Z

    move-result v0

    :goto_0
    return v0
.end method

.method public final y()Z
    .locals 1

    iget-boolean v0, p0, Lc/b2;->D:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lc/b2;->p0:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public final z()F
    .locals 5

    iget-object v0, p0, Lc/b2;->e0:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->g0()Z

    move-result v0

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lc/b2;->r0:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/b2;->Q:Lc/v8;

    if-nez v0, :cond_0

    iget v0, p0, Lc/b2;->e:F

    cmpl-float v0, v0, v1

    if-lez v0, :cond_0

    const/high16 v0, 0x42300000    # 44.0f

    invoke-virtual {p0, v0}, Lc/b2;->J(F)F

    move-result v0

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-virtual {p0, v1}, Lc/b2;->m(F)F

    move-result v1

    add-float/2addr v1, v0

    :cond_0
    return v1

    :cond_1
    iget-object v0, p0, Lc/b2;->g0:Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/util/Date;->setTime(J)V

    iget-object v1, p0, Lc/b2;->y:Landroid/graphics/Paint;

    const/high16 v2, 0x41b80000    # 23.0f

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v2, Lc/b2;->x0:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v3

    iget-object v4, p0, Lc/b2;->f0:Ljava/text/SimpleDateFormat;

    invoke-virtual {v4, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    add-float/2addr v0, v3

    invoke-virtual {p0, v2}, Lc/b2;->m(F)F

    move-result v1

    add-float/2addr v1, v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v2, Lc/E;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v3}, Lc/E;-><init>(Lc/b2;I)V

    invoke-static {v0, v2}, Lc/A8;->d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;

    move-result-object v0

    iget-boolean v2, v0, Lc/A8;->e:Z

    iget-boolean v3, v0, Lc/A8;->b:Z

    add-int/2addr v2, v3

    iget-boolean v3, v0, Lc/A8;->c:Z

    add-int/2addr v2, v3

    iget-boolean v0, v0, Lc/A8;->d:Z

    add-int/2addr v2, v0

    if-lez v2, :cond_2

    add-int/lit8 v2, v2, -0x1

    mul-int/lit8 v2, v2, 0x28

    add-int/lit8 v2, v2, 0x1e

    int-to-float v0, v2

    invoke-virtual {p0, v0}, Lc/b2;->m(F)F

    move-result v0

    add-float/2addr v1, v0

    :cond_2
    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {p0, v0}, Lc/b2;->m(F)F

    move-result v0

    add-float/2addr v0, v1

    return v0
.end method
