.class public final Lc/y;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Z)V
    .locals 0

    iput-object p1, p0, Lc/y;->b:Ljava/lang/Object;

    iput-boolean p2, p0, Lc/y;->a:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 12

    iget-object v0, p0, Lc/y;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v8, 0x0

    if-nez v2, :cond_0

    invoke-static {v0, v1}, Lc/z;->l(Landroid/content/Context;Ljava/lang/String;)Lc/y;

    move-result-object v2

    if-eqz v2, :cond_0

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2, v8}, Lc/n1;->A0(Z)V

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->I0(Ljava/lang/String;)V

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->v0(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v2}, Lc/z;->k()V

    iget-wide v2, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    const-wide/16 v4, 0x1

    add-long/2addr v2, v4

    iput-wide v2, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    new-array v9, v1, [Landroid/app/Dialog;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v1}, Lc/z;->c()Ljava/util/List;

    move-result-object v4

    const-string v1, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lc/B4;

    const/4 v1, 0x1

    invoke-direct {v6, p0, v2, v3, v1}, Lc/B4;-><init>(Ljava/lang/Object;JI)V

    new-instance v7, Lc/H;

    const/16 v1, 0x16

    invoke-direct {v7, p0, v9, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object v1, v0

    move-object v2, v4

    move-object v3, v5

    move-object v4, v6

    move-object v5, v7

    move v6, v11

    move-object v7, v10

    invoke-static/range {v1 .. v7}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    move-result-object v1

    aput-object v1, v9, v8

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    return-void
.end method

.method public b(Ljava/lang/String;)V
    .locals 2

    iget-boolean v0, p0, Lc/y;->a:Z

    iget-object v1, p0, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    if-nez v0, :cond_1

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v1, p1}, Lru/drivedeck/launcher/MainActivity;->I(Ljava/lang/String;)V

    return-void

    :cond_1
    :goto_0
    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_2
    const/4 v0, 0x1

    invoke-virtual {v1, v0, p1}, Lru/drivedeck/launcher/MainActivity;->N(ZLjava/lang/String;)V

    return-void
.end method
