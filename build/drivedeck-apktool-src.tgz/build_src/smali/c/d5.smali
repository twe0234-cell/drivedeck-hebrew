.class public final synthetic Lc/d5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/g5;


# direct methods
.method public synthetic constructor <init>(Lc/g5;I)V
    .locals 0

    iput p2, p0, Lc/d5;->a:I

    iput-object p1, p0, Lc/d5;->b:Lc/g5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/d5;->a:I

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object v2, p0, Lc/d5;->b:Lc/g5;

    invoke-virtual {v2, v0, v1}, Lc/g5;->j(FLjava/lang/Runnable;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/d5;->b:Lc/g5;

    iget-boolean v1, v0, Lc/g5;->E:Z

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, v0, Lc/g5;->v:[Lc/f5;

    const/4 v2, 0x0

    if-eqz v1, :cond_3

    const/4 v3, 0x1

    aget-object v1, v1, v3

    iget-object v1, v1, Lc/f5;->a:Ljava/lang/String;

    iget-object v4, v0, Lc/g5;->u:[Lc/f5;

    aget-object v4, v4, v3

    iget-object v4, v4, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    iget-object v1, v0, Lc/g5;->v:[Lc/f5;

    aget-object v1, v1, v3

    iget-object v1, v1, Lc/f5;->c:Landroid/graphics/Bitmap;

    iget-object v4, v0, Lc/g5;->u:[Lc/f5;

    aget-object v4, v4, v3

    iget-object v4, v4, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-eqz v1, :cond_2

    :cond_1
    if-eqz v4, :cond_2

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_2

    iput-boolean v2, v0, Lc/g5;->C:Z

    iget-object v0, v0, Lc/g5;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    goto :goto_0

    :cond_2
    invoke-virtual {v0, v3}, Lc/g5;->l(Z)V

    goto :goto_0

    :cond_3
    iput-boolean v2, v0, Lc/g5;->E:Z

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lc/g5;->j(FLjava/lang/Runnable;)V

    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
