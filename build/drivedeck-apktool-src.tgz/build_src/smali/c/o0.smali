.class public final Lc/o0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/m0;

.field public final b:Lc/m0;

.field public final c:Lc/m0;

.field public final d:Lc/m0;

.field public final e:Ljava/util/EnumMap;

.field public final f:Z

.field public final g:Z

.field public final h:I

.field public final i:F

.field public final j:Lc/Q1;

.field public final k:F

.field public final l:F


# direct methods
.method public constructor <init>(Lc/m0;Lc/m0;Lc/m0;Lc/m0;Ljava/util/EnumMap;ZZIFLc/Q1;FF)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/o0;->a:Lc/m0;

    iput-object p2, p0, Lc/o0;->b:Lc/m0;

    iput-object p3, p0, Lc/o0;->c:Lc/m0;

    iput-object p4, p0, Lc/o0;->d:Lc/m0;

    iput-object p5, p0, Lc/o0;->e:Ljava/util/EnumMap;

    iput-boolean p6, p0, Lc/o0;->f:Z

    iput-boolean p7, p0, Lc/o0;->g:Z

    iput p8, p0, Lc/o0;->h:I

    iput p9, p0, Lc/o0;->i:F

    iput-object p10, p0, Lc/o0;->j:Lc/Q1;

    iput p11, p0, Lc/o0;->k:F

    iput p12, p0, Lc/o0;->l:F

    return-void
.end method


# virtual methods
.method public final a(Lc/r0;)Lc/m0;
    .locals 14

    iget v0, p1, Lc/r0;->c:I

    const/16 v1, 0x1e

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget v2, p0, Lc/o0;->h:I

    iget v3, p1, Lc/r0;->d:I

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    rsub-int/lit8 v4, v0, 0x1e

    iget v5, p1, Lc/r0;->e:I

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    sub-int v5, v2, v3

    iget p1, p1, Lc/r0;->f:I

    invoke-static {v5, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    sget-object v1, Lc/Q1;->b:Lc/Q1;

    iget v5, p0, Lc/o0;->k:F

    iget-object v6, p0, Lc/o0;->c:Lc/m0;

    iget-object v7, p0, Lc/o0;->j:Lc/Q1;

    if-ne v7, v1, :cond_0

    invoke-virtual {v6, v5}, Lc/m0;->c(F)Lc/m0;

    move-result-object v6

    :cond_0
    invoke-virtual {v6}, Lc/m0;->d()F

    move-result v8

    iget v9, p0, Lc/o0;->l:F

    add-float/2addr v8, v9

    const/high16 v10, 0x41f00000    # 30.0f

    div-float/2addr v8, v10

    iget v10, p0, Lc/o0;->i:F

    add-float/2addr v10, v9

    int-to-float v2, v2

    div-float/2addr v10, v2

    new-instance v2, Lc/m0;

    int-to-float v11, v0

    mul-float/2addr v11, v8

    iget v12, v6, Lc/m0;->a:F

    add-float/2addr v11, v12

    int-to-float v13, v3

    mul-float/2addr v13, v10

    iget v6, v6, Lc/m0;->b:F

    add-float/2addr v13, v6

    add-int/2addr v0, v4

    int-to-float v0, v0

    mul-float/2addr v0, v8

    add-float/2addr v0, v12

    sub-float/2addr v0, v9

    add-int/2addr v3, p1

    int-to-float p1, v3

    mul-float/2addr p1, v10

    add-float/2addr p1, v6

    sub-float/2addr p1, v9

    invoke-direct {v2, v11, v13, v0, p1}, Lc/m0;-><init>(FFFF)V

    if-ne v7, v1, :cond_1

    invoke-virtual {v2, v5}, Lc/m0;->c(F)Lc/m0;

    move-result-object v2

    :cond_1
    return-object v2
.end method

.method public final b(I)F
    .locals 6

    iget-object v0, p0, Lc/o0;->c:Lc/m0;

    invoke-virtual {v0}, Lc/m0;->d()F

    move-result v1

    iget v2, p0, Lc/o0;->l:F

    add-float/2addr v1, v2

    const/high16 v2, 0x41f00000    # 30.0f

    div-float/2addr v1, v2

    sget-object v2, Lc/Q1;->b:Lc/Q1;

    iget v3, v0, Lc/m0;->c:F

    iget v0, v0, Lc/m0;->a:F

    const/16 v4, 0x1e

    iget-object v5, p0, Lc/o0;->j:Lc/Q1;

    if-ne p1, v4, :cond_1

    if-ne v5, v2, :cond_0

    move v3, v0

    :cond_0
    return v3

    :cond_1
    int-to-float p1, p1

    mul-float/2addr p1, v1

    if-ne v5, v2, :cond_2

    sub-float/2addr v3, p1

    goto :goto_0

    :cond_2
    add-float v3, p1, v0

    :goto_0
    return v3
.end method

.method public final c()F
    .locals 3

    iget-boolean v0, p0, Lc/o0;->g:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/o0;->c:Lc/m0;

    invoke-virtual {v0}, Lc/m0;->b()F

    move-result v0

    iget v2, p0, Lc/o0;->i:F

    sub-float/2addr v2, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    :goto_0
    return v1
.end method

.method public final d(FF)Lc/n0;
    .locals 6

    sget-object v0, Lc/Q1;->b:Lc/Q1;

    iget-object v1, p0, Lc/o0;->j:Lc/Q1;

    iget v2, p0, Lc/o0;->k:F

    if-ne v1, v0, :cond_0

    sub-float p1, v2, p1

    :cond_0
    iget-object v3, p0, Lc/o0;->c:Lc/m0;

    if-ne v1, v0, :cond_1

    invoke-virtual {v3, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v3

    :cond_1
    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v0

    iget v1, p0, Lc/o0;->l:F

    add-float/2addr v0, v1

    const/high16 v2, 0x41f00000    # 30.0f

    div-float/2addr v0, v2

    iget v2, p0, Lc/o0;->i:F

    add-float/2addr v2, v1

    iget v1, p0, Lc/o0;->h:I

    int-to-float v4, v1

    div-float/2addr v2, v4

    iget v4, v3, Lc/m0;->a:F

    sub-float/2addr p1, v4

    div-float/2addr p1, v0

    const v0, 0x3727c5ac    # 1.0E-5f

    add-float/2addr p1, v0

    float-to-double v4, p1

    invoke-static {v4, v5}, Ljava/lang/Math;->floor(D)D

    move-result-wide v4

    double-to-int p1, v4

    iget v3, v3, Lc/m0;->b:F

    sub-float/2addr p2, v3

    div-float/2addr p2, v2

    add-float/2addr p2, v0

    float-to-double v2, p2

    invoke-static {v2, v3}, Ljava/lang/Math;->floor(D)D

    move-result-wide v2

    double-to-int p2, v2

    new-instance v0, Lc/n0;

    const/16 v2, 0x1d

    invoke-static {v2, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v2, 0x0

    invoke-static {v2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    add-int/lit8 v1, v1, -0x1

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-static {v2, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-direct {v0, p1, p2}, Lc/n0;-><init>(II)V

    return-object v0
.end method
