.class public final synthetic Lc/R6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lorg/json/JSONObject;

.field public final synthetic b:Ljava/util/LinkedHashMap;

.field public final synthetic c:Landroid/widget/Spinner;

.field public final synthetic d:Landroid/widget/Spinner;

.field public final synthetic e:Landroid/widget/CheckBox;

.field public final synthetic f:Landroid/widget/CheckBox;

.field public final synthetic g:Landroid/widget/TextView;

.field public final synthetic h:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic i:Lc/T5;


# direct methods
.method public synthetic constructor <init>(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/T5;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/R6;->a:Lorg/json/JSONObject;

    iput-object p2, p0, Lc/R6;->b:Ljava/util/LinkedHashMap;

    iput-object p3, p0, Lc/R6;->c:Landroid/widget/Spinner;

    iput-object p4, p0, Lc/R6;->d:Landroid/widget/Spinner;

    iput-object p5, p0, Lc/R6;->e:Landroid/widget/CheckBox;

    iput-object p6, p0, Lc/R6;->f:Landroid/widget/CheckBox;

    iput-object p7, p0, Lc/R6;->g:Landroid/widget/TextView;

    iput-object p8, p0, Lc/R6;->h:Lru/drivedeck/launcher/MainActivity;

    iput-object p9, p0, Lc/R6;->i:Lc/T5;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget-object v0, p0, Lc/R6;->a:Lorg/json/JSONObject;

    iget-object v1, p0, Lc/R6;->b:Ljava/util/LinkedHashMap;

    iget-object v2, p0, Lc/R6;->c:Landroid/widget/Spinner;

    iget-object v3, p0, Lc/R6;->d:Landroid/widget/Spinner;

    iget-object v4, p0, Lc/R6;->e:Landroid/widget/CheckBox;

    iget-object v5, p0, Lc/R6;->f:Landroid/widget/CheckBox;

    iget-object v6, p0, Lc/R6;->g:Landroid/widget/TextView;

    iget-object v7, p0, Lc/R6;->h:Lru/drivedeck/launcher/MainActivity;

    iget-object v8, p0, Lc/R6;->i:Lc/T5;

    :try_start_0
    invoke-static/range {v0 .. v5}, Lc/b7;->d(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "\u041e\u0436\u0438\u0434\u0430\u043d\u0438\u0435 \u043e\u0442\u0432\u0435\u0442\u0430 \u042d\u0411\u0423\u2026"

    invoke-static {v7, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v1, Lc/b;

    const/4 v2, 0x3

    invoke-direct {v1, v6, v7, v2}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v8, v0, v1}, Lc/T5;->N0(Lorg/json/JSONObject;Lc/b;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Lc/i;

    const/16 v1, 0xd

    invoke-direct {v0, v6, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v6, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    return-void
.end method
