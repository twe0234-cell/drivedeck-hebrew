.class public final synthetic Lc/F3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/P3;


# direct methods
.method public synthetic constructor <init>(Lc/P3;I)V
    .locals 0

    iput p2, p0, Lc/F3;->a:I

    iput-object p1, p0, Lc/F3;->b:Lc/P3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 41

    move-object/from16 v0, p0

    const-string v5, ""

    const/high16 v8, 0x41600000    # 14.0f

    const-string v9, "speed_obd"

    sget-object v10, Lc/s0;->g:Lc/s0;

    const-string v11, "\u0424\u043e\u043d"

    const-string v12, "\u0413\u043e\u0442\u043e\u0432\u043e"

    const/16 v13, 0x8

    iget-object v4, v0, Lc/F3;->b:Lc/P3;

    const/4 v7, 0x0

    const/4 v1, 0x1

    iget v2, v0, Lc/F3;->a:I

    packed-switch v2, :pswitch_data_0

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    instance-of v2, v2, Lru/drivedeck/launcher/MainActivity;

    if-eqz v2, :cond_c

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    new-instance v9, Lc/F3;

    invoke-direct {v9, v4, v13}, Lc/F3;-><init>(Lc/P3;I)V

    new-instance v10, Lc/n1;

    invoke-direct {v10, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v11

    const-string v13, "music_widget_style"

    iget-object v6, v10, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    invoke-interface {v6, v13, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v13

    if-ne v13, v1, :cond_0

    move v13, v1

    goto :goto_0

    :cond_0
    move v13, v7

    :goto_0
    new-instance v3, Landroid/app/Dialog;

    invoke-direct {v3, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v2}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v15

    const-string v14, "music_controls_auto_hide"

    invoke-interface {v6, v14, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    const-string v1, "\u0410\u0432\u0442\u043e\u0441\u043a\u0440\u044b\u0442\u0438\u0435 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-static {v2, v1, v14}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v1

    iget v14, v11, Lc/r4;->e:I

    const-string v7, "\u0427\u0435\u0440\u0435\u0437 1,5 \u0441\u0435\u043a\u0443\u043d\u0434\u044b \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u0441\u043a\u0440\u044b\u0432\u0430\u0435\u0442\u0441\u044f. \u041a\u0430\u0441\u0430\u043d\u0438\u0435 \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435."

    invoke-static {v2, v7, v8, v14}, Lc/G8;->X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;

    move-result-object v7

    const-string v14, "\u0423\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435"

    invoke-static {v2, v14}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v14

    invoke-virtual {v14, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v14, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v7, "music_auto_hide_keep_title"

    const/4 v8, 0x0

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    const-string v8, "\u041a\u0440\u043e\u043c\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f \u0438 \u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044f"

    invoke-static {v2, v8, v7}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v7

    invoke-virtual {v1}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/View;->setEnabled(Z)V

    new-instance v8, Lc/v0;

    const/4 v0, 0x0

    invoke-direct {v8, v10, v9, v0}, Lc/v0;-><init>(Lc/n1;Lc/F3;I)V

    invoke-virtual {v7, v8}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v14, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    if-nez v13, :cond_1

    move v8, v0

    goto :goto_1

    :cond_1
    const/16 v8, 0x8

    :goto_1
    invoke-virtual {v14, v8}, Landroid/view/View;->setVisibility(I)V

    new-instance v8, Lc/w0;

    invoke-direct {v8, v10, v7, v9, v0}, Lc/w0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v8}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v0, "\u0412\u0438\u0434 \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    invoke-static {v2, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v7, v7, Landroid/util/DisplayMetrics;->widthPixels:I

    const/high16 v8, 0x43d70000    # 430.0f

    invoke-static {v2, v8}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v8

    if-ge v7, v8, :cond_2

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    const/4 v7, 0x0

    :goto_2
    invoke-virtual {v1, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    move-object/from16 v32, v5

    const/4 v5, 0x0

    const/4 v8, 0x1

    filled-new-array {v5, v8}, [I

    move-result-object v16

    const-string v5, "\u041a\u043b\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043a\u0438\u0439"

    const-string v8, "\u041e\u0431\u043b\u043e\u0436\u043a\u0430 \u0441\u043b\u0435\u0432\u0430"

    filled-new-array {v5, v8}, [Ljava/lang/String;

    move-result-object v5

    move-object/from16 v33, v4

    const/4 v8, 0x2

    new-array v4, v8, [Landroid/widget/LinearLayout;

    move-object/from16 v17, v3

    move-object/from16 v34, v12

    const/4 v3, 0x0

    :goto_3
    iget v12, v11, Lc/r4;->d:I

    if-ge v3, v8, :cond_8

    aget v8, v16, v3

    move-object/from16 v35, v6

    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v36, v15

    const/4 v15, 0x1

    invoke-virtual {v6, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    move-object/from16 v37, v0

    const/high16 v15, 0x41000000    # 8.0f

    invoke-static {v2, v15}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v0

    move-object/from16 v38, v1

    invoke-static {v2, v15}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    move/from16 v39, v7

    invoke-static {v2, v15}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/high16 v15, 0x40800000    # 4.0f

    invoke-static {v2, v15}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v15

    invoke-virtual {v6, v0, v1, v7, v15}, Landroid/view/View;->setPadding(IIII)V

    if-ne v8, v13, :cond_3

    const/4 v0, 0x1

    goto :goto_4

    :cond_3
    const/4 v0, 0x0

    :goto_4
    invoke-static {v11, v2, v0}, Lc/G8;->U0(Lc/r4;Lru/drivedeck/launcher/MainActivity;Z)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/A0;

    invoke-direct {v0, v2, v2, v11, v8}, Lc/A0;-><init>(Lru/drivedeck/launcher/MainActivity;Lru/drivedeck/launcher/MainActivity;Lc/r4;I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42ac0000    # 86.0f

    invoke-static {v2, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/4 v15, -0x1

    invoke-direct {v1, v15, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v0, v5, v3

    const/high16 v1, 0x41600000    # 14.0f

    invoke-static {v2, v0, v1, v12}, Lc/G8;->X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v2, v1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v1, v5, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-ne v8, v13, :cond_4

    const-string v1, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    goto :goto_5

    :cond_4
    move-object/from16 v1, v32

    :goto_5
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    invoke-virtual {v6, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v6, v0}, Landroid/view/View;->setClickable(Z)V

    new-instance v0, Lc/x0;

    move-object/from16 v22, v0

    move-object/from16 v23, v10

    move/from16 v24, v8

    move-object/from16 v25, v14

    move-object/from16 v26, v4

    move-object/from16 v27, v11

    move-object/from16 v28, v2

    move-object/from16 v29, v16

    move-object/from16 v30, v5

    move-object/from16 v31, v9

    invoke-direct/range {v22 .. v31}, Lc/x0;-><init>(Lc/n1;ILandroid/widget/LinearLayout;[Landroid/widget/LinearLayout;Lc/r4;Lru/drivedeck/launcher/MainActivity;[I[Ljava/lang/String;Lc/F3;)V

    invoke-virtual {v6, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    aput-object v6, v4, v3

    if-eqz v39, :cond_5

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v7, -0x2

    invoke-direct {v0, v1, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_6

    :cond_5
    const/4 v7, -0x2

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, 0x0

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    :goto_6
    if-lez v3, :cond_6

    if-eqz v39, :cond_7

    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {v2, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_6
    :goto_7
    move-object/from16 v1, v38

    goto :goto_8

    :cond_7
    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {v2, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    goto :goto_7

    :goto_8
    invoke-virtual {v1, v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    add-int/2addr v3, v0

    move-object/from16 v6, v35

    move-object/from16 v15, v36

    move-object/from16 v0, v37

    move/from16 v7, v39

    const/4 v8, 0x2

    goto/16 :goto_3

    :cond_8
    move-object/from16 v35, v6

    move-object/from16 v36, v15

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v1, v36

    invoke-static {v2, v1, v0}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v2, v1, v14}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "\u041e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u0435"

    invoke-static {v2, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    sget-object v3, Lc/s0;->d:Lc/s0;

    invoke-virtual {v10, v3}, Lc/n1;->Y(Lc/s0;)I

    move-result v4

    new-instance v5, Lc/y0;

    const/4 v6, 0x0

    invoke-direct {v5, v10, v9, v6}, Lc/y0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v6, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u043e\u0431\u043b\u043e\u0436\u043a\u0438"

    invoke-static {v2, v0, v6, v4, v5}, Lc/G8;->e(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Ljava/lang/String;ILjava/util/function/IntConsumer;)V

    invoke-virtual {v10}, Lc/n1;->s()I

    move-result v4

    new-instance v5, Lc/y0;

    const/4 v6, 0x1

    invoke-direct {v5, v10, v9, v6}, Lc/y0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v7, "\u0420\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0430 \u043e\u0431\u043b\u043e\u0436\u043a\u0438"

    invoke-static {v2, v0, v7, v4, v5}, Lc/G8;->e(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Ljava/lang/String;ILjava/util/function/IntConsumer;)V

    invoke-static {v2, v0, v3, v9}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v2, v1, v0}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435"

    invoke-static {v2, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v3, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u043e\u0431\u043b\u043e\u0436\u043a\u0443"

    invoke-virtual {v10}, Lc/n1;->k0()Z

    move-result v4

    invoke-static {v2, v3, v4}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v3

    new-instance v4, Lc/v0;

    invoke-direct {v4, v10, v9, v6}, Lc/v0;-><init>(Lc/n1;Lc/F3;I)V

    invoke-virtual {v3, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v3, "music_tap_to_open"

    move-object/from16 v4, v35

    invoke-interface {v4, v3, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    const-string v4, "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043f\u043e \u043d\u0430\u0436\u0430\u0442\u0438\u044e"

    invoke-static {v2, v4, v3}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v3

    new-instance v4, Lc/v0;

    const/4 v5, 0x2

    invoke-direct {v4, v10, v9, v5}, Lc/v0;-><init>(Lc/n1;Lc/F3;I)V

    invoke-virtual {v3, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v3, "\u0420\u0430\u0437\u043c\u0435\u0440 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f \u0438 \u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044f"

    const/high16 v4, 0x41700000    # 15.0f

    iget v5, v11, Lc/r4;->e:I

    invoke-static {v2, v3, v4, v5}, Lc/G8;->X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v7, -0x2

    invoke-direct {v4, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v6, 0x41000000    # 8.0f

    invoke-static {v2, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-static {v2, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v8

    const/4 v6, 0x0

    invoke-virtual {v4, v6, v7, v6, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v4, 0x1

    const/4 v7, 0x2

    filled-new-array {v6, v4, v7}, [I

    move-result-object v8

    const-string v4, "\u041a\u0440\u0443\u043f\u043d\u044b\u0439"

    const-string v6, "\u041c\u0430\u043b\u0435\u043d\u044c\u043a\u0438\u0439"

    const-string v7, "\u041e\u0431\u044b\u0447\u043d\u044b\u0439"

    filled-new-array {v6, v7, v4}, [Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10}, Lc/n1;->t()I

    move-result v6

    const/4 v7, 0x3

    new-array v13, v7, [Landroid/widget/TextView;

    const/4 v14, 0x0

    :goto_9
    if-ge v14, v7, :cond_b

    aget v7, v8, v14

    aget-object v15, v4, v14

    move-object/from16 v36, v1

    move/from16 v30, v5

    move/from16 v16, v6

    const/high16 v1, 0x41600000    # 14.0f

    if-ne v7, v6, :cond_9

    const/4 v6, 0x1

    goto :goto_a

    :cond_9
    const/4 v6, 0x0

    :goto_a
    invoke-static {v2, v15, v1, v12}, Lc/G8;->X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;

    move-result-object v5

    const/16 v1, 0x11

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0xb

    move-object/from16 v32, v0

    move-object/from16 v35, v3

    move/from16 v31, v12

    const/4 v0, 0x2

    const/16 v3, 0xe

    const/4 v12, 0x1

    invoke-virtual {v5, v1, v3, v12, v0}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    invoke-virtual {v5, v12}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v5, v12}, Landroid/view/View;->setClickable(Z)V

    invoke-static {v5, v15, v11, v6}, Lc/G8;->T0(Landroid/widget/TextView;Ljava/lang/String;Lc/r4;Z)V

    invoke-static {v5}, Lc/G8;->r(Landroid/widget/TextView;)V

    new-instance v0, Lc/z0;

    move-object/from16 v22, v0

    move-object/from16 v23, v10

    move/from16 v24, v7

    move-object/from16 v25, v9

    move-object/from16 v26, v13

    move-object/from16 v27, v4

    move-object/from16 v28, v11

    move-object/from16 v29, v8

    invoke-direct/range {v22 .. v29}, Lc/z0;-><init>(Lc/n1;ILc/F3;[Landroid/widget/TextView;[Ljava/lang/String;Lc/r4;[I)V

    invoke-virtual {v5, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    aput-object v5, v13, v14

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v2, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    const/4 v1, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v14, :cond_a

    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {v2, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_a
    move-object/from16 v1, v35

    invoke-virtual {v1, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    add-int/2addr v14, v0

    move-object v3, v1

    move/from16 v6, v16

    move/from16 v5, v30

    move/from16 v12, v31

    move-object/from16 v0, v32

    move-object/from16 v1, v36

    const/4 v7, 0x3

    goto :goto_9

    :cond_b
    move-object/from16 v36, v1

    move-object v1, v3

    move/from16 v30, v5

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v1, "\u0414\u043b\u0438\u043d\u043d\u043e\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0442\u0440\u0435\u043a\u0430 \u043f\u0440\u043e\u043a\u0440\u0443\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044f \u043d\u0430\u0434 \u043f\u043e\u043b\u043e\u0441\u043e\u0439 \u043f\u0440\u043e\u0433\u0440\u0435\u0441\u0441\u0430."

    move/from16 v3, v30

    const/high16 v4, 0x41600000    # 14.0f

    invoke-static {v2, v1, v4, v3}, Lc/G8;->X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;

    move-result-object v1

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v4, 0x41400000    # 12.0f

    invoke-static {v2, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4, v5, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v0, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v1, v36

    invoke-static {v2, v1, v0}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    move-object/from16 v3, v34

    const/4 v0, 0x1

    invoke-static {v2, v3, v0}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Lc/a0;

    move-object/from16 v6, v17

    const/4 v7, 0x2

    invoke-direct {v4, v6, v7}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v0, v0, [Landroid/view/View;

    aput-object v3, v0, v5

    invoke-static {v2, v0}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v3, "\u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-static {v6, v2, v3, v1, v0}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    move-object/from16 v0, v33

    iput-object v6, v0, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_c
    return-void

    :pswitch_0
    move-object v0, v4

    move-object/from16 v32, v5

    move-object v3, v12

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_d

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    new-instance v2, Lc/F3;

    const/16 v4, 0xc

    invoke-direct {v2, v0, v4}, Lc/F3;-><init>(Lc/P3;I)V

    new-instance v4, Lc/n1;

    invoke-direct {v4, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v5

    iget v6, v5, Lc/r4;->e:I

    move-object/from16 v12, v32

    const/4 v7, 0x0

    const/16 v8, 0xe

    invoke-static {v1, v12, v8, v7, v6}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v6

    new-instance v7, Lc/H;

    const/4 v8, 0x1

    invoke-direct {v7, v6, v1, v8}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v7}, Lc/H;->run()V

    new-instance v8, Lc/Q0;

    invoke-direct {v8, v1, v7}, Lc/Q0;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/H;)V

    invoke-static {v1}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-static {v1, v11}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v11

    invoke-static {v1, v11, v10, v2}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v1, v7, v11}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v1, v7, v10, v2}, Lc/r9;->a(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    const-string v10, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438"

    invoke-static {v1, v10}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v10

    iget-object v11, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v11, Landroid/content/SharedPreferences;

    const/4 v12, 0x0

    invoke-interface {v11, v9, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const-string v13, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0438\u0437 OBD"

    invoke-static {v1, v13, v9}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v9

    new-instance v13, Lc/O0;

    invoke-direct {v13, v4, v2, v12}, Lc/O0;-><init>(Lc/n1;Lc/F3;I)V

    invoke-virtual {v9, v13}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v10, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v9, "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438, \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 OBD. \u0411\u0435\u0437 \u0434\u0430\u043d\u043d\u044b\u0445 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430 \u2014 GPS. \u041f\u0440\u0438 \u043f\u043e\u044f\u0432\u043b\u0435\u043d\u0438\u0438 \u0434\u0430\u043d\u043d\u044b\u0445 \u2014 \u0441\u043d\u043e\u0432\u0430 OBD."

    iget v5, v5, Lc/r4;->e:I

    const/16 v13, 0xe

    invoke-static {v1, v9, v13, v12, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v9

    sget-object v13, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {v9, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v10, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v1, v7, v10}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v9, "\u041d\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044f"

    invoke-static {v1, v9}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v9

    const-string v10, "speed_navigation"

    invoke-interface {v11, v10, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    const-string v11, "\u041f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0438 \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u0430"

    invoke-static {v1, v11, v10}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v10

    new-instance v11, Lc/O0;

    const/4 v14, 0x1

    invoke-direct {v11, v4, v2, v14}, Lc/O0;-><init>(Lc/n1;Lc/F3;I)V

    invoke-virtual {v10, v11}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v2, "\u041c\u0430\u043d\u0451\u0432\u0440 \u0438 \u043e\u0433\u0440\u0430\u043d\u0438\u0447\u0435\u043d\u0438\u0435 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438 \u0438\u0437 \u042f\u043d\u0434\u0435\u043a\u0441 \u041d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u0430 \u0438\u043b\u0438 2\u0413\u0418\u0421. \u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u2014 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0432 \u043e\u043a\u043d\u0435 \u043d\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u0438."

    const/16 v4, 0xe

    invoke-static {v1, v2, v4, v12, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v4, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v12, 0x41000000    # 8.0f

    invoke-static {v1, v12}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v14

    iput v14, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v2, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v9, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v10, 0x41400000    # 12.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    iput v10, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v9, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0435 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438"

    const/4 v6, 0x0

    invoke-static {v1, v2, v6}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v10, Lc/P0;

    invoke-direct {v10, v1, v6}, Lc/P0;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v2, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x42400000    # 48.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    const/4 v11, -0x1

    invoke-direct {v6, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v10, 0x41000000    # 8.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v9, v2, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0441\u043b\u0443\u0436\u0431\u0443 \u00abDriveDeck: \u0434\u0432\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f\u00bb."

    const/4 v6, 0x0

    const/16 v10, 0xe

    invoke-static {v1, v2, v10, v6, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v9, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v1, v7, v9}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const/4 v2, 0x1

    invoke-static {v1, v3, v2}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Lc/c;

    const/4 v5, 0x4

    invoke-direct {v4, v8, v5}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v2, v2, [Landroid/view/View;

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-static {v1, v2}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    const-string v3, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c"

    invoke-static {v8, v1, v3, v7, v2}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    iput-object v8, v0, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_d
    return-void

    :pswitch_1
    move-object v0, v4

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_11

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Lc/P3;->o0()Lc/i;

    move-result-object v5

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    new-instance v8, Landroid/app/Dialog;

    invoke-direct {v8, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v1}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v9

    invoke-static {v1, v11}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v3

    sget-object v4, Lc/s0;->c:Lc/s0;

    invoke-static {v1, v3, v4, v5}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v1, v9, v3}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v1, v9, v4, v5}, Lc/r9;->a(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    const-string v3, "\u041c\u0435\u0441\u0442\u043e\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v1, v3}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v3

    new-instance v4, Landroid/widget/EditText;

    invoke-direct {v4, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x1

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-static {v1}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v6, "\u041d\u0430\u0441\u0435\u043b\u0451\u043d\u043d\u044b\u0439 \u043f\u0443\u043d\u043a\u0442"

    invoke-static {v1, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    iget v6, v2, Lc/r4;->d:I

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    iget v6, v2, Lc/r4;->e:I

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setHintTextColor(I)V

    const/16 v7, 0x2001

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setInputType(I)V

    const/high16 v7, 0x42400000    # 48.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/widget/TextView;->setMinHeight(I)V

    const/high16 v7, 0x41600000    # 14.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/4 v11, 0x0

    invoke-virtual {v4, v10, v11, v7, v11}, Landroid/view/View;->setPadding(IIII)V

    iget v7, v2, Lc/r4;->b:I

    const/16 v10, 0xc

    invoke-static {v1, v7, v10}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x0

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v12, -0x2

    invoke-direct {v7, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v7, "\u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043a\u0430\u0436\u0434\u044b\u0435 30 \u043c\u0438\u043d\u0443\u0442"

    const/16 v13, 0xe

    invoke-static {v1, v7, v13, v11, v6}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v6

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v10, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v10, 0x41000000    # 8.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    iput v11, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v6, "Open-Meteo / \u042f\u043d\u0434\u0435\u043a\u0441 \u041f\u043e\u0433\u043e\u0434\u0430"

    invoke-static {v1}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v7

    invoke-static {v1, v6, v7}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v1}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v7

    const-string v10, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0434\u0430\u043d\u043d\u044b\u0445: Open-Meteo.com"

    invoke-static {v1, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "\u042f\u043d\u0434\u0435\u043a\u0441 \u041f\u043e\u0433\u043e\u0434\u0430"

    const-string v12, "Open-Meteo.com"

    if-eqz v7, :cond_e

    invoke-virtual {v10, v12, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v10

    :cond_e
    sget-object v13, Lc/r4;->p:Lc/r4;

    if-ne v2, v13, :cond_f

    const v2, -0x7f4501

    :goto_b
    const/4 v13, 0x0

    const/16 v14, 0xe

    goto :goto_c

    :cond_f
    iget v2, v2, Lc/r4;->f:I

    goto :goto_b

    :goto_c
    invoke-static {v1, v10, v14, v13, v2}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/TextView;->getPaintFlags()I

    move-result v10

    const/16 v13, 0x8

    or-int/2addr v10, v13

    invoke-virtual {v2, v10}, Landroid/widget/TextView;->setPaintFlags(I)V

    const-string v10, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0434\u0430\u043d\u043d\u044b\u0445 \u043e \u043f\u043e\u0433\u043e\u0434\u0435 Open-Meteo.com. \u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0441\u0430\u0439\u0442"

    invoke-static {v1, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v7, :cond_10

    invoke-virtual {v10, v12, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    goto :goto_d

    :cond_10
    move-object v7, v10

    :goto_d
    invoke-virtual {v2, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v7, 0x1

    invoke-virtual {v2, v7}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v2, v7}, Landroid/view/View;->setClickable(Z)V

    const/16 v11, 0x10

    invoke-virtual {v2, v11}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v11, Lc/P0;

    invoke-direct {v11, v1, v7}, Lc/P0;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v2, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x42400000    # 48.0f

    invoke-static {v1, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    const/4 v12, -0x1

    invoke-direct {v7, v12, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v11, 0x41000000    # 8.0f

    invoke-static {v1, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    iput v11, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v2, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Lc/T0;

    invoke-direct {v7, v1, v2, v10, v5}, Lc/T0;-><init>(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Ljava/lang/String;Lc/i;)V

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-static {v1, v9, v3}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v2, "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c GPS"

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    new-instance v2, Lc/l;

    const/4 v3, 0x2

    invoke-direct {v2, v1, v5, v8, v3}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v2, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v11

    new-instance v12, Lc/j0;

    const/4 v7, 0x1

    move-object v2, v12

    move-object v3, v4

    move-object v4, v1

    move-object v6, v8

    invoke-direct/range {v2 .. v7}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x2

    new-array v2, v2, [Landroid/view/View;

    const/4 v3, 0x0

    aput-object v10, v2, v3

    const/4 v3, 0x1

    aput-object v11, v2, v3

    invoke-static {v1, v2}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    const-string v3, "\u041f\u043e\u0433\u043e\u0434\u0430"

    invoke-static {v8, v1, v3, v9, v2}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    iput-object v8, v0, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_11
    return-void

    :pswitch_2
    move-object v0, v4

    move v3, v7

    iput-boolean v3, v0, Lc/P3;->w:Z

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    iget-object v2, v0, Lc/P3;->C1:Lc/n1;

    if-eqz v1, :cond_14

    iget-object v1, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1, v9, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-virtual {v0, v10}, Lc/P3;->L(Lc/s0;)Z

    move-result v1

    if-eqz v1, :cond_14

    iget-object v1, v0, Lc/P3;->B:Lc/U0;

    if-nez v1, :cond_12

    const/4 v3, -0x1

    goto :goto_e

    :cond_12
    iget v3, v1, Lc/U0;->r:I

    :goto_e
    iget-boolean v1, v0, Lc/P3;->r:Z

    invoke-virtual {v0}, Lc/P3;->n0()V

    invoke-virtual {v0}, Lc/P3;->o()I

    move-result v4

    if-ne v4, v3, :cond_13

    iget-boolean v3, v0, Lc/P3;->r:Z

    if-eq v1, v3, :cond_14

    :cond_13
    invoke-virtual {v0}, Lc/P3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_14
    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_16

    iget-object v1, v0, Lc/P3;->n:Lc/G0;

    iget-boolean v3, v1, Lc/G0;->o:Z

    if-eqz v3, :cond_16

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Lc/n1;->z()I

    move-result v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v2

    invoke-virtual {v2}, Lc/T5;->f1()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v3, v0, Lc/P3;->x:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_15

    iput-object v2, v0, Lc/P3;->x:Ljava/lang/String;

    iget-object v2, v0, Lc/P3;->f:Lc/o0;

    if-eqz v2, :cond_15

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lc/P3;->K(Z)Z

    :cond_15
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/G0;->j(Z)Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_16
    return-void

    :pswitch_3
    move-object v0, v4

    iget-object v1, v0, Lc/P3;->S0:Lc/y8;

    invoke-virtual {v1}, Lc/y8;->c()Z

    move-result v1

    iput-boolean v1, v0, Lc/P3;->R0:Z

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_4
    move-object v0, v4

    iget-object v1, v0, Lc/P3;->S0:Lc/y8;

    invoke-virtual {v1}, Lc/y8;->c()Z

    move-result v1

    iput-boolean v1, v0, Lc/P3;->R0:Z

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_5
    move-object v0, v4

    invoke-virtual {v0}, Lc/P3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_6
    move-object v0, v4

    move v1, v7

    invoke-virtual {v0, v1}, Lc/P3;->K(Z)Z

    return-void

    :pswitch_7
    move-object v0, v4

    move-object v3, v12

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_1f

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lc/J1;

    const/4 v4, 0x2

    invoke-direct {v2, v1, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    new-instance v10, Lc/n1;

    invoke-direct {v10, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v12

    new-instance v13, Landroid/app/Dialog;

    invoke-direct {v13, v1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v1}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v14

    invoke-static {v1, v11}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    sget-object v5, Lc/s0;->b:Lc/s0;

    invoke-static {v1, v4, v5, v2}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v1, v14, v4}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v1, v14, v5, v2}, Lc/r9;->a(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    const-string v4, "\u0421\u0442\u0430\u0442\u0443\u0441 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f"

    invoke-static {v1, v4}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    const-string v5, "clock_status_visible"

    iget-object v6, v10, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v7, 0x1

    invoke-interface {v6, v5, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    const-string v6, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0437\u043d\u0430\u0447\u043a\u0438 \u0441\u0432\u044f\u0437\u0438"

    invoke-static {v1, v6, v5}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v5

    new-instance v6, Lc/i0;

    const/4 v7, 0x0

    invoke-direct {v6, v10, v2, v7}, Lc/i0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v5, v6}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v1, v14, v4}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v4, "\u0427\u0430\u0441\u044b"

    invoke-static {v1, v4}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v11

    new-instance v15, Landroid/widget/LinearLayout;

    invoke-direct {v15, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    const/high16 v5, 0x44020000    # 520.0f

    invoke-static {v1, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    if-ge v4, v5, :cond_17

    const/4 v9, 0x1

    goto :goto_f

    :cond_17
    const/4 v9, 0x0

    :goto_f
    invoke-virtual {v15, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const-string v4, "\u0410\u043d\u0430\u043b\u043e\u0433\u043e\u0432\u044b\u0435"

    const-string v5, "\u0412\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u0446\u0438\u0444\u0440\u044b"

    const-string v6, "\u0413\u043e\u0440\u0438\u0437\u043e\u043d\u0442\u0430\u043b\u044c\u043d\u044b\u0435 \u0446\u0438\u0444\u0440\u044b"

    filled-new-array {v5, v6, v4}, [Ljava/lang/String;

    move-result-object v17

    sget-object v4, Lc/q0;->a:Lc/q0;

    sget-object v5, Lc/q0;->b:Lc/q0;

    sget-object v6, Lc/q0;->c:Lc/q0;

    filled-new-array {v4, v5, v6}, [Lc/q0;

    move-result-object v18

    const/4 v7, 0x3

    const/4 v8, 0x0

    :goto_10
    if-ge v8, v7, :cond_1e

    aget-object v6, v18, v8

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    invoke-virtual {v5, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v4, 0x41000000    # 8.0f

    invoke-static {v1, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v5, v7, v7, v7, v7}, Landroid/view/View;->setPadding(IIII)V

    iget v4, v12, Lc/r4;->b:I

    const/16 v7, 0x10

    invoke-static {v1, v4, v7}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v10}, Lc/n1;->i()Lc/u0;

    move-result-object v7

    iget-object v7, v7, Lc/u0;->c:Ljava/lang/Object;

    check-cast v7, Lc/q0;

    if-eq v7, v6, :cond_19

    sget-object v7, Lc/r4;->p:Lc/r4;

    if-eq v12, v7, :cond_18

    goto :goto_11

    :cond_18
    move/from16 v22, v9

    goto :goto_13

    :cond_19
    :goto_11
    const/high16 v7, 0x40000000    # 2.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    move/from16 v22, v9

    invoke-virtual {v10}, Lc/n1;->i()Lc/u0;

    move-result-object v9

    iget-object v9, v9, Lc/u0;->c:Ljava/lang/Object;

    check-cast v9, Lc/q0;

    if-ne v9, v6, :cond_1a

    iget v9, v12, Lc/r4;->f:I

    goto :goto_12

    :cond_1a
    iget v9, v12, Lc/r4;->h:I

    :goto_12
    invoke-virtual {v4, v7, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :goto_13
    new-instance v7, Landroid/graphics/drawable/RippleDrawable;

    move-object/from16 v33, v0

    const/4 v9, 0x0

    invoke-static {v9}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v9, 0x0

    invoke-direct {v7, v0, v4, v9}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/k0;

    invoke-direct {v0, v1, v1, v6, v12}, Lc/k0;-><init>(Lru/drivedeck/launcher/MainActivity;Lru/drivedeck/launcher/MainActivity;Lc/q0;Lc/r4;)V

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42c00000    # 96.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/4 v9, -0x1

    invoke-direct {v4, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v0, v17, v8

    iget v4, v12, Lc/r4;->d:I

    const/4 v7, 0x0

    const/16 v9, 0xe

    invoke-static {v1, v0, v9, v7, v4}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v0

    const/16 v7, 0x11

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v4, 0x42400000    # 48.0f

    invoke-static {v1, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setMinHeight(I)V

    const/4 v7, 0x2

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    aget-object v0, v17, v8

    invoke-static {v1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    invoke-virtual {v5, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v5, v0}, Landroid/view/View;->setClickable(Z)V

    new-instance v0, Lc/j0;

    const/16 v19, 0x0

    move/from16 v21, v4

    move-object v4, v0

    move-object/from16 v40, v5

    move-object v5, v10

    move/from16 v20, v7

    const/16 v23, 0x11

    const/16 v24, 0x3

    move-object v7, v2

    move/from16 v25, v8

    move-object v8, v13

    move/from16 v16, v22

    const/16 v26, 0x0

    move/from16 v22, v9

    move/from16 v9, v19

    invoke-direct/range {v4 .. v9}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v4, v40

    invoke-virtual {v4, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v16, :cond_1b

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v0, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v8, 0x3f800000    # 1.0f

    goto :goto_14

    :cond_1b
    const/4 v5, -0x1

    const/4 v6, -0x2

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x0

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v0, v7, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    :goto_14
    if-lez v25, :cond_1d

    if-eqz v16, :cond_1c

    const/high16 v7, 0x41000000    # 8.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    iput v9, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    goto :goto_15

    :cond_1c
    const/high16 v7, 0x41000000    # 8.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    iput v9, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    goto :goto_15

    :cond_1d
    const/high16 v7, 0x41000000    # 8.0f

    :goto_15
    invoke-virtual {v15, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    add-int/lit8 v4, v25, 0x1

    move v8, v4

    move/from16 v9, v16

    move/from16 v7, v24

    move-object/from16 v0, v33

    goto/16 :goto_10

    :cond_1e
    move-object/from16 v33, v0

    const/4 v0, 0x1

    invoke-virtual {v11, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v1, v14, v11}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v1, v3, v0}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Lc/a0;

    invoke-direct {v3, v13, v0}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v0, v0, [Landroid/view/View;

    const/4 v3, 0x0

    aput-object v2, v0, v3

    invoke-static {v1, v0}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v2, "\u0412\u0438\u0434 \u0447\u0430\u0441\u043e\u0432"

    invoke-static {v13, v1, v2, v14, v0}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    move-object/from16 v0, v33

    iput-object v13, v0, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_1f
    return-void

    :pswitch_8
    move-object v0, v4

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_20

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_20
    return-void

    :pswitch_9
    move-object v0, v4

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_a
    move-object v0, v4

    iget-boolean v1, v0, Lc/P3;->L1:Z

    if-nez v1, :cond_22

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_22

    iget-object v1, v0, Lc/P3;->P1:Landroid/app/Dialog;

    if-eqz v1, :cond_21

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_21

    goto :goto_16

    :cond_21
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->J1:Z

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->performHapticFeedback(I)Z

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, v0, Lc/P3;->B:Lc/U0;

    if-eqz v1, :cond_22

    iget-object v1, v0, Lc/P3;->O1:Lc/s0;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    iget-object v0, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v0, v1, v2, v3}, Lc/g1;->a(Lc/s0;FF)V

    :cond_22
    :goto_16
    return-void

    :pswitch_b
    move-object v0, v4

    move v1, v7

    iput-boolean v1, v0, Lc/P3;->m1:Z

    iget-boolean v1, v0, Lc/P3;->U1:Z

    if-nez v1, :cond_23

    goto :goto_17

    :cond_23
    invoke-virtual {v0}, Lc/P3;->Y()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_17
    return-void

    :pswitch_c
    move-object v0, v4

    iget v1, v0, Lc/P3;->O0:I

    if-ltz v1, :cond_24

    const/4 v2, 0x1

    iput-boolean v2, v0, Lc/P3;->Q0:Z

    invoke-virtual {v0, v1}, Lc/P3;->T(I)V

    :cond_24
    return-void

    :pswitch_d
    move-object v0, v4

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-nez v1, :cond_25

    goto :goto_18

    :cond_25
    invoke-virtual {v0}, Lc/P3;->N()V

    :goto_18
    return-void

    :pswitch_e
    move-object v0, v4

    iget-boolean v1, v0, Lc/P3;->U1:Z

    if-eqz v1, :cond_26

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0}, Lc/P3;->o0()Lc/i;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v1, v0, v3, v2}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    :cond_26
    return-void

    :pswitch_f
    move-object v0, v4

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_28

    iget-object v1, v0, Lc/P3;->n:Lc/G0;

    iget-boolean v1, v1, Lc/G0;->o:Z

    if-nez v1, :cond_27

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v2, 0x0

    invoke-interface {v1, v9, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-virtual {v0, v10}, Lc/P3;->L(Lc/s0;)Z

    move-result v1

    if-eqz v1, :cond_28

    :cond_27
    iget-boolean v1, v0, Lc/P3;->w:Z

    if-nez v1, :cond_28

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->w:Z

    iget-object v1, v0, Lc/P3;->y:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    :cond_28
    return-void

    :pswitch_10
    move-object v0, v4

    const/4 v5, -0x1

    iget-object v1, v0, Lc/P3;->B1:Lc/x3;

    if-eqz v1, :cond_29

    iget-object v2, v0, Lc/P3;->A1:Lc/r3;

    invoke-virtual {v2}, Lc/r3;->a()I

    move-result v2

    invoke-virtual {v1, v2}, Lc/x3;->accept(I)V

    :cond_29
    iget-object v1, v0, Lc/P3;->B:Lc/U0;

    if-nez v1, :cond_2a

    move v3, v5

    goto :goto_19

    :cond_2a
    iget v3, v1, Lc/U0;->r:I

    :goto_19
    iget-boolean v1, v0, Lc/P3;->r:Z

    invoke-virtual {v0}, Lc/P3;->o()I

    move-result v2

    if-ne v2, v3, :cond_2b

    iget-boolean v2, v0, Lc/P3;->r:Z

    if-eq v1, v2, :cond_2c

    :cond_2b
    invoke-virtual {v0}, Lc/P3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_2c
    return-void

    :pswitch_11
    move-object v0, v4

    invoke-virtual {v0}, Lc/P3;->N()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
