.class public final Lc/L6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Landroid/bluetooth/BluetoothDevice;

.field public final synthetic d:I

.field public final synthetic e:Lc/d6;

.field public final synthetic f:Lc/M6;


# direct methods
.method public constructor <init>(Lc/M6;IJLandroid/bluetooth/BluetoothDevice;ILc/d6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/L6;->f:Lc/M6;

    iput p2, p0, Lc/L6;->a:I

    iput-wide p3, p0, Lc/L6;->b:J

    iput-object p5, p0, Lc/L6;->c:Landroid/bluetooth/BluetoothDevice;

    iput p6, p0, Lc/L6;->d:I

    iput-object p7, p0, Lc/L6;->e:Lc/d6;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 18

    move-object/from16 v1, p0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    :try_start_0
    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->isDiscovering()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->cancelDiscovery()Z

    goto :goto_0

    :catch_0
    move-exception v0

    goto/16 :goto_11

    :cond_0
    :goto_0
    iget v0, v1, Lc/L6;->a:I

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-ne v0, v3, :cond_1

    filled-new-array {v3}, [I

    move-result-object v0

    :goto_1
    move-object v7, v0

    goto :goto_2

    :cond_1
    if-ne v0, v6, :cond_2

    filled-new-array {v6}, [I

    move-result-object v0

    goto :goto_1

    :cond_2
    if-ne v0, v5, :cond_3

    filled-new-array {v5}, [I

    move-result-object v0

    goto :goto_1

    :cond_3
    if-ne v0, v4, :cond_4

    filled-new-array {v4}, [I

    move-result-object v0

    goto :goto_1

    :cond_4
    filled-new-array {v3, v5, v4}, [I

    move-result-object v0

    goto :goto_1

    :goto_2
    array-length v8, v7

    const/4 v0, 0x0

    move v10, v0

    const/4 v0, 0x0

    :goto_3
    if-ge v10, v8, :cond_15

    aget v11, v7, v10

    iget-wide v12, v1, Lc/L6;->b:J

    iget-object v0, v1, Lc/L6;->f:Lc/M6;

    iget-object v0, v0, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v14

    cmp-long v0, v12, v14

    if-nez v0, :cond_14

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v0, :cond_5

    goto/16 :goto_f

    :cond_5
    :try_start_1
    iget-object v0, v1, Lc/L6;->c:Landroid/bluetooth/BluetoothDevice;

    sget-object v12, Lc/M6;->f:Ljava/util/UUID;

    if-ne v11, v3, :cond_6

    invoke-virtual {v0, v12}, Landroid/bluetooth/BluetoothDevice;->createRfcommSocketToServiceRecord(Ljava/util/UUID;)Landroid/bluetooth/BluetoothSocket;

    move-result-object v0

    :goto_4
    move-object v12, v0

    goto :goto_6

    :cond_6
    if-ne v11, v6, :cond_7

    invoke-virtual {v0, v12}, Landroid/bluetooth/BluetoothDevice;->createInsecureRfcommSocketToServiceRecord(Ljava/util/UUID;)Landroid/bluetooth/BluetoothSocket;

    move-result-object v0

    goto :goto_4

    :cond_7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v12

    if-ne v11, v5, :cond_8

    const-string v13, "createRfcommSocket"

    goto :goto_5

    :cond_8
    const-string v13, "createInsecureRfcommSocket"

    :goto_5
    sget-object v14, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    filled-new-array {v14}, [Ljava/lang/Class;

    move-result-object v14

    invoke-virtual {v12, v13, v14}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v12

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    filled-new-array {v13}, [Ljava/lang/Object;

    move-result-object v13

    invoke-virtual {v12, v0, v13}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/BluetoothSocket;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_9

    goto :goto_4

    :goto_6
    :try_start_2
    iget-object v13, v1, Lc/L6;->f:Lc/M6;

    monitor-enter v13
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_6

    :try_start_3
    iget-wide v14, v1, Lc/L6;->b:J

    iget-object v0, v1, Lc/L6;->f:Lc/M6;

    iget-object v0, v0, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v16
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    cmp-long v0, v14, v16

    if-eqz v0, :cond_a

    if-eqz v12, :cond_9

    :try_start_4
    invoke-virtual {v12}, Landroid/bluetooth/BluetoothSocket;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_8

    :goto_7
    move/from16 v16, v10

    goto/16 :goto_b

    :catch_1
    :cond_9
    :goto_8
    :try_start_5
    monitor-exit v13

    return-void

    :catchall_0
    move-exception v0

    goto :goto_7

    :cond_a
    iget-object v0, v1, Lc/L6;->f:Lc/M6;

    iput-object v12, v0, Lc/M6;->e:Landroid/bluetooth/BluetoothSocket;

    iget-object v0, v1, Lc/L6;->f:Lc/M6;

    iget-object v0, v0, Lc/M6;->b:Ljava/util/concurrent/ExecutorService;

    new-instance v14, Lc/K6;

    invoke-direct {v14, v12}, Lc/K6;-><init>(Landroid/bluetooth/BluetoothSocket;)V

    invoke-interface {v0, v14}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    move-result-object v14

    monitor-exit v13
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    iget v0, v1, Lc/L6;->d:I
    :try_end_6
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_6 .. :try_end_6} :catch_8
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_6 .. :try_end_6} :catch_7
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_6

    move/from16 v16, v10

    int-to-long v9, v0

    :try_start_7
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-interface {v14, v9, v10, v0}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;
    :try_end_7
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_7 .. :try_end_7} :catch_5
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_7 .. :try_end_7} :catch_4
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    :try_start_8
    invoke-virtual {v12}, Landroid/bluetooth/BluetoothSocket;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_c

    iget-wide v9, v1, Lc/L6;->b:J

    iget-object v0, v1, Lc/L6;->f:Lc/M6;

    iget-object v0, v0, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v13
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3

    cmp-long v0, v9, v13

    if-eqz v0, :cond_b

    :try_start_9
    invoke-virtual {v12}, Landroid/bluetooth/BluetoothSocket;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_2
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_3

    :catch_2
    return-void

    :cond_b
    :try_start_a
    iget-object v0, v1, Lc/L6;->e:Lc/d6;

    invoke-virtual {v0, v12}, Lc/d6;->a(Landroid/bluetooth/BluetoothSocket;)V

    return-void

    :catch_3
    move-exception v0

    goto :goto_d

    :cond_c
    new-instance v0, Ljava/io/IOException;

    const-string v9, "SPP not connected"

    invoke-direct {v0, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_4
    move-exception v0

    goto :goto_9

    :catch_5
    move-exception v0

    goto :goto_a

    :catch_6
    move-exception v0

    move/from16 v16, v10

    goto :goto_d

    :catch_7
    move-exception v0

    move/from16 v16, v10

    :goto_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    instance-of v9, v0, Ljava/lang/Exception;

    if-eqz v9, :cond_d

    check-cast v0, Ljava/lang/Exception;

    throw v0

    :cond_d
    new-instance v9, Ljava/io/IOException;

    const-string v10, "SPP socket worker failed"

    invoke-direct {v9, v10, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v9

    :catch_8
    move-exception v0

    move/from16 v16, v10

    :goto_a
    invoke-interface {v14, v3}, Ljava/util/concurrent/Future;->cancel(Z)Z

    new-instance v9, Ljava/io/IOException;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "SPP timeout: "

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v13, v1, Lc/L6;->d:I

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, " ms"

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v9
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_3

    :goto_b
    :try_start_b
    monitor-exit v13
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_1

    :try_start_c
    throw v0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_3

    :catchall_1
    move-exception v0

    goto :goto_b

    :goto_c
    const/4 v12, 0x0

    goto :goto_d

    :catch_9
    move-exception v0

    move/from16 v16, v10

    goto :goto_c

    :goto_d
    :try_start_d
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v9

    if-lez v9, :cond_e

    const/16 v9, 0xa

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_e
    if-eq v11, v3, :cond_12

    if-eq v11, v6, :cond_11

    if-eq v11, v5, :cond_10

    if-eq v11, v4, :cond_f

    const-string v9, "automatic SPP"

    goto :goto_e

    :cond_f
    const-string v9, "insecure RFCOMM channel 1"

    goto :goto_e

    :cond_10
    const-string v9, "secure RFCOMM channel 1"

    goto :goto_e

    :cond_11
    const-string v9, "insecure SPP UUID"

    goto :goto_e

    :cond_12
    const-string v9, "secure SPP UUID"

    :goto_e
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ": "

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Lc/M6;->b(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_0

    if-eqz v12, :cond_13

    :try_start_e
    invoke-virtual {v12}, Landroid/bluetooth/BluetoothSocket;->close()V
    :try_end_e
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_a
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_0

    :catch_a
    :cond_13
    :try_start_f
    iget-object v9, v1, Lc/L6;->f:Lc/M6;

    const/4 v10, 0x0

    iput-object v10, v9, Lc/M6;->e:Landroid/bluetooth/BluetoothSocket;

    add-int/lit8 v9, v16, 0x1

    move v10, v9

    goto/16 :goto_3

    :cond_14
    :goto_f
    return-void

    :cond_15
    iget-wide v3, v1, Lc/L6;->b:J

    iget-object v5, v1, Lc/L6;->f:Lc/M6;

    iget-object v5, v5, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    cmp-long v3, v3, v5

    if-nez v3, :cond_17

    iget-object v3, v1, Lc/L6;->e:Lc/d6;

    new-instance v4, Ljava/io/IOException;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    if-lez v5, :cond_16

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_10

    :cond_16
    const-string v2, "SPP unavailable"

    :goto_10
    invoke-direct {v4, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, v3, Lc/d6;->a:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget-object v0, v0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v2, Lc/x;

    iget v5, v3, Lc/d6;->b:I

    const/4 v6, 0x6

    invoke-direct {v2, v3, v5, v4, v6}, Lc/x;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_0

    goto :goto_12

    :goto_11
    iget-wide v2, v1, Lc/L6;->b:J

    iget-object v4, v1, Lc/L6;->f:Lc/M6;

    iget-object v4, v4, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    cmp-long v2, v2, v4

    if-nez v2, :cond_17

    iget-object v2, v1, Lc/L6;->e:Lc/d6;

    iget-object v3, v2, Lc/d6;->a:Ljava/lang/Object;

    check-cast v3, Lc/T5;

    iget-object v3, v3, Lc/T5;->c:Landroid/os/Handler;

    new-instance v4, Lc/x;

    iget v5, v2, Lc/d6;->b:I

    const/4 v6, 0x6

    invoke-direct {v4, v2, v5, v0, v6}, Lc/x;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_17
    :goto_12
    return-void
.end method
