.class public final Lc/f4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroid/content/Context;

.field public final synthetic e:Landroid/os/Handler;


# direct methods
.method public constructor <init>(ILjava/lang/String;Landroid/content/Context;Landroid/os/Handler;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/f4;->b:I

    iput-object p2, p0, Lc/f4;->c:Ljava/lang/String;

    iput-object p3, p0, Lc/f4;->d:Landroid/content/Context;

    iput-object p4, p0, Lc/f4;->e:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    sget v0, Lc/G8;->A:I

    iget v1, p0, Lc/f4;->b:I

    if-ne v1, v0, :cond_6

    new-instance v0, Lc/n1;

    iget-object v1, p0, Lc/f4;->d:Landroid/content/Context;

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static {v1, v0}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lc/f4;->c:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    const-string v0, "media_session"

    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/session/MediaSessionManager;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v3, p0, Lc/f4;->e:Landroid/os/Handler;

    const-wide/16 v4, 0x1388

    const/16 v6, 0x3c

    if-eqz v0, :cond_5

    :try_start_1
    invoke-static {v1, v0}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/media/session/MediaController;

    invoke-virtual {v7}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v7}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v2

    const/4 v8, 0x3

    if-eq v2, v8, :cond_2

    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v0

    const/4 v2, 0x6

    if-ne v0, v2, :cond_3

    :cond_2
    return-void

    :cond_3
    invoke-virtual {v7}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    new-instance v2, Lc/i;

    const/16 v8, 0x8

    invoke-direct {v2, v7, v8}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-static {v1, v0, v2}, Lc/G8;->X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V

    iget v0, p0, Lc/f4;->a:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/f4;->a:I

    if-ge v0, v6, :cond_4

    invoke-virtual {v3, p0, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    :cond_4
    return-void

    :cond_5
    iget v0, p0, Lc/f4;->a:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/f4;->a:I

    if-ge v0, v6, :cond_6

    invoke-virtual {v3, p0, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :catch_0
    :cond_6
    :goto_1
    return-void
.end method
