.class public final Lc/Q3;
.super Lc/F;
.source "SourceFile"

# interfaces
.implements Lc/s2;


# static fields
.field public static final synthetic c0:I


# instance fields
.field public final A:Landroid/view/View;

.field public final B:Lc/E8;

.field public final C:Landroid/view/View;

.field public final D:Lc/b2;

.field public final E:Lc/z;

.field public final F:Lc/n1;

.field public G:Ljava/lang/String;

.field public H:I

.field public I:J

.field public J:Lc/u0;

.field public K:Lc/o0;

.field public final L:Landroid/graphics/RectF;

.field public M:I

.field public N:I

.field public O:Z

.field public P:Z

.field public Q:Lc/s0;

.field public final R:Lc/p9;

.field public S:Z

.field public T:Z

.field public U:F

.field public V:F

.field public final W:Lc/t3;

.field public a0:Ljava/lang/String;

.field public b0:Z

.field public final t:Lc/P3;

.field public u:Z

.field public v:Z

.field public final w:Lc/e0;

.field public final x:Landroid/widget/FrameLayout;

.field public final y:Lc/t2;

.field public final z:Lc/t2;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;Lc/e0;)V
    .locals 14

    move-object v0, p0

    move-object v8, p1

    move-object/from16 v3, p2

    move-object/from16 v1, p3

    move-object/from16 v2, p4

    move-object/from16 v4, p5

    invoke-direct {p0, p1}, Lc/F;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5}, Landroid/graphics/RectF;-><init>()V

    iput-object v5, v0, Lc/Q3;->L:Landroid/graphics/RectF;

    const/4 v5, -0x1

    iput v5, v0, Lc/Q3;->M:I

    iput v5, v0, Lc/Q3;->N:I

    const/4 v9, 0x1

    iput-boolean v9, v0, Lc/Q3;->T:Z

    const-string v5, ""

    iput-object v5, v0, Lc/Q3;->a0:Ljava/lang/String;

    iput-object v3, v0, Lc/Q3;->E:Lc/z;

    iput-object v1, v0, Lc/Q3;->F:Lc/n1;

    iput-object v4, v0, Lc/Q3;->w:Lc/e0;

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    iget v7, v6, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v6, v6, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-static {v7, v6}, Lc/G8;->M(II)Z

    move-result v6

    iput-boolean v6, v0, Lc/Q3;->b0:Z

    invoke-virtual {v1, v6}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v6

    iput-object v6, v0, Lc/Q3;->J:Lc/u0;

    iget-object v6, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const-string v7, "startup_screen"

    invoke-interface {v6, v7}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_0

    const-string v6, "home"

    invoke-virtual/range {p3 .. p3}, Lc/n1;->K()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    invoke-virtual {v1, v7}, Lc/n1;->J(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_0

    invoke-static {v6}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-static {v10, v6}, Lc/z;->l(Landroid/content/Context;Ljava/lang/String;)Lc/y;

    move-result-object v10

    if-eqz v10, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lc/Q3;->z()Ljava/lang/String;

    move-result-object v6

    :cond_1
    :goto_0
    iput-object v6, v0, Lc/Q3;->G:Ljava/lang/String;

    invoke-static {p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v6

    iget v6, v6, Lc/r4;->a:I

    invoke-virtual {p0, v6}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v10, Lc/E8;

    invoke-direct {v10, p1, v3}, Lc/E8;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;)V

    iput-object v10, v0, Lc/Q3;->B:Lc/E8;

    new-instance v6, Lc/P3;

    invoke-direct {v6, p1, v3, v1, v2}, Lc/P3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;)V

    iput-object v6, v0, Lc/Q3;->t:Lc/P3;

    iget-object v11, v0, Lc/Q3;->J:Lc/u0;

    iput-object v11, v6, Lc/P3;->e:Lc/u0;

    iput-object v10, v6, Lc/P3;->b1:Lc/E8;

    new-instance v11, Lc/t3;

    const/4 v12, 0x0

    invoke-direct {v11, p0, v12}, Lc/t3;-><init>(Lc/Q3;I)V

    iput-object v11, v0, Lc/Q3;->W:Lc/t3;

    invoke-virtual {p0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v11, v6, Lc/P3;->i:Lc/S;

    invoke-virtual {p0, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static/range {p5 .. p5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v11, Lc/X;

    const/4 v12, 0x2

    invoke-direct {v11, v4, v12}, Lc/X;-><init>(Lc/e0;I)V

    iget-object v12, v6, Lc/P3;->A:Lc/g1;

    iput-object v11, v12, Lc/g1;->i:Ljava/lang/Runnable;

    new-instance v11, Landroid/widget/FrameLayout;

    invoke-direct {v11, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v11, v0, Lc/Q3;->x:Landroid/widget/FrameLayout;

    invoke-virtual {v11, v9}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    iget-boolean v13, v4, Lc/e0;->n:Z

    if-nez v13, :cond_2

    invoke-virtual/range {p5 .. p5}, Lc/e0;->n()V

    :cond_2
    iget-object v4, v4, Lc/e0;->e:Lc/c0;

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v13

    instance-of v13, v13, Landroid/view/ViewGroup;

    if-eqz v13, :cond_3

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v13

    check-cast v13, Landroid/view/ViewGroup;

    invoke-virtual {v13, v4}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_3
    invoke-virtual {v11, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {p0, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v4, Lc/t2;

    iget-object v11, v0, Lc/Q3;->G:Ljava/lang/String;

    invoke-direct {v4, p1, v7, v11, p0}, Lc/t2;-><init>(Lru/drivedeck/launcher/MainActivity;ILjava/lang/String;Lc/s2;)V

    iput-object v4, v0, Lc/Q3;->y:Lc/t2;

    iput-boolean v9, v4, Lc/t2;->y0:Z

    invoke-virtual {v4}, Lc/t2;->b()V

    invoke-virtual {v4}, Landroid/view/View;->requestLayout()V

    iget-object v11, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {v4, v11}, Lc/t2;->B(Ljava/lang/String;)Z

    move-result v11

    iput-boolean v11, v4, Lc/t2;->z0:Z

    invoke-virtual {v4}, Lc/t2;->I()V

    invoke-virtual {v4}, Lc/t2;->J()V

    new-instance v11, Lc/t3;

    const/4 v13, 0x1

    invoke-direct {v11, p0, v13}, Lc/t3;-><init>(Lc/Q3;I)V

    iput-object v11, v12, Lc/g1;->g:Ljava/lang/Runnable;

    invoke-virtual {p0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual/range {p3 .. p3}, Lc/n1;->F()Ljava/lang/String;

    move-result-object v4

    iget-object v11, v0, Lc/Q3;->G:Ljava/lang/String;

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_4

    goto :goto_1

    :cond_4
    move-object v5, v4

    :goto_1
    new-instance v4, Lc/t2;

    invoke-direct {v4, p1, v9, v5, p0}, Lc/t2;-><init>(Lru/drivedeck/launcher/MainActivity;ILjava/lang/String;Lc/s2;)V

    iput-object v4, v0, Lc/Q3;->z:Lc/t2;

    iput-boolean v9, v4, Lc/t2;->y0:Z

    invoke-virtual {v4}, Lc/t2;->b()V

    invoke-virtual {v4}, Landroid/view/View;->requestLayout()V

    iget-object v5, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {v4, v5}, Lc/t2;->B(Ljava/lang/String;)Z

    move-result v5

    iput-boolean v5, v4, Lc/t2;->z0:Z

    invoke-virtual {v4}, Lc/t2;->I()V

    invoke-virtual {v4}, Lc/t2;->J()V

    new-instance v5, Lc/x3;

    const/4 v11, 0x0

    invoke-direct {v5, p0, v11}, Lc/x3;-><init>(Landroid/view/KeyEvent$Callback;I)V

    iput-object v5, v6, Lc/P3;->B1:Lc/x3;

    invoke-virtual {v4, v7}, Lc/t2;->c0(Z)V

    invoke-virtual {p0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v4, Landroid/view/View;

    invoke-direct {v4, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v4, v0, Lc/Q3;->A:Landroid/view/View;

    new-instance v5, Lc/y3;

    const/4 v6, 0x0

    invoke-direct {v5, p0, v6}, Lc/y3;-><init>(Lc/Q3;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v5, 0x4

    invoke-virtual {v4, v5}, Landroid/view/View;->setImportantForAccessibility(I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v4, v12, Lc/g1;->j:Ljava/util/function/Consumer;

    new-instance v6, Lc/b;

    const/4 v11, 0x1

    invoke-direct {v6, p0, v4, v11}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    iput-object v6, v12, Lc/g1;->j:Ljava/util/function/Consumer;

    new-instance v4, Landroid/view/View;

    invoke-direct {v4, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iput-object v4, v0, Lc/Q3;->C:Landroid/view/View;

    new-instance v6, Lc/y3;

    const/4 v11, 0x1

    invoke-direct {v6, p0, v11}, Lc/y3;-><init>(Lc/Q3;I)V

    invoke-virtual {v4, v6}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    invoke-virtual {v4, v7}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setImportantForAccessibility(I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v11, Lc/b2;

    invoke-virtual/range {p3 .. p3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v4

    new-instance v5, Lc/v8;

    const/4 v1, 0x6

    invoke-direct {v5, v2, v1}, Lc/v8;-><init>(Ljava/lang/Object;I)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    move-object v1, v11

    move-object v2, p1

    move-object/from16 v3, p2

    invoke-direct/range {v1 .. v7}, Lc/b2;-><init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;ZZ)V

    iput-object v11, v0, Lc/Q3;->D:Lc/b2;

    iput-boolean v9, v12, Lc/g1;->L:Z

    new-instance v1, Lc/z3;

    const/4 v2, 0x0

    invoke-direct {v1, v12, v2}, Lc/z3;-><init>(Lc/g1;I)V

    new-instance v2, Lc/z3;

    const/4 v3, 0x1

    invoke-direct {v2, v12, v3}, Lc/z3;-><init>(Lc/g1;I)V

    iput-object v1, v11, Lc/b2;->E:Ljava/lang/Runnable;

    iput-object v2, v11, Lc/b2;->F:Ljava/lang/Runnable;

    invoke-virtual {p0, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {p0, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v1, Lc/p9;

    new-instance v2, Lc/z3;

    const/4 v3, 0x0

    invoke-direct {v2, v12, v3}, Lc/z3;-><init>(Lc/g1;I)V

    new-instance v3, Lc/z3;

    const/4 v4, 0x1

    invoke-direct {v3, v12, v4}, Lc/z3;-><init>(Lc/g1;I)V

    invoke-direct {v1, p1, v2, v3}, Lc/p9;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z3;Lc/z3;)V

    iput-object v1, v0, Lc/Q3;->R:Lc/p9;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iput-object v11, v0, Lc/F;->l:Landroid/view/View;

    new-instance v1, Lc/B;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lc/B;-><init>(Lc/F;I)V

    iput-object v1, v11, Lc/b2;->d:Ljava/util/function/Consumer;

    iget-boolean v2, v11, Lc/b2;->c:Z

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v2}, Lc/B;->accept(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lc/Q3;->I()V

    return-void
.end method

.method public static F(Landroid/view/View;Lc/m0;)V
    .locals 3

    iget v0, p1, Lc/m0;->a:F

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    iget v1, p1, Lc/m0;->b:F

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {p1}, Lc/m0;->d()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    add-int/2addr v2, v0

    invoke-virtual {p1}, Lc/m0;->b()F

    move-result p1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    add-int/2addr p1, v1

    invoke-virtual {p0, v0, v1, v2, p1}, Landroid/view/View;->layout(IIII)V

    return-void
.end method

.method public static G(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;)Lc/C3;
    .locals 18

    move-object/from16 v6, p0

    new-instance v7, Lc/P3;

    move-object/from16 v0, p1

    move-object/from16 v5, p2

    move-object/from16 v1, p3

    invoke-direct {v7, v6, v0, v5, v1}, Lc/P3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;)V

    const/4 v8, 0x1

    iput-boolean v8, v7, Lc/P3;->L1:Z

    iget-object v0, v7, Lc/P3;->A:Lc/g1;

    const/4 v9, 0x0

    iput-boolean v9, v0, Lc/g1;->Y:Z

    invoke-virtual {v0}, Lc/g1;->c()Z

    const-string v0, "music-screen-surface"

    invoke-virtual {v7, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    iput-boolean v8, v7, Lc/P3;->d:Z

    new-instance v3, Lc/u0;

    new-instance v0, Lc/r0;

    sget-object v11, Lc/s0;->d:Lc/s0;

    const/4 v14, 0x0

    const/16 v17, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/16 v15, 0x1e

    const/16 v16, 0x24

    move-object v10, v0

    invoke-direct/range {v10 .. v17}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    sget-object v1, Lc/s0;->i:Lc/s0;

    invoke-static {v1}, Lc/u0;->j(Lc/s0;)Lc/r0;

    move-result-object v1

    invoke-virtual {v1, v8}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v1

    filled-new-array {v0, v1}, [Lc/r0;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-direct {v3, v0}, Lc/u0;-><init>(Ljava/util/List;)V

    iput-object v3, v7, Lc/P3;->e:Lc/u0;

    new-instance v10, Lc/B3;

    move-object v0, v10

    move-object/from16 v1, p0

    move-object v2, v7

    move-object/from16 v4, p0

    move-object/from16 v5, p2

    invoke-direct/range {v0 .. v5}, Lc/B3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/P3;Lc/u0;Lru/drivedeck/launcher/MainActivity;Lc/n1;)V

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v1}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v7, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Lc/C3;

    invoke-direct {v0, v6, v7}, Lc/C3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/P3;)V

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const-string v2, "music-screen-root"

    invoke-virtual {v0, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    iget v2, v2, Lc/r4;->a:I

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v2, v1, v9, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v10, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public static L(Landroid/view/View;)V
    .locals 4

    const-string v0, "music-screen-surface"

    invoke-virtual {p0, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lc/P3;

    const-string v1, "music-screen-root"

    invoke-virtual {p0, v1}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_3

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    iput-object v2, v0, Lc/P3;->c0:Lc/r4;

    invoke-virtual {v0}, Lc/P3;->p()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget v0, v2, Lc/r4;->a:I

    invoke-virtual {v1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const-string v0, "music-screen-title"

    invoke-virtual {v1, v0}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    const-string v3, "music-screen-close"

    invoke-virtual {v1, v3}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    iget v3, v2, Lc/r4;->d:I

    if-eqz v0, :cond_1

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_1
    if-eqz v1, :cond_2

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v0, 0x0

    invoke-static {v1, v2, v0}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    :cond_2
    invoke-static {p0}, Lc/b4;->d(Landroid/view/View;)V

    :cond_3
    :goto_0
    return-void
.end method

.method public static v(Lc/Q3;)V
    .locals 11

    iget-boolean v0, p0, Lc/Q3;->O:Z

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-nez v1, :cond_2

    iget-object v1, p0, Lc/Q3;->K:Lc/o0;

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    iput-boolean v1, p0, Lc/Q3;->O:Z

    iget-object v1, p0, Lc/Q3;->Q:Lc/s0;

    const/4 v2, 0x0

    iput-object v2, p0, Lc/Q3;->Q:Lc/s0;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iget v8, p0, Lc/Q3;->U:F

    iget v9, p0, Lc/Q3;->V:F

    const/4 v10, 0x0

    const/4 v7, 0x3

    invoke-static/range {v3 .. v10}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v2

    invoke-super {p0, v2}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    iget v2, p0, Lc/Q3;->U:F

    iget p0, p0, Lc/Q3;->V:F

    if-eqz v1, :cond_2

    iget-object v3, v0, Lc/P3;->B:Lc/U0;

    if-eqz v3, :cond_2

    iget-object v3, v0, Lc/P3;->f:Lc/o0;

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    iget-object v3, v3, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v3, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/m0;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v4

    const/4 v5, 0x0

    cmpl-float v4, v4, v5

    if-lez v4, :cond_2

    invoke-virtual {v3}, Lc/m0;->b()F

    move-result v3

    cmpl-float v3, v3, v5

    if-lez v3, :cond_2

    iget-object v0, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v0, v1, v2, p0}, Lc/g1;->a(Lc/s0;FF)V

    :cond_2
    :goto_0
    return-void
.end method


# virtual methods
.method public final A()Z
    .locals 2

    iget-object v0, p0, Lc/Q3;->J:Lc/u0;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    sget-object v1, Lc/s0;->j:Lc/s0;

    invoke-virtual {v0, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    :goto_0
    if-eqz v0, :cond_1

    iget-boolean v0, v0, Lc/r0;->g:Z

    if-nez v0, :cond_1

    const/4 v0, 0x1

    goto :goto_1

    :cond_1
    const/4 v0, 0x0

    :goto_1
    return v0
.end method

.method public final B()V
    .locals 4

    iget-wide v0, p0, Lc/Q3;->I:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/Q3;->I:J

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->i()V

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->i()V

    return-void
.end method

.method public final C(FF)Z
    .locals 5

    iget-object v0, p0, Lc/Q3;->C:Landroid/view/View;

    iget-object v1, p0, Lc/Q3;->A:Landroid/view/View;

    filled-new-array {v0, v1}, [Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/4 v3, 0x2

    if-ge v2, v3, :cond_1

    aget-object v3, v0, v2

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v4

    int-to-float v4, v4

    cmpl-float v4, p1, v4

    if-ltz v4, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getRight()I

    move-result v4

    int-to-float v4, v4

    cmpg-float v4, p1, v4

    if-gez v4, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v4

    int-to-float v4, v4

    cmpl-float v4, p2, v4

    if-ltz v4, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getBottom()I

    move-result v3

    int-to-float v3, v3

    cmpg-float v3, p2, v3

    if-gez v3, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return v1
.end method

.method public final D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v0}, Lc/n1;->Z0(I)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    :cond_0
    iget-object p2, p0, Lc/Q3;->E:Lc/z;

    invoke-virtual {p2, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final E(Lc/t2;FF)Z
    .locals 2

    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v0

    int-to-float v0, v0

    cmpg-float v0, p2, v0

    if-ltz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result v0

    int-to-float v0, v0

    cmpl-float v0, p2, v0

    if-gez v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v0

    int-to-float v0, v0

    cmpg-float v0, p3, v0

    if-ltz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result v0

    int-to-float v0, v0

    cmpl-float v0, p3, v0

    if-ltz v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getClipBounds()Landroid/graphics/Rect;

    move-result-object v0

    if-nez v0, :cond_2

    return v1

    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr p2, v1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    int-to-float p1, p1

    sub-float/2addr p3, p1

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-virtual {v0, p2, p1}, Landroid/graphics/Rect;->contains(II)Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    return p1

    :cond_3
    :goto_0
    return v1
.end method

.method public final H(Ljava/lang/String;)Lc/t2;
    .locals 2

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    iget-object v1, v0, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :cond_0
    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    iget-object v1, v0, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final I()V
    .locals 5

    const/4 v0, 0x1

    sget-object v1, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object v1, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v1}, Lc/P3;->p()V

    iget-object v2, p0, Lc/Q3;->w:Lc/e0;

    iget-boolean v3, v2, Lc/e0;->n:Z

    if-eqz v3, :cond_0

    iget-object v3, v2, Lc/e0;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v4, v2, Lc/e0;->o:Ljava/util/List;

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    :cond_0
    invoke-virtual {v2}, Lc/e0;->n()V

    :cond_1
    iget-boolean v2, p0, Lc/Q3;->b0:Z

    iget-object v3, p0, Lc/Q3;->F:Lc/n1;

    invoke-virtual {v3, v2}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v2

    iput-object v2, p0, Lc/Q3;->J:Lc/u0;

    iput-object v2, v1, Lc/P3;->e:Lc/u0;

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    iget-object v1, p0, Lc/F;->l:Landroid/view/View;

    check-cast v1, Lc/b2;

    invoke-virtual {v1}, Lc/b2;->B()V

    iget-object v1, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v1}, Lc/t2;->I()V

    iget-object v2, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v2}, Lc/t2;->I()V

    invoke-virtual {v3}, Lc/n1;->F()Ljava/lang/String;

    move-result-object v3

    iget-object v1, v1, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v3, ""

    :cond_2
    invoke-virtual {v2, v3}, Lc/t2;->d0(Ljava/lang/String;)V

    iget v1, p0, Lc/Q3;->H:I

    add-int/2addr v1, v0

    iput v1, p0, Lc/Q3;->H:I

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    new-instance v3, Lc/j2;

    invoke-direct {v3, p0, v1, v0}, Lc/j2;-><init>(Landroid/view/ViewGroup;II)V

    invoke-static {v2, v3}, Lc/X3;->f(Landroid/content/Context;Ljava/util/function/Consumer;)V

    return-void
.end method

.method public final J()V
    .locals 15

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v2, v0, Lc/P3;->a:Lc/W3;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    iget v3, v1, Lc/r4;->a:I

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    iget-object v1, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v6

    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    move-result v7

    iget-object v1, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual/range {v1 .. v7}, Lc/t2;->a0(Lc/W3;IIIII)V

    iget-object v9, v0, Lc/P3;->a:Lc/W3;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iget v10, v0, Lc/r4;->a:I

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v11

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v12

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v13

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v14

    iget-object v8, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual/range {v8 .. v14}, Lc/t2;->a0(Lc/W3;IIIII)V

    return-void
.end method

.method public final K()V
    .locals 2

    invoke-virtual {p0}, Lc/F;->d()V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    iget-object v0, p0, Lc/F;->l:Landroid/view/View;

    if-eqz v0, :cond_1

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/b2;->j()V

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->invalidateOutline()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_1
    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final M()V
    .locals 3

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lc/i2;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lc/i2;

    invoke-direct {v1, v0, v2}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final N()V
    .locals 2

    invoke-virtual {p0}, Lc/Q3;->I()V

    iget-object v0, p0, Lc/Q3;->w:Lc/e0;

    invoke-virtual {v0}, Lc/e0;->m()V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iget v1, v0, Lc/r4;->a:I

    invoke-virtual {p0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v1, p0, Lc/Q3;->t:Lc/P3;

    iput-object v0, v1, Lc/P3;->c0:Lc/r4;

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    iget-object v0, p0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->K()V

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->K()V

    invoke-virtual {p0}, Lc/Q3;->J()V

    return-void
.end method

.method public final O()V
    .locals 2

    invoke-virtual {p0}, Lc/Q3;->f()Z

    invoke-virtual {p0}, Lc/Q3;->z()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc/Q3;->G:Ljava/lang/String;

    iget-object v1, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v1, v0}, Lc/t2;->d0(Ljava/lang/String;)V

    iget-object v0, p0, Lc/Q3;->F:Lc/n1;

    iget-object v1, p0, Lc/Q3;->G:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/n1;->x0(Ljava/lang/String;)V

    return-void
.end method

.method public final P(Z)V
    .locals 6

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lc/Q3;->w()V

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0}, Lc/P3;->k()V

    invoke-virtual {p0}, Lc/Q3;->B()V

    :cond_0
    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    iput-boolean p1, v0, Lc/t2;->C:Z

    iget-wide v1, v0, Lc/t2;->H:J

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    iput-wide v1, v0, Lc/t2;->H:J

    const/4 v5, 0x0

    invoke-virtual {v0, p1, v1, v2, v5}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    iput-boolean p1, v0, Lc/t2;->C:Z

    iget-wide v1, v0, Lc/t2;->H:J

    add-long/2addr v1, v3

    iput-wide v1, v0, Lc/t2;->H:J

    invoke-virtual {v0, p1, v1, v2, v5}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    return-void
.end method

.method public final Q()V
    .locals 5

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->i()V

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v0, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v0}, Lc/g1;->c()Z

    iget-wide v0, p0, Lc/Q3;->I:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/Q3;->I:J

    iget-object v2, p0, Lc/Q3;->E:Lc/z;

    invoke-virtual {v2}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v2

    new-instance v3, Lc/w3;

    const/4 v4, 0x1

    invoke-direct {v3, p0, v0, v1, v4}, Lc/w3;-><init>(Lc/Q3;JI)V

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0, v2, v3}, Lc/t2;->k0(Ljava/util/ArrayList;Lc/f2;)V

    return-void
.end method

.method public final R(I)V
    .locals 27

    move-object/from16 v6, p0

    move/from16 v7, p1

    const/4 v8, 0x0

    iget-object v0, v6, Lc/Q3;->F:Lc/n1;

    invoke-virtual {v0, v7}, Lc/n1;->e(I)Lc/n1;

    move-result-object v15

    const/4 v14, 0x1

    if-ne v7, v14, :cond_0

    iget-object v0, v6, Lc/Q3;->z:Lc/t2;

    :goto_0
    move-object v13, v0

    goto :goto_1

    :cond_0
    iget-object v0, v6, Lc/Q3;->y:Lc/t2;

    goto :goto_0

    :goto_1
    if-ne v7, v14, :cond_1

    sget-object v0, Lc/s0;->m:Lc/s0;

    goto :goto_2

    :cond_1
    sget-object v0, Lc/s0;->i:Lc/s0;

    :goto_2
    iget-object v1, v6, Lc/Q3;->t:Lc/P3;

    iget-object v1, v1, Lc/P3;->A:Lc/g1;

    invoke-virtual {v1}, Lc/g1;->c()Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v1, v1, Lru/drivedeck/launcher/MainActivity;

    if-nez v1, :cond_2

    return-void

    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v11

    const-string v1, "home_window_scale"

    invoke-virtual {v15, v1}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x64

    iget-object v3, v15, Lc/n1;->b:Ljava/lang/Object;

    move-object v10, v3

    check-cast v10, Landroid/content/SharedPreferences;

    const/16 v3, 0x78

    const/16 v4, 0x32

    invoke-static {v10, v1, v2, v3, v4}, Lc/t;->b(Landroid/content/SharedPreferences;Ljava/lang/String;III)I

    move-result v1

    invoke-static {v12}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v9

    if-ne v7, v14, :cond_3

    const-string v2, "\u041e\u043a\u043d\u043e 2"

    goto :goto_3

    :cond_3
    const-string v2, "\u041e\u043a\u043d\u043e 1"

    :goto_3
    invoke-static {v12, v2}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    new-instance v3, Lc/i2;

    const/16 v5, 0x17

    invoke-direct {v3, v13, v5}, Lc/i2;-><init>(Lc/t2;I)V

    new-instance v5, Lc/n1;

    invoke-direct {v5, v12}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v0}, Lc/n1;->Y(Lc/s0;)I

    move-result v14

    new-instance v4, Lc/W0;

    invoke-direct {v4, v5, v0, v3, v8}, Lc/W0;-><init>(Lc/n1;Lc/s0;Ljava/lang/Runnable;I)V

    const-string v0, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    invoke-static {v12, v2, v0, v14, v4}, Lc/G8;->e(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Ljava/lang/String;ILjava/util/function/IntConsumer;)V

    invoke-static {v12, v9, v2}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, v12}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v3, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u043f\u043e\u043b\u043e\u0441\u0443"

    invoke-static {v12, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v0, v11}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v3, "home_window_bar_visible"

    invoke-virtual {v15, v3}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v10, v3, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v3, Lc/v3;

    invoke-direct {v3, v15, v13, v8}, Lc/v3;-><init>(Lc/n1;Lc/t2;I)V

    invoke-virtual {v0, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v0, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0433\u043e"

    invoke-static {v12, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v14

    invoke-static {v12, v9, v14}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0433\u043e \u2014 "

    const/16 v5, 0x10

    iget v4, v11, Lc/r4;->d:I

    invoke-static {v12, v0, v5, v8, v4}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "%"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v14, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v12}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v3

    const/16 v0, 0x46

    invoke-virtual {v3, v0}, Landroid/widget/ProgressBar;->setMax(I)V

    const/16 v0, 0x32

    sub-int/2addr v1, v0

    invoke-virtual {v3, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432 \u043e\u043a\u043d\u0435 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v0

    const-string v1, "activity"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/16 v16, 0x1

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {v3, v0}, Landroid/view/View;->setEnabled(Z)V

    new-instance v0, Lc/A3;

    const/16 v17, 0x0

    move-object/from16 v18, v0

    move-object/from16 v19, v1

    move-object/from16 v1, p0

    move-object v8, v3

    move-object v3, v15

    move v6, v4

    move-object v4, v13

    move-object/from16 v20, v5

    const/16 v7, 0x10

    move/from16 v5, v17

    invoke-direct/range {v0 .. v5}, Lc/A3;-><init>(Lc/Q3;Landroid/widget/TextView;Lc/n1;Lc/t2;I)V

    invoke-virtual {v8, v0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    invoke-virtual {v14, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v0, ""

    const/16 v8, 0xe

    iget v5, v11, Lc/r4;->e:I

    const/4 v1, 0x0

    invoke-static {v12, v0, v8, v1, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v0

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v1

    move-object/from16 v2, v19

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    const-string v1, "100% \u2014 \u043e\u0431\u044b\u0447\u043d\u044b\u0439 \u0440\u0430\u0437\u043c\u0435\u0440. \u041e\u043a\u043d\u043e \u043e\u0441\u0442\u0430\u0451\u0442\u0441\u044f \u043f\u0440\u0435\u0436\u043d\u0435\u0433\u043e \u0440\u0430\u0437\u043c\u0435\u0440\u0430."

    goto :goto_4

    :cond_4
    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0434\u043b\u044f \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u043e\u0433\u043e \u043e\u043a\u043d\u0430."

    :goto_4
    invoke-static {v12, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    sget-object v4, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {v0, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v14, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v0, "\u041a\u0440\u0430\u0439 \u043e\u043a\u043d\u0430"

    invoke-static {v12, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-static {v12, v9, v3}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/high16 v1, 0x40800000    # 4.0f

    invoke-static {v12, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    invoke-static {v12, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v14

    invoke-static {v12, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-static {v12, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v8

    invoke-virtual {v0, v2, v14, v7, v8}, Landroid/view/View;->setPadding(IIII)V

    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v7, v11, Lc/r4;->b:I

    invoke-virtual {v2, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/high16 v8, 0x447a0000    # 1000.0f

    invoke-static {v7, v8}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v2, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x2

    invoke-direct {v2, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v14, 0x41000000    # 8.0f

    invoke-static {v12, v14}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "off"

    const-string v7, "driving"

    const-string v14, "always"

    filled-new-array {v7, v14, v2}, [Ljava/lang/String;

    move-result-object v2

    const-string v7, "\u0412\u044b\u043a\u043b."

    const-string v14, "\u0412 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0438"

    const-string v8, "\u0412\u0441\u0435\u0433\u0434\u0430"

    filled-new-array {v14, v8, v7}, [Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x3

    new-array v14, v8, [Landroid/widget/TextView;

    const/4 v1, 0x0

    :goto_5
    if-ge v1, v8, :cond_6

    aget-object v22, v2, v1

    aget-object v8, v7, v1

    move-object/from16 v23, v4

    move/from16 v24, v5

    const/16 v4, 0xe

    const/4 v5, 0x0

    invoke-static {v12, v8, v4, v5, v6}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v8

    const/16 v4, 0x11

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v4, 0x42400000    # 48.0f

    invoke-static {v12, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v8, v5}, Landroid/widget/TextView;->setMinHeight(I)V

    const/4 v5, 0x1

    invoke-virtual {v8, v5}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v8, v5}, Landroid/view/View;->setClickable(Z)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v12, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    move-object/from16 v25, v7

    const/high16 v7, 0x3f800000    # 1.0f

    move-object/from16 v26, v9

    const/4 v9, 0x0

    invoke-direct {v5, v9, v4, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v4, 0x40800000    # 4.0f

    if-lez v1, :cond_5

    invoke-static {v12, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_5
    invoke-virtual {v0, v8, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    aput-object v8, v14, v1

    const/4 v5, 0x1

    add-int/2addr v1, v5

    move-object/from16 v4, v23

    move/from16 v5, v24

    move-object/from16 v7, v25

    move-object/from16 v9, v26

    const/4 v8, 0x3

    goto :goto_5

    :cond_6
    move-object/from16 v23, v4

    move/from16 v24, v5

    move-object/from16 v26, v9

    const/4 v5, 0x1

    new-instance v0, Lc/C2;

    const/4 v1, 0x3

    move-object/from16 v7, v26

    move-object v9, v0

    move-object v4, v10

    move-object v10, v2

    move-object v8, v11

    move-object v11, v15

    move-object v5, v12

    move-object v12, v14

    move-object/from16 v21, v13

    move-object v13, v8

    move-object/from16 v16, v14

    const/4 v8, 0x1

    move v14, v1

    invoke-direct/range {v9 .. v14}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v1, 0x0

    const/4 v14, 0x3

    :goto_6
    if-ge v1, v14, :cond_7

    aget-object v11, v2, v1

    aget-object v13, v16, v1

    new-instance v12, Lc/j0;

    const/16 v19, 0x4

    move-object v9, v12

    move-object v10, v15

    move-object v8, v12

    move-object/from16 v12, v21

    move-object/from16 v25, v2

    move-object v2, v13

    move-object v13, v0

    move/from16 v26, v14

    move/from16 v14, v19

    invoke-direct/range {v9 .. v14}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x1

    add-int/2addr v1, v2

    move v8, v2

    move-object/from16 v2, v25

    move/from16 v14, v26

    goto :goto_6

    :cond_7
    move v2, v8

    invoke-virtual {v0}, Lc/C2;->run()V

    const-string v0, "home_edge_fade_all_apps"

    invoke-virtual {v15, v0}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v4, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const-string v1, "\u0420\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u044b\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v5, v1, v0}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v0

    new-instance v1, Lc/v3;

    move-object/from16 v4, v21

    invoke-direct {v1, v15, v4, v2}, Lc/v3;-><init>(Lc/n1;Lc/t2;I)V

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v8, -0x2

    invoke-direct {v1, v2, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x41000000    # 8.0f

    invoke-static {v5, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v8

    iput v8, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v15}, Lc/n1;->h0()Z

    move-result v0

    if-eqz v0, :cond_8

    const-string v0, "\u041e\u0432\u0430\u043b"

    goto :goto_7

    :cond_8
    const-string v0, "\u041f\u0440\u044f\u043c\u043e\u0443\u0433\u043e\u043b\u044c\u043d\u0438\u043a"

    :goto_7
    invoke-virtual {v15}, Lc/n1;->h0()Z

    move-result v1

    invoke-static {v5, v0, v1}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v0

    new-instance v1, Lc/T0;

    invoke-direct {v1, v15, v0, v5, v4}, Lc/T0;-><init>(Lc/n1;Landroid/widget/Switch;Lru/drivedeck/launcher/MainActivity;Lc/t2;)V

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x1

    const/4 v9, -0x2

    invoke-direct {v1, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438"

    const/16 v1, 0x10

    const/4 v8, 0x0

    invoke-static {v5, v0, v1, v8, v6}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v6

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-static {v8, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " \u2014 "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Lc/n1;->q()I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v0, v20

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v8, -0x2

    invoke-direct {v0, v1, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {v5, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v5}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v8

    const/16 v0, 0x7d

    invoke-virtual {v8, v0}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v15}, Lc/n1;->q()I

    move-result v0

    add-int/lit8 v0, v0, -0x19

    invoke-virtual {v8, v0}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438 \u043e\u043a\u043d\u0430 \u043e\u0442 25 \u0434\u043e 150 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u043e\u0432"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v9, Lc/A3;

    const/4 v10, 0x1

    move-object v0, v9

    move-object/from16 v1, p0

    move-object v2, v6

    move-object v6, v3

    move-object v3, v15

    move-object/from16 v11, v23

    move-object v12, v5

    move/from16 v13, v24

    move v5, v10

    invoke-direct/range {v0 .. v5}, Lc/A3;-><init>(Lc/Q3;Landroid/widget/TextView;Lc/n1;Lc/t2;I)V

    invoke-virtual {v8, v9}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    invoke-virtual {v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v0, "\u0412 split-\u0440\u0435\u0436\u0438\u043c\u0435 \u043a\u0440\u0430\u044f \u043e\u0441\u0442\u0430\u044e\u0442\u0441\u044f \u0447\u0451\u0442\u043a\u0438\u043c\u0438."

    const/16 v1, 0xe

    const/4 v2, 0x0

    invoke-static {v12, v0, v1, v2, v13}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v11}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, v12}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v12, v1, v2}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Lc/G2;

    move-object/from16 v3, p0

    move/from16 v4, p1

    invoke-direct {v2, v3, v0, v4}, Lc/G2;-><init>(Lc/Q3;Landroid/app/Dialog;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v2, "\u0413\u043e\u0442\u043e\u0432\u043e"

    const/4 v5, 0x1

    invoke-static {v12, v2, v5}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v6, Lc/a0;

    const/4 v8, 0x7

    invoke-direct {v6, v0, v8}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-ne v4, v5, :cond_9

    const-string v4, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432\u0442\u043e\u0440\u043e\u0433\u043e \u043e\u043a\u043d\u0430"

    goto :goto_8

    :cond_9
    const-string v4, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043e\u043a\u043d\u0430"

    :goto_8
    const/4 v6, 0x2

    new-array v6, v6, [Landroid/view/View;

    const/4 v8, 0x0

    aput-object v1, v6, v8

    aput-object v2, v6, v5

    invoke-static {v12, v6}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-static {v0, v12, v4, v7, v1}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    return-void
.end method

.method public final S()V
    .locals 5

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v0, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v0}, Lc/g1;->c()Z

    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->i()V

    iget-wide v0, p0, Lc/Q3;->I:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/Q3;->I:J

    iget-object v2, p0, Lc/Q3;->E:Lc/z;

    invoke-virtual {v2}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v2

    new-instance v3, Lc/w3;

    const/4 v4, 0x0

    invoke-direct {v3, p0, v0, v1, v4}, Lc/w3;-><init>(Lc/Q3;JI)V

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0, v2, v3}, Lc/t2;->k0(Ljava/util/ArrayList;Lc/f2;)V

    return-void
.end method

.method public final T()V
    .locals 8

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    iget-object v2, p0, Lc/Q3;->w:Lc/e0;

    iget-boolean v3, v2, Lc/e0;->m:Z

    iget-object v4, v2, Lc/e0;->e:Lc/c0;

    if-ne v3, v1, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean v1, v2, Lc/e0;->m:Z

    invoke-virtual {v2}, Lc/e0;->m()V

    const/4 v1, -0x1

    iput v1, v2, Lc/e0;->q:I

    iput v1, v2, Lc/e0;->p:I

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual {v2, v1, v3}, Lc/e0;->x(II)V

    :goto_0
    iget-object v1, p0, Lc/Q3;->K:Lc/o0;

    if-nez v1, :cond_1

    return-void

    :cond_1
    iget-object v1, p0, Lc/Q3;->J:Lc/u0;

    sget-object v3, Lc/s0;->j:Lc/s0;

    invoke-virtual {v1, v3}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    iget-object v5, p0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v5, v3}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/m0;

    iget-object v5, p0, Lc/Q3;->x:Landroid/widget/FrameLayout;

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    iget-boolean v1, v1, Lc/r0;->g:Z

    if-nez v1, :cond_7

    if-nez v3, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {v5, v6}, Landroid/view/View;->setVisibility(I)V

    iget-boolean v1, p0, Lc/Q3;->T:Z

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_3

    move v6, v5

    :cond_3
    invoke-virtual {v2, v6}, Lc/e0;->q(Z)V

    iget-boolean v1, v2, Lc/e0;->n:Z

    if-nez v1, :cond_4

    invoke-virtual {v2}, Lc/e0;->n()V

    :cond_4
    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v3}, Lc/m0;->b()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget-object v5, p0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->c:Lc/m0;

    iget v5, v5, Lc/m0;->a:F

    iget v6, v3, Lc/m0;->a:F

    sub-float/2addr v6, v5

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget-object v6, p0, Lc/Q3;->K:Lc/o0;

    iget-object v6, v6, Lc/o0;->c:Lc/m0;

    iget v6, v6, Lc/m0;->b:F

    iget v3, v3, Lc/m0;->b:F

    sub-float/2addr v3, v6

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/widget/FrameLayout$LayoutParams;

    iget v7, v6, Landroid/widget/FrameLayout$LayoutParams;->width:I

    if-ne v7, v1, :cond_5

    iget v7, v6, Landroid/widget/FrameLayout$LayoutParams;->height:I

    if-ne v7, v2, :cond_5

    iget v7, v6, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    if-ne v7, v5, :cond_5

    iget v7, v6, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    if-eq v7, v3, :cond_6

    :cond_5
    iput v1, v6, Landroid/widget/FrameLayout$LayoutParams;->width:I

    iput v2, v6, Landroid/widget/FrameLayout$LayoutParams;->height:I

    iput v5, v6, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput v3, v6, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    invoke-virtual {v4, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_6
    iget v0, v0, Lc/P3;->D:F

    neg-float v0, v0

    invoke-virtual {v4, v0}, Landroid/view/View;->setTranslationY(F)V

    return-void

    :cond_7
    :goto_1
    const/16 v0, 0x8

    invoke-virtual {v5, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v2, v6}, Lc/e0;->q(Z)V

    return-void
.end method

.method public final U(Lc/m0;Z)V
    .locals 10

    invoke-virtual {p0}, Lc/F;->k()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Lc/m0;->d()F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p1}, Lc/m0;->b()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget-object v3, p0, Lc/Q3;->L:Landroid/graphics/RectF;

    iget v4, v3, Landroid/graphics/RectF;->left:F

    iget v5, p1, Lc/m0;->a:F

    cmpl-float v4, v4, v5

    const/4 v6, 0x1

    iget v7, p1, Lc/m0;->d:F

    iget v8, p1, Lc/m0;->c:F

    iget v9, p1, Lc/m0;->b:F

    if-nez v4, :cond_2

    iget v4, v3, Landroid/graphics/RectF;->top:F

    cmpl-float v4, v4, v9

    if-nez v4, :cond_2

    iget v4, v3, Landroid/graphics/RectF;->right:F

    cmpl-float v4, v4, v8

    if-nez v4, :cond_2

    iget v4, v3, Landroid/graphics/RectF;->bottom:F

    cmpl-float v4, v4, v7

    if-eqz v4, :cond_1

    goto :goto_0

    :cond_1
    move v4, v1

    goto :goto_1

    :cond_2
    :goto_0
    move v4, v6

    :goto_1
    if-eqz p2, :cond_4

    iget p2, p0, Lc/Q3;->M:I

    if-ne p2, v0, :cond_3

    iget p2, p0, Lc/Q3;->N:I

    if-eq p2, v2, :cond_4

    :cond_3
    move v1, v6

    :cond_4
    iget-object p2, p0, Lc/Q3;->y:Lc/t2;

    if-nez v4, :cond_5

    if-nez v1, :cond_5

    invoke-virtual {p2}, Landroid/view/View;->isLayoutRequested()Z

    move-result v4

    if-nez v4, :cond_5

    invoke-virtual {p0, p1}, Lc/Q3;->x(Lc/m0;)V

    return-void

    :cond_5
    if-eqz v1, :cond_6

    if-lez v0, :cond_6

    if-lez v2, :cond_6

    const/high16 v4, 0x40000000    # 2.0f

    invoke-static {v0, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-static {v2, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-virtual {p2, v6, v4}, Landroid/view/View;->measure(II)V

    :cond_6
    invoke-static {p2, p1}, Lc/Q3;->F(Landroid/view/View;Lc/m0;)V

    invoke-virtual {p0, p1}, Lc/Q3;->x(Lc/m0;)V

    if-eqz v1, :cond_8

    if-lez v0, :cond_8

    if-lez v2, :cond_8

    iget p1, p0, Lc/Q3;->M:I

    if-lez p1, :cond_7

    invoke-virtual {p2}, Lc/t2;->m0()V

    :cond_7
    invoke-virtual {p2}, Lc/t2;->T()V

    :cond_8
    invoke-virtual {v3, v5, v9, v8, v7}, Landroid/graphics/RectF;->set(FFFF)V

    iput v0, p0, Lc/Q3;->M:I

    iput v2, p0, Lc/Q3;->N:I

    invoke-virtual {p0}, Lc/Q3;->W()V

    invoke-virtual {p0}, Lc/Q3;->J()V

    return-void
.end method

.method public final V(Z)V
    .locals 9

    invoke-virtual {p0}, Lc/F;->k()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    if-nez v0, :cond_1

    return-void

    :cond_1
    iget-object v0, p0, Lc/Q3;->J:Lc/u0;

    sget-object v1, Lc/s0;->m:Lc/s0;

    invoke-virtual {v0, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    iget-boolean v0, v0, Lc/r0;->g:Z

    if-nez v0, :cond_2

    move v0, v2

    goto :goto_0

    :cond_2
    move v0, v3

    :goto_0
    iget-object v4, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v4, v0}, Lc/t2;->c0(Z)V

    if-nez v0, :cond_3

    return-void

    :cond_3
    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    iget-object v0, v0, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v0, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/m0;

    if-nez v0, :cond_4

    return-void

    :cond_4
    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5}, Landroid/graphics/RectF;-><init>()V

    iget-object v6, p0, Lc/Q3;->t:Lc/P3;

    iget-object v7, v6, Lc/P3;->A:Lc/g1;

    invoke-virtual {v7, v1, v5}, Lc/g1;->p(Lc/s0;Landroid/graphics/RectF;)V

    iget-object v1, v6, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-eqz v1, :cond_5

    invoke-virtual {v5}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5

    new-instance v0, Lc/m0;

    iget v1, v5, Landroid/graphics/RectF;->left:F

    iget v6, v5, Landroid/graphics/RectF;->top:F

    iget v7, v5, Landroid/graphics/RectF;->right:F

    iget v5, v5, Landroid/graphics/RectF;->bottom:F

    invoke-direct {v0, v1, v6, v7, v5}, Lc/m0;-><init>(FFFF)V

    goto :goto_1

    :cond_5
    iget-object v1, p0, Lc/Q3;->K:Lc/o0;

    iget-boolean v5, v1, Lc/o0;->f:Z

    if-nez v5, :cond_6

    iget-boolean v1, v1, Lc/o0;->g:Z

    if-eqz v1, :cond_7

    :cond_6
    new-instance v1, Lc/m0;

    iget v5, v6, Lc/P3;->D:F

    iget v6, v0, Lc/m0;->b:F

    sub-float/2addr v6, v5

    iget v7, v0, Lc/m0;->d:F

    sub-float/2addr v7, v5

    iget v5, v0, Lc/m0;->a:F

    iget v0, v0, Lc/m0;->c:F

    invoke-direct {v1, v5, v6, v0, v7}, Lc/m0;-><init>(FFFF)V

    move-object v0, v1

    :cond_7
    :goto_1
    invoke-virtual {v0}, Lc/m0;->d()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    const/4 v5, 0x2

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v0}, Lc/m0;->b()F

    move-result v6

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v6

    if-ne v6, v1, :cond_9

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v6

    if-eq v6, v5, :cond_8

    goto :goto_2

    :cond_8
    move v2, v3

    :cond_9
    :goto_2
    if-nez p1, :cond_a

    if-nez v2, :cond_a

    invoke-virtual {v4}, Landroid/view/View;->isLayoutRequested()Z

    move-result p1

    if-eqz p1, :cond_b

    :cond_a
    const/high16 p1, 0x40000000    # 2.0f

    invoke-static {v1, p1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-static {v5, p1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    invoke-virtual {v4, v6, p1}, Landroid/view/View;->measure(II)V

    :cond_b
    invoke-static {v4, v0}, Lc/Q3;->F(Landroid/view/View;Lc/m0;)V

    new-instance p1, Landroid/graphics/Rect;

    iget-object v6, p0, Lc/Q3;->K:Lc/o0;

    iget-object v6, v6, Lc/o0;->c:Lc/m0;

    iget v6, v6, Lc/m0;->a:F

    iget v7, v0, Lc/m0;->a:F

    sub-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v3, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    iget-object v8, p0, Lc/Q3;->K:Lc/o0;

    iget-object v8, v8, Lc/o0;->c:Lc/m0;

    iget v8, v8, Lc/m0;->b:F

    iget v0, v0, Lc/m0;->b:F

    sub-float/2addr v8, v0

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    invoke-static {v3, v8}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget-object v8, p0, Lc/Q3;->K:Lc/o0;

    iget-object v8, v8, Lc/o0;->c:Lc/m0;

    iget v8, v8, Lc/m0;->c:F

    sub-float/2addr v8, v7

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    move-result v1

    iget-object v7, p0, Lc/Q3;->K:Lc/o0;

    iget-object v7, v7, Lc/o0;->c:Lc/m0;

    iget v7, v7, Lc/m0;->d:F

    sub-float/2addr v7, v0

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {v5, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-direct {p1, v6, v3, v1, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    iget-boolean v1, v0, Lc/o0;->f:Z

    if-nez v1, :cond_d

    iget-boolean v0, v0, Lc/o0;->g:Z

    if-eqz v0, :cond_c

    goto :goto_3

    :cond_c
    const/4 p1, 0x0

    :cond_d
    :goto_3
    invoke-virtual {v4, p1}, Landroid/view/View;->setClipBounds(Landroid/graphics/Rect;)V

    if-eqz v2, :cond_e

    invoke-virtual {v4}, Lc/t2;->T()V

    :cond_e
    return-void
.end method

.method public final W()V
    .locals 3

    sget-object v0, Lc/s0;->i:Lc/s0;

    iget-object v1, p0, Lc/Q3;->C:Landroid/view/View;

    iget-object v2, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {p0, v2, v0, v1}, Lc/Q3;->X(Lc/t2;Lc/s0;Landroid/view/View;)V

    sget-object v0, Lc/s0;->m:Lc/s0;

    iget-object v1, p0, Lc/Q3;->A:Landroid/view/View;

    iget-object v2, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {p0, v2, v0, v1}, Lc/Q3;->X(Lc/t2;Lc/s0;Landroid/view/View;)V

    return-void
.end method

.method public final X(Lc/t2;Lc/s0;Landroid/view/View;)V
    .locals 8

    iget-object v0, p0, Lc/Q3;->J:Lc/u0;

    if-nez v0, :cond_0

    const/4 p2, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0, p2}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object p2

    :goto_0
    iget-boolean v0, p0, Lc/F;->a:Z

    const/4 v1, 0x4

    if-eqz v0, :cond_7

    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    if-eqz v0, :cond_7

    if-eqz p2, :cond_7

    iget-boolean p2, p2, Lc/r0;->g:Z

    if-nez p2, :cond_7

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p2

    if-eqz p2, :cond_1

    goto/16 :goto_3

    :cond_1
    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    const/4 v0, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-virtual {p1}, Landroid/view/View;->getBottom()I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {p1}, Landroid/view/View;->getClipBounds()Landroid/graphics/Rect;

    move-result-object v5

    if-eqz v5, :cond_2

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v6

    iget v7, v5, Landroid/graphics/Rect;->left:I

    add-int/2addr v6, v7

    invoke-static {p2, v6}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v6

    iget v7, v5, Landroid/graphics/Rect;->top:I

    add-int/2addr v6, v7

    invoke-static {v2, v6}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result v6

    iget v7, v5, Landroid/graphics/Rect;->right:I

    add-int/2addr v6, v7

    invoke-static {v3, v6}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    add-int/2addr p1, v5

    invoke-static {v4, p1}, Ljava/lang/Math;->min(II)I

    move-result v4

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/high16 v5, 0x42800000    # 64.0f

    invoke-static {p1, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    invoke-virtual {p0}, Lc/F;->q()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    sub-int/2addr v5, p1

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-static {v4, p1}, Ljava/lang/Math;->min(II)I

    move-result v4

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, Lc/Q3;->g()Lc/Q1;

    move-result-object v5

    sget-object v6, Lc/Q1;->a:Lc/Q1;

    if-ne v5, v6, :cond_4

    invoke-static {v3, p1}, Ljava/lang/Math;->min(II)I

    move-result v3

    goto :goto_1

    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v5

    sub-int/2addr v5, p1

    invoke-static {p2, v5}, Ljava/lang/Math;->max(II)I

    move-result p2

    :goto_1
    if-ge p2, v3, :cond_6

    if-lt v2, v4, :cond_5

    goto :goto_2

    :cond_5
    invoke-virtual {p3, p2, v2, v3, v4}, Landroid/view/View;->layout(IIII)V

    invoke-virtual {p3, v0}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_6
    :goto_2
    invoke-virtual {p3, v1}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_7
    :goto_3
    invoke-virtual {p3, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public final a(I)V
    .locals 3

    invoke-virtual {p0}, Lc/Q3;->f()Z

    const/4 v0, 0x1

    iget-object v1, p0, Lc/Q3;->F:Lc/n1;

    const-string v2, ""

    if-ne p1, v0, :cond_0

    invoke-virtual {v1, v2}, Lc/n1;->O0(Ljava/lang/String;)Z

    iget-object p1, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {p1}, Lc/t2;->k()V

    return-void

    :cond_0
    iput-object v2, p0, Lc/Q3;->G:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/n1;->x0(Ljava/lang/String;)V

    iget-object p1, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {p1}, Lc/t2;->k()V

    return-void
.end method

.method public final b(I)V
    .locals 1

    invoke-virtual {p0}, Lc/Q3;->f()Z

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Lc/Q3;->S()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lc/Q3;->Q()V

    return-void
.end method

.method public final c(I)V
    .locals 1

    invoke-virtual {p0}, Lc/Q3;->f()Z

    move-result v0

    if-nez v0, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lc/Q3;->z:Lc/t2;

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lc/Q3;->y:Lc/t2;

    :goto_0
    iget-object p1, p1, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lc/Q3;->y(Ljava/lang/String;)Z

    :cond_1
    return-void
.end method

.method public final dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 26

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    invoke-virtual/range {p0 .. p0}, Lc/F;->k()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-super/range {p0 .. p1}, Lc/F;->dispatchDraw(Landroid/graphics/Canvas;)V

    return-void

    :cond_0
    iget-object v8, v0, Lc/Q3;->t:Lc/P3;

    iget-object v1, v8, Lc/P3;->A:Lc/g1;

    iget-boolean v9, v1, Lc/g1;->J:Z

    iget-boolean v1, v0, Lc/F;->d:Z

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-ne v1, v9, :cond_1

    goto :goto_0

    :cond_1
    iput-boolean v9, v0, Lc/F;->d:Z

    iget-object v1, v0, Lc/F;->l:Landroid/view/View;

    check-cast v1, Lc/b2;

    invoke-virtual {v1, v11}, Lc/b2;->F(Z)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->requestLayout()V

    if-eqz v9, :cond_2

    iget-object v1, v0, Lc/F;->s:Lc/D;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    new-instance v1, Lc/n1;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Lc/n1;->f0()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {v0, v10}, Lc/F;->s(Z)V

    goto :goto_0

    :cond_2
    invoke-virtual/range {p0 .. p0}, Lc/F;->d()V

    :cond_3
    :goto_0
    if-eqz v9, :cond_4

    move v1, v11

    goto :goto_1

    :cond_4
    const/16 v1, 0x8

    :goto_1
    iget-object v12, v0, Lc/Q3;->R:Lc/p9;

    invoke-virtual {v12, v1}, Landroid/view/View;->setVisibility(I)V

    if-eqz v9, :cond_5

    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    sub-int/2addr v2, v10

    if-eq v1, v2, :cond_5

    invoke-virtual {v12}, Landroid/view/View;->bringToFront()V

    :cond_5
    iget-object v1, v0, Lc/Q3;->K:Lc/o0;

    sget-object v13, Lc/s0;->i:Lc/s0;

    iget-object v14, v8, Lc/P3;->A:Lc/g1;

    if-nez v1, :cond_6

    goto :goto_2

    :cond_6
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {v14, v13, v1}, Lc/g1;->p(Lc/s0;Landroid/graphics/RectF;)V

    iget-boolean v2, v14, Lc/g1;->J:Z

    if-eqz v2, :cond_7

    invoke-virtual {v1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_7

    new-instance v2, Lc/m0;

    iget v3, v1, Landroid/graphics/RectF;->left:F

    iget v4, v1, Landroid/graphics/RectF;->top:F

    iget v5, v1, Landroid/graphics/RectF;->right:F

    iget v1, v1, Landroid/graphics/RectF;->bottom:F

    invoke-direct {v2, v3, v4, v5, v1}, Lc/m0;-><init>(FFFF)V

    invoke-virtual {v0, v2, v10}, Lc/Q3;->U(Lc/m0;Z)V

    goto :goto_2

    :cond_7
    iget-object v1, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual {v1, v13}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    if-eqz v1, :cond_a

    iget-object v1, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual {v1, v13}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    iget-boolean v1, v1, Lc/r0;->g:Z

    if-nez v1, :cond_a

    iget-object v1, v0, Lc/Q3;->K:Lc/o0;

    iget-object v2, v1, Lc/o0;->b:Lc/m0;

    iget-boolean v3, v1, Lc/o0;->f:Z

    if-nez v3, :cond_8

    iget-boolean v1, v1, Lc/o0;->g:Z

    if-eqz v1, :cond_9

    :cond_8
    new-instance v1, Lc/m0;

    iget v3, v2, Lc/m0;->a:F

    iget v4, v8, Lc/P3;->D:F

    iget v5, v2, Lc/m0;->b:F

    sub-float/2addr v5, v4

    iget v6, v2, Lc/m0;->d:F

    sub-float/2addr v6, v4

    iget v2, v2, Lc/m0;->c:F

    invoke-direct {v1, v3, v5, v2, v6}, Lc/m0;-><init>(FFFF)V

    move-object v2, v1

    :cond_9
    invoke-virtual {v0, v2, v11}, Lc/Q3;->U(Lc/m0;Z)V

    :cond_a
    :goto_2
    invoke-virtual {v0, v11}, Lc/Q3;->V(Z)V

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->T()V

    invoke-super/range {p0 .. p1}, Lc/F;->dispatchDraw(Landroid/graphics/Canvas;)V

    iget-object v15, v8, Lc/P3;->B:Lc/U0;

    if-eqz v15, :cond_20

    iget-object v1, v8, Lc/P3;->f:Lc/o0;

    if-eqz v1, :cond_20

    iget-object v6, v8, Lc/P3;->c0:Lc/r4;

    iget-object v1, v14, Lc/g1;->F:Lc/o0;

    if-nez v1, :cond_b

    goto/16 :goto_b

    :cond_b
    invoke-virtual {v14}, Lc/g1;->z()V

    iget-boolean v1, v14, Lc/g1;->J:Z

    iget-object v5, v14, Lc/g1;->w:Landroid/graphics/RectF;

    iget-object v4, v14, Lc/g1;->x:Landroid/graphics/RectF;

    if-eqz v1, :cond_c

    invoke-virtual {v14}, Lc/g1;->o()V

    goto :goto_3

    :cond_c
    invoke-virtual {v5}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v4}, Landroid/graphics/RectF;->setEmpty()V

    :goto_3
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v3

    iget-object v1, v14, Lc/g1;->F:Lc/o0;

    iget-object v1, v1, Lc/o0;->c:Lc/m0;

    iget v2, v1, Lc/m0;->b:F

    iget v10, v1, Lc/m0;->c:F

    iget v11, v1, Lc/m0;->a:F

    iget v1, v1, Lc/m0;->d:F

    invoke-virtual {v7, v11, v2, v10, v1}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    iget-boolean v1, v14, Lc/g1;->J:Z

    iget-object v10, v14, Lc/g1;->y:Landroid/graphics/RectF;

    if-eqz v1, :cond_1c

    iget-object v1, v14, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_4
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/s0;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    move-object/from16 v16, v1

    iget-object v1, v14, Lc/g1;->H:Lc/s0;

    move/from16 v17, v3

    sget-object v3, Lc/s0;->k:Lc/s0;

    move-object/from16 v18, v4

    sget-object v4, Lc/s0;->h:Lc/s0;

    if-eq v1, v3, :cond_d

    if-ne v1, v4, :cond_e

    :cond_d
    iget-object v1, v14, Lc/g1;->D:Lc/u0;

    if-eqz v1, :cond_e

    iget-boolean v1, v14, Lc/g1;->K:Z

    if-eqz v1, :cond_e

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {v14, v2, v1}, Lc/g1;->p(Lc/s0;Landroid/graphics/RectF;)V

    move-object v3, v1

    goto :goto_5

    :cond_e
    move-object/from16 v3, v16

    :goto_5
    iget v1, v3, Landroid/graphics/RectF;->bottom:F

    move-object/from16 v16, v5

    iget-object v5, v14, Lc/g1;->F:Lc/o0;

    iget-object v5, v5, Lc/o0;->c:Lc/m0;

    move-object/from16 v19, v11

    iget v11, v5, Lc/m0;->b:F

    cmpg-float v1, v1, v11

    if-ltz v1, :cond_1b

    iget v1, v3, Landroid/graphics/RectF;->top:F

    iget v5, v5, Lc/m0;->d:F

    cmpl-float v1, v1, v5

    if-lez v1, :cond_f

    :goto_6
    move-object/from16 v5, v16

    move/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v11, v19

    goto :goto_4

    :cond_f
    invoke-virtual {v14, v2}, Lc/g1;->i(Lc/s0;)Z

    move-result v1

    if-eqz v1, :cond_12

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {v14, v2, v1}, Lc/g1;->p(Lc/s0;Landroid/graphics/RectF;)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v3

    invoke-virtual {v7, v1}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    invoke-virtual {v8, v2, v7, v1, v15}, Lc/P3;->H(Lc/s0;Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V

    invoke-virtual {v7, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget-object v2, v14, Lc/g1;->D:Lc/u0;

    if-nez v2, :cond_10

    iget v3, v6, Lc/r4;->d:I

    goto :goto_7

    :cond_10
    iget v3, v6, Lc/r4;->e:I

    :goto_7
    if-eqz v2, :cond_11

    const/4 v2, 0x1

    goto :goto_8

    :cond_11
    const/4 v2, 0x0

    :goto_8
    invoke-virtual {v14, v7, v1, v3, v2}, Lc/g1;->w(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V

    goto :goto_6

    :cond_12
    iget v1, v6, Lc/r4;->d:I

    const/4 v5, 0x0

    invoke-virtual {v14, v7, v3, v1, v5}, Lc/g1;->w(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V

    iget v11, v6, Lc/r4;->a:I

    if-ne v2, v4, :cond_13

    iget-object v1, v14, Lc/g1;->z:Landroid/graphics/RectF;

    move-object/from16 v20, v2

    const/4 v4, 0x1

    invoke-virtual {v14, v3, v5, v4}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v14, v7, v1, v6}, Lc/g1;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    const v2, 0x7f0300c4

    invoke-virtual {v14, v7, v2, v1, v11}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    goto :goto_9

    :cond_13
    move-object/from16 v20, v2

    :goto_9
    iget-object v5, v14, Lc/g1;->l:Landroid/graphics/Paint;

    iget v1, v6, Lc/r4;->d:I

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x40800000    # 4.0f

    invoke-virtual {v14, v1}, Lc/g1;->h(F)F

    move-result v1

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    iget v1, v3, Landroid/graphics/RectF;->left:F

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v14, v4}, Lc/g1;->h(F)F

    move-result v2

    add-float/2addr v2, v1

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/high16 v4, 0x41200000    # 10.0f

    invoke-virtual {v14, v4}, Lc/g1;->h(F)F

    move-result v22

    sub-float v22, v1, v22

    iget v1, v3, Landroid/graphics/RectF;->left:F

    const/high16 v4, 0x40000000    # 2.0f

    invoke-virtual {v14, v4}, Lc/g1;->h(F)F

    move-result v21

    add-float v21, v21, v1

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/high16 v4, 0x41200000    # 10.0f

    invoke-virtual {v14, v4}, Lc/g1;->h(F)F

    move-result v23

    add-float v23, v23, v1

    move-object/from16 v1, p1

    move-object/from16 v24, v8

    move-object/from16 v8, v20

    move-object v0, v3

    move-object/from16 v20, v15

    move/from16 v15, v17

    move/from16 v3, v22

    move-object/from16 v17, v18

    move-object/from16 v18, v12

    const/high16 v12, 0x40000000    # 2.0f

    move/from16 v4, v21

    move-object/from16 v21, v5

    move/from16 v5, v23

    move-object/from16 v25, v6

    move-object/from16 v6, v21

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    iget v1, v0, Landroid/graphics/RectF;->right:F

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v2

    sub-float v2, v1, v2

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v14, v6}, Lc/g1;->h(F)F

    move-result v3

    sub-float v3, v1, v3

    iget v1, v0, Landroid/graphics/RectF;->right:F

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v4

    sub-float v4, v1, v4

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    invoke-virtual {v14, v6}, Lc/g1;->h(F)F

    move-result v5

    add-float/2addr v5, v1

    move-object/from16 v1, p1

    move v12, v6

    move-object/from16 v6, v21

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v2

    sub-float v2, v1, v2

    iget v1, v0, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x40000000    # 2.0f

    invoke-virtual {v14, v3}, Lc/g1;->h(F)F

    move-result v4

    add-float/2addr v4, v1

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v5

    add-float/2addr v5, v1

    iget v1, v0, Landroid/graphics/RectF;->top:F

    invoke-virtual {v14, v3}, Lc/g1;->h(F)F

    move-result v6

    add-float/2addr v6, v1

    move-object/from16 v1, p1

    move v3, v4

    move v4, v5

    move v5, v6

    move-object/from16 v6, v21

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v2

    sub-float v2, v1, v2

    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    const/high16 v3, 0x40000000    # 2.0f

    invoke-virtual {v14, v3}, Lc/g1;->h(F)F

    move-result v4

    sub-float v4, v1, v4

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v14, v12}, Lc/g1;->h(F)F

    move-result v5

    add-float/2addr v5, v1

    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v14, v3}, Lc/g1;->h(F)F

    move-result v3

    sub-float v6, v1, v3

    move-object/from16 v1, p1

    move v3, v4

    move v4, v5

    move v5, v6

    move-object/from16 v6, v21

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v14, v0, v1, v2}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v3

    iget-object v4, v14, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v4, v8, v3}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v12, v25

    invoke-virtual {v14, v7, v3, v12}, Lc/g1;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    const v4, 0x7f0300c3

    invoke-virtual {v14, v7, v4, v3, v11}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    sget-object v3, Lc/s0;->j:Lc/s0;

    if-ne v8, v3, :cond_14

    invoke-virtual {v14, v0, v2, v1}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v3

    invoke-virtual {v10, v3}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v14, v7, v10, v12}, Lc/g1;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    const v2, 0x7f0300bf

    invoke-virtual {v14, v7, v2, v10, v11}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    :cond_14
    invoke-virtual {v14, v0, v1, v1}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v2

    iget-object v1, v14, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v1, v8, v2}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v14, v7, v2, v12}, Lc/g1;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    const v1, 0x7f0300c9

    invoke-virtual {v14, v7, v1, v2, v11}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    sget-object v1, Lc/s0;->c:Lc/s0;

    if-ne v8, v1, :cond_15

    iget-object v1, v14, Lc/g1;->s:Landroid/graphics/RectF;

    goto :goto_a

    :cond_15
    sget-object v1, Lc/s0;->g:Lc/s0;

    if-ne v8, v1, :cond_16

    iget-object v1, v14, Lc/g1;->t:Landroid/graphics/RectF;

    goto :goto_a

    :cond_16
    if-ne v8, v13, :cond_17

    iget-object v1, v14, Lc/g1;->u:Landroid/graphics/RectF;

    goto :goto_a

    :cond_17
    sget-object v1, Lc/s0;->d:Lc/s0;

    if-ne v8, v1, :cond_18

    iget-object v1, v14, Lc/g1;->v:Landroid/graphics/RectF;

    goto :goto_a

    :cond_18
    sget-object v1, Lc/s0;->b:Lc/s0;

    if-ne v8, v1, :cond_19

    iget-object v1, v14, Lc/g1;->r:Landroid/graphics/RectF;

    goto :goto_a

    :cond_19
    iget-object v1, v14, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {v1, v8}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    :goto_a
    const/4 v2, 0x0

    if-eqz v1, :cond_1a

    invoke-virtual {v14, v0, v2, v2}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v14, v7, v1, v12}, Lc/g1;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V

    const v0, 0x7f0300cb

    invoke-virtual {v14, v7, v0, v1, v11}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    :cond_1a
    move-object/from16 v0, p0

    move-object v6, v12

    move v3, v15

    move-object/from16 v5, v16

    move-object/from16 v4, v17

    move-object/from16 v12, v18

    move-object/from16 v11, v19

    move-object/from16 v15, v20

    move-object/from16 v8, v24

    goto/16 :goto_4

    :cond_1b
    move-object/from16 v20, v15

    move/from16 v15, v17

    move-object/from16 v17, v18

    move-object/from16 v18, v12

    move-object/from16 v0, p0

    move v3, v15

    move-object/from16 v5, v16

    move-object/from16 v4, v17

    move-object/from16 v11, v19

    move-object/from16 v15, v20

    goto/16 :goto_4

    :cond_1c
    move v15, v3

    move-object/from16 v17, v4

    move-object/from16 v16, v5

    move-object/from16 v18, v12

    move-object v12, v6

    invoke-virtual {v7, v15}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget-boolean v0, v14, Lc/g1;->L:Z

    if-eqz v0, :cond_1d

    goto :goto_c

    :cond_1d
    iget-boolean v0, v14, Lc/g1;->J:Z

    if-eqz v0, :cond_1f

    iget v1, v14, Lc/g1;->N:I

    const/4 v2, 0x1

    if-eq v1, v2, :cond_1e

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1f

    :cond_1e
    iget-boolean v1, v14, Lc/g1;->K:Z

    if-eqz v1, :cond_1f

    invoke-virtual/range {v16 .. v16}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {v17 .. v17}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v10}, Landroid/graphics/RectF;->setEmpty()V

    goto :goto_c

    :cond_1f
    if-eqz v0, :cond_21

    const-string v4, "\u0413\u043e\u0442\u043e\u0432\u043e"

    const v5, 0x7f0300c1

    move-object v1, v14

    move-object/from16 v2, p1

    move-object/from16 v3, v16

    move-object v6, v12

    invoke-virtual/range {v1 .. v6}, Lc/g1;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;ILc/r4;)V

    invoke-virtual/range {v17 .. v17}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_21

    const-string v4, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442"

    const v5, 0x7f0300bf

    move-object v1, v14

    move-object/from16 v2, p1

    move-object/from16 v3, v17

    move-object v6, v12

    invoke-virtual/range {v1 .. v6}, Lc/g1;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;ILc/r4;)V

    goto :goto_c

    :cond_20
    :goto_b
    move-object/from16 v18, v12

    :cond_21
    :goto_c
    if-eqz v9, :cond_22

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getDrawingTime()J

    move-result-wide v0

    move-object/from16 v2, p0

    move-object/from16 v3, v18

    invoke-super {v2, v7, v3, v0, v1}, Lc/F;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    goto :goto_d

    :cond_22
    move-object/from16 v2, p0

    :goto_d
    return-void
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 17

    move-object/from16 v0, p0

    iget-boolean v1, v0, Lc/Q3;->T:Z

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lc/F;->k()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-super/range {p0 .. p1}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    return v1

    :cond_1
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v3, 0x1

    iget-object v4, v0, Lc/Q3;->t:Lc/P3;

    if-nez v1, :cond_5

    iget-object v1, v4, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_2

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-virtual {v1, v5, v6}, Lc/a5;->c(FF)Z

    move-result v1

    if-eqz v1, :cond_2

    move v1, v3

    goto :goto_0

    :cond_2
    move v1, v2

    :goto_0
    iput-boolean v1, v0, Lc/Q3;->u:Z

    iget-object v5, v4, Lc/P3;->K:Lc/a5;

    if-eqz v5, :cond_3

    if-nez v1, :cond_3

    iget-object v1, v4, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-virtual {v1, v5, v6}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3

    move v1, v3

    goto :goto_1

    :cond_3
    move v1, v2

    :goto_1
    iput-boolean v1, v0, Lc/Q3;->v:Z

    if-eqz v1, :cond_4

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    invoke-virtual {v4}, Lc/P3;->p()V

    goto :goto_2

    :cond_4
    iget-object v1, v4, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_5

    iget-boolean v1, v0, Lc/Q3;->u:Z

    if-nez v1, :cond_5

    iget-object v1, v4, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-virtual {v1, v5, v6}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-nez v1, :cond_5

    invoke-virtual {v4}, Lc/P3;->p()V

    :cond_5
    :goto_2
    iget-boolean v1, v0, Lc/Q3;->v:Z

    const/4 v5, 0x3

    if-eqz v1, :cond_8

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-eq v1, v3, :cond_6

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-ne v1, v5, :cond_7

    :cond_6
    iput-boolean v2, v0, Lc/Q3;->v:Z

    :cond_7
    return v3

    :cond_8
    iget-boolean v1, v0, Lc/Q3;->u:Z

    if-eqz v1, :cond_b

    iget-object v1, v4, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_b

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    invoke-virtual/range {p0 .. p1}, Lc/F;->p(Landroid/view/MotionEvent;)V

    invoke-static/range {p1 .. p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v1

    iget-object v6, v4, Lc/P3;->K:Lc/a5;

    iget v7, v6, Lc/a5;->w:I

    neg-int v7, v7

    int-to-float v7, v7

    iget v6, v6, Lc/a5;->x:I

    neg-int v6, v6

    int-to-float v6, v6

    invoke-virtual {v1, v7, v6}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    iget-object v4, v4, Lc/P3;->K:Lc/a5;

    invoke-virtual {v4, v1}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-eq v1, v3, :cond_9

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-ne v1, v5, :cond_a

    :cond_9
    iput-boolean v2, v0, Lc/Q3;->u:Z

    :cond_a
    return v3

    :cond_b
    iget-object v1, v4, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    const/4 v6, 0x2

    if-eqz v1, :cond_1a

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-nez v1, :cond_16

    iget-object v7, v0, Lc/Q3;->w:Lc/e0;

    iget-boolean v8, v7, Lc/e0;->n:Z

    if-nez v8, :cond_c

    invoke-virtual {v7}, Lc/e0;->n()V

    :cond_c
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v8

    iget-object v9, v0, Lc/Q3;->x:Landroid/widget/FrameLayout;

    invoke-virtual {v9}, Landroid/view/View;->getX()F

    move-result v10

    sub-float/2addr v8, v10

    iget-object v10, v7, Lc/e0;->e:Lc/c0;

    invoke-virtual {v10}, Landroid/view/View;->getX()F

    move-result v11

    sub-float/2addr v8, v11

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v11

    invoke-virtual {v9}, Landroid/view/View;->getY()F

    move-result v9

    sub-float/2addr v11, v9

    invoke-virtual {v10}, Landroid/view/View;->getY()F

    move-result v9

    sub-float/2addr v11, v9

    iget-object v9, v0, Lc/Q3;->R:Lc/p9;

    invoke-virtual {v9}, Landroid/view/View;->getVisibility()I

    move-result v10

    if-nez v10, :cond_d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getX()F

    move-result v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getX()F

    move-result v12

    invoke-virtual {v9}, Landroid/view/View;->getWidth()I

    move-result v13

    int-to-float v13, v13

    add-float/2addr v12, v13

    cmpg-float v10, v10, v12

    if-gez v10, :cond_d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getY()F

    move-result v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getY()F

    move-result v12

    invoke-virtual {v9}, Landroid/view/View;->getHeight()I

    move-result v9

    int-to-float v9, v9

    add-float/2addr v12, v9

    cmpg-float v9, v10, v12

    if-ltz v9, :cond_14

    :cond_d
    iget-object v9, v0, Lc/Q3;->D:Lc/b2;

    invoke-virtual {v9}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v10

    if-ne v10, v0, :cond_e

    invoke-virtual {v9}, Landroid/view/View;->getVisibility()I

    move-result v10

    if-nez v10, :cond_e

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getLeft()I

    move-result v12

    int-to-float v12, v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_e

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getRight()I

    move-result v12

    int-to-float v12, v12

    cmpg-float v10, v10, v12

    if-gez v10, :cond_e

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getTop()I

    move-result v12

    int-to-float v12, v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_e

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v9}, Landroid/view/View;->getBottom()I

    move-result v9

    int-to-float v9, v9

    cmpg-float v9, v10, v9

    if-ltz v9, :cond_14

    :cond_e
    invoke-virtual {v7, v8, v11}, Lc/e0;->g(FF)Z

    move-result v9

    if-nez v9, :cond_f

    goto/16 :goto_6

    :cond_f
    move v9, v2

    :goto_3
    iget-object v10, v7, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v10}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v12

    if-ge v9, v12, :cond_13

    invoke-virtual {v10, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v12

    instance-of v13, v12, Landroid/widget/FrameLayout;

    if-nez v13, :cond_10

    goto :goto_5

    :cond_10
    check-cast v12, Landroid/widget/FrameLayout;

    invoke-virtual {v10}, Landroid/view/View;->getX()F

    move-result v13

    sub-float v13, v8, v13

    invoke-virtual {v12}, Landroid/view/View;->getX()F

    move-result v14

    sub-float/2addr v13, v14

    invoke-virtual {v10}, Landroid/view/View;->getY()F

    move-result v10

    sub-float v10, v11, v10

    invoke-virtual {v12}, Landroid/view/View;->getY()F

    move-result v14

    sub-float/2addr v10, v14

    filled-new-array {v6, v5}, [I

    move-result-object v14

    move v15, v2

    :goto_4
    if-ge v15, v6, :cond_12

    aget v6, v14, v15

    invoke-virtual {v12, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v16

    if-nez v16, :cond_11

    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    move-result v2

    int-to-float v2, v2

    cmpl-float v2, v13, v2

    if-ltz v2, :cond_11

    invoke-virtual {v6}, Landroid/view/View;->getRight()I

    move-result v2

    int-to-float v2, v2

    cmpg-float v2, v13, v2

    if-gez v2, :cond_11

    invoke-virtual {v6}, Landroid/view/View;->getTop()I

    move-result v2

    int-to-float v2, v2

    cmpl-float v2, v10, v2

    if-ltz v2, :cond_11

    invoke-virtual {v6}, Landroid/view/View;->getBottom()I

    move-result v2

    int-to-float v2, v2

    cmpg-float v2, v10, v2

    if-gez v2, :cond_11

    goto :goto_7

    :cond_11
    add-int/lit8 v15, v15, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    goto :goto_4

    :cond_12
    :goto_5
    add-int/lit8 v9, v9, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    goto :goto_3

    :cond_13
    :goto_6
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    iget-object v9, v4, Lc/P3;->A:Lc/g1;

    invoke-virtual {v9, v2, v6}, Lc/g1;->f(FF)Z

    move-result v2

    if-nez v2, :cond_15

    invoke-virtual {v7, v8, v11}, Lc/e0;->g(FF)Z

    move-result v2

    if-eqz v2, :cond_15

    :cond_14
    :goto_7
    move v2, v3

    goto :goto_8

    :cond_15
    const/4 v2, 0x0

    :goto_8
    iput-boolean v2, v0, Lc/Q3;->P:Z

    :cond_16
    iget-boolean v2, v0, Lc/Q3;->P:Z

    if-eqz v2, :cond_19

    invoke-super/range {p0 .. p1}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v2

    if-eq v1, v3, :cond_17

    if-ne v1, v5, :cond_18

    :cond_17
    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/Q3;->P:Z

    :cond_18
    return v2

    :cond_19
    invoke-virtual/range {p0 .. p1}, Lc/F;->p(Landroid/view/MotionEvent;)V

    move-object/from16 v2, p1

    invoke-virtual {v4, v2}, Lc/P3;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    return v1

    :cond_1a
    move v1, v2

    move-object/from16 v2, p1

    iput-boolean v1, v0, Lc/Q3;->P:Z

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-nez v1, :cond_1d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v7

    iget-object v8, v0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0, v8, v6, v7}, Lc/Q3;->E(Lc/t2;FF)Z

    move-result v6

    if-nez v6, :cond_1c

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v7

    iget-object v8, v0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0, v8, v6, v7}, Lc/Q3;->E(Lc/t2;FF)Z

    move-result v6

    if-eqz v6, :cond_1b

    goto :goto_9

    :cond_1b
    const/4 v6, 0x0

    goto :goto_a

    :cond_1c
    :goto_9
    move v6, v3

    :goto_a
    iput-boolean v6, v0, Lc/Q3;->S:Z

    :cond_1d
    iget-boolean v6, v0, Lc/Q3;->S:Z

    if-eqz v6, :cond_20

    invoke-super/range {p0 .. p1}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v2

    if-eq v1, v3, :cond_1e

    if-ne v1, v5, :cond_1f

    :cond_1e
    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/Q3;->S:Z

    :cond_1f
    return v2

    :cond_20
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-nez v1, :cond_24

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    iget-object v1, v0, Lc/Q3;->K:Lc/o0;

    sget-object v5, Lc/s0;->j:Lc/s0;

    if-nez v1, :cond_21

    const/4 v1, 0x0

    goto :goto_b

    :cond_21
    iget-object v1, v1, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v1, v5}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/m0;

    :goto_b
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    iget-object v7, v0, Lc/Q3;->K:Lc/o0;

    if-eqz v7, :cond_23

    iget-boolean v8, v7, Lc/o0;->f:Z

    if-nez v8, :cond_22

    iget-boolean v7, v7, Lc/o0;->g:Z

    if-eqz v7, :cond_23

    :cond_22
    iget v4, v4, Lc/P3;->D:F

    goto :goto_c

    :cond_23
    const/4 v4, 0x0

    :goto_c
    add-float/2addr v6, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v7

    invoke-virtual {v0, v4, v7}, Lc/Q3;->C(FF)Z

    move-result v4

    if-nez v4, :cond_28

    if-eqz v1, :cond_28

    iget-object v4, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual {v4, v5}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v4

    if-eqz v4, :cond_28

    iget-object v4, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual {v4, v5}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v4

    iget-boolean v4, v4, Lc/r0;->g:Z

    if-nez v4, :cond_28

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual {v1, v4, v6}, Lc/m0;->a(FF)Z

    move-result v1

    if-eqz v1, :cond_28

    iput-boolean v3, v0, Lc/Q3;->O:Z

    iput-object v5, v0, Lc/Q3;->Q:Lc/s0;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iput v1, v0, Lc/Q3;->U:F

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v0, Lc/Q3;->V:F

    iget-object v1, v0, Lc/Q3;->W:Lc/t3;

    const-wide/16 v3, 0x1f4

    invoke-virtual {v0, v1, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_d

    :cond_24
    iget-boolean v1, v0, Lc/Q3;->O:Z

    if-eqz v1, :cond_25

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v4, 0x2

    if-ne v1, v4, :cond_25

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iget v4, v0, Lc/Q3;->U:F

    sub-float/2addr v1, v4

    float-to-double v6, v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v4, v0, Lc/Q3;->V:F

    sub-float/2addr v1, v4

    float-to-double v8, v1

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v1

    int-to-double v8, v1

    cmpl-double v1, v6, v8

    if-lez v1, :cond_25

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    goto :goto_d

    :cond_25
    iget-boolean v1, v0, Lc/Q3;->O:Z

    if-eqz v1, :cond_26

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v4, 0x5

    if-ne v1, v4, :cond_26

    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    goto :goto_d

    :cond_26
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-eq v1, v3, :cond_27

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    if-ne v1, v5, :cond_28

    :cond_27
    invoke-virtual/range {p0 .. p0}, Lc/Q3;->w()V

    :cond_28
    :goto_d
    invoke-super/range {p0 .. p1}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    return v1
.end method

.method public final drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .locals 1

    iget-object v0, p0, Lc/Q3;->R:Lc/p9;

    if-ne p2, v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-super {p0, p1, p2, p3, p4}, Lc/F;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    move-result p1

    return p1
.end method

.method public final e(FF)Z
    .locals 4

    invoke-super {p0, p1, p2}, Lc/F;->e(FF)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    int-to-float v2, v2

    sub-float v2, p1, v2

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v3

    int-to-float v3, v3

    sub-float v3, p2, v3

    invoke-virtual {v0, v2, v3}, Lc/t2;->n(FF)Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    int-to-float v2, v2

    sub-float v2, p1, v2

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v3

    int-to-float v3, v3

    sub-float v3, p2, v3

    invoke-virtual {v0, v2, v3}, Lc/t2;->n(FF)Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    invoke-virtual {p0, p1, p2}, Lc/Q3;->C(FF)Z

    move-result p1

    if-eqz p1, :cond_3

    :cond_2
    const/4 v1, 0x1

    :cond_3
    return v1
.end method

.method public final f()Z
    .locals 1

    invoke-super {p0}, Lc/F;->f()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    const/4 v0, -0x1

    iput v0, p0, Lc/Q3;->N:I

    iput v0, p0, Lc/Q3;->M:I

    iget-object v0, p0, Lc/Q3;->L:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v0, 0x1

    return v0
.end method

.method public final g()Lc/Q1;
    .locals 1

    iget-object v0, p0, Lc/Q3;->J:Lc/u0;

    if-nez v0, :cond_0

    sget-object v0, Lc/Q1;->a:Lc/Q1;

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q1;

    :goto_0
    return-object v0
.end method

.method public final i(Lc/t2;)Z
    .locals 2

    invoke-super {p0, p1}, Lc/F;->i(Lc/t2;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v0, v0, Lc/P3;->i:Lc/S;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/S;->b(Z)V

    :cond_0
    return p1
.end method

.method public final o(Z)V
    .locals 1

    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0}, Lc/P3;->p()V

    iput-boolean p1, v0, Lc/P3;->d:Z

    invoke-virtual {p0}, Lc/Q3;->W()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 2

    invoke-super {p0}, Lc/F;->onAttachedToWindow()V

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    sget-object v1, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object v1, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v1, v0}, Lc/P3;->f0(Z)V

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/Q3;->T:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lc/Q3;->A()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lc/Q3;->w:Lc/e0;

    invoke-virtual {v1, v0}, Lc/e0;->q(Z)V

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 2

    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0}, Lc/P3;->p()V

    invoke-virtual {p0}, Lc/Q3;->w()V

    iget-object v0, p0, Lc/Q3;->w:Lc/e0;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/e0;->q(Z)V

    invoke-super {p0}, Lc/F;->onDetachedFromWindow()V

    return-void
.end method

.method public final onLayout(ZIIII)V
    .locals 9

    iget-object p1, p0, Lc/Q3;->D:Lc/b2;

    invoke-virtual {p0, p1}, Lc/F;->m(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sub-int/2addr p4, p2

    sub-int/2addr p5, p3

    iget-object p2, p0, Lc/Q3;->t:Lc/P3;

    const/4 p3, 0x0

    invoke-virtual {p2, p3, p3, p4, p5}, Landroid/view/View;->layout(IIII)V

    iget-object v0, p2, Lc/P3;->i:Lc/S;

    invoke-virtual {v0, p3, p3, p4, p5}, Landroid/view/View;->layout(IIII)V

    iget-object v0, p0, Lc/Q3;->R:Lc/p9;

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v0, v1}, Lc/p9;->b(F)I

    move-result v2

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v4

    sub-int v5, p4, v3

    mul-int/lit8 v6, v2, 0x2

    sub-int/2addr v5, v6

    invoke-static {p3, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-float v5, v5

    iget v7, v0, Lc/p9;->a:F

    mul-float/2addr v5, v7

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    add-int/2addr v5, v2

    sub-int/2addr p5, v4

    sub-int/2addr p5, v6

    invoke-static {p3, p5}, Ljava/lang/Math;->max(II)I

    move-result p5

    int-to-float p5, p5

    iget v6, v0, Lc/p9;->b:F

    mul-float/2addr p5, v6

    invoke-static {p5}, Ljava/lang/Math;->round(F)I

    move-result p5

    add-int/2addr p5, v2

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->setTranslationX(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setTranslationY(F)V

    add-int/2addr v3, v5

    add-int/2addr v4, p5

    invoke-virtual {v0, v5, p5, v3, v4}, Landroid/view/View;->layout(IIII)V

    iget-object p5, p0, Lc/Q3;->B:Lc/E8;

    invoke-virtual {p5}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    sub-int/2addr p4, v2

    div-int/lit8 p4, p4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v1}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {p5}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    add-int/2addr v2, p4

    invoke-virtual {p5}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    add-int/2addr v3, v1

    invoke-virtual {p5, p4, v1, v2, v3}, Landroid/view/View;->layout(IIII)V

    iget-object p4, p0, Lc/Q3;->K:Lc/o0;

    if-nez p4, :cond_1

    return-void

    :cond_1
    iget-object v1, p0, Lc/Q3;->x:Landroid/widget/FrameLayout;

    iget-object p4, p4, Lc/o0;->c:Lc/m0;

    invoke-static {v1, p4}, Lc/Q3;->F(Landroid/view/View;Lc/m0;)V

    invoke-virtual {p0}, Lc/Q3;->T()V

    iget-object p4, p0, Lc/Q3;->J:Lc/u0;

    sget-object v1, Lc/s0;->i:Lc/s0;

    invoke-virtual {p4, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object p4

    const/4 v1, 0x1

    if-eqz p4, :cond_2

    iget-boolean v2, p4, Lc/r0;->g:Z

    if-nez v2, :cond_2

    move p3, v1

    :cond_2
    iget-object v2, p0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v2, p3}, Lc/t2;->c0(Z)V

    if-eqz p4, :cond_5

    iget-boolean p3, p4, Lc/r0;->g:Z

    if-nez p3, :cond_5

    iget-object p3, p0, Lc/Q3;->K:Lc/o0;

    iget-object p4, p3, Lc/o0;->b:Lc/m0;

    iget-boolean v3, p3, Lc/o0;->f:Z

    if-nez v3, :cond_3

    iget-boolean p3, p3, Lc/o0;->g:Z

    if-eqz p3, :cond_4

    :cond_3
    new-instance p3, Lc/m0;

    iget v3, p4, Lc/m0;->a:F

    iget v4, p2, Lc/P3;->D:F

    iget v5, p4, Lc/m0;->b:F

    sub-float/2addr v5, v4

    iget v6, p4, Lc/m0;->d:F

    sub-float/2addr v6, v4

    iget p4, p4, Lc/m0;->c:F

    invoke-direct {p3, v3, v5, p4, v6}, Lc/m0;-><init>(FFFF)V

    move-object p4, p3

    :cond_4
    invoke-virtual {p0, p4, v1}, Lc/Q3;->U(Lc/m0;Z)V

    :cond_5
    iget-object p3, p0, Lc/Q3;->K:Lc/o0;

    iget-object p3, p3, Lc/o0;->a:Lc/m0;

    iget p3, p3, Lc/m0;->a:F

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget-object p3, p0, Lc/Q3;->K:Lc/o0;

    iget-object p3, p3, Lc/o0;->a:Lc/m0;

    iget p3, p3, Lc/m0;->b:F

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result v6

    iget-object p3, p0, Lc/Q3;->K:Lc/o0;

    iget-object p3, p3, Lc/o0;->a:Lc/m0;

    iget p3, p3, Lc/m0;->a:F

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    iget-object p4, p0, Lc/Q3;->K:Lc/o0;

    iget-object p4, p4, Lc/o0;->a:Lc/m0;

    invoke-virtual {p4}, Lc/m0;->d()F

    move-result p4

    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    move-result p4

    add-int v7, p4, p3

    iget-object p3, p0, Lc/Q3;->K:Lc/o0;

    iget-object p3, p3, Lc/o0;->a:Lc/m0;

    iget p3, p3, Lc/m0;->b:F

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    iget-object p4, p0, Lc/Q3;->K:Lc/o0;

    iget-object p4, p4, Lc/o0;->a:Lc/m0;

    invoke-virtual {p4}, Lc/m0;->b()F

    move-result p4

    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    move-result p4

    add-int v8, p4, p3

    iget-object v4, p0, Lc/Q3;->D:Lc/b2;

    move-object v3, p0

    invoke-virtual/range {v3 .. v8}, Lc/F;->l(Landroid/view/View;IIII)V

    invoke-virtual {p0, v1}, Lc/Q3;->V(Z)V

    invoke-virtual {p0}, Lc/Q3;->J()V

    invoke-virtual {v2}, Landroid/view/View;->bringToFront()V

    iget-object p3, p0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {p3}, Landroid/view/View;->bringToFront()V

    invoke-virtual {p0}, Lc/Q3;->W()V

    iget-object p3, p0, Lc/Q3;->C:Landroid/view/View;

    invoke-virtual {p3}, Landroid/view/View;->bringToFront()V

    iget-object p3, p0, Lc/Q3;->A:Landroid/view/View;

    invoke-virtual {p3}, Landroid/view/View;->bringToFront()V

    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    iget-object p1, p2, Lc/P3;->K:Lc/a5;

    if-eqz p1, :cond_6

    iget p3, p1, Lc/a5;->w:I

    iget p4, p1, Lc/a5;->x:I

    iget v1, p1, Lc/a5;->y:I

    add-int/2addr v1, p3

    iget v2, p1, Lc/a5;->u:I

    add-int/2addr v2, p4

    invoke-virtual {p1, p3, p4, v1, v2}, Landroid/view/View;->layout(IIII)V

    iget-object p1, p2, Lc/P3;->K:Lc/a5;

    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    :cond_6
    invoke-virtual {p5}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    return-void
.end method

.method public final onMeasure(II)V
    .locals 32

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/Q3;->D:Lc/b2;

    move/from16 v2, p1

    move/from16 v3, p2

    invoke-virtual {v0, v2, v3, v1}, Lc/F;->n(IILandroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-void

    :cond_0
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v3

    invoke-static {v2, v3}, Lc/G8;->M(II)Z

    move-result v4

    iget-boolean v5, v0, Lc/Q3;->b0:Z

    iget-object v12, v0, Lc/Q3;->F:Lc/n1;

    if-eq v5, v4, :cond_1

    iput-boolean v4, v0, Lc/Q3;->b0:Z

    invoke-virtual {v12, v4}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v5

    iput-object v5, v0, Lc/Q3;->J:Lc/u0;

    :cond_1
    iget-object v5, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual {v12}, Lc/n1;->V()I

    move-result v6

    invoke-virtual {v12, v5, v4, v6}, Lc/n1;->c(Lc/u0;ZI)Lc/u0;

    move-result-object v4

    if-eqz v4, :cond_2

    iput-object v4, v0, Lc/Q3;->J:Lc/u0;

    :cond_2
    invoke-virtual {v0, v2, v3}, Landroid/view/View;->setMeasuredDimension(II)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const/high16 v5, 0x435c0000    # 220.0f

    invoke-static {v4, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/high16 v13, 0x40000000    # 2.0f

    invoke-static {v4, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/high16 v6, 0x42800000    # 64.0f

    invoke-static {v5, v6}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v5

    invoke-static {v5, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    iget-object v6, v0, Lc/Q3;->R:Lc/p9;

    invoke-virtual {v6, v4, v5}, Landroid/view/View;->measure(II)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    sget v5, Lc/E8;->h:I

    const/high16 v5, 0x44070000    # 540.0f

    invoke-static {v4, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v5

    const/high16 v6, 0x42000000    # 32.0f

    invoke-static {v4, v6}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    sub-int v4, v2, v4

    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v14, 0x1

    invoke-static {v14, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/high16 v5, -0x80000000

    invoke-static {v4, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/high16 v6, 0x42900000    # 72.0f

    invoke-static {v5, v6}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v5, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    iget-object v6, v0, Lc/Q3;->B:Lc/E8;

    invoke-virtual {v6, v4, v5}, Landroid/view/View;->measure(II)V

    invoke-static {v2, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-static {v3, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    iget-object v15, v0, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v15, v4, v5}, Landroid/view/View;->measure(II)V

    invoke-static {v2, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-static {v3, v13}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    iget-object v6, v15, Lc/P3;->i:Lc/S;

    invoke-virtual {v6, v4, v5}, Landroid/view/View;->measure(II)V

    iget-object v4, v15, Lc/P3;->A:Lc/g1;

    iget-boolean v4, v4, Lc/g1;->J:Z

    iget-object v5, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-static {v6, v11}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    iget v9, v6, Landroid/util/DisplayMetrics;->density:F

    iget-boolean v10, v0, Lc/F;->a:Z

    invoke-virtual {v12}, Lc/n1;->C()I

    invoke-virtual {v12}, Lc/n1;->B()I

    invoke-virtual {v12}, Lc/n1;->f0()Z

    move-result v16

    move v6, v2

    move v7, v3

    move v13, v11

    move/from16 v11, v16

    invoke-static/range {v5 .. v11}, Lc/G8;->k(Lc/u0;IIFFZZ)Lc/o0;

    move-result-object v5

    iput-object v5, v0, Lc/Q3;->K:Lc/o0;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ":"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, v0, Lc/Q3;->K:Lc/o0;

    iget-object v7, v7, Lc/o0;->c:Lc/m0;

    invoke-virtual {v7}, Lc/m0;->d()F

    move-result v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, v0, Lc/Q3;->K:Lc/o0;

    iget-object v7, v7, Lc/o0;->c:Lc/m0;

    invoke-virtual {v7}, Lc/m0;->b()F

    move-result v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-static {v7, v13}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v0, Lc/Q3;->K:Lc/o0;

    iget-boolean v6, v6, Lc/o0;->f:Z

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Lc/Q3;->a0:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    iput-object v5, v0, Lc/Q3;->a0:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->c:Lc/m0;

    invoke-virtual {v5}, Lc/m0;->d()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v21

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->c:Lc/m0;

    invoke-virtual {v5}, Lc/m0;->b()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5, v13}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v25

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-boolean v5, v5, Lc/o0;->f:Z

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v27

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->b:Lc/m0;

    invoke-virtual {v5}, Lc/m0;->d()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v29

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->b:Lc/m0;

    invoke-virtual {v5}, Lc/m0;->b()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v31

    const-string v28, "navigation_width"

    const-string v30, "navigation_height"

    const-string v16, "viewport_width"

    const-string v18, "viewport_height"

    const-string v20, "widgets_width"

    const-string v22, "widgets_height"

    const-string v24, "unit_px"

    const-string v26, "narrow"

    filled-new-array/range {v16 .. v31}, [Ljava/lang/Object;

    move-result-object v5

    const-string v6, "dashboard_geometry"

    invoke-static {v6, v5}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_3
    if-nez v4, :cond_5

    iget-boolean v4, v0, Lc/F;->a:Z

    if-nez v4, :cond_4

    invoke-virtual {v12}, Lc/n1;->f0()Z

    move-result v4

    if-eqz v4, :cond_5

    :cond_4
    iget-object v5, v0, Lc/Q3;->J:Lc/u0;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-static {v4, v13}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v9, v4, Landroid/util/DisplayMetrics;->density:F

    invoke-virtual {v12}, Lc/n1;->C()I

    invoke-virtual {v12}, Lc/n1;->B()I

    const/4 v11, 0x0

    const/4 v10, 0x0

    move v6, v2

    move v7, v3

    invoke-static/range {v5 .. v11}, Lc/G8;->k(Lc/u0;IIFFZZ)Lc/o0;

    move-result-object v4

    sget-object v5, Lc/s0;->l:Lc/s0;

    iget-object v4, v4, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v4, v5}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/m0;

    goto :goto_0

    :cond_5
    const/4 v4, 0x0

    :goto_0
    iget-object v5, v0, Lc/Q3;->J:Lc/u0;

    iget-object v6, v0, Lc/Q3;->K:Lc/o0;

    invoke-virtual {v15, v5, v6, v4}, Lc/P3;->g0(Lc/u0;Lc/o0;Lc/m0;)V

    iget-object v4, v0, Lc/Q3;->x:Landroid/widget/FrameLayout;

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->c:Lc/m0;

    invoke-virtual {v5}, Lc/m0;->d()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v14, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    const/high16 v6, 0x40000000    # 2.0f

    invoke-static {v5, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    iget-object v7, v0, Lc/Q3;->K:Lc/o0;

    iget-object v7, v7, Lc/o0;->c:Lc/m0;

    invoke-virtual {v7}, Lc/m0;->b()F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-static {v14, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-static {v7, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    invoke-virtual {v4, v5, v7}, Landroid/view/View;->measure(II)V

    iget-object v4, v0, Lc/Q3;->J:Lc/u0;

    sget-object v5, Lc/s0;->i:Lc/s0;

    invoke-virtual {v4, v5}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v4

    const/4 v5, 0x0

    if-eqz v4, :cond_6

    iget-boolean v4, v4, Lc/r0;->g:Z

    if-nez v4, :cond_6

    move v4, v14

    goto :goto_1

    :cond_6
    move v4, v5

    :goto_1
    iget-object v6, v0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v6, v4}, Lc/t2;->c0(Z)V

    const/4 v7, 0x2

    if-eqz v4, :cond_7

    iget-object v4, v0, Lc/Q3;->K:Lc/o0;

    iget-object v4, v4, Lc/o0;->b:Lc/m0;

    invoke-virtual {v4}, Lc/m0;->d()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/high16 v8, 0x40000000    # 2.0f

    invoke-static {v4, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    iget-object v9, v0, Lc/Q3;->K:Lc/o0;

    iget-object v9, v9, Lc/o0;->b:Lc/m0;

    invoke-virtual {v9}, Lc/m0;->b()F

    move-result v9

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-static {v7, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-static {v9, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    invoke-virtual {v6, v4, v9}, Landroid/view/View;->measure(II)V

    :cond_7
    iget-object v4, v0, Lc/Q3;->J:Lc/u0;

    sget-object v6, Lc/s0;->m:Lc/s0;

    invoke-virtual {v4, v6}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v4

    if-eqz v4, :cond_8

    iget-boolean v4, v4, Lc/r0;->g:Z

    if-nez v4, :cond_8

    move v5, v14

    :cond_8
    iget-object v4, v0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v4, v5}, Lc/t2;->c0(Z)V

    if-eqz v5, :cond_9

    iget-object v5, v0, Lc/Q3;->K:Lc/o0;

    iget-object v5, v5, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v5, v6}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/m0;

    if-eqz v5, :cond_9

    invoke-virtual {v5}, Lc/m0;->d()F

    move-result v6

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v7, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    const/high16 v8, 0x40000000    # 2.0f

    invoke-static {v6, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-virtual {v5}, Lc/m0;->b()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v5, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v4, v6, v5}, Landroid/view/View;->measure(II)V

    :cond_9
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    if-eq v4, v0, :cond_a

    iget-boolean v4, v0, Lc/Q3;->T:Z

    if-eqz v4, :cond_b

    :cond_a
    iget-object v4, v0, Lc/F;->l:Landroid/view/View;

    check-cast v4, Lc/b2;

    invoke-static {v2, v3}, Lc/G8;->M(II)Z

    move-result v5

    invoke-virtual {v4, v5}, Lc/b2;->E(Z)V

    :cond_b
    iget-object v4, v15, Lc/P3;->K:Lc/a5;

    if-eqz v4, :cond_e

    iget v5, v4, Lc/a5;->p:I

    if-ne v5, v2, :cond_d

    iget v2, v4, Lc/a5;->q:I

    if-eq v2, v3, :cond_c

    goto :goto_2

    :cond_c
    iget v2, v4, Lc/a5;->y:I

    const/high16 v3, 0x40000000    # 2.0f

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    iget-object v5, v15, Lc/P3;->K:Lc/a5;

    iget v5, v5, Lc/a5;->u:I

    invoke-static {v5, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v4, v2, v5}, Landroid/view/View;->measure(II)V

    goto :goto_3

    :cond_d
    :goto_2
    invoke-virtual {v15}, Lc/P3;->p()V

    :cond_e
    :goto_3
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-ne v2, v0, :cond_f

    iget-object v2, v0, Lc/Q3;->K:Lc/o0;

    iget-object v2, v2, Lc/o0;->a:Lc/m0;

    invoke-virtual {v2}, Lc/m0;->d()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {v14, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/high16 v3, 0x40000000    # 2.0f

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    iget-object v4, v0, Lc/Q3;->K:Lc/o0;

    iget-object v4, v4, Lc/o0;->a:Lc/m0;

    invoke-virtual {v4}, Lc/m0;->b()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-static {v14, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static {v4, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/view/View;->measure(II)V

    :cond_f
    return-void
.end method

.method public final onVisibilityChanged(Landroid/view/View;I)V
    .locals 1

    invoke-super {p0, p1, p2}, Lc/F;->onVisibilityChanged(Landroid/view/View;I)V

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result p1

    iget-object p2, p0, Lc/Q3;->t:Lc/P3;

    if-nez p1, :cond_0

    sget-object p1, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {p2}, Lc/P3;->p()V

    invoke-virtual {p0}, Lc/Q3;->w()V

    invoke-virtual {p0}, Lc/Q3;->B()V

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result p1

    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {p2, p1}, Lc/P3;->f0(Z)V

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result p1

    if-eqz p1, :cond_1

    iget-boolean p1, p0, Lc/Q3;->T:Z

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lc/Q3;->A()Z

    move-result p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    iget-object p2, p0, Lc/Q3;->w:Lc/e0;

    invoke-virtual {p2, p1}, Lc/e0;->q(Z)V

    return-void
.end method

.method public final r(Z)V
    .locals 1

    invoke-super {p0, p1}, Lc/F;->r(Z)V

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    if-eqz p1, :cond_0

    iget-object p1, v0, Lc/P3;->i:Lc/S;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lc/S;->b(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_0
    return-void
.end method

.method public final u(Landroid/view/View;)V
    .locals 4

    invoke-super {p0, p1}, Lc/F;->u(Landroid/view/View;)V

    iget-object p1, p0, Lc/F;->l:Landroid/view/View;

    check-cast p1, Lc/b2;

    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lc/z3;

    const/4 v3, 0x0

    invoke-direct {v2, v1, v3}, Lc/z3;-><init>(Lc/g1;I)V

    iget-object v0, v0, Lc/P3;->A:Lc/g1;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lc/z3;

    const/4 v3, 0x1

    invoke-direct {v1, v0, v3}, Lc/z3;-><init>(Lc/g1;I)V

    iput-object v2, p1, Lc/b2;->E:Ljava/lang/Runnable;

    iput-object v1, p1, Lc/b2;->F:Ljava/lang/Runnable;

    iget-object p1, p0, Lc/F;->l:Landroid/view/View;

    check-cast p1, Lc/b2;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lc/b2;->F(Z)V

    return-void
.end method

.method public final w()V
    .locals 1

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/Q3;->O:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/Q3;->Q:Lc/s0;

    iget-object v0, p0, Lc/Q3;->W:Lc/t3;

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final x(Lc/m0;)V
    .locals 9

    iget-object v0, p0, Lc/Q3;->K:Lc/o0;

    iget-object v1, p0, Lc/Q3;->y:Lc/t2;

    if-eqz v0, :cond_1

    iget-boolean v2, v0, Lc/o0;->f:Z

    if-nez v2, :cond_0

    iget-boolean v2, v0, Lc/o0;->g:Z

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/o0;->c:Lc/m0;

    invoke-virtual {p1}, Lc/m0;->d()F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p1}, Lc/m0;->b()F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    iget v5, v0, Lc/m0;->a:F

    iget v6, p1, Lc/m0;->a:F

    sub-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v2, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iget v7, v0, Lc/m0;->b:F

    iget p1, p1, Lc/m0;->b:F

    sub-float/2addr v7, p1

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-static {v4, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-static {v3, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget v8, v0, Lc/m0;->c:F

    sub-float/2addr v8, v6

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v2, v6}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget v0, v0, Lc/m0;->d:F

    sub-float/2addr v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {v4, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {v3, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    new-instance v0, Landroid/graphics/Rect;

    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v7, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-direct {v0, v5, v7, v2, p1}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v1, v0}, Landroid/view/View;->setClipBounds(Landroid/graphics/Rect;)V

    return-void

    :cond_1
    :goto_0
    const/4 p1, 0x0

    invoke-virtual {v1, p1}, Landroid/view/View;->setClipBounds(Landroid/graphics/Rect;)V

    return-void
.end method

.method public final y(Ljava/lang/String;)Z
    .locals 2

    invoke-virtual {p0}, Lc/F;->k()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Lc/Q3;->H(Ljava/lang/String;)Lc/t2;

    move-result-object p1

    invoke-virtual {p0, p1}, Lc/Q3;->i(Lc/t2;)Z

    move-result p1

    return p1

    :cond_0
    iget-object v0, p0, Lc/Q3;->t:Lc/P3;

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v1}, Lc/g1;->c()Z

    invoke-virtual {v0}, Lc/P3;->p()V

    invoke-virtual {p0}, Lc/Q3;->w()V

    invoke-virtual {p0, p1}, Lc/Q3;->H(Ljava/lang/String;)Lc/t2;

    move-result-object p1

    invoke-virtual {p0, p1}, Lc/Q3;->i(Lc/t2;)Z

    move-result p1

    return p1
.end method

.method public final z()Ljava/lang/String;
    .locals 7

    iget-object v0, p0, Lc/Q3;->F:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v3, v0}, Lc/Q3;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-object v1

    :cond_0
    const-string v1, "com.google.android.apps.maps"

    const-string v4, "ru.dublgis.dgismobile"

    const-string v5, "ru.yandex.yandexnavi"

    const-string v6, "ru.yandex.yandexmaps"

    filled-new-array {v5, v6, v1, v4}, [Ljava/lang/String;

    move-result-object v1

    :goto_0
    const/4 v4, 0x4

    if-ge v2, v4, :cond_2

    aget-object v4, v1, v2

    invoke-virtual {p0, v4, v3, v0}, Lc/Q3;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    return-object v4

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    iget-object v1, p0, Lc/Q3;->E:Lc/z;

    invoke-virtual {v1}, Lc/z;->c()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/a;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    iget-object v5, v2, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3

    iget-object v2, v2, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {p0, v2, v3, v0}, Lc/Q3;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    return-object v2

    :cond_4
    const-string v0, ""

    return-object v0
.end method
