.class public final synthetic Lc/I4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/I4;->a:I

    iput-object p1, p0, Lc/I4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lc/I4;->b:Lru/drivedeck/launcher/MainActivity;

    iget v1, p0, Lc/I4;->a:I

    packed-switch v1, :pswitch_data_0

    invoke-static {v0}, Lru/drivedeck/launcher/MainActivity;->a(Lru/drivedeck/launcher/MainActivity;)V

    return-void

    :pswitch_0
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->j()V

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->l()V

    return-void

    :pswitch_1
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->C(Z)V

    return-void

    :pswitch_2
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->h()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
