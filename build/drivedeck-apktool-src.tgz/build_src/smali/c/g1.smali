.class public final Lc/g1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final A:Landroid/graphics/RectF;

.field public final B:Landroid/graphics/RectF;

.field public C:Lc/u0;

.field public D:Lc/u0;

.field public E:Lc/r0;

.field public F:Lc/o0;

.field public G:Landroid/graphics/Rect;

.field public H:Lc/s0;

.field public I:Z

.field public J:Z

.field public K:Z

.field public L:Z

.field public M:Z

.field public N:I

.field public O:I

.field public P:F

.field public Q:F

.field public R:F

.field public S:F

.field public T:F

.field public U:Ljava/lang/String;

.field public final V:[[B

.field public W:Landroid/app/AlertDialog;

.field public final X:Lc/e1;

.field public Y:Z

.field public Z:Lc/u0;

.field public final a:Lc/P3;

.field public final a0:Landroid/util/SparseArray;

.field public final b:Lc/n1;

.field public final c:Lc/F3;

.field public final d:Lc/F3;

.field public e:Ljava/lang/Runnable;

.field public f:Ljava/lang/Runnable;

.field public g:Ljava/lang/Runnable;

.field public h:Ljava/lang/Runnable;

.field public i:Ljava/lang/Runnable;

.field public j:Ljava/util/function/Consumer;

.field public final k:Lc/M3;

.field public final l:Landroid/graphics/Paint;

.field public final m:Landroid/graphics/DashPathEffect;

.field public final n:Ljava/util/EnumMap;

.field public final o:Ljava/util/EnumMap;

.field public final p:Ljava/util/EnumMap;

.field public final q:Ljava/util/EnumMap;

.field public final r:Landroid/graphics/RectF;

.field public final s:Landroid/graphics/RectF;

.field public final t:Landroid/graphics/RectF;

.field public final u:Landroid/graphics/RectF;

.field public final v:Landroid/graphics/RectF;

.field public final w:Landroid/graphics/RectF;

.field public final x:Landroid/graphics/RectF;

.field public final y:Landroid/graphics/RectF;

.field public final z:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Lc/P3;Lc/n1;Lc/F3;Lc/M3;Lc/F3;)V
    .locals 6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v2, Lc/a1;

    invoke-direct {v2, v1}, Lc/a1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->e:Ljava/lang/Runnable;

    new-instance v2, Lc/a1;

    invoke-direct {v2, v1}, Lc/a1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->f:Ljava/lang/Runnable;

    new-instance v2, Lc/a1;

    invoke-direct {v2, v1}, Lc/a1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->g:Ljava/lang/Runnable;

    new-instance v2, Lc/a1;

    invoke-direct {v2, v1}, Lc/a1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->h:Ljava/lang/Runnable;

    new-instance v2, Lc/a1;

    invoke-direct {v2, v1}, Lc/a1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->i:Ljava/lang/Runnable;

    new-instance v2, Lc/b1;

    invoke-direct {v2, v1}, Lc/b1;-><init>(I)V

    iput-object v2, p0, Lc/g1;->j:Ljava/util/function/Consumer;

    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lc/g1;->l:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/DashPathEffect;

    new-array v4, v0, [F

    fill-array-data v4, :array_0

    const/4 v5, 0x0

    invoke-direct {v2, v4, v5}, Landroid/graphics/DashPathEffect;-><init>([FF)V

    iput-object v2, p0, Lc/g1;->m:Landroid/graphics/DashPathEffect;

    new-instance v2, Ljava/util/EnumMap;

    const-class v4, Lc/s0;

    invoke-direct {v2, v4}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v2, p0, Lc/g1;->n:Ljava/util/EnumMap;

    new-instance v2, Ljava/util/EnumMap;

    invoke-direct {v2, v4}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v2, p0, Lc/g1;->o:Ljava/util/EnumMap;

    new-instance v2, Ljava/util/EnumMap;

    invoke-direct {v2, v4}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v2, p0, Lc/g1;->p:Ljava/util/EnumMap;

    new-instance v2, Ljava/util/EnumMap;

    invoke-direct {v2, v4}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v2, p0, Lc/g1;->q:Ljava/util/EnumMap;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->r:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->s:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->t:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->u:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->v:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->w:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->x:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->y:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->z:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->A:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/g1;->B:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    iput-object v2, p0, Lc/g1;->G:Landroid/graphics/Rect;

    iput v1, p0, Lc/g1;->N:I

    const-string v2, ""

    iput-object v2, p0, Lc/g1;->U:Ljava/lang/String;

    new-array v0, v0, [I

    const/16 v2, 0x49

    aput v2, v0, v3

    const/16 v2, 0x1f

    aput v2, v0, v1

    sget-object v2, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    invoke-static {v2, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[B

    iput-object v0, p0, Lc/g1;->V:[[B

    new-instance v0, Lc/e1;

    invoke-direct {v0, p0, v1}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/g1;->X:Lc/e1;

    iput-boolean v3, p0, Lc/g1;->Y:Z

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lc/g1;->a0:Landroid/util/SparseArray;

    iput-object p1, p0, Lc/g1;->a:Lc/P3;

    iput-object p2, p0, Lc/g1;->b:Lc/n1;

    iput-object p3, p0, Lc/g1;->c:Lc/F3;

    iput-object p4, p0, Lc/g1;->k:Lc/M3;

    iput-object p5, p0, Lc/g1;->d:Lc/F3;

    return-void

    nop

    :array_0
    .array-data 4
        0x41000000    # 8.0f
        0x40c00000    # 6.0f
    .end array-data
.end method


# virtual methods
.method public final a(Lc/s0;FF)V
    .locals 2

    iget-boolean v0, p0, Lc/g1;->Y:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/g1;->F:Lc/o0;

    if-eqz v0, :cond_2

    if-eqz p1, :cond_0

    iget-object v0, v0, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/g1;->J:Z

    iget-object v1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    iput-object p1, p0, Lc/g1;->H:Lc/s0;

    invoke-virtual {p0}, Lc/g1;->z()V

    invoke-virtual {p0}, Lc/g1;->o()V

    if-nez p1, :cond_1

    const/4 p1, 0x5

    goto :goto_0

    :cond_1
    move p1, v0

    :goto_0
    invoke-virtual {p0, p1, p2, p3}, Lc/g1;->v(IFF)V

    invoke-virtual {p0, v0}, Lc/g1;->m(Z)V

    :cond_2
    :goto_1
    return-void
.end method

.method public final b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Ljava/lang/String;ILc/r4;)V
    .locals 7

    iget-object v0, p0, Lc/g1;->l:Landroid/graphics/Paint;

    iget v1, p5, Lc/r4;->c:I

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v1

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v3

    div-float/2addr v3, v2

    invoke-virtual {p1, p2, v1, v3, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    sget-object v1, Lc/r4;->p:Lc/r4;

    if-eq p5, v1, :cond_0

    iget v1, p5, Lc/r4;->h:I

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2, v1, v3}, Lc/g1;->w(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V

    :cond_0
    new-instance v1, Landroid/graphics/RectF;

    iget v3, p2, Landroid/graphics/RectF;->left:F

    const/high16 v4, 0x41000000    # 8.0f

    invoke-virtual {p0, v4}, Lc/g1;->h(F)F

    move-result v4

    add-float/2addr v4, v3

    iget v3, p2, Landroid/graphics/RectF;->top:F

    iget v5, p2, Landroid/graphics/RectF;->left:F

    const/high16 v6, 0x42100000    # 36.0f

    invoke-virtual {p0, v6}, Lc/g1;->h(F)F

    move-result v6

    add-float/2addr v6, v5

    iget v5, p2, Landroid/graphics/RectF;->bottom:F

    invoke-direct {v1, v4, v3, v6, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget p5, p5, Lc/r4;->d:I

    invoke-virtual {p0, p1, p4, v1, p5}, Lc/g1;->l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 p4, 0x41800000    # 16.0f

    invoke-virtual {p0, p4}, Lc/g1;->h(F)F

    move-result p4

    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object p4, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    iget-object p4, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {p4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p4

    invoke-static {p4, p3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    new-instance p4, Landroid/text/TextPaint;

    invoke-direct {p4, v0}, Landroid/text/TextPaint;-><init>(Landroid/graphics/Paint;)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result p5

    const/high16 v1, 0x42800000    # 64.0f

    invoke-virtual {p0, v1}, Lc/g1;->h(F)F

    move-result v1

    sub-float/2addr p5, v1

    const/4 v1, 0x0

    invoke-static {v1, p5}, Ljava/lang/Math;->max(FF)F

    move-result p5

    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {p3, p4, p5, v1}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object p3

    invoke-interface {p3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p3

    iget p4, p2, Landroid/graphics/RectF;->left:F

    const/high16 p5, 0x42200000    # 40.0f

    invoke-virtual {p0, p5}, Lc/g1;->h(F)F

    move-result p5

    add-float/2addr p5, p4

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerY()F

    move-result p2

    invoke-virtual {v0}, Landroid/graphics/Paint;->ascent()F

    move-result p4

    invoke-virtual {v0}, Landroid/graphics/Paint;->descent()F

    move-result v1

    add-float/2addr v1, p4

    div-float/2addr v1, v2

    sub-float/2addr p2, v1

    invoke-virtual {p1, p3, p5, p2, v0}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final c()Z
    .locals 2

    iget-boolean v0, p0, Lc/g1;->J:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Lc/g1;->J:Z

    iget-object v1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    invoke-virtual {p0}, Lc/g1;->r()V

    iget-object v1, p0, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->r:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->s:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->t:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->u:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->v:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->z:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->w:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->x:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->W:Landroid/app/AlertDialog;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/app/Dialog;->dismiss()V

    const/4 v1, 0x0

    iput-object v1, p0, Lc/g1;->W:Landroid/app/AlertDialog;

    :cond_0
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Lc/g1;->m(Z)V

    return v0
.end method

.method public final d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;)V
    .locals 2

    iget-object v0, p0, Lc/g1;->l:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget p3, p3, Lc/r4;->d:I

    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result p3

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerY()F

    move-result p2

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {p0, v1}, Lc/g1;->h(F)F

    move-result v1

    invoke-virtual {p1, p3, p2, v1, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final e(Lc/r0;)Z
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v0, Lc/g1;->J:Z

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    iget-object v2, v1, Lc/r0;->a:Lc/s0;

    iget-object v6, v0, Lc/g1;->H:Lc/s0;

    if-ne v2, v6, :cond_1

    iget v2, v0, Lc/g1;->N:I

    if-eq v2, v5, :cond_0

    if-ne v2, v3, :cond_1

    :cond_0
    move v2, v5

    goto :goto_0

    :cond_1
    move v2, v4

    :goto_0
    iget-object v6, v0, Lc/g1;->V:[[B

    if-eqz v2, :cond_3

    iget v7, v1, Lc/r0;->e:I

    aget-object v7, v6, v7

    iget v8, v1, Lc/r0;->f:I

    aget-byte v7, v7, v8

    if-eqz v7, :cond_3

    if-ne v7, v5, :cond_2

    move v4, v5

    :cond_2
    return v4

    :cond_3
    iget-object v7, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v8, v7, Lc/o0;->f:Z

    const/high16 v9, 0x3f800000    # 1.0f

    if-eqz v8, :cond_4

    new-instance v8, Lc/m0;

    iget-object v7, v7, Lc/o0;->c:Lc/m0;

    invoke-virtual {v7}, Lc/m0;->d()F

    move-result v7

    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v1, v10}, Lc/G8;->U(Lc/r0;F)F

    move-result v10

    const/4 v11, 0x0

    invoke-direct {v8, v11, v11, v7, v10}, Lc/m0;-><init>(FFFF)V

    goto :goto_1

    :cond_4
    invoke-virtual {v7, v1}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v8

    :goto_1
    iget-object v7, v1, Lc/r0;->a:Lc/s0;

    sget-object v10, Lc/s0;->j:Lc/s0;

    const/high16 v11, 0x3f000000    # 0.5f

    if-ne v7, v10, :cond_5

    invoke-virtual {v8}, Lc/m0;->d()F

    move-result v10

    add-float/2addr v10, v11

    iget-object v12, v0, Lc/g1;->G:Landroid/graphics/Rect;

    iget v12, v12, Landroid/graphics/Rect;->right:I

    int-to-float v12, v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_c

    invoke-virtual {v8}, Lc/m0;->b()F

    move-result v10

    add-float/2addr v10, v11

    iget-object v12, v0, Lc/g1;->G:Landroid/graphics/Rect;

    iget v12, v12, Landroid/graphics/Rect;->bottom:I

    int-to-float v12, v12

    cmpl-float v10, v10, v12

    if-ltz v10, :cond_c

    :cond_5
    sget-object v10, Lc/s0;->e:Lc/s0;

    iget-object v12, v0, Lc/g1;->b:Lc/n1;

    if-ne v7, v10, :cond_6

    invoke-virtual {v12}, Lc/n1;->u()I

    move-result v10

    invoke-virtual {v8}, Lc/m0;->d()F

    move-result v13

    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v14

    div-float/2addr v13, v14

    invoke-virtual {v8}, Lc/m0;->b()F

    move-result v14

    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v15

    div-float/2addr v14, v15

    invoke-virtual/range {p0 .. p0}, Lc/g1;->x()F

    move-result v15

    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v16

    div-float v15, v15, v16

    invoke-static {v13, v14, v15}, Lc/G8;->V(FFF)I

    move-result v13

    if-gt v10, v13, :cond_c

    :cond_6
    sget-object v10, Lc/s0;->l:Lc/s0;

    if-ne v7, v10, :cond_7

    iget-object v10, v0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v13

    invoke-static {v10, v12, v8, v13}, Lc/G0;->g(Landroid/content/Context;Lc/n1;Lc/m0;F)Z

    move-result v10

    if-eqz v10, :cond_c

    :cond_7
    invoke-virtual {v0, v9}, Lc/g1;->h(F)F

    move-result v9

    invoke-virtual/range {p0 .. p0}, Lc/g1;->x()F

    move-result v10

    invoke-virtual {v12}, Lc/n1;->C()I

    move-result v13

    invoke-virtual {v12}, Lc/n1;->B()I

    move-result v14

    invoke-virtual {v12}, Lc/n1;->V()I

    move-result v12

    sget-object v15, Lc/s0;->k:Lc/s0;

    if-ne v7, v15, :cond_8

    invoke-virtual {v8}, Lc/m0;->d()F

    move-result v7

    invoke-virtual {v8}, Lc/m0;->b()F

    move-result v8

    invoke-static {v13, v7, v8, v9, v14}, Lc/k6;->E(IFFFI)Z

    move-result v7

    goto :goto_3

    :cond_8
    sget-object v13, Lc/s0;->h:Lc/s0;

    if-ne v7, v13, :cond_a

    invoke-virtual {v8}, Lc/m0;->d()F

    move-result v7

    invoke-virtual {v8}, Lc/m0;->b()F

    move-result v8

    add-float/2addr v7, v11

    int-to-float v10, v12

    const/high16 v12, 0x40800000    # 4.0f

    add-float/2addr v10, v12

    add-float/2addr v10, v12

    mul-float/2addr v10, v9

    cmpl-float v7, v7, v10

    if-ltz v7, :cond_9

    add-float/2addr v8, v11

    cmpl-float v7, v8, v10

    if-ltz v7, :cond_9

    goto :goto_2

    :cond_9
    move v7, v4

    goto :goto_3

    :cond_a
    sget-object v11, Lc/s0;->d:Lc/s0;

    if-ne v7, v11, :cond_b

    invoke-virtual {v8}, Lc/m0;->d()F

    move-result v7

    const/high16 v11, 0x40400000    # 3.0f

    mul-float/2addr v11, v10

    const/high16 v12, 0x42000000    # 32.0f

    mul-float/2addr v12, v9

    add-float/2addr v12, v11

    cmpl-float v7, v7, v12

    if-ltz v7, :cond_9

    invoke-virtual {v8}, Lc/m0;->b()F

    move-result v7

    const/high16 v8, 0x40000000    # 2.0f

    mul-float/2addr v10, v8

    const/high16 v8, 0x42400000    # 48.0f

    mul-float/2addr v9, v8

    add-float/2addr v9, v10

    cmpl-float v7, v7, v9

    if-ltz v7, :cond_9

    :cond_b
    :goto_2
    move v7, v5

    :goto_3
    if-eqz v7, :cond_c

    move v4, v5

    :cond_c
    if-eqz v2, :cond_e

    iget v2, v1, Lc/r0;->e:I

    aget-object v2, v6, v2

    if-eqz v4, :cond_d

    move v3, v5

    :cond_d
    int-to-byte v3, v3

    iget v1, v1, Lc/r0;->f:I

    aput-byte v3, v2, v1

    :cond_e
    return v4
.end method

.method public final f(FF)Z
    .locals 3

    iget-object v0, p0, Lc/g1;->w:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->x:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->r:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->s:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->t:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->u:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->v:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-nez v0, :cond_9

    iget-object v0, p0, Lc/g1;->z:Landroid/graphics/RectF;

    invoke-virtual {v0, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-object v0, p0, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {v0}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {v2, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_1

    return v1

    :cond_2
    iget-object v0, p0, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v0}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {v2, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_3

    return v1

    :cond_4
    iget-object v0, p0, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v0}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_5
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {v2, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_5

    return v1

    :cond_6
    iget-object v0, p0, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v0}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {p0, v2, p1, p2}, Lc/g1;->j(Landroid/graphics/RectF;FF)I

    move-result v2

    if-eqz v2, :cond_7

    return v1

    :cond_8
    const/4 p1, 0x0

    return p1

    :cond_9
    :goto_0
    return v1
.end method

.method public final g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;
    .locals 3

    invoke-virtual {p0}, Lc/g1;->x()F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {p0, v1}, Lc/g1;->h(F)F

    move-result v1

    if-eqz p2, :cond_0

    iget p2, p1, Landroid/graphics/RectF;->right:F

    sub-float/2addr p2, v1

    goto :goto_0

    :cond_0
    iget p2, p1, Landroid/graphics/RectF;->left:F

    add-float/2addr p2, v1

    :goto_0
    if-eqz p3, :cond_1

    iget p1, p1, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr p1, v1

    goto :goto_1

    :cond_1
    iget p1, p1, Landroid/graphics/RectF;->top:F

    add-float/2addr p1, v1

    :goto_1
    new-instance p3, Landroid/graphics/RectF;

    sub-float v1, p2, v0

    sub-float v2, p1, v0

    add-float/2addr p2, v0

    add-float/2addr p1, v0

    invoke-direct {p3, v1, v2, p2, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    return-object p3
.end method

.method public final h(F)F
    .locals 1

    iget-object v0, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final i(Lc/s0;)Z
    .locals 2

    iget-boolean v0, p0, Lc/g1;->J:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/g1;->H:Lc/s0;

    if-ne v0, p1, :cond_0

    iget-boolean p1, p0, Lc/g1;->K:Z

    if-eqz p1, :cond_0

    iget p1, p0, Lc/g1;->N:I

    const/4 v0, 0x1

    if-eq p1, v0, :cond_1

    const/4 v1, 0x2

    if-ne p1, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :cond_1
    :goto_0
    return v0
.end method

.method public final j(Landroid/graphics/RectF;FF)I
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_6

    invoke-virtual {p1, p2, p3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_2

    :cond_0
    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {p0, v1}, Lc/g1;->h(F)F

    move-result v1

    iget-object v2, p0, Lc/g1;->F:Lc/o0;

    iget-boolean v2, v2, Lc/o0;->f:Z

    if-eqz v2, :cond_2

    :cond_1
    move p2, v0

    goto :goto_0

    :cond_2
    iget v2, p1, Landroid/graphics/RectF;->left:F

    add-float/2addr v2, v1

    cmpg-float v2, p2, v2

    if-gez v2, :cond_3

    const/4 p2, 0x1

    goto :goto_0

    :cond_3
    iget v2, p1, Landroid/graphics/RectF;->right:F

    sub-float/2addr v2, v1

    cmpl-float p2, p2, v2

    if-lez p2, :cond_1

    const/4 p2, 0x2

    :goto_0
    iget v2, p1, Landroid/graphics/RectF;->top:F

    add-float/2addr v2, v1

    cmpg-float v2, p3, v2

    if-gez v2, :cond_4

    const/4 v0, 0x4

    goto :goto_1

    :cond_4
    iget p1, p1, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr p1, v1

    cmpl-float p1, p3, p1

    if-lez p1, :cond_5

    const/16 v0, 0x8

    :cond_5
    :goto_1
    or-int p1, p2, v0

    return p1

    :cond_6
    :goto_2
    return v0
.end method

.method public final k()Z
    .locals 6

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v1, :cond_3

    aget-object v4, v0, v3

    sget-object v5, Lc/s0;->f:Lc/s0;

    if-ne v4, v5, :cond_0

    goto :goto_1

    :cond_0
    iget-object v5, p0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v5, v4}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v4

    if-eqz v4, :cond_2

    iget-boolean v4, v4, Lc/r0;->g:Z

    if-eqz v4, :cond_1

    goto :goto_2

    :cond_1
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    :goto_2
    const/4 v0, 0x1

    return v0

    :cond_3
    return v2
.end method

.method public final l(Landroid/graphics/Canvas;ILandroid/graphics/RectF;I)V
    .locals 3

    iget-object v0, p0, Lc/g1;->a0:Landroid/util/SparseArray;

    invoke-virtual {v0, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_0

    iget-object v1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_0
    invoke-virtual {v1, p4}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/high16 p2, 0x41300000    # 11.0f

    invoke-virtual {p0, p2}, Lc/g1;->h(F)F

    move-result p2

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-virtual {p3}, Landroid/graphics/RectF;->centerX()F

    move-result p4

    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    move-result p4

    invoke-virtual {p3}, Landroid/graphics/RectF;->centerY()F

    move-result p3

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    sub-int v0, p4, p2

    sub-int v2, p3, p2

    add-int/2addr p4, p2

    add-int/2addr p3, p2

    invoke-virtual {v1, v0, v2, p4, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public final m(Z)V
    .locals 1

    iget-object v0, p0, Lc/g1;->a:Lc/P3;

    if-eqz p1, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of v0, p1, Landroid/view/View;

    if-eqz v0, :cond_1

    check-cast p1, Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->postInvalidateOnAnimation()V

    :cond_1
    return-void
.end method

.method public final n(Landroid/view/MotionEvent;)Z
    .locals 25

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/g1;->F:Lc/o0;

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    :cond_0
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    iget-boolean v5, v0, Lc/g1;->J:Z

    iget-object v6, v0, Lc/g1;->x:Landroid/graphics/RectF;

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez v5, :cond_2

    if-nez v1, :cond_1

    invoke-virtual {v6, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-virtual {v0, v8, v3, v4}, Lc/g1;->v(IFF)V

    return v7

    :cond_1
    iget v5, v0, Lc/g1;->N:I

    if-eq v5, v8, :cond_2

    return v2

    :cond_2
    const/4 v5, 0x5

    if-eq v1, v5, :cond_3

    const/4 v9, 0x3

    if-ne v1, v9, :cond_4

    :cond_3
    move v1, v7

    goto/16 :goto_25

    :cond_4
    iget-object v10, v0, Lc/g1;->y:Landroid/graphics/RectF;

    iget-object v11, v0, Lc/g1;->w:Landroid/graphics/RectF;

    sget-object v12, Lc/s0;->i:Lc/s0;

    sget-object v13, Lc/s0;->g:Lc/s0;

    sget-object v14, Lc/s0;->h:Lc/s0;

    iget-object v8, v0, Lc/g1;->q:Ljava/util/EnumMap;

    iget-object v5, v0, Lc/g1;->v:Landroid/graphics/RectF;

    sget-object v7, Lc/s0;->d:Lc/s0;

    iget-object v9, v0, Lc/g1;->u:Landroid/graphics/RectF;

    iget-object v15, v0, Lc/g1;->t:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/g1;->s:Landroid/graphics/RectF;

    move-object/from16 v16, v2

    sget-object v2, Lc/s0;->c:Lc/s0;

    move-object/from16 v17, v5

    iget-object v5, v0, Lc/g1;->r:Landroid/graphics/RectF;

    move-object/from16 v18, v5

    iget-object v5, v0, Lc/g1;->p:Ljava/util/EnumMap;

    move-object/from16 v19, v9

    iget-object v9, v0, Lc/g1;->a:Lc/P3;

    move-object/from16 v21, v15

    iget-object v15, v0, Lc/g1;->b:Lc/n1;

    if-nez v1, :cond_16

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v15}, Lc/e0;->o(Landroid/content/Context;Lc/n1;)Landroid/graphics/Rect;

    move-result-object v1

    iput-object v1, v0, Lc/g1;->G:Landroid/graphics/Rect;

    const/4 v1, 0x0

    iput v1, v0, Lc/g1;->O:I

    invoke-virtual {v11, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_5

    const/16 v20, 0x3

    goto :goto_0

    :cond_5
    invoke-virtual {v6, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_6

    const/16 v20, 0x7

    goto :goto_0

    :cond_6
    invoke-virtual {v10, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_7

    const/16 v20, 0x8

    goto :goto_0

    :cond_7
    const/16 v20, 0x0

    :goto_0
    if-nez v20, :cond_8

    iget-object v1, v0, Lc/g1;->z:Landroid/graphics/RectF;

    invoke-virtual {v1, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_8

    iput-object v14, v0, Lc/g1;->H:Lc/s0;

    const/16 v20, 0x1

    :cond_8
    if-nez v20, :cond_14

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v6, v1

    const v9, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v10, 0x0

    :goto_1
    if-ge v10, v6, :cond_10

    aget-object v11, v1, v10

    invoke-virtual {v5, v11}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/graphics/RectF;

    iget-object v15, v0, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v15, v11}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroid/graphics/RectF;

    move-object/from16 p1, v1

    sget-object v1, Lc/s0;->b:Lc/s0;

    if-ne v11, v1, :cond_9

    move-object/from16 v1, v18

    goto :goto_2

    :cond_9
    if-ne v11, v2, :cond_a

    move-object/from16 v1, v16

    goto :goto_2

    :cond_a
    if-ne v11, v13, :cond_b

    move-object/from16 v1, v21

    goto :goto_2

    :cond_b
    if-ne v11, v12, :cond_c

    move-object/from16 v1, v19

    goto :goto_2

    :cond_c
    if-ne v11, v7, :cond_d

    move-object/from16 v1, v17

    goto :goto_2

    :cond_d
    invoke-virtual {v8, v11}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    :goto_2
    filled-new-array {v14, v15, v1}, [Landroid/graphics/RectF;

    move-result-object v1

    move/from16 v22, v6

    const/4 v6, 0x2

    const/4 v14, 0x6

    const/4 v15, 0x4

    filled-new-array {v15, v6, v14}, [I

    move-result-object v23

    const/4 v6, 0x0

    :goto_3
    const/4 v14, 0x3

    if-ge v6, v14, :cond_f

    aget-object v14, v1, v6

    if-eqz v14, :cond_e

    invoke-virtual {v14, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v15

    if-eqz v15, :cond_e

    invoke-virtual {v14}, Landroid/graphics/RectF;->centerX()F

    move-result v15

    sub-float v15, v3, v15

    invoke-virtual {v14}, Landroid/graphics/RectF;->centerX()F

    move-result v24

    sub-float v24, v3, v24

    mul-float v24, v24, v15

    invoke-virtual {v14}, Landroid/graphics/RectF;->centerY()F

    move-result v15

    sub-float v15, v4, v15

    invoke-virtual {v14}, Landroid/graphics/RectF;->centerY()F

    move-result v14

    sub-float v14, v4, v14

    mul-float/2addr v14, v15

    add-float v14, v14, v24

    cmpg-float v15, v14, v9

    if-gez v15, :cond_e

    aget v20, v23, v6

    iput-object v11, v0, Lc/g1;->H:Lc/s0;

    move v9, v14

    :cond_e
    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_f
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v1, p1

    move/from16 v6, v22

    goto :goto_1

    :cond_10
    iget-object v1, v0, Lc/g1;->n:Ljava/util/EnumMap;

    if-nez v20, :cond_12

    invoke-virtual {v1}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_11
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_12

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/graphics/RectF;

    invoke-virtual {v0, v6, v3, v4}, Lc/g1;->j(Landroid/graphics/RectF;FF)I

    move-result v6

    if-eqz v6, :cond_11

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/s0;

    iput-object v2, v0, Lc/g1;->H:Lc/s0;

    iput v6, v0, Lc/g1;->O:I

    const/16 v20, 0x2

    :cond_12
    if-nez v20, :cond_14

    invoke-virtual {v1}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_13
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_14

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/RectF;

    invoke-virtual {v5, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_13

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/s0;

    iput-object v1, v0, Lc/g1;->H:Lc/s0;

    const/16 v20, 0x1

    :cond_14
    if-nez v20, :cond_15

    const/4 v5, 0x5

    goto :goto_4

    :cond_15
    move/from16 v5, v20

    :goto_4
    invoke-virtual {v0, v5, v3, v4}, Lc/g1;->v(IFF)V

    :goto_5
    const/4 v1, 0x1

    return v1

    :cond_16
    move-object/from16 v22, v5

    sget-object v5, Lc/s0;->k:Lc/s0;

    move-object/from16 v23, v8

    const/4 v8, 0x2

    if-ne v1, v8, :cond_2d

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v0, v1}, Lc/g1;->i(Lc/s0;)Z

    move-result v1

    iput v3, v0, Lc/g1;->R:F

    iput v4, v0, Lc/g1;->S:F

    iget-boolean v2, v0, Lc/g1;->K:Z

    iget v6, v0, Lc/g1;->P:F

    sub-float v6, v3, v6

    float-to-double v6, v6

    iget v8, v0, Lc/g1;->Q:F

    sub-float v8, v4, v8

    float-to-double v10, v8

    invoke-static {v6, v7, v10, v11}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v6

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-static {v8}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v8

    invoke-virtual {v8}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v8

    int-to-double v10, v8

    cmpl-double v6, v6, v10

    if-lez v6, :cond_17

    const/4 v6, 0x1

    goto :goto_6

    :cond_17
    const/4 v6, 0x0

    :goto_6
    or-int/2addr v2, v6

    iput-boolean v2, v0, Lc/g1;->K:Z

    if-eqz v2, :cond_29

    iget v6, v0, Lc/g1;->N:I

    const/4 v7, 0x1

    if-eq v6, v7, :cond_18

    const/4 v8, 0x2

    if-ne v6, v8, :cond_29

    :cond_18
    iget-object v2, v0, Lc/g1;->A:Landroid/graphics/RectF;

    iget-object v8, v0, Lc/g1;->B:Landroid/graphics/RectF;

    if-ne v6, v7, :cond_19

    iget v5, v8, Landroid/graphics/RectF;->left:F

    add-float/2addr v5, v3

    iget v6, v0, Lc/g1;->P:F

    sub-float/2addr v5, v6

    iget v7, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v7, v4

    iget v10, v0, Lc/g1;->Q:F

    sub-float/2addr v7, v10

    iget v11, v8, Landroid/graphics/RectF;->right:F

    add-float/2addr v11, v3

    sub-float/2addr v11, v6

    iget v3, v8, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v3, v4

    sub-float/2addr v3, v10

    invoke-virtual {v2, v5, v7, v11, v3}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v2, v0, Lc/g1;->X:Lc/e1;

    invoke-virtual {v9, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v9, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_7
    const/4 v2, 0x0

    goto/16 :goto_11

    :cond_19
    iget-object v6, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v6, v6, Lc/o0;->f:Z

    const/high16 v7, 0x42a00000    # 80.0f

    const/high16 v9, 0x40800000    # 4.0f

    if-eqz v6, :cond_1d

    iget-object v3, v0, Lc/g1;->H:Lc/s0;

    if-ne v3, v5, :cond_1a

    invoke-virtual {v15}, Lc/n1;->B()I

    move-result v3

    invoke-static {v3}, Lc/k6;->s(I)F

    move-result v3

    invoke-virtual {v0, v3}, Lc/g1;->h(F)F

    move-result v3

    goto :goto_8

    :cond_1a
    if-ne v3, v14, :cond_1b

    invoke-virtual {v15}, Lc/n1;->V()I

    move-result v3

    int-to-float v3, v3

    add-float/2addr v3, v9

    add-float/2addr v3, v9

    invoke-virtual {v0, v3}, Lc/g1;->h(F)F

    move-result v3

    goto :goto_8

    :cond_1b
    invoke-virtual {v0, v7}, Lc/g1;->h(F)F

    move-result v3

    :goto_8
    iget v5, v0, Lc/g1;->O:I

    const/4 v6, 0x4

    and-int/2addr v5, v6

    if-eqz v5, :cond_1c

    iget v5, v8, Landroid/graphics/RectF;->left:F

    iget v6, v8, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v6, v3

    iget v3, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v3, v4

    iget v4, v0, Lc/g1;->Q:F

    sub-float/2addr v3, v4

    invoke-static {v6, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    iget v4, v8, Landroid/graphics/RectF;->right:F

    iget v6, v8, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v2, v5, v3, v4, v6}, Landroid/graphics/RectF;->set(FFFF)V

    goto :goto_7

    :cond_1c
    iget v5, v8, Landroid/graphics/RectF;->left:F

    iget v6, v8, Landroid/graphics/RectF;->top:F

    iget v7, v8, Landroid/graphics/RectF;->right:F

    add-float/2addr v3, v6

    iget v8, v8, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v8, v4

    iget v4, v0, Lc/g1;->Q:F

    sub-float/2addr v8, v4

    invoke-static {v3, v8}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-virtual {v2, v5, v6, v7, v3}, Landroid/graphics/RectF;->set(FFFF)V

    goto :goto_7

    :cond_1d
    iget v6, v0, Lc/g1;->O:I

    const/high16 v10, 0x42400000    # 48.0f

    if-eqz v6, :cond_24

    iget v5, v0, Lc/g1;->P:F

    sub-float/2addr v3, v5

    iget v5, v0, Lc/g1;->Q:F

    sub-float/2addr v4, v5

    iget-object v5, v0, Lc/g1;->H:Lc/s0;

    if-ne v5, v14, :cond_1e

    invoke-virtual {v15}, Lc/n1;->V()I

    move-result v5

    int-to-float v5, v5

    add-float/2addr v5, v9

    add-float/2addr v5, v9

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v5

    goto :goto_9

    :cond_1e
    invoke-virtual {v0, v10}, Lc/g1;->h(F)F

    move-result v5

    :goto_9
    iget-object v6, v0, Lc/g1;->H:Lc/s0;

    if-ne v6, v14, :cond_1f

    invoke-virtual {v15}, Lc/n1;->V()I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v6, v9

    add-float/2addr v6, v9

    invoke-virtual {v0, v6}, Lc/g1;->h(F)F

    move-result v6

    goto :goto_a

    :cond_1f
    invoke-virtual {v0, v10}, Lc/g1;->h(F)F

    move-result v6

    :goto_a
    iget v7, v0, Lc/g1;->O:I

    const/4 v9, 0x1

    and-int/2addr v7, v9

    if-eqz v7, :cond_20

    iget v7, v8, Landroid/graphics/RectF;->right:F

    sub-float/2addr v7, v5

    iget v9, v8, Landroid/graphics/RectF;->left:F

    add-float/2addr v9, v3

    invoke-static {v7, v9}, Ljava/lang/Math;->min(FF)F

    move-result v7

    goto :goto_b

    :cond_20
    iget v7, v8, Landroid/graphics/RectF;->left:F

    :goto_b
    iget v9, v0, Lc/g1;->O:I

    const/4 v10, 0x2

    and-int/2addr v9, v10

    if-eqz v9, :cond_21

    iget v9, v8, Landroid/graphics/RectF;->left:F

    add-float/2addr v9, v5

    iget v5, v8, Landroid/graphics/RectF;->right:F

    add-float/2addr v5, v3

    invoke-static {v9, v5}, Ljava/lang/Math;->max(FF)F

    move-result v3

    goto :goto_c

    :cond_21
    iget v3, v8, Landroid/graphics/RectF;->right:F

    :goto_c
    iget v5, v0, Lc/g1;->O:I

    const/4 v9, 0x4

    and-int/2addr v5, v9

    if-eqz v5, :cond_22

    iget v5, v8, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v5, v6

    iget v9, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v9, v4

    invoke-static {v5, v9}, Ljava/lang/Math;->min(FF)F

    move-result v5

    goto :goto_d

    :cond_22
    iget v5, v8, Landroid/graphics/RectF;->top:F

    :goto_d
    iget v9, v0, Lc/g1;->O:I

    const/16 v10, 0x8

    and-int/2addr v9, v10

    if-eqz v9, :cond_23

    iget v9, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v9, v6

    iget v6, v8, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v6, v4

    invoke-static {v9, v6}, Ljava/lang/Math;->max(FF)F

    move-result v4

    goto :goto_e

    :cond_23
    iget v4, v8, Landroid/graphics/RectF;->bottom:F

    :goto_e
    invoke-virtual {v2, v7, v5, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    goto/16 :goto_7

    :cond_24
    iget-object v6, v0, Lc/g1;->H:Lc/s0;

    if-ne v6, v5, :cond_25

    invoke-virtual {v15}, Lc/n1;->B()I

    move-result v6

    invoke-static {v6}, Lc/k6;->s(I)F

    move-result v6

    invoke-virtual {v0, v6}, Lc/g1;->h(F)F

    move-result v6

    goto :goto_f

    :cond_25
    if-ne v6, v14, :cond_26

    invoke-virtual {v15}, Lc/n1;->V()I

    move-result v6

    int-to-float v6, v6

    add-float/2addr v6, v9

    add-float/2addr v6, v9

    invoke-virtual {v0, v6}, Lc/g1;->h(F)F

    move-result v6

    goto :goto_f

    :cond_26
    invoke-virtual {v0, v10}, Lc/g1;->h(F)F

    move-result v6

    :goto_f
    iget-object v10, v0, Lc/g1;->H:Lc/s0;

    if-ne v10, v5, :cond_27

    invoke-virtual {v15}, Lc/n1;->B()I

    move-result v5

    invoke-static {v5}, Lc/k6;->s(I)F

    move-result v5

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v5

    goto :goto_10

    :cond_27
    if-ne v10, v14, :cond_28

    invoke-virtual {v15}, Lc/n1;->V()I

    move-result v5

    int-to-float v5, v5

    add-float/2addr v5, v9

    add-float/2addr v5, v9

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v5

    goto :goto_10

    :cond_28
    invoke-virtual {v0, v7}, Lc/g1;->h(F)F

    move-result v5

    :goto_10
    iget v7, v8, Landroid/graphics/RectF;->left:F

    iget v9, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v6, v7

    iget v10, v8, Landroid/graphics/RectF;->right:F

    add-float/2addr v10, v3

    iget v3, v0, Lc/g1;->P:F

    sub-float/2addr v10, v3

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v3

    iget v6, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v6, v5

    iget v5, v8, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v5, v4

    iget v4, v0, Lc/g1;->Q:F

    sub-float/2addr v5, v4

    invoke-static {v6, v5}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v2, v7, v9, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    goto/16 :goto_7

    :goto_11
    invoke-virtual {v0, v2}, Lc/g1;->y(Z)V

    goto :goto_12

    :cond_29
    iget v3, v0, Lc/g1;->N:I

    const/4 v5, 0x5

    if-ne v3, v5, :cond_2a

    if-eqz v2, :cond_2a

    iget-object v2, v0, Lc/g1;->F:Lc/o0;

    invoke-virtual {v2}, Lc/o0;->c()F

    move-result v2

    iget v3, v0, Lc/g1;->T:F

    iget v5, v0, Lc/g1;->Q:F

    add-float/2addr v3, v5

    sub-float/2addr v3, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iget-object v3, v0, Lc/g1;->k:Lc/M3;

    iget-object v3, v3, Lc/M3;->a:Lc/P3;

    iput v2, v3, Lc/P3;->D:F

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    :cond_2a
    :goto_12
    if-eqz v1, :cond_2c

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v0, v1}, Lc/g1;->i(Lc/s0;)Z

    move-result v1

    if-nez v1, :cond_2b

    goto :goto_13

    :cond_2b
    const/4 v2, 0x0

    goto :goto_14

    :cond_2c
    :goto_13
    const/4 v2, 0x1

    :goto_14
    invoke-virtual {v0, v2}, Lc/g1;->m(Z)V

    const/4 v8, 0x1

    return v8

    :cond_2d
    const/4 v8, 0x1

    if-ne v1, v8, :cond_4d

    iget v1, v0, Lc/g1;->N:I

    const/4 v15, 0x3

    if-ne v1, v15, :cond_2e

    iget-boolean v1, v0, Lc/g1;->K:Z

    if-nez v1, :cond_2e

    invoke-virtual {v11, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_2e

    invoke-virtual/range {p0 .. p0}, Lc/g1;->c()Z

    return v8

    :cond_2e
    iget v1, v0, Lc/g1;->N:I

    const/4 v8, 0x7

    if-ne v1, v8, :cond_2f

    iget-boolean v1, v0, Lc/g1;->K:Z

    if-nez v1, :cond_2f

    invoke-virtual {v6, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_2f

    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    invoke-virtual/range {p0 .. p0}, Lc/g1;->u()V

    goto/16 :goto_5

    :cond_2f
    iget v1, v0, Lc/g1;->N:I

    const/16 v6, 0x8

    if-ne v1, v6, :cond_30

    iget-boolean v1, v0, Lc/g1;->K:Z

    if-nez v1, :cond_30

    invoke-virtual {v10, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_30

    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    iget-object v1, v0, Lc/g1;->i:Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto/16 :goto_5

    :cond_30
    iget v1, v0, Lc/g1;->N:I

    sget-object v6, Lc/s0;->j:Lc/s0;

    const/4 v8, 0x6

    if-ne v1, v8, :cond_42

    iget-boolean v1, v0, Lc/g1;->K:Z

    if-nez v1, :cond_42

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    if-ne v1, v2, :cond_31

    const/4 v2, 0x1

    goto :goto_15

    :cond_31
    const/4 v2, 0x0

    :goto_15
    if-ne v1, v13, :cond_32

    const/4 v8, 0x1

    goto :goto_16

    :cond_32
    const/4 v8, 0x0

    :goto_16
    if-ne v1, v12, :cond_33

    const/4 v10, 0x1

    goto :goto_17

    :cond_33
    const/4 v10, 0x0

    :goto_17
    if-ne v1, v7, :cond_34

    const/4 v7, 0x1

    goto :goto_18

    :cond_34
    const/4 v7, 0x0

    :goto_18
    sget-object v11, Lc/s0;->m:Lc/s0;

    if-eq v1, v11, :cond_36

    sget-object v11, Lc/s0;->f:Lc/s0;

    if-eq v1, v11, :cond_36

    sget-object v11, Lc/s0;->e:Lc/s0;

    if-eq v1, v11, :cond_36

    if-eq v1, v5, :cond_36

    if-eq v1, v14, :cond_36

    sget-object v5, Lc/s0;->l:Lc/s0;

    if-eq v1, v5, :cond_36

    if-ne v1, v6, :cond_35

    goto :goto_19

    :cond_35
    const/4 v5, 0x0

    goto :goto_1a

    :cond_36
    :goto_19
    const/4 v5, 0x1

    :goto_1a
    if-eqz v5, :cond_37

    move-object/from16 v11, v23

    invoke-virtual {v11, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    goto :goto_1b

    :cond_37
    if-eqz v2, :cond_38

    move-object/from16 v1, v16

    goto :goto_1b

    :cond_38
    if-eqz v8, :cond_39

    move-object/from16 v1, v21

    goto :goto_1b

    :cond_39
    if-eqz v10, :cond_3a

    move-object/from16 v1, v19

    goto :goto_1b

    :cond_3a
    if-eqz v7, :cond_3b

    move-object/from16 v1, v17

    goto :goto_1b

    :cond_3b
    move-object/from16 v1, v18

    :goto_1b
    if-eqz v1, :cond_42

    invoke-virtual {v1, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_42

    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    if-ne v1, v6, :cond_3c

    iget-object v1, v0, Lc/g1;->i:Ljava/lang/Runnable;

    :goto_1c
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    :goto_1d
    const/4 v1, 0x1

    goto :goto_1e

    :cond_3c
    if-eqz v5, :cond_3d

    iget-object v2, v0, Lc/g1;->j:Ljava/util/function/Consumer;

    invoke-interface {v2, v1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    goto :goto_1d

    :cond_3d
    if-eqz v2, :cond_3e

    iget-object v1, v0, Lc/g1;->f:Ljava/lang/Runnable;

    goto :goto_1c

    :cond_3e
    if-eqz v8, :cond_3f

    iget-object v1, v0, Lc/g1;->e:Ljava/lang/Runnable;

    goto :goto_1c

    :cond_3f
    if-eqz v10, :cond_40

    iget-object v1, v0, Lc/g1;->g:Ljava/lang/Runnable;

    goto :goto_1c

    :cond_40
    if-eqz v7, :cond_41

    iget-object v1, v0, Lc/g1;->h:Ljava/lang/Runnable;

    goto :goto_1c

    :cond_41
    iget-object v1, v0, Lc/g1;->d:Lc/F3;

    goto :goto_1c

    :goto_1e
    return v1

    :cond_42
    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    move-object/from16 v2, v22

    invoke-virtual {v2, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    iget v2, v0, Lc/g1;->N:I

    const/4 v5, 0x4

    if-ne v2, v5, :cond_48

    iget-boolean v2, v0, Lc/g1;->K:Z

    if-nez v2, :cond_48

    if-eqz v1, :cond_48

    invoke-virtual {v1, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_48

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    if-ne v1, v12, :cond_43

    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-static {v1}, Lc/u0;->j(Lc/s0;)Lc/r0;

    move-result-object v1

    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v1

    invoke-virtual {v2, v1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    goto :goto_20

    :cond_43
    const/4 v3, 0x1

    if-ne v1, v13, :cond_44

    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-static {v1}, Lc/u0;->j(Lc/s0;)Lc/r0;

    move-result-object v1

    invoke-virtual {v1, v3}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v1

    invoke-virtual {v2, v1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    goto :goto_20

    :cond_44
    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iget-object v4, v2, Lc/u0;->d:Ljava/lang/Object;

    check-cast v4, Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_45
    :goto_1f
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_46

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/r0;

    iget-object v7, v5, Lc/r0;->a:Lc/s0;

    if-eq v7, v1, :cond_45

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    :cond_46
    new-instance v1, Lc/u0;

    iget-object v4, v2, Lc/u0;->b:Ljava/lang/Object;

    check-cast v4, Lc/Q1;

    iget-object v5, v2, Lc/u0;->c:Ljava/lang/Object;

    check-cast v5, Lc/q0;

    iget v2, v2, Lc/u0;->a:I

    invoke-direct {v1, v4, v5, v3, v2}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    :goto_20
    iget-object v2, v0, Lc/g1;->H:Lc/s0;

    if-ne v2, v6, :cond_47

    const/4 v2, 0x1

    goto :goto_21

    :cond_47
    const/4 v2, 0x0

    :goto_21
    invoke-virtual {v0, v1, v2}, Lc/g1;->t(Lc/u0;Z)V

    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/g1;->m(Z)V

    return v1

    :cond_48
    const/4 v1, 0x1

    iget-boolean v2, v0, Lc/g1;->K:Z

    if-eqz v2, :cond_4c

    iget v2, v0, Lc/g1;->N:I

    if-eq v2, v1, :cond_49

    const/4 v5, 0x2

    if-ne v2, v5, :cond_4c

    :cond_49
    iput v3, v0, Lc/g1;->R:F

    iput v4, v0, Lc/g1;->S:F

    invoke-virtual {v0, v1}, Lc/g1;->y(Z)V

    iget-object v1, v0, Lc/g1;->D:Lc/u0;

    if-nez v1, :cond_4a

    iget-object v2, v0, Lc/g1;->F:Lc/o0;

    iget-object v2, v2, Lc/o0;->c:Lc/m0;

    invoke-virtual {v2, v3, v4}, Lc/m0;->a(FF)Z

    move-result v2

    if-eqz v2, :cond_4a

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043c\u0435\u0441\u0442\u0430 \u0434\u043b\u044f \u0442\u0430\u043a\u043e\u0433\u043e \u0440\u0430\u0437\u043c\u0435\u0440\u0430"

    invoke-static {v3, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    goto :goto_22

    :cond_4a
    const/4 v4, 0x0

    :goto_22
    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    if-eqz v1, :cond_4b

    invoke-virtual {v0, v1, v4}, Lc/g1;->t(Lc/u0;Z)V

    :cond_4b
    :goto_23
    const/4 v1, 0x1

    goto :goto_24

    :cond_4c
    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    goto :goto_23

    :goto_24
    invoke-virtual {v0, v1}, Lc/g1;->m(Z)V

    return v1

    :cond_4d
    move v1, v8

    return v1

    :goto_25
    invoke-virtual/range {p0 .. p0}, Lc/g1;->r()V

    invoke-virtual {v0, v1}, Lc/g1;->m(Z)V

    return v1
.end method

.method public final o()V
    .locals 19

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v2, v0, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v2}, Ljava/util/EnumMap;->clear()V

    iget-object v3, v0, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {v3}, Ljava/util/EnumMap;->clear()V

    iget-object v4, v0, Lc/g1;->r:Landroid/graphics/RectF;

    invoke-virtual {v4}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v5, v0, Lc/g1;->s:Landroid/graphics/RectF;

    invoke-virtual {v5}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v6, v0, Lc/g1;->t:Landroid/graphics/RectF;

    invoke-virtual {v6}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v7, v0, Lc/g1;->u:Landroid/graphics/RectF;

    invoke-virtual {v7}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v8, v0, Lc/g1;->v:Landroid/graphics/RectF;

    invoke-virtual {v8}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v9, v0, Lc/g1;->z:Landroid/graphics/RectF;

    invoke-virtual {v9}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v10, v0, Lc/g1;->w:Landroid/graphics/RectF;

    invoke-virtual {v10}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v11, v0, Lc/g1;->x:Landroid/graphics/RectF;

    invoke-virtual {v11}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v12, v0, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {v12}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v13, v0, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v13}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v13

    invoke-interface {v13}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_0
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_b

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/Map$Entry;

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lc/s0;

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/graphics/RectF;

    move-object/from16 v16, v13

    sget-object v13, Lc/s0;->h:Lc/s0;

    move-object/from16 v17, v11

    const/4 v11, 0x1

    move-object/from16 v18, v10

    const/4 v10, 0x0

    if-ne v15, v13, :cond_0

    invoke-virtual {v0, v14, v10, v11}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v13

    invoke-virtual {v9, v13}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v13

    invoke-virtual {v3, v15, v13}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-virtual {v0, v14, v11, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v13

    invoke-virtual {v2, v15, v13}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v14, v11, v11}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v13

    invoke-virtual {v1, v15, v13}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v13, Lc/s0;->j:Lc/s0;

    if-ne v15, v13, :cond_1

    invoke-virtual {v0, v14, v10, v11}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v11

    invoke-virtual {v12, v11}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_1
    if-ne v15, v13, :cond_2

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v11

    invoke-virtual {v3, v15, v11}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    sget-object v11, Lc/s0;->b:Lc/s0;

    if-ne v15, v11, :cond_3

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v4, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_2

    :cond_3
    sget-object v11, Lc/s0;->c:Lc/s0;

    if-ne v15, v11, :cond_4

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v5, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_2

    :cond_4
    sget-object v11, Lc/s0;->g:Lc/s0;

    if-ne v15, v11, :cond_5

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v6, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_2

    :cond_5
    sget-object v11, Lc/s0;->i:Lc/s0;

    if-ne v15, v11, :cond_6

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v7, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_2

    :cond_6
    sget-object v11, Lc/s0;->d:Lc/s0;

    if-ne v15, v11, :cond_7

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v8, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_2

    :cond_7
    sget-object v11, Lc/s0;->m:Lc/s0;

    if-eq v15, v11, :cond_9

    sget-object v11, Lc/s0;->f:Lc/s0;

    if-eq v15, v11, :cond_9

    sget-object v11, Lc/s0;->e:Lc/s0;

    if-eq v15, v11, :cond_9

    sget-object v11, Lc/s0;->l:Lc/s0;

    if-ne v15, v11, :cond_8

    goto :goto_1

    :cond_8
    sget-object v11, Lc/s0;->k:Lc/s0;

    if-ne v15, v11, :cond_a

    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v3, v15, v10}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_9
    :goto_1
    invoke-virtual {v0, v14, v10, v10}, Lc/g1;->g(Landroid/graphics/RectF;ZZ)Landroid/graphics/RectF;

    move-result-object v10

    invoke-virtual {v3, v15, v10}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_a
    :goto_2
    move-object/from16 v13, v16

    move-object/from16 v11, v17

    move-object/from16 v10, v18

    goto/16 :goto_0

    :cond_b
    move-object/from16 v18, v10

    move-object/from16 v17, v11

    iget-boolean v1, v0, Lc/g1;->L:Z

    if-eqz v1, :cond_c

    return-void

    :cond_c
    invoke-virtual/range {p0 .. p0}, Lc/g1;->x()F

    move-result v1

    iget-object v2, v0, Lc/g1;->F:Lc/o0;

    iget-object v3, v2, Lc/o0;->d:Lc/m0;

    sget-object v4, Lc/Q1;->a:Lc/Q1;

    iget v5, v3, Lc/m0;->c:F

    iget-object v2, v2, Lc/o0;->j:Lc/Q1;

    const/high16 v6, 0x42f00000    # 120.0f

    if-ne v2, v4, :cond_e

    iget v2, v3, Lc/m0;->a:F

    invoke-virtual {v0, v6}, Lc/g1;->h(F)F

    move-result v4

    add-float/2addr v4, v2

    invoke-virtual/range {p0 .. p0}, Lc/g1;->k()Z

    move-result v2

    if-eqz v2, :cond_d

    const/high16 v2, 0x434c0000    # 204.0f

    invoke-virtual {v0, v2}, Lc/g1;->h(F)F

    move-result v2

    goto :goto_3

    :cond_d
    const/4 v2, 0x0

    :goto_3
    add-float/2addr v4, v2

    invoke-static {v5, v4}, Ljava/lang/Math;->min(FF)F

    move-result v5

    :cond_e
    invoke-virtual {v0, v6}, Lc/g1;->h(F)F

    move-result v2

    sub-float v2, v5, v2

    iget v3, v3, Lc/m0;->d:F

    sub-float v1, v3, v1

    move-object/from16 v4, v18

    invoke-virtual {v4, v2, v1, v5, v3}, Landroid/graphics/RectF;->set(FFFF)V

    iget v2, v4, Landroid/graphics/RectF;->left:F

    const/high16 v4, 0x41000000    # 8.0f

    invoke-virtual {v0, v4}, Lc/g1;->h(F)F

    move-result v4

    sub-float/2addr v2, v4

    invoke-virtual/range {p0 .. p0}, Lc/g1;->k()Z

    move-result v4

    if-eqz v4, :cond_f

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget-object v4, v4, Lc/o0;->c:Lc/m0;

    const/high16 v5, 0x43440000    # 196.0f

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v5

    sub-float v5, v2, v5

    iget v4, v4, Lc/m0;->a:F

    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    move-result v4

    move-object/from16 v5, v17

    invoke-virtual {v5, v4, v1, v2, v3}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_f
    return-void
.end method

.method public final p(Lc/s0;Landroid/graphics/RectF;)V
    .locals 10

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/g1;->F:Lc/o0;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0, p1}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    iget-object v1, p0, Lc/g1;->k:Lc/M3;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/g1;->D:Lc/u0;

    if-nez v0, :cond_2

    iget-object v0, p0, Lc/g1;->E:Lc/r0;

    if-eqz v0, :cond_2

    iget-object v2, p0, Lc/g1;->F:Lc/o0;

    iget-boolean v3, v2, Lc/o0;->f:Z

    if-eqz v3, :cond_1

    iget-object v0, p0, Lc/g1;->A:Landroid/graphics/RectF;

    invoke-virtual {p2, v0}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_0

    :cond_1
    invoke-virtual {v2, v0}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v0

    iget-object v2, v1, Lc/M3;->a:Lc/P3;

    iget v2, v2, Lc/P3;->D:F

    iget v3, v0, Lc/m0;->b:F

    sub-float/2addr v3, v2

    iget v4, v0, Lc/m0;->d:F

    sub-float/2addr v4, v2

    iget v2, v0, Lc/m0;->a:F

    iget v0, v0, Lc/m0;->c:F

    invoke-virtual {p2, v2, v3, v0, v4}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_2
    :goto_0
    iget-object v0, p0, Lc/g1;->H:Lc/s0;

    invoke-virtual {p0, v0}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    const/high16 v2, 0x3f800000    # 1.0f

    if-eqz v0, :cond_3

    iget-object v3, p0, Lc/g1;->D:Lc/u0;

    if-eqz v3, :cond_3

    iget-object v0, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v4

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-virtual {p0, v2}, Lc/g1;->h(F)F

    move-result v6

    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v7, v0, Landroid/util/DisplayMetrics;->density:F

    iget-boolean v8, p0, Lc/g1;->I:Z

    iget-object v0, p0, Lc/g1;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->C()I

    invoke-virtual {v0}, Lc/n1;->B()I

    invoke-virtual {v0}, Lc/n1;->f0()Z

    move-result v9

    invoke-static/range {v3 .. v9}, Lc/G8;->k(Lc/u0;IIFFZZ)Lc/o0;

    move-result-object v0

    iget-object v0, v0, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/m0;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lc/m0;->d()F

    move-result v3

    cmpl-float v3, v3, v2

    if-lez v3, :cond_3

    invoke-virtual {v0}, Lc/m0;->b()F

    move-result v3

    cmpl-float v3, v3, v2

    if-lez v3, :cond_3

    iget-object v3, v1, Lc/M3;->a:Lc/P3;

    iget v3, v3, Lc/P3;->D:F

    iget v4, v0, Lc/m0;->b:F

    sub-float/2addr v4, v3

    iget v5, v0, Lc/m0;->d:F

    sub-float/2addr v5, v3

    iget v3, v0, Lc/m0;->a:F

    iget v0, v0, Lc/m0;->c:F

    invoke-virtual {p2, v3, v4, v0, v5}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_3
    invoke-virtual {p2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lc/g1;->F:Lc/o0;

    iget-object v0, v0, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/m0;

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Lc/m0;->d()F

    move-result v0

    cmpl-float v0, v0, v2

    if-lez v0, :cond_4

    invoke-virtual {p1}, Lc/m0;->b()F

    move-result v0

    cmpl-float v0, v0, v2

    if-lez v0, :cond_4

    iget-object v0, v1, Lc/M3;->a:Lc/P3;

    iget v0, v0, Lc/P3;->D:F

    iget v1, p1, Lc/m0;->b:F

    sub-float/2addr v1, v0

    iget v2, p1, Lc/m0;->d:F

    sub-float/2addr v2, v0

    iget v0, p1, Lc/m0;->a:F

    iget p1, p1, Lc/m0;->c:F

    invoke-virtual {p2, v0, v1, p1, v2}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_4
    return-void
.end method

.method public final q(Lc/s0;)Lc/r0;
    .locals 2

    invoke-virtual {p0, p1}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/g1;->E:Lc/r0;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lc/g1;->D:Lc/u0;

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/g1;->D:Lc/u0;

    if-eqz v0, :cond_1

    invoke-virtual {p0, p1}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/g1;->D:Lc/u0;

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lc/g1;->C:Lc/u0;

    :goto_0
    invoke-virtual {v0, p1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    :goto_1
    return-object v0
.end method

.method public final r()V
    .locals 5

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g1;->M:Z

    iput v0, p0, Lc/g1;->N:I

    iput-boolean v0, p0, Lc/g1;->K:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc/g1;->D:Lc/u0;

    iput-object v1, p0, Lc/g1;->E:Lc/r0;

    const-string v1, ""

    iput-object v1, p0, Lc/g1;->U:Ljava/lang/String;

    iget-object v1, p0, Lc/g1;->X:Lc/e1;

    iget-object v2, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v2, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v1, p0, Lc/g1;->V:[[B

    array-length v2, v1

    move v3, v0

    :goto_0
    if-ge v3, v2, :cond_0

    aget-object v4, v1, v3

    invoke-static {v4, v0}, Ljava/util/Arrays;->fill([BB)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final s(Lc/s0;I)V
    .locals 2

    iget-boolean v0, p0, Lc/g1;->J:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v0, p1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    iput-object p1, p0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result p1

    invoke-virtual {p0, p2, v1, p1}, Lc/g1;->v(IFF)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/g1;->M:Z

    iget-object p1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x2

    if-ne p2, v1, :cond_1

    const-string p2, "\u0421\u0442\u0440\u0435\u043b\u043a\u0438 \u2014 \u0440\u0430\u0437\u043c\u0435\u0440, \u043d\u0430\u0436\u0430\u0442\u0438\u0435 \u2014 \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c, \u041d\u0430\u0437\u0430\u0434 \u2014 \u043e\u0442\u043c\u0435\u043d\u0438\u0442\u044c"

    goto :goto_0

    :cond_1
    const-string p2, "\u0421\u0442\u0440\u0435\u043b\u043a\u0438 \u2014 \u043f\u0435\u0440\u0435\u043c\u0435\u0449\u0435\u043d\u0438\u0435, \u043d\u0430\u0436\u0430\u0442\u0438\u0435 \u2014 \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c, \u041d\u0430\u0437\u0430\u0434 \u2014 \u043e\u0442\u043c\u0435\u043d\u0438\u0442\u044c"

    :goto_0
    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    invoke-static {v0, p1, p2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_1
    return-void
.end method

.method public final t(Lc/u0;Z)V
    .locals 2

    iget-boolean v0, p0, Lc/g1;->Y:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/g1;->F:Lc/o0;

    iget-boolean v0, v0, Lc/o0;->g:Z

    iget-object v1, p0, Lc/g1;->b:Lc/n1;

    invoke-virtual {v1, p1, v0, p2}, Lc/n1;->B0(Lc/u0;ZZ)Z

    move-result p2

    if-eqz p2, :cond_1

    iput-object p1, p0, Lc/g1;->C:Lc/u0;

    iget-object p1, p0, Lc/g1;->c:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442\u044b"

    invoke-static {p1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-static {p2, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_0
    return-void
.end method

.method public final u()V
    .locals 15

    const/4 v0, 0x0

    iget-object v1, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    new-instance v4, Ljava/util/ArrayList;

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    sget-object v5, Lc/s0;->m:Lc/s0;

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    sget-object v6, Lc/s0;->i:Lc/s0;

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v6

    const/4 v7, 0x1

    add-int/2addr v6, v7

    invoke-virtual {v4, v6, v5}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/s0;

    sget-object v6, Lc/s0;->f:Lc/s0;

    if-ne v5, v6, :cond_1

    goto :goto_0

    :cond_1
    iget-object v6, p0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v6, v5}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v6

    if-eqz v6, :cond_2

    iget-boolean v6, v6, Lc/r0;->g:Z

    if-eqz v6, :cond_0

    :cond_2
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    new-instance v4, Lc/f1;

    invoke-direct {v4, p0, v3, v2}, Lc/f1;-><init>(Lc/g1;Ljava/util/ArrayList;Lc/r4;)V

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v6, Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-direct {v6, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v8, 0x10

    invoke-virtual {v6, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v8, 0x41a00000    # 20.0f

    invoke-virtual {p0, v8}, Lc/g1;->h(F)F

    move-result v9

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    const/high16 v10, 0x40800000    # 4.0f

    invoke-virtual {p0, v10}, Lc/g1;->h(F)F

    move-result v11

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {p0, v12}, Lc/g1;->h(F)F

    move-result v12

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    invoke-virtual {p0, v10}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    invoke-virtual {v6, v9, v11, v12, v10}, Landroid/view/View;->setPadding(IIII)V

    new-instance v9, Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-direct {v9, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    const-string v11, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-static {v10, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextSize(F)V

    iget v8, v2, Lc/r4;->d:I

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v8, 0x0

    invoke-virtual {v9, v8, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v10, v0, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v9, Landroid/widget/ImageButton;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-direct {v9, v10}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    const v10, 0x1080038

    invoke-virtual {v9, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v10, v2, Lc/r4;->d:I

    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v9, v0}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    const-string v13, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v10, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v10, Lc/c;

    const/4 v13, 0x5

    invoke-direct {v10, p0, v13}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {p0}, Lc/g1;->x()F

    move-result v13

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-virtual {p0}, Lc/g1;->x()F

    move-result v14

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    invoke-direct {v10, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v6, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    invoke-direct {v6, v9}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lc/r4;->a()I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {p0, v12}, Lc/g1;->h(F)F

    move-result v10

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    const/4 v13, -0x1

    invoke-direct {v9, v13, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v6, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Landroid/app/AlertDialog$Builder;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    iget-boolean v10, v2, Lc/r4;->m:Z

    if-eqz v10, :cond_4

    const v10, 0x7f050005

    goto :goto_1

    :cond_4
    sget-object v10, Lc/r4;->p:Lc/r4;

    if-ne v2, v10, :cond_5

    const v10, 0x7f050003

    goto :goto_1

    :cond_5
    const v10, 0x7f050004

    :goto_1
    invoke-direct {v6, v9, v10}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v6, v5}, Landroid/app/AlertDialog$Builder;->setCustomTitle(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    invoke-virtual {v5, v4, v8}, Landroid/app/AlertDialog$Builder;->setAdapter(Landroid/widget/ListAdapter;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v6, "\u0413\u043e\u0442\u043e\u0432\u043e"

    invoke-static {v1, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v1

    iput-object v1, p0, Lc/g1;->W:Landroid/app/AlertDialog;

    invoke-virtual {v1, v7}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    new-instance v5, Lc/c1;

    invoke-direct {v5, p0, v1, v0}, Lc/c1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v5}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-virtual {v1}, Landroid/app/Dialog;->show()V

    invoke-virtual {v1, v11}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v5

    invoke-static {v5, v2, v7}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance v5, Landroid/graphics/drawable/LayerDrawable;

    new-instance v6, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v2}, Lc/r4;->a()I

    move-result v2

    invoke-direct {v6, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    new-array v2, v7, [Landroid/graphics/drawable/Drawable;

    aput-object v6, v2, v0

    invoke-direct {v5, v2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, v12}, Lc/g1;->h(F)F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-virtual {v5, v0, v2}, Landroid/graphics/drawable/LayerDrawable;->setLayerHeight(II)V

    const/16 v2, 0x30

    invoke-virtual {v5, v0, v2}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    invoke-virtual {v1, v11}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    check-cast v2, Landroid/view/View;

    invoke-virtual {v2, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1}, Landroid/app/AlertDialog;->getListView()Landroid/widget/ListView;

    move-result-object v2

    const/high16 v5, 0x41400000    # 12.0f

    invoke-virtual {p0, v5}, Lc/g1;->h(F)F

    move-result v6

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {p0, v5}, Lc/g1;->h(F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v2, v0, v6, v0, v5}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v1}, Landroid/app/AlertDialog;->getListView()Landroid/widget/ListView;

    move-result-object v0

    new-instance v1, Lc/d1;

    invoke-direct {v1, p0, v3, v4}, Lc/d1;-><init>(Lc/g1;Ljava/util/ArrayList;Lc/f1;)V

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    return-void
.end method

.method public final v(IFF)V
    .locals 0

    invoke-virtual {p0}, Lc/g1;->r()V

    iput p1, p0, Lc/g1;->N:I

    iput p2, p0, Lc/g1;->R:F

    iput p2, p0, Lc/g1;->P:F

    iput p3, p0, Lc/g1;->S:F

    iput p3, p0, Lc/g1;->Q:F

    iget-object p1, p0, Lc/g1;->k:Lc/M3;

    iget-object p1, p1, Lc/M3;->a:Lc/P3;

    iget p1, p1, Lc/P3;->D:F

    iput p1, p0, Lc/g1;->T:F

    iget-object p1, p0, Lc/g1;->n:Ljava/util/EnumMap;

    iget-object p2, p0, Lc/g1;->H:Lc/s0;

    invoke-virtual {p1, p2}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    if-eqz p1, :cond_0

    iget-object p2, p0, Lc/g1;->B:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object p2, p0, Lc/g1;->A:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_0
    return-void
.end method

.method public final w(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V
    .locals 2

    iget-object v0, p0, Lc/g1;->l:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v1, 0x40000000    # 2.0f

    invoke-virtual {p0, v1}, Lc/g1;->h(F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setColor(I)V

    const/4 p3, 0x0

    if-eqz p4, :cond_0

    iget-object p4, p0, Lc/g1;->m:Landroid/graphics/DashPathEffect;

    goto :goto_0

    :cond_0
    move-object p4, p3

    :goto_0
    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    const/high16 p4, 0x41800000    # 16.0f

    invoke-virtual {p0, p4}, Lc/g1;->h(F)F

    move-result v1

    invoke-virtual {p0, p4}, Lc/g1;->h(F)F

    move-result p4

    invoke-virtual {p1, p2, v1, p4, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    sget-object p1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method

.method public final x()F
    .locals 2

    iget-object v0, p0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v0, v1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    return v0
.end method

.method public final y(Z)V
    .locals 36

    move-object/from16 v0, p0

    const/4 v1, 0x0

    iput-object v1, v0, Lc/g1;->D:Lc/u0;

    iput-object v1, v0, Lc/g1;->E:Lc/r0;

    iget-object v2, v0, Lc/g1;->F:Lc/o0;

    iget-object v2, v2, Lc/o0;->c:Lc/m0;

    iget v3, v0, Lc/g1;->R:F

    iget v4, v0, Lc/g1;->S:F

    invoke-virtual {v2, v3, v4}, Lc/m0;->a(FF)Z

    move-result v2

    if-eqz v2, :cond_39

    iget-object v2, v0, Lc/g1;->H:Lc/s0;

    if-nez v2, :cond_0

    goto/16 :goto_21

    :cond_0
    iget-object v3, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v3, v2}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v2

    iget-object v3, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v3, v3, Lc/o0;->f:Z

    iget-object v4, v0, Lc/g1;->A:Landroid/graphics/RectF;

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/high16 v8, 0x3f800000    # 1.0f

    const/high16 v9, 0x40000000    # 2.0f

    iget-object v10, v0, Lc/g1;->k:Lc/M3;

    if-eqz v3, :cond_a

    iget v3, v0, Lc/g1;->N:I

    if-ne v3, v6, :cond_3

    iget v1, v0, Lc/g1;->S:F

    iget-object v2, v10, Lc/M3;->a:Lc/P3;

    iget v2, v2, Lc/P3;->D:F

    add-float/2addr v1, v2

    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    iget-object v2, v2, Lc/u0;->d:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v11, 0x0

    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/r0;

    iget-boolean v4, v3, Lc/r0;->g:Z

    if-nez v4, :cond_1

    iget-object v4, v0, Lc/g1;->H:Lc/s0;

    iget-object v3, v3, Lc/r0;->a:Lc/s0;

    if-eq v3, v4, :cond_1

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget-object v4, v4, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v4, v3}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/m0;

    if-eqz v3, :cond_1

    iget v4, v3, Lc/m0;->b:F

    iget v3, v3, Lc/m0;->d:F

    add-float/2addr v4, v3

    div-float/2addr v4, v9

    cmpl-float v3, v1, v4

    if-ltz v3, :cond_1

    add-int/lit8 v11, v11, 0x1

    goto :goto_0

    :cond_2
    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    iget-object v2, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v1, v2, v11}, Lc/u0;->q(Lc/s0;I)Lc/u0;

    move-result-object v1

    iput-object v1, v0, Lc/g1;->D:Lc/u0;

    goto/16 :goto_4

    :cond_3
    if-ne v3, v5, :cond_9

    iget-object v3, v2, Lc/r0;->a:Lc/s0;

    invoke-virtual {v3}, Lc/s0;->b()I

    move-result v3

    iget-object v5, v0, Lc/g1;->F:Lc/o0;

    iget v5, v5, Lc/o0;->h:I

    invoke-virtual {v0, v8}, Lc/g1;->h(F)F

    move-result v6

    iget v8, v2, Lc/r0;->f:I

    const v7, 0x7f7fffff    # Float.MAX_VALUE

    :goto_1
    iget v9, v2, Lc/r0;->e:I

    if-gt v3, v5, :cond_6

    invoke-virtual {v2, v9, v3}, Lc/r0;->c(II)Lc/r0;

    move-result-object v10

    invoke-static {v10, v6}, Lc/G8;->U(Lc/r0;F)F

    move-result v10

    invoke-virtual {v2, v9, v3}, Lc/r0;->c(II)Lc/r0;

    move-result-object v9

    invoke-virtual {v0, v9}, Lc/g1;->e(Lc/r0;)Z

    move-result v9

    if-nez v9, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v9

    sub-float/2addr v10, v9

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v9

    cmpg-float v10, v9, v7

    if-gez v10, :cond_5

    move v8, v3

    move v7, v9

    :cond_5
    :goto_2
    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_6
    invoke-virtual {v2, v9, v8}, Lc/r0;->c(II)Lc/r0;

    move-result-object v3

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget v4, v4, Lc/o0;->h:I

    sub-int/2addr v4, v8

    iget v5, v2, Lc/r0;->d:I

    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget v2, v2, Lc/r0;->c:I

    invoke-virtual {v3, v2, v4}, Lc/r0;->a(II)Lc/r0;

    move-result-object v2

    iput-object v2, v0, Lc/g1;->E:Lc/r0;

    if-eqz p1, :cond_7

    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-static {v1, v2}, Lc/G8;->r0(Lc/u0;Lc/r0;)Lc/u0;

    move-result-object v1

    goto :goto_3

    :cond_7
    iget-object v3, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v3, v2}, Lc/u0;->a(Lc/r0;)Z

    move-result v3

    if-eqz v3, :cond_8

    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v1, v2}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    :cond_8
    :goto_3
    iput-object v1, v0, Lc/g1;->D:Lc/u0;

    :cond_9
    :goto_4
    return-void

    :cond_a
    iget v3, v0, Lc/g1;->N:I

    if-ne v3, v5, :cond_31

    iget-object v3, v2, Lc/r0;->a:Lc/s0;

    invoke-virtual {v3}, Lc/s0;->a()I

    move-result v3

    iget-object v5, v2, Lc/r0;->a:Lc/s0;

    invoke-virtual {v5}, Lc/s0;->b()I

    move-result v9

    iget-object v13, v0, Lc/g1;->F:Lc/o0;

    iget v14, v13, Lc/o0;->h:I

    iget v15, v4, Landroid/graphics/RectF;->left:F

    iget v1, v4, Landroid/graphics/RectF;->top:F

    iget-object v7, v10, Lc/M3;->a:Lc/P3;

    iget v7, v7, Lc/P3;->D:F

    add-float/2addr v1, v7

    iget v11, v4, Landroid/graphics/RectF;->right:F

    iget v12, v4, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v12, v7

    invoke-virtual {v13, v15, v1}, Lc/o0;->d(FF)Lc/n0;

    move-result-object v7

    sub-float/2addr v11, v8

    invoke-static {v15, v11}, Ljava/lang/Math;->max(FF)F

    move-result v11

    sub-float/2addr v12, v8

    invoke-static {v1, v12}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {v13, v11, v1}, Lc/o0;->d(FF)Lc/n0;

    move-result-object v1

    iget v8, v7, Lc/n0;->a:I

    iget v11, v1, Lc/n0;->a:I

    invoke-static {v8, v11}, Ljava/lang/Math;->min(II)I

    move-result v12

    iget v7, v7, Lc/n0;->b:I

    iget v1, v1, Lc/n0;->b:I

    invoke-static {v7, v1}, Ljava/lang/Math;->min(II)I

    move-result v13

    invoke-static {v8, v11}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget v7, v0, Lc/g1;->R:F

    iget v11, v0, Lc/g1;->P:F

    sub-float/2addr v7, v11

    iget v11, v0, Lc/g1;->S:F

    iget v15, v0, Lc/g1;->Q:F

    sub-float/2addr v11, v15

    iget-object v15, v0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v15

    invoke-static {v15}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v15

    invoke-virtual {v15}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v15

    int-to-float v15, v15

    iget v6, v0, Lc/g1;->O:I

    if-eqz v6, :cond_c

    and-int/lit8 v6, v6, 0xc

    if-nez v6, :cond_b

    :goto_5
    move-object/from16 v18, v10

    const/4 v6, 0x1

    goto :goto_6

    :cond_b
    move-object/from16 v18, v10

    const/4 v6, 0x0

    goto :goto_6

    :cond_c
    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v6

    cmpl-float v6, v6, v15

    if-lez v6, :cond_b

    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v6

    cmpg-float v6, v6, v15

    if-gtz v6, :cond_b

    goto :goto_5

    :goto_6
    iget v10, v0, Lc/g1;->O:I

    if-eqz v10, :cond_e

    and-int/lit8 v7, v10, 0x3

    if-nez v7, :cond_d

    :goto_7
    const/4 v7, 0x1

    goto :goto_8

    :cond_d
    const/4 v7, 0x0

    goto :goto_8

    :cond_e
    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v10

    cmpl-float v10, v10, v15

    if-lez v10, :cond_d

    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v7

    cmpg-float v7, v7, v15

    if-gtz v7, :cond_d

    goto :goto_7

    :goto_8
    sub-int v10, v8, v12

    const/4 v11, 0x1

    add-int/2addr v10, v11

    const/16 v15, 0x1e

    invoke-static {v15, v10}, Ljava/lang/Math;->min(II)I

    move-result v10

    invoke-static {v3, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    sub-int v15, v1, v13

    add-int/2addr v15, v11

    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    move-result v11

    invoke-static {v9, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    iget v15, v2, Lc/r0;->f:I

    move/from16 v19, v3

    if-eqz v6, :cond_f

    move v11, v15

    :cond_f
    iget v3, v2, Lc/r0;->e:I

    if-eqz v7, :cond_10

    move v10, v3

    :cond_10
    move/from16 v20, v9

    iget v9, v0, Lc/g1;->O:I

    and-int/lit8 v21, v9, 0x1

    if-eqz v21, :cond_11

    const/16 v21, 0x1

    goto :goto_9

    :cond_11
    const/16 v21, 0x0

    :goto_9
    and-int/lit8 v22, v9, 0x2

    move/from16 v23, v12

    if-eqz v22, :cond_12

    const/16 v22, 0x1

    goto :goto_a

    :cond_12
    const/16 v22, 0x0

    :goto_a
    sget-object v12, Lc/Q1;->b:Lc/Q1;

    move/from16 v24, v13

    iget v13, v2, Lc/r0;->d:I

    move/from16 v25, v14

    iget v14, v2, Lc/r0;->c:I

    if-nez v9, :cond_16

    iget-object v1, v0, Lc/g1;->F:Lc/o0;

    iget-object v1, v1, Lc/o0;->j:Lc/Q1;

    if-ne v1, v12, :cond_13

    sub-int/2addr v8, v10

    const/4 v1, 0x1

    add-int/2addr v1, v8

    goto :goto_b

    :cond_13
    move/from16 v1, v23

    :goto_b
    if-nez v6, :cond_14

    if-eqz v7, :cond_15

    :cond_14
    move/from16 v24, v13

    :cond_15
    move-object/from16 v26, v4

    goto :goto_f

    :cond_16
    if-eqz v21, :cond_19

    if-nez v22, :cond_19

    move-object/from16 v26, v4

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget-object v4, v4, Lc/o0;->j:Lc/Q1;

    if-ne v4, v12, :cond_18

    :cond_17
    sub-int/2addr v8, v10

    const/4 v4, 0x1

    add-int/2addr v8, v4

    goto :goto_d

    :cond_18
    :goto_c
    move/from16 v8, v23

    goto :goto_d

    :cond_19
    move-object/from16 v26, v4

    if-eqz v22, :cond_1a

    if-nez v21, :cond_1a

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget-object v4, v4, Lc/o0;->j:Lc/Q1;

    if-ne v4, v12, :cond_17

    goto :goto_c

    :cond_1a
    move v8, v14

    :goto_d
    and-int/lit8 v4, v9, 0x4

    if-eqz v4, :cond_1b

    :goto_e
    move v1, v8

    goto :goto_f

    :cond_1b
    and-int/lit8 v4, v9, 0x8

    if-eqz v4, :cond_1c

    sub-int/2addr v1, v11

    const/4 v4, 0x1

    add-int/2addr v1, v4

    move/from16 v24, v1

    goto :goto_e

    :cond_1c
    move v1, v8

    move/from16 v24, v13

    :goto_f
    if-eqz v6, :cond_1d

    move v4, v13

    goto :goto_10

    :cond_1d
    move/from16 v4, v24

    :goto_10
    if-eqz v7, :cond_1e

    move v1, v14

    :cond_1e
    rsub-int/lit8 v8, v10, 0x1e

    invoke-static {v8, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v8, 0x0

    invoke-static {v8, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object v9, v0, Lc/g1;->F:Lc/o0;

    iget v9, v9, Lc/o0;->h:I

    sub-int/2addr v9, v11

    invoke-static {v9, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    if-eqz v7, :cond_1f

    move/from16 v19, v3

    :cond_1f
    if-eqz v7, :cond_20

    move v7, v3

    goto :goto_11

    :cond_20
    const/16 v7, 0x1e

    :goto_11
    sget-object v8, Lc/s0;->h:Lc/s0;

    sget-object v9, Lc/s0;->k:Lc/s0;

    if-eqz v6, :cond_21

    if-eq v5, v9, :cond_21

    if-eq v5, v8, :cond_21

    move/from16 v20, v11

    :cond_21
    if-eqz v6, :cond_22

    if-eq v5, v9, :cond_22

    if-eq v5, v8, :cond_22

    move/from16 v17, v1

    move v1, v11

    goto :goto_12

    :cond_22
    move/from16 v17, v1

    move/from16 v1, v25

    :goto_12
    move/from16 v28, v4

    move/from16 v27, v17

    const v16, 0x7f7fffff    # Float.MAX_VALUE

    move/from16 v4, v19

    move/from16 v19, v28

    :goto_13
    if-gt v4, v7, :cond_2e

    move/from16 v23, v7

    move/from16 v7, v20

    :goto_14
    move/from16 v24, v1

    if-gt v7, v1, :cond_2d

    iget v1, v0, Lc/g1;->O:I

    move/from16 v25, v10

    if-nez v1, :cond_23

    move/from16 v10, v17

    goto :goto_16

    :cond_23
    iget-object v10, v0, Lc/g1;->F:Lc/o0;

    iget-object v10, v10, Lc/o0;->j:Lc/Q1;

    if-ne v10, v12, :cond_24

    if-eqz v22, :cond_25

    goto :goto_15

    :cond_24
    if-eqz v21, :cond_25

    :goto_15
    add-int v10, v14, v3

    sub-int/2addr v10, v4

    goto :goto_16

    :cond_25
    move v10, v14

    :goto_16
    if-nez v1, :cond_26

    move/from16 v1, v19

    goto :goto_17

    :cond_26
    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_27

    add-int v1, v13, v15

    sub-int/2addr v1, v7

    goto :goto_17

    :cond_27
    move v1, v13

    :goto_17
    move/from16 v29, v3

    rsub-int/lit8 v3, v4, 0x1e

    invoke-static {v3, v10}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v10, 0x0

    invoke-static {v10, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget-object v10, v0, Lc/g1;->F:Lc/o0;

    iget v10, v10, Lc/o0;->h:I

    sub-int/2addr v10, v7

    invoke-static {v10, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v10, 0x0

    invoke-static {v10, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object v10, v0, Lc/g1;->F:Lc/o0;

    move/from16 v30, v11

    invoke-virtual {v2, v4, v7}, Lc/r0;->c(II)Lc/r0;

    move-result-object v11

    invoke-virtual {v11, v3, v1}, Lc/r0;->a(II)Lc/r0;

    move-result-object v11

    invoke-virtual {v10, v11}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v10

    invoke-virtual {v2, v4, v7}, Lc/r0;->c(II)Lc/r0;

    move-result-object v11

    invoke-virtual {v11, v3, v1}, Lc/r0;->a(II)Lc/r0;

    move-result-object v11

    invoke-virtual {v0, v11}, Lc/g1;->e(Lc/r0;)Z

    move-result v11

    if-nez v11, :cond_28

    move-object/from16 v32, v5

    move-object/from16 v34, v8

    move-object/from16 v33, v9

    move-object/from16 v9, v18

    move-object/from16 v3, v26

    move/from16 v18, v6

    goto/16 :goto_1b

    :cond_28
    iget v11, v10, Lc/m0;->c:F

    move/from16 v31, v1

    iget v1, v10, Lc/m0;->a:F

    if-eqz v6, :cond_2b

    if-eq v5, v9, :cond_29

    if-ne v5, v8, :cond_2a

    :cond_29
    move-object/from16 v10, v26

    move/from16 v26, v3

    goto :goto_18

    :cond_2a
    move-object/from16 v32, v5

    move-object/from16 v35, v26

    move/from16 v26, v3

    move-object/from16 v3, v35

    goto :goto_19

    :goto_18
    iget v3, v10, Landroid/graphics/RectF;->left:F

    sub-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v3, v10, Landroid/graphics/RectF;->right:F

    sub-float/2addr v11, v3

    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v3

    add-float/2addr v3, v1

    int-to-float v1, v7

    const v11, 0x3c23d70a    # 0.01f

    mul-float/2addr v1, v11

    add-float/2addr v1, v3

    move-object/from16 v32, v5

    move-object/from16 v34, v8

    move-object/from16 v33, v9

    move-object v3, v10

    move-object/from16 v9, v18

    move/from16 v18, v6

    goto :goto_1a

    :cond_2b
    move-object/from16 v35, v26

    move/from16 v26, v3

    move-object/from16 v3, v35

    move-object/from16 v32, v5

    :goto_19
    iget v5, v3, Landroid/graphics/RectF;->left:F

    sub-float/2addr v1, v5

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v5, v3, Landroid/graphics/RectF;->top:F

    move-object/from16 v33, v9

    move-object/from16 v9, v18

    move/from16 v18, v6

    iget-object v6, v9, Lc/M3;->a:Lc/P3;

    move-object/from16 v34, v8

    iget v8, v6, Lc/P3;->D:F

    add-float/2addr v5, v8

    iget v8, v10, Lc/m0;->b:F

    sub-float/2addr v8, v5

    invoke-static {v8}, Ljava/lang/Math;->abs(F)F

    move-result v5

    add-float/2addr v5, v1

    iget v1, v3, Landroid/graphics/RectF;->right:F

    sub-float/2addr v11, v1

    invoke-static {v11}, Ljava/lang/Math;->abs(F)F

    move-result v1

    add-float/2addr v1, v5

    iget v5, v3, Landroid/graphics/RectF;->bottom:F

    iget v6, v6, Lc/P3;->D:F

    add-float/2addr v5, v6

    iget v6, v10, Lc/m0;->d:F

    sub-float/2addr v6, v5

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v5

    add-float/2addr v1, v5

    :goto_1a
    cmpg-float v5, v1, v16

    if-gez v5, :cond_2c

    move/from16 v16, v1

    move v10, v4

    move v11, v7

    move/from16 v27, v26

    move/from16 v28, v31

    goto :goto_1c

    :cond_2c
    :goto_1b
    move/from16 v10, v25

    move/from16 v11, v30

    :goto_1c
    add-int/lit8 v7, v7, 0x1

    move-object/from16 v26, v3

    move/from16 v6, v18

    move/from16 v1, v24

    move/from16 v3, v29

    move-object/from16 v5, v32

    move-object/from16 v8, v34

    move-object/from16 v18, v9

    move-object/from16 v9, v33

    goto/16 :goto_14

    :cond_2d
    move/from16 v29, v3

    move-object/from16 v32, v5

    move-object/from16 v34, v8

    move-object/from16 v33, v9

    move/from16 v25, v10

    move/from16 v30, v11

    move-object/from16 v9, v18

    move-object/from16 v3, v26

    move/from16 v18, v6

    add-int/lit8 v4, v4, 0x1

    move/from16 v7, v23

    move/from16 v3, v29

    move-object/from16 v18, v9

    move-object/from16 v9, v33

    goto/16 :goto_13

    :cond_2e
    const v1, 0x7f7fffff    # Float.MAX_VALUE

    cmpl-float v1, v16, v1

    if-nez v1, :cond_30

    :cond_2f
    const/4 v1, 0x0

    goto/16 :goto_1f

    :cond_30
    invoke-virtual {v2, v10, v11}, Lc/r0;->c(II)Lc/r0;

    move-result-object v1

    move/from16 v2, v27

    move/from16 v4, v28

    invoke-virtual {v1, v2, v4}, Lc/r0;->a(II)Lc/r0;

    move-result-object v1

    goto/16 :goto_1f

    :cond_31
    move-object v3, v4

    move v1, v9

    move-object v9, v10

    invoke-virtual {v0, v2}, Lc/g1;->e(Lc/r0;)Z

    move-result v4

    if-eqz v4, :cond_2f

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {v3}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    iget-object v6, v9, Lc/M3;->a:Lc/P3;

    iget v6, v6, Lc/P3;->D:F

    add-float/2addr v3, v6

    const/4 v6, 0x0

    invoke-virtual {v2, v6, v6}, Lc/r0;->a(II)Lc/r0;

    move-result-object v7

    invoke-virtual {v4, v7}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v7

    const/4 v8, 0x1

    invoke-virtual {v4, v8}, Lc/o0;->b(I)F

    move-result v9

    invoke-virtual {v4, v6}, Lc/o0;->b(I)F

    move-result v10

    sub-float/2addr v9, v10

    iget-object v6, v4, Lc/o0;->c:Lc/m0;

    iget v10, v4, Lc/o0;->l:F

    iget v11, v4, Lc/o0;->h:I

    iget v4, v4, Lc/o0;->i:F

    if-ne v8, v11, :cond_32

    move v12, v4

    goto :goto_1d

    :cond_32
    int-to-float v8, v8

    add-float v12, v4, v10

    mul-float/2addr v12, v8

    int-to-float v8, v11

    div-float/2addr v12, v8

    :goto_1d
    iget v6, v6, Lc/m0;->b:F

    add-float/2addr v12, v6

    if-nez v11, :cond_33

    goto :goto_1e

    :cond_33
    const/4 v8, 0x0

    int-to-float v13, v8

    add-float/2addr v4, v10

    mul-float/2addr v4, v13

    int-to-float v8, v11

    div-float/2addr v4, v8

    :goto_1e
    add-float/2addr v6, v4

    sub-float/2addr v12, v6

    iget v4, v7, Lc/m0;->a:F

    iget v6, v7, Lc/m0;->c:F

    add-float/2addr v4, v6

    div-float/2addr v4, v1

    sub-float/2addr v5, v4

    div-float/2addr v5, v9

    const/high16 v4, 0x3f000000    # 0.5f

    sub-float/2addr v5, v4

    float-to-double v5, v5

    invoke-static {v5, v6}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v5

    double-to-int v5, v5

    iget v6, v7, Lc/m0;->b:F

    iget v7, v7, Lc/m0;->d:F

    add-float/2addr v6, v7

    div-float/2addr v6, v1

    sub-float/2addr v3, v6

    div-float/2addr v3, v12

    sub-float/2addr v3, v4

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-int v1, v3

    iget v3, v2, Lc/r0;->e:I

    const/16 v4, 0x1e

    rsub-int/lit8 v12, v3, 0x1e

    invoke-static {v12, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget v5, v2, Lc/r0;->f:I

    sub-int/2addr v11, v5

    invoke-static {v11, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v2, v3, v1}, Lc/r0;->a(II)Lc/r0;

    move-result-object v1

    :goto_1f
    if-nez v1, :cond_34

    return-void

    :cond_34
    iput-object v1, v0, Lc/g1;->E:Lc/r0;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget v3, v1, Lc/r0;->c:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v1, Lc/r0;->d:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v1, Lc/r0;->e:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v1, Lc/r0;->f:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    if-nez p1, :cond_35

    iget-object v3, v0, Lc/g1;->U:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_35

    iget-object v1, v0, Lc/g1;->Z:Lc/u0;

    iput-object v1, v0, Lc/g1;->D:Lc/u0;

    return-void

    :cond_35
    iput-object v2, v0, Lc/g1;->U:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/g1;->e(Lc/r0;)Z

    move-result v2

    if-nez v2, :cond_37

    :cond_36
    const/4 v1, 0x0

    goto :goto_20

    :cond_37
    if-eqz p1, :cond_38

    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-static {v2, v1}, Lc/G8;->r0(Lc/u0;Lc/r0;)Lc/u0;

    move-result-object v1

    goto :goto_20

    :cond_38
    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v2, v1}, Lc/u0;->a(Lc/r0;)Z

    move-result v2

    if-eqz v2, :cond_36

    iget-object v2, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v2, v1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    :goto_20
    iput-object v1, v0, Lc/g1;->D:Lc/u0;

    iput-object v1, v0, Lc/g1;->Z:Lc/u0;

    :cond_39
    :goto_21
    return-void
.end method

.method public final z()V
    .locals 9

    iget-object v0, p0, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-virtual {v0}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->clear()V

    iget-object v1, p0, Lc/g1;->r:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->s:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->t:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->u:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->v:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->z:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, p0, Lc/g1;->F:Lc/o0;

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v1, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v1}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    iget-object v3, p0, Lc/g1;->C:Lc/u0;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/s0;

    invoke-virtual {v3, v4}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v3

    if-eqz v3, :cond_1

    iget-boolean v3, v3, Lc/r0;->g:Z

    if-eqz v3, :cond_2

    goto :goto_0

    :cond_2
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/m0;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/s0;

    new-instance v4, Landroid/graphics/RectF;

    iget v5, v3, Lc/m0;->a:F

    iget-object v6, p0, Lc/g1;->k:Lc/M3;

    iget-object v6, v6, Lc/M3;->a:Lc/P3;

    iget v6, v6, Lc/P3;->D:F

    iget v7, v3, Lc/m0;->b:F

    sub-float/2addr v7, v6

    iget v8, v3, Lc/m0;->d:F

    sub-float/2addr v8, v6

    iget v3, v3, Lc/m0;->c:F

    invoke-direct {v4, v5, v7, v3, v8}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v0, v2, v4}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_3
    return-void
.end method
