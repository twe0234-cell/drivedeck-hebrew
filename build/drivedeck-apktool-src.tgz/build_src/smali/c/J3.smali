.class public final synthetic Lc/J3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic a:Lc/P3;

.field public final synthetic b:[Z

.field public final synthetic c:Z

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lc/P3;[ZZI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J3;->a:Lc/P3;

    iput-object p2, p0, Lc/J3;->b:[Z

    iput-boolean p3, p0, Lc/J3;->c:Z

    iput p4, p0, Lc/J3;->d:I

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 5

    iget-object p1, p0, Lc/J3;->a:Lc/P3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/J3;->b:[Z

    const/4 v1, 0x0

    aget-boolean v0, v0, v1

    if-nez v0, :cond_0

    sget-object v0, Lc/s0;->h:Lc/s0;

    iget-object v1, p1, Lc/P3;->C1:Lc/n1;

    iget-object v2, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "widget_background_APPS"

    iget-boolean v4, p0, Lc/J3;->c:Z

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget v2, p0, Lc/J3;->d:I

    invoke-virtual {v1, v0, v2}, Lc/n1;->X0(Lc/s0;I)V

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_0
    return-void
.end method
