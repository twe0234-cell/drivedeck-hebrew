.class public final synthetic Lc/h5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/u0;

.field public final synthetic b:I

.field public final synthetic c:I

.field public final synthetic d:J

.field public final synthetic e:Lc/y4;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/u0;IIJLc/y4;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/h5;->a:Lc/u0;

    iput p2, p0, Lc/h5;->b:I

    iput p3, p0, Lc/h5;->c:I

    iput-wide p4, p0, Lc/h5;->d:J

    iput-object p6, p0, Lc/h5;->e:Lc/y4;

    iput-object p7, p0, Lc/h5;->f:Ljava/lang/String;

    iput-object p8, p0, Lc/h5;->g:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/h5;->c:I

    iget-wide v1, p0, Lc/h5;->d:J

    iget-object v3, p0, Lc/h5;->a:Lc/u0;

    iget v4, p0, Lc/h5;->b:I

    invoke-virtual {v3, v4, v0, v1, v2}, Lc/u0;->n(IIJ)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v3}, Lc/u0;->b()V

    iget-object v0, p0, Lc/h5;->f:Ljava/lang/String;

    iget-object v1, p0, Lc/h5;->g:Ljava/lang/String;

    invoke-virtual {v3, v0, v1}, Lc/u0;->h(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iget-object v1, p0, Lc/h5;->e:Lc/y4;

    invoke-virtual {v1, v0}, Lc/y4;->accept(Ljava/lang/Object;)V

    :goto_0
    return-void
.end method
