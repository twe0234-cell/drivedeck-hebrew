.class public final synthetic Lc/C7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lc/O7;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:I

.field public final synthetic d:Lc/y7;

.field public final synthetic e:Z


# direct methods
.method public synthetic constructor <init>(Lc/O7;Ljava/lang/String;ILc/y7;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/C7;->a:Lc/O7;

    iput-object p2, p0, Lc/C7;->b:Ljava/lang/String;

    iput p3, p0, Lc/C7;->c:I

    iput-object p4, p0, Lc/C7;->d:Lc/y7;

    iput-boolean p5, p0, Lc/C7;->e:Z

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 19

    move-object/from16 v0, p0

    const/4 v2, 0x0

    const/4 v3, 0x1

    move-object/from16 v4, p1

    check-cast v4, Ljava/util/List;

    iget-object v12, v0, Lc/C7;->a:Lc/O7;

    iget-object v13, v0, Lc/C7;->b:Ljava/lang/String;

    iget v14, v0, Lc/C7;->c:I

    invoke-virtual {v12, v13, v14}, Lc/O7;->e(Ljava/lang/String;I)Z

    move-result v5

    if-nez v5, :cond_0

    goto/16 :goto_2

    :cond_0
    new-instance v5, Ljava/util/LinkedHashSet;

    invoke-direct {v5}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    iget-object v7, v0, Lc/C7;->d:Lc/y7;

    if-eqz v6, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/Q;

    iget-object v7, v7, Lc/y7;->a:Ljava/lang/String;

    iget-object v8, v6, Lc/Q;->a:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    iget-object v6, v6, Lc/Q;->b:Ljava/lang/String;

    invoke-static {v6}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_1

    invoke-virtual {v5, v6}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    iget-object v4, v7, Lc/y7;->b:Ljava/lang/String;

    invoke-static {v4}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_3

    invoke-virtual {v5, v4}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_3
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->size()I

    move-result v4

    iget-boolean v15, v0, Lc/C7;->e:Z

    if-ne v4, v3, :cond_4

    invoke-virtual {v5}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v12, v1, v13, v14, v15}, Lc/O7;->q(Ljava/lang/String;Ljava/lang/String;IZ)V

    goto/16 :goto_2

    :cond_4
    invoke-virtual {v5}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_5

    goto/16 :goto_2

    :cond_5
    new-instance v4, Landroid/app/Dialog;

    iget-object v11, v12, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v4, v11}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    iput-object v4, v12, Lc/O7;->r:Landroid/app/Dialog;

    invoke-static {v11}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v10

    const-string v6, "phone-number-choices"

    invoke-virtual {v10, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v9, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043d\u043e\u043c\u0435\u0440"

    invoke-static {v11, v9}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v8

    const-string v6, ""

    const/16 v1, 0x14

    invoke-virtual {v12, v1, v6, v3}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iget-object v6, v7, Lc/y7;->a:Ljava/lang/String;

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v5}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v5, v2

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    check-cast v7, Ljava/lang/String;

    invoke-static {v11, v7, v2}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v0, "phone-number-choice:"

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int/lit8 v0, v5, 0x1

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v2, 0x18

    const/16 v5, 0x12

    move/from16 p1, v0

    const/4 v0, 0x2

    invoke-virtual {v6, v5, v2, v3, v0}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    const/16 v0, 0x40

    invoke-virtual {v12, v0}, Lc/O7;->g(I)I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/16 v0, 0x10

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v0, 0x3

    invoke-virtual {v6, v0}, Landroid/view/View;->setTextDirection(I)V

    new-instance v0, Lc/D7;

    move-object v5, v0

    move-object v2, v6

    move-object v6, v12

    move-object/from16 v16, v7

    move-object v7, v13

    move-object v3, v8

    move v8, v14

    move-object/from16 v17, v1

    move-object v1, v9

    move-object/from16 v9, v16

    move-object/from16 v16, v13

    move-object v13, v10

    move v10, v15

    move/from16 v18, v14

    move-object v14, v11

    move-object v11, v4

    invoke-direct/range {v5 .. v11}, Lc/D7;-><init>(Lc/O7;Ljava/lang/String;ILjava/lang/String;ZLandroid/app/Dialog;)V

    invoke-virtual {v2, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v0, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v0, p0

    move/from16 v5, p1

    move-object v9, v1

    move-object v8, v3

    move-object v10, v13

    move-object v11, v14

    move-object/from16 v13, v16

    move-object/from16 v1, v17

    move/from16 v14, v18

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_1

    :cond_6
    move-object v3, v8

    move-object v1, v9

    move-object v13, v10

    move-object v14, v11

    const-string v0, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v2, 0x0

    invoke-static {v14, v0, v2}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    const-string v2, "phone-number-cancel"

    invoke-virtual {v0, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v2, Lc/a0;

    const/16 v5, 0xb

    invoke-direct {v2, v4, v5}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Lc/c1;

    const/4 v5, 0x2

    invoke-direct {v2, v12, v4, v5}, Lc/c1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v2}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-static {v14, v13, v3}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const/4 v2, 0x1

    new-array v2, v2, [Landroid/view/View;

    const/4 v3, 0x0

    aput-object v0, v2, v3

    invoke-static {v14, v2}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-static {v4, v14, v1, v13, v0}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    :goto_2
    return-void
.end method
