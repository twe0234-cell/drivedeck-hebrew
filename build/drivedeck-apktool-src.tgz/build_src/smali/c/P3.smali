.class public final Lc/P3;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Lc/q8;


# static fields
.field public static final X1:Landroid/graphics/Typeface;

.field public static final Y1:Landroid/graphics/Typeface;


# instance fields
.field public final A:Lc/g1;

.field public A0:F

.field public final A1:Lc/r3;

.field public B:Lc/U0;

.field public final B0:Landroid/graphics/RectF;

.field public B1:Lc/x3;

.field public C:Lc/A8;

.field public final C0:Landroid/graphics/RectF;

.field public final C1:Lc/n1;

.field public D:F

.field public final D0:Landroid/graphics/RectF;

.field public final D1:Landroid/graphics/RectF;

.field public E:F

.field public final E0:Landroid/graphics/RectF;

.field public final E1:Lc/O3;

.field public F:Z

.field public F0:Lc/V4;

.field public F1:F

.field public G:Z

.field public G0:Lc/V4;

.field public G1:F

.field public H:Z

.field public H0:J

.field public H1:J

.field public I:J

.field public final I0:Landroid/graphics/RectF;

.field public I1:Z

.field public J:Lc/m0;

.field public final J0:Landroid/graphics/RectF;

.field public J1:Z

.field public K:Lc/a5;

.field public final K0:Landroid/graphics/RectF;

.field public K1:Z

.field public final L:Landroid/graphics/RectF;

.field public final L0:Landroid/graphics/RectF;

.field public L1:Z

.field public final M:Landroid/graphics/Paint;

.field public final M0:[Landroid/graphics/RectF;

.field public final M1:Lc/b5;

.field public final N:Landroid/graphics/Paint;

.field public final N0:[Landroid/graphics/RectF;

.field public final N1:Lc/g5;

.field public final O:Landroid/graphics/Path;

.field public O0:I

.field public O1:Lc/s0;

.field public final P:Landroid/text/TextPaint;

.field public P0:I

.field public P1:Landroid/app/Dialog;

.field public final Q:Landroid/text/TextPaint;

.field public Q0:Z

.field public final Q1:Lc/F3;

.field public final R:Landroid/graphics/RectF;

.field public R0:Z

.field public R1:I

.field public final S:Landroid/graphics/RectF;

.field public final S0:Lc/y8;

.field public S1:I

.field public final T:Landroid/graphics/RectF;

.field public final T0:Lc/z8;

.field public T1:Z

.field public final U:Landroid/graphics/RectF;

.field public final U0:Lc/F3;

.field public U1:Z

.field public final V:Landroid/graphics/RectF;

.field public V0:Z

.field public V1:I

.field public final W:Landroid/graphics/RectF;

.field public final W0:Landroid/os/Handler;

.field public final W1:Landroid/graphics/Rect;

.field public final X0:Lc/o5;

.field public final Y0:Lc/e1;

.field public Z0:J

.field public a:Lc/W3;

.field public final a0:Lc/z;

.field public a1:Lc/w8;

.field public final b:Landroid/graphics/RectF;

.field public final b0:Lc/y;

.field public b1:Lc/E8;

.field public final c:Landroid/graphics/Path;

.field public c0:Lc/r4;

.field public c1:Landroid/media/session/MediaController;

.field public d:Z

.field public final d0:Ljava/util/ArrayList;

.field public d1:Landroid/media/MediaMetadata;

.field public e:Lc/u0;

.field public final e0:Ljava/util/ArrayList;

.field public e1:Landroid/media/session/PlaybackState;

.field public f:Lc/o0;

.field public final f0:Ljava/util/ArrayList;

.field public f1:Lc/V4;

.field public final g:Ljava/util/EnumMap;

.field public g0:Ljava/util/List;

.field public g1:Landroid/media/session/MediaSessionManager;

.field public final h:Lc/h0;

.field public h0:Lc/q5;

.field public h1:Ljava/util/List;

.field public final i:Lc/S;

.field public i0:Z

.field public final i1:Ljava/util/HashMap;

.field public final j:Landroid/graphics/RectF;

.field public j0:F

.field public j1:Z

.field public k:Z

.field public final k0:Lc/F3;

.field public k1:Z

.field public final l:Lc/B0;

.field public final l0:Lc/T4;

.field public final l1:Lc/L;

.field public final m:Lc/S0;

.field public final m0:Lc/B0;

.field public m1:Z

.field public final n:Lc/G0;

.field public final n0:Landroid/graphics/RectF;

.field public final n1:Lc/F3;

.field public final o:Lc/C0;

.field public o0:Z

.field public o1:Lc/w8;

.field public final p:Ljava/lang/Object;

.field public p0:Landroid/graphics/Bitmap;

.field public p1:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public q0:Ljava/lang/String;

.field public q1:Landroid/graphics/Bitmap;

.field public r:Z

.field public r0:Ljava/lang/String;

.field public r1:Ljava/lang/String;

.field public s:Landroid/graphics/drawable/Drawable;

.field public s0:Ljava/lang/String;

.field public s1:Landroid/graphics/Bitmap;

.field public t:Landroid/graphics/drawable/Drawable;

.field public t0:J

.field public final t1:Lc/g0;

.field public final u:Landroid/graphics/RectF;

.field public final u0:Ljava/util/EnumMap;

.field public final u1:Lc/g8;

.field public final v:Landroid/graphics/RectF;

.field public final v0:Lc/U4;

.field public final v1:Lc/o1;

.field public w:Z

.field public w0:Z

.field public w1:Landroid/media/session/MediaController;

.field public x:Ljava/lang/String;

.field public x0:Z

.field public final x1:Lc/M;

.field public final y:Lc/F3;

.field public y0:Z

.field public final y1:Lc/P;

.field public final z:Lc/F3;

.field public z0:Z

.field public final z1:Lc/x7;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x0

    const-string v1, "sans"

    invoke-static {v1, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    const/4 v0, 0x1

    invoke-static {v1, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lc/P3;->Y1:Landroid/graphics/Typeface;

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;)V
    .locals 11

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/P3;->b:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/P3;->c:Landroid/graphics/Path;

    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0

    iput-object v0, p0, Lc/P3;->e:Lc/u0;

    new-instance v0, Ljava/util/EnumMap;

    const-class v1, Lc/s0;

    invoke-direct {v0, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v0, p0, Lc/P3;->g:Ljava/util/EnumMap;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/P3;->j:Landroid/graphics/RectF;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lc/P3;->p:Ljava/lang/Object;

    const-string v0, ""

    iput-object v0, p0, Lc/P3;->q:Ljava/lang/String;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->u:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->v:Landroid/graphics/RectF;

    iput-object v0, p0, Lc/P3;->x:Ljava/lang/String;

    new-instance v2, Lc/F3;

    const/16 v3, 0xf

    invoke-direct {v2, p0, v3}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v2, p0, Lc/P3;->y:Lc/F3;

    new-instance v2, Lc/F3;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v2, p0, Lc/P3;->z:Lc/F3;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->L:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lc/P3;->M:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lc/P3;->N:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    iput-object v2, p0, Lc/P3;->O:Landroid/graphics/Path;

    new-instance v2, Landroid/text/TextPaint;

    invoke-direct {v2, v3}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v2, p0, Lc/P3;->P:Landroid/text/TextPaint;

    new-instance v2, Landroid/text/TextPaint;

    invoke-direct {v2, v3}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v2, p0, Lc/P3;->Q:Landroid/text/TextPaint;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->R:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->S:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->T:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->U:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->V:Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->W:Landroid/graphics/RectF;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/P3;->d0:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/P3;->e0:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    iput-object v2, p0, Lc/P3;->g0:Ljava/util/List;

    new-instance v2, Lc/F3;

    const/4 v4, 0x4

    invoke-direct {v2, p0, v4}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v2, p0, Lc/P3;->k0:Lc/F3;

    new-instance v2, Lc/T4;

    invoke-direct {v2}, Lc/T4;-><init>()V

    iput-object v2, p0, Lc/P3;->l0:Lc/T4;

    new-instance v2, Lc/B0;

    invoke-direct {v2}, Lc/B0;-><init>()V

    iput-object v2, p0, Lc/P3;->m0:Lc/B0;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/P3;->n0:Landroid/graphics/RectF;

    iput-object v0, p0, Lc/P3;->q0:Ljava/lang/String;

    iput-object v0, p0, Lc/P3;->r0:Ljava/lang/String;

    iput-object v0, p0, Lc/P3;->s0:Ljava/lang/String;

    new-instance v2, Ljava/util/EnumMap;

    invoke-direct {v2, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v2, p0, Lc/P3;->u0:Ljava/util/EnumMap;

    new-instance v1, Lc/U4;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/high16 v2, 0x3f800000    # 1.0f

    iput v2, v1, Lc/U4;->e:F

    iput v2, v1, Lc/U4;->f:F

    iput-object v1, p0, Lc/P3;->v0:Lc/U4;

    iput v2, p0, Lc/P3;->A0:F

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->B0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->C0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->D0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->E0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->I0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->J0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->K0:Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/P3;->L0:Landroid/graphics/RectF;

    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4}, Landroid/graphics/RectF;-><init>()V

    new-instance v5, Landroid/graphics/RectF;

    invoke-direct {v5}, Landroid/graphics/RectF;-><init>()V

    new-instance v6, Landroid/graphics/RectF;

    invoke-direct {v6}, Landroid/graphics/RectF;-><init>()V

    new-instance v7, Landroid/graphics/RectF;

    invoke-direct {v7}, Landroid/graphics/RectF;-><init>()V

    new-instance v8, Landroid/graphics/RectF;

    invoke-direct {v8}, Landroid/graphics/RectF;-><init>()V

    new-instance v9, Landroid/graphics/RectF;

    invoke-direct {v9}, Landroid/graphics/RectF;-><init>()V

    new-instance v10, Landroid/graphics/RectF;

    invoke-direct {v10}, Landroid/graphics/RectF;-><init>()V

    filled-new-array/range {v4 .. v10}, [Landroid/graphics/RectF;

    move-result-object v1

    iput-object v1, p0, Lc/P3;->M0:[Landroid/graphics/RectF;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4}, Landroid/graphics/RectF;-><init>()V

    filled-new-array {v1, v2, v4}, [Landroid/graphics/RectF;

    move-result-object v1

    iput-object v1, p0, Lc/P3;->N0:[Landroid/graphics/RectF;

    const/4 v1, -0x1

    iput v1, p0, Lc/P3;->O0:I

    iput v1, p0, Lc/P3;->P0:I

    new-instance v2, Lc/F3;

    const/4 v4, 0x5

    invoke-direct {v2, p0, v4}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v2, p0, Lc/P3;->U0:Lc/F3;

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v2, p0, Lc/P3;->W0:Landroid/os/Handler;

    new-instance v2, Lc/e1;

    const/4 v4, 0x3

    invoke-direct {v2, p0, v4}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v2, p0, Lc/P3;->Y0:Lc/e1;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    iput-object v2, p0, Lc/P3;->h1:Ljava/util/List;

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    iput-object v2, p0, Lc/P3;->i1:Ljava/util/HashMap;

    new-instance v2, Lc/L;

    const/4 v4, 0x1

    invoke-direct {v2, p0, v4}, Lc/L;-><init>(Ljava/lang/Object;I)V

    iput-object v2, p0, Lc/P3;->l1:Lc/L;

    new-instance v2, Lc/F3;

    const/4 v4, 0x6

    invoke-direct {v2, p0, v4}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v2, p0, Lc/P3;->n1:Lc/F3;

    iput-object v0, p0, Lc/P3;->p1:Ljava/lang/String;

    iput-object v0, p0, Lc/P3;->r1:Ljava/lang/String;

    new-instance v0, Lc/M;

    const/4 v2, 0x1

    invoke-direct {v0, p0, v2}, Lc/M;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/P3;->x1:Lc/M;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/P3;->D1:Landroid/graphics/RectF;

    new-instance v0, Lc/O3;

    invoke-direct {v0, p0}, Lc/O3;-><init>(Lc/P3;)V

    iput-object v0, p0, Lc/P3;->E1:Lc/O3;

    new-instance v0, Lc/b5;

    invoke-direct {v0}, Lc/b5;-><init>()V

    iput-object v0, p0, Lc/P3;->M1:Lc/b5;

    new-instance v0, Lc/g5;

    invoke-direct {v0, p0}, Lc/g5;-><init>(Lc/P3;)V

    iput-object v0, p0, Lc/P3;->N1:Lc/g5;

    new-instance v0, Lc/F3;

    const/4 v2, 0x7

    invoke-direct {v0, p0, v2}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object v0, p0, Lc/P3;->Q1:Lc/F3;

    iput v1, p0, Lc/P3;->R1:I

    iput v1, p0, Lc/P3;->S1:I

    iput v1, p0, Lc/P3;->V1:I

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lc/P3;->W1:Landroid/graphics/Rect;

    new-instance v0, Lc/h0;

    invoke-direct {v0, p1}, Lc/h0;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, Lc/P3;->h:Lc/h0;

    new-instance v1, Lc/S;

    invoke-direct {v1, p1, v0}, Lc/S;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/h0;)V

    iput-object v1, p0, Lc/P3;->i:Lc/S;

    new-instance v0, Lc/B0;

    invoke-direct {v0, p1}, Lc/B0;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object v0, p0, Lc/P3;->l:Lc/B0;

    iput-object p2, p0, Lc/P3;->a0:Lc/z;

    new-instance v0, Lc/g0;

    new-instance v1, Lc/E3;

    const/4 v2, 0x1

    invoke-direct {v1, p4, v2}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    invoke-direct {v0, p0, p3, p2, v1}, Lc/g0;-><init>(Lc/P3;Lc/n1;Lc/z;Lc/E3;)V

    iput-object v0, p0, Lc/P3;->t1:Lc/g0;

    new-instance p2, Lc/S0;

    invoke-direct {p2, p1}, Lc/S0;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object p2, p0, Lc/P3;->m:Lc/S0;

    new-instance p2, Lc/G0;

    invoke-direct {p2, p1, p3}, Lc/G0;-><init>(Landroid/app/Activity;Lc/n1;)V

    iput-object p2, p0, Lc/P3;->n:Lc/G0;

    new-instance v0, Lc/g1;

    new-instance v7, Lc/F3;

    const/16 v1, 0x9

    invoke-direct {v7, p0, v1}, Lc/F3;-><init>(Lc/P3;I)V

    new-instance v8, Lc/M3;

    invoke-direct {v8, p0}, Lc/M3;-><init>(Lc/P3;)V

    new-instance v9, Lc/F3;

    const/16 v1, 0xa

    invoke-direct {v9, p0, v1}, Lc/F3;-><init>(Lc/P3;I)V

    move-object v4, v0

    move-object v5, p0

    move-object v6, p3

    invoke-direct/range {v4 .. v9}, Lc/g1;-><init>(Lc/P3;Lc/n1;Lc/F3;Lc/M3;Lc/F3;)V

    iput-object v0, p0, Lc/P3;->A:Lc/g1;

    new-instance v1, Lc/C0;

    new-instance v2, Lc/K3;

    invoke-direct {v2, p0}, Lc/K3;-><init>(Lc/P3;)V

    invoke-direct {v1, p0, p3, p2, v2}, Lc/C0;-><init>(Lc/P3;Lc/n1;Lc/G0;Lc/K3;)V

    iput-object v1, p0, Lc/P3;->o:Lc/C0;

    new-instance p2, Lc/F3;

    const/16 v1, 0x10

    invoke-direct {p2, p0, v1}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object p2, v0, Lc/g1;->f:Ljava/lang/Runnable;

    new-instance p2, Lc/F3;

    const/16 v1, 0x11

    invoke-direct {p2, p0, v1}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object p2, v0, Lc/g1;->e:Ljava/lang/Runnable;

    new-instance p2, Lc/F3;

    const/16 v1, 0x12

    invoke-direct {p2, p0, v1}, Lc/F3;-><init>(Lc/P3;I)V

    iput-object p2, v0, Lc/g1;->h:Ljava/lang/Runnable;

    new-instance p2, Lc/E3;

    const/4 v1, 0x0

    invoke-direct {p2, p0, v1}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    iput-object p2, v0, Lc/g1;->j:Ljava/util/function/Consumer;

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object p2

    array-length v0, p2

    :goto_0
    if-ge v1, v0, :cond_0

    aget-object v2, p2, v1

    iget-object v4, p0, Lc/P3;->g:Ljava/util/EnumMap;

    new-instance v5, Lc/V0;

    invoke-direct {v5, v2}, Lc/V0;-><init>(Lc/s0;)V

    invoke-virtual {v4, v2, v5}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iput-object p4, p0, Lc/P3;->b0:Lc/y;

    invoke-static {p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p2

    iput-object p2, p0, Lc/P3;->c0:Lc/r4;

    iput-object p3, p0, Lc/P3;->C1:Lc/n1;

    new-instance p2, Lc/y8;

    invoke-direct {p2, p1}, Lc/y8;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lc/P3;->S0:Lc/y8;

    new-instance p3, Lc/z8;

    invoke-direct {p3, p1}, Lc/z8;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object p3, p0, Lc/P3;->T0:Lc/z8;

    invoke-virtual {p2}, Lc/y8;->c()Z

    move-result p2

    iput-boolean p2, p0, Lc/P3;->R0:Z

    new-instance p2, Lc/P;

    new-instance p3, Lc/F3;

    const/4 p4, 0x0

    invoke-direct {p3, p0, p4}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p2, p1, p3}, Lc/P;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/Runnable;)V

    iput-object p2, p0, Lc/P3;->y1:Lc/P;

    new-instance p2, Lc/g8;

    new-instance p3, Lc/F3;

    invoke-direct {p3, p0, p4}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p2, p1, p3}, Lc/g8;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V

    iput-object p2, p0, Lc/P3;->u1:Lc/g8;

    new-instance p2, Lc/o1;

    new-instance p3, Lc/F3;

    invoke-direct {p3, p0, p4}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p2, p1, p3}, Lc/o1;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V

    iput-object p2, p0, Lc/P3;->v1:Lc/o1;

    new-instance p2, Lc/x7;

    new-instance p3, Lc/F3;

    invoke-direct {p3, p0, p4}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p2, p1, p3}, Lc/x7;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V

    iput-object p2, p0, Lc/P3;->z1:Lc/x7;

    new-instance p2, Lc/r3;

    new-instance p3, Lc/F3;

    const/4 p4, 0x1

    invoke-direct {p3, p0, p4}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p2, p1, p3}, Lc/r3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V

    iput-object p2, p0, Lc/P3;->A1:Lc/r3;

    new-instance p1, Lc/o5;

    new-instance p2, Lc/F3;

    const/4 p3, 0x3

    invoke-direct {p2, p0, p3}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-direct {p1, p0, p2}, Lc/o5;-><init>(Landroid/view/View;Lc/F3;)V

    iput-object p1, p0, Lc/P3;->X0:Lc/o5;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string p2, "\u0413\u043b\u0430\u0432\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d DriveDeck"

    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {p0, v3}, Landroid/view/View;->setImportantForAccessibility(I)V

    return-void
.end method

.method public static M(Ljava/lang/String;)Z
    .locals 1

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const-string v0, "telegram"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "whatsapp"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "messenger"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "viber"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "vk.im"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_1

    :cond_1
    const/4 p0, 0x0

    goto :goto_2

    :cond_2
    :goto_1
    const/4 p0, 0x1

    :goto_2
    return p0
.end method

.method public static V(J)Ljava/lang/String;
    .locals 5

    const-wide/16 v0, 0x0

    cmp-long v0, p0, v0

    if-gez v0, :cond_0

    const-string p0, "\u2014:\u2014"

    return-object p0

    :cond_0
    const-wide/16 v0, 0x3e8

    div-long/2addr p0, v0

    const-wide/16 v0, 0x3c

    rem-long v2, p0, v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    div-long/2addr p0, v0

    invoke-virtual {v4, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-wide/16 p0, 0xa

    cmp-long p0, v2, p0

    if-gez p0, :cond_1

    const-string p0, ":0"

    goto :goto_0

    :cond_1
    const-string p0, ":"

    :goto_0
    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static f(Lc/P3;Lc/s0;)Ljava/lang/String;
    .locals 0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    packed-switch p0, :pswitch_data_0

    const-string p0, "\u0412\u0438\u0434\u0436\u0435\u0442"

    goto :goto_0

    :pswitch_0
    const-string p0, "\u0414\u0430\u043d\u043d\u044b\u0435 OBD"

    goto :goto_0

    :pswitch_1
    const-string p0, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    goto :goto_0

    :pswitch_2
    const-string p0, "\u0412\u0438\u0434\u0436\u0435\u0442\u044b Android"

    goto :goto_0

    :pswitch_3
    const-string p0, "\u041e\u043a\u043d\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    goto :goto_0

    :pswitch_4
    const-string p0, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    goto :goto_0

    :pswitch_5
    const-string p0, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c"

    goto :goto_0

    :pswitch_6
    const-string p0, "\u041d\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044f"

    goto :goto_0

    :pswitch_7
    const-string p0, "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f"

    goto :goto_0

    :pswitch_8
    const-string p0, "\u041c\u0443\u0437\u044b\u043a\u0430"

    goto :goto_0

    :pswitch_9
    const-string p0, "\u041f\u043e\u0433\u043e\u0434\u0430"

    goto :goto_0

    :pswitch_a
    const-string p0, "\u0427\u0430\u0441\u044b"

    :goto_0
    return-object p0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final A(Landroid/graphics/Canvas;FFFZZ)V
    .locals 18

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    move/from16 v3, p2

    move/from16 v10, p3

    move/from16 v11, p4

    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    iget-wide v12, v0, Lc/U0;->c:J

    iget-object v1, v8, Lc/P3;->V:Landroid/graphics/RectF;

    const/high16 v2, 0x40e00000    # 7.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v4

    add-float/2addr v4, v11

    invoke-virtual {v1, v3, v11, v10, v4}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->j()Z

    move-result v1

    iget-object v4, v8, Lc/P3;->W:Landroid/graphics/RectF;

    if-eqz v1, :cond_0

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v8, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float v1, v11, v1

    const/high16 v5, 0x42000000    # 32.0f

    invoke-virtual {v8, v5}, Lc/P3;->s(F)F

    move-result v5

    add-float/2addr v5, v11

    invoke-virtual {v4, v3, v1, v10, v5}, Landroid/graphics/RectF;->set(FFFF)V

    goto :goto_0

    :cond_0
    invoke-virtual {v4}, Landroid/graphics/RectF;->setEmpty()V

    :goto_0
    iget-object v1, v8, Lc/P3;->R:Landroid/graphics/RectF;

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v4

    add-float/2addr v4, v11

    invoke-virtual {v1, v3, v11, v10, v4}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v4, 0x40600000    # 3.5f

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v5

    if-eqz p6, :cond_1

    const v6, -0x66000001

    goto :goto_1

    :cond_1
    iget-object v6, v8, Lc/P3;->c0:Lc/r4;

    iget v6, v6, Lc/r4;->h:I

    :goto_1
    invoke-virtual {v8, v9, v1, v5, v6}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    const-wide/16 v5, 0x0

    cmp-long v14, v12, v5

    iget-wide v2, v0, Lc/U0;->b:J

    if-lez v14, :cond_4

    cmp-long v0, v2, v5

    if-ltz v0, :cond_4

    invoke-static {v12, v13, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    invoke-static {v5, v6, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    move/from16 v5, p2

    sub-float v0, v10, v5

    long-to-float v6, v2

    mul-float/2addr v0, v6

    long-to-float v6, v12

    div-float/2addr v0, v6

    add-float/2addr v0, v5

    const/high16 v6, 0x40e00000    # 7.0f

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v11

    invoke-virtual {v1, v5, v11, v0, v6}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v0

    if-eqz p6, :cond_2

    const v4, -0x722001

    goto :goto_3

    :cond_2
    iget-object v4, v8, Lc/P3;->c0:Lc/r4;

    iget-boolean v4, v4, Lc/r4;->m:Z

    if-eqz v4, :cond_3

    const/16 v4, 0xab

    const/16 v6, 0x1a

    const/16 v7, 0x85

    :goto_2
    invoke-static {v6, v7, v4}, Landroid/graphics/Color;->rgb(III)I

    move-result v4

    goto :goto_3

    :cond_3
    const/16 v4, 0xf1

    const/16 v6, 0x67

    const/16 v7, 0xce

    goto :goto_2

    :goto_3
    invoke-virtual {v8, v9, v1, v0, v4}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    goto :goto_4

    :cond_4
    move/from16 v5, p2

    :goto_4
    if-eqz p5, :cond_7

    if-eqz p6, :cond_5

    const v0, -0x111112

    :goto_5
    move v15, v0

    goto :goto_6

    :cond_5
    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->e:I

    goto :goto_5

    :goto_6
    invoke-static {v2, v3}, Lc/P3;->V(J)Ljava/lang/String;

    move-result-object v2

    const/high16 v7, 0x41d80000    # 27.0f

    invoke-virtual {v8, v7}, Lc/P3;->s(F)F

    move-result v0

    add-float v4, v0, v11

    const/high16 v6, 0x41500000    # 13.0f

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v16

    const/16 v17, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, p2

    move/from16 v5, v16

    move v9, v6

    move v6, v15

    move/from16 v7, v17

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    if-lez v14, :cond_6

    goto :goto_7

    :cond_6
    const-wide/16 v12, -0x1

    :goto_7
    invoke-static {v12, v13}, Lc/P3;->V(J)Ljava/lang/String;

    move-result-object v2

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v8, v9}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    sub-float v3, v10, v0

    const/high16 v0, 0x41d80000    # 27.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v4, v0, v11

    invoke-virtual {v8, v9}, Lc/P3;->s(F)F

    move-result v5

    const/4 v7, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v6, v15

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    :cond_7
    return-void
.end method

.method public final B(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 34

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v0, p2

    const-string v1, ""

    const-string v2, "\u2708"

    filled-new-array {v1, v1, v1, v2}, [Ljava/lang/String;

    move-result-object v9

    iget-object v1, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->C()I

    move-result v10

    invoke-static {v10}, Lc/k6;->p0(I)I

    move-result v2

    iget-object v11, v7, Lc/P3;->M0:[Landroid/graphics/RectF;

    array-length v3, v11

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_0

    aget-object v5, v11, v4

    invoke-virtual {v5}, Landroid/graphics/RectF;->setEmpty()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    iget-object v13, v7, Lc/P3;->N0:[Landroid/graphics/RectF;

    array-length v3, v13

    const/4 v4, 0x0

    :goto_1
    if-ge v4, v3, :cond_1

    aget-object v5, v13, v4

    invoke-virtual {v5}, Landroid/graphics/RectF;->setEmpty()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    if-nez v2, :cond_2

    return-void

    :cond_2
    invoke-virtual {v1}, Lc/n1;->B()I

    move-result v1

    invoke-static {v1}, Lc/k6;->s(I)F

    move-result v2

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v14

    int-to-float v2, v1

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v15

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-virtual {v7, v3}, Lc/P3;->s(F)F

    move-result v3

    invoke-static {v10, v2, v3, v1}, Lc/k6;->u(IFFI)I

    move-result v6

    invoke-static {v10, v6}, Lc/k6;->l0(II)I

    move-result v1

    const/4 v5, 0x1

    if-lt v6, v5, :cond_25

    const v2, 0x7fffffff

    if-ne v1, v2, :cond_3

    goto/16 :goto_20

    :cond_3
    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    int-to-float v3, v1

    mul-float/2addr v3, v14

    sub-float/2addr v2, v3

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    if-ne v1, v5, :cond_4

    move v12, v3

    goto :goto_2

    :cond_4
    const/high16 v4, 0x40c00000    # 6.0f

    invoke-virtual {v7, v4}, Lc/P3;->s(F)F

    move-result v4

    add-int/lit8 v12, v1, -0x1

    int-to-float v12, v12

    div-float v12, v2, v12

    invoke-static {v4, v12}, Ljava/lang/Math;->min(FF)F

    move-result v4

    move v12, v4

    :goto_2
    iget v4, v0, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x41000000    # 8.0f

    move-object/from16 v18, v13

    invoke-virtual {v7, v3}, Lc/P3;->s(F)F

    move-result v13

    sub-int/2addr v1, v5

    int-to-float v1, v1

    mul-float/2addr v1, v12

    sub-float/2addr v2, v1

    const/high16 v19, 0x40000000    # 2.0f

    div-float v2, v2, v19

    invoke-static {v13, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    add-float v13, v1, v4

    iget v1, v0, Landroid/graphics/RectF;->left:F

    invoke-virtual {v7, v3}, Lc/P3;->s(F)F

    move-result v2

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    int-to-float v4, v6

    mul-float/2addr v4, v14

    sub-float/2addr v3, v4

    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    add-float v17, v2, v1

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v4

    invoke-virtual/range {p1 .. p2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3, v5}, Landroid/graphics/Paint;-><init>(I)V

    sget-object v0, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    div-float v2, v15, v19

    iget-object v0, v7, Lc/P3;->c0:Lc/r4;

    sget-object v1, Lc/r4;->p:Lc/r4;

    if-ne v0, v1, :cond_5

    const v20, -0x4c000001

    goto :goto_3

    :cond_5
    const v20, -0x77000001

    :goto_3
    if-ne v0, v1, :cond_6

    const v0, -0x33dfdedc    # -4.1976976E7f

    :goto_4
    move/from16 v21, v0

    goto :goto_5

    :cond_6
    const v0, -0x66dfdedc

    goto :goto_4

    :goto_5
    const/4 v0, 0x0

    const/4 v1, 0x0

    const/16 v22, 0x0

    :goto_6
    const v24, 0x3eb33333    # 0.35f

    const-string v5, "sans-serif-medium"

    const v25, 0x3f0f5c29    # 0.56f

    move/from16 v26, v4

    const/4 v4, 0x4

    move-object/from16 v28, v9

    if-ge v1, v4, :cond_13

    const/16 v23, 0x1

    shl-int v4, v23, v1

    and-int/2addr v4, v10

    if-eqz v4, :cond_12

    if-lt v0, v6, :cond_7

    add-int/lit8 v22, v22, 0x1

    move/from16 v0, v22

    const/4 v4, 0x0

    goto :goto_7

    :cond_7
    move v4, v0

    move/from16 v0, v22

    :goto_7
    aget-object v9, v11, v1

    move/from16 v30, v6

    int-to-float v6, v4

    mul-float/2addr v6, v14

    add-float v6, v6, v17

    move/from16 v22, v4

    int-to-float v4, v0

    add-float v31, v14, v12

    mul-float v31, v31, v4

    add-float v4, v31, v13

    move/from16 v31, v0

    add-float v0, v6, v14

    move/from16 v32, v13

    add-float v13, v4, v14

    invoke-virtual {v9, v6, v4, v0, v13}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v9}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    invoke-virtual {v9}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    iget-object v0, v7, Lc/P3;->C:Lc/A8;

    if-eqz v0, :cond_b

    if-nez v1, :cond_8

    iget-boolean v0, v0, Lc/A8;->j:Z

    if-eqz v0, :cond_b

    goto :goto_8

    :cond_8
    const/4 v9, 0x1

    if-ne v1, v9, :cond_9

    iget-boolean v0, v0, Lc/A8;->k:Z

    if-eqz v0, :cond_b

    goto :goto_8

    :cond_9
    iget-boolean v9, v0, Lc/A8;->m:Z

    const/4 v13, 0x2

    if-ne v1, v13, :cond_a

    iget-boolean v0, v0, Lc/A8;->l:Z

    if-eqz v0, :cond_b

    if-nez v9, :cond_b

    goto :goto_8

    :cond_a
    if-eqz v9, :cond_b

    :goto_8
    const/4 v0, 0x1

    goto :goto_9

    :cond_b
    const/4 v0, 0x0

    :goto_9
    sget-object v9, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    if-eqz v0, :cond_c

    const/4 v9, -0x1

    goto :goto_a

    :cond_c
    move/from16 v9, v20

    :goto_a
    invoke-virtual {v3, v9}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v8, v4, v6, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v9, 0x3

    if-ge v1, v9, :cond_10

    if-nez v1, :cond_d

    const v5, 0x7f0300a1

    move v9, v5

    const/4 v5, 0x1

    goto :goto_b

    :cond_d
    const/4 v5, 0x1

    if-ne v1, v5, :cond_e

    const v9, 0x7f030092

    goto :goto_b

    :cond_e
    const v9, 0x7f03002b

    :goto_b
    mul-float v13, v15, v25

    if-eqz v0, :cond_f

    move/from16 v23, v31

    const v29, -0xdfdedc

    goto :goto_c

    :cond_f
    move/from16 v29, v21

    move/from16 v23, v31

    :goto_c
    move-object/from16 v0, p0

    move/from16 v25, v1

    move-object/from16 v1, p1

    move v7, v2

    move v2, v9

    move-object v9, v3

    move v3, v4

    move/from16 v33, v26

    move v4, v6

    move v6, v5

    move v5, v13

    move/from16 v13, v30

    move/from16 v6, v29

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_e

    :cond_10
    move/from16 v25, v1

    move v7, v2

    move-object v9, v3

    move/from16 v33, v26

    move/from16 v13, v30

    move/from16 v23, v31

    if-eqz v0, :cond_11

    const v0, -0xdfdedc

    goto :goto_d

    :cond_11
    move/from16 v0, v21

    :goto_d
    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3f0ccccd    # 0.55f

    mul-float/2addr v0, v15

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v0, 0x0

    invoke-static {v5, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    aget-object v0, v28, v25

    invoke-virtual {v9}, Landroid/graphics/Paint;->getTextSize()F

    move-result v1

    mul-float v1, v1, v24

    add-float/2addr v1, v6

    invoke-static {v8, v0, v4, v1, v9}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :goto_e
    add-int/lit8 v0, v22, 0x1

    move/from16 v22, v23

    goto :goto_f

    :cond_12
    move/from16 v25, v1

    move v7, v2

    move-object v9, v3

    move/from16 v32, v13

    move/from16 v33, v26

    move v13, v6

    :goto_f
    add-int/lit8 v1, v25, 0x1

    move v2, v7

    move-object v3, v9

    move v6, v13

    move-object/from16 v9, v28

    move/from16 v13, v32

    move/from16 v4, v33

    move-object/from16 v7, p0

    goto/16 :goto_6

    :cond_13
    move v7, v2

    move-object v9, v3

    move/from16 v32, v13

    move/from16 v33, v26

    move v13, v6

    and-int/lit8 v1, v10, 0x10

    if-eqz v1, :cond_20

    const/4 v6, 0x2

    if-ge v13, v6, :cond_14

    const/16 v20, 0x1

    goto :goto_10

    :cond_14
    const/16 v20, 0x0

    :goto_10
    if-eqz v20, :cond_15

    if-lez v0, :cond_16

    goto :goto_11

    :cond_15
    add-int/lit8 v1, v0, 0x2

    if-le v1, v13, :cond_16

    :goto_11
    add-int/lit8 v22, v22, 0x1

    move/from16 v2, v22

    const/4 v3, 0x0

    goto :goto_12

    :cond_16
    move v3, v0

    move/from16 v2, v22

    :goto_12
    aget-object v0, v11, v4

    int-to-float v1, v3

    mul-float/2addr v1, v14

    add-float v4, v1, v17

    int-to-float v1, v2

    add-float v21, v14, v12

    mul-float v21, v21, v1

    add-float v1, v21, v32

    div-float v21, v14, v19

    add-float v22, v1, v21

    if-eqz v20, :cond_17

    new-instance v6, Landroid/graphics/RectF;

    add-float v21, v4, v21

    move/from16 v23, v2

    sub-float v2, v21, v7

    move/from16 v26, v3

    add-float v3, v21, v7

    mul-float v21, v14, v19

    add-float v21, v21, v1

    move-object/from16 v28, v5

    add-float v5, v21, v12

    invoke-direct {v6, v2, v1, v3, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    move-object/from16 v21, v11

    goto :goto_13

    :cond_17
    move/from16 v23, v2

    move/from16 v26, v3

    move-object/from16 v28, v5

    new-instance v6, Landroid/graphics/RectF;

    const v2, 0x3dcccccd    # 0.1f

    mul-float/2addr v2, v14

    add-float/2addr v2, v4

    sub-float v3, v22, v7

    const v5, 0x3ff33333    # 1.9f

    mul-float/2addr v5, v14

    add-float/2addr v5, v4

    move-object/from16 v21, v11

    add-float v11, v22, v7

    invoke-direct {v6, v2, v3, v5, v11}, Landroid/graphics/RectF;-><init>(FFFF)V

    :goto_13
    if-eqz v20, :cond_18

    move v2, v14

    goto :goto_14

    :cond_18
    mul-float v2, v14, v19

    :goto_14
    add-float/2addr v2, v4

    if-eqz v20, :cond_19

    mul-float v19, v19, v14

    add-float v19, v19, v12

    goto :goto_15

    :cond_19
    move/from16 v19, v14

    :goto_15
    add-float v3, v1, v19

    invoke-virtual {v0, v4, v1, v2, v3}, Landroid/graphics/RectF;->set(FFFF)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v0, -0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v8, v6, v7, v7, v9}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v5, 0x3

    const/4 v11, 0x0

    :goto_16
    if-ge v11, v5, :cond_1e

    aget-object v0, v18, v11

    const/high16 v1, 0x40400000    # 3.0f

    if-eqz v20, :cond_1a

    iget v2, v6, Landroid/graphics/RectF;->top:F

    int-to-float v3, v11

    const/high16 v19, 0x3f000000    # 0.5f

    add-float v3, v3, v19

    invoke-virtual {v6}, Landroid/graphics/RectF;->height()F

    move-result v19

    mul-float v19, v19, v3

    div-float v19, v19, v1

    add-float v19, v19, v2

    move/from16 v3, v19

    goto :goto_17

    :cond_1a
    move/from16 v3, v22

    :goto_17
    if-eqz v20, :cond_1b

    iget v2, v6, Landroid/graphics/RectF;->top:F

    int-to-float v5, v11

    invoke-virtual {v6}, Landroid/graphics/RectF;->height()F

    move-result v19

    mul-float v19, v19, v5

    div-float v19, v19, v1

    add-float v2, v19, v2

    add-float v5, v4, v14

    iget v1, v6, Landroid/graphics/RectF;->top:F

    move/from16 v30, v7

    add-int/lit8 v7, v11, 0x1

    int-to-float v7, v7

    invoke-virtual {v6}, Landroid/graphics/RectF;->height()F

    move-result v31

    mul-float v31, v31, v7

    const/high16 v7, 0x40400000    # 3.0f

    div-float v31, v31, v7

    add-float v1, v31, v1

    invoke-virtual {v0, v4, v2, v5, v1}, Landroid/graphics/RectF;->set(FFFF)V

    :goto_18
    const/4 v7, 0x1

    goto :goto_19

    :cond_1b
    move/from16 v30, v7

    move v7, v1

    iget v1, v6, Landroid/graphics/RectF;->left:F

    int-to-float v2, v11

    invoke-virtual {v6}, Landroid/graphics/RectF;->width()F

    move-result v5

    mul-float/2addr v5, v2

    div-float/2addr v5, v7

    add-float/2addr v5, v1

    iget v1, v6, Landroid/graphics/RectF;->top:F

    iget v2, v6, Landroid/graphics/RectF;->left:F

    add-int/lit8 v7, v11, 0x1

    int-to-float v7, v7

    invoke-virtual {v6}, Landroid/graphics/RectF;->width()F

    move-result v31

    mul-float v31, v31, v7

    const/high16 v7, 0x40400000    # 3.0f

    div-float v31, v31, v7

    add-float v2, v31, v2

    iget v7, v6, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v0, v5, v1, v2, v7}, Landroid/graphics/RectF;->set(FFFF)V

    goto :goto_18

    :goto_19
    if-ne v11, v7, :cond_1c

    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    move-object/from16 v5, p0

    move/from16 v1, v30

    iget-boolean v0, v5, Lc/P3;->R0:Z

    mul-float v19, v15, v24

    move/from16 v30, v0

    move-object/from16 v0, p0

    move v7, v1

    move-object/from16 v1, p1

    move/from16 v31, v4

    const/16 v27, 0x3

    move/from16 v4, v30

    move-object/from16 v30, v6

    move-object/from16 v6, v28

    const/16 v28, 0x2

    move/from16 v5, v19

    invoke-virtual/range {v0 .. v5}, Lc/P3;->G(Landroid/graphics/Canvas;FFZF)V

    const/4 v0, -0x1

    const v1, -0xdfdedc

    const/4 v5, 0x0

    goto :goto_1b

    :cond_1c
    move/from16 v31, v4

    move/from16 v7, v30

    const v1, -0xdfdedc

    const/16 v27, 0x3

    move-object/from16 v30, v6

    move-object/from16 v6, v28

    const/16 v28, 0x2

    invoke-virtual {v9, v1}, Landroid/graphics/Paint;->setColor(I)V

    const v2, 0x3ed70a3d    # 0.42f

    mul-float/2addr v2, v15

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v5, 0x0

    invoke-static {v6, v5}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    if-nez v11, :cond_1d

    const-string v2, "\u2212"

    goto :goto_1a

    :cond_1d
    const-string v2, "+"

    :goto_1a
    invoke-virtual {v0}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v9}, Landroid/graphics/Paint;->getTextSize()F

    move-result v4

    const v16, 0x3eae147b    # 0.34f

    mul-float v4, v4, v16

    add-float/2addr v4, v3

    invoke-static {v8, v2, v0, v4, v9}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/4 v0, -0x1

    :goto_1b
    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    add-int/lit8 v11, v11, 0x1

    move-object/from16 v28, v6

    move/from16 v5, v27

    move-object/from16 v6, v30

    move/from16 v4, v31

    goto/16 :goto_16

    :cond_1e
    const/4 v5, 0x0

    const/16 v28, 0x2

    if-eqz v20, :cond_1f

    add-int/lit8 v22, v23, 0x1

    const/4 v0, 0x1

    goto :goto_1c

    :cond_1f
    add-int/lit8 v0, v26, 0x2

    move/from16 v22, v23

    goto :goto_1c

    :cond_20
    move-object/from16 v21, v11

    const/4 v5, 0x0

    :goto_1c
    and-int/lit8 v1, v10, 0x20

    if-eqz v1, :cond_22

    if-lt v0, v13, :cond_21

    add-int/lit8 v22, v22, 0x1

    move v6, v5

    :goto_1d
    move/from16 v11, v22

    goto :goto_1e

    :cond_21
    move v6, v0

    goto :goto_1d

    :goto_1e
    int-to-float v0, v6

    mul-float/2addr v0, v14

    add-float v0, v0, v17

    int-to-float v1, v11

    add-float v2, v14, v12

    mul-float/2addr v2, v1

    add-float v2, v2, v32

    const/4 v1, 0x5

    aget-object v1, v21, v1

    add-float v3, v0, v14

    add-float v4, v2, v14

    invoke-virtual {v1, v0, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v0, -0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    invoke-virtual {v8, v0, v2, v7, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    move-object/from16 v4, p0

    iget-boolean v0, v4, Lc/P3;->R0:Z

    const/16 v16, 0x1

    xor-int/lit8 v18, v0, 0x1

    const v0, 0x3ef5c28f    # 0.48f

    mul-float v19, v15, v0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v4, v18

    move/from16 v18, v5

    move/from16 v5, v19

    invoke-virtual/range {v0 .. v5}, Lc/P3;->G(Landroid/graphics/Canvas;FFZF)V

    add-int/lit8 v0, v6, 0x1

    move/from16 v22, v11

    goto :goto_1f

    :cond_22
    move/from16 v18, v5

    :goto_1f
    and-int/lit8 v1, v10, 0x40

    if-eqz v1, :cond_24

    if-lt v0, v13, :cond_23

    add-int/lit8 v22, v22, 0x1

    move/from16 v0, v18

    :cond_23
    move/from16 v1, v22

    int-to-float v0, v0

    mul-float/2addr v0, v14

    add-float v0, v0, v17

    int-to-float v1, v1

    add-float/2addr v12, v14

    mul-float/2addr v12, v1

    add-float v12, v12, v32

    const/4 v1, 0x6

    aget-object v1, v21, v1

    add-float v2, v0, v14

    add-float/2addr v14, v12

    invoke-virtual {v1, v0, v12, v2, v14}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v0, -0x1

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    invoke-virtual {v8, v0, v2, v7, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    mul-float v5, v15, v25

    const v6, -0xdfdedc

    const v2, 0x7f030016

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_24
    move/from16 v0, v33

    invoke-virtual {v8, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_25
    :goto_20
    return-void
.end method

.method public final C(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 30

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    move-object/from16 v10, p2

    iget-object v0, v8, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->u()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v0, v1

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-virtual {v8, v11}, Lc/P3;->s(F)F

    move-result v1

    mul-float v12, v1, v0

    const/high16 v0, 0x42280000    # 42.0f

    mul-float v13, v12, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v0, v1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    const/high16 v2, 0x42600000    # 56.0f

    mul-float/2addr v2, v12

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v14

    iget-object v0, v8, Lc/P3;->A:Lc/g1;

    iget-boolean v0, v0, Lc/g1;->J:Z

    const/high16 v15, 0x41800000    # 16.0f

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move v1, v15

    :goto_0
    invoke-virtual {v8, v1}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/high16 v16, 0x40000000    # 2.0f

    mul-float v3, v0, v16

    sub-float/2addr v2, v3

    mul-float v7, v12, v15

    const/4 v6, 0x1

    invoke-virtual {v8, v1, v2, v7, v6}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    iget v1, v10, Landroid/graphics/RectF;->left:F

    add-float v3, v1, v0

    iget v0, v10, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41e80000    # 29.0f

    mul-float/2addr v1, v12

    add-float v4, v1, v0

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v5, v0, Lc/r4;->d:I

    const/16 v17, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v18, v5

    move v5, v7

    move/from16 v6, v18

    move v11, v7

    move/from16 v7, v17

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    iget-object v7, v8, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->v:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->m:Z

    if-eqz v0, :cond_1

    const-string v0, "\u041d\u043e\u0432\u044b\u0445 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u0439 \u043d\u0435\u0442"

    goto :goto_1

    :cond_1
    const-string v0, "\u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u0430 \u043a \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f\u043c"

    :goto_1
    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x42000000    # 32.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    invoke-virtual {v8, v0, v1, v11, v6}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    iget v0, v10, Landroid/graphics/RectF;->left:F

    invoke-virtual {v8, v15}, Lc/P3;->s(F)F

    move-result v1

    add-float v3, v1, v0

    iget v0, v10, Landroid/graphics/RectF;->top:F

    add-float/2addr v0, v13

    div-float v14, v14, v16

    add-float/2addr v14, v0

    const/high16 v0, 0x40c00000    # 6.0f

    mul-float/2addr v12, v0

    add-float v4, v12, v14

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->e:I

    const/4 v7, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v5, v11

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    return-void

    :cond_2
    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->v:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v1

    sub-float/2addr v1, v13

    const/high16 v15, 0x41600000    # 14.0f

    invoke-virtual {v8, v15}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    div-float/2addr v1, v14

    float-to-int v1, v1

    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v5

    move v4, v6

    :goto_2
    if-ge v4, v5, :cond_9

    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->v:Ljava/util/List;

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Lc/q5;

    iget v0, v10, Landroid/graphics/RectF;->top:F

    add-float/2addr v0, v13

    int-to-float v1, v4

    mul-float/2addr v1, v14

    add-float/2addr v1, v0

    const/high16 v0, 0x42580000    # 54.0f

    mul-float/2addr v0, v12

    sub-float v0, v14, v0

    div-float v0, v0, v16

    add-float v17, v0, v1

    new-instance v2, Landroid/graphics/RectF;

    iget v0, v10, Landroid/graphics/RectF;->left:F

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v21

    add-float v0, v21, v0

    iget v15, v10, Landroid/graphics/RectF;->right:F

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v22

    sub-float v15, v15, v22

    add-float v6, v1, v14

    invoke-direct {v2, v0, v1, v15, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v0, v8, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-lez v4, :cond_3

    iget-object v6, v8, Lc/P3;->M:Landroid/graphics/Paint;

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    invoke-virtual {v0}, Lc/r4;->a()I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget v0, v2, Landroid/graphics/RectF;->left:F

    const/high16 v1, 0x42380000    # 46.0f

    mul-float/2addr v1, v12

    add-float/2addr v1, v0

    iget v15, v2, Landroid/graphics/RectF;->top:F

    iget v0, v2, Landroid/graphics/RectF;->right:F

    const/high16 v18, 0x3f800000    # 1.0f

    mul-float v23, v12, v18

    add-float v23, v23, v15

    move/from16 v24, v0

    move-object/from16 v0, p1

    move-object/from16 v25, v7

    move-object v7, v2

    move v2, v15

    move-object v15, v3

    move/from16 v3, v24

    move/from16 v24, v4

    move/from16 v4, v23

    move/from16 v23, v5

    move-object v5, v6

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    goto :goto_3

    :cond_3
    move-object v15, v3

    move/from16 v24, v4

    move/from16 v23, v5

    move-object/from16 v25, v7

    const/high16 v18, 0x3f800000    # 1.0f

    move-object v7, v2

    :goto_3
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v6

    invoke-virtual {v9, v7}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    iget-boolean v0, v8, Lc/P3;->i0:Z

    if-eqz v0, :cond_4

    iget-object v0, v8, Lc/P3;->h0:Lc/q5;

    invoke-virtual {v15, v0}, Lc/q5;->c(Lc/q5;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget v0, v8, Lc/P3;->j0:F

    const/4 v1, 0x0

    invoke-virtual {v9, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_4
    iget-object v0, v15, Lc/q5;->a:Ljava/lang/String;

    iget-object v1, v8, Lc/P3;->a0:Lc/z;

    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    iget-object v2, v8, Lc/P3;->R:Landroid/graphics/RectF;

    iget v3, v7, Landroid/graphics/RectF;->left:F

    const/high16 v4, 0x40800000    # 4.0f

    mul-float/2addr v4, v12

    add-float/2addr v4, v3

    const/high16 v5, 0x41100000    # 9.0f

    mul-float/2addr v5, v12

    add-float v5, v5, v17

    const/high16 v26, 0x42200000    # 40.0f

    mul-float v26, v26, v12

    add-float v3, v26, v3

    const/high16 v26, 0x42340000    # 45.0f

    mul-float v26, v26, v12

    move/from16 v27, v6

    add-float v6, v26, v17

    invoke-virtual {v2, v4, v5, v3, v6}, Landroid/graphics/RectF;->set(FFFF)V

    if-eqz v0, :cond_5

    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    iget-object v3, v8, Lc/P3;->c0:Lc/r4;

    invoke-static {v9, v0, v2, v3}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_5

    :cond_5
    const/high16 v0, 0x41400000    # 12.0f

    mul-float v6, v12, v0

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->c:I

    invoke-virtual {v8, v9, v2, v6, v0}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->c:I

    sget-object v3, Lc/q9;->z:Ljava/lang/ThreadLocal;

    invoke-virtual {v3}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/q9;

    if-eqz v3, :cond_6

    iget-object v4, v3, Lc/q9;->h:Landroid/graphics/RectF;

    invoke-virtual {v4, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iput v0, v3, Lc/q9;->i:I

    const/4 v6, 0x1

    iput-boolean v6, v3, Lc/q9;->j:Z

    goto :goto_4

    :cond_6
    const/4 v6, 0x1

    :goto_4
    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    const/high16 v3, 0x41000000    # 8.0f

    mul-float/2addr v3, v12

    add-float/2addr v3, v2

    const/high16 v2, 0x41c00000    # 24.0f

    mul-float/2addr v2, v12

    iget-object v4, v8, Lc/P3;->c0:Lc/r4;

    iget v4, v4, Lc/r4;->d:I

    iget-object v5, v8, Lc/P3;->N:Landroid/graphics/Paint;

    sget-object v6, Lc/P3;->Y1:Landroid/graphics/Typeface;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setColor(I)V

    const-string v2, "\u2022"

    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    div-float v4, v4, v16

    sub-float/2addr v0, v4

    invoke-static {v9, v2, v0, v3, v5}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :goto_5
    iget-object v0, v15, Lc/q5;->b:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v0, v15, Lc/q5;->a:Ljava/lang/String;

    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v1

    if-nez v1, :cond_7

    goto :goto_6

    :cond_7
    iget-object v0, v1, Lc/a;->b:Ljava/lang/String;

    :cond_8
    :goto_6
    iget v1, v7, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x42480000    # 50.0f

    mul-float/2addr v2, v12

    add-float v22, v2, v1

    invoke-virtual {v7}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x42780000    # 62.0f

    mul-float v26, v12, v2

    sub-float v1, v1, v26

    const/4 v6, 0x1

    invoke-virtual {v8, v0, v1, v11, v6}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    const/high16 v0, 0x41b00000    # 22.0f

    mul-float/2addr v0, v12

    add-float v4, v0, v17

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v5, v0, Lc/r4;->d:I

    const/16 v19, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v22

    move/from16 v28, v5

    move v5, v11

    move/from16 v20, v6

    move/from16 v29, v27

    const/4 v10, 0x0

    move/from16 v6, v28

    move-object/from16 v27, v7

    move/from16 v7, v19

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    invoke-virtual/range {v27 .. v27}, Landroid/graphics/RectF;->width()F

    move-result v0

    sub-float v0, v0, v26

    const/high16 v19, 0x41600000    # 14.0f

    mul-float v5, v12, v19

    iget-object v1, v15, Lc/q5;->c:Ljava/lang/String;

    invoke-virtual {v8, v1, v0, v5, v10}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    const/high16 v0, 0x42300000    # 44.0f

    mul-float/2addr v0, v12

    add-float v4, v0, v17

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->e:I

    const/4 v7, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    move/from16 v0, v29

    invoke-virtual {v9, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    add-int/lit8 v4, v24, 0x1

    move v6, v10

    move/from16 v15, v19

    move/from16 v5, v23

    move-object/from16 v7, v25

    move-object/from16 v10, p2

    goto/16 :goto_2

    :cond_9
    return-void
.end method

.method public final D(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V
    .locals 67

    move-object/from16 v8, p0

    move-object/from16 v15, p1

    move-object/from16 v14, p2

    move-object/from16 v13, p3

    const/high16 v0, 0x41800000    # 16.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    const v20, 0x3e19999a    # 0.15f

    mul-float v2, v2, v20

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v21

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v8, v12}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    const v22, 0x3da3d70a    # 0.08f

    mul-float v2, v2, v22

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v23

    iget-object v11, v8, Lc/P3;->v:Landroid/graphics/RectF;

    invoke-virtual {v11, v14}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget v1, v11, Landroid/graphics/RectF;->top:F

    add-float v2, v21, v23

    add-float/2addr v2, v1

    iput v2, v11, Landroid/graphics/RectF;->top:F

    invoke-virtual {v11}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-static {v9, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {v11}, Landroid/graphics/RectF;->height()F

    move-result v2

    invoke-static {v9, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-virtual {v8, v9}, Lc/P3;->s(F)F

    move-result v24

    iget-object v3, v8, Lc/P3;->C1:Lc/n1;

    iget-object v4, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    const-string v5, "speed_navigation"

    const/4 v10, 0x0

    invoke-interface {v4, v5, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    xor-int/lit8 v5, v4, 0x1

    const/high16 v6, 0x43340000    # 180.0f

    if-eqz v4, :cond_3

    iget-object v4, v13, Lc/U0;->t:Lc/j5;

    if-eqz v4, :cond_3

    iget-object v4, v13, Lc/U0;->h:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_0

    iget-object v4, v13, Lc/U0;->i:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_3

    :cond_0
    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v4

    cmpl-float v4, v1, v4

    if-ltz v4, :cond_1

    const/high16 v4, 0x42b40000    # 90.0f

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v4

    cmpl-float v4, v2, v4

    if-gez v4, :cond_2

    :cond_1
    const/high16 v4, 0x42c80000    # 100.0f

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v16

    cmpl-float v16, v1, v16

    if-ltz v16, :cond_3

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v4

    cmpl-float v4, v2, v4

    if-ltz v4, :cond_3

    :cond_2
    const/16 v16, 0x1

    goto :goto_0

    :cond_3
    move/from16 v16, v10

    :goto_0
    const/high16 v4, 0x430c0000    # 140.0f

    if-eqz v16, :cond_4

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v17

    cmpl-float v17, v1, v17

    if-ltz v17, :cond_4

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v17

    cmpl-float v17, v2, v17

    if-ltz v17, :cond_4

    const/16 v17, 0x1

    goto :goto_1

    :cond_4
    move/from16 v17, v10

    :goto_1
    if-eqz v17, :cond_5

    const/16 v18, 0x1

    goto :goto_2

    :cond_5
    move/from16 v18, v5

    :goto_2
    const v25, 0x3e23d70a    # 0.16f

    const/4 v5, 0x0

    if-eqz v17, :cond_6

    iget-object v4, v13, Lc/U0;->t:Lc/j5;

    iget-object v4, v4, Lc/j5;->c:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_6

    const/high16 v4, 0x42280000    # 42.0f

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v4

    mul-float v7, v2, v25

    invoke-static {v4, v7}, Ljava/lang/Math;->min(FF)F

    move-result v4

    move/from16 v27, v4

    goto :goto_3

    :cond_6
    move/from16 v27, v5

    :goto_3
    sub-float v7, v2, v27

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v2

    cmpg-float v2, v1, v2

    if-ltz v2, :cond_8

    const/high16 v2, 0x42aa0000    # 85.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    cmpg-float v2, v7, v2

    if-gez v2, :cond_7

    goto :goto_4

    :cond_7
    move/from16 v28, v10

    goto :goto_5

    :cond_8
    :goto_4
    const/16 v28, 0x1

    :goto_5
    const/high16 v4, 0x43d20000    # 420.0f

    if-eqz v16, :cond_9

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v2

    cmpl-float v2, v1, v2

    if-ltz v2, :cond_9

    div-float v2, v1, v7

    const v29, 0x400ccccd    # 2.2f

    cmpl-float v2, v2, v29

    if-lez v2, :cond_9

    const/16 v29, 0x1

    goto :goto_6

    :cond_9
    move/from16 v29, v10

    :goto_6
    if-eqz v16, :cond_a

    if-nez v29, :cond_a

    const/high16 v2, 0x43960000    # 300.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    cmpl-float v2, v7, v2

    if-lez v2, :cond_a

    const/16 v30, 0x1

    goto :goto_7

    :cond_a
    move/from16 v30, v10

    :goto_7
    if-eqz v16, :cond_b

    if-nez v29, :cond_b

    if-nez v30, :cond_b

    const/16 v31, 0x1

    goto :goto_8

    :cond_b
    move/from16 v31, v10

    :goto_8
    invoke-virtual {v8, v12}, Lc/P3;->s(F)F

    move-result v2

    const/high16 v6, 0x41a00000    # 20.0f

    invoke-virtual {v8, v6}, Lc/P3;->s(F)F

    move-result v4

    invoke-static {v1, v7}, Ljava/lang/Math;->min(FF)F

    move-result v34

    mul-float v6, v34, v22

    invoke-static {v4, v6}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->max(FF)F

    move-result v34

    iget v2, v13, Lc/U0;->s:I

    const v36, 0x3f0f5c29    # 0.56f

    const v37, 0x3f2147ae    # 0.63f

    const v38, 0x3ef5c28f    # 0.48f

    const v4, 0x3ec7ae14    # 0.39f

    const v39, 0x3ecccccd    # 0.4f

    const v40, 0x3ea3d70a    # 0.32f

    if-gtz v2, :cond_c

    if-nez v17, :cond_c

    move/from16 v42, v5

    goto :goto_b

    :cond_c
    if-eqz v18, :cond_d

    mul-float v2, v7, v39

    mul-float v6, v1, v40

    :goto_9
    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    :goto_a
    move/from16 v42, v2

    goto :goto_b

    :cond_d
    if-eqz v28, :cond_e

    mul-float v2, v7, v4

    const v6, 0x3e99999a    # 0.3f

    mul-float/2addr v6, v1

    goto :goto_9

    :cond_e
    if-eqz v31, :cond_f

    const/high16 v2, 0x429c0000    # 78.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    mul-float v6, v1, v40

    mul-float v12, v7, v38

    invoke-static {v6, v12}, Ljava/lang/Math;->min(FF)F

    move-result v6

    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    goto :goto_a

    :cond_f
    if-eqz v29, :cond_10

    mul-float v2, v7, v37

    const v6, 0x3e75c28f    # 0.24f

    mul-float/2addr v6, v1

    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    goto :goto_a

    :cond_10
    if-eqz v30, :cond_11

    const v2, 0x3ed70a3d    # 0.42f

    mul-float/2addr v2, v7

    const v6, 0x3e8a3d71    # 0.27f

    mul-float/2addr v6, v1

    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    goto :goto_a

    :cond_11
    mul-float v2, v7, v36

    mul-float v6, v1, v40

    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    goto :goto_a

    :goto_b
    const/high16 v2, 0x3f400000    # 0.75f

    const v6, 0x3efae148    # 0.49f

    const/high16 v12, 0x40000000    # 2.0f

    if-eqz v18, :cond_12

    iget v4, v11, Landroid/graphics/RectF;->right:F

    sub-float v4, v4, v34

    div-float v44, v42, v12

    sub-float v4, v4, v44

    :goto_c
    move v10, v4

    goto :goto_10

    :cond_12
    if-eqz v28, :cond_13

    iget v4, v11, Landroid/graphics/RectF;->right:F

    const/high16 v10, 0x41d80000    # 27.0f

    invoke-virtual {v8, v10}, Lc/P3;->s(F)F

    move-result v10

    :goto_d
    sub-float/2addr v4, v10

    goto :goto_c

    :cond_13
    if-eqz v31, :cond_14

    iget v4, v11, Landroid/graphics/RectF;->right:F

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v10

    sub-float/2addr v4, v10

    :goto_e
    div-float v10, v42, v12

    goto :goto_d

    :cond_14
    if-eqz v29, :cond_15

    iget v4, v11, Landroid/graphics/RectF;->left:F

    mul-float v10, v1, v6

    :goto_f
    add-float/2addr v4, v10

    goto :goto_c

    :cond_15
    if-eqz v30, :cond_16

    iget v4, v11, Landroid/graphics/RectF;->left:F

    mul-float v10, v1, v2

    goto :goto_f

    :cond_16
    iget v4, v11, Landroid/graphics/RectF;->right:F

    sub-float v4, v4, v34

    goto :goto_e

    :goto_10
    const/high16 v4, 0x42000000    # 32.0f

    if-eqz v18, :cond_17

    iget v6, v11, Landroid/graphics/RectF;->top:F

    add-float v6, v6, v34

    div-float v46, v42, v12

    :goto_11
    add-float v46, v46, v6

    move/from16 v6, v46

    goto :goto_14

    :cond_17
    if-eqz v28, :cond_18

    iget v6, v11, Landroid/graphics/RectF;->top:F

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v46

    goto :goto_11

    :cond_18
    const v6, 0x3eb33333    # 0.35f

    if-eqz v31, :cond_19

    iget v4, v11, Landroid/graphics/RectF;->top:F

    const/high16 v2, 0x42600000    # 56.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    mul-float/2addr v6, v7

    invoke-static {v2, v6}, Ljava/lang/Math;->min(FF)F

    move-result v2

    add-float/2addr v2, v4

    :goto_12
    move v6, v2

    goto :goto_14

    :cond_19
    if-eqz v29, :cond_1a

    iget v2, v11, Landroid/graphics/RectF;->top:F

    mul-float/2addr v6, v7

    add-float/2addr v2, v6

    goto :goto_12

    :cond_1a
    if-eqz v30, :cond_1b

    iget v2, v11, Landroid/graphics/RectF;->top:F

    const v4, 0x3e9eb852    # 0.31f

    mul-float/2addr v4, v7

    :goto_13
    add-float/2addr v2, v4

    goto :goto_12

    :cond_1b
    iget v2, v11, Landroid/graphics/RectF;->top:F

    add-float v2, v2, v34

    div-float v4, v42, v12

    goto :goto_13

    :goto_14
    cmpl-float v2, v42, v5

    iget v4, v13, Lc/U0;->r:I

    iget v5, v13, Lc/U0;->s:I

    if-lez v2, :cond_1c

    if-lez v5, :cond_1c

    add-int/lit8 v12, v5, 0x14

    if-lt v4, v12, :cond_1c

    const/4 v12, 0x1

    goto :goto_15

    :cond_1c
    const/4 v12, 0x0

    :goto_15
    const-wide/16 v50, 0x2bc

    const/high16 v52, 0x3f000000    # 0.5f

    if-eqz v12, :cond_1d

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v53

    move/from16 v56, v1

    rem-long v0, v53, v50

    long-to-double v0, v0

    const-wide v53, 0x400921fb54442d18L    # Math.PI

    mul-double v0, v0, v53

    const-wide/high16 v53, 0x4000000000000000L    # 2.0

    mul-double v0, v0, v53

    const-wide v53, 0x4085e00000000000L    # 700.0

    div-double v0, v0, v53

    invoke-static {v0, v1}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    double-to-float v0, v0

    mul-float v0, v0, v52

    sub-float v0, v52, v0

    mul-float v0, v0, v22

    add-float/2addr v0, v9

    goto :goto_16

    :cond_1d
    move/from16 v56, v1

    move v0, v9

    :goto_16
    iget-object v1, v8, Lc/P3;->M:Landroid/graphics/Paint;

    const v53, 0x3edc28f6    # 0.43f

    if-eqz v12, :cond_20

    mul-float v12, v42, v0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v57

    const-wide/16 v59, 0x578

    rem-long v57, v57, v59

    iget-object v9, v8, Lc/P3;->O:Landroid/graphics/Path;

    invoke-virtual {v9}, Landroid/graphics/Path;->rewind()V

    const/high16 v14, 0x41800000    # 16.0f

    invoke-virtual {v8, v14}, Lc/P3;->s(F)F

    move-result v13

    invoke-virtual {v8, v14}, Lc/P3;->s(F)F

    move-result v14

    move/from16 v55, v0

    sget-object v0, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v9, v11, v13, v14, v0}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    invoke-virtual {v15, v9}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v9, 0x40000000    # 2.0f

    invoke-virtual {v8, v9}, Lc/P3;->s(F)F

    move-result v13

    const v9, 0x3d3851ec    # 0.045f

    mul-float/2addr v9, v12

    invoke-static {v13, v9}, Ljava/lang/Math;->max(FF)F

    move-result v9

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v9, 0x0

    :goto_17
    const/4 v13, 0x2

    if-ge v9, v13, :cond_1e

    int-to-long v13, v9

    mul-long v13, v13, v50

    add-long v13, v13, v57

    rem-long v13, v13, v59

    long-to-float v13, v13

    const/high16 v14, 0x44af0000    # 1400.0f

    div-float/2addr v13, v14

    const/high16 v14, 0x3f800000    # 1.0f

    sub-float v61, v14, v13

    const/high16 v14, 0x43020000    # 130.0f

    mul-float v14, v14, v61

    mul-float v14, v14, v61

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    move/from16 v61, v5

    const/16 v5, 0x2f

    move-object/from16 v62, v3

    const/16 v3, 0x36

    move/from16 v63, v2

    const/16 v2, 0xdf

    invoke-static {v14, v2, v5, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v13, v13, v53

    const v2, 0x3f051eb8    # 0.52f

    add-float/2addr v13, v2

    mul-float/2addr v13, v12

    invoke-virtual {v15, v10, v6, v13, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    add-int/lit8 v9, v9, 0x1

    move/from16 v5, v61

    move-object/from16 v3, v62

    move/from16 v2, v63

    goto :goto_17

    :cond_1e
    move/from16 v63, v2

    move-object/from16 v62, v3

    move/from16 v61, v5

    invoke-virtual {v15, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_1f

    const-wide/16 v2, 0x20

    invoke-virtual {v8, v2, v3}, Landroid/view/View;->postInvalidateDelayed(J)V

    :cond_1f
    :goto_18
    const/4 v12, 0x0

    goto :goto_19

    :cond_20
    move/from16 v55, v0

    move/from16 v63, v2

    move-object/from16 v62, v3

    move/from16 v61, v5

    goto :goto_18

    :goto_19
    invoke-static {v12, v4}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v9

    if-eqz v18, :cond_21

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float v0, v0, v34

    goto :goto_1c

    :cond_21
    if-eqz v28, :cond_22

    iget v0, v11, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x41200000    # 10.0f

    :goto_1a
    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    :goto_1b
    add-float/2addr v0, v2

    goto :goto_1c

    :cond_22
    if-eqz v31, :cond_23

    iget v0, v11, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x41400000    # 12.0f

    goto :goto_1a

    :cond_23
    iget v0, v11, Landroid/graphics/RectF;->left:F

    const v2, 0x3d99999a    # 0.075f

    mul-float v2, v2, v56

    goto :goto_1b

    :goto_1c
    const v44, 0x3f2e147b    # 0.68f

    if-eqz v18, :cond_24

    iget v2, v11, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x3f400000    # 0.75f

    :goto_1d
    mul-float/2addr v3, v7

    :goto_1e
    add-float/2addr v3, v2

    :goto_1f
    move v13, v3

    goto :goto_20

    :cond_24
    if-eqz v28, :cond_26

    iget v2, v11, Landroid/graphics/RectF;->top:F

    if-eqz v16, :cond_25

    const v3, 0x3efae148    # 0.49f

    goto :goto_1d

    :cond_25
    const v3, 0x3f3d70a4    # 0.74f

    goto :goto_1d

    :cond_26
    if-eqz v31, :cond_27

    iget v2, v11, Landroid/graphics/RectF;->top:F

    const v3, 0x3f018937    # 0.506f

    goto :goto_1d

    :cond_27
    if-eqz v29, :cond_28

    iget v2, v11, Landroid/graphics/RectF;->top:F

    mul-float v3, v7, v44

    goto :goto_1e

    :cond_28
    if-eqz v30, :cond_29

    iget v2, v11, Landroid/graphics/RectF;->top:F

    mul-float v53, v53, v7

    add-float v3, v53, v2

    goto :goto_1f

    :cond_29
    iget v2, v11, Landroid/graphics/RectF;->top:F

    const v3, 0x3f2b851f    # 0.67f

    goto :goto_1d

    :goto_20
    const v14, 0x3f19999a    # 0.6f

    const v47, 0x3f23d70a    # 0.64f

    const v50, 0x3f6147ae    # 0.88f

    if-eqz v18, :cond_2a

    mul-float v2, v7, v50

    goto :goto_22

    :cond_2a
    if-eqz v28, :cond_2c

    if-eqz v16, :cond_2b

    move/from16 v45, v40

    goto :goto_21

    :cond_2b
    const v45, 0x3efae148    # 0.49f

    :goto_21
    mul-float v2, v7, v45

    goto :goto_22

    :cond_2c
    if-eqz v31, :cond_2d

    const/high16 v2, 0x42800000    # 64.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    mul-float v3, v7, v39

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    goto :goto_22

    :cond_2d
    if-eqz v29, :cond_2e

    mul-float v2, v7, v47

    goto :goto_22

    :cond_2e
    if-eqz v30, :cond_2f

    const v2, 0x3ec7ae14    # 0.39f

    mul-float/2addr v2, v7

    goto :goto_22

    :cond_2f
    mul-float v2, v7, v14

    :goto_22
    if-lez v63, :cond_30

    const/high16 v3, 0x40000000    # 2.0f

    div-float v4, v42, v3

    sub-float v3, v10, v4

    sub-float/2addr v3, v0

    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v3, v4

    goto :goto_23

    :cond_30
    iget v3, v11, Landroid/graphics/RectF;->right:F

    sub-float v3, v3, v34

    sub-float/2addr v3, v0

    :goto_23
    sget-object v0, Lc/s0;->g:Lc/s0;

    move-object/from16 v4, v62

    invoke-virtual {v4, v0}, Lc/n1;->X(Lc/s0;)I

    move-result v0

    invoke-static {v0}, Lc/r9;->b(I)Landroid/graphics/Typeface;

    move-result-object v5

    iget-object v4, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setTextScaleX(F)V

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v43

    mul-float v12, v43, v0

    const v14, 0x3c23d70a    # 0.01f

    invoke-static {v14, v12}, Ljava/lang/Math;->max(FF)F

    move-result v12

    div-float/2addr v3, v12

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const v3, 0x402aaaab

    mul-float/2addr v2, v3

    const/high16 v3, 0x40000000    # 2.0f

    mul-float v12, v34, v3

    sub-float v51, v56, v12

    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    mul-float/2addr v3, v0

    invoke-static {v14, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    div-float v3, v51, v3

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    iget v3, v11, Landroid/graphics/RectF;->top:F

    sub-float v3, v13, v3

    sub-float v3, v3, v34

    invoke-virtual {v4}, Landroid/graphics/Paint;->ascent()F

    move-result v12

    neg-float v12, v12

    div-float/2addr v3, v12

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v12

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setTextScaleX(F)V

    invoke-virtual {v4, v9}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v14

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float v3, v0, v34

    move/from16 v53, v7

    if-lez v63, :cond_32

    if-lez v61, :cond_32

    mul-float v55, v55, v42

    const/high16 v49, 0x40000000    # 2.0f

    div-float v2, v55, v49

    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v0

    const v57, 0x3db851ec    # 0.09f

    mul-float v7, v42, v57

    invoke-static {v0, v7}, Ljava/lang/Math;->max(FF)F

    move-result v0

    sget-object v7, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    move/from16 v57, v14

    const/4 v14, -0x1

    invoke-virtual {v1, v14}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v15, v10, v6, v2, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    sget-object v14, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v14}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const v14, -0x20d0ca

    invoke-virtual {v1, v14}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v49, 0x40000000    # 2.0f

    div-float v55, v0, v49

    sub-float v2, v2, v55

    invoke-virtual {v15, v10, v6, v2, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-static/range {v61 .. v61}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    sget-object v7, Lc/P3;->Y1:Landroid/graphics/Typeface;

    invoke-virtual {v4, v7}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const v7, 0x3eeb851f    # 0.46f

    mul-float v7, v7, v42

    invoke-virtual {v4, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    mul-float v0, v0, v49

    sub-float v0, v42, v0

    const/high16 v7, 0x40c00000    # 6.0f

    invoke-virtual {v8, v7}, Lc/P3;->s(F)F

    move-result v55

    sub-float v0, v0, v55

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v7, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v7

    cmpl-float v7, v7, v0

    if-lez v7, :cond_31

    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    move-result v7

    mul-float/2addr v7, v0

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    div-float/2addr v7, v0

    invoke-virtual {v4, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    :cond_31
    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    const/high16 v7, 0x40000000    # 2.0f

    div-float/2addr v0, v7

    sub-float v55, v10, v0

    invoke-virtual {v4}, Landroid/graphics/Paint;->ascent()F

    move-result v0

    invoke-virtual {v4}, Landroid/graphics/Paint;->descent()F

    move-result v49

    add-float v49, v49, v0

    div-float v0, v49, v7

    sub-float v7, v6, v0

    invoke-virtual {v4}, Landroid/graphics/Paint;->getTextSize()F

    move-result v59

    const/high16 v60, -0x1000000

    const/16 v61, 0x1

    move-object/from16 v0, p0

    move-object/from16 v64, v1

    move-object/from16 v1, p1

    move v14, v3

    move/from16 v3, v55

    move-object/from16 v65, v4

    const/high16 v19, 0x42000000    # 32.0f

    move v4, v7

    move-object/from16 v66, v5

    const/4 v7, 0x0

    move/from16 v5, v59

    move/from16 v46, v6

    const/high16 v32, 0x43340000    # 180.0f

    const/high16 v33, 0x41a00000    # 20.0f

    move/from16 v6, v60

    move/from16 v26, v10

    move/from16 v35, v53

    move v10, v7

    move/from16 v7, v61

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    move-object/from16 v1, v65

    move-object/from16 v0, v66

    goto :goto_24

    :cond_32
    move-object/from16 v64, v1

    move/from16 v46, v6

    move/from16 v26, v10

    move/from16 v57, v14

    move/from16 v35, v53

    const/4 v10, 0x0

    const/high16 v19, 0x42000000    # 32.0f

    const/high16 v32, 0x43340000    # 180.0f

    const/high16 v33, 0x41a00000    # 20.0f

    move v14, v3

    move-object v1, v4

    move-object v0, v5

    :goto_24
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    invoke-static {v15, v9, v14, v13, v1}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTextScaleX(F)V

    const v48, 0x3dcccccd    # 0.1f

    const v53, 0x3df5c28f    # 0.12f

    if-eqz v18, :cond_34

    :cond_33
    mul-float v7, v35, v25

    :goto_25
    move v5, v7

    goto :goto_27

    :cond_34
    if-eqz v28, :cond_36

    if-eqz v16, :cond_35

    move/from16 v0, v48

    goto :goto_26

    :cond_35
    const v0, 0x3e0f5c29    # 0.14f

    :goto_26
    mul-float v7, v35, v0

    goto :goto_25

    :cond_36
    if-eqz v31, :cond_37

    const/high16 v0, 0x41980000    # 19.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v0

    mul-float v7, v35, v53

    invoke-static {v0, v7}, Ljava/lang/Math;->min(FF)F

    move-result v0

    move v5, v0

    goto :goto_27

    :cond_37
    if-eqz v29, :cond_38

    const v0, 0x3e2e147b    # 0.17f

    goto :goto_26

    :cond_38
    if-eqz v30, :cond_33

    const v0, 0x3de147ae    # 0.11f

    goto :goto_26

    :goto_27
    if-eqz v18, :cond_39

    iget v0, v11, Landroid/graphics/RectF;->top:F

    const v2, 0x3f6e147b    # 0.93f

    :goto_28
    mul-float v7, v35, v2

    :goto_29
    add-float/2addr v7, v0

    move v4, v7

    goto :goto_2b

    :cond_39
    if-eqz v28, :cond_3b

    iget v0, v11, Landroid/graphics/RectF;->top:F

    if-eqz v16, :cond_3a

    goto :goto_2a

    :cond_3a
    const v47, 0x3f70a3d7    # 0.94f

    :goto_2a
    mul-float v7, v35, v47

    goto :goto_29

    :cond_3b
    if-eqz v31, :cond_3c

    iget v0, v11, Landroid/graphics/RectF;->top:F

    const v2, 0x3f1ced91    # 0.613f

    goto :goto_28

    :cond_3c
    if-eqz v29, :cond_3d

    iget v0, v11, Landroid/graphics/RectF;->top:F

    const v2, 0x3f63d70a    # 0.89f

    goto :goto_28

    :cond_3d
    if-eqz v30, :cond_3e

    iget v0, v11, Landroid/graphics/RectF;->top:F

    const v2, 0x3f0a3d71    # 0.54f

    goto :goto_28

    :cond_3e
    iget v0, v11, Landroid/graphics/RectF;->top:F

    const v2, 0x3f666666    # 0.9f

    goto :goto_28

    :goto_2b
    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    const-string v0, "\u043a\u043c/\u0447"

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    sub-float v0, v57, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float v3, v0, v14

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->e:I

    const/4 v7, 0x0

    const-string v2, "\u043a\u043c/\u0447"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    const v28, 0x3eae147b    # 0.34f

    const/16 v14, 0x10

    iget-object v13, v8, Lc/P3;->l:Lc/B0;

    move-object/from16 v12, p3

    iget-object v9, v12, Lc/U0;->t:Lc/j5;

    if-eqz v17, :cond_45

    iget-object v6, v8, Lc/P3;->c0:Lc/r4;

    const/high16 v0, 0x40000000    # 2.0f

    div-float v1, v42, v0

    add-float v1, v1, v46

    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v2

    add-float v16, v2, v1

    iget v0, v11, Landroid/graphics/RectF;->bottom:F

    sub-float v0, v0, v34

    sub-float v0, v0, v27

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sub-float v0, v0, v16

    mul-float v4, v24, v19

    cmpg-float v1, v0, v4

    if-gez v1, :cond_3f

    move-object/from16 v4, p2

    move-object v7, v9

    move/from16 v31, v10

    move-object/from16 v41, v11

    move-object v1, v12

    move-object/from16 v40, v13

    const/high16 v0, 0x40000000    # 2.0f

    const/high16 v2, 0x41000000    # 8.0f

    const/4 v6, 0x1

    const/16 v26, 0x0

    goto/16 :goto_2f

    :cond_3f
    iget v1, v9, Lc/j5;->a:I

    if-eq v1, v14, :cond_40

    const/4 v14, 0x1

    goto :goto_2c

    :cond_40
    const/4 v14, 0x0

    :goto_2c
    mul-float v1, v42, v40

    const v2, 0x3e8f5c29    # 0.28f

    mul-float/2addr v2, v0

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v5

    const v1, 0x3f59999a    # 0.85f

    mul-float v1, v1, v42

    sub-float/2addr v0, v5

    const/high16 v17, 0x41000000    # 8.0f

    mul-float v2, v24, v17

    sub-float/2addr v0, v2

    invoke-static {v10, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v18

    if-eqz v14, :cond_41

    const/high16 v0, 0x40000000    # 2.0f

    div-float v1, v18, v0

    sub-float v3, v26, v1

    iget v4, v6, Lc/r4;->d:I

    iget v2, v9, Lc/j5;->a:I

    move-object v0, v13

    move-object/from16 v1, p1

    move/from16 v19, v4

    move/from16 v4, v16

    move v10, v5

    move/from16 v5, v18

    move-object v7, v6

    move/from16 v6, v19

    invoke-virtual/range {v0 .. v6}, Lc/B0;->a(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_2d

    :cond_41
    move v10, v5

    move-object v7, v6

    :goto_2d
    iget-object v0, v9, Lc/j5;->b:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_42

    iget v0, v9, Lc/j5;->a:I

    invoke-static {v0}, Lc/B0;->c(I)Ljava/lang/String;

    move-result-object v0

    :cond_42
    iget-object v1, v13, Lc/B0;->d:Ljava/lang/Object;

    check-cast v1, Landroid/text/TextPaint;

    const-string v2, "sans"

    const/4 v6, 0x1

    invoke-static {v2, v6}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v2, v13, Lc/B0;->c:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-static {v4, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    div-float v3, v42, v3

    invoke-static {v4, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    mul-float/2addr v3, v10

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    sub-float v1, v26, v1

    if-eqz v14, :cond_43

    add-float v5, v18, v10

    goto :goto_2e

    :cond_43
    move v5, v10

    :goto_2e
    add-float v4, v16, v5

    iget v5, v7, Lc/r4;->d:I

    const/16 v18, 0x1

    const/16 v19, 0x0

    move-object v7, v9

    move-object v9, v13

    const/16 v26, 0x0

    const/16 v31, 0x0

    move-object/from16 v10, p1

    move-object v14, v11

    move-object v11, v0

    move v0, v2

    move/from16 v2, v17

    move v12, v1

    move-object/from16 v1, p3

    move-object/from16 v40, v13

    move v13, v4

    move-object/from16 v4, p2

    move-object/from16 v41, v14

    move/from16 v14, v42

    move v15, v3

    move/from16 v16, v3

    move/from16 v17, v5

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    :cond_44
    :goto_2f
    move/from16 v39, v6

    move-object/from16 v8, v41

    goto/16 :goto_41

    :cond_45
    move-object/from16 v4, p2

    move-object v7, v9

    move/from16 v31, v10

    move-object/from16 v41, v11

    move-object v1, v12

    move-object/from16 v40, v13

    const/high16 v0, 0x40000000    # 2.0f

    const/high16 v2, 0x41000000    # 8.0f

    const/4 v6, 0x1

    const/16 v26, 0x0

    if-eqz v16, :cond_44

    iget-object v15, v8, Lc/P3;->c0:Lc/r4;

    invoke-virtual/range {v40 .. v40}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v41 .. v41}, Landroid/graphics/RectF;->width()F

    move-result v42

    invoke-virtual/range {v41 .. v41}, Landroid/graphics/RectF;->height()F

    move-result v45

    move-object/from16 v13, v41

    iget v9, v13, Landroid/graphics/RectF;->left:F

    iget v12, v13, Landroid/graphics/RectF;->top:F

    iget v3, v7, Lc/j5;->a:I

    if-eq v3, v14, :cond_46

    move v10, v6

    goto :goto_30

    :cond_46
    move/from16 v10, v26

    :goto_30
    if-eqz v10, :cond_48

    iget-object v3, v7, Lc/j5;->b:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_47

    iget v3, v7, Lc/j5;->a:I

    invoke-static {v3}, Lc/B0;->c(I)Ljava/lang/String;

    move-result-object v3

    :cond_47
    :goto_31
    move-object v11, v3

    goto :goto_32

    :cond_48
    iget-object v3, v7, Lc/j5;->d:Ljava/lang/String;

    goto :goto_31

    :goto_32
    iget-object v5, v7, Lc/j5;->c:Ljava/lang/String;

    const v3, 0x3e4ccccd    # 0.2f

    if-eqz v29, :cond_4b

    mul-float v14, v45, v39

    mul-float v0, v42, v53

    invoke-static {v14, v0}, Ljava/lang/Math;->min(FF)F

    move-result v14

    const v0, 0x3f19999a    # 0.6f

    mul-float v0, v0, v42

    add-float/2addr v9, v0

    if-eqz v10, :cond_49

    mul-float v3, v3, v45

    add-float v16, v3, v12

    iget v3, v15, Lc/r4;->d:I

    iget v0, v7, Lc/j5;->a:I

    move/from16 v17, v0

    move-object/from16 v0, v40

    move-object/from16 v1, p1

    move v8, v2

    move/from16 v2, v17

    move/from16 v17, v3

    move v3, v9

    move/from16 v4, v16

    move-object/from16 v29, v5

    move v5, v14

    move/from16 v39, v6

    move/from16 v6, v17

    invoke-virtual/range {v0 .. v6}, Lc/B0;->a(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_33

    :cond_49
    move v8, v2

    move-object/from16 v29, v5

    move/from16 v39, v6

    :goto_33
    iget v0, v13, Landroid/graphics/RectF;->right:F

    const/high16 v1, 0x42300000    # 44.0f

    mul-float v1, v1, v24

    sub-float/2addr v0, v1

    mul-float v37, v37, v45

    add-float v1, v37, v12

    sub-float v2, v0, v9

    if-eqz v10, :cond_4a

    mul-float v3, v24, v8

    add-float v5, v3, v14

    goto :goto_34

    :cond_4a
    move/from16 v5, v31

    :goto_34
    sub-float/2addr v2, v5

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v14

    mul-float v2, v45, v28

    mul-float v16, v24, v33

    iget v3, v15, Lc/r4;->d:I

    const/16 v18, 0x1

    const/16 v19, 0x1

    move-object/from16 v9, v40

    move-object/from16 v10, p1

    move/from16 v33, v12

    move v12, v0

    move-object v6, v13

    move v13, v1

    move-object v5, v15

    move v15, v2

    move/from16 v17, v3

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    mul-float v50, v50, v45

    add-float v13, v50, v33

    mul-float v14, v42, v38

    mul-float v15, v45, v20

    const/high16 v1, 0x41600000    # 14.0f

    mul-float v16, v24, v1

    iget v1, v5, Lc/r4;->e:I

    const/16 v18, 0x0

    move-object/from16 v11, v29

    move/from16 v17, v1

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    move-object v8, v6

    goto/16 :goto_41

    :cond_4b
    move v8, v2

    move-object/from16 v29, v5

    move/from16 v39, v6

    move/from16 v33, v12

    move-object v6, v13

    move-object v5, v15

    if-eqz v30, :cond_4e

    const/high16 v0, 0x3e800000    # 0.25f

    mul-float v0, v0, v45

    mul-float v3, v3, v42

    invoke-static {v0, v3}, Ljava/lang/Math;->min(FF)F

    move-result v12

    const v0, 0x3d75c28f    # 0.06f

    mul-float v13, v42, v0

    add-float/2addr v9, v13

    if-eqz v10, :cond_4c

    mul-float v37, v37, v45

    add-float v4, v37, v33

    iget v14, v5, Lc/r4;->d:I

    iget v2, v7, Lc/j5;->a:I

    move-object/from16 v0, v40

    move-object/from16 v1, p1

    move v3, v9

    move-object v15, v5

    move v5, v12

    move-object v8, v6

    move v6, v14

    invoke-virtual/range {v0 .. v6}, Lc/B0;->a(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_35

    :cond_4c
    move-object v15, v5

    move-object v8, v6

    :goto_35
    if-eqz v10, :cond_4d

    const v0, 0x3ccccccd    # 0.025f

    mul-float v42, v42, v0

    add-float v5, v42, v12

    goto :goto_36

    :cond_4d
    move/from16 v5, v31

    :goto_36
    add-float v0, v9, v5

    iget v1, v8, Landroid/graphics/RectF;->right:F

    sub-float/2addr v1, v0

    sub-float/2addr v1, v13

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const v2, 0x3f4a3d71    # 0.79f

    mul-float v2, v2, v45

    add-float v13, v2, v33

    const v2, 0x3e6147ae    # 0.22f

    mul-float v2, v2, v45

    const/high16 v3, 0x41e00000    # 28.0f

    mul-float v16, v24, v3

    iget v3, v15, Lc/r4;->d:I

    const/16 v18, 0x1

    const/16 v19, 0x0

    move-object/from16 v9, v40

    move-object/from16 v10, p1

    move v12, v0

    move v14, v1

    move-object v6, v15

    move v15, v2

    move/from16 v17, v3

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    const v2, 0x3f6b851f    # 0.92f

    mul-float v2, v2, v45

    add-float v13, v2, v33

    mul-float v15, v45, v48

    const/high16 v2, 0x41900000    # 18.0f

    mul-float v16, v24, v2

    iget v2, v6, Lc/r4;->e:I

    const/16 v18, 0x0

    move-object/from16 v11, v29

    move/from16 v17, v2

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    goto/16 :goto_41

    :cond_4e
    move-object v8, v6

    move-object v6, v5

    mul-float v0, v24, v32

    cmpg-float v0, v42, v0

    if-gez v0, :cond_4f

    move/from16 v20, v39

    goto :goto_37

    :cond_4f
    move/from16 v20, v26

    :goto_37
    const/16 v30, 0xa

    if-eqz v20, :cond_50

    move/from16 v0, v30

    goto :goto_38

    :cond_50
    move v0, v14

    :goto_38
    int-to-float v0, v0

    mul-float v0, v0, v24

    add-float v3, v0, v9

    const/16 v12, 0x1e

    if-eqz v20, :cond_51

    const/16 v0, 0x18

    goto :goto_39

    :cond_51
    move v0, v12

    :goto_39
    int-to-float v0, v0

    mul-float v5, v0, v24

    if-eqz v10, :cond_52

    const v0, 0x3f31a9fc    # 0.694f

    mul-float v0, v0, v45

    add-float v4, v0, v33

    iget v13, v6, Lc/r4;->d:I

    iget v2, v7, Lc/j5;->a:I

    move-object/from16 v0, v40

    move-object/from16 v1, p1

    move-object v15, v6

    move v6, v13

    invoke-virtual/range {v0 .. v6}, Lc/B0;->a(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_3a

    :cond_52
    move-object v15, v6

    :goto_3a
    if-eqz v10, :cond_54

    if-eqz v20, :cond_53

    const/16 v0, 0x2a

    goto :goto_3b

    :cond_53
    const/16 v0, 0x3a

    goto :goto_3b

    :cond_54
    if-eqz v20, :cond_55

    move/from16 v0, v30

    goto :goto_3b

    :cond_55
    move v0, v14

    :goto_3b
    int-to-float v0, v0

    mul-float v0, v0, v24

    add-float/2addr v0, v9

    iget v1, v8, Landroid/graphics/RectF;->right:F

    sub-float/2addr v1, v0

    if-eqz v20, :cond_56

    const/16 v2, 0x8

    goto :goto_3c

    :cond_56
    const/16 v2, 0x12

    :goto_3c
    int-to-float v2, v2

    mul-float v2, v2, v24

    sub-float/2addr v1, v2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const v2, 0x3f51a9fc    # 0.819f

    mul-float v2, v2, v45

    add-float v13, v2, v33

    if-eqz v20, :cond_57

    const/16 v12, 0x14

    :cond_57
    int-to-float v2, v12

    mul-float v2, v2, v24

    if-eqz v20, :cond_58

    const/16 v3, 0xe

    goto :goto_3d

    :cond_58
    const/16 v3, 0x13

    :goto_3d
    int-to-float v3, v3

    mul-float v16, v3, v24

    iget v3, v15, Lc/r4;->d:I

    const/16 v18, 0x1

    const/16 v19, 0x0

    move-object/from16 v9, v40

    move-object/from16 v10, p1

    move v12, v0

    move v4, v14

    move v14, v1

    move-object v5, v15

    move v15, v2

    move/from16 v17, v3

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    const v2, 0x3f6ccccd    # 0.925f

    mul-float v45, v45, v2

    add-float v13, v45, v33

    if-eqz v20, :cond_59

    const/16 v14, 0xc

    goto :goto_3e

    :cond_59
    move v14, v4

    :goto_3e
    int-to-float v2, v14

    mul-float v15, v2, v24

    if-eqz v20, :cond_5a

    :goto_3f
    move/from16 v2, v30

    goto :goto_40

    :cond_5a
    const/16 v30, 0xd

    goto :goto_3f

    :goto_40
    int-to-float v2, v2

    mul-float v16, v2, v24

    iget v2, v5, Lc/r4;->e:I

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v9, v40

    move-object/from16 v10, p1

    move-object/from16 v11, v29

    move v12, v0

    move v14, v1

    move/from16 v17, v2

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    :goto_41
    cmpl-float v0, v27, v31

    if-lez v0, :cond_5b

    iget-object v11, v7, Lc/j5;->c:Ljava/lang/String;

    const/high16 v0, 0x41000000    # 8.0f

    move-object/from16 v7, p0

    iget-object v1, v7, Lc/P3;->c0:Lc/r4;

    iget v2, v8, Landroid/graphics/RectF;->left:F

    add-float v12, v2, v34

    iget v2, v8, Landroid/graphics/RectF;->bottom:F

    sub-float v13, v2, v34

    invoke-virtual/range {v40 .. v40}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/high16 v2, 0x41b00000    # 22.0f

    mul-float v2, v2, v24

    const v3, 0x3f266666    # 0.65f

    mul-float v3, v3, v27

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v15

    const/high16 v2, 0x41600000    # 14.0f

    mul-float v2, v2, v24

    mul-float v3, v27, v52

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v16

    iget v1, v1, Lc/r4;->e:I

    const/16 v18, 0x0

    const/16 v19, 0x0

    move-object/from16 v9, v40

    move-object/from16 v10, p1

    move/from16 v14, v51

    move/from16 v17, v1

    invoke-virtual/range {v9 .. v19}, Lc/B0;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V

    :goto_42
    move-object/from16 v1, p3

    goto :goto_43

    :cond_5b
    const/high16 v0, 0x41000000    # 8.0f

    move-object/from16 v7, p0

    goto :goto_42

    :goto_43
    iget-boolean v1, v1, Lc/U0;->u:Z

    if-eqz v1, :cond_5e

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-virtual {v7, v1}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual {v7, v0}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v2

    const v3, 0x3e3851ec    # 0.18f

    mul-float/2addr v2, v3

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v4

    mul-float/2addr v4, v3

    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v9

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v1, 0x43d20000    # 420.0f

    invoke-virtual {v7, v1}, Lc/P3;->s(F)F

    move-result v1

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_5c

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v0

    const/high16 v1, 0x430c0000    # 140.0f

    invoke-virtual {v7, v1}, Lc/P3;->s(F)F

    move-result v1

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_5c

    move/from16 v10, v39

    goto :goto_44

    :cond_5c
    move/from16 v10, v26

    :goto_44
    iget v0, v8, Landroid/graphics/RectF;->left:F

    iget v1, v8, Landroid/graphics/RectF;->right:F

    sub-float/2addr v1, v9

    const/high16 v2, 0x40c00000    # 6.0f

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v3

    add-float/2addr v3, v0

    invoke-static {v1, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v11

    mul-float v44, v44, v9

    iget v0, v8, Landroid/graphics/RectF;->top:F

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v1

    add-float v12, v1, v0

    const/high16 v0, 0x40000000    # 2.0f

    invoke-virtual {v7, v0}, Lc/P3;->s(F)F

    move-result v0

    mul-float v1, v9, v53

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v6

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    move-object/from16 v13, v64

    invoke-virtual {v13, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v14, -0x20d0ca

    invoke-virtual {v13, v14}, Landroid/graphics/Paint;->setColor(I)V

    add-float v15, v11, v9

    add-float v4, v12, v44

    move-object/from16 v0, p1

    move v1, v11

    move v2, v12

    move v3, v15

    move v5, v6

    move-object v7, v13

    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/4 v0, -0x1

    invoke-virtual {v13, v0}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v36, v36, v9

    add-float v0, v36, v11

    mul-float v28, v28, v9

    add-float v1, v28, v12

    mul-float v2, v9, v25

    move-object/from16 v11, p1

    invoke-virtual {v11, v0, v1, v2, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-virtual {v13, v14}, Landroid/graphics/Paint;->setColor(I)V

    const v2, 0x3d8f5c29    # 0.07f

    mul-float/2addr v2, v9

    invoke-virtual {v11, v0, v1, v2, v13}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    if-eqz v10, :cond_5d

    const/high16 v0, 0x41300000    # 11.0f

    move-object/from16 v10, p0

    invoke-virtual {v10, v0}, Lc/P3;->s(F)F

    move-result v0

    const/high16 v1, 0x41100000    # 9.0f

    invoke-virtual {v10, v1}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v2

    mul-float v2, v2, v22

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v5

    const/high16 v0, 0x40a00000    # 5.0f

    invoke-virtual {v10, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v3, v0, v15

    const v0, 0x3f07ae14    # 0.53f

    mul-float/2addr v9, v0

    add-float v4, v9, v12

    const v6, -0x20d0ca

    const/4 v7, 0x1

    const-string v2, "\u041a\u0410\u041c\u0415\u0420\u0410"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    goto :goto_45

    :cond_5d
    move-object/from16 v10, p0

    goto :goto_45

    :cond_5e
    move-object/from16 v11, p1

    move-object v10, v7

    :goto_45
    iget-object v0, v10, Lc/P3;->s:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_5f

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f03001c

    invoke-virtual {v0, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, v10, Lc/P3;->s:Landroid/graphics/drawable/Drawable;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const v1, 0x7f0300c8

    invoke-virtual {v0, v1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, v10, Lc/P3;->t:Landroid/graphics/drawable/Drawable;

    :cond_5f
    iget-boolean v0, v10, Lc/P3;->r:Z

    if-eqz v0, :cond_60

    iget-object v0, v10, Lc/P3;->t:Landroid/graphics/drawable/Drawable;

    goto :goto_46

    :cond_60
    iget-object v0, v10, Lc/P3;->s:Landroid/graphics/drawable/Drawable;

    :goto_46
    iget-object v1, v10, Lc/P3;->c0:Lc/r4;

    iget v1, v1, Lc/r4;->e:I

    invoke-static {v1}, Lc/q9;->a(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    iget-object v1, v10, Lc/P3;->u:Landroid/graphics/RectF;

    move-object/from16 v2, p2

    iget v3, v2, Landroid/graphics/RectF;->left:F

    add-float v3, v3, v23

    iget v2, v2, Landroid/graphics/RectF;->top:F

    add-float v2, v2, v23

    add-float v4, v3, v21

    add-float v5, v2, v21

    invoke-virtual {v1, v3, v2, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget v2, v1, Landroid/graphics/RectF;->left:F

    float-to-int v2, v2

    iget v3, v1, Landroid/graphics/RectF;->top:F

    float-to-int v3, v3

    iget v4, v1, Landroid/graphics/RectF;->right:F

    float-to-int v4, v4

    iget v1, v1, Landroid/graphics/RectF;->bottom:F

    float-to-int v1, v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v0, v11}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public final E(Landroid/graphics/Canvas;IFFFI)V
    .locals 3

    iget-object v0, p0, Lc/P3;->T:Landroid/graphics/RectF;

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr p5, v1

    sub-float v1, p3, p5

    sub-float v2, p4, p5

    add-float/2addr p3, p5

    add-float/2addr p4, p5

    invoke-virtual {v0, v1, v2, p3, p4}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    invoke-static {p6}, Lc/q9;->a(I)I

    move-result p4

    invoke-static {p3, p1, p2, p4, v0}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    return-void
.end method

.method public final F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lc/P3;->N:Landroid/graphics/Paint;

    if-eqz p7, :cond_0

    sget-object p7, Lc/P3;->Y1:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_0
    sget-object p7, Lc/P3;->X1:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {v0, p7}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setColor(I)V

    if-nez p2, :cond_1

    const-string p2, ""

    :cond_1
    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final G(Landroid/graphics/Canvas;FFZF)V
    .locals 13

    move-object v6, p1

    move/from16 v0, p3

    const/high16 v1, 0x41c00000    # 24.0f

    div-float v1, p5, v1

    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    const/high16 v3, 0x41000000    # 8.0f

    mul-float/2addr v3, v1

    sub-float v3, p2, v3

    const/high16 v4, 0x40800000    # 4.0f

    mul-float/2addr v4, v1

    sub-float v7, v0, v4

    invoke-virtual {v2, v3, v7}, Landroid/graphics/Path;->moveTo(FF)V

    sub-float v5, p2, v4

    invoke-virtual {v2, v5, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v8, 0x40000000    # 2.0f

    mul-float/2addr v8, v1

    add-float/2addr v8, p2

    const/high16 v9, 0x41100000    # 9.0f

    mul-float/2addr v9, v1

    sub-float v10, v0, v9

    invoke-virtual {v2, v8, v10}, Landroid/graphics/Path;->lineTo(FF)V

    add-float/2addr v9, v0

    invoke-virtual {v2, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    add-float v8, v0, v4

    invoke-virtual {v2, v5, v8}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v2, v3, v8}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v2}, Landroid/graphics/Path;->close()V

    new-instance v9, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v9, v3}, Landroid/graphics/Paint;-><init>(I)V

    const v3, -0xdfdedc

    invoke-virtual {v9, v3}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {p1, v2, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v2, 0x3fe66666    # 1.8f

    move-object v10, p0

    invoke-virtual {p0, v2}, Lc/P3;->s(F)F

    move-result v2

    const v3, 0x3db851ec    # 0.09f

    mul-float v3, v3, p5

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const/high16 v2, 0x40a00000    # 5.0f

    if-nez p4, :cond_0

    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    mul-float/2addr v2, v1

    add-float/2addr v2, p2

    invoke-virtual {v3, v2, v7}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x41200000    # 10.0f

    mul-float/2addr v1, v4

    add-float/2addr v1, p2

    invoke-virtual {v3, v1, v0, v2, v8}, Landroid/graphics/Path;->quadTo(FFFF)V

    invoke-virtual {p1, v3, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    goto :goto_0

    :cond_0
    mul-float/2addr v2, v1

    add-float v11, v2, p2

    const/high16 v0, 0x41300000    # 11.0f

    mul-float/2addr v1, v0

    add-float v12, v1, p2

    move-object v0, p1

    move v1, v11

    move v2, v7

    move v3, v12

    move v4, v8

    move-object v5, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v1, v12

    move v3, v11

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :goto_0
    return-void
.end method

.method public final H(Lc/s0;Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V
    .locals 24

    move-object/from16 v9, p0

    move-object/from16 v0, p1

    move-object/from16 v11, p2

    move-object/from16 v12, p3

    move-object/from16 v10, p4

    sget-object v1, Lc/s0;->d:Lc/s0;

    sget-object v2, Lc/s0;->m:Lc/s0;

    sget-object v3, Lc/s0;->i:Lc/s0;

    const/high16 v4, 0x42c80000    # 100.0f

    const/16 v5, 0xff

    const/high16 v6, 0x41800000    # 16.0f

    iget-object v8, v9, Lc/P3;->C1:Lc/n1;

    iget-object v15, v9, Lc/P3;->A:Lc/g1;

    if-ne v0, v1, :cond_0

    sget-object v7, Lc/q9;->z:Ljava/lang/ThreadLocal;

    invoke-virtual {v7}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Lc/q9;

    invoke-virtual {v7}, Ljava/lang/ThreadLocal;->remove()V

    move-object/from16 v20, v1

    move-object/from16 v23, v2

    move-object/from16 v21, v8

    move-object/from16 v22, v15

    move-object/from16 v15, v16

    goto/16 :goto_4

    :cond_0
    iget-object v7, v9, Lc/P3;->u0:Ljava/util/EnumMap;

    invoke-virtual {v7, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Lc/q9;

    if-nez v16, :cond_1

    new-instance v14, Lc/q9;

    invoke-direct {v14}, Lc/q9;-><init>()V

    invoke-virtual {v7, v0, v14}, Ljava/util/EnumMap;->put(Ljava/lang/Enum;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    move-object/from16 v14, v16

    :goto_0
    if-eq v0, v3, :cond_2

    if-eq v0, v2, :cond_2

    invoke-virtual {v8, v0}, Lc/n1;->s0(Lc/s0;)Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-virtual {v8, v0}, Lc/n1;->W(Lc/s0;)I

    move-result v7

    rsub-int/lit8 v7, v7, 0x64

    mul-int/2addr v7, v5

    int-to-float v7, v7

    div-float/2addr v7, v4

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    :goto_1
    iget-object v4, v9, Lc/P3;->a:Lc/W3;

    iget-object v5, v9, Lc/P3;->c0:Lc/r4;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v13

    int-to-float v13, v13

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v10

    int-to-float v10, v10

    move-object/from16 v20, v1

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual {v8}, Lc/n1;->S()I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v6

    move-object/from16 v21, v8

    invoke-virtual {v15, v0}, Lc/g1;->i(Lc/s0;)Z

    move-result v8

    iput-boolean v8, v14, Lc/q9;->w:Z

    iget v8, v12, Landroid/graphics/RectF;->right:F

    invoke-static {v13, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    iget v13, v12, Landroid/graphics/RectF;->bottom:F

    invoke-static {v10, v13}, Ljava/lang/Math;->max(FF)F

    move-result v10

    const/4 v13, 0x0

    iput-boolean v13, v14, Lc/q9;->j:Z

    if-nez v4, :cond_3

    move-object/from16 v22, v15

    const/4 v13, 0x0

    goto :goto_2

    :cond_3
    iget-object v13, v4, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v13}, Landroid/graphics/Bitmap;->getGenerationId()I

    move-result v13

    move-object/from16 v22, v15

    :goto_2
    iget-object v15, v14, Lc/q9;->a:Landroid/graphics/RectF;

    invoke-virtual {v15, v12}, Landroid/graphics/RectF;->equals(Ljava/lang/Object;)Z

    move-result v23

    if-eqz v23, :cond_4

    move-object/from16 v23, v2

    iget-object v2, v14, Lc/q9;->m:Lc/W3;

    if-ne v2, v4, :cond_5

    iget-object v2, v14, Lc/q9;->n:Lc/r4;

    if-ne v2, v5, :cond_5

    iget v2, v14, Lc/q9;->o:F

    cmpl-float v2, v2, v8

    if-nez v2, :cond_5

    iget v2, v14, Lc/q9;->p:F

    cmpl-float v2, v2, v10

    if-nez v2, :cond_5

    iget v2, v14, Lc/q9;->q:F

    cmpl-float v2, v2, v1

    if-nez v2, :cond_5

    iget v2, v14, Lc/q9;->r:F

    cmpl-float v2, v2, v6

    if-nez v2, :cond_5

    iget v2, v14, Lc/q9;->s:I

    if-ne v2, v7, :cond_5

    iget v2, v14, Lc/q9;->t:I

    if-eq v2, v13, :cond_6

    goto :goto_3

    :cond_4
    move-object/from16 v23, v2

    :cond_5
    :goto_3
    invoke-virtual {v15, v12}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iput-object v4, v14, Lc/q9;->m:Lc/W3;

    iput-object v5, v14, Lc/q9;->n:Lc/r4;

    iput v8, v14, Lc/q9;->o:F

    iput v10, v14, Lc/q9;->p:F

    iput v1, v14, Lc/q9;->q:F

    iput v6, v14, Lc/q9;->r:F

    iput v7, v14, Lc/q9;->s:I

    iput v13, v14, Lc/q9;->t:I

    const/4 v1, 0x1

    iput-boolean v1, v14, Lc/q9;->u:Z

    :cond_6
    iget-object v1, v14, Lc/q9;->c:Landroid/graphics/Matrix;

    invoke-virtual {v11, v1}, Landroid/graphics/Canvas;->getMatrix(Landroid/graphics/Matrix;)V

    iget-object v2, v14, Lc/q9;->b:Landroid/graphics/Matrix;

    invoke-virtual {v1, v2}, Landroid/graphics/Matrix;->invert(Landroid/graphics/Matrix;)Z

    move-result v1

    if-nez v1, :cond_7

    invoke-virtual {v2}, Landroid/graphics/Matrix;->reset()V

    :cond_7
    sget-object v1, Lc/q9;->z:Ljava/lang/ThreadLocal;

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/q9;

    invoke-virtual {v1, v14}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    move-object v15, v2

    :goto_4
    :try_start_0
    iget-boolean v1, v9, Lc/P3;->L1:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_5

    sget-object v2, Lc/s0;->c:Lc/s0;

    if-nez v1, :cond_f

    if-eq v0, v3, :cond_f

    move-object/from16 v1, v23

    if-eq v0, v1, :cond_f

    move-object/from16 v8, v21

    :try_start_1
    invoke-virtual {v8, v0}, Lc/n1;->s0(Lc/s0;)Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual {v8, v0}, Lc/n1;->W(Lc/s0;)I

    move-result v1

    rsub-int/lit8 v1, v1, 0x64

    const/16 v3, 0xff

    mul-int/2addr v1, v3

    int-to-float v1, v1

    const/high16 v3, 0x42c80000    # 100.0f

    div-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget-object v3, v9, Lc/P3;->c0:Lc/r4;

    iget v3, v3, Lc/r4;->b:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    sget-object v5, Lc/s0;->h:Lc/s0;

    if-eq v0, v2, :cond_9

    if-ne v0, v5, :cond_8

    goto :goto_6

    :cond_8
    move-object/from16 v23, v15

    :goto_5
    move-object/from16 v4, v20

    goto/16 :goto_a

    :cond_9
    :goto_6
    :try_start_2
    iget-object v6, v9, Lc/P3;->a:Lc/W3;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz v6, :cond_8

    iget-object v6, v9, Lc/P3;->c:Landroid/graphics/Path;

    :try_start_3
    invoke-virtual {v6}, Landroid/graphics/Path;->reset()V

    const/high16 v7, 0x41800000    # 16.0f

    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v10

    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v13

    sget-object v7, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v6, v12, v10, v13, v7}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/Canvas;->save()I

    move-result v7

    invoke-virtual {v11, v6}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v6

    int-to-float v6, v6

    iget-object v10, v9, Lc/P3;->a:Lc/W3;

    iget-object v10, v10, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v10}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v10

    int-to-float v10, v10

    div-float/2addr v6, v10

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v10

    int-to-float v10, v10

    iget-object v13, v9, Lc/P3;->a:Lc/W3;

    iget-object v13, v13, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v13}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v13

    int-to-float v13, v13

    div-float/2addr v10, v13

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v6

    iget-object v10, v9, Lc/P3;->a:Lc/W3;

    iget-object v10, v10, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v10}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v10

    int-to-float v10, v10

    mul-float/2addr v10, v6

    iget-object v13, v9, Lc/P3;->a:Lc/W3;

    iget-object v13, v13, Lc/W3;->a:Landroid/graphics/Bitmap;

    invoke-virtual {v13}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v13
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    int-to-float v13, v13

    mul-float/2addr v13, v6

    iget-object v6, v9, Lc/P3;->b:Landroid/graphics/RectF;

    :try_start_4
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v14

    int-to-float v14, v14

    sub-float/2addr v14, v10

    const/high16 v16, 0x40000000    # 2.0f

    div-float v14, v14, v16

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    int-to-float v4, v4

    sub-float/2addr v4, v13

    div-float v4, v4, v16

    move-object/from16 v23, v15

    :try_start_5
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v15

    int-to-float v15, v15

    add-float/2addr v15, v10

    div-float v15, v15, v16

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v10

    int-to-float v10, v10

    add-float/2addr v10, v13

    div-float v10, v10, v16

    invoke-virtual {v6, v14, v4, v15, v10}, Landroid/graphics/RectF;->set(FFFF)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    iget-object v4, v9, Lc/P3;->M:Landroid/graphics/Paint;

    const/4 v10, 0x0

    :try_start_6
    invoke-virtual {v4, v10}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v13, -0x1

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v13, 0x1

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setFilterBitmap(Z)V

    if-ne v0, v5, :cond_a

    invoke-virtual {v4, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    goto :goto_8

    :catchall_0
    move-exception v0

    :goto_7
    move-object/from16 v13, v23

    goto/16 :goto_1f

    :cond_a
    :goto_8
    iget-object v13, v9, Lc/P3;->a:Lc/W3;

    iget-object v13, v13, Lc/W3;->b:Landroid/graphics/Bitmap;

    invoke-virtual {v11, v13, v10, v6, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    const/16 v6, 0xff

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setAlpha(I)V

    iget-object v4, v9, Lc/P3;->c0:Lc/r4;

    sget-object v6, Lc/r4;->p:Lc/r4;

    if-ne v4, v6, :cond_c

    if-ne v0, v5, :cond_b

    int-to-float v4, v1

    const/high16 v5, 0x437f0000    # 255.0f

    div-float/2addr v4, v5

    goto :goto_9

    :cond_b
    const/high16 v4, 0x3f800000    # 1.0f

    :goto_9
    const/high16 v5, 0x43330000    # 179.0f

    mul-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    shl-int/lit8 v4, v4, 0x18

    invoke-virtual {v11, v4}, Landroid/graphics/Canvas;->drawColor(I)V

    :cond_c
    invoke-virtual {v11, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto/16 :goto_5

    :catchall_1
    move-exception v0

    move-object/from16 v23, v15

    goto :goto_7

    :goto_a
    if-ne v0, v4, :cond_d

    const/high16 v7, 0x42000000    # 32.0f

    goto :goto_b

    :cond_d
    const/high16 v7, 0x41800000    # 16.0f

    :goto_b
    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v4

    shl-int/lit8 v1, v1, 0x18

    const v5, 0xffffff

    and-int/2addr v3, v5

    or-int/2addr v1, v3

    invoke-virtual {v9, v11, v12, v4, v1}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    goto :goto_c

    :cond_e
    move-object/from16 v23, v15

    goto :goto_c

    :cond_f
    move-object/from16 v23, v15

    move-object/from16 v8, v21

    :goto_c
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/high16 v10, 0x41400000    # 12.0f

    packed-switch v1, :pswitch_data_0

    :cond_10
    :goto_d
    :pswitch_0
    move-object/from16 v13, v23

    goto/16 :goto_1d

    :pswitch_1
    iget-object v1, v9, Lc/P3;->n:Lc/G0;

    iget-object v4, v9, Lc/P3;->c0:Lc/r4;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v5

    move-object/from16 v13, v22

    iget-boolean v2, v13, Lc/g1;->J:Z

    if-nez v2, :cond_12

    iget-object v2, v9, Lc/P3;->J:Lc/m0;

    if-nez v2, :cond_11

    goto :goto_f

    :cond_11
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v2

    iget-object v3, v9, Lc/P3;->J:Lc/m0;

    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    :goto_e
    move v6, v2

    goto :goto_10

    :cond_12
    :goto_f
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v2

    goto :goto_e

    :goto_10
    iget-boolean v2, v13, Lc/g1;->J:Z

    if-nez v2, :cond_14

    iget-object v2, v9, Lc/P3;->J:Lc/m0;

    if-nez v2, :cond_13

    goto :goto_12

    :cond_13
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->height()F

    move-result v2

    iget-object v3, v9, Lc/P3;->J:Lc/m0;

    invoke-virtual {v3}, Lc/m0;->b()F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    :goto_11
    move v7, v2

    goto :goto_13

    :cond_14
    :goto_12
    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->height()F

    move-result v2

    goto :goto_11

    :goto_13
    move-object/from16 v2, p2

    move-object/from16 v3, p3

    invoke-virtual/range {v1 .. v7}, Lc/G0;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;FFF)V

    iget-object v1, v9, Lc/P3;->n:Lc/G0;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isShown()Z

    move-result v2

    if-eqz v2, :cond_15

    iget-boolean v2, v9, Lc/P3;->U1:Z

    if-eqz v2, :cond_15

    const/4 v2, 0x1

    goto :goto_14

    :cond_15
    const/4 v2, 0x0

    :goto_14
    invoke-virtual {v1, v9, v2}, Lc/G0;->k(Ljava/lang/Object;Z)V

    iget-object v1, v9, Lc/P3;->o:Lc/C0;

    iget-object v2, v9, Lc/P3;->c0:Lc/r4;

    iget-boolean v3, v13, Lc/g1;->J:Z

    if-eqz v3, :cond_16

    invoke-virtual {v13, v0}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    if-nez v0, :cond_16

    const/4 v13, 0x1

    goto :goto_15

    :cond_16
    const/4 v13, 0x0

    :goto_15
    invoke-virtual {v1, v11, v2, v13}, Lc/C0;->b(Landroid/graphics/Canvas;Lc/r4;Z)V

    goto :goto_d

    :pswitch_2
    invoke-virtual {v9, v11, v12}, Lc/P3;->B(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    goto :goto_d

    :pswitch_3
    move-object/from16 v13, v22

    invoke-virtual {v13, v0}, Lc/g1;->i(Lc/s0;)Z

    move-result v0

    if-eqz v0, :cond_10

    const-string v3, "\u0412\u0438\u0434\u0436\u0435\u0442\u044b Android"

    iget v0, v12, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v10}, Lc/P3;->s(F)F

    move-result v1

    add-float v4, v0, v1

    iget v0, v12, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41e00000    # 28.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v5, v0, v1

    const/high16 v0, 0x41800000    # 16.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v6

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v7, v0, Lc/r4;->d:I

    const/4 v8, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    invoke-virtual/range {v1 .. v8}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    goto/16 :goto_d

    :pswitch_4
    move-object/from16 v13, v22

    iget-object v1, v9, Lc/P3;->t1:Lc/g0;

    invoke-virtual {v13, v0}, Lc/g1;->q(Lc/s0;)Lc/r0;

    iget-boolean v0, v13, Lc/g1;->J:Z

    iget-object v2, v9, Lc/P3;->c0:Lc/r4;

    invoke-virtual {v1, v11, v12, v0, v2}, Lc/g0;->e(Landroid/graphics/Canvas;Landroid/graphics/RectF;ZLc/r4;)V

    goto/16 :goto_d

    :pswitch_5
    move-object/from16 v0, p4

    invoke-virtual {v9, v11, v12, v0}, Lc/P3;->D(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V

    goto/16 :goto_d

    :pswitch_6
    move-object/from16 v0, p4

    const-string v3, "\u041c\u0410\u041d\u0401\u0412\u0420"

    iget v1, v12, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v10}, Lc/P3;->s(F)F

    move-result v2

    add-float v4, v1, v2

    iget v1, v12, Landroid/graphics/RectF;->top:F

    const/high16 v13, 0x41c00000    # 24.0f

    invoke-virtual {v9, v13}, Lc/P3;->s(F)F

    move-result v2

    add-float v5, v1, v2

    invoke-virtual {v9, v10}, Lc/P3;->s(F)F

    move-result v6

    iget-object v1, v9, Lc/P3;->c0:Lc/r4;

    iget v7, v1, Lc/r4;->e:I

    const/4 v8, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    invoke-virtual/range {v1 .. v8}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    iget-object v1, v0, Lc/U0;->h:Ljava/lang/String;

    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v2

    invoke-virtual {v9, v13}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v2, v3

    const/high16 v3, 0x41900000    # 18.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v4

    const/4 v5, 0x1

    invoke-virtual {v9, v1, v2, v4, v5}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v4

    iget v1, v12, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v10}, Lc/P3;->s(F)F

    move-result v2

    add-float v5, v1, v2

    iget v1, v12, Landroid/graphics/RectF;->top:F

    const/high16 v2, 0x42480000    # 50.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float v6, v1, v2

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v7

    iget-object v1, v9, Lc/P3;->c0:Lc/r4;

    iget v8, v1, Lc/r4;->d:I

    const/4 v14, 0x1

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object v3, v4

    move v4, v5

    move v5, v6

    move v6, v7

    move v7, v8

    move v8, v14

    invoke-virtual/range {v1 .. v8}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    iget-object v0, v0, Lc/U0;->i:Ljava/lang/String;

    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v1

    invoke-virtual {v9, v13}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v9, v0, v1, v3, v4}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v3

    iget v0, v12, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v10}, Lc/P3;->s(F)F

    move-result v1

    add-float v4, v0, v1

    iget v0, v12, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x42940000    # 74.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v5, v0, v1

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v6

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v7, v0, Lc/r4;->d:I

    const/4 v8, 0x0

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    invoke-virtual/range {v1 .. v8}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    goto/16 :goto_d

    :pswitch_7
    invoke-virtual {v9, v11, v12}, Lc/P3;->C(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    goto/16 :goto_d

    :pswitch_8
    invoke-virtual {v9, v11, v12}, Lc/P3;->v(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    goto/16 :goto_d

    :pswitch_9
    move-object/from16 v0, p4

    move-object/from16 v13, v22

    :try_start_7
    invoke-virtual {v13, v2}, Lc/g1;->q(Lc/s0;)Lc/r0;

    move-result-object v1

    iget-object v10, v9, Lc/P3;->m:Lc/S0;

    iget-object v1, v1, Lc/r0;->b:Lc/t0;

    iget-object v1, v0, Lc/U0;->q:Lc/R0;

    iget-object v14, v0, Lc/U0;->d:Ljava/lang/String;

    iget v15, v0, Lc/U0;->j:I

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    iget-boolean v3, v13, Lc/g1;->J:Z

    const/4 v4, 0x1

    xor-int/lit8 v18, v3, 0x1

    iget-object v3, v9, Lc/P3;->L0:Landroid/graphics/RectF;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    move-object/from16 v11, p2

    move-object/from16 v12, p3

    move-object v13, v1

    move-object/from16 v7, v23

    move-object/from16 v16, v0

    move/from16 v17, v2

    move-object/from16 v19, v3

    :try_start_8
    invoke-virtual/range {v10 .. v19}, Lc/S0;->c(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/R0;Ljava/lang/String;ILc/r4;FZLandroid/graphics/RectF;)V

    move-object v13, v7

    goto/16 :goto_1d

    :catchall_2
    move-exception v0

    :goto_16
    move-object v13, v7

    goto/16 :goto_1f

    :catchall_3
    move-exception v0

    move-object/from16 v7, v23

    goto :goto_16

    :pswitch_a
    move-object/from16 v0, p4

    move-object/from16 v13, v22

    move-object/from16 v7, v23

    const/4 v4, 0x0

    iget-object v10, v9, Lc/P3;->R:Landroid/graphics/RectF;

    invoke-virtual {v10, v12}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Lc/Q3;

    if-eqz v1, :cond_18

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Lc/Q3;

    iget-boolean v1, v1, Lc/F;->f:Z

    if-nez v1, :cond_17

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Lc/Q3;

    invoke-virtual {v1}, Lc/F;->k()Z

    move-result v1

    if-nez v1, :cond_17

    goto :goto_17

    :cond_17
    move v1, v4

    goto :goto_18

    :cond_18
    :goto_17
    const/4 v1, 0x1

    :goto_18
    iget-boolean v2, v9, Lc/P3;->U1:Z

    if-eqz v2, :cond_19

    iget-boolean v2, v13, Lc/g1;->J:Z

    if-nez v2, :cond_19

    iget-boolean v2, v9, Lc/P3;->L1:Z

    if-nez v2, :cond_19

    if-eqz v1, :cond_19

    iget-object v1, v9, Lc/P3;->e:Lc/u0;

    iget-object v1, v1, Lc/u0;->c:Ljava/lang/Object;

    check-cast v1, Lc/q0;

    sget-object v2, Lc/q0;->c:Lc/q0;

    if-ne v1, v2, :cond_19

    const/4 v13, 0x1

    goto :goto_19

    :cond_19
    move v13, v4

    :goto_19
    if-eqz v13, :cond_1c

    iget-object v1, v9, Lc/P3;->f:Lc/o0;

    iget-object v1, v1, Lc/o0;->c:Lc/m0;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    iget-object v2, v9, Lc/P3;->j:Landroid/graphics/RectF;

    :try_start_9
    iget v3, v1, Lc/m0;->a:F

    iget v4, v1, Lc/m0;->b:F

    iget v5, v1, Lc/m0;->c:F

    iget v1, v1, Lc/m0;->d:F

    invoke-virtual {v2, v3, v4, v5, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v9, Lc/P3;->i:Lc/S;

    iget-object v3, v9, Lc/P3;->c0:Lc/r4;

    iget v3, v3, Lc/r4;->d:I

    invoke-static {v3}, Lc/q9;->a(I)I

    move-result v3

    iget-object v4, v1, Lc/S;->b:Landroid/graphics/RectF;

    invoke-virtual {v4, v10}, Landroid/graphics/RectF;->equals(Ljava/lang/Object;)Z

    move-result v5

    iget-object v6, v1, Lc/S;->c:Landroid/graphics/RectF;

    if-eqz v5, :cond_1b

    invoke-virtual {v6, v2}, Landroid/graphics/RectF;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1b

    iget v5, v1, Lc/S;->d:I

    if-eq v5, v3, :cond_1a

    goto :goto_1b

    :cond_1a
    :goto_1a
    const/4 v1, 0x1

    goto :goto_1c

    :cond_1b
    :goto_1b
    invoke-virtual {v4, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v6, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iput v3, v1, Lc/S;->d:I

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    goto :goto_1a

    :goto_1c
    iput-boolean v1, v9, Lc/P3;->k:Z

    :cond_1c
    iget-object v1, v9, Lc/P3;->h:Lc/h0;

    iget-object v2, v9, Lc/P3;->e:Lc/u0;

    iget-object v2, v2, Lc/u0;->c:Ljava/lang/Object;

    move-object v3, v2

    check-cast v3, Lc/q0;

    iget-wide v4, v0, Lc/U0;->a:J

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    const/4 v0, 0x1

    xor-int/lit8 v12, v13, 0x1

    move-object v0, v1

    move-object/from16 v1, p2

    move-object v2, v10

    move-object v13, v7

    move v7, v12

    :try_start_a
    invoke-virtual/range {v0 .. v7}, Lc/h0;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;JIZ)V

    invoke-virtual {v8}, Lc/n1;->f0()Z

    move-result v0

    if-eqz v0, :cond_1d

    const-string v0, "clock_status_visible"

    iget-object v1, v8, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v2, 0x1

    invoke-interface {v1, v0, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-virtual {v9, v11, v10}, Lc/P3;->t(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    goto :goto_1d

    :catchall_4
    move-exception v0

    goto :goto_1f

    :cond_1d
    :goto_1d
    sget-object v0, Lc/q9;->z:Ljava/lang/ThreadLocal;

    if-nez v13, :cond_1e

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_1e

    :cond_1e
    invoke-virtual {v0, v13}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_1e
    return-void

    :catchall_5
    move-exception v0

    move-object v13, v15

    :goto_1f
    sget-object v1, Lc/q9;->z:Ljava/lang/ThreadLocal;

    if-nez v13, :cond_1f

    invoke-virtual {v1}, Ljava/lang/ThreadLocal;->remove()V

    goto :goto_20

    :cond_1f
    invoke-virtual {v1, v13}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :goto_20
    throw v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public final I(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FZ)V
    .locals 20

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    move-object/from16 v10, p3

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l0()Z

    move-result v2

    sget-object v3, Lc/s0;->d:Lc/s0;

    if-eqz v2, :cond_0

    invoke-virtual {v1}, Lc/n1;->s()I

    move-result v6

    invoke-virtual {v1, v3}, Lc/n1;->Y(Lc/s0;)I

    move-result v7

    iget-object v1, v0, Lc/P3;->l0:Lc/T4;

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p4

    move/from16 v8, p5

    invoke-virtual/range {v1 .. v8}, Lc/T4;->a(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FIIZ)V

    goto/16 :goto_3

    :cond_0
    invoke-virtual {v1}, Lc/n1;->s()I

    move-result v11

    invoke-virtual {v1, v3}, Lc/n1;->Y(Lc/s0;)I

    move-result v1

    iget-object v12, v0, Lc/P3;->N1:Lc/g5;

    const/4 v13, 0x1

    iput-boolean v13, v12, Lc/g5;->D:Z

    iget-object v2, v12, Lc/g5;->b:Landroid/graphics/RectF;

    invoke-virtual {v2, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object v2, v12, Lc/g5;->c:Landroid/graphics/RectF;

    invoke-virtual {v2, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    const/16 v14, 0x64

    invoke-static {v14, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    rsub-int/lit8 v1, v1, 0x64

    mul-int/lit16 v1, v1, 0xff

    int-to-float v1, v1

    const/high16 v15, 0x42c80000    # 100.0f

    div-float/2addr v1, v15

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v9, v10, v1}, Landroid/graphics/Canvas;->saveLayerAlpha(Landroid/graphics/RectF;I)I

    move-result v8

    iget-object v1, v12, Lc/g5;->I:Landroid/graphics/Path;

    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    sget-object v3, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    move/from16 v4, p4

    invoke-virtual {v1, v10, v4, v4, v3}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    invoke-virtual {v9, v1}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    iget-object v1, v12, Lc/g5;->u:[Lc/f5;

    aget-object v1, v1, v13

    iget-object v1, v1, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    iget-object v7, v12, Lc/g5;->j:[Lc/T4;

    if-eqz v1, :cond_1

    if-eqz p2, :cond_1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_1

    aget-object v1, v7, v13

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v12, 0x0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v16, v7

    move v7, v12

    move v12, v8

    move/from16 v8, p5

    invoke-virtual/range {v1 .. v8}, Lc/T4;->a(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FIIZ)V

    move/from16 v19, v12

    goto/16 :goto_2

    :cond_1
    move-object/from16 v16, v7

    move v7, v2

    :goto_0
    iget-object v1, v12, Lc/g5;->u:[Lc/f5;

    array-length v1, v1

    if-ge v7, v1, :cond_5

    add-int/lit8 v1, v7, -0x1

    int-to-float v1, v1

    iget v2, v12, Lc/g5;->w:F

    add-float/2addr v1, v2

    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float/2addr v2, v1

    iget-object v4, v12, Lc/g5;->d:Landroid/graphics/RectF;

    invoke-virtual {v4, v10}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    const/4 v1, 0x0

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->offset(FF)V

    iget v1, v4, Landroid/graphics/RectF;->right:F

    iget v2, v10, Landroid/graphics/RectF;->left:F

    cmpg-float v1, v1, v2

    if-lez v1, :cond_2

    iget v1, v4, Landroid/graphics/RectF;->left:F

    iget v2, v10, Landroid/graphics/RectF;->right:F

    cmpl-float v1, v1, v2

    if-ltz v1, :cond_3

    :cond_2
    move/from16 v18, v7

    move/from16 v19, v8

    goto :goto_1

    :cond_3
    iget-object v1, v12, Lc/g5;->u:[Lc/f5;

    aget-object v1, v1, v7

    iget-object v3, v1, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_4

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_4

    aget-object v1, v16, v7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v17, 0x0

    move-object/from16 v2, p1

    move/from16 v18, v7

    move/from16 v7, v17

    move/from16 v19, v8

    move/from16 v8, p5

    invoke-virtual/range {v1 .. v8}, Lc/T4;->a(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FIIZ)V

    goto :goto_1

    :cond_4
    move/from16 v18, v7

    move/from16 v19, v8

    iget v1, v4, Landroid/graphics/RectF;->left:F

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget v2, v4, Landroid/graphics/RectF;->top:F

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v3, v4, Landroid/graphics/RectF;->right:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    iget v4, v4, Landroid/graphics/RectF;->bottom:F

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    iget-object v5, v12, Lc/g5;->k:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v1, v2, v3, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v5, v9}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :goto_1
    add-int/lit8 v7, v18, 0x1

    move/from16 v8, v19

    goto :goto_0

    :cond_5
    move/from16 v19, v8

    :goto_2
    if-lez v11, :cond_6

    aget-object v1, v16, v13

    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->width()F

    move-result v2

    invoke-virtual/range {p3 .. p3}, Landroid/graphics/RectF;->height()F

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const v3, 0x3ee66666    # 0.45f

    mul-float/2addr v2, v3

    invoke-static {v14, v11}, Ljava/lang/Math;->min(II)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v2, v3

    div-float/2addr v2, v15

    invoke-virtual {v1, v9, v10, v2}, Lc/T4;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;F)V

    :cond_6
    move/from16 v1, v19

    invoke-virtual {v9, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :goto_3
    return-void
.end method

.method public final J(Ljava/lang/String;FFZ)Ljava/lang/String;
    .locals 6

    if-nez p1, :cond_0

    const-string p1, ""

    return-object p1

    :cond_0
    iget-object v0, p0, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setTextSize(F)V

    if-eqz p4, :cond_1

    sget-object p3, Lc/P3;->Y1:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_1
    sget-object p3, Lc/P3;->X1:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {v0, p3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p3

    cmpg-float p3, p3, p2

    if-gtz p3, :cond_2

    return-object p1

    :cond_2
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    const/4 p4, 0x1

    sub-int/2addr p3, p4

    invoke-static {p4, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    const-string v1, "\u2026"

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    move v3, p4

    :goto_1
    const/4 v4, 0x0

    if-ge v3, p3, :cond_4

    add-int v5, v3, p3

    add-int/2addr v5, p4

    ushr-int/2addr v5, p4

    invoke-virtual {v0, p1, v4, v5}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;II)F

    move-result v4

    add-float/2addr v4, v2

    cmpg-float v4, v4, p2

    if-gtz v4, :cond_3

    move v3, v5

    goto :goto_1

    :cond_3
    add-int/lit8 v5, v5, -0x1

    move p3, v5

    goto :goto_1

    :cond_4
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method public final K(Z)Z
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-object v2, v1, Lc/g1;->C:Lc/u0;

    const/4 v3, 0x0

    if-eqz v2, :cond_1

    iget-object v2, v1, Lc/g1;->F:Lc/o0;

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, v1, Lc/g1;->a:Lc/P3;

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v5, v1, Lc/g1;->C:Lc/u0;

    iget-object v6, v1, Lc/g1;->F:Lc/o0;

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v1, v7}, Lc/g1;->h(F)F

    move-result v8

    iget-object v9, v1, Lc/g1;->b:Lc/n1;

    invoke-static {v4, v9, v5, v6, v8}, Lc/G0;->f(Landroid/content/Context;Lc/n1;Lc/u0;Lc/o0;F)Lc/u0;

    move-result-object v4

    if-nez v4, :cond_2

    :cond_1
    :goto_0
    move v1, v3

    goto/16 :goto_3

    :cond_2
    if-eqz p1, :cond_5

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v5, v1, Lc/g1;->F:Lc/o0;

    invoke-virtual {v1, v7}, Lc/g1;->h(F)F

    move-result v6

    sget-object v7, Lc/s0;->l:Lc/s0;

    invoke-virtual {v4, v7}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v7

    if-eqz v7, :cond_5

    iget-boolean v8, v7, Lc/r0;->g:Z

    if-nez v8, :cond_5

    iget-boolean v8, v5, Lc/o0;->f:Z

    if-eqz v8, :cond_3

    goto :goto_2

    :cond_3
    iget-object v8, v7, Lc/r0;->a:Lc/s0;

    invoke-virtual {v8}, Lc/s0;->b()I

    move-result v8

    move v14, v8

    :goto_1
    iget v8, v7, Lc/r0;->f:I

    if-ge v14, v8, :cond_5

    iget v8, v7, Lc/r0;->e:I

    invoke-virtual {v7, v8, v14}, Lc/r0;->c(II)Lc/r0;

    move-result-object v15

    invoke-virtual {v5, v15}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Lc/m0;->d()F

    move-result v10

    iget-object v9, v1, Lc/g1;->b:Lc/n1;

    const/4 v13, 0x0

    const/high16 v12, 0x3f800000    # 1.0f

    move-object v8, v2

    move v11, v6

    invoke-static/range {v8 .. v13}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object v8

    new-instance v9, Landroid/graphics/PointF;

    iget v10, v8, Lc/D0;->b:F

    iget v8, v8, Lc/D0;->c:F

    invoke-direct {v9, v10, v8}, Landroid/graphics/PointF;-><init>(FF)V

    invoke-virtual/range {v16 .. v16}, Lc/m0;->d()F

    move-result v8

    const/high16 v10, 0x3f000000    # 0.5f

    add-float/2addr v8, v10

    iget v11, v9, Landroid/graphics/PointF;->x:F

    cmpl-float v8, v8, v11

    if-ltz v8, :cond_4

    invoke-virtual/range {v16 .. v16}, Lc/m0;->b()F

    move-result v8

    add-float/2addr v8, v10

    iget v9, v9, Landroid/graphics/PointF;->y:F

    cmpl-float v8, v8, v9

    if-ltz v8, :cond_4

    invoke-virtual {v4, v15}, Lc/u0;->a(Lc/r0;)Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-virtual {v4, v15}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v4

    goto :goto_2

    :cond_4
    add-int/lit8 v14, v14, 0x1

    goto :goto_1

    :cond_5
    :goto_2
    iget-object v2, v1, Lc/g1;->C:Lc/u0;

    if-eq v4, v2, :cond_6

    invoke-virtual {v1, v4, v3}, Lc/g1;->t(Lc/u0;Z)V

    :cond_6
    const/4 v1, 0x1

    :goto_3
    if-eqz v1, :cond_7

    iget-object v2, v0, Lc/P3;->n:Lc/G0;

    invoke-virtual {v2, v3}, Lc/G0;->j(Z)Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    goto :goto_4

    :cond_7
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const-string v5, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043c\u0435\u0441\u0442\u0430. \u0423\u043c\u0435\u043d\u044c\u0448\u0438\u0442\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u0438\u043b\u0438 \u043e\u0441\u0432\u043e\u0431\u043e\u0434\u0438\u0442\u0435 \u043c\u0435\u0441\u0442\u043e \u043d\u0430 \u044d\u043a\u0440\u0430\u043d\u0435."

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v2, v4, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    :goto_4
    return v1
.end method

.method public final L(Lc/s0;)Z
    .locals 1

    iget-object v0, p0, Lc/P3;->e:Lc/u0;

    invoke-virtual {v0, p1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-boolean p1, p1, Lc/r0;->g:Z

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final N()V
    .locals 4

    iget-boolean v0, p0, Lc/P3;->U1:Z

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lc/P3;->m1:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/P3;->m1:Z

    iget-object v0, p0, Lc/P3;->W0:Landroid/os/Handler;

    iget-object v1, p0, Lc/P3;->n1:Lc/F3;

    const-wide/16 v2, 0x20

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    :goto_0
    return-void
.end method

.method public final O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I
    .locals 3

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    iget v1, p0, Lc/P3;->A0:F

    const v2, 0x3f7fbe77    # 0.999f

    cmpl-float v1, v1, v2

    if-ltz v1, :cond_0

    return v0

    :cond_0
    invoke-virtual {p1, p2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    const/high16 v1, 0x437f0000    # 255.0f

    iget v2, p0, Lc/P3;->A0:F

    mul-float/2addr v2, v1

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {p1, p2, v1}, Landroid/graphics/Canvas;->saveLayerAlpha(Landroid/graphics/RectF;I)I

    const/high16 v1, 0x3f800000    # 1.0f

    iget v2, p0, Lc/P3;->A0:F

    sub-float/2addr v1, v2

    if-eqz p3, :cond_1

    const/high16 p2, 0x42dc0000    # 110.0f

    invoke-virtual {p0, p2}, Lc/P3;->s(F)F

    move-result p2

    neg-float p2, p2

    goto :goto_0

    :cond_1
    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result p2

    const/high16 p3, 0x433e0000    # 190.0f

    invoke-virtual {p0, p3}, Lc/P3;->s(F)F

    move-result p3

    invoke-static {p2, p3}, Ljava/lang/Math;->min(FF)F

    move-result p2

    :goto_0
    mul-float/2addr v1, p2

    const/4 p2, 0x0

    invoke-virtual {p1, p2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    return v0
.end method

.method public final P()Z
    .locals 3

    sget-object v0, Lc/s0;->d:Lc/s0;

    invoke-virtual {p0, v0}, Lc/P3;->L(Lc/s0;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "track_popup_enabled"

    iget-object v1, p0, Lc/P3;->C1:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v2, 0x0

    invoke-interface {v1, v0, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x1

    :cond_1
    return v2
.end method

.method public final Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;
    .locals 1

    if-eqz p6, :cond_0

    sget-object p6, Lc/P3;->Y1:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_0
    sget-object p6, Lc/P3;->X1:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {p1, p6}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {p1, p4}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {p1, p5}, Landroid/graphics/Paint;->setColor(I)V

    iget-object p4, p0, Lc/P3;->c0:Lc/r4;

    iget-boolean p4, p4, Lc/r4;->m:Z

    const/high16 p5, 0x3f800000    # 1.0f

    const/4 p6, 0x0

    if-eqz p4, :cond_1

    if-eqz p8, :cond_1

    const/high16 p4, 0x40200000    # 2.5f

    invoke-virtual {p0, p4}, Lc/P3;->s(F)F

    move-result p4

    invoke-virtual {p0, p5}, Lc/P3;->s(F)F

    move-result p8

    const/high16 v0, -0x50000000

    invoke-virtual {p1, p4, p6, p8, v0}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_1

    :cond_1
    invoke-virtual {p1}, Landroid/graphics/Paint;->clearShadowLayer()V

    :goto_1
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p4

    const/4 p8, 0x1

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    invoke-static {p8, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    const/4 p8, 0x0

    invoke-static {p2, p8, p4, p1, p3}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    sget-object p2, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    invoke-virtual {p1, p2}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1, p8}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1, p6, p5}, Landroid/text/StaticLayout$Builder;->setLineSpacing(FF)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1, p7}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    sget-object p2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p1, p2}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object p1

    return-object p1
.end method

.method public final R()Landroid/graphics/Bitmap;
    .locals 4

    iget-object v0, p0, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->p:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_0

    return-object v0

    :cond_0
    iget-wide v0, p0, Lc/P3;->t0:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    const/4 v3, 0x0

    if-lez v2, :cond_2

    invoke-virtual {p0, v0, v1}, Landroid/view/View;->postInvalidateDelayed(J)V

    iget-object v0, p0, Lc/P3;->p0:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v3, p0, Lc/P3;->p0:Landroid/graphics/Bitmap;

    :cond_1
    return-object v3

    :cond_2
    iput-object v3, p0, Lc/P3;->p0:Landroid/graphics/Bitmap;

    return-object v3
.end method

.method public final S(Ljava/util/List;)V
    .locals 6

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lc/P3;->i1:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    iget-object v4, p0, Lc/P3;->x1:Lc/M;

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/media/session/MediaController;

    invoke-virtual {v3}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    invoke-virtual {v3, v4}, Landroid/media/session/MediaController;->unregisterCallback(Landroid/media/session/MediaController$Callback;)V

    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    goto :goto_1

    :cond_2
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_3
    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_3

    iget-object v3, p0, Lc/P3;->W0:Landroid/os/Handler;

    invoke-virtual {v2, v4, v3}, Landroid/media/session/MediaController;->registerCallback(Landroid/media/session/MediaController$Callback;Landroid/os/Handler;)V

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v3

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_4
    iput-object p1, p0, Lc/P3;->h1:Ljava/util/List;

    return-void
.end method

.method public final T(I)V
    .locals 5

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const-string v2, "android.settings.panel.action.WIFI"

    goto :goto_0

    :cond_0
    if-ne p1, v1, :cond_1

    const-string v2, "android.settings.panel.action.BLUETOOTH"

    goto :goto_0

    :cond_1
    if-ne p1, v0, :cond_2

    const-string v2, "android.settings.panel.action.INTERNET_CONNECTIVITY"

    goto :goto_0

    :cond_2
    const-string v2, ""

    :goto_0
    if-nez p1, :cond_3

    const-string p1, "android.settings.WIFI_SETTINGS"

    goto :goto_1

    :cond_3
    if-ne p1, v1, :cond_4

    const-string p1, "android.settings.BLUETOOTH_SETTINGS"

    goto :goto_1

    :cond_4
    if-ne p1, v0, :cond_5

    const-string p1, "android.settings.NETWORK_OPERATOR_SETTINGS"

    goto :goto_1

    :cond_5
    const/4 v0, 0x3

    if-ne p1, v0, :cond_6

    const-string p1, "android.settings.AIRPLANE_MODE_SETTINGS"

    goto :goto_1

    :cond_6
    const-string p1, "android.settings.SOUND_SETTINGS"

    :goto_1
    const/high16 v0, 0x10000000

    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    new-instance v3, Landroid/content/Intent;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_7

    move-object v2, p1

    :cond_7
    invoke-direct {v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    :try_start_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_2
    return-void
.end method

.method public final U(II)V
    .locals 10

    const-string v0, "disable"

    const-string v1, "enable"

    const-string v2, "svc wifi "

    const-string v3, "com.syu.ipc.IRemoteModule"

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-ne p1, v4, :cond_2

    iget-object p1, p0, Lc/P3;->T0:Lc/z8;

    iget-object p2, p1, Lc/z8;->b:Landroid/os/IBinder;

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object p2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    invoke-virtual {p2, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/16 v1, 0x10

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->writeInt(I)V

    filled-new-array {v7}, [I

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->writeIntArray([I)V

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->writeFloatArray([F)V

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    iget-object p1, p1, Lc/z8;->b:Landroid/os/IBinder;

    invoke-interface {p1, v7, p2, v0, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez p1, :cond_1

    :catch_0
    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_0

    :cond_1
    :try_start_1
    invoke-virtual {v0}, Landroid/os/Parcel;->readException()V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_1

    :catchall_0
    move-exception p1

    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1

    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const-string v0, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0434\u0438\u0441\u043f\u043b\u0435\u044f \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e"

    invoke-static {p2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_1
    return-void

    :cond_2
    iget-object v4, p0, Lc/P3;->S0:Lc/y8;

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-ne p1, v8, :cond_8

    new-instance p1, Lc/F3;

    const/16 p2, 0xd

    invoke-direct {p1, p0, p2}, Lc/F3;-><init>(Lc/P3;I)V

    iget-boolean p2, v4, Lc/y8;->d:Z

    if-eqz p2, :cond_5

    iget-object p2, v4, Lc/y8;->m:Landroid/os/IBinder;

    if-nez p2, :cond_3

    goto :goto_2

    :cond_3
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object p2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_2
    invoke-virtual {p2, v3}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    invoke-virtual {p2, v6}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, -0x5

    filled-new-array {v1}, [I

    move-result-object v1

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->writeIntArray([I)V

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->writeFloatArray([F)V

    invoke-virtual {p2, v5}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    iget-object v1, v4, Lc/y8;->m:Landroid/os/IBinder;

    invoke-interface {v1, v7, p2, v0, v6}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-nez v1, :cond_4

    :catch_1
    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_2

    :cond_4
    :try_start_3
    invoke-virtual {v0}, Landroid/os/Parcel;->readException()V
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    iget-boolean p2, v4, Lc/y8;->o:Z

    xor-int/2addr p2, v7

    iput-boolean p2, v4, Lc/y8;->o:Z

    goto :goto_4

    :catchall_1
    move-exception p1

    invoke-virtual {p2}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1

    :goto_2
    const-string p2, "input keyevent 164"

    invoke-static {p2}, Lc/j8;->e(Ljava/lang/String;)V

    iget-boolean p2, v4, Lc/y8;->o:Z

    xor-int/2addr p2, v7

    iput-boolean p2, v4, Lc/y8;->o:Z

    goto :goto_4

    :cond_5
    iget-object p2, v4, Lc/y8;->b:Landroid/media/AudioManager;

    if-eqz p2, :cond_7

    invoke-virtual {v4}, Lc/y8;->c()Z

    move-result v0

    if-eqz v0, :cond_6

    const/16 v0, 0x64

    goto :goto_3

    :cond_6
    const/16 v0, -0x64

    :goto_3
    invoke-virtual {p2, v9, v0, v7}, Landroid/media/AudioManager;->adjustStreamVolume(III)V

    :cond_7
    :goto_4
    iget-object p2, v4, Lc/y8;->c:Landroid/os/Handler;

    const-wide/16 v0, 0x12c

    invoke-virtual {p2, p1, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_8
    const/4 v3, 0x2

    const/4 v5, 0x4

    if-ne p1, v5, :cond_d

    if-gez p2, :cond_9

    return-void

    :cond_9
    new-instance p1, Lc/F3;

    const/16 v0, 0xe

    invoke-direct {p1, p0, v0}, Lc/F3;-><init>(Lc/P3;I)V

    if-nez p2, :cond_a

    invoke-virtual {v4, v6, p1}, Lc/y8;->a(ZLc/F3;)V

    goto :goto_5

    :cond_a
    if-ne p2, v7, :cond_b

    invoke-virtual {p0, v5}, Lc/P3;->T(I)V

    goto :goto_5

    :cond_b
    if-ne p2, v3, :cond_c

    invoke-virtual {v4, v7, p1}, Lc/y8;->a(ZLc/F3;)V

    :cond_c
    :goto_5
    return-void

    :cond_d
    if-nez p1, :cond_10

    :try_start_4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const-string v3, "wifi"

    invoke-virtual {p2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/net/wifi/WifiManager;

    if-eqz p2, :cond_14

    invoke-virtual {p2}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v3
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_3

    xor-int/lit8 v4, v3, 0x1

    :try_start_5
    invoke-virtual {p2, v4}, Landroid/net/wifi/WifiManager;->setWifiEnabled(Z)Z

    move-result p2

    if-nez p2, :cond_14

    if-nez v3, :cond_e

    move-object p2, v1

    goto :goto_6

    :cond_e
    move-object p2, v0

    :goto_6
    invoke-virtual {v2, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lc/j8;->e(Ljava/lang/String;)V
    :try_end_5
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_3

    goto :goto_7

    :catch_2
    if-nez v3, :cond_f

    move-object v0, v1

    :cond_f
    :try_start_6
    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lc/j8;->e(Ljava/lang/String;)V

    goto :goto_7

    :cond_10
    if-ne p1, v7, :cond_11

    invoke-virtual {p0}, Lc/P3;->k0()V

    goto :goto_7

    :cond_11
    if-ne p1, v3, :cond_12

    invoke-virtual {p0}, Lc/P3;->l0()V

    goto :goto_7

    :cond_12
    if-ne p1, v9, :cond_14

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p2

    const-string v0, "airplane_mode_on"

    invoke-static {p2, v0, v6}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-eqz v1, :cond_13

    move v6, v7

    :cond_13
    xor-int/lit8 v1, v6, 0x1

    invoke-static {p2, v0, v1}, Landroid/provider/Settings$Global;->putInt(Landroid/content/ContentResolver;Ljava/lang/String;I)Z

    new-instance p2, Landroid/content/Intent;

    const-string v0, "android.intent.action.AIRPLANE_MODE"

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v0, "state"

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_6
    .catch Ljava/lang/RuntimeException; {:try_start_6 .. :try_end_6} :catch_3

    goto :goto_7

    :catch_3
    invoke-virtual {p0, p1}, Lc/P3;->T(I)V

    :cond_14
    :goto_7
    sget-object p1, Lc/A8;->s:Ljava/lang/Object;

    monitor-enter p1

    :try_start_7
    sget-object p2, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    const-wide/16 v0, 0x0

    sput-wide v0, Lc/A8;->w:J

    monitor-exit p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :catchall_2
    move-exception p2

    :try_start_8
    monitor-exit p1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    throw p2
.end method

.method public final W()V
    .locals 47

    move-object/from16 v7, p0

    const/4 v9, 0x3

    const/16 v12, 0xd

    invoke-virtual/range {p0 .. p0}, Lc/P3;->n0()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lru/drivedeck/launcher/NotificationBridgeService;->a(Landroid/content/Context;)Z

    move-result v39

    iget-object v1, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->e0()Z

    move-result v15

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-object v1, v7, Lc/P3;->d1:Landroid/media/MediaMetadata;

    iget-object v2, v7, Lc/P3;->o1:Lc/w8;

    const/4 v14, 0x0

    if-eqz v2, :cond_2

    iget-object v2, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v2, :cond_1

    const-string v3, "com.syu.music"

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v2, v7, Lc/P3;->o1:Lc/w8;

    iget-object v2, v2, Lc/w8;->a:Ljava/lang/String;

    if-nez v1, :cond_0

    move-object v3, v14

    goto :goto_0

    :cond_0
    const-string v3, "android.media.metadata.TITLE"

    invoke-virtual {v1, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_0
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    :cond_1
    move-object v1, v14

    :cond_2
    if-nez v1, :cond_3

    move-object v2, v14

    goto :goto_1

    :cond_3
    const-string v2, "android.media.metadata.ALBUM_ART"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    :goto_1
    if-nez v2, :cond_4

    if-eqz v1, :cond_4

    const-string v2, "android.media.metadata.ART"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    :cond_4
    if-nez v2, :cond_5

    if-eqz v1, :cond_5

    iget-object v3, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l0()Z

    move-result v3

    if-eqz v3, :cond_5

    const-string v2, "android.media.metadata.DISPLAY_ICON"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    :cond_5
    if-nez v1, :cond_6

    const-string v3, "\u041c\u0443\u0437\u044b\u043a\u0430 \u043d\u0435 \u0438\u0433\u0440\u0430\u0435\u0442"

    goto :goto_2

    :cond_6
    const-string v3, "android.media.metadata.TITLE"

    invoke-virtual {v1, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_2
    if-nez v1, :cond_7

    const-string v4, "\u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u043f\u043b\u0435\u0435\u0440"

    goto :goto_3

    :cond_7
    const-string v4, "android.media.metadata.ARTIST"

    invoke-virtual {v1, v4}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_3
    iget-object v8, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v8, :cond_9

    const-string v8, "com.syu.music"

    iget-object v0, v7, Lc/P3;->a0:Lc/z;

    invoke-virtual {v0, v8}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    if-nez v0, :cond_8

    goto :goto_6

    :cond_8
    iget-object v8, v0, Lc/a;->b:Ljava/lang/String;

    goto :goto_6

    :cond_9
    if-nez v15, :cond_c

    iget-object v0, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v0, :cond_a

    goto :goto_5

    :cond_a
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iget-object v8, v7, Lc/P3;->a0:Lc/z;

    invoke-virtual {v8, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v8

    if-nez v8, :cond_b

    :goto_4
    move-object v8, v0

    goto :goto_6

    :cond_b
    iget-object v0, v8, Lc/a;->b:Ljava/lang/String;

    goto :goto_4

    :cond_c
    :goto_5
    const-string v8, ""

    :goto_6
    iget-object v0, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_f

    iget-object v3, v0, Lc/w8;->a:Ljava/lang/String;

    iget-object v4, v0, Lc/w8;->b:Ljava/lang/String;

    if-nez v2, :cond_f

    iget-object v0, v0, Lc/w8;->c:Ljava/lang/String;

    iget-object v2, v7, Lc/P3;->p1:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    goto :goto_7

    :cond_d
    iput-object v0, v7, Lc/P3;->p1:Ljava/lang/String;

    iput-object v14, v7, Lc/P3;->q1:Landroid/graphics/Bitmap;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_e

    goto :goto_7

    :cond_e
    sget-object v2, Landroid/os/AsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;

    new-instance v13, Lc/H;

    invoke-direct {v13, v7, v0, v12}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v2, v13}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_7
    iget-object v2, v7, Lc/P3;->q1:Landroid/graphics/Bitmap;

    :cond_f
    if-eqz v15, :cond_12

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->l:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_10

    const-string v0, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043d\u0435 \u043f\u0435\u0440\u0435\u0434\u0430\u0451\u0442\u0441\u044f"

    :goto_8
    move-object v3, v0

    goto :goto_9

    :cond_10
    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->l:Ljava/lang/String;

    goto :goto_8

    :goto_9
    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v4, v0, Lc/P;->m:Ljava/lang/String;

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->l:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_11

    if-eqz v1, :cond_11

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->l:Ljava/lang/String;

    const-string v13, "android.media.metadata.TITLE"

    invoke-virtual {v1, v13}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    :cond_11
    move-object v2, v14

    :cond_12
    if-nez v1, :cond_16

    iget-object v0, v7, Lc/P3;->o1:Lc/w8;

    if-nez v0, :cond_16

    if-nez v15, :cond_16

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v13, "source"

    invoke-static {v0, v13}, Lc/G8;->h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v13, "com.syu.bt"

    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_14

    const-string v13, "com.android.bluetooth"

    invoke-virtual {v0, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_13

    goto :goto_a

    :cond_13
    const/4 v13, 0x0

    goto :goto_b

    :cond_14
    :goto_a
    const/4 v13, 0x1

    :goto_b
    if-ne v15, v13, :cond_16

    iget-object v13, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_15

    iget-object v13, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_16

    :cond_15
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v13, "title"

    invoke-static {v0, v13}, Lc/G8;->h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_16

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "title"

    invoke-static {v0, v3}, Lc/G8;->h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v4, "artist"

    invoke-static {v0, v4}, Lc/G8;->h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :cond_16
    const-wide/16 v18, -0x1

    if-nez v1, :cond_17

    move-wide/from16 v20, v18

    goto :goto_c

    :cond_17
    const-string v0, "android.media.metadata.DURATION"

    invoke-virtual {v1, v0}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v20

    :goto_c
    iget-object v0, v7, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    if-nez v0, :cond_18

    move-wide/from16 v22, v18

    goto :goto_d

    :cond_18
    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v22

    :goto_d
    iget-object v0, v7, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v0

    if-ne v0, v9, :cond_19

    const/4 v0, 0x1

    goto :goto_e

    :cond_19
    const/4 v0, 0x0

    :goto_e
    if-eqz v0, :cond_1a

    if-nez v1, :cond_1a

    iget-object v13, v7, Lc/P3;->o1:Lc/w8;

    if-nez v13, :cond_1a

    if-nez v15, :cond_1a

    const-string v3, "\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435"

    move-object v4, v8

    :cond_1a
    const-wide/16 v12, 0x0

    if-eqz v0, :cond_1b

    cmp-long v25, v22, v12

    if-ltz v25, :cond_1b

    iget-object v9, v7, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    invoke-virtual {v9}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v26

    cmp-long v9, v26, v12

    if-lez v9, :cond_1b

    iget-object v9, v7, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    invoke-virtual {v9}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v26

    sub-long v10, v5, v26

    long-to-float v10, v10

    iget-object v11, v7, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    invoke-virtual {v11}, Landroid/media/session/PlaybackState;->getPlaybackSpeed()F

    move-result v11

    mul-float/2addr v11, v10

    float-to-long v10, v11

    add-long v22, v22, v10

    :cond_1b
    if-eqz v15, :cond_1e

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->a:Lc/K;

    iget-wide v10, v0, Lc/K;->a:J

    cmp-long v26, v10, v12

    if-lez v26, :cond_1c

    move-wide/from16 v20, v10

    :cond_1c
    invoke-virtual {v0, v5, v6}, Lc/K;->a(J)J

    move-result-wide v10

    cmp-long v0, v10, v12

    if-ltz v0, :cond_1d

    move-wide/from16 v22, v10

    :cond_1d
    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-boolean v0, v0, Lc/P;->n:Z

    :cond_1e
    iget-object v10, v7, Lc/P3;->o1:Lc/w8;

    const-wide/16 v26, 0x7530

    if-eqz v10, :cond_23

    move v11, v15

    iget-wide v14, v10, Lc/w8;->d:J

    move-object/from16 v29, v1

    iget-wide v0, v10, Lc/w8;->e:J

    cmp-long v20, v0, v12

    if-ltz v20, :cond_1f

    iget-wide v12, v10, Lc/w8;->f:J

    iget-boolean v9, v10, Lc/w8;->h:Z

    if-eqz v9, :cond_20

    sub-long v20, v5, v12

    cmp-long v20, v20, v26

    if-ltz v20, :cond_20

    :cond_1f
    move-object v9, v2

    move-object/from16 v33, v3

    goto :goto_10

    :cond_20
    if-eqz v9, :cond_21

    sub-long v12, v5, v12

    move-object v9, v2

    move-object/from16 v33, v3

    const-wide/16 v2, 0x0

    invoke-static {v2, v3, v12, v13}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v30

    goto :goto_f

    :cond_21
    move-object v9, v2

    move-object/from16 v33, v3

    const-wide/16 v2, 0x0

    move-wide/from16 v30, v2

    :goto_f
    add-long v0, v0, v30

    iget-wide v12, v10, Lc/w8;->d:J

    cmp-long v10, v12, v2

    if-lez v10, :cond_22

    invoke-static {v12, v13, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    :cond_22
    move-wide/from16 v22, v0

    goto :goto_11

    :goto_10
    move-wide/from16 v22, v18

    :goto_11
    iget-object v0, v7, Lc/P3;->o1:Lc/w8;

    invoke-virtual {v0, v5, v6}, Lc/w8;->b(J)Z

    move-result v0

    move-wide/from16 v20, v14

    goto :goto_12

    :cond_23
    move-object/from16 v29, v1

    move-object v9, v2

    move-object/from16 v33, v3

    move v11, v15

    :goto_12
    iget-boolean v1, v7, Lc/P3;->k1:Z

    if-nez v1, :cond_24

    if-nez v11, :cond_24

    iget-object v1, v7, Lc/P3;->o1:Lc/w8;

    if-nez v1, :cond_24

    const-string v3, "\u041c\u0443\u0437\u044b\u043a\u0430"

    const-string v4, "\u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u0430 \u043a \u043c\u0435\u0434\u0438\u0430\u0441\u0435\u0441\u0441\u0438\u044f\u043c"

    move-wide/from16 v20, v18

    move-wide/from16 v22, v20

    const/4 v0, 0x0

    const/4 v2, 0x0

    goto :goto_13

    :cond_24
    move-object v2, v9

    move-object/from16 v3, v33

    :goto_13
    iget-object v1, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l0()Z

    move-result v1

    if-eqz v1, :cond_31

    iget-object v1, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->D()Ljava/lang/String;

    move-result-object v1

    iget-object v8, v7, Lc/P3;->a0:Lc/z;

    invoke-virtual {v8, v1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v8

    if-nez v8, :cond_25

    move-object v8, v1

    goto :goto_14

    :cond_25
    iget-object v8, v8, Lc/a;->b:Ljava/lang/String;

    :goto_14
    iget-object v9, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v9, :cond_26

    invoke-virtual {v9}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_26

    move-object/from16 v9, v29

    goto :goto_15

    :cond_26
    const/4 v2, 0x0

    const/4 v9, 0x0

    :goto_15
    if-nez v9, :cond_27

    const-string v3, "\u0420\u0430\u0434\u0438\u043e"

    const-string v4, "\u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u0440\u0430\u0434\u0438\u043e"

    const/4 v0, 0x0

    :cond_27
    const-string v10, "com.syu.radio"

    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_30

    iget-object v1, v7, Lc/P3;->u1:Lc/g8;

    iget-object v1, v1, Lc/g8;->e:Landroid/os/IBinder;

    if-eqz v1, :cond_30

    if-nez v9, :cond_28

    const/4 v1, 0x0

    goto :goto_16

    :cond_28
    const-string v1, "android.media.metadata.TITLE"

    invoke-virtual {v9, v1}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_16
    if-eqz v1, :cond_29

    iget-object v3, v7, Lc/P3;->u1:Lc/g8;

    iget-object v3, v3, Lc/g8;->g:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_29

    iget-object v3, v7, Lc/P3;->u1:Lc/g8;

    iget-object v3, v3, Lc/g8;->g:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2a

    :cond_29
    const/4 v2, 0x0

    :cond_2a
    if-nez v2, :cond_2c

    iget-object v1, v7, Lc/P3;->u1:Lc/g8;

    iget v3, v1, Lc/g8;->f:I

    iget-object v4, v1, Lc/g8;->g:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "|"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    iget-object v1, v7, Lc/P3;->r1:Ljava/lang/String;

    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2b

    move-wide/from16 v40, v5

    goto :goto_17

    :cond_2b
    iput-object v10, v7, Lc/P3;->r1:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, v7, Lc/P3;->s1:Landroid/graphics/Bitmap;

    sget-object v12, Landroid/os/AsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;

    new-instance v13, Lc/N;

    const/4 v14, 0x2

    move-object v1, v13

    move-object/from16 v2, p0

    move-wide/from16 v40, v5

    move-object v5, v10

    move v6, v14

    invoke-direct/range {v1 .. v6}, Lc/N;-><init>(Landroid/view/KeyEvent$Callback;ILjava/io/Serializable;Ljava/io/Serializable;I)V

    invoke-interface {v12, v13}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_17
    iget-object v1, v7, Lc/P3;->s1:Landroid/graphics/Bitmap;

    move-object v2, v1

    goto :goto_18

    :cond_2c
    move-wide/from16 v40, v5

    :goto_18
    iget-object v1, v7, Lc/P3;->u1:Lc/g8;

    iget-object v1, v1, Lc/g8;->g:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2d

    iget-object v1, v7, Lc/P3;->u1:Lc/g8;

    invoke-virtual {v1}, Lc/g8;->a()Ljava/lang/String;

    move-result-object v1

    goto :goto_19

    :cond_2d
    iget-object v1, v7, Lc/P3;->u1:Lc/g8;

    iget-object v1, v1, Lc/g8;->g:Ljava/lang/String;

    :goto_19
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_2e

    const-string v1, "\u0420\u0430\u0434\u0438\u043e"

    :cond_2e
    move-object v3, v1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v7, Lc/P3;->u1:Lc/g8;

    invoke-virtual {v4}, Lc/g8;->a()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v7, Lc/P3;->u1:Lc/g8;

    iget-object v4, v4, Lc/g8;->h:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2f

    const-string v4, ""

    goto :goto_1a

    :cond_2f
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, " \u00b7 "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, v7, Lc/P3;->u1:Lc/g8;

    iget-object v5, v5, Lc/g8;->h:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_1a
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_1b
    move-object v1, v9

    move-wide/from16 v5, v18

    move-wide v12, v5

    goto :goto_1c

    :cond_30
    move-wide/from16 v40, v5

    goto :goto_1b

    :cond_31
    move-wide/from16 v40, v5

    move-wide/from16 v12, v20

    move-wide/from16 v5, v22

    move-object/from16 v1, v29

    :goto_1c
    const-string v10, ""

    const-string v14, ""

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v9

    instance-of v9, v9, Lc/Q3;

    if-eqz v9, :cond_32

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v9

    check-cast v9, Lc/Q3;

    goto :goto_1d

    :cond_32
    const/4 v9, 0x0

    :goto_1d
    if-nez v9, :cond_33

    iget-object v9, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v9}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v9

    goto :goto_1e

    :cond_33
    iget-object v9, v9, Lc/Q3;->G:Ljava/lang/String;

    :goto_1e
    sget-object v15, Lc/s0;->i:Lc/s0;

    invoke-virtual {v7, v15}, Lc/P3;->L(Lc/s0;)Z

    move-result v15

    move-object/from16 v18, v10

    iget-object v10, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v10}, Lc/n1;->F()Ljava/lang/String;

    move-result-object v10

    move/from16 v19, v11

    sget-object v11, Lc/s0;->m:Lc/s0;

    invoke-virtual {v7, v11}, Lc/P3;->L(Lc/s0;)Z

    move-result v11

    move-object/from16 v20, v14

    const-string v14, "ru.dublgis.dgismobile"

    if-eqz v15, :cond_34

    invoke-virtual {v14, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_34

    const/4 v10, 0x1

    goto :goto_20

    :cond_34
    if-eqz v15, :cond_35

    const-string v15, "ru.yandex.yandexnavi"

    invoke-virtual {v15, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_35

    const/4 v10, 0x0

    goto :goto_20

    :cond_35
    if-eqz v11, :cond_36

    invoke-virtual {v14, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_36

    const/4 v9, 0x1

    goto :goto_1f

    :cond_36
    const/4 v9, 0x0

    :goto_1f
    move v10, v9

    :goto_20
    iget-boolean v9, v7, Lc/P3;->U1:Z

    if-eqz v9, :cond_39

    if-eqz v10, :cond_39

    iget-object v9, v7, Lc/P3;->C1:Lc/n1;

    const-string v11, "speed_navigation"

    iget-object v9, v9, Lc/n1;->b:Ljava/lang/Object;

    check-cast v9, Landroid/content/SharedPreferences;

    const/4 v14, 0x0

    invoke-interface {v9, v11, v14}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    if-eqz v9, :cond_39

    iget-object v11, v7, Lc/P3;->v1:Lc/o1;

    iget-boolean v9, v11, Lc/o1;->f:Z

    if-nez v9, :cond_38

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v14

    move/from16 v33, v0

    move-object/from16 v42, v1

    iget-wide v0, v11, Lc/o1;->i:J

    sub-long/2addr v14, v0

    cmp-long v9, v14, v26

    if-gez v9, :cond_37

    const-wide/16 v14, 0x0

    cmp-long v0, v0, v14

    if-lez v0, :cond_37

    goto :goto_21

    :cond_37
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, v11, Lc/o1;->i:J

    iget-wide v0, v11, Lc/o1;->h:J

    const-wide/16 v14, 0x1

    add-long/2addr v0, v14

    iput-wide v0, v11, Lc/o1;->h:J

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "DriveDeck-2GIS"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, v11, Lc/o1;->d:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    monitor-enter v11

    :try_start_0
    new-instance v0, Landroid/os/Handler;

    iget-object v1, v11, Lc/o1;->d:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, v11, Lc/o1;->e:Landroid/os/Handler;

    monitor-exit v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-object v0, v11, Lc/o1;->a:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    const-string v9, "ru.dublgis.api.ACTION_BIND_DASHBOARD_INFORMATION_SERVICE"

    invoke-direct {v1, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v9, Landroid/content/ComponentName;

    const-string v14, "ru.dublgis.dgismobile"

    const-string v15, "ru.dublgis.api.DashboardInformationService"

    invoke-direct {v9, v14, v15}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v9}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v11, v9}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, v11, Lc/o1;->f:Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    iget-boolean v0, v11, Lc/o1;->f:Z

    if-nez v0, :cond_3a

    invoke-virtual {v11}, Lc/o1;->c()V

    goto :goto_21

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v11
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :cond_38
    move/from16 v33, v0

    move-object/from16 v42, v1

    goto :goto_21

    :cond_39
    move/from16 v33, v0

    move-object/from16 v42, v1

    iget-object v0, v7, Lc/P3;->v1:Lc/o1;

    invoke-virtual {v0}, Lc/o1;->c()V

    :cond_3a
    :goto_21
    if-eqz v10, :cond_3b

    iget-object v0, v7, Lc/P3;->v1:Lc/o1;

    iget-object v1, v0, Lc/o1;->j:Lc/n1;

    goto :goto_22

    :cond_3b
    const/4 v1, 0x0

    :goto_22
    if-eqz v10, :cond_3e

    if-eqz v1, :cond_3d

    iget-object v0, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3c

    goto :goto_24

    :cond_3c
    new-instance v0, Lc/k5;

    iget-object v11, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v11, Ljava/lang/String;

    iget-object v9, v1, Lc/n1;->c:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    invoke-direct {v0, v11, v9}, Lc/k5;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :goto_23
    const/4 v11, 0x0

    goto/16 :goto_29

    :cond_3d
    :goto_24
    const/4 v0, 0x0

    goto :goto_23

    :cond_3e
    if-eqz v39, :cond_3f

    iget-object v0, v7, Lc/P3;->g0:Ljava/util/List;

    goto :goto_25

    :cond_3f
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    :goto_25
    sget-object v9, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v9

    :try_start_3
    sget-object v11, Lc/k5;->k:Lc/k5;

    if-nez v11, :cond_40

    monitor-exit v9

    const/4 v11, 0x0

    const/16 v28, 0x0

    goto :goto_27

    :catchall_1
    move-exception v0

    goto/16 :goto_52

    :cond_40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v21

    iget-wide v14, v11, Lc/k5;->d:J

    sub-long v21, v21, v14

    const-wide/16 v14, 0x0

    cmp-long v23, v21, v14

    if-ltz v23, :cond_41

    const-wide/16 v14, 0xbb8

    cmp-long v21, v21, v14

    if-gtz v21, :cond_41

    monitor-exit v9

    move-object/from16 v28, v11

    const/4 v11, 0x0

    goto :goto_27

    :cond_41
    sget-object v14, Lc/k5;->k:Lc/k5;

    if-ne v14, v11, :cond_42

    const/4 v11, 0x0

    sput-object v11, Lc/k5;->k:Lc/k5;

    goto :goto_26

    :cond_42
    const/4 v11, 0x0

    :goto_26
    monitor-exit v9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    move-object/from16 v28, v11

    :goto_27
    if-eqz v28, :cond_43

    goto :goto_28

    :cond_43
    if-nez v0, :cond_45

    :cond_44
    move-object/from16 v28, v11

    goto :goto_28

    :cond_45
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_1
    :cond_46
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_44

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/q5;

    if-eqz v9, :cond_46

    const-string v14, "ru.yandex.yandexnavi"

    iget-object v15, v9, Lc/q5;->a:Ljava/lang/String;

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_46

    :try_start_4
    invoke-virtual {v9}, Lc/q5;->a()Z

    move-result v14

    if-eqz v14, :cond_46

    new-instance v14, Lc/k5;

    iget-object v15, v9, Lc/q5;->b:Ljava/lang/String;

    iget-object v9, v9, Lc/q5;->c:Ljava/lang/String;

    if-nez v9, :cond_47

    const-string v9, ""

    :cond_47
    invoke-direct {v14, v15, v9}, Lc/k5;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_1

    move-object/from16 v28, v14

    :goto_28
    move-object/from16 v0, v28

    :goto_29
    if-eqz v0, :cond_48

    iget-boolean v9, v0, Lc/k5;->c:Z

    if-eqz v9, :cond_48

    const/16 v38, 0x1

    goto :goto_2a

    :cond_48
    const/16 v38, 0x0

    :goto_2a
    if-eqz v0, :cond_49

    iget-object v9, v0, Lc/k5;->a:Ljava/lang/String;

    iget-object v0, v0, Lc/k5;->b:Ljava/lang/String;

    move-object/from16 v32, v9

    goto :goto_2b

    :cond_49
    move-object/from16 v32, v18

    move-object/from16 v0, v20

    :goto_2b
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    new-instance v14, Lc/F3;

    const/16 v15, 0x8

    invoke-direct {v14, v7, v15}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-static {v9, v14}, Lc/A8;->d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;

    move-result-object v9

    iput-object v9, v7, Lc/P3;->C:Lc/A8;

    sget-object v9, Lc/y9;->e:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v14

    const-string v11, "yandex_weather"

    const/4 v15, 0x0

    invoke-virtual {v14, v11, v15}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v11

    const-string v14, "updated_at"

    move-wide/from16 v34, v12

    const-wide/16 v12, 0x0

    invoke-interface {v11, v14, v12, v13}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v14

    move-object/from16 v36, v0

    const-string v0, "request_at"

    invoke-interface {v11, v0, v12, v13}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    sget-object v0, Lc/y9;->i:Lc/R0;

    iget-object v12, v7, Lc/P3;->C:Lc/A8;

    iget-boolean v12, v12, Lc/A8;->a:Z

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    const-wide/16 v20, 0x0

    cmp-long v18, v14, v20

    if-lez v18, :cond_4b

    cmp-long v18, v14, v12

    if-gtz v18, :cond_4a

    sub-long/2addr v12, v14

    const-wide/32 v14, 0x5265c00

    cmp-long v12, v12, v14

    if-gtz v12, :cond_4b

    :cond_4a
    if-eqz v9, :cond_4b

    const-string v12, ".*[0-9].*"

    invoke-virtual {v9, v12}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_4b

    if-eqz v0, :cond_4b

    iget-object v12, v0, Lc/R0;->d:Ljava/lang/Integer;

    if-eqz v12, :cond_4b

    goto :goto_2c

    :cond_4b
    const-string v9, "\u041d\u0435\u0442 \u0434\u0430\u043d\u043d\u044b\u0445"

    :goto_2c
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-static {v12}, Lc/y9;->c(Landroid/content/Context;)Ljava/lang/Boolean;

    move-result-object v12

    sget-object v13, Lc/y9;->f:Ljava/lang/String;

    if-eqz v12, :cond_4d

    invoke-virtual {v12}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v12

    if-nez v12, :cond_4c

    const/4 v12, 0x1

    goto :goto_2d

    :cond_4c
    const/4 v12, 0x0

    goto :goto_2d

    :cond_4d
    sget-boolean v12, Lc/y9;->g:Z

    :goto_2d
    const v14, 0x7f0300bc

    if-nez v13, :cond_4e

    :goto_2e
    move v12, v14

    goto/16 :goto_31

    :cond_4e
    invoke-virtual {v13}, Ljava/lang/String;->hashCode()I

    move-result v15

    sparse-switch v15, :sswitch_data_0

    :goto_2f
    const/4 v13, -0x1

    goto/16 :goto_30

    :sswitch_0
    const-string v15, "showers"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_4f

    goto :goto_2f

    :cond_4f
    const/16 v13, 0x14

    goto/16 :goto_30

    :sswitch_1
    const-string v15, "moderate-rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_50

    goto :goto_2f

    :cond_50
    const/16 v13, 0x13

    goto/16 :goto_30

    :sswitch_2
    const-string v15, "thunderstorm-with-rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_51

    goto :goto_2f

    :cond_51
    const/16 v13, 0x12

    goto/16 :goto_30

    :sswitch_3
    const-string v15, "thunderstorm-with-hail"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_52

    goto :goto_2f

    :cond_52
    const/16 v13, 0x11

    goto/16 :goto_30

    :sswitch_4
    const-string v15, "drizzle"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_53

    goto :goto_2f

    :cond_53
    const/16 v13, 0x10

    goto/16 :goto_30

    :sswitch_5
    const-string v15, "heavy-rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_54

    goto :goto_2f

    :cond_54
    const/16 v13, 0xf

    goto/16 :goto_30

    :sswitch_6
    const-string v15, "overcast"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_55

    goto :goto_2f

    :cond_55
    const/16 v13, 0xe

    goto/16 :goto_30

    :sswitch_7
    const-string v15, "clear"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_56

    goto :goto_2f

    :cond_56
    const/16 v13, 0xd

    goto/16 :goto_30

    :sswitch_8
    const-string v15, "snow-showers"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_57

    goto :goto_2f

    :cond_57
    const/16 v13, 0xc

    goto/16 :goto_30

    :sswitch_9
    const-string v15, "snow"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_58

    goto/16 :goto_2f

    :cond_58
    const/16 v13, 0xb

    goto/16 :goto_30

    :sswitch_a
    const-string v15, "rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_59

    goto/16 :goto_2f

    :cond_59
    const/16 v13, 0xa

    goto/16 :goto_30

    :sswitch_b
    const-string v15, "mist"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5a

    goto/16 :goto_2f

    :cond_5a
    const/16 v13, 0x9

    goto/16 :goto_30

    :sswitch_c
    const-string v15, "hail"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5b

    goto/16 :goto_2f

    :cond_5b
    const/16 v13, 0x8

    goto/16 :goto_30

    :sswitch_d
    const-string v15, "fog"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5c

    goto/16 :goto_2f

    :cond_5c
    const/4 v13, 0x7

    goto :goto_30

    :sswitch_e
    const-string v15, "wet-snow"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5d

    goto/16 :goto_2f

    :cond_5d
    const/4 v13, 0x6

    goto :goto_30

    :sswitch_f
    const-string v15, "light-snow"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5e

    goto/16 :goto_2f

    :cond_5e
    const/4 v13, 0x5

    goto :goto_30

    :sswitch_10
    const-string v15, "light-rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_5f

    goto/16 :goto_2f

    :cond_5f
    const/4 v13, 0x4

    goto :goto_30

    :sswitch_11
    const-string v15, "partly-cloudy"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_60

    goto/16 :goto_2f

    :cond_60
    const/4 v13, 0x3

    goto :goto_30

    :sswitch_12
    const-string v15, "continuous-heavy-rain"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_61

    goto/16 :goto_2f

    :cond_61
    const/4 v13, 0x2

    goto :goto_30

    :sswitch_13
    const-string v15, "cloudy"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_62

    goto/16 :goto_2f

    :cond_62
    const/4 v13, 0x1

    goto :goto_30

    :sswitch_14
    const-string v15, "thunderstorm"

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_63

    goto/16 :goto_2f

    :cond_63
    const/4 v13, 0x0

    :goto_30
    packed-switch v13, :pswitch_data_0

    goto/16 :goto_2e

    :pswitch_0
    const v12, 0x7f0300b5

    goto/16 :goto_31

    :pswitch_1
    const v12, 0x7f0300af

    goto/16 :goto_31

    :pswitch_2
    const v12, 0x7f0300bb

    goto :goto_31

    :pswitch_3
    const v12, 0x7f0300ba

    goto :goto_31

    :pswitch_4
    const v12, 0x7f0300a8

    goto :goto_31

    :pswitch_5
    const v12, 0x7f0300b0

    goto :goto_31

    :pswitch_6
    if-eqz v12, :cond_64

    const v12, 0x7f0300a5

    goto :goto_31

    :cond_64
    const v12, 0x7f0300a4

    goto :goto_31

    :pswitch_7
    const v12, 0x7f0300b7

    goto :goto_31

    :pswitch_8
    const v12, 0x7f0300b6

    goto :goto_31

    :pswitch_9
    const v12, 0x7f0300b3

    goto :goto_31

    :pswitch_a
    const v12, 0x7f0300aa

    goto :goto_31

    :pswitch_b
    const v12, 0x7f0300a9

    goto :goto_31

    :pswitch_c
    const v12, 0x7f0300bd

    goto :goto_31

    :pswitch_d
    const v12, 0x7f0300ae

    goto :goto_31

    :pswitch_e
    const v12, 0x7f0300ad

    goto :goto_31

    :pswitch_f
    if-eqz v12, :cond_65

    const v12, 0x7f0300b2

    goto :goto_31

    :cond_65
    const v12, 0x7f0300b1

    goto :goto_31

    :pswitch_10
    const v12, 0x7f0300ab

    goto :goto_31

    :pswitch_11
    if-eqz v12, :cond_66

    const v12, 0x7f0300a7

    goto :goto_31

    :cond_66
    const v12, 0x7f0300a6

    goto :goto_31

    :pswitch_12
    const v12, 0x7f0300b9

    :goto_31
    const-string v13, "\u041d\u0435\u0442 \u0434\u0430\u043d\u043d\u044b\u0445"

    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_67

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object v12

    iget-object v0, v0, Lc/R0;->a:Ljava/lang/String;

    invoke-virtual {v12, v0}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v0

    move/from16 v18, v14

    goto :goto_32

    :cond_67
    move/from16 v18, v12

    :goto_32
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    iget-object v14, v0, Lc/R0;->d:Ljava/lang/Integer;

    if-eqz v14, :cond_68

    const-string v14, "solar_from"

    move-wide/from16 v43, v5

    const-wide/16 v5, 0x0

    invoke-interface {v11, v14, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v14

    cmp-long v14, v12, v14

    if-ltz v14, :cond_69

    const-string v14, "solar_until"

    invoke-interface {v11, v14, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v14

    cmp-long v14, v12, v14

    if-gez v14, :cond_69

    const/4 v14, 0x1

    goto :goto_33

    :cond_68
    move-wide/from16 v43, v5

    const-wide/16 v5, 0x0

    :cond_69
    const/4 v14, 0x0

    :goto_33
    iget-object v15, v7, Lc/P3;->m:Lc/S0;

    move-object/from16 v37, v0

    if-eqz v14, :cond_6a

    const-string v0, "sunrise"

    invoke-interface {v11, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v30

    move-wide/from16 v45, v30

    goto :goto_34

    :cond_6a
    move-wide/from16 v45, v5

    :goto_34
    if-eqz v14, :cond_6b

    const-string v0, "sunset"

    invoke-interface {v11, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v30

    move-object v0, v8

    move-wide/from16 v20, v12

    move-wide/from16 v11, v45

    move-object v13, v9

    move-wide/from16 v8, v30

    goto :goto_35

    :cond_6b
    move-object v0, v8

    move-wide/from16 v20, v12

    move-wide/from16 v11, v45

    move-object v13, v9

    move-wide v8, v5

    :goto_35
    cmp-long v14, v11, v5

    const-string v22, "\u2014"

    iget-object v5, v15, Lc/S0;->j:Ljava/text/SimpleDateFormat;

    if-lez v14, :cond_6c

    new-instance v6, Ljava/util/Date;

    invoke-direct {v6, v11, v12}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v5, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v6

    goto :goto_36

    :cond_6c
    move-object/from16 v6, v22

    :goto_36
    iput-object v6, v15, Lc/S0;->s:Ljava/lang/String;

    const-wide/16 v11, 0x0

    cmp-long v6, v8, v11

    if-lez v6, :cond_6d

    new-instance v6, Ljava/util/Date;

    invoke-direct {v6, v8, v9}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v5, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v22

    :cond_6d
    move-object/from16 v5, v22

    iput-object v5, v15, Lc/S0;->t:Ljava/lang/String;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, v15, Lc/S0;->s:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " / "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v15, Lc/S0;->t:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v15, Lc/S0;->u:Ljava/lang/String;

    new-instance v5, Lc/U0;

    iget-object v6, v7, Lc/P3;->z1:Lc/x7;

    iget-object v8, v7, Lc/P3;->y1:Lc/P;

    iget-object v8, v8, Lc/P;->a:Lc/K;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v9, v8, Lc/K;->f:Z

    if-eqz v9, :cond_6e

    iget v8, v8, Lc/K;->d:I

    if-ltz v8, :cond_6e

    const/16 v9, 0x14

    mul-int/2addr v8, v9

    move v6, v8

    goto :goto_37

    :cond_6e
    iget-boolean v8, v6, Lc/x7;->e:Z

    if-eqz v8, :cond_6f

    iget v6, v6, Lc/x7;->f:I

    goto :goto_37

    :cond_6f
    const/4 v6, -0x1

    :goto_37
    iget-object v8, v7, Lc/P3;->z1:Lc/x7;

    iget-object v9, v7, Lc/P3;->y1:Lc/P;

    iget-object v9, v9, Lc/P;->a:Lc/K;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v11, v9, Lc/K;->f:Z

    if-eqz v11, :cond_70

    iget v9, v9, Lc/K;->e:I

    if-ltz v9, :cond_70

    move/from16 v22, v9

    goto :goto_38

    :cond_70
    iget-boolean v9, v8, Lc/x7;->e:Z

    if-eqz v9, :cond_71

    iget v8, v8, Lc/x7;->g:I

    move/from16 v22, v8

    goto :goto_38

    :cond_71
    const/16 v22, -0x1

    :goto_38
    if-eqz v3, :cond_73

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_72

    goto :goto_39

    :cond_72
    move-object/from16 v23, v3

    goto :goto_3a

    :cond_73
    :goto_39
    const-string v8, "\u0411\u0435\u0437 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u044f"

    move-object/from16 v23, v8

    :goto_3a
    if-nez v4, :cond_74

    const-string v8, ""

    move-object/from16 v24, v8

    goto :goto_3b

    :cond_74
    move-object/from16 v24, v4

    :goto_3b
    if-eqz v39, :cond_75

    iget-object v8, v7, Lc/P3;->e0:Ljava/util/ArrayList;

    goto :goto_3c

    :cond_75
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v8

    :goto_3c
    invoke-virtual/range {p0 .. p0}, Lc/P3;->o()I

    move-result v9

    if-eqz v10, :cond_77

    if-nez v1, :cond_76

    const/4 v1, 0x0

    const/4 v10, -0x1

    goto :goto_40

    :cond_76
    iget v1, v1, Lc/n1;->a:I

    move v10, v1

    :goto_3d
    const/4 v1, 0x0

    goto :goto_40

    :cond_77
    sget-object v1, Lc/k5;->i:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    sget v10, Lc/k5;->l:I

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v11

    sget-wide v14, Lc/k5;->m:J

    sub-long/2addr v11, v14

    if-lez v10, :cond_78

    const-wide/16 v14, 0x0

    cmp-long v17, v11, v14

    if-ltz v17, :cond_78

    const-wide/16 v14, 0xbb8

    cmp-long v17, v11, v14

    if-gtz v17, :cond_78

    monitor-exit v1

    goto :goto_3d

    :catchall_2
    move-exception v0

    goto/16 :goto_51

    :cond_78
    const-wide/16 v14, 0x0

    cmp-long v10, v11, v14

    if-ltz v10, :cond_79

    const-wide/16 v25, 0xbb8

    cmp-long v10, v11, v25

    if-lez v10, :cond_7a

    :cond_79
    const/4 v10, -0x1

    goto :goto_3e

    :cond_7a
    const/4 v10, -0x1

    goto :goto_3f

    :goto_3e
    sput v10, Lc/k5;->l:I

    sput-wide v14, Lc/k5;->m:J

    :goto_3f
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_3d

    :goto_40
    move-object v14, v5

    move/from16 v11, v19

    const/16 v12, 0x8

    move-wide/from16 v15, v20

    move-object/from16 v17, v13

    move/from16 v19, v39

    move/from16 v20, v11

    move/from16 v21, v6

    move-object/from16 v25, v0

    move-object/from16 v26, v2

    move-wide/from16 v27, v43

    move-wide/from16 v29, v34

    move/from16 v31, v33

    move-object/from16 v33, v36

    move-object/from16 v34, v8

    move-object/from16 v35, v37

    move/from16 v36, v9

    move/from16 v37, v10

    invoke-direct/range {v14 .. v38}, Lc/U0;-><init>(JLjava/lang/String;IZZIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;JJZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Lc/R0;IIZ)V

    iput-object v5, v7, Lc/P3;->B:Lc/U0;

    iget-object v0, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v0

    if-eqz v0, :cond_7b

    const-string v0, "radio"

    goto :goto_41

    :cond_7b
    if-eqz v11, :cond_7d

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->e:Landroid/os/IBinder;

    if-eqz v0, :cond_7c

    const-string v0, "com.syu.bt"

    goto :goto_41

    :cond_7c
    const-string v0, "com.android.bluetooth"

    goto :goto_41

    :cond_7d
    iget-object v0, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_7e

    const-string v0, "com.syu.music"

    goto :goto_41

    :cond_7e
    iget-object v0, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v0, :cond_7f

    const-string v0, ""

    goto :goto_41

    :cond_7f
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    :goto_41
    iget-object v5, v7, Lc/P3;->q0:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-wide/16 v8, 0x3e8

    if-eqz v5, :cond_80

    iget-object v6, v7, Lc/P3;->B:Lc/U0;

    iget-object v6, v6, Lc/U0;->e:Ljava/lang/String;

    iget-object v10, v7, Lc/P3;->r0:Ljava/lang/String;

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_80

    iget-object v6, v7, Lc/P3;->B:Lc/U0;

    iget-object v6, v6, Lc/U0;->f:Ljava/lang/String;

    iget-object v10, v7, Lc/P3;->s0:Ljava/lang/String;

    invoke-virtual {v6, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_83

    :cond_80
    if-eqz v5, :cond_81

    iget-object v5, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->l0()Z

    move-result v5

    if-eqz v5, :cond_82

    :cond_81
    iput-object v1, v7, Lc/P3;->p0:Landroid/graphics/Bitmap;

    :cond_82
    iput-object v0, v7, Lc/P3;->q0:Ljava/lang/String;

    iget-object v5, v7, Lc/P3;->B:Lc/U0;

    iget-object v6, v5, Lc/U0;->e:Ljava/lang/String;

    iput-object v6, v7, Lc/P3;->r0:Ljava/lang/String;

    iget-object v5, v5, Lc/U0;->f:Ljava/lang/String;

    iput-object v5, v7, Lc/P3;->s0:Ljava/lang/String;

    add-long v5, v40, v8

    iput-wide v5, v7, Lc/P3;->t0:J

    :cond_83
    if-eqz v2, :cond_84

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v5

    if-nez v5, :cond_84

    iput-object v2, v7, Lc/P3;->p0:Landroid/graphics/Bitmap;

    add-long v5, v40, v8

    iput-wide v5, v7, Lc/P3;->t0:J

    :cond_84
    iget-object v5, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->l0()Z

    move-result v5

    if-eqz v5, :cond_85

    iget-object v0, v7, Lc/P3;->N1:Lc/g5;

    invoke-virtual {v0}, Lc/g5;->b()V

    goto :goto_44

    :cond_85
    iget-boolean v5, v7, Lc/P3;->L1:Z

    if-nez v5, :cond_86

    iget-object v5, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->k0()Z

    move-result v5

    if-eqz v5, :cond_89

    iget-object v5, v7, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v5}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_89

    :cond_86
    iget-object v5, v7, Lc/P3;->N1:Lc/g5;

    if-nez v11, :cond_88

    iget-object v6, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v6, :cond_87

    goto :goto_42

    :cond_87
    iget-object v14, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    move-object/from16 v19, v14

    goto :goto_43

    :cond_88
    :goto_42
    move-object/from16 v19, v1

    :goto_43
    iget-object v6, v7, Lc/P3;->B:Lc/U0;

    iget-object v8, v6, Lc/U0;->e:Ljava/lang/String;

    iget-object v6, v6, Lc/U0;->f:Ljava/lang/String;

    move-object/from16 v18, v5

    move-object/from16 v20, v0

    move-object/from16 v21, v8

    move-object/from16 v22, v6

    move-object/from16 v23, v2

    invoke-virtual/range {v18 .. v23}, Lc/g5;->m(Landroid/media/session/MediaController;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    :cond_89
    :goto_44
    iget-object v0, v7, Lc/P3;->b1:Lc/E8;

    if-eqz v0, :cond_a3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Lc/Q3;

    if-eqz v0, :cond_8a

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lc/Q3;

    goto :goto_45

    :cond_8a
    move-object v14, v1

    :goto_45
    if-eqz v11, :cond_8c

    iget-object v0, v7, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->e:Landroid/os/IBinder;

    if-eqz v0, :cond_8b

    const-string v0, "com.syu.bt"

    goto :goto_46

    :cond_8b
    const-string v0, "com.android.bluetooth"

    goto :goto_46

    :cond_8c
    iget-object v0, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_8d

    const-string v0, "com.syu.music"

    goto :goto_46

    :cond_8d
    iget-object v0, v7, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v0, :cond_8e

    const-string v0, ""

    goto :goto_46

    :cond_8e
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    :goto_46
    if-eqz v11, :cond_8f

    const-string v2, ""

    :goto_47
    move-object/from16 v9, v42

    goto :goto_48

    :cond_8f
    iget-object v2, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v2, :cond_90

    iget-object v2, v2, Lc/w8;->c:Ljava/lang/String;

    goto :goto_47

    :cond_90
    if-nez v42, :cond_91

    const-string v2, ""

    goto :goto_47

    :cond_91
    const-string v2, "android.media.metadata.MEDIA_ID"

    move-object/from16 v9, v42

    invoke-virtual {v9, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_48
    if-eqz v11, :cond_93

    iget-object v5, v7, Lc/P3;->y1:Lc/P;

    iget-object v5, v5, Lc/P;->l:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_92

    :goto_49
    const/4 v5, 0x1

    goto :goto_4a

    :cond_92
    const/4 v5, 0x0

    goto :goto_4a

    :cond_93
    iget-object v5, v7, Lc/P3;->o1:Lc/w8;

    if-eqz v5, :cond_94

    iget-object v5, v5, Lc/w8;->a:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_92

    goto :goto_49

    :cond_94
    if-eqz v9, :cond_92

    iget-boolean v5, v7, Lc/P3;->k1:Z

    if-eqz v5, :cond_92

    goto :goto_49

    :goto_4a
    iget-object v6, v7, Lc/P3;->b1:Lc/E8;

    iget-object v8, v7, Lc/P3;->C1:Lc/n1;

    const-string v9, "track_popup_enabled"

    iget-object v8, v8, Lc/n1;->b:Ljava/lang/Object;

    check-cast v8, Landroid/content/SharedPreferences;

    const/4 v10, 0x0

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_95

    iget-boolean v8, v7, Lc/P3;->U1:Z

    if-eqz v8, :cond_95

    iget-boolean v8, v7, Lc/P3;->T1:Z

    if-eqz v8, :cond_95

    if-eqz v14, :cond_95

    iget-boolean v8, v14, Lc/Q3;->T:Z

    if-eqz v8, :cond_95

    iget-boolean v8, v14, Lc/F;->f:Z

    if-nez v8, :cond_95

    iget-object v8, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v8}, Lc/n1;->l0()Z

    move-result v8

    if-nez v8, :cond_95

    const/4 v8, 0x1

    goto :goto_4b

    :cond_95
    const/4 v8, 0x0

    :goto_4b
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v8, :cond_96

    invoke-virtual {v6}, Lc/E8;->c()V

    goto/16 :goto_50

    :cond_96
    if-eqz v0, :cond_97

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_97

    iget-object v8, v6, Lc/E8;->e:Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_97

    invoke-virtual {v6}, Lc/E8;->c()V

    iput-object v0, v6, Lc/E8;->e:Ljava/lang/String;

    :cond_97
    if-eqz v5, :cond_a3

    if-eqz v0, :cond_a3

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_a3

    if-eqz v3, :cond_a3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_98

    goto/16 :goto_50

    :cond_98
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const-string v5, ""

    if-nez v4, :cond_99

    move-object v4, v5

    goto :goto_4c

    :cond_99
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    :goto_4c
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v2, :cond_9a

    move-object v2, v5

    :cond_9a
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n"

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    iget-object v5, v6, Lc/E8;->f:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_9b

    iput-object v2, v6, Lc/E8;->f:Ljava/lang/String;

    goto/16 :goto_50

    :cond_9b
    iget-object v5, v6, Lc/E8;->f:Ljava/lang/String;

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_9c

    goto/16 :goto_50

    :cond_9c
    iput-object v2, v6, Lc/E8;->f:Ljava/lang/String;

    iget-object v2, v6, Lc/E8;->a:Lc/z;

    invoke-virtual {v2, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v2

    if-nez v2, :cond_9d

    move-object v14, v1

    goto :goto_4d

    :cond_9d
    iget-object v14, v2, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    :goto_4d
    if-nez v14, :cond_9e

    :try_start_6
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v5

    invoke-virtual {v5, v0}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v14
    :try_end_6
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/SecurityException; {:try_start_6 .. :try_end_6} :catch_2

    :catch_2
    :cond_9e
    iget-object v0, v6, Lc/E8;->b:Landroid/widget/ImageView;

    if-eqz v2, :cond_9f

    iget-object v2, v2, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_9f

    goto :goto_4e

    :cond_9f
    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    if-nez v14, :cond_a0

    invoke-virtual {v6}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const v8, 0x7f03001d

    invoke-virtual {v5, v8}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    :cond_a0
    invoke-static {v2, v14}, Lc/s;->f(Landroid/content/Context;Landroid/graphics/drawable/Drawable;)Lc/q;

    move-result-object v2

    :goto_4e
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, v6, Lc/E8;->c:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setSelected(Z)V

    iget-object v5, v6, Lc/E8;->d:Landroid/widget/TextView;

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_a1

    move v13, v12

    goto :goto_4f

    :cond_a1
    const/4 v13, 0x0

    :goto_4f
    invoke-virtual {v5, v13}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v6}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {v6}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_a2

    invoke-virtual {v6, v1}, Landroid/view/View;->setAlpha(F)V

    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {v6, v0}, Lc/E8;->b(F)I

    move-result v0

    neg-int v0, v0

    int-to-float v0, v0

    invoke-virtual {v6, v0}, Landroid/view/View;->setTranslationY(F)V

    const/4 v0, 0x0

    invoke-virtual {v6, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_a2
    invoke-virtual {v6}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0xb4

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    iget-object v0, v6, Lc/E8;->g:Lc/D8;

    invoke-virtual {v6, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const-wide/16 v1, 0xfa0

    invoke-virtual {v6, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_a3
    :goto_50
    if-nez v39, :cond_a4

    iget-object v0, v7, Lc/P3;->e0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    :cond_a4
    return-void

    :goto_51
    :try_start_7
    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    throw v0

    :goto_52
    :try_start_8
    monitor-exit v9
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    throw v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x6fc1b57b -> :sswitch_14
        -0x50ea171c -> :sswitch_13
        -0x4e3db5a8 -> :sswitch_12
        -0x1b63456f -> :sswitch_11
        -0xf300a15 -> :sswitch_10
        -0xf2f6426 -> :sswitch_f
        -0xedc8876 -> :sswitch_e
        0x18cbe -> :sswitch_d
        0x30bfdc -> :sswitch_c
        0x3324fd -> :sswitch_b
        0x354b94 -> :sswitch_a
        0x35f183 -> :sswitch_9
        0x48712ff -> :sswitch_8
        0x5a5b64d -> :sswitch_7
        0x1f902e13 -> :sswitch_6
        0x4c70e0da -> :sswitch_5
        0x72788cd4 -> :sswitch_4
        0x75c4473b -> :sswitch_3
        0x75c8d2f3 -> :sswitch_2
        0x78471a1e -> :sswitch_1
        0x7b387149 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_b
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_10
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final X()V
    .locals 6

    const/4 v0, 0x0

    :try_start_0
    iget-boolean v1, p0, Lc/P3;->U1:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lc/P3;->P()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    if-eqz v1, :cond_0

    iget-boolean v1, p0, Lc/P3;->j1:Z

    if-nez v1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v3, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    iget-object v4, p0, Lc/P3;->l1:Lc/L;

    iget-object v5, p0, Lc/P3;->W0:Landroid/os/Handler;

    invoke-static {v1, v3, v4, v5}, Lc/G8;->W(Landroid/content/Context;Landroid/media/session/MediaSessionManager;Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/os/Handler;)V

    iput-boolean v2, p0, Lc/P3;->j1:Z

    :cond_0
    iget-object v1, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    if-nez v1, :cond_1

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v3, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    invoke-static {v1, v3}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v1

    :goto_0
    invoke-virtual {p0, v1}, Lc/P3;->S(Ljava/util/List;)V

    iget-object v1, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    if-eqz v1, :cond_2

    goto :goto_1

    :cond_2
    move v2, v0

    :goto_1
    iput-boolean v2, p0, Lc/P3;->k1:Z
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/P3;->S(Ljava/util/List;)V

    iput-boolean v0, p0, Lc/P3;->k1:Z

    :goto_2
    return-void
.end method

.method public final Y()V
    .locals 25

    move-object/from16 v0, p0

    const-string v1, "com.syu.radio"

    const-string v2, ""

    iget-object v3, v0, Lc/P3;->W0:Landroid/os/Handler;

    iget-object v4, v0, Lc/P3;->n1:Lc/F3;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v3, 0x0

    iput-boolean v3, v0, Lc/P3;->m1:Z

    invoke-virtual/range {p0 .. p0}, Lc/P3;->j0()Z

    iget-boolean v4, v0, Lc/P3;->U1:Z

    if-eqz v4, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/P3;->P()Z

    move-result v4

    if-eqz v4, :cond_0

    iget-boolean v4, v0, Lc/P3;->j1:Z

    if-nez v4, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/P3;->X()V

    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    iput-wide v4, v0, Lc/P3;->Z0:J

    sget-object v4, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    iput-object v4, v0, Lc/P3;->a1:Lc/w8;

    iget-object v4, v0, Lc/P3;->e0:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    sget-object v4, Lru/drivedeck/launcher/NotificationBridgeService;->d:Ljava/util/List;

    iput-object v4, v0, Lc/P3;->g0:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/q5;

    invoke-virtual {v5}, Lc/q5;->b()Z

    move-result v6

    if-nez v6, :cond_1

    iget-object v6, v5, Lc/q5;->a:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    iget-object v6, v0, Lc/P3;->e0:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v7, 0x4

    if-ge v6, v7, :cond_1

    iget-object v6, v0, Lc/P3;->e0:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    iput-object v4, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    iget-object v5, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x3

    const-wide/16 v8, 0x1388

    :try_start_0
    iget-object v10, v0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    if-eqz v10, :cond_1c

    iget-object v10, v0, Lc/P3;->h1:Ljava/util/List;

    iget-object v11, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v11}, Lc/n1;->t0()J

    move-result-wide v11

    iget-object v13, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->e0()Z

    move-result v13
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v7, "com.android.bluetooth"

    const-string v14, "com.syu.bt"

    if-eqz v13, :cond_3

    :try_start_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v17

    sub-long v17, v17, v11

    cmp-long v13, v17, v8

    if-gez v13, :cond_3

    goto :goto_2

    :cond_3
    iget-object v13, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->e0()Z

    move-result v13

    if-eqz v13, :cond_5

    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v13

    :goto_1
    invoke-interface {v13}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_5

    invoke-interface {v13}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroid/media/session/MediaController;

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v15

    invoke-virtual {v4, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_4

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_4

    if-eqz v15, :cond_4

    invoke-virtual {v15}, Landroid/media/session/PlaybackState;->getState()I

    move-result v15

    if-ne v15, v6, :cond_4

    invoke-static {v4}, Lc/P3;->M(Ljava/lang/String;)Z

    move-result v15

    if-nez v15, :cond_4

    iget-object v11, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v11, v3}, Lc/n1;->A0(Z)V

    iget-object v11, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v11, v4}, Lc/n1;->I0(Ljava/lang/String;)V

    iget-object v11, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v11, v4}, Lc/n1;->J0(Ljava/lang/String;)V

    const-wide/16 v11, 0x0

    goto :goto_2

    :cond_4
    const/4 v4, 0x0

    goto :goto_1

    :cond_5
    :goto_2
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_6

    move-object v4, v5

    goto :goto_3

    :cond_6
    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->l0()Z

    move-result v4

    if-eqz v4, :cond_7

    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->D()Ljava/lang/String;

    move-result-object v4

    goto :goto_3

    :cond_7
    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    const-string v13, "last_media_package"

    iget-object v4, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    invoke-interface {v4, v13, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_3
    iget-object v13, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->e0()Z

    move-result v13

    if-nez v13, :cond_8

    if-eqz v4, :cond_8

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_8

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v18

    sub-long v18, v18, v11

    cmp-long v13, v18, v8

    if-gez v13, :cond_8

    const/4 v13, 0x1

    goto :goto_4

    :cond_8
    move v13, v3

    :goto_4
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v10

    const/4 v15, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    :goto_5
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_17

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Landroid/media/session/MediaController;

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_a

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_9

    goto :goto_6

    :cond_9
    const/4 v8, 0x0

    goto :goto_7

    :cond_a
    :goto_6
    const/4 v8, 0x1

    :goto_7
    iget-object v9, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v9}, Lc/n1;->e0()Z

    move-result v9

    if-eqz v9, :cond_b

    if-nez v8, :cond_b

    move-object/from16 v22, v7

    goto :goto_b

    :cond_b
    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v9

    if-nez v9, :cond_c

    move-object/from16 v22, v7

    const/4 v7, 0x0

    goto :goto_8

    :cond_c
    invoke-virtual {v9}, Landroid/media/session/PlaybackState;->getState()I

    move-result v21

    move-object/from16 v22, v7

    move/from16 v7, v21

    :goto_8
    if-nez v9, :cond_d

    const-wide/16 v23, 0x0

    goto :goto_9

    :cond_d
    invoke-virtual {v9}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v23

    :goto_9
    iget-object v9, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v9}, Lc/n1;->l0()Z

    move-result v9

    if-nez v9, :cond_e

    const-string v9, "ru.yandex.yandexnavi"

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v9, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_e

    const/4 v6, 0x3

    if-ne v7, v6, :cond_e

    cmp-long v6, v23, v11

    if-lez v6, :cond_e

    const/4 v6, 0x1

    goto :goto_a

    :cond_e
    const/4 v6, 0x0

    :goto_a
    if-eqz v13, :cond_f

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_f

    if-nez v6, :cond_f

    goto :goto_b

    :cond_f
    if-eqz v8, :cond_11

    iget-object v6, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v6}, Lc/n1;->e0()Z

    move-result v6

    if-nez v6, :cond_11

    :cond_10
    :goto_b
    move-object/from16 v7, v22

    const/4 v6, 0x3

    const-wide/16 v8, 0x1388

    goto/16 :goto_5

    :cond_11
    const/4 v6, 0x3

    if-ne v7, v6, :cond_12

    const/4 v6, 0x2

    goto :goto_d

    :cond_12
    const/4 v6, 0x6

    if-eq v7, v6, :cond_14

    const/16 v6, 0x8

    if-ne v7, v6, :cond_13

    goto :goto_c

    :cond_13
    const/4 v6, 0x0

    goto :goto_d

    :cond_14
    :goto_c
    const/4 v6, 0x1

    :goto_d
    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lc/P3;->M(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_15

    if-le v6, v3, :cond_15

    move v3, v6

    move-object/from16 v15, v20

    :cond_15
    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_16

    move-object/from16 v18, v20

    :cond_16
    if-nez v19, :cond_10

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lc/P3;->M(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_10

    invoke-virtual/range {v20 .. v20}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v6

    if-eqz v6, :cond_10

    move-object/from16 v19, v20

    goto :goto_b

    :cond_17
    if-eqz v15, :cond_18

    move-object v3, v15

    goto :goto_e

    :cond_18
    if-eqz v18, :cond_19

    move-object/from16 v3, v18

    goto :goto_e

    :cond_19
    move-object/from16 v3, v19

    :goto_e
    iput-object v3, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v15, :cond_1c

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->e0()Z

    move-result v3

    if-nez v3, :cond_1c

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_1a

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1a

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3, v2}, Lc/n1;->v0(Ljava/lang/String;)V

    :cond_1a
    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1b

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "radio_app_package"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_1b
    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lc/n1;->I0(Ljava/lang/String;)V

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/P3;->M(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1c

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v15}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Lc/n1;->J0(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_1c
    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v1, :cond_1d

    iget-object v3, v0, Lc/P3;->w1:Landroid/media/session/MediaController;

    if-eqz v3, :cond_1d

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v1

    iget-object v3, v0, Lc/P3;->w1:Landroid/media/session/MediaController;

    invoke-virtual {v3}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/media/session/MediaSession$Token;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    :cond_1d
    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    iput-object v1, v0, Lc/P3;->w1:Landroid/media/session/MediaController;

    :cond_1e
    iget-object v1, v0, Lc/P3;->w1:Landroid/media/session/MediaController;

    iput-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v1, :cond_1f

    const/4 v1, 0x0

    goto :goto_f

    :cond_1f
    invoke-virtual {v1}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v1

    :goto_f
    iput-object v1, v0, Lc/P3;->d1:Landroid/media/MediaMetadata;

    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v1, :cond_20

    const/4 v1, 0x0

    goto :goto_10

    :cond_20
    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    :goto_10
    iput-object v1, v0, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    const/4 v1, 0x0

    iput-object v1, v0, Lc/P3;->o1:Lc/w8;

    sget-object v1, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->e0()Z

    move-result v3

    if-eqz v3, :cond_21

    if-eqz v1, :cond_21

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v1, v3, v4}, Lc/w8;->b(J)Z

    move-result v3

    if-eqz v3, :cond_21

    iget-wide v3, v1, Lc/w8;->g:J

    iget-object v6, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v6}, Lc/n1;->t0()J

    move-result-wide v6

    cmp-long v3, v3, v6

    if-lez v3, :cond_21

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-object v6, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v6}, Lc/n1;->t0()J

    move-result-wide v6

    sub-long/2addr v3, v6

    const-wide/16 v6, 0x1388

    cmp-long v3, v3, v6

    if-ltz v3, :cond_21

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Lc/n1;->A0(Z)V

    const/4 v3, 0x0

    iput-object v3, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    iput-object v3, v0, Lc/P3;->d1:Landroid/media/MediaMetadata;

    iput-object v3, v0, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    goto :goto_11

    :cond_21
    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_11
    iget-object v6, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v6}, Lc/n1;->e0()Z

    move-result v6

    if-nez v6, :cond_29

    if-eqz v1, :cond_29

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    const-string v7, "com.syu.music"

    if-nez v6, :cond_22

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_22

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-object v8, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v8}, Lc/n1;->t0()J

    move-result-wide v8

    sub-long/2addr v5, v8

    const-wide/16 v8, 0x1388

    cmp-long v5, v5, v8

    if-ltz v5, :cond_29

    :cond_22
    iget-object v5, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v5, :cond_23

    goto :goto_12

    :cond_23
    invoke-virtual {v5}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v3

    :goto_12
    if-eqz v3, :cond_24

    invoke-virtual {v3}, Landroid/media/session/PlaybackState;->getState()I

    move-result v5

    const/4 v6, 0x3

    if-ne v5, v6, :cond_24

    const/16 v16, 0x1

    goto :goto_13

    :cond_24
    move/from16 v16, v4

    :goto_13
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    invoke-virtual {v1, v4, v5}, Lc/w8;->b(J)Z

    move-result v4

    if-eqz v4, :cond_26

    iget-object v5, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_25

    iget-wide v5, v1, Lc/w8;->g:J

    iget-object v8, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v8}, Lc/n1;->t0()J

    move-result-wide v8

    cmp-long v5, v5, v8

    if-lez v5, :cond_26

    :cond_25
    if-eqz v16, :cond_27

    iget-wide v5, v1, Lc/w8;->g:J

    invoke-virtual {v3}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v8

    cmp-long v3, v5, v8

    if-gez v3, :cond_27

    :cond_26
    if-nez v16, :cond_29

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_29

    :cond_27
    iput-object v1, v0, Lc/P3;->o1:Lc/w8;

    if-eqz v4, :cond_29

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->t0()J

    move-result-wide v5

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x1388

    cmp-long v1, v3, v5

    if-ltz v1, :cond_29

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_28

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_28

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1, v2}, Lc/n1;->v0(Ljava/lang/String;)V

    :cond_28
    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1, v7}, Lc/n1;->I0(Ljava/lang/String;)V

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1, v7}, Lc/n1;->J0(Ljava/lang/String;)V

    :cond_29
    invoke-virtual/range {p0 .. p0}, Lc/P3;->n()Lc/V4;

    move-result-object v1

    iput-object v1, v0, Lc/P3;->f1:Lc/V4;

    invoke-virtual/range {p0 .. p0}, Lc/P3;->a0()V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->W()V

    return-void
.end method

.method public final Z()V
    .locals 4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Lc/P3;->o0()Lc/i;

    move-result-object v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v0, :cond_0

    const-string v0, "\u041f\u043e\u0433\u043e\u0434\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u044f\u0435\u0442\u0441\u044f"

    goto :goto_0

    :cond_0
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0447\u0430\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435"

    :goto_0
    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final a(ILandroid/graphics/Rect;)Z
    .locals 3

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iget-object v1, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v2, v1, Lc/g1;->M:Z

    if-nez v2, :cond_0

    invoke-virtual {p0, p1, v0}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    goto :goto_0

    :cond_0
    iget-object p1, v1, Lc/g1;->H:Lc/s0;

    invoke-virtual {v1, p1, v0}, Lc/g1;->p(Lc/s0;Landroid/graphics/RectF;)V

    :goto_0
    invoke-virtual {v0, p2}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    invoke-virtual {p2}, Landroid/graphics/Rect;->isEmpty()Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    return p1
.end method

.method public final a0()V
    .locals 22

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/P3;->o1:Lc/w8;

    if-eqz v1, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, v0, Lc/P3;->o1:Lc/w8;

    iget-object v3, v2, Lc/w8;->a:Ljava/lang/String;

    iget-object v2, v2, Lc/w8;->b:Ljava/lang/String;

    const-string v4, "com.syu.music"

    invoke-static {v1, v4, v3, v2}, Lc/G8;->o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_6

    :cond_0
    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->e0()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-object v1, v0, Lc/P3;->y1:Lc/P;

    iget-object v1, v1, Lc/P;->l:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, v0, Lc/P3;->y1:Lc/P;

    iget-object v3, v2, Lc/P;->e:Landroid/os/IBinder;

    if-eqz v3, :cond_1

    const-string v3, "com.syu.bt"

    goto :goto_0

    :cond_1
    const-string v3, "com.android.bluetooth"

    :goto_0
    iget-object v2, v2, Lc/P;->l:Ljava/lang/String;

    iget-object v4, v0, Lc/P3;->y1:Lc/P;

    iget-object v4, v4, Lc/P;->m:Ljava/lang/String;

    invoke-static {v1, v3, v2, v4}, Lc/G8;->o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_6

    :cond_2
    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v1, :cond_c

    iget-object v2, v0, Lc/P3;->d1:Landroid/media/MediaMetadata;

    if-eqz v2, :cond_c

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/P3;->M(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_c

    iget-object v1, v0, Lc/P3;->d1:Landroid/media/MediaMetadata;

    iget-object v2, v0, Lc/P3;->e1:Landroid/media/session/PlaybackState;

    const-wide/16 v3, -0x1

    if-nez v2, :cond_3

    move-wide v5, v3

    goto :goto_1

    :cond_3
    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v5

    :goto_1
    const/4 v7, 0x0

    if-eqz v2, :cond_5

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getState()I

    move-result v9

    const/4 v10, 0x3

    if-eq v9, v10, :cond_4

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getState()I

    move-result v9

    const/4 v10, 0x6

    if-ne v9, v10, :cond_5

    :cond_4
    const/4 v9, 0x1

    goto :goto_2

    :cond_5
    move v9, v7

    :goto_2
    const-wide/16 v10, 0x0

    if-eqz v9, :cond_6

    cmp-long v12, v5, v10

    if-ltz v12, :cond_6

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v12

    cmp-long v12, v12, v10

    if-lez v12, :cond_6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v12

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getLastPositionUpdateTime()J

    move-result-wide v14

    sub-long/2addr v12, v14

    long-to-float v12, v12

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getPlaybackSpeed()F

    move-result v2

    mul-float/2addr v2, v12

    float-to-long v12, v2

    add-long/2addr v5, v12

    :cond_6
    const-string v2, "android.media.metadata.TITLE"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v12, "android.media.metadata.ARTIST"

    invoke-virtual {v1, v12}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    iget-object v14, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v14}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v14

    invoke-static {v13, v14, v2, v12}, Lc/G8;->o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    iget-object v14, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v14}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v14

    const-string v15, "android.media.metadata.DURATION"

    move/from16 v17, v9

    invoke-virtual {v1, v15}, Landroid/media/MediaMetadata;->getLong(Ljava/lang/String;)J

    move-result-wide v8

    cmp-long v1, v5, v10

    if-ltz v1, :cond_c

    if-eqz v14, :cond_c

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_c

    if-eqz v2, :cond_c

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    goto/16 :goto_6

    :cond_7
    const-string v1, "last_playback"

    invoke-virtual {v13, v1, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    new-instance v15, Ljava/lang/StringBuilder;

    const-string v10, "player."

    invoke-direct {v15, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, "."

    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, "position"

    invoke-virtual {v11, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v1, v11, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "playing"

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v0, 0x0

    invoke-interface {v1, v11, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v11

    const-string v0, ""

    move-object/from16 v18, v7

    move-wide/from16 v19, v8

    if-nez v12, :cond_8

    move-object v7, v0

    goto :goto_3

    :cond_8
    move-object v7, v12

    :goto_3
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "title"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v1, v8, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    move-object/from16 v21, v15

    const-string v15, "artist"

    if-eqz v8, :cond_9

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v1, v8, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    const/16 v16, 0x1

    goto :goto_4

    :cond_9
    const/16 v16, 0x0

    :goto_4
    invoke-static {v13, v14, v2, v12}, Lc/G8;->o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v16, :cond_a

    const-wide/16 v12, 0x0

    cmp-long v0, v3, v12

    if-ltz v0, :cond_a

    move/from16 v8, v17

    if-ne v8, v11, :cond_b

    sub-long v3, v5, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v3

    const-wide/16 v11, 0xbb8

    cmp-long v0, v3, v11

    if-ltz v0, :cond_c

    goto :goto_5

    :cond_a
    move/from16 v8, v17

    :cond_b
    :goto_5
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v2, v21

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v5, v6}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "duration"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    move-wide/from16 v2, v19

    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v2, v18

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_c
    :goto_6
    return-void
.end method

.method public final b()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/P3;->z0:Z

    iget-object v0, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v0, Lc/g1;->M:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/g1;->r()V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/g1;->m(Z)V

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final b0(Ljava/util/ArrayList;I)V
    .locals 6

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {p0, p2, v3}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    const/16 v0, 0x64

    if-lt p2, v0, :cond_0

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v1, v1

    add-int/2addr v1, v0

    if-ge p2, v1, :cond_0

    new-instance v0, Lc/L3;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p2, v1}, Lc/L3;-><init>(Lc/P3;II)V

    :goto_0
    move-object v5, v0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    goto :goto_0

    :goto_1
    new-instance v4, Lc/L3;

    const/4 v0, 0x1

    invoke-direct {v4, p0, p2, v0}, Lc/L3;-><init>(Lc/P3;II)V

    move-object v0, p1

    move-object v1, p0

    move v2, p2

    invoke-static/range {v0 .. v5}, Lc/t8;->b(Ljava/util/ArrayList;Landroid/view/View;ILandroid/graphics/RectF;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    return-void
.end method

.method public final c()Z
    .locals 1

    iget-boolean v0, p0, Lc/P3;->z0:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v0, v0, Lc/g1;->J:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public final c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V
    .locals 2

    iget-object v0, p0, Lc/P3;->M:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p1, p2, p3, p3, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final d(Ljava/util/ArrayList;)V
    .locals 6

    iget-boolean v0, p0, Lc/P3;->z0:Z

    iget-object v1, p0, Lc/P3;->A:Lc/g1;

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    iget-boolean v0, v1, Lc/g1;->J:Z

    if-nez v0, :cond_1

    :goto_0
    const/4 v0, 0x5

    if-ge v2, v0, :cond_0

    add-int/lit16 v0, v2, 0x7d0

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void

    :cond_1
    iget-boolean v0, v1, Lc/g1;->J:Z

    if-eqz v0, :cond_4

    const/16 v0, 0xffa

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    move v0, v2

    :goto_1
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v1, v1

    if-ge v0, v1, :cond_2

    add-int/lit16 v1, v0, 0xfd2

    invoke-virtual {p0, p1, v1}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    array-length v0, v0

    mul-int/lit8 v0, v0, 0x3

    add-int/lit8 v0, v0, 0x2

    if-ge v2, v0, :cond_3

    add-int/lit16 v0, v2, 0xfa0

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    return-void

    :cond_4
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    array-length v1, v0

    move v3, v2

    :goto_3
    if-ge v3, v1, :cond_6

    aget-object v4, v0, v3

    sget-object v5, Lc/s0;->i:Lc/s0;

    if-eq v4, v5, :cond_5

    sget-object v5, Lc/s0;->m:Lc/s0;

    if-eq v4, v5, :cond_5

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    add-int/lit8 v4, v4, 0x64

    invoke-virtual {p0, p1, v4}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    :cond_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_6
    move v0, v2

    :goto_4
    iget-object v1, p0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_7

    add-int/lit16 v1, v0, 0x3e8

    invoke-virtual {p0, p1, v1}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_4

    :cond_7
    move v0, v2

    :goto_5
    iget-object v1, p0, Lc/P3;->t1:Lc/g0;

    iget-object v3, v1, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_9

    invoke-virtual {v1, v0}, Lc/g0;->b(I)Z

    move-result v1

    if-eqz v1, :cond_8

    add-int/lit16 v1, v0, 0xbb8

    invoke-virtual {p0, p1, v1}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    :cond_8
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_9
    const/16 v0, 0x1389

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    const/16 v0, 0x1388

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    :goto_6
    const/16 v0, 0x9

    if-ge v2, v0, :cond_a

    add-int/lit16 v0, v2, 0x1770

    invoke-virtual {p0, p1, v0}, Lc/P3;->b0(Ljava/util/ArrayList;I)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_a
    return-void
.end method

.method public final d0(FZ)V
    .locals 9

    invoke-virtual {p0}, Lc/P3;->j()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/P3;->V:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/4 v2, 0x0

    cmpg-float v1, v1, v2

    if-gtz v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    if-nez p2, :cond_1

    iget-wide v5, p0, Lc/P3;->H1:J

    sub-long v5, v3, v5

    const-wide/16 v7, 0xfa

    cmp-long p2, v5, v7

    if-gez p2, :cond_1

    return-void

    :cond_1
    iget p2, v0, Landroid/graphics/RectF;->left:F

    sub-float/2addr p1, p2

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result p2

    div-float/2addr p1, p2

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-static {p2, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {v2, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    :try_start_0
    invoke-static {}, Lc/G8;->l()V

    iget-object p2, p0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {p2}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p2

    iget-object v0, p0, Lc/P3;->B:Lc/U0;

    iget-wide v0, v0, Lc/U0;->c:J

    long-to-float v0, v0

    mul-float/2addr v0, p1

    float-to-long v0, v0

    invoke-virtual {p2, v0, v1}, Landroid/media/session/MediaController$TransportControls;->seekTo(J)V

    iput-wide v3, p0, Lc/P3;->H1:J
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    :goto_0
    return-void
.end method

.method public final dispatchHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 12

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v1, 0x0

    const/16 v2, 0x100

    const/4 v3, -0x1

    if-nez v0, :cond_1

    iget p1, p0, Lc/P3;->S1:I

    if-eq p1, v3, :cond_0

    invoke-virtual {p0, p1, v2}, Lc/P3;->e0(II)V

    iput v3, p0, Lc/P3;->S1:I

    :cond_0
    return v1

    :cond_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/16 v4, 0xa

    const/4 v5, 0x1

    if-ne v0, v4, :cond_3

    iget p1, p0, Lc/P3;->S1:I

    if-eq p1, v3, :cond_2

    invoke-virtual {p0, p1, v2}, Lc/P3;->e0(II)V

    :cond_2
    iput v3, p0, Lc/P3;->S1:I

    return v5

    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    iget-object v6, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v7, v6, Lc/g1;->J:Z

    if-nez v7, :cond_4

    iget-object v7, p0, Lc/P3;->f:Lc/o0;

    if-eqz v7, :cond_4

    sget-object v8, Lc/s0;->l:Lc/s0;

    iget-object v7, v7, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v7, v8}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_4

    iget-object v7, p0, Lc/P3;->n:Lc/G0;

    iget-object v7, v7, Lc/G0;->k:Landroid/graphics/RectF;

    invoke-virtual {v7, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v7

    if-eqz v7, :cond_4

    const/16 v0, 0x1389

    goto/16 :goto_5

    :cond_4
    iget-boolean v7, v6, Lc/g1;->J:Z

    if-nez v7, :cond_5

    iget-object v7, p0, Lc/P3;->L0:Landroid/graphics/RectF;

    invoke-virtual {v7, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v7

    if-eqz v7, :cond_5

    const/16 v0, 0x1388

    goto/16 :goto_5

    :cond_5
    iget-boolean v7, v6, Lc/g1;->J:Z

    iget-object v8, p0, Lc/P3;->R:Landroid/graphics/RectF;

    if-nez v7, :cond_7

    move v7, v1

    :goto_0
    const/16 v9, 0x9

    if-ge v7, v9, :cond_7

    add-int/lit16 v9, v7, 0x1770

    invoke-virtual {p0, v9, v8}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v8, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v10

    if-eqz v10, :cond_6

    move v0, v9

    goto/16 :goto_5

    :cond_6
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_7
    iget-boolean v7, v6, Lc/g1;->J:Z

    if-eqz v7, :cond_8

    iget-object v6, v6, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {v6, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v6

    if-eqz v6, :cond_8

    const/16 v0, 0xffa

    goto/16 :goto_5

    :cond_8
    move v6, v1

    :goto_1
    iget-object v7, p0, Lc/P3;->t1:Lc/g0;

    iget-object v9, v7, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v6, v9, :cond_a

    invoke-virtual {v7, v6}, Lc/g0;->b(I)Z

    move-result v9

    if-eqz v9, :cond_9

    invoke-virtual {v7, v6}, Lc/g0;->a(I)Landroid/graphics/RectF;

    move-result-object v7

    invoke-virtual {v7, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v7

    if-eqz v7, :cond_9

    add-int/lit16 v0, v6, 0xbb8

    goto :goto_5

    :cond_9
    add-int/lit8 v6, v6, 0x1

    goto :goto_1

    :cond_a
    move v6, v1

    :goto_2
    iget-object v7, p0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v6, v9, :cond_c

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/RectF;

    invoke-virtual {v7, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v7

    if-eqz v7, :cond_b

    add-int/lit16 v0, v6, 0x3e8

    goto :goto_5

    :cond_b
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_c
    move v6, v1

    :goto_3
    const/4 v7, 0x5

    if-ge v6, v7, :cond_e

    add-int/lit16 v7, v6, 0x7d0

    invoke-virtual {p0, v7, v8}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v8, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v9

    if-eqz v9, :cond_d

    move v0, v7

    goto :goto_5

    :cond_d
    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_e
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v6

    array-length v7, v6

    move v9, v1

    :goto_4
    if-ge v9, v7, :cond_10

    aget-object v10, v6, v9

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v11

    add-int/lit8 v11, v11, 0x64

    invoke-virtual {p0, v11, v8}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v8, v0, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v11

    if-eqz v11, :cond_f

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    add-int/lit8 v0, v0, 0x64

    goto :goto_5

    :cond_f
    add-int/lit8 v9, v9, 0x1

    goto :goto_4

    :cond_10
    move v0, v3

    :goto_5
    iget v4, p0, Lc/P3;->S1:I

    if-eq v0, v4, :cond_12

    if-eq v4, v3, :cond_11

    invoke-virtual {p0, v4, v2}, Lc/P3;->e0(II)V

    :cond_11
    iput v0, p0, Lc/P3;->S1:I

    if-eq v0, v3, :cond_12

    const/16 v2, 0x80

    invoke-virtual {p0, v0, v2}, Lc/P3;->e0(II)V

    :cond_12
    if-ne v0, v3, :cond_13

    invoke-super {p0, p1}, Landroid/view/View;->dispatchHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    if-eqz p1, :cond_14

    :cond_13
    move v1, v5

    :cond_14
    return v1
.end method

.method public final e(Landroid/view/KeyEvent;)Z
    .locals 12

    iget-object v0, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v0, Lc/g1;->M:Z

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v1, :cond_0

    goto :goto_6

    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    const/16 v5, 0x17

    if-eq v1, v5, :cond_2

    const/16 v5, 0x42

    if-eq v1, v5, :cond_2

    const/16 v5, 0xa0

    if-ne v1, v5, :cond_1

    goto :goto_0

    :cond_1
    move v5, v4

    goto :goto_1

    :cond_2
    :goto_0
    move v5, v2

    :goto_1
    if-ne v1, v3, :cond_3

    move v6, v2

    goto :goto_2

    :cond_3
    move v6, v4

    :goto_2
    const/16 v7, 0x15

    const/4 v8, -0x1

    if-ne v1, v7, :cond_4

    move v7, v8

    goto :goto_3

    :cond_4
    const/16 v7, 0x16

    if-ne v1, v7, :cond_5

    move v7, v2

    goto :goto_3

    :cond_5
    move v7, v4

    :goto_3
    const/16 v9, 0x13

    const/16 v10, 0x105

    const/16 v11, 0x104

    if-eq v1, v9, :cond_9

    if-ne v1, v11, :cond_6

    goto :goto_5

    :cond_6
    const/16 v8, 0x14

    if-eq v1, v8, :cond_8

    if-ne v1, v10, :cond_7

    goto :goto_4

    :cond_7
    move v8, v4

    goto :goto_5

    :cond_8
    :goto_4
    move v8, v2

    :cond_9
    :goto_5
    if-nez v5, :cond_e

    if-nez v6, :cond_e

    if-nez v7, :cond_e

    if-nez v8, :cond_e

    :goto_6
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    if-ne v1, v3, :cond_d

    iget-boolean v1, p0, Lc/P3;->z0:Z

    if-nez v1, :cond_a

    iget-boolean v1, v0, Lc/g1;->J:Z

    if-nez v1, :cond_a

    goto :goto_7

    :cond_a
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-ne p1, v2, :cond_c

    iput-boolean v4, p0, Lc/P3;->z0:Z

    iget-boolean p1, v0, Lc/g1;->J:Z

    if-eqz p1, :cond_b

    invoke-virtual {v0}, Lc/g1;->c()Z

    :cond_b
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_c
    return v2

    :cond_d
    :goto_7
    return v4

    :cond_e
    const/4 v3, 0x0

    if-nez v5, :cond_21

    if-eqz v6, :cond_f

    goto/16 :goto_c

    :cond_f
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-eqz p1, :cond_10

    goto/16 :goto_e

    :cond_10
    iget p1, v0, Lc/g1;->N:I

    if-ne p1, v2, :cond_12

    if-eq v1, v11, :cond_11

    if-ne v1, v10, :cond_12

    :cond_11
    move v7, v8

    move v8, v4

    :cond_12
    iget-object p1, v0, Lc/g1;->E:Lc/r0;

    if-eqz p1, :cond_13

    goto :goto_8

    :cond_13
    iget-object p1, v0, Lc/g1;->C:Lc/u0;

    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {p1, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object p1

    :goto_8
    iget v1, v0, Lc/g1;->N:I

    const/16 v5, 0x1e

    if-ne v1, v2, :cond_1c

    iget-object v1, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v6, v1, Lc/o0;->f:Z

    if-eqz v6, :cond_19

    iget-object p1, v0, Lc/g1;->D:Lc/u0;

    if-eqz p1, :cond_14

    goto :goto_9

    :cond_14
    iget-object p1, v0, Lc/g1;->C:Lc/u0;

    :goto_9
    iget-object v1, p1, Lc/u0;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v3, v4

    move v5, v3

    :cond_15
    :goto_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_17

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    iget-boolean v9, v6, Lc/r0;->g:Z

    if-nez v9, :cond_15

    iget-object v6, v6, Lc/r0;->a:Lc/s0;

    iget-object v9, v0, Lc/g1;->H:Lc/s0;

    if-ne v6, v9, :cond_16

    move v5, v3

    :cond_16
    add-int/lit8 v3, v3, 0x1

    goto :goto_a

    :cond_17
    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    sub-int/2addr v3, v2

    if-eqz v8, :cond_18

    move v7, v8

    :cond_18
    add-int/2addr v5, v7

    invoke-static {v3, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {p1, v1, v3}, Lc/u0;->q(Lc/s0;I)Lc/u0;

    move-result-object p1

    iput-object p1, v0, Lc/g1;->D:Lc/u0;

    iput-boolean v2, v0, Lc/g1;->K:Z

    invoke-virtual {v0, v2}, Lc/g1;->m(Z)V

    goto/16 :goto_e

    :cond_19
    sget-object v6, Lc/Q1;->b:Lc/Q1;

    iget-object v1, v1, Lc/o0;->j:Lc/Q1;

    if-ne v1, v6, :cond_1a

    neg-int v7, v7

    :cond_1a
    iget v1, p1, Lc/r0;->e:I

    sub-int/2addr v5, v1

    iget v1, p1, Lc/r0;->c:I

    add-int/2addr v1, v7

    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object v5, v0, Lc/g1;->F:Lc/o0;

    iget v5, v5, Lc/o0;->h:I

    iget v6, p1, Lc/r0;->f:I

    sub-int/2addr v5, v6

    iget v6, p1, Lc/r0;->d:I

    add-int/2addr v6, v8

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {p1, v1, v4}, Lc/r0;->a(II)Lc/r0;

    move-result-object p1

    iput-object p1, v0, Lc/g1;->E:Lc/r0;

    iput-boolean v2, v0, Lc/g1;->K:Z

    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v1, p1}, Lc/u0;->a(Lc/r0;)Z

    move-result p1

    if-eqz p1, :cond_1b

    iget-object p1, v0, Lc/g1;->C:Lc/u0;

    iget-object v1, v0, Lc/g1;->E:Lc/r0;

    invoke-virtual {p1, v1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v3

    :cond_1b
    iput-object v3, v0, Lc/g1;->D:Lc/u0;

    invoke-virtual {v0, v2}, Lc/g1;->m(Z)V

    goto/16 :goto_e

    :cond_1c
    iget-object v1, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v1}, Lc/s0;->a()I

    move-result v1

    iget v6, p1, Lc/r0;->e:I

    iget-object v9, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v9, v9, Lc/o0;->f:Z

    if-eqz v9, :cond_1d

    goto :goto_b

    :cond_1d
    move v4, v7

    :goto_b
    add-int/2addr v6, v4

    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object v4, v0, Lc/g1;->H:Lc/s0;

    invoke-virtual {v4}, Lc/s0;->b()I

    move-result v4

    iget-object v6, v0, Lc/g1;->F:Lc/o0;

    iget v6, v6, Lc/o0;->h:I

    iget v7, p1, Lc/r0;->f:I

    add-int/2addr v7, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {p1, v1, v4}, Lc/r0;->c(II)Lc/r0;

    move-result-object p1

    iget v6, p1, Lc/r0;->c:I

    add-int/2addr v6, v1

    if-gt v6, v5, :cond_27

    iget v1, p1, Lc/r0;->d:I

    add-int/2addr v1, v4

    iget-object v4, v0, Lc/g1;->F:Lc/o0;

    iget v4, v4, Lc/o0;->h:I

    if-gt v1, v4, :cond_27

    invoke-virtual {v0, p1}, Lc/g1;->e(Lc/r0;)Z

    move-result v1

    if-nez v1, :cond_1e

    goto/16 :goto_e

    :cond_1e
    iput-object p1, v0, Lc/g1;->E:Lc/r0;

    iput-boolean v2, v0, Lc/g1;->K:Z

    iget-object v1, v0, Lc/g1;->F:Lc/o0;

    iget-boolean v1, v1, Lc/o0;->f:Z

    if-eqz v1, :cond_1f

    iget-object v1, v0, Lc/g1;->A:Landroid/graphics/RectF;

    iget v4, v1, Landroid/graphics/RectF;->top:F

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v5

    invoke-static {p1, v5}, Lc/G8;->U(Lc/r0;F)F

    move-result v5

    add-float/2addr v5, v4

    iput v5, v1, Landroid/graphics/RectF;->bottom:F

    :cond_1f
    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v1, p1}, Lc/u0;->a(Lc/r0;)Z

    move-result v1

    if-eqz v1, :cond_20

    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-virtual {v1, p1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v3

    :cond_20
    iput-object v3, v0, Lc/g1;->D:Lc/u0;

    invoke-virtual {v0, v2}, Lc/g1;->m(Z)V

    goto :goto_e

    :cond_21
    :goto_c
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-ne p1, v2, :cond_27

    if-nez v5, :cond_22

    goto :goto_d

    :cond_22
    iget p1, v0, Lc/g1;->N:I

    if-ne p1, v2, :cond_23

    iget-object p1, v0, Lc/g1;->F:Lc/o0;

    iget-boolean p1, p1, Lc/o0;->f:Z

    if-eqz p1, :cond_23

    iget-object v3, v0, Lc/g1;->D:Lc/u0;

    goto :goto_d

    :cond_23
    iget-object p1, v0, Lc/g1;->E:Lc/r0;

    if-eqz p1, :cond_24

    iget-object v1, v0, Lc/g1;->C:Lc/u0;

    invoke-static {v1, p1}, Lc/G8;->r0(Lc/u0;Lc/r0;)Lc/u0;

    move-result-object v3

    :cond_24
    :goto_d
    if-eqz v5, :cond_25

    iget-object p1, v0, Lc/g1;->E:Lc/r0;

    if-eqz p1, :cond_25

    if-nez v3, :cond_25

    iget-object p1, v0, Lc/g1;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const-string v5, "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043c\u0435\u0441\u0442\u0430"

    invoke-static {p1, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :cond_25
    invoke-virtual {v0}, Lc/g1;->r()V

    if-eqz v3, :cond_26

    invoke-virtual {v0, v3, v4}, Lc/g1;->t(Lc/u0;Z)V

    :cond_26
    invoke-virtual {v0, v2}, Lc/g1;->m(Z)V

    :cond_27
    :goto_e
    return v2
.end method

.method public final e0(II)V
    .locals 2

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-class v1, Landroid/view/accessibility/AccessibilityManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/accessibility/AccessibilityManager;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p2}, Landroid/view/accessibility/AccessibilityEvent;->obtain(I)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityEvent;->setPackageName(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p0, p1}, Landroid/view/accessibility/AccessibilityRecord;->setSource(Landroid/view/View;I)V

    :try_start_0
    invoke-virtual {p0, v0}, Landroid/view/View;->sendAccessibilityEventUnchecked(Landroid/view/accessibility/AccessibilityEvent;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const-string p2, "type"

    filled-new-array {p2, p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string p2, "accessibility_event_rejected"

    invoke-static {p2, p1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final f0(Z)V
    .locals 7

    iget-boolean v0, p0, Lc/P3;->T1:Z

    if-ne p1, v0, :cond_1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-boolean p1, p0, Lc/P3;->U1:Z

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lc/P3;->i0()V

    :cond_0
    return-void

    :cond_1
    iput-boolean p1, p0, Lc/P3;->T1:Z

    if-nez p1, :cond_e

    iget-object p1, p0, Lc/P3;->i:Lc/S;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lc/S;->b(Z)V

    iget-object p1, p0, Lc/P3;->N1:Lc/g5;

    invoke-virtual {p1}, Lc/g5;->b()V

    iget-object p1, p0, Lc/P3;->u0:Ljava/util/EnumMap;

    invoke-virtual {p1}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/q9;

    iget-object v3, v1, Lc/q9;->k:Landroid/graphics/Bitmap;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    :cond_2
    iput-object v2, v1, Lc/q9;->k:Landroid/graphics/Bitmap;

    iput-object v2, v1, Lc/q9;->l:[F

    iput-object v2, v1, Lc/q9;->m:Lc/W3;

    const/4 v2, 0x1

    iput-boolean v2, v1, Lc/q9;->u:Z

    iput-boolean v0, v1, Lc/q9;->v:Z

    iput-boolean v0, v1, Lc/q9;->y:Z

    goto :goto_0

    :cond_3
    iget-object p1, p0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {p1}, Lc/U4;->c()V

    iput-boolean v0, p0, Lc/P3;->y0:Z

    iput-boolean v0, p0, Lc/P3;->x0:Z

    iput-boolean v0, p0, Lc/P3;->w0:Z

    const/high16 p1, 0x3f800000    # 1.0f

    iput p1, p0, Lc/P3;->A0:F

    iget-object p1, p0, Lc/P3;->b1:Lc/E8;

    if-eqz p1, :cond_4

    invoke-virtual {p1}, Lc/E8;->c()V

    :cond_4
    iget-object p1, p0, Lc/P3;->n:Lc/G0;

    invoke-virtual {p1, p0, v0}, Lc/G0;->k(Ljava/lang/Object;Z)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object p1

    iget-object v1, p0, Lc/P3;->p:Ljava/lang/Object;

    invoke-virtual {p1, v1}, Lc/T5;->n0(Ljava/lang/Object;)V

    const-string p1, ""

    iput-object p1, p0, Lc/P3;->q:Ljava/lang/String;

    invoke-virtual {p0}, Lc/P3;->p()V

    iget-boolean p1, p0, Lc/P3;->U1:Z

    if-nez p1, :cond_5

    goto/16 :goto_3

    :cond_5
    iput-boolean v0, p0, Lc/P3;->U1:Z

    const/4 p1, -0x1

    iput p1, p0, Lc/P3;->V1:I

    iget-object v1, p0, Lc/P3;->W0:Landroid/os/Handler;

    iget-object v3, p0, Lc/P3;->n1:Lc/F3;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v0, p0, Lc/P3;->m1:Z

    sget-object v3, Lru/drivedeck/launcher/NotificationBridgeService;->a:Ljava/util/concurrent/CopyOnWriteArraySet;

    iget-object v4, p0, Lc/P3;->k0:Lc/F3;

    invoke-virtual {v3, v4}, Ljava/util/concurrent/CopyOnWriteArraySet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v3

    iget-object v3, v3, Lc/T5;->B1:Ljava/util/HashSet;

    iget-object v4, p0, Lc/P3;->z:Lc/F3;

    invoke-virtual {v3, v4}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget-object v3, p0, Lc/P3;->y:Lc/F3;

    invoke-virtual {p0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v0, p0, Lc/P3;->w:Z

    iget-object v3, p0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {p0, v3}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {p0}, Lc/P3;->k()V

    iget-object v3, p0, Lc/P3;->t1:Lc/g0;

    iget-object v4, v3, Lc/g0;->t:Lc/j;

    if-eqz v4, :cond_6

    invoke-virtual {v4}, Lc/j;->dismiss()V

    iput-object v2, v3, Lc/g0;->t:Lc/j;

    :cond_6
    iput p1, v3, Lc/g0;->l:I

    iput p1, v3, Lc/g0;->k:I

    iput p1, v3, Lc/g0;->j:I

    iget-object v3, p0, Lc/P3;->P1:Landroid/app/Dialog;

    if-eqz v3, :cond_7

    invoke-virtual {v3}, Landroid/app/Dialog;->dismiss()V

    iput-object v2, p0, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_7
    iget-boolean v3, p0, Lc/P3;->j1:Z

    if-eqz v3, :cond_8

    iget-object v3, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    iget-object v4, p0, Lc/P3;->l1:Lc/L;

    invoke-virtual {v3, v4}, Landroid/media/session/MediaSessionManager;->removeOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;)V

    :cond_8
    iput-boolean v0, p0, Lc/P3;->j1:Z

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v3

    invoke-virtual {p0, v3}, Lc/P3;->S(Ljava/util/List;)V

    iput-boolean v0, p0, Lc/P3;->k1:Z

    iput-object v2, p0, Lc/P3;->w1:Landroid/media/session/MediaController;

    iget-object v3, p0, Lc/P3;->Y0:Lc/e1;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lc/P3;->X0:Lc/o5;

    iget-object v3, v1, Lc/o5;->b:Landroid/net/ConnectivityManager;

    if-eqz v3, :cond_a

    iget-boolean v4, v1, Lc/o5;->c:Z

    if-nez v4, :cond_9

    goto :goto_1

    :cond_9
    :try_start_0
    iget-object v4, v1, Lc/o5;->f:Lc/n5;

    invoke-virtual {v3, v4}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iput-boolean v0, v1, Lc/o5;->c:Z

    iput-boolean v0, v1, Lc/o5;->d:Z

    :cond_a
    :goto_1
    iget-object v1, p0, Lc/P3;->z1:Lc/x7;

    iget-boolean v3, v1, Lc/x7;->c:Z

    if-eqz v3, :cond_b

    iget-object v3, v1, Lc/x7;->h:Lc/w7;

    iget-object v4, v1, Lc/x7;->a:Landroid/content/Context;

    invoke-virtual {v4, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    :cond_b
    iput-boolean v0, v1, Lc/x7;->c:Z

    iput-boolean v0, v1, Lc/x7;->e:Z

    iput-object v2, v1, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    iput p1, v1, Lc/x7;->g:I

    iput p1, v1, Lc/x7;->f:I

    iget-object v1, p0, Lc/P3;->y1:Lc/P;

    invoke-virtual {v1}, Lc/P;->d()V

    iget-object v1, p0, Lc/P3;->u1:Lc/g8;

    invoke-virtual {v1}, Lc/g8;->c()V

    iget-object v1, p0, Lc/P3;->v1:Lc/o1;

    invoke-virtual {v1}, Lc/o1;->c()V

    iget-object v1, p0, Lc/P3;->S0:Lc/y8;

    invoke-virtual {v1}, Lc/y8;->g()V

    iget-object v1, p0, Lc/P3;->T0:Lc/z8;

    iput-object v2, v1, Lc/z8;->b:Landroid/os/IBinder;

    iget-boolean v3, v1, Lc/z8;->c:Z

    if-nez v3, :cond_c

    goto :goto_2

    :cond_c
    iput-boolean v0, v1, Lc/z8;->c:Z

    :try_start_1
    iget-object v3, v1, Lc/z8;->a:Landroid/content/Context;

    invoke-virtual {v3, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :goto_2
    iget-object v1, p0, Lc/P3;->A1:Lc/r3;

    iput-boolean v0, v1, Lc/r3;->g:Z

    iget-wide v3, v1, Lc/r3;->f:J

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    iput-wide v3, v1, Lc/r3;->f:J

    iget-object v3, v1, Lc/r3;->d:Landroid/os/Handler;

    invoke-virtual {v3, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v3, v1, Lc/r3;->i:Lc/q3;

    iput-object v2, v1, Lc/r3;->i:Lc/q3;

    iget-object v4, v1, Lc/r3;->b:Landroid/location/LocationManager;

    if-eqz v4, :cond_d

    iget-boolean v5, v1, Lc/r3;->h:Z

    if-eqz v5, :cond_d

    if-eqz v3, :cond_d

    invoke-virtual {v4, v3}, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V

    :cond_d
    iput-boolean v0, v1, Lc/r3;->h:Z

    iput-object v2, v1, Lc/r3;->j:Landroid/location/Location;

    iput p1, v1, Lc/r3;->k:I

    goto :goto_3

    :cond_e
    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p1

    if-eqz p1, :cond_f

    invoke-virtual {p0}, Lc/P3;->i0()V

    :cond_f
    :goto_3
    return-void
.end method

.method public final g(ILandroid/graphics/RectF;)V
    .locals 6

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    const/16 v0, 0x64

    if-lt p1, v0, :cond_1

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v1, v1

    add-int/2addr v1, v0

    if-ge p1, v1, :cond_1

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    sub-int/2addr p1, v0

    aget-object p1, v1, p1

    iget-object v0, p0, Lc/P3;->f:Lc/o0;

    if-nez v0, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/m0;

    :goto_0
    if-eqz p1, :cond_1b

    iget v0, p0, Lc/P3;->D:F

    iget v1, p1, Lc/m0;->b:F

    sub-float/2addr v1, v0

    iget v2, p1, Lc/m0;->d:F

    sub-float/2addr v2, v0

    iget v0, p1, Lc/m0;->a:F

    iget p1, p1, Lc/m0;->c:F

    invoke-virtual {p2, v0, v1, p1, v2}, Landroid/graphics/RectF;->set(FFFF)V

    goto/16 :goto_3

    :cond_1
    const/16 v0, 0x3e8

    if-lt p1, v0, :cond_2

    iget-object v1, p0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/2addr v2, v0

    if-ge p1, v2, :cond_2

    sub-int/2addr p1, v0

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_2
    const/16 v0, 0x7d0

    if-lt p1, v0, :cond_7

    const/16 v1, 0x7d5

    if-ge p1, v1, :cond_7

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    if-ne p1, v0, :cond_3

    iget-object p1, p0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v1, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_3
    const/16 v0, 0x7d1

    if-ne p1, v0, :cond_4

    iget-object p1, p0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v1, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_4
    const/16 v0, 0x7d2

    if-ne p1, v0, :cond_5

    iget-object p1, p0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v1, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_5
    const/16 v0, 0x7d3

    if-ne p1, v0, :cond_6

    iget-object p1, p0, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v1, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1

    :cond_6
    iget-object p1, p0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual {v1, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :goto_1
    invoke-virtual {p2, v1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_7
    const/16 v0, 0xbb8

    if-lt p1, v0, :cond_8

    iget-object v1, p0, Lc/P3;->t1:Lc/g0;

    iget-object v2, v1, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    add-int/2addr v2, v0

    if-ge p1, v2, :cond_8

    sub-int/2addr p1, v0

    invoke-virtual {v1, p1}, Lc/g0;->a(I)Landroid/graphics/RectF;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_8
    sget-object v0, Lc/s0;->l:Lc/s0;

    const/16 v1, 0x1389

    iget-object v2, p0, Lc/P3;->A:Lc/g1;

    if-ne p1, v1, :cond_9

    iget-boolean p1, v2, Lc/g1;->J:Z

    if-nez p1, :cond_1b

    iget-object p1, p0, Lc/P3;->f:Lc/o0;

    if-eqz p1, :cond_1b

    iget-object p1, p1, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {p1, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_1b

    iget-object p1, p0, Lc/P3;->n:Lc/G0;

    iget-object p1, p1, Lc/G0;->k:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_9
    const/16 v1, 0x1388

    if-ne p1, v1, :cond_a

    iget-boolean p1, v2, Lc/g1;->J:Z

    if-nez p1, :cond_1b

    iget-object p1, p0, Lc/P3;->L0:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_a
    const/16 v1, 0x1770

    if-lt p1, v1, :cond_d

    const/16 v1, 0x1779

    if-ge p1, v1, :cond_d

    iget-boolean v0, v2, Lc/g1;->J:Z

    if-nez v0, :cond_1b

    add-int/lit16 v0, p1, -0x1770

    const/4 v1, 0x4

    iget-object v2, p0, Lc/P3;->M0:[Landroid/graphics/RectF;

    if-ge v0, v1, :cond_b

    aget-object p1, v2, v0

    goto :goto_2

    :cond_b
    const/4 v1, 0x7

    if-lt v0, v1, :cond_c

    add-int/lit16 p1, p1, -0x1772

    aget-object p1, v2, p1

    goto :goto_2

    :cond_c
    add-int/lit16 p1, p1, -0x1774

    iget-object v0, p0, Lc/P3;->N0:[Landroid/graphics/RectF;

    aget-object p1, v0, p1

    :goto_2
    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_d
    const/16 v1, 0xfa0

    if-lt p1, v1, :cond_1b

    const/16 v1, 0x1004

    if-ge p1, v1, :cond_1b

    add-int/lit16 v1, p1, -0xfa0

    iget-boolean v3, v2, Lc/g1;->J:Z

    if-nez v3, :cond_e

    return-void

    :cond_e
    if-nez v1, :cond_f

    iget-object p1, v2, Lc/g1;->w:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_f
    const/4 v3, 0x1

    if-ne v1, v3, :cond_10

    iget-object p1, v2, Lc/g1;->x:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_10
    const/16 v4, 0x5a

    if-ne v1, v4, :cond_11

    iget-object p1, v2, Lc/g1;->y:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_11
    const/16 v4, 0x32

    if-lt v1, v4, :cond_12

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    array-length v5, v5

    add-int/2addr v5, v4

    if-ge v1, v5, :cond_12

    iget-object v0, v2, Lc/g1;->n:Ljava/util/EnumMap;

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    add-int/lit16 p1, p1, -0xfd2

    aget-object p1, v1, p1

    invoke-virtual {v0, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    if-eqz p1, :cond_1b

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_12
    add-int/lit16 p1, p1, -0xfa2

    div-int/lit8 v1, p1, 0x3

    rem-int/lit8 p1, p1, 0x3

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v4

    if-ltz v1, :cond_1b

    array-length v5, v4

    if-ge v1, v5, :cond_1b

    aget-object v1, v4, v1

    if-nez p1, :cond_13

    iget-object v4, v2, Lc/g1;->p:Ljava/util/EnumMap;

    invoke-virtual {v4, v1}, Ljava/util/EnumMap;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_13

    invoke-virtual {v4, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_13
    if-ne p1, v3, :cond_14

    iget-object v3, v2, Lc/g1;->o:Ljava/util/EnumMap;

    invoke-virtual {v3, v1}, Ljava/util/EnumMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    invoke-virtual {v3, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_3

    :cond_14
    const/4 v3, 0x2

    if-ne p1, v3, :cond_15

    sget-object v4, Lc/s0;->b:Lc/s0;

    if-ne v1, v4, :cond_15

    iget-object p1, v2, Lc/g1;->r:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_15
    if-ne p1, v3, :cond_16

    sget-object v4, Lc/s0;->c:Lc/s0;

    if-ne v1, v4, :cond_16

    iget-object p1, v2, Lc/g1;->s:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_16
    if-ne p1, v3, :cond_17

    sget-object v4, Lc/s0;->g:Lc/s0;

    if-ne v1, v4, :cond_17

    iget-object p1, v2, Lc/g1;->t:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_17
    if-ne p1, v3, :cond_18

    sget-object v4, Lc/s0;->i:Lc/s0;

    if-ne v1, v4, :cond_18

    iget-object p1, v2, Lc/g1;->u:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_18
    if-ne p1, v3, :cond_19

    sget-object v4, Lc/s0;->d:Lc/s0;

    if-ne v1, v4, :cond_19

    iget-object p1, v2, Lc/g1;->v:Landroid/graphics/RectF;

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_19
    if-ne p1, v3, :cond_1b

    sget-object p1, Lc/s0;->m:Lc/s0;

    if-eq v1, p1, :cond_1a

    sget-object p1, Lc/s0;->k:Lc/s0;

    if-eq v1, p1, :cond_1a

    sget-object p1, Lc/s0;->h:Lc/s0;

    if-eq v1, p1, :cond_1a

    if-eq v1, v0, :cond_1a

    sget-object p1, Lc/s0;->e:Lc/s0;

    if-eq v1, p1, :cond_1a

    sget-object p1, Lc/s0;->f:Lc/s0;

    if-ne v1, p1, :cond_1b

    :cond_1a
    iget-object p1, v2, Lc/g1;->q:Ljava/util/EnumMap;

    invoke-virtual {p1, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    if-eqz p1, :cond_1b

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_1b
    :goto_3
    return-void
.end method

.method public final g0(Lc/u0;Lc/o0;Lc/m0;)V
    .locals 1

    iput-object p3, p0, Lc/P3;->J:Lc/m0;

    iget-object p3, p0, Lc/P3;->e:Lc/u0;

    if-eq p3, p1, :cond_0

    const/4 p3, 0x1

    goto :goto_0

    :cond_0
    const/4 p3, 0x0

    :goto_0
    iput-object p1, p0, Lc/P3;->e:Lc/u0;

    iput-object p2, p0, Lc/P3;->f:Lc/o0;

    if-eqz p3, :cond_1

    invoke-virtual {p0}, Lc/P3;->N()V

    :cond_1
    iget p3, p0, Lc/P3;->D:F

    invoke-virtual {p2}, Lc/o0;->c()F

    move-result v0

    invoke-static {p3, v0}, Ljava/lang/Math;->min(FF)F

    move-result p3

    const/4 v0, 0x0

    invoke-static {v0, p3}, Ljava/lang/Math;->max(FF)F

    move-result p3

    iput p3, p0, Lc/P3;->D:F

    iget-boolean p3, p0, Lc/P3;->d:Z

    iget-object v0, p0, Lc/P3;->A:Lc/g1;

    iput-object p1, v0, Lc/g1;->C:Lc/u0;

    iput-object p2, v0, Lc/g1;->F:Lc/o0;

    iput-boolean p3, v0, Lc/g1;->I:Z

    iget-object p1, v0, Lc/g1;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    iget-object p3, v0, Lc/g1;->b:Lc/n1;

    invoke-static {p1, p3}, Lc/e0;->o(Landroid/content/Context;Lc/n1;)Landroid/graphics/Rect;

    move-result-object p1

    iput-object p1, v0, Lc/g1;->G:Landroid/graphics/Rect;

    invoke-virtual {v0}, Lc/g1;->r()V

    invoke-virtual {v0}, Lc/g1;->z()V

    iget-boolean p1, v0, Lc/g1;->J:Z

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Lc/g1;->o()V

    :cond_2
    sget-object p1, Lc/s0;->l:Lc/s0;

    iget-object p2, p2, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {p2, p1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/m0;

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/high16 p3, 0x3f800000    # 1.0f

    invoke-virtual {p0, p3}, Lc/P3;->s(F)F

    move-result p3

    iget-object v0, p0, Lc/P3;->C1:Lc/n1;

    invoke-static {p2, v0, p1, p3}, Lc/G0;->g(Landroid/content/Context;Lc/n1;Lc/m0;F)Z

    move-result p1

    if-nez p1, :cond_3

    new-instance p1, Lc/F3;

    const/16 p2, 0xb

    invoke-direct {p1, p0, p2}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-virtual {p0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_3
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final getAccessibilityNodeProvider()Landroid/view/accessibility/AccessibilityNodeProvider;
    .locals 1

    iget-object v0, p0, Lc/P3;->E1:Lc/O3;

    return-object v0
.end method

.method public final h(I)Z
    .locals 14

    iget-object v0, p0, Lc/P3;->t1:Lc/g0;

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    :cond_0
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {p0, p1, v1}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    return v2

    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v12

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v9

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v10

    const/4 v11, 0x0

    const/4 v8, 0x0

    move-wide v4, v12

    move-wide v6, v12

    invoke-static/range {v4 .. v11}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v3

    const-wide/16 v4, 0x1

    add-long v6, v12, v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v9

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v10

    const/4 v8, 0x1

    move-wide v4, v12

    invoke-static/range {v4 .. v11}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v1

    const/16 v4, 0x1389

    const/4 v5, 0x1

    if-ne p1, v4, :cond_2

    :try_start_0
    iget-object p1, p0, Lc/P3;->n:Lc/G0;

    invoke-virtual {p1}, Lc/G0;->l()V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    invoke-virtual {v3}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    return v5

    :catchall_0
    move-exception p1

    goto/16 :goto_5

    :cond_2
    const/16 v4, 0x1388

    if-ne p1, v4, :cond_3

    :try_start_1
    invoke-virtual {p0}, Lc/P3;->Z()V

    goto :goto_0

    :cond_3
    const/16 v4, 0x1770

    if-lt p1, v4, :cond_8

    const/16 v4, 0x1779

    if-ge p1, v4, :cond_8

    const/16 v0, 0x1777

    const/16 v2, 0x1774

    if-ge p1, v2, :cond_4

    add-int/lit16 v4, p1, -0x1770

    goto :goto_1

    :cond_4
    if-lt p1, v0, :cond_5

    add-int/lit16 v4, p1, -0x1772

    goto :goto_1

    :cond_5
    const/4 v4, 0x4

    :goto_1
    if-lt p1, v2, :cond_7

    if-lt p1, v0, :cond_6

    goto :goto_2

    :cond_6
    sub-int/2addr p1, v2

    goto :goto_3

    :cond_7
    :goto_2
    const/4 p1, -0x1

    :goto_3
    invoke-virtual {p0, v4, p1}, Lc/P3;->U(II)V

    goto :goto_0

    :cond_8
    const/16 v4, 0xbb8

    if-lt p1, v4, :cond_a

    iget-object v6, v0, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    add-int/2addr v6, v4

    if-ge p1, v6, :cond_a

    sub-int/2addr p1, v4

    invoke-virtual {v0, p1}, Lc/g0;->a(I)Landroid/graphics/RectF;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_9

    goto :goto_4

    :cond_9
    invoke-virtual {p1}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result p1

    invoke-virtual {v0, v2, v4, v5, p1}, Lc/g0;->i(FFFF)Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_4
    invoke-virtual {v3}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    return v2

    :cond_a
    :try_start_2
    invoke-virtual {p0, v3}, Lc/P3;->onTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {p0, v1}, Lc/P3;->onTouchEvent(Landroid/view/MotionEvent;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {v3}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    return v5

    :goto_5
    invoke-virtual {v3}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {v1}, Landroid/view/MotionEvent;->recycle()V

    throw p1
.end method

.method public final h0()V
    .locals 17

    move-object/from16 v1, p0

    const/4 v0, 0x2

    const/4 v3, 0x1

    iget-object v4, v1, Lc/P3;->K:Lc/a5;

    if-eqz v4, :cond_0

    return-void

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    instance-of v4, v4, Landroid/view/ViewGroup;

    if-eqz v4, :cond_e

    iget-object v4, v1, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v4}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_1

    goto/16 :goto_9

    :cond_1
    new-instance v10, Landroid/graphics/RectF;

    iget-object v5, v1, Lc/P3;->L:Landroid/graphics/RectF;

    invoke-direct {v10, v5}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    invoke-virtual {v10}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v5

    const/high16 v14, 0x41800000    # 16.0f

    if-eqz v5, :cond_2

    iget v5, v4, Landroid/graphics/RectF;->left:F

    invoke-virtual {v1, v14}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v5

    iget v5, v4, Landroid/graphics/RectF;->top:F

    invoke-virtual {v1, v14}, Lc/P3;->s(F)F

    move-result v7

    add-float/2addr v7, v5

    iget v5, v4, Landroid/graphics/RectF;->left:F

    const/high16 v8, 0x42400000    # 48.0f

    invoke-virtual {v1, v8}, Lc/P3;->s(F)F

    move-result v9

    add-float/2addr v9, v5

    iget v5, v4, Landroid/graphics/RectF;->top:F

    invoke-virtual {v1, v8}, Lc/P3;->s(F)F

    move-result v8

    add-float/2addr v8, v5

    invoke-virtual {v10, v6, v7, v9, v8}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    move-object v15, v5

    check-cast v15, Landroid/view/ViewGroup;

    new-instance v13, Lc/a5;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    new-instance v9, Lc/M3;

    invoke-direct {v9, v1}, Lc/M3;-><init>(Lc/P3;)V

    invoke-virtual {v15}, Landroid/view/View;->getWidth()I

    move-result v12

    invoke-virtual {v15}, Landroid/view/View;->getHeight()I

    move-result v16

    iget-object v7, v1, Lc/P3;->a0:Lc/z;

    iget-object v8, v1, Lc/P3;->C1:Lc/n1;

    move-object v5, v13

    move-object v11, v4

    move-object v2, v13

    move/from16 v13, v16

    invoke-direct/range {v5 .. v13}, Lc/a5;-><init>(Landroid/content/Context;Lc/z;Lc/n1;Lc/M3;Landroid/graphics/RectF;Landroid/graphics/RectF;II)V

    iget-boolean v5, v1, Lc/P3;->L1:Z

    const/4 v6, 0x0

    if-eqz v5, :cond_6

    invoke-virtual {v4}, Landroid/graphics/RectF;->width()F

    move-result v5

    const/high16 v7, 0x44160000    # 600.0f

    invoke-virtual {v1, v7}, Lc/P3;->s(F)F

    move-result v7

    cmpl-float v5, v5, v7

    const/4 v7, 0x0

    if-ltz v5, :cond_3

    invoke-virtual {v4}, Landroid/graphics/RectF;->width()F

    move-result v5

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v4

    const v8, 0x3f933333    # 1.15f

    mul-float/2addr v4, v8

    cmpl-float v4, v5, v4

    if-lez v4, :cond_3

    move v4, v7

    goto :goto_0

    :cond_3
    iget-object v4, v1, Lc/P3;->J0:Landroid/graphics/RectF;

    iget v4, v4, Landroid/graphics/RectF;->top:F

    :goto_0
    iput-boolean v3, v2, Lc/a5;->v:Z

    iget v5, v2, Lc/a5;->u:I

    cmpl-float v8, v4, v7

    iget v9, v2, Lc/a5;->q:I

    if-lez v8, :cond_4

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    const/high16 v10, 0x41c00000    # 24.0f

    invoke-static {v8, v10}, Lc/G8;->a(Landroid/content/Context;F)I

    move-result v8

    add-int/2addr v8, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    sub-int v4, v9, v4

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const/high16 v10, 0x41400000    # 12.0f

    invoke-static {v5, v10}, Lc/G8;->a(Landroid/content/Context;F)I

    move-result v5

    add-int/2addr v5, v4

    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    :cond_4
    invoke-static {v9, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    iput v4, v2, Lc/a5;->u:I

    const/4 v4, 0x0

    :goto_1
    iget-object v5, v2, Lc/a5;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    if-ge v4, v8, :cond_5

    invoke-virtual {v5, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    iget v8, v2, Lc/a5;->u:I

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-static {v10, v14}, Lc/G8;->a(Landroid/content/Context;F)I

    move-result v10

    sub-int/2addr v8, v10

    iput v8, v5, Landroid/view/ViewGroup$LayoutParams;->height:I

    add-int/2addr v4, v3

    goto :goto_1

    :cond_5
    iget-object v4, v2, Lc/a5;->n:Landroid/graphics/RectF;

    iget v5, v2, Lc/a5;->u:I

    sub-int v5, v9, v5

    const/4 v8, 0x0

    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-float v5, v5

    iget v10, v2, Lc/a5;->p:I

    int-to-float v10, v10

    int-to-float v9, v9

    invoke-virtual {v4, v7, v5, v10, v9}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v2}, Lc/a5;->f()V

    invoke-virtual {v2, v8}, Landroid/view/View;->setClipToOutline(Z)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    :cond_6
    iget-object v4, v2, Lc/a5;->d:Lc/r4;

    :try_start_0
    iget v5, v2, Lc/a5;->y:I

    iget v7, v2, Lc/a5;->u:I

    invoke-static {v5, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-float v5, v5

    const/high16 v7, 0x43a00000    # 320.0f

    div-float/2addr v7, v5

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-static {v5, v7}, Ljava/lang/Math;->min(FF)F

    move-result v5

    iget v7, v2, Lc/a5;->y:I

    int-to-float v7, v7

    mul-float/2addr v7, v5

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-static {v3, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget v8, v2, Lc/a5;->u:I

    int-to-float v8, v8

    mul-float/2addr v8, v5

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    invoke-static {v3, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    sget-object v9, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v7, v8, v9}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v7
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    new-instance v8, Landroid/graphics/Canvas;

    invoke-direct {v8, v7}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    iget v9, v4, Lc/r4;->a:I

    invoke-virtual {v8, v9}, Landroid/graphics/Canvas;->drawColor(I)V

    invoke-virtual {v8, v5, v5}, Landroid/graphics/Canvas;->scale(FF)V

    iget v5, v2, Lc/a5;->w:I

    neg-int v5, v5

    int-to-float v5, v5

    iget v9, v2, Lc/a5;->x:I

    neg-int v9, v9

    int-to-float v9, v9

    invoke-virtual {v8, v5, v9}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v1, v8}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    const/4 v5, 0x3

    invoke-static {v7, v5, v0}, Lc/X3;->b(Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;

    move-result-object v5

    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v9, v4, Lc/r4;->b:I

    const v10, 0xffffff

    and-int/2addr v9, v10

    iget-boolean v10, v2, Lc/a5;->v:Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iget-boolean v4, v4, Lc/r4;->m:Z

    if-eqz v10, :cond_8

    if-eqz v4, :cond_7

    const/16 v4, 0x88

    goto :goto_2

    :cond_7
    const/16 v4, 0x9c

    goto :goto_2

    :cond_8
    if-eqz v4, :cond_9

    const/16 v4, 0xa0

    goto :goto_2

    :cond_9
    const/16 v4, 0xb8

    :goto_2
    shl-int/lit8 v4, v4, 0x18

    or-int/2addr v4, v9

    :try_start_2
    invoke-virtual {v8, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    new-instance v4, Landroid/graphics/drawable/LayerDrawable;

    new-instance v9, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    invoke-direct {v9, v10, v5}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    new-array v0, v0, [Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x0

    aput-object v9, v0, v5

    aput-object v8, v0, v3

    invoke-direct {v4, v0}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    iget-boolean v0, v2, Lc/a5;->v:Z

    if-eqz v0, :cond_a

    const/16 v0, 0xeb

    invoke-virtual {v4, v0}, Landroid/graphics/drawable/LayerDrawable;->setAlpha(I)V

    goto :goto_3

    :catchall_0
    move-exception v0

    move-object v6, v7

    goto :goto_8

    :catch_0
    move-exception v0

    goto :goto_6

    :catch_1
    move-exception v0

    goto :goto_6

    :cond_a
    :goto_3
    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/Z1;

    invoke-direct {v0, v2, v3}, Lc/Z1;-><init>(Landroid/view/View;I)V

    invoke-virtual {v2, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_4
    invoke-virtual {v7}, Landroid/graphics/Bitmap;->recycle()V

    goto :goto_7

    :catchall_1
    move-exception v0

    goto :goto_8

    :catch_2
    move-exception v0

    :goto_5
    move-object v7, v6

    goto :goto_6

    :catch_3
    move-exception v0

    goto :goto_5

    :goto_6
    :try_start_3
    const-string v3, "DriveDeckMedia"

    const-string v4, "Cannot prepare source backdrop"

    invoke-static {v3, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-eqz v7, :cond_b

    goto :goto_4

    :cond_b
    :goto_7
    iget-boolean v0, v1, Lc/P3;->L1:Z

    if-eqz v0, :cond_c

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/View;->setClipToOutline(Z)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    :cond_c
    iput-object v2, v1, Lc/P3;->K:Lc/a5;

    invoke-virtual {v15, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v0, v1, Lc/P3;->K:Lc/a5;

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return-void

    :goto_8
    if-eqz v6, :cond_d

    invoke-virtual {v6}, Landroid/graphics/Bitmap;->recycle()V

    :cond_d
    throw v0

    :cond_e
    :goto_9
    return-void
.end method

.method public final i(I)Z
    .locals 3

    iget-boolean v0, p0, Lc/P3;->L1:Z

    const/4 v1, 0x0

    if-nez v0, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_3

    const/16 v0, 0x64

    if-lt p1, v0, :cond_3

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v2

    array-length v2, v2

    add-int/2addr v2, v0

    if-lt p1, v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    add-int/lit8 v2, p1, -0x64

    aget-object v0, v0, v2

    sget-object v2, Lc/s0;->i:Lc/s0;

    if-eq v0, v2, :cond_3

    sget-object v2, Lc/s0;->m:Lc/s0;

    if-ne v0, v2, :cond_1

    goto :goto_0

    :cond_1
    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    invoke-virtual {p0, p1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_3

    iget-object p1, p0, Lc/P3;->B:Lc/U0;

    if-nez p1, :cond_2

    goto :goto_0

    :cond_2
    iput-boolean v1, p0, Lc/P3;->z0:Z

    iput-object v0, p0, Lc/P3;->O1:Lc/s0;

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result p1

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    iget-object v2, p0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v2, v0, p1, v1}, Lc/g1;->a(Lc/s0;FF)V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    iget-boolean p1, v2, Lc/g1;->J:Z

    return p1

    :cond_3
    :goto_0
    return v1
.end method

.method public final i0()V
    .locals 7

    iget-boolean v0, p0, Lc/P3;->U1:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/P3;->U1:Z

    sget-object v1, Lru/drivedeck/launcher/NotificationBridgeService;->a:Ljava/util/concurrent/CopyOnWriteArraySet;

    iget-object v2, p0, Lc/P3;->k0:Lc/F3;

    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v1

    iget-object v1, v1, Lc/T5;->B1:Ljava/util/HashSet;

    iget-object v2, p0, Lc/P3;->z:Lc/F3;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lc/P3;->n:Lc/G0;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/G0;->j(Z)Z

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v3

    if-eqz v3, :cond_1

    iget-boolean v3, v1, Lc/G0;->o:Z

    if-eqz v3, :cond_1

    move v3, v0

    goto :goto_0

    :cond_1
    move v3, v2

    :goto_0
    invoke-virtual {v1, p0, v3}, Lc/G0;->k(Ljava/lang/Object;Z)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v3, Landroid/media/session/MediaSessionManager;

    invoke-virtual {v1, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/MediaSessionManager;

    iput-object v1, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    invoke-virtual {p0}, Lc/P3;->j0()Z

    invoke-virtual {p0}, Lc/P3;->Y()V

    iget-object v1, p0, Lc/P3;->X0:Lc/o5;

    invoke-virtual {v1}, Lc/o5;->a()V

    iget-object v1, p0, Lc/P3;->A1:Lc/r3;

    iget-boolean v3, v1, Lc/r3;->g:Z

    if-nez v3, :cond_2

    iput-boolean v0, v1, Lc/r3;->g:Z

    const/high16 v0, -0x80000000

    iput v0, v1, Lc/r3;->l:I

    iget-wide v3, v1, Lc/r3;->f:J

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    iput-wide v3, v1, Lc/r3;->f:J

    iget-object v0, v1, Lc/r3;->d:Landroid/os/Handler;

    iget-object v1, v1, Lc/r3;->n:Lc/e1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Lc/P3;->o0()Lc/i;

    move-result-object v1

    invoke-static {v0, v1, v2, v2}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    iget-object v0, p0, Lc/P3;->W0:Landroid/os/Handler;

    iget-object v1, p0, Lc/P3;->Y0:Lc/e1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final j()Z
    .locals 7

    iget-object v0, p0, Lc/P3;->c1:Landroid/media/session/MediaController;

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    iget-object v1, p0, Lc/P3;->B:Lc/U0;

    if-eqz v1, :cond_1

    iget-wide v3, v1, Lc/U0;->c:J

    const-wide/16 v5, 0x0

    cmp-long v1, v3, v5

    if-gtz v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    :cond_1
    :goto_0
    return v2
.end method

.method public final j0()Z
    .locals 14

    iget-boolean v0, p0, Lc/P3;->U1:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0}, Lc/P3;->P()Z

    move-result v0

    sget-object v2, Lc/s0;->b:Lc/s0;

    invoke-virtual {p0, v2}, Lc/P3;->L(Lc/s0;)Z

    move-result v2

    const/4 v3, 0x1

    iget-object v4, p0, Lc/P3;->C1:Lc/n1;

    if-eqz v2, :cond_1

    const-string v2, "clock_status_visible"

    iget-object v5, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    invoke-interface {v5, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_1

    move v2, v3

    goto :goto_0

    :cond_1
    move v2, v1

    :goto_0
    sget-object v5, Lc/s0;->k:Lc/s0;

    invoke-virtual {p0, v5}, Lc/P3;->L(Lc/s0;)Z

    move-result v5

    invoke-virtual {v4}, Lc/n1;->C()I

    move-result v6

    const/4 v7, 0x2

    if-nez v2, :cond_3

    if-eqz v0, :cond_2

    goto :goto_1

    :cond_2
    move v2, v1

    goto :goto_2

    :cond_3
    :goto_1
    move v2, v7

    :goto_2
    or-int/2addr v2, v0

    if-eqz v0, :cond_4

    invoke-virtual {v4}, Lc/n1;->l0()Z

    move-result v8

    if-eqz v8, :cond_4

    const/4 v8, 0x4

    goto :goto_3

    :cond_4
    move v8, v1

    :goto_3
    or-int/2addr v2, v8

    if-eqz v5, :cond_5

    and-int/lit8 v8, v6, 0x30

    if-eqz v8, :cond_5

    const/16 v8, 0x8

    goto :goto_4

    :cond_5
    move v8, v1

    :goto_4
    or-int/2addr v2, v8

    if-eqz v5, :cond_6

    and-int/lit8 v5, v6, 0x40

    if-eqz v5, :cond_6

    const/16 v5, 0x10

    goto :goto_5

    :cond_6
    move v5, v1

    :goto_5
    or-int/2addr v2, v5

    const-string v5, "com.syu.music"

    const/16 v6, 0x20

    if-eqz v0, :cond_7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    move v0, v6

    goto :goto_6

    :cond_7
    move v0, v1

    :goto_6
    or-int/2addr v0, v2

    iget v2, p0, Lc/P3;->V1:I

    if-ne v0, v2, :cond_8

    return v1

    :cond_8
    iput v0, p0, Lc/P3;->V1:I

    and-int/lit8 v4, v0, 0x1

    const/4 v8, 0x0

    iget-object v9, p0, Lc/P3;->l1:Lc/L;

    if-eqz v4, :cond_b

    if-ltz v2, :cond_9

    and-int/lit8 v10, v2, 0x1

    if-nez v10, :cond_b

    :cond_9
    iget-object v4, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    if-eqz v4, :cond_a

    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    iget-object v10, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    iget-object v11, p0, Lc/P3;->W0:Landroid/os/Handler;

    invoke-static {v4, v10, v9, v11}, Lc/G8;->W(Landroid/content/Context;Landroid/media/session/MediaSessionManager;Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/os/Handler;)V

    iput-boolean v3, p0, Lc/P3;->j1:Z
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_a
    invoke-virtual {p0}, Lc/P3;->X()V

    goto :goto_7

    :cond_b
    if-nez v4, :cond_d

    iget-boolean v4, p0, Lc/P3;->j1:Z

    if-eqz v4, :cond_c

    iget-object v4, p0, Lc/P3;->g1:Landroid/media/session/MediaSessionManager;

    invoke-virtual {v4, v9}, Landroid/media/session/MediaSessionManager;->removeOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;)V

    :cond_c
    iput-boolean v1, p0, Lc/P3;->j1:Z

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v4

    invoke-virtual {p0, v4}, Lc/P3;->S(Ljava/util/List;)V

    iput-boolean v1, p0, Lc/P3;->k1:Z

    iput-object v8, p0, Lc/P3;->w1:Landroid/media/session/MediaController;

    :cond_d
    :goto_7
    if-ltz v2, :cond_e

    and-int/lit8 v4, v2, 0x2

    and-int/lit8 v9, v0, 0x2

    if-eq v4, v9, :cond_13

    :cond_e
    and-int/lit8 v4, v0, 0x2

    iget-object v9, p0, Lc/P3;->z1:Lc/x7;

    iget-object v10, p0, Lc/P3;->y1:Lc/P;

    if-eqz v4, :cond_11

    invoke-virtual {v10}, Lc/P;->c()V

    iget-boolean v4, v9, Lc/x7;->c:Z

    if-eqz v4, :cond_f

    goto :goto_9

    :cond_f
    new-instance v4, Landroid/content/IntentFilter;

    const-string v10, "android.bluetooth.headsetclient.profile.action.CONNECTION_STATE_CHANGED"

    invoke-direct {v4, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const-string v10, "android.bluetooth.headsetclient.profile.action.AG_EVENT"

    invoke-virtual {v4, v10}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v11, v9, Lc/x7;->h:Lc/w7;

    const/16 v12, 0x21

    iget-object v13, v9, Lc/x7;->a:Landroid/content/Context;

    if-lt v10, v12, :cond_10

    invoke-virtual {v13, v11, v4, v7}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    goto :goto_8

    :cond_10
    invoke-virtual {v13, v11, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    :goto_8
    iput-boolean v3, v9, Lc/x7;->c:Z

    goto :goto_9

    :cond_11
    invoke-virtual {v10}, Lc/P;->d()V

    iget-boolean v4, v9, Lc/x7;->c:Z

    if-eqz v4, :cond_12

    iget-object v4, v9, Lc/x7;->h:Lc/w7;

    iget-object v7, v9, Lc/x7;->a:Landroid/content/Context;

    invoke-virtual {v7, v4}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    :cond_12
    iput-boolean v1, v9, Lc/x7;->c:Z

    iput-boolean v1, v9, Lc/x7;->e:Z

    iput-object v8, v9, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    const/4 v4, -0x1

    iput v4, v9, Lc/x7;->g:I

    iput v4, v9, Lc/x7;->f:I

    :cond_13
    :goto_9
    and-int/lit8 v4, v0, 0x4

    iget-object v7, p0, Lc/P3;->u1:Lc/g8;

    if-eqz v4, :cond_14

    invoke-virtual {v7}, Lc/g8;->b()V

    goto :goto_a

    :cond_14
    invoke-virtual {v7}, Lc/g8;->c()V

    :goto_a
    and-int/lit8 v4, v0, 0x8

    iget-object v7, p0, Lc/P3;->S0:Lc/y8;

    if-eqz v4, :cond_15

    invoke-virtual {v7}, Lc/y8;->f()V

    goto :goto_b

    :cond_15
    invoke-virtual {v7}, Lc/y8;->g()V

    :goto_b
    and-int/lit8 v4, v0, 0x10

    iget-object v7, p0, Lc/P3;->T0:Lc/z8;

    if-eqz v4, :cond_17

    iget-boolean v4, v7, Lc/z8;->c:Z

    if-eqz v4, :cond_16

    goto :goto_c

    :cond_16
    :try_start_1
    iget-object v4, v7, Lc/z8;->a:Landroid/content/Context;

    new-instance v8, Landroid/content/Intent;

    const-string v9, "com.syu.ms.main"

    invoke-direct {v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v9, Landroid/content/ComponentName;

    const-string v10, "com.syu.ms"

    const-string v11, "app.ModuleService"

    invoke-direct {v9, v10, v11}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v8, v9}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v8

    invoke-virtual {v4, v8, v7, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v4

    iput-boolean v4, v7, Lc/z8;->c:Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_c

    :catch_1
    iput-boolean v1, v7, Lc/z8;->c:Z

    goto :goto_c

    :cond_17
    iput-object v8, v7, Lc/z8;->b:Landroid/os/IBinder;

    iget-boolean v4, v7, Lc/z8;->c:Z

    if-nez v4, :cond_18

    goto :goto_c

    :cond_18
    iput-boolean v1, v7, Lc/z8;->c:Z

    :try_start_2
    iget-object v1, v7, Lc/z8;->a:Landroid/content/Context;

    invoke-virtual {v1, v7}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :goto_c
    and-int/2addr v0, v6

    if-eqz v0, :cond_1a

    if-ltz v2, :cond_19

    and-int/lit8 v0, v2, 0x20

    if-nez v0, :cond_1a

    :cond_19
    iget-object v0, p0, Lc/P3;->a0:Lc/z;

    invoke-virtual {v0, v5}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    if-eqz v0, :cond_1a

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "Widget"

    invoke-static {v0, v1}, Lru/drivedeck/launcher/StockMusicService;->a(Landroid/content/Context;Ljava/lang/String;)Z

    :cond_1a
    return v3
.end method

.method public final k()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/P3;->K1:Z

    iget-object v1, p0, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lc/P3;->p()V

    return-void

    :cond_0
    iget-object v1, p0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {p0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v0, p0, Lc/P3;->J1:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/P3;->O1:Lc/s0;

    iget-object v0, p0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v0}, Lc/g1;->c()Z

    return-void
.end method

.method public final k0()V
    .locals 4

    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "bluetooth_on"

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    move v1, v3

    :goto_0
    if-eqz v1, :cond_2

    const-string v2, "disable"

    goto :goto_1

    :cond_2
    const-string v2, "enable"

    :goto_1
    const-string v3, "svc bluetooth "

    if-eqz v1, :cond_3

    :try_start_1
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->disable()Z

    move-result v0

    if-eqz v0, :cond_4

    goto :goto_2

    :cond_3
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->enable()Z

    move-result v0

    if-nez v0, :cond_5

    :cond_4
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/j8;->e(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/j8;->e(Ljava/lang/String;)V

    :cond_5
    :goto_2
    return-void
.end method

.method public final l()V
    .locals 3

    iget-boolean v0, p0, Lc/P3;->w0:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/P3;->v0:Lc/U4;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lc/U4;->b(J)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->L:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->B0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->W:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/P3;->V:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    :cond_0
    return-void
.end method

.method public final l0()V
    .locals 6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "mobile_data"

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    move v1, v2

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v3, "phone"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const-class v3, Landroid/telephony/TelephonyManager;

    const-string v4, "setDataEnabled"

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    filled-new-array {v5}, [Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    xor-int/2addr v2, v1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v3, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    if-eqz v1, :cond_1

    const-string v0, "disable"

    goto :goto_0

    :cond_1
    const-string v0, "enable"

    :goto_0
    const-string v1, "svc data "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/j8;->e(Ljava/lang/String;)V

    :goto_1
    return-void
.end method

.method public final m()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lc/P3;->z1:Lc/x7;

    iget-boolean v0, v0, Lc/x7;->e:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/P3;->y1:Lc/P;

    iget-boolean v0, v0, Lc/P;->o:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->a:Lc/K;

    iget-boolean v0, v0, Lc/K;->f:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    iget-object v1, p0, Lc/P3;->z1:Lc/x7;

    iget-object v2, p0, Lc/P3;->y1:Lc/P;

    iget-object v2, v2, Lc/P;->a:Lc/K;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v3, v2, Lc/K;->f:Z

    if-eqz v3, :cond_2

    iget v2, v2, Lc/K;->d:I

    if-ltz v2, :cond_2

    mul-int/lit8 v2, v2, 0x14

    goto :goto_2

    :cond_2
    iget-boolean v2, v1, Lc/x7;->e:Z

    if-eqz v2, :cond_3

    iget v2, v1, Lc/x7;->f:I

    goto :goto_2

    :cond_3
    const/4 v2, -0x1

    :goto_2
    if-eqz v0, :cond_4

    if-ltz v2, :cond_4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "%"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_4
    if-nez v0, :cond_7

    iget-object v0, p0, Lc/P3;->C:Lc/A8;

    if-eqz v0, :cond_5

    iget-boolean v0, v0, Lc/A8;->d:Z

    if-eqz v0, :cond_5

    goto :goto_4

    :cond_5
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, Lc/P3;->C:Lc/A8;

    if-eqz v1, :cond_6

    iget-boolean v1, v1, Lc/A8;->k:Z

    if-eqz v1, :cond_6

    const-string v1, "\u0412\u043a\u043b."

    goto :goto_3

    :cond_6
    const-string v1, "\u0412\u044b\u043a\u043b."

    :goto_3
    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_7
    :goto_4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "\u041f\u043e\u0434\u043a\u043b."

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final m0()V
    .locals 13

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-boolean v2, p0, Lc/P3;->L1:Z

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_1

    iget-object v2, p0, Lc/P3;->C1:Lc/n1;

    iget-object v5, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    const-string v6, "music_controls_auto_hide"

    invoke-interface {v5, v6, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_1

    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    const-string v5, "music_widget_style"

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-ne v2, v4, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, p0, Lc/P3;->A:Lc/g1;

    iget-boolean v2, v2, Lc/g1;->J:Z

    if-nez v2, :cond_1

    move v2, v4

    goto :goto_1

    :cond_1
    :goto_0
    move v2, v3

    :goto_1
    iput-boolean v2, p0, Lc/P3;->w0:Z

    iget-boolean v5, p0, Lc/P3;->x0:Z

    if-nez v5, :cond_2

    iget-boolean v5, p0, Lc/P3;->I1:Z

    if-nez v5, :cond_2

    iget-object v5, p0, Lc/P3;->K:Lc/a5;

    if-nez v5, :cond_2

    iget-boolean v5, p0, Lc/P3;->z0:Z

    if-eqz v5, :cond_3

    :cond_2
    move v3, v4

    :cond_3
    iget-object v4, p0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v4, v0, v1, v2, v3}, Lc/U4;->d(JZZ)V

    invoke-virtual {v4, v0, v1}, Lc/U4;->a(J)F

    move-result v2

    iput v2, p0, Lc/P3;->A0:F

    iget-boolean v2, v4, Lc/U4;->a:Z

    const-wide/16 v5, 0x10

    const-wide/16 v7, -0x1

    if-nez v2, :cond_4

    goto :goto_2

    :cond_4
    iget v2, v4, Lc/U4;->e:F

    iget v3, v4, Lc/U4;->f:F

    cmpl-float v2, v2, v3

    if-eqz v2, :cond_5

    iget-wide v9, v4, Lc/U4;->d:J

    sub-long v9, v0, v9

    const-wide/16 v11, 0x104

    cmp-long v2, v9, v11

    if-gez v2, :cond_5

    move-wide v7, v5

    goto :goto_2

    :cond_5
    const/high16 v2, 0x3f800000    # 1.0f

    cmpl-float v2, v3, v2

    if-nez v2, :cond_6

    iget-boolean v2, v4, Lc/U4;->b:Z

    if-nez v2, :cond_6

    iget-wide v2, v4, Lc/U4;->c:J

    const-wide/16 v7, 0x5dc

    add-long/2addr v2, v7

    sub-long/2addr v2, v0

    const-wide/16 v0, 0x1

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v7

    :cond_6
    :goto_2
    const-wide/16 v0, 0x0

    cmp-long v0, v7, v0

    if-ltz v0, :cond_8

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_8

    cmp-long v0, v7, v5

    if-gtz v0, :cond_7

    invoke-virtual {p0}, Landroid/view/View;->postInvalidateOnAnimation()V

    goto :goto_3

    :cond_7
    invoke-virtual {p0, v7, v8}, Landroid/view/View;->postInvalidateDelayed(J)V

    :cond_8
    :goto_3
    return-void
.end method

.method public final n()Lc/V4;
    .locals 2

    iget-object v0, p0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->e0()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-static {v0}, Lc/V4;->d(Landroid/media/session/MediaController;)Lc/V4;

    move-result-object v0

    return-object v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    return-object v0
.end method

.method public final n0()V
    .locals 8

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v0

    iget-boolean v1, p0, Lc/P3;->U1:Z

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "speed_obd"

    iget-object v3, p0, Lc/P3;->C1:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_0

    sget-object v1, Lc/s0;->g:Lc/s0;

    invoke-virtual {p0, v1}, Lc/P3;->L(Lc/s0;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v2, 0x1

    :cond_0
    const/16 v1, 0xd

    if-eqz v2, :cond_1

    invoke-virtual {v0, v1}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v3

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    :goto_0
    if-nez v2, :cond_2

    const-string v3, ""

    goto :goto_3

    :cond_2
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v0, Lc/T5;->g:Lc/j6;

    const-string v6, ":"

    if-nez v5, :cond_3

    const-string v5, "standard"

    goto :goto_1

    :cond_3
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v0, Lc/T5;->g:Lc/j6;

    iget-object v7, v7, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v7, v0, Lc/T5;->g:Lc/j6;

    iget-object v7, v7, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :goto_1
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v3, :cond_4

    const-string v3, "13"

    goto :goto_2

    :cond_4
    iget-object v3, v3, Lc/i6;->a:Ljava/lang/String;

    :goto_2
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :goto_3
    iget-object v4, p0, Lc/P3;->q:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5

    return-void

    :cond_5
    iput-object v3, p0, Lc/P3;->q:Ljava/lang/String;

    iget-object v3, p0, Lc/P3;->p:Ljava/lang/Object;

    if-eqz v2, :cond_8

    invoke-virtual {v0, v1}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v2

    if-nez v2, :cond_6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    goto :goto_4

    :cond_6
    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v1

    :goto_4
    invoke-virtual {v0, v3, v1}, Lc/T5;->p0(Ljava/lang/Object;Ljava/util/Set;)V

    if-nez v2, :cond_7

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v1

    goto :goto_5

    :cond_7
    iget-object v1, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-static {v1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    :goto_5
    invoke-virtual {v0, v3, v1}, Lc/T5;->q0(Ljava/lang/Object;Ljava/util/Set;)V

    goto :goto_6

    :cond_8
    invoke-virtual {v0, v3}, Lc/T5;->n0(Ljava/lang/Object;)V

    :goto_6
    return-void
.end method

.method public final o()I
    .locals 7

    const-string v0, "speed_obd"

    iget-object v1, p0, Lc/P3;->C1:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v2, 0x0

    invoke-interface {v1, v0, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v0

    const/16 v3, 0xd

    invoke-virtual {v0, v3}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v4

    if-nez v4, :cond_0

    move-object v5, v1

    goto :goto_0

    :cond_0
    iget-object v5, v4, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v5}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v5

    :goto_0
    if-nez v4, :cond_1

    invoke-virtual {v0, v3}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v0

    goto :goto_1

    :cond_1
    if-nez v5, :cond_2

    move-object v0, v1

    goto :goto_1

    :cond_2
    invoke-virtual {v5, v4}, Lc/S5;->a(Lc/i6;)I

    move-result v3

    iget-wide v4, v5, Lc/S5;->a:D

    const/4 v6, 0x5

    invoke-virtual {v0, v6, v3, v4, v5}, Lc/T5;->A(IID)Ljava/lang/Double;

    move-result-object v0

    :goto_1
    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmpg-double v3, v3, v5

    if-ltz v3, :cond_4

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    const-wide v5, 0x41dfffffffc00000L    # 2.147483647E9

    cmpl-double v3, v3, v5

    if-lez v3, :cond_3

    goto :goto_2

    :cond_3
    move-object v1, v0

    :cond_4
    :goto_2
    if-eqz v1, :cond_5

    const/4 v2, 0x1

    :cond_5
    iput-boolean v2, p0, Lc/P3;->r:Z

    if-nez v1, :cond_6

    iget-object v0, p0, Lc/P3;->A1:Lc/r3;

    invoke-virtual {v0}, Lc/r3;->a()I

    move-result v0

    goto :goto_3

    :cond_6
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    long-to-int v0, v0

    :goto_3
    return v0
.end method

.method public final o0()Lc/i;
    .locals 3

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    new-instance v1, Lc/i;

    const/4 v2, 0x7

    invoke-direct {v1, v0, v2}, Lc/i;-><init>(Ljava/lang/Object;I)V

    return-object v1
.end method

.method public final onAttachedToWindow()V
    .locals 1

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getWindowVisibility()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0}, Lc/P3;->f0(Z)V

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 1

    iget-object v0, p0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/P3;->f0(Z)V

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 22

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget-boolean v0, v8, Lc/P3;->L1:Z

    iget-object v10, v8, Lc/P3;->M:Landroid/graphics/Paint;

    if-nez v0, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v5, v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v6, v0

    iget-object v2, v8, Lc/P3;->b:Landroid/graphics/RectF;

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v3, v0, Lc/r4;->a:I

    iget-object v4, v8, Lc/P3;->a:Lc/W3;

    iget-object v0, v8, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->S()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v7

    move-object/from16 v0, p1

    move-object v1, v10

    invoke-static/range {v0 .. v7}, Lc/s3;->a(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/RectF;ILc/W3;FFF)V

    :cond_0
    iget-object v0, v8, Lc/P3;->B0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v11, v8, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v11}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->V:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->W:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->L0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, v8, Lc/P3;->M0:[Landroid/graphics/RectF;

    array-length v1, v0

    const/4 v12, 0x0

    move v2, v12

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->setEmpty()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object v0, v8, Lc/P3;->N0:[Landroid/graphics/RectF;

    array-length v1, v0

    move v2, v12

    :goto_1
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    invoke-virtual {v3}, Landroid/graphics/RectF;->setEmpty()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    iget-object v0, v8, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v8, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v8, Lc/P3;->t1:Lc/g0;

    iget-object v1, v0, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v0, Lc/g0;->g:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v8, Lc/P3;->n:Lc/G0;

    iput-boolean v12, v0, Lc/G0;->o:Z

    iget-object v0, v0, Lc/G0;->k:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iput-boolean v12, v8, Lc/P3;->k:Z

    iget-object v0, v8, Lc/P3;->f:Lc/o0;

    iget-object v13, v8, Lc/P3;->i:Lc/S;

    if-eqz v0, :cond_3

    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    if-nez v0, :cond_4

    :cond_3
    move v0, v12

    goto/16 :goto_8

    :cond_4
    iget-boolean v0, v8, Lc/P3;->K1:Z

    const/4 v14, 0x0

    iget-object v15, v8, Lc/P3;->A:Lc/g1;

    if-eqz v0, :cond_5

    iput-boolean v12, v8, Lc/P3;->K1:Z

    const/4 v0, 0x0

    invoke-virtual {v15, v0, v14, v14}, Lc/g1;->a(Lc/s0;FF)V

    invoke-virtual {v15}, Lc/g1;->r()V

    :cond_5
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v7

    iget-object v0, v8, Lc/P3;->f:Lc/o0;

    iget-object v6, v0, Lc/o0;->c:Lc/m0;

    iget-boolean v0, v8, Lc/P3;->L1:Z

    iget v5, v6, Lc/m0;->d:F

    iget v4, v6, Lc/m0;->c:F

    iget v3, v6, Lc/m0;->b:F

    if-nez v0, :cond_6

    iget v0, v6, Lc/m0;->a:F

    invoke-virtual {v9, v0, v3, v4, v5}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    :cond_6
    iget-object v0, v8, Lc/P3;->e:Lc/u0;

    iget-object v0, v0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_2
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    iget-object v1, v8, Lc/P3;->R:Landroid/graphics/RectF;

    if-eqz v0, :cond_10

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/r0;

    iget-object v2, v0, Lc/r0;->a:Lc/s0;

    invoke-virtual {v15, v2}, Lc/g1;->i(Lc/s0;)Z

    move-result v2

    if-eqz v2, :cond_7

    goto :goto_2

    :cond_7
    iget-object v2, v8, Lc/P3;->f:Lc/o0;

    iget-object v2, v2, Lc/o0;->e:Ljava/util/EnumMap;

    iget-object v0, v0, Lc/r0;->a:Lc/s0;

    invoke-virtual {v2, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/m0;

    if-eqz v2, :cond_f

    iget v14, v8, Lc/P3;->D:F

    iget v12, v2, Lc/m0;->d:F

    sub-float v17, v12, v14

    cmpg-float v17, v17, v3

    if-ltz v17, :cond_e

    move/from16 v17, v3

    iget v3, v2, Lc/m0;->b:F

    sub-float v14, v3, v14

    cmpl-float v14, v14, v5

    if-lez v14, :cond_8

    move/from16 v3, v17

    :goto_3
    const/4 v12, 0x0

    const/4 v14, 0x0

    goto :goto_2

    :cond_8
    iget-object v14, v8, Lc/P3;->g:Ljava/util/EnumMap;

    invoke-virtual {v14, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lc/V0;

    move/from16 v18, v4

    iget v4, v8, Lc/P3;->D:F

    move/from16 v19, v5

    iget-object v5, v14, Lc/V0;->b:Landroid/graphics/RectF;

    move-object/from16 v20, v6

    sub-float v6, v3, v4

    sub-float v4, v12, v4

    move/from16 v21, v7

    iget v7, v2, Lc/m0;->a:F

    iget v2, v2, Lc/m0;->c:F

    invoke-virtual {v5, v7, v6, v2, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-boolean v4, v15, Lc/g1;->J:Z

    sget-object v5, Lc/s0;->f:Lc/s0;

    if-eqz v4, :cond_9

    if-ne v0, v5, :cond_9

    iget-object v4, v8, Lc/P3;->B:Lc/U0;

    iget-object v4, v4, Lc/U0;->h:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_9

    iget-object v4, v8, Lc/P3;->B:Lc/U0;

    iget-object v4, v4, Lc/U0;->i:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_9

    iget v0, v8, Lc/P3;->D:F

    sub-float/2addr v3, v0

    sub-float/2addr v12, v0

    invoke-virtual {v1, v7, v3, v2, v12}, Landroid/graphics/RectF;->set(FFFF)V

    iget v0, v1, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v8, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float v3, v2, v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    const/high16 v1, 0x40a00000    # 5.0f

    invoke-virtual {v8, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v4, v1, v0

    const/high16 v0, 0x41700000    # 15.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->e:I

    const/4 v7, 0x0

    const-string v2, "\u041f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0430 \u043c\u0430\u0440\u0448\u0440\u0443\u0442\u0430"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v12, v18

    move/from16 v18, v19

    move-object/from16 v19, v20

    move/from16 v14, v21

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    move v6, v12

    move v4, v14

    goto :goto_4

    :cond_9
    move/from16 v6, v18

    move/from16 v18, v19

    move-object/from16 v19, v20

    move/from16 v4, v21

    iget-boolean v1, v8, Lc/P3;->L1:Z

    if-eqz v1, :cond_a

    sget-object v1, Lc/s0;->d:Lc/s0;

    if-ne v0, v1, :cond_a

    iget v1, v8, Lc/P3;->D:F

    sub-float/2addr v3, v1

    sub-float/2addr v12, v1

    invoke-virtual {v11, v7, v3, v2, v12}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v8, Lc/P3;->B:Lc/U0;

    invoke-virtual {v8, v0, v9, v11, v1}, Lc/P3;->H(Lc/s0;Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V

    goto :goto_4

    :cond_a
    iget-object v0, v8, Lc/P3;->B:Lc/U0;

    if-eqz v0, :cond_d

    iget-object v1, v14, Lc/V0;->b:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_b

    goto :goto_4

    :cond_b
    iget-object v2, v14, Lc/V0;->a:Lc/s0;

    if-ne v2, v5, :cond_c

    iget-object v3, v0, Lc/U0;->h:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_c

    iget-object v3, v0, Lc/U0;->i:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_c

    goto :goto_4

    :cond_c
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v3

    invoke-virtual {v9, v1}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    invoke-virtual {v8, v2, v9, v1, v0}, Lc/P3;->H(Lc/s0;Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/U0;)V

    invoke-virtual {v9, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_d
    :goto_4
    move v7, v4

    move v4, v6

    move/from16 v3, v17

    move/from16 v5, v18

    :goto_5
    move-object/from16 v6, v19

    goto/16 :goto_3

    :cond_e
    move-object/from16 v19, v6

    move v6, v4

    goto :goto_5

    :cond_f
    move-object/from16 v19, v6

    move v6, v4

    move-object/from16 v6, v19

    goto/16 :goto_2

    :cond_10
    move/from16 v17, v3

    move-object/from16 v19, v6

    move v6, v4

    move v4, v7

    iget-object v0, v8, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    const/high16 v3, 0x40000000    # 2.0f

    if-nez v2, :cond_12

    iget-object v2, v8, Lc/P3;->L:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    invoke-virtual {v0, v5, v2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-nez v2, :cond_12

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v3

    iget-object v5, v8, Lc/P3;->c0:Lc/r4;

    iget-boolean v5, v5, Lc/r4;->m:Z

    if-eqz v5, :cond_11

    const/16 v5, 0x18

    const/4 v7, 0x0

    :goto_6
    invoke-static {v5, v7, v7, v7}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    goto :goto_7

    :cond_11
    const/16 v5, 0x1e

    const/16 v7, 0xff

    goto :goto_6

    :goto_7
    invoke-virtual {v8, v9, v0, v2, v5}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    :cond_12
    invoke-virtual {v9, v4}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget-boolean v0, v8, Lc/P3;->k:Z

    invoke-virtual {v13, v0}, Lc/S;->b(Z)V

    iget-object v0, v8, Lc/P3;->f:Lc/o0;

    invoke-virtual {v0}, Lc/o0;->c()F

    move-result v0

    const/4 v2, 0x0

    cmpl-float v0, v0, v2

    if-lez v0, :cond_13

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->e:I

    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v0, 0x41c00000    # 24.0f

    invoke-virtual {v8, v0}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual/range {v19 .. v19}, Lc/m0;->b()F

    move-result v2

    invoke-virtual/range {v19 .. v19}, Lc/m0;->b()F

    move-result v4

    mul-float/2addr v4, v2

    iget-object v2, v8, Lc/P3;->f:Lc/o0;

    iget v2, v2, Lc/o0;->i:F

    div-float/2addr v4, v2

    invoke-static {v0, v4}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual/range {v19 .. v19}, Lc/m0;->b()F

    move-result v2

    sub-float/2addr v2, v0

    iget v4, v8, Lc/P3;->D:F

    mul-float/2addr v2, v4

    iget-object v4, v8, Lc/P3;->f:Lc/o0;

    invoke-virtual {v4}, Lc/o0;->c()F

    move-result v4

    div-float/2addr v2, v4

    add-float v2, v2, v17

    const/high16 v4, 0x40400000    # 3.0f

    invoke-virtual {v8, v4}, Lc/P3;->s(F)F

    move-result v4

    sub-float v4, v6, v4

    add-float/2addr v0, v2

    invoke-virtual {v1, v4, v2, v6, v0}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v8, v3}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v8, v3}, Lc/P3;->s(F)F

    move-result v2

    invoke-virtual {v9, v1, v0, v2, v10}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_13
    return-void

    :goto_8
    invoke-virtual {v13, v0}, Lc/S;->b(Z)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v0, Lc/P3;->L1:Z

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/high16 v6, 0x3fa00000    # 1.25f

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v2, :cond_c

    iget-object v2, v0, Lc/P3;->K:Lc/a5;

    if-nez v2, :cond_c

    iget-object v2, v0, Lc/P3;->N1:Lc/g5;

    new-instance v13, Lc/x3;

    const/4 v14, 0x1

    invoke-direct {v13, v0, v14}, Lc/x3;-><init>(Landroid/view/KeyEvent$Callback;I)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v14

    if-nez v14, :cond_2

    iget-boolean v13, v2, Lc/g5;->C:Z

    if-nez v13, :cond_c

    iget-object v13, v2, Lc/g5;->c:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v14

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v15

    invoke-virtual {v13, v14, v15}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v13

    if-nez v13, :cond_0

    goto/16 :goto_3

    :cond_0
    iget-object v3, v2, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v8, v2, Lc/g5;->J:Landroid/animation/ValueAnimator;

    :cond_1
    iput-boolean v12, v2, Lc/g5;->A:Z

    iput-boolean v11, v2, Lc/g5;->B:Z

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    iput v3, v2, Lc/g5;->x:F

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v2, Lc/g5;->y:F

    goto/16 :goto_2

    :cond_2
    iget-boolean v15, v2, Lc/g5;->A:Z

    if-nez v15, :cond_3

    goto/16 :goto_3

    :cond_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v15

    iget v10, v2, Lc/g5;->x:F

    sub-float/2addr v15, v10

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v10, v2, Lc/g5;->y:F

    sub-float/2addr v1, v10

    iget-object v10, v2, Lc/g5;->a:Lc/P3;

    if-ne v14, v4, :cond_6

    iget-boolean v4, v2, Lc/g5;->B:Z

    if-nez v4, :cond_4

    invoke-static {v15}, Ljava/lang/Math;->abs(F)F

    move-result v4

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v5

    int-to-float v5, v5

    cmpl-float v4, v4, v5

    if-lez v4, :cond_4

    invoke-static {v15}, Ljava/lang/Math;->abs(F)F

    move-result v4

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    mul-float/2addr v1, v6

    cmpl-float v1, v4, v1

    if-lez v1, :cond_4

    iput-boolean v12, v2, Lc/g5;->B:Z

    invoke-virtual {v10}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1, v12}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_4
    iget-boolean v1, v2, Lc/g5;->B:Z

    if-eqz v1, :cond_b

    iget-boolean v1, v2, Lc/g5;->D:Z

    if-eqz v1, :cond_5

    iget-object v1, v2, Lc/g5;->b:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->width()F

    move-result v1

    const v4, 0x3f428f5c    # 0.76f

    mul-float/2addr v1, v4

    goto :goto_0

    :cond_5
    iget v1, v2, Lc/g5;->z:F

    :goto_0
    div-float/2addr v15, v1

    invoke-static {v3, v15}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v3, -0x40800000    # -1.0f

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, v2, Lc/g5;->w:F

    invoke-virtual {v10}, Landroid/view/View;->invalidate()V

    goto :goto_2

    :cond_6
    if-eq v14, v12, :cond_7

    if-eq v14, v7, :cond_7

    if-ne v14, v5, :cond_b

    :cond_7
    iput-boolean v11, v2, Lc/g5;->A:Z

    invoke-virtual {v10}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    invoke-interface {v1, v11}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    if-ne v14, v12, :cond_a

    iget-boolean v1, v2, Lc/g5;->B:Z

    if-eqz v1, :cond_a

    iget v1, v2, Lc/g5;->w:F

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const v3, 0x3e4ccccd    # 0.2f

    cmpl-float v1, v1, v3

    if-lez v1, :cond_a

    iget v1, v2, Lc/g5;->w:F

    cmpg-float v1, v1, v9

    if-gez v1, :cond_8

    move v10, v12

    goto :goto_1

    :cond_8
    const/4 v10, -0x1

    :goto_1
    if-lez v10, :cond_9

    move v11, v12

    :cond_9
    new-instance v1, Lc/w;

    const/4 v3, 0x6

    invoke-direct {v1, v13, v10, v3}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v2, v11, v1}, Lc/g5;->k(ZLjava/lang/Runnable;)Z

    goto :goto_2

    :cond_a
    invoke-virtual {v2, v9, v8}, Lc/g5;->j(FLjava/lang/Runnable;)V

    :cond_b
    :goto_2
    return v12

    :cond_c
    :goto_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v13

    if-nez v2, :cond_f

    iput-boolean v11, v0, Lc/P3;->y0:Z

    iget-boolean v2, v0, Lc/P3;->w0:Z

    if-eqz v2, :cond_11

    iget-object v2, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v2, v2, Lc/g1;->J:Z

    if-nez v2, :cond_11

    iget-object v2, v0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v10

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v15

    invoke-virtual {v2, v10, v15}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_11

    iget-object v2, v0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v2, v13, v14, v12, v11}, Lc/U4;->d(JZZ)V

    iget-object v2, v0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v2, v13, v14}, Lc/U4;->b(J)Z

    move-result v2

    xor-int/lit8 v10, v2, 0x1

    iput-boolean v10, v0, Lc/P3;->y0:Z

    iput-boolean v12, v0, Lc/P3;->x0:Z

    if-eqz v2, :cond_e

    iget-object v2, v0, Lc/P3;->v0:Lc/U4;

    iput-wide v13, v2, Lc/U4;->c:J

    iget v10, v2, Lc/U4;->f:F

    cmpl-float v10, v10, v3

    if-nez v10, :cond_d

    goto :goto_4

    :cond_d
    invoke-virtual {v2, v13, v14}, Lc/U4;->a(J)F

    move-result v10

    iput v10, v2, Lc/U4;->e:F

    iput v3, v2, Lc/U4;->f:F

    iput-wide v13, v2, Lc/U4;->d:J

    :cond_e
    :goto_4
    iget-object v2, v0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v2, v13, v14, v12, v12}, Lc/U4;->d(JZZ)V

    goto :goto_5

    :cond_f
    if-eq v2, v12, :cond_10

    if-eq v2, v7, :cond_10

    if-ne v2, v5, :cond_11

    :cond_10
    iput-boolean v11, v0, Lc/P3;->x0:Z

    iget-object v10, v0, Lc/P3;->v0:Lc/U4;

    iget-boolean v15, v0, Lc/P3;->w0:Z

    invoke-virtual {v10, v13, v14, v15, v11}, Lc/U4;->d(JZZ)V

    if-eq v2, v12, :cond_11

    iput-boolean v11, v0, Lc/P3;->y0:Z

    :cond_11
    :goto_5
    iget-object v2, v0, Lc/P3;->o:Lc/C0;

    iget-object v2, v2, Lc/C0;->h:Ljava/lang/String;

    const/4 v10, 0x4

    if-eqz v2, :cond_12

    goto :goto_6

    :cond_12
    iget-object v2, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v15

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-virtual {v2, v15, v6}, Lc/g1;->f(FF)Z

    move-result v2

    if-nez v2, :cond_24

    :goto_6
    iget-object v2, v0, Lc/P3;->o:Lc/C0;

    iget-object v6, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v6, v6, Lc/g1;->J:Z

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v15

    iget-object v9, v2, Lc/C0;->h:Ljava/lang/String;

    iget-object v12, v2, Lc/C0;->c:Lc/G0;

    if-eqz v9, :cond_14

    iget-object v9, v2, Lc/C0;->j:Lc/j6;

    iget-object v3, v12, Lc/G0;->c:Lc/T5;

    iget-object v3, v3, Lc/T5;->g:Lc/j6;

    if-eq v9, v3, :cond_14

    invoke-virtual {v2}, Lc/C0;->a()V

    iput-object v8, v2, Lc/C0;->g:Ljava/lang/String;

    :cond_13
    :goto_7
    const/4 v1, 0x1

    goto/16 :goto_d

    :cond_14
    iget-object v3, v2, Lc/C0;->i:Lc/j6;

    iget-object v9, v12, Lc/G0;->c:Lc/T5;

    iget-object v9, v9, Lc/T5;->g:Lc/j6;

    iget-object v4, v2, Lc/C0;->f:Landroid/graphics/RectF;

    if-eq v3, v9, :cond_15

    iput-object v8, v2, Lc/C0;->g:Ljava/lang/String;

    invoke-virtual {v4}, Landroid/graphics/RectF;->setEmpty()V

    :cond_15
    if-eqz v6, :cond_23

    iget-boolean v3, v12, Lc/G0;->o:Z

    if-nez v3, :cond_16

    goto/16 :goto_e

    :cond_16
    iget-object v3, v2, Lc/C0;->a:Lc/P3;

    iget-object v6, v2, Lc/C0;->b:Lc/n1;

    if-nez v15, :cond_1a

    iget-object v9, v2, Lc/C0;->g:Ljava/lang/String;

    if-eqz v9, :cond_17

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v9

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v15

    invoke-virtual {v4, v9, v15}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_17

    const/4 v4, 0x1

    goto :goto_8

    :cond_17
    move v4, v11

    :goto_8
    iput-boolean v4, v2, Lc/C0;->o:Z

    if-eqz v4, :cond_18

    iget-object v4, v2, Lc/C0;->g:Ljava/lang/String;

    goto :goto_9

    :cond_18
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v9

    invoke-virtual {v2, v4, v9}, Lc/C0;->c(FF)Ljava/lang/String;

    move-result-object v4

    :goto_9
    iput-object v4, v2, Lc/C0;->h:Ljava/lang/String;

    if-nez v4, :cond_19

    goto/16 :goto_f

    :cond_19
    iput-object v4, v2, Lc/C0;->g:Ljava/lang/String;

    iget-object v4, v12, Lc/G0;->c:Lc/T5;

    iget-object v4, v4, Lc/T5;->g:Lc/j6;

    iput-object v4, v2, Lc/C0;->j:Lc/j6;

    iput-object v4, v2, Lc/C0;->i:Lc/j6;

    invoke-virtual {v6, v4}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v4

    iput-object v4, v2, Lc/C0;->k:Ljava/util/ArrayList;

    iget-object v4, v2, Lc/C0;->j:Lc/j6;

    iget-object v5, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v6, v4, v5}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v4

    iput v4, v2, Lc/C0;->l:I

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    iput v4, v2, Lc/C0;->m:F

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v2, Lc/C0;->n:F

    iput-boolean v11, v2, Lc/C0;->p:Z

    invoke-virtual {v3, v10}, Landroid/view/View;->performHapticFeedback(I)Z

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    goto :goto_7

    :cond_1a
    iget-object v4, v2, Lc/C0;->h:Ljava/lang/String;

    if-nez v4, :cond_1b

    goto/16 :goto_f

    :cond_1b
    if-eq v15, v7, :cond_1c

    if-ne v15, v5, :cond_1d

    :cond_1c
    const/4 v1, 0x1

    goto/16 :goto_c

    :cond_1d
    const/4 v4, 0x2

    if-ne v15, v4, :cond_21

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    iget v7, v2, Lc/C0;->m:F

    sub-float/2addr v4, v7

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v7

    iget v8, v2, Lc/C0;->n:F

    sub-float/2addr v7, v8

    iget-boolean v8, v2, Lc/C0;->p:Z

    float-to-double v9, v4

    float-to-double v13, v7

    invoke-static {v9, v10, v13, v14}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v9

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    invoke-static {v13}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v13

    int-to-double v13, v13

    cmpl-double v9, v9, v13

    if-lez v9, :cond_1e

    const/4 v9, 0x1

    goto :goto_a

    :cond_1e
    move v9, v11

    :goto_a
    or-int/2addr v8, v9

    iput-boolean v8, v2, Lc/C0;->p:Z

    if-eqz v8, :cond_13

    iget-boolean v8, v2, Lc/C0;->o:Z

    iget-object v9, v2, Lc/C0;->d:Lc/K3;

    if-eqz v8, :cond_1f

    iget-object v1, v2, Lc/C0;->j:Lc/j6;

    iget-object v8, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v6, v1, v8}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v1

    iget v8, v2, Lc/C0;->l:I

    int-to-float v8, v8

    add-float/2addr v4, v7

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v7, v10}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v7

    const/high16 v10, 0x40000000    # 2.0f

    mul-float/2addr v7, v10

    div-float/2addr v4, v7

    add-float/2addr v4, v8

    const/high16 v7, 0x40a00000    # 5.0f

    div-float/2addr v4, v7

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    mul-int/2addr v4, v5

    const/16 v5, 0xc8

    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/16 v5, 0x19

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    if-eq v4, v1, :cond_20

    iget-object v5, v2, Lc/C0;->j:Lc/j6;

    iget-object v7, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v6, v5, v7, v4}, Lc/n1;->M0(Lc/j6;Ljava/lang/String;I)V

    invoke-virtual {v9}, Lc/K3;->getAsBoolean()Z

    move-result v4

    if-nez v4, :cond_20

    iget-object v4, v2, Lc/C0;->j:Lc/j6;

    iget-object v2, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v6, v4, v2, v1}, Lc/n1;->M0(Lc/j6;Ljava/lang/String;I)V

    goto :goto_b

    :cond_1f
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    invoke-virtual {v2, v4, v1}, Lc/C0;->c(FF)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_20

    iget-object v4, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_20

    iget-object v4, v2, Lc/C0;->j:Lc/j6;

    invoke-virtual {v6, v4}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v4

    iget-object v5, v2, Lc/C0;->j:Lc/j6;

    invoke-virtual {v6, v5}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v1

    iget-object v7, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v7, v2, Lc/C0;->h:Ljava/lang/String;

    invoke-virtual {v5, v1, v7}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget-object v1, v2, Lc/C0;->j:Lc/j6;

    invoke-virtual {v6, v1, v5}, Lc/n1;->L0(Lc/j6;Ljava/util/ArrayList;)V

    invoke-virtual {v9}, Lc/K3;->getAsBoolean()Z

    move-result v1

    if-nez v1, :cond_20

    iget-object v1, v2, Lc/C0;->j:Lc/j6;

    invoke-virtual {v6, v1, v4}, Lc/n1;->L0(Lc/j6;Ljava/util/ArrayList;)V

    :cond_20
    :goto_b
    invoke-virtual {v12, v11}, Lc/G0;->j(Z)Z

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    goto/16 :goto_7

    :cond_21
    const/4 v1, 0x1

    if-ne v15, v1, :cond_22

    iput-object v8, v2, Lc/C0;->h:Ljava/lang/String;

    iput-object v8, v2, Lc/C0;->k:Ljava/util/ArrayList;

    iput-object v8, v2, Lc/C0;->j:Lc/j6;

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    goto :goto_d

    :goto_c
    invoke-virtual {v2}, Lc/C0;->a()V

    :cond_22
    :goto_d
    return v1

    :cond_23
    :goto_e
    invoke-virtual {v2}, Lc/C0;->a()V

    iput-object v8, v2, Lc/C0;->g:Ljava/lang/String;

    :cond_24
    :goto_f
    iget-object v2, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v3, v2, Lc/g1;->J:Z

    if-eqz v3, :cond_26

    iget-object v3, v0, Lc/P3;->t1:Lc/g0;

    iget v3, v3, Lc/g0;->j:I

    if-ltz v3, :cond_25

    goto :goto_10

    :cond_25
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    invoke-virtual {v2, v3, v4}, Lc/g1;->f(FF)Z

    move-result v2

    if-nez v2, :cond_26

    :goto_10
    iget-object v2, v0, Lc/P3;->t1:Lc/g0;

    invoke-virtual {v2, v1}, Lc/g0;->f(Landroid/view/MotionEvent;)Z

    move-result v2

    if-eqz v2, :cond_26

    const/4 v2, 0x1

    goto :goto_11

    :cond_26
    move v2, v11

    :goto_11
    if-eqz v2, :cond_28

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-eq v3, v7, :cond_27

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-ne v3, v5, :cond_28

    :cond_27
    iget-object v3, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v3, v1}, Lc/g1;->n(Landroid/view/MotionEvent;)Z

    :cond_28
    if-eqz v2, :cond_29

    const/4 v2, 0x1

    return v2

    :cond_29
    const/4 v2, 0x1

    iget-object v3, v0, Lc/P3;->A:Lc/g1;

    invoke-virtual {v3, v1}, Lc/g1;->n(Landroid/view/MotionEvent;)Z

    move-result v3

    if-eqz v3, :cond_2a

    return v2

    :cond_2a
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    if-ne v2, v5, :cond_2b

    iget-object v1, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v1, v0, Lc/P3;->U0:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v1, -0x1

    iput v1, v0, Lc/P3;->O0:I

    iput v1, v0, Lc/P3;->P0:I

    iput-boolean v11, v0, Lc/P3;->V0:Z

    iput-boolean v11, v0, Lc/P3;->i0:Z

    const/4 v1, 0x0

    iput v1, v0, Lc/P3;->j0:F

    iput-object v8, v0, Lc/P3;->h0:Lc/q5;

    iput-boolean v11, v0, Lc/P3;->G:Z

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->H:Z

    iput-boolean v11, v0, Lc/P3;->I1:Z

    iget-object v2, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v1

    :cond_2b
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    sget-object v3, Lc/s0;->l:Lc/s0;

    if-nez v2, :cond_44

    iget-object v2, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v11, v0, Lc/P3;->J1:Z

    iput-object v8, v0, Lc/P3;->O1:Lc/s0;

    iput-boolean v11, v0, Lc/P3;->V0:Z

    iput-boolean v11, v0, Lc/P3;->G:Z

    iput-boolean v11, v0, Lc/P3;->H:Z

    iget-object v2, v0, Lc/P3;->f:Lc/o0;

    if-eqz v2, :cond_43

    iget-object v2, v2, Lc/o0;->c:Lc/m0;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v5

    invoke-virtual {v2, v4, v5}, Lc/m0;->a(FF)Z

    move-result v2

    if-nez v2, :cond_2c

    iget-boolean v2, v0, Lc/P3;->L1:Z

    if-eqz v2, :cond_43

    iget-object v2, v0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-nez v2, :cond_2c

    goto/16 :goto_1e

    :cond_2c
    iget v2, v0, Lc/P3;->D:F

    iput v2, v0, Lc/P3;->E:F

    iput-boolean v11, v0, Lc/P3;->F:Z

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    iput v2, v0, Lc/P3;->F1:F

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v0, Lc/P3;->G1:F

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v2, v1

    move v4, v11

    :goto_12
    if-ge v4, v2, :cond_2e

    aget-object v5, v1, v4

    iget-object v6, v0, Lc/P3;->f:Lc/o0;

    iget-object v6, v6, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v6, v5}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/m0;

    if-eqz v6, :cond_2d

    iget v7, v0, Lc/P3;->F1:F

    iget v9, v0, Lc/P3;->G1:F

    iget v12, v0, Lc/P3;->D:F

    add-float/2addr v9, v12

    invoke-virtual {v6, v7, v9}, Lc/m0;->a(FF)Z

    move-result v6

    if-eqz v6, :cond_2d

    iput-object v5, v0, Lc/P3;->O1:Lc/s0;

    goto :goto_13

    :cond_2d
    add-int/lit8 v4, v4, 0x1

    goto :goto_12

    :cond_2e
    :goto_13
    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-nez v1, :cond_2f

    iget-object v1, v0, Lc/P3;->W:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v4, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_2f

    invoke-virtual/range {p0 .. p0}, Lc/P3;->j()Z

    move-result v1

    if-eqz v1, :cond_2f

    const/4 v1, 0x1

    goto :goto_14

    :cond_2f
    move v1, v11

    :goto_14
    iput-boolean v1, v0, Lc/P3;->I1:Z

    const-wide/16 v4, 0x0

    iput-wide v4, v0, Lc/P3;->H1:J

    iget-object v2, v0, Lc/P3;->O1:Lc/s0;

    sget-object v4, Lc/s0;->d:Lc/s0;

    if-ne v2, v4, :cond_30

    if-nez v1, :cond_30

    const/4 v1, 0x1

    goto :goto_15

    :cond_30
    move v1, v11

    :goto_15
    iput-boolean v1, v0, Lc/P3;->G:Z

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-nez v1, :cond_31

    iget-object v1, v0, Lc/P3;->L0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v4, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, 0x1

    goto :goto_16

    :cond_31
    move v1, v11

    :goto_16
    iput-boolean v1, v0, Lc/P3;->V0:Z

    const/4 v1, -0x1

    iput v1, v0, Lc/P3;->O0:I

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-nez v1, :cond_32

    move v1, v11

    :goto_17
    iget-object v2, v0, Lc/P3;->M0:[Landroid/graphics/RectF;

    array-length v4, v2

    if-ge v1, v4, :cond_32

    aget-object v2, v2, v1

    iget v4, v0, Lc/P3;->F1:F

    iget v5, v0, Lc/P3;->G1:F

    invoke-virtual {v2, v4, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_33

    iput v1, v0, Lc/P3;->O0:I

    :cond_32
    const/4 v1, -0x1

    goto :goto_18

    :cond_33
    add-int/lit8 v1, v1, 0x1

    goto :goto_17

    :goto_18
    iput v1, v0, Lc/P3;->P0:I

    iput-boolean v11, v0, Lc/P3;->Q0:Z

    iget v1, v0, Lc/P3;->O0:I

    if-ne v1, v10, :cond_35

    move v1, v11

    :goto_19
    iget-object v2, v0, Lc/P3;->N0:[Landroid/graphics/RectF;

    array-length v4, v2

    if-ge v1, v4, :cond_35

    aget-object v2, v2, v1

    iget v4, v0, Lc/P3;->F1:F

    iget v5, v0, Lc/P3;->G1:F

    invoke-virtual {v2, v4, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_34

    iput v1, v0, Lc/P3;->P0:I

    goto :goto_1a

    :cond_34
    add-int/lit8 v1, v1, 0x1

    goto :goto_19

    :cond_35
    :goto_1a
    iget v1, v0, Lc/P3;->O0:I

    const-wide/16 v4, 0x1f4

    if-ltz v1, :cond_36

    const/4 v2, 0x6

    if-eq v1, v2, :cond_36

    iget-object v1, v0, Lc/P3;->U0:Lc/F3;

    invoke-virtual {v0, v1, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1b

    :cond_36
    iget-boolean v1, v0, Lc/P3;->V0:Z

    if-nez v1, :cond_37

    iget-boolean v1, v0, Lc/P3;->I1:Z

    if-nez v1, :cond_37

    iget-object v1, v0, Lc/P3;->O1:Lc/s0;

    sget-object v2, Lc/s0;->i:Lc/s0;

    if-eq v1, v2, :cond_37

    sget-object v2, Lc/s0;->m:Lc/s0;

    if-eq v1, v2, :cond_37

    iget-object v1, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v1, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_37
    :goto_1b
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    invoke-virtual/range {p0 .. p0}, Lc/P3;->n()Lc/V4;

    move-result-object v1

    iput-object v1, v0, Lc/P3;->F0:Lc/V4;

    iput-boolean v11, v0, Lc/P3;->i0:Z

    const/4 v1, 0x0

    iput v1, v0, Lc/P3;->j0:F

    iput-object v8, v0, Lc/P3;->h0:Lc/q5;

    :goto_1c
    iget-object v1, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v11, v1, :cond_39

    iget-object v1, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v4, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_38

    iget-object v1, v0, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/q5;

    iput-object v1, v0, Lc/P3;->h0:Lc/q5;

    :cond_38
    add-int/lit8 v11, v11, 0x1

    goto :goto_1c

    :cond_39
    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, v0, Lc/P3;->O1:Lc/s0;

    if-ne v1, v3, :cond_3a

    iget-object v1, v0, Lc/P3;->n:Lc/G0;

    iget-object v1, v1, Lc/G0;->k:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3a

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->n:Lc/G0;

    iget-object v2, v2, Lc/G0;->k:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto/16 :goto_1d

    :cond_3a
    iget-boolean v1, v0, Lc/P3;->V0:Z

    if-eqz v1, :cond_3b

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->L0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1d

    :cond_3b
    iget-object v1, v0, Lc/P3;->E0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3c

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1d

    :cond_3c
    iget-object v1, v0, Lc/P3;->D0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3d

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1d

    :cond_3d
    iget-object v1, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3e

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1d

    :cond_3e
    iget-object v1, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_3f

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_1d

    :cond_3f
    iget-object v1, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_40

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    iget-object v2, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_40
    :goto_1d
    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_42

    iget-object v1, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_41
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_42

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    iget v3, v0, Lc/P3;->F1:F

    iget v4, v0, Lc/P3;->G1:F

    invoke-virtual {v2, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_41

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1, v2}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    :cond_42
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :cond_43
    :goto_1e
    return v11

    :cond_44
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    if-ne v2, v7, :cond_45

    iput-boolean v11, v0, Lc/P3;->i0:Z

    const/4 v1, 0x0

    iput v1, v0, Lc/P3;->j0:F

    iput-object v8, v0, Lc/P3;->h0:Lc/q5;

    iget-object v1, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v1, v0, Lc/P3;->U0:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v11, v0, Lc/P3;->V0:Z

    const/4 v1, -0x1

    iput v1, v0, Lc/P3;->O0:I

    iput v1, v0, Lc/P3;->P0:I

    iput-boolean v11, v0, Lc/P3;->Q0:Z

    iput-boolean v11, v0, Lc/P3;->G:Z

    iput-boolean v11, v0, Lc/P3;->H:Z

    iput-boolean v11, v0, Lc/P3;->I1:Z

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x1

    return v2

    :cond_45
    const/4 v2, 0x1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v4

    const/4 v5, 0x2

    if-ne v4, v5, :cond_56

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    iget v4, v0, Lc/P3;->F1:F

    sub-float/2addr v3, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    iget v5, v0, Lc/P3;->G1:F

    sub-float/2addr v4, v5

    iget-boolean v5, v0, Lc/P3;->H:Z

    if-eqz v5, :cond_46

    return v2

    :cond_46
    float-to-double v5, v3

    float-to-double v7, v4

    invoke-static {v5, v6, v7, v8}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v2

    int-to-double v7, v2

    cmpl-double v2, v5, v7

    if-lez v2, :cond_47

    iget-object v2, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, v0, Lc/P3;->U0:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v11, v0, Lc/P3;->V0:Z

    :cond_47
    iget-boolean v2, v0, Lc/P3;->I1:Z

    if-eqz v2, :cond_48

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {v0, v1, v11}, Lc/P3;->d0(FZ)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :cond_48
    iget-boolean v2, v0, Lc/P3;->G:Z

    const/high16 v5, 0x41400000    # 12.0f

    if-eqz v2, :cond_4f

    const/high16 v2, 0x42400000    # 48.0f

    invoke-virtual {v0, v2}, Lc/P3;->s(F)F

    move-result v6

    neg-float v6, v6

    cmpg-float v6, v4, v6

    if-gez v6, :cond_49

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v6

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v7

    const/high16 v8, 0x3fa00000    # 1.25f

    mul-float/2addr v7, v8

    cmpl-float v6, v6, v7

    if-lez v6, :cond_49

    iput-boolean v11, v0, Lc/P3;->G:Z

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->H:Z

    iput-boolean v11, v0, Lc/P3;->J1:Z

    iput-boolean v11, v0, Lc/P3;->F:Z

    iget-object v2, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->h0()V

    return v1

    :cond_49
    invoke-virtual {v0, v2}, Lc/P3;->s(F)F

    move-result v2

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v6

    cmpg-float v2, v6, v2

    if-ltz v2, :cond_4c

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v2

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v6

    const/high16 v7, 0x3fa00000    # 1.25f

    mul-float/2addr v6, v7

    cmpg-float v2, v2, v6

    if-gtz v2, :cond_4a

    goto :goto_1f

    :cond_4a
    const/4 v2, 0x0

    cmpg-float v6, v3, v2

    if-gez v6, :cond_4b

    const/4 v10, 0x1

    goto :goto_20

    :cond_4b
    const/4 v10, -0x1

    goto :goto_20

    :cond_4c
    :goto_1f
    move v10, v11

    :goto_20
    if-eqz v10, :cond_4e

    iput-boolean v11, v0, Lc/P3;->G:Z

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->H:Z

    iput-boolean v11, v0, Lc/P3;->J1:Z

    iget-object v1, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iput-boolean v11, v0, Lc/P3;->V0:Z

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    if-lez v10, :cond_4d

    const/4 v11, 0x1

    :cond_4d
    invoke-virtual {v0, v11}, Lc/P3;->q(Z)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :cond_4e
    invoke-virtual {v0, v5}, Lc/P3;->s(F)F

    move-result v2

    cmpl-float v2, v4, v2

    if-lez v2, :cond_4f

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v2

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v6

    cmpl-float v2, v2, v6

    if-lez v2, :cond_4f

    iput-boolean v11, v0, Lc/P3;->G:Z

    :cond_4f
    iget-boolean v2, v0, Lc/P3;->J1:Z

    if-eqz v2, :cond_50

    const/4 v2, 0x1

    return v2

    :cond_50
    iget-boolean v2, v0, Lc/P3;->F:Z

    if-nez v2, :cond_52

    iget-object v2, v0, Lc/P3;->h0:Lc/q5;

    if-eqz v2, :cond_52

    iget-boolean v2, v2, Lc/q5;->g:Z

    if-eqz v2, :cond_52

    iget-boolean v2, v0, Lc/P3;->i0:Z

    if-nez v2, :cond_51

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v6

    int-to-float v6, v6

    cmpl-float v2, v2, v6

    if-lez v2, :cond_52

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v2

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    const/high16 v6, 0x3fa00000    # 1.25f

    mul-float/2addr v4, v6

    cmpl-float v2, v2, v4

    if-lez v2, :cond_52

    :cond_51
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/P3;->i0:Z

    iput v3, v0, Lc/P3;->j0:F

    iget-object v2, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v1

    :cond_52
    iget-object v2, v0, Lc/P3;->f:Lc/o0;

    if-eqz v2, :cond_54

    invoke-virtual {v2}, Lc/o0;->c()F

    move-result v2

    const/4 v3, 0x0

    cmpl-float v2, v2, v3

    if-lez v2, :cond_54

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    iget v3, v0, Lc/P3;->G1:F

    sub-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    invoke-virtual {v0, v5}, Lc/P3;->s(F)F

    move-result v3

    cmpl-float v2, v2, v3

    if-lez v2, :cond_54

    iget-boolean v2, v0, Lc/P3;->G:Z

    if-eqz v2, :cond_53

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    iget v3, v0, Lc/P3;->G1:F

    cmpg-float v2, v2, v3

    if-ltz v2, :cond_54

    :cond_53
    const/4 v2, 0x1

    iput-boolean v2, v0, Lc/P3;->F:Z

    iget-object v2, v0, Lc/P3;->f:Lc/o0;

    invoke-virtual {v2}, Lc/o0;->c()F

    move-result v2

    iget v3, v0, Lc/P3;->E:F

    iget v4, v0, Lc/P3;->G1:F

    add-float/2addr v3, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    sub-float/2addr v3, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, v0, Lc/P3;->D:F

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :cond_54
    iget-object v2, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    invoke-virtual {v2, v3, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-nez v1, :cond_55

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    :cond_55
    const/4 v2, 0x1

    return v2

    :cond_56
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v4

    if-eq v4, v2, :cond_57

    return v2

    :cond_57
    iget-object v2, v0, Lc/P3;->Q1:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v2, v0, Lc/P3;->U0:Lc/F3;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-boolean v2, v0, Lc/P3;->i0:Z

    if-eqz v2, :cond_5c

    move v3, v11

    const/4 v2, 0x0

    :goto_21
    iget-object v4, v0, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_59

    iget-object v4, v0, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/q5;

    iget-object v5, v0, Lc/P3;->h0:Lc/q5;

    invoke-virtual {v4, v5}, Lc/q5;->c(Lc/q5;)Z

    move-result v4

    if-eqz v4, :cond_58

    iget-object v2, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v2

    :cond_58
    add-int/lit8 v3, v3, 0x1

    goto :goto_21

    :cond_59
    const/4 v3, 0x0

    cmpl-float v4, v2, v3

    if-lez v4, :cond_5b

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iget v3, v0, Lc/P3;->F1:F

    sub-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v3, 0x42800000    # 64.0f

    invoke-virtual {v0, v3}, Lc/P3;->s(F)F

    move-result v3

    const/high16 v4, 0x3e800000    # 0.25f

    mul-float/2addr v2, v4

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    cmpl-float v1, v1, v2

    if-ltz v1, :cond_5b

    iget-object v1, v0, Lc/P3;->h0:Lc/q5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    iget-boolean v3, v1, Lc/q5;->g:Z

    if-eqz v3, :cond_5b

    iget-object v1, v1, Lc/q5;->f:Ljava/lang/String;

    if-eqz v1, :cond_5b

    if-nez v2, :cond_5a

    goto :goto_22

    :cond_5a
    :try_start_0
    invoke-virtual {v2, v1}, Landroid/service/notification/NotificationListenerService;->cancelNotification(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_5b
    :goto_22
    iput-boolean v11, v0, Lc/P3;->i0:Z

    const/4 v1, 0x0

    iput v1, v0, Lc/P3;->j0:F

    iput-object v8, v0, Lc/P3;->h0:Lc/q5;

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x1

    return v2

    :cond_5c
    const/4 v2, 0x1

    iget-boolean v4, v0, Lc/P3;->I1:Z

    if-eqz v4, :cond_5d

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    invoke-virtual {v0, v1, v2}, Lc/P3;->d0(FZ)V

    iput-boolean v11, v0, Lc/P3;->I1:Z

    iget-object v1, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v2

    :cond_5d
    iget-boolean v4, v0, Lc/P3;->J1:Z

    if-eqz v4, :cond_5e

    return v2

    :cond_5e
    iget-boolean v4, v0, Lc/P3;->H:Z

    if-eqz v4, :cond_5f

    iput-boolean v11, v0, Lc/P3;->G:Z

    iput-boolean v11, v0, Lc/P3;->H:Z

    iput-boolean v11, v0, Lc/P3;->y0:Z

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v2

    :cond_5f
    iget-boolean v2, v0, Lc/P3;->V0:Z

    if-eqz v2, :cond_60

    iget-object v2, v0, Lc/P3;->L0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v5

    invoke-virtual {v2, v4, v5}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_60

    const/4 v2, 0x1

    goto :goto_23

    :cond_60
    move v2, v11

    :goto_23
    iput-boolean v11, v0, Lc/P3;->V0:Z

    iget v4, v0, Lc/P3;->O0:I

    if-ltz v4, :cond_61

    iget-object v5, v0, Lc/P3;->M0:[Landroid/graphics/RectF;

    aget-object v4, v5, v4

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_61

    iget v4, v0, Lc/P3;->O0:I

    goto :goto_24

    :cond_61
    const/4 v4, -0x1

    :goto_24
    iget v5, v0, Lc/P3;->P0:I

    if-ltz v5, :cond_62

    iget-object v6, v0, Lc/P3;->N0:[Landroid/graphics/RectF;

    aget-object v5, v6, v5

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v9

    invoke-virtual {v5, v6, v9}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_62

    iget v5, v0, Lc/P3;->P0:I

    :goto_25
    const/4 v6, -0x1

    goto :goto_26

    :cond_62
    const/4 v5, -0x1

    goto :goto_25

    :goto_26
    iput v6, v0, Lc/P3;->O0:I

    iput v6, v0, Lc/P3;->P0:I

    iget-object v6, v0, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v6}, Landroid/graphics/RectF;->setEmpty()V

    iget-boolean v6, v0, Lc/P3;->F:Z

    if-nez v6, :cond_63

    iget-object v6, v0, Lc/P3;->f:Lc/o0;

    if-eqz v6, :cond_63

    iget-object v6, v6, Lc/o0;->c:Lc/m0;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v9

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v6, v9, v10}, Lc/m0;->a(FF)Z

    move-result v6

    if-nez v6, :cond_64

    iget-boolean v6, v0, Lc/P3;->L1:Z

    if-eqz v6, :cond_63

    iget-object v6, v0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v9

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v10

    invoke-virtual {v6, v9, v10}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v6

    if-nez v6, :cond_64

    :cond_63
    const/4 v1, 0x1

    goto/16 :goto_3c

    :cond_64
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v6

    iget v9, v0, Lc/P3;->F1:F

    sub-float/2addr v6, v9

    float-to-double v9, v6

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v6

    iget v12, v0, Lc/P3;->G1:F

    sub-float/2addr v6, v12

    float-to-double v7, v6

    invoke-static {v9, v10, v7, v8}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v6

    const/high16 v8, 0x41800000    # 16.0f

    invoke-virtual {v0, v8}, Lc/P3;->s(F)F

    move-result v8

    float-to-double v8, v8

    cmpl-double v6, v6, v8

    if-lez v6, :cond_65

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v6, 0x1

    return v6

    :cond_65
    const/4 v6, 0x1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    invoke-super/range {p0 .. p0}, Landroid/view/View;->performClick()Z

    iget-boolean v7, v0, Lc/P3;->Q0:Z

    if-eqz v7, :cond_66

    iput-boolean v11, v0, Lc/P3;->Q0:Z

    return v6

    :cond_66
    if-ltz v4, :cond_67

    invoke-virtual {v0, v4, v5}, Lc/P3;->U(II)V

    return v6

    :cond_67
    if-eqz v2, :cond_68

    invoke-virtual/range {p0 .. p0}, Lc/P3;->Z()V

    return v6

    :cond_68
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget-boolean v4, v0, Lc/P3;->y0:Z

    if-eqz v4, :cond_6a

    iget-object v4, v0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_6a

    iput-boolean v11, v0, Lc/P3;->y0:Z

    iget-object v1, v0, Lc/P3;->v0:Lc/U4;

    iput-wide v13, v1, Lc/U4;->c:J

    iget v2, v1, Lc/U4;->f:F

    const/high16 v3, 0x3f800000    # 1.0f

    cmpl-float v2, v2, v3

    if-nez v2, :cond_69

    goto :goto_27

    :cond_69
    invoke-virtual {v1, v13, v14}, Lc/U4;->a(J)F

    move-result v2

    iput v2, v1, Lc/U4;->e:F

    iput v3, v1, Lc/U4;->f:F

    iput-wide v13, v1, Lc/U4;->d:J

    :goto_27
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :cond_6a
    iget-object v4, v0, Lc/P3;->O1:Lc/s0;

    if-ne v4, v3, :cond_6c

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    instance-of v3, v3, Lru/drivedeck/launcher/MainActivity;

    if-eqz v3, :cond_6c

    iget-object v3, v0, Lc/P3;->n:Lc/G0;

    iget-object v3, v3, Lc/G0;->k:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_6b

    iget-object v1, v0, Lc/P3;->n:Lc/G0;

    iget-object v1, v1, Lc/G0;->k:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_6b

    iget-object v1, v0, Lc/P3;->n:Lc/G0;

    invoke-virtual {v1}, Lc/G0;->l()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    :goto_28
    const/4 v3, 0x1

    goto :goto_29

    :cond_6b
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    new-instance v2, Lc/K3;

    invoke-direct {v2, v0}, Lc/K3;-><init>(Lc/P3;)V

    invoke-static {v1, v2}, Lc/G8;->G0(Lru/drivedeck/launcher/MainActivity;Ljava/util/function/BooleanSupplier;)Landroid/app/Dialog;

    move-result-object v1

    iput-object v1, v0, Lc/P3;->P1:Landroid/app/Dialog;

    goto :goto_28

    :goto_29
    return v3

    :cond_6c
    const/4 v3, 0x1

    iget-object v4, v0, Lc/P3;->O1:Lc/s0;

    sget-object v5, Lc/s0;->h:Lc/s0;

    if-ne v4, v5, :cond_6d

    iget-object v4, v0, Lc/P3;->t1:Lc/g0;

    iget v5, v0, Lc/P3;->F1:F

    iget v6, v0, Lc/P3;->G1:F

    invoke-virtual {v4, v2, v1, v5, v6}, Lc/g0;->i(FFFF)Z

    move-result v4

    if-eqz v4, :cond_6d

    return v3

    :cond_6d
    move v3, v11

    :goto_2a
    iget-object v4, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_71

    iget-object v4, v0, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_70

    iget-object v1, v0, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/q5;

    iget-object v2, v0, Lc/P3;->h0:Lc/q5;

    invoke-virtual {v1, v2}, Lc/q5;->c(Lc/q5;)Z

    move-result v1

    if-eqz v1, :cond_6f

    iget-object v1, v0, Lc/P3;->h0:Lc/q5;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_1
    iget-object v3, v1, Lc/q5;->e:Landroid/app/Notification;

    iget-object v3, v3, Landroid/app/Notification;->contentIntent:Landroid/app/PendingIntent;

    if-eqz v3, :cond_6e

    invoke-virtual {v3}, Landroid/app/PendingIntent;->send()V

    goto :goto_2b

    :cond_6e
    iget-object v1, v1, Lc/q5;->a:Ljava/lang/String;

    invoke-static {v2, v1}, Lc/z;->l(Landroid/content/Context;Ljava/lang/String;)Lc/y;

    move-result-object v1

    if-eqz v1, :cond_6f

    iget-object v1, v1, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    const/high16 v3, 0x10000000

    invoke-virtual {v1, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_6f
    :goto_2b
    const/4 v1, 0x1

    return v1

    :cond_70
    add-int/lit8 v3, v3, 0x1

    goto :goto_2a

    :cond_71
    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->e0()Z

    move-result v3

    if-nez v3, :cond_78

    iget-object v3, v0, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_78

    iget-object v1, v0, Lc/P3;->E0:Landroid/graphics/RectF;

    iget v2, v0, Lc/P3;->F1:F

    iget v3, v0, Lc/P3;->G1:F

    invoke-virtual {v1, v2, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-nez v1, :cond_72

    const/4 v1, 0x1

    return v1

    :cond_72
    invoke-virtual/range {p0 .. p0}, Lc/P3;->Y()V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->n()Lc/V4;

    move-result-object v1

    if-nez v1, :cond_73

    const-string v1, "\u041f\u043b\u0435\u0435\u0440 \u043d\u0435 \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u00ab\u0412 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435\u00bb"

    goto :goto_2c

    :cond_73
    iget-object v2, v0, Lc/P3;->F0:Lc/V4;

    invoke-virtual {v1, v2}, Lc/V4;->e(Lc/V4;)Z

    move-result v2

    if-nez v2, :cond_74

    const-string v1, "\u0422\u0440\u0435\u043a \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u0441\u044f. \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437"

    goto :goto_2c

    :cond_74
    iget-boolean v2, v1, Lc/V4;->c:Z

    if-eqz v2, :cond_75

    const-string v1, "\u0422\u0440\u0435\u043a \u0443\u0436\u0435 \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u043c"

    goto :goto_2c

    :cond_75
    iget-object v2, v0, Lc/P3;->G0:Lc/V4;

    invoke-virtual {v1, v2}, Lc/V4;->e(Lc/V4;)Z

    move-result v2

    if-eqz v2, :cond_76

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, v0, Lc/P3;->H0:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x1388

    cmp-long v2, v2, v4

    if-gez v2, :cond_76

    const-string v1, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u0443\u0436\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0430 \u043f\u043b\u0435\u0435\u0440\u0443"

    goto :goto_2c

    :cond_76
    :try_start_2
    invoke-virtual {v1}, Lc/V4;->f()Z

    move-result v2

    if-eqz v2, :cond_77

    iput-object v1, v0, Lc/P3;->G0:Lc/V4;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, v0, Lc/P3;->H0:J

    const-string v1, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u00ab\u041d\u0440\u0430\u0432\u0438\u0442\u0441\u044f\u00bb \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0430 \u043f\u043b\u0435\u0435\u0440\u0443"

    goto :goto_2c

    :cond_77
    const-string v1, "\u0421\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0442\u0440\u0435\u043a\u0430 \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u043e\u0441\u044c. \u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437"
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    goto :goto_2c

    :catch_2
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0435\u0440\u0435\u0434\u0430\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u043f\u043b\u0435\u0435\u0440\u0443"

    :goto_2c
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-static {v3, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v3, 0x1

    return v3

    :cond_78
    const/4 v3, 0x1

    iget-object v4, v0, Lc/P3;->D0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_7a

    iget-object v1, v0, Lc/P3;->K:Lc/a5;

    if-eqz v1, :cond_79

    invoke-virtual/range {p0 .. p0}, Lc/P3;->p()V

    return v3

    :cond_79
    invoke-virtual/range {p0 .. p0}, Lc/P3;->h0()V

    return v3

    :cond_7a
    iget-object v3, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-nez v3, :cond_7c

    iget-object v3, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-nez v3, :cond_7c

    iget-object v3, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_7b

    goto :goto_2d

    :cond_7b
    move v3, v11

    goto :goto_2e

    :cond_7c
    :goto_2d
    const/4 v3, 0x1

    :goto_2e
    iget-object v4, v0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    const-string v5, "music_tap_to_open"

    if-eqz v4, :cond_7e

    if-nez v3, :cond_7e

    iget-boolean v4, v0, Lc/P3;->L1:Z

    if-nez v4, :cond_7d

    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    iget-object v4, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    const/4 v6, 0x1

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    if-nez v4, :cond_7e

    goto :goto_2f

    :cond_7d
    const/4 v6, 0x1

    :goto_2f
    return v6

    :cond_7e
    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->l0()Z

    move-result v4

    if-eqz v4, :cond_82

    iget-object v4, v0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_82

    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->D()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-nez v4, :cond_81

    iget-object v4, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_7f

    goto :goto_31

    :cond_7f
    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v2, 0x1

    invoke-interface {v1, v5, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_80

    iget-object v1, v0, Lc/P3;->b0:Lc/y;

    invoke-virtual {v1, v3}, Lc/y;->b(Ljava/lang/String;)V

    :cond_80
    :goto_30
    const/4 v1, 0x1

    goto :goto_32

    :cond_81
    :goto_31
    iget-object v3, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    invoke-virtual {v0, v1}, Lc/P3;->q(Z)V

    goto :goto_30

    :goto_32
    return v1

    :cond_82
    iget-object v4, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v4, :cond_83

    const/4 v8, 0x0

    goto :goto_33

    :cond_83
    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v8

    :goto_33
    iget-object v4, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->e0()Z

    move-result v4

    if-eqz v4, :cond_84

    iget-object v4, v0, Lc/P3;->y1:Lc/P;

    iget-boolean v4, v4, Lc/P;->n:Z

    goto :goto_34

    :cond_84
    iget-object v4, v0, Lc/P3;->o1:Lc/w8;

    if-eqz v4, :cond_85

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Lc/w8;->b(J)Z

    move-result v4

    goto :goto_34

    :cond_85
    if-eqz v8, :cond_86

    invoke-virtual {v8}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v5, 0x3

    if-ne v4, v5, :cond_86

    const/4 v4, 0x1

    goto :goto_34

    :cond_86
    move v4, v11

    :goto_34
    iget-object v5, v0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v5, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v5

    if-eqz v5, :cond_89

    if-nez v3, :cond_89

    if-nez v4, :cond_89

    iget-object v1, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_88

    iget-object v2, v0, Lc/P3;->a0:Lc/z;

    invoke-virtual {v2, v1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v2

    if-nez v2, :cond_87

    goto :goto_36

    :cond_87
    iget-object v2, v0, Lc/P3;->b0:Lc/y;

    invoke-virtual {v2, v1}, Lc/y;->b(Ljava/lang/String;)V

    :goto_35
    const/4 v1, 0x1

    goto :goto_37

    :cond_88
    :goto_36
    iget-object v1, v0, Lc/P3;->b0:Lc/y;

    invoke-virtual {v1}, Lc/y;->a()V

    goto :goto_35

    :goto_37
    return v1

    :cond_89
    iget-object v3, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_8a

    invoke-static {}, Lc/G8;->l()V

    :cond_8a
    iget-object v3, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->e0()Z

    move-result v3

    if-eqz v3, :cond_8e

    iget-object v3, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_8b

    invoke-virtual {v0, v11}, Lc/P3;->q(Z)V

    const/4 v3, 0x1

    goto :goto_38

    :cond_8b
    iget-object v3, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_8c

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lc/P3;->q(Z)V

    goto :goto_38

    :cond_8c
    const/4 v3, 0x1

    iget-object v4, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_8d

    iget-object v1, v0, Lc/P3;->y1:Lc/P;

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Lc/P;->a(I)V

    :cond_8d
    :goto_38
    return v3

    :cond_8e
    iget-object v3, v0, Lc/P3;->o1:Lc/w8;

    if-eqz v3, :cond_93

    iget-object v3, v0, Lc/P3;->B0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_8f

    iget-object v1, v0, Lc/P3;->b0:Lc/y;

    const-string v2, "com.syu.music"

    invoke-virtual {v1, v2}, Lc/y;->b(Ljava/lang/String;)V

    :goto_39
    const/4 v3, 0x1

    goto :goto_3a

    :cond_8f
    iget-object v3, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_90

    invoke-virtual {v0, v11}, Lc/P3;->q(Z)V

    goto :goto_39

    :cond_90
    iget-object v3, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_91

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lc/P3;->q(Z)V

    goto :goto_3a

    :cond_91
    const/4 v3, 0x1

    iget-object v4, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_92

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "playpause"

    invoke-static {v1, v2}, Lru/drivedeck/launcher/StockMusicService;->a(Landroid/content/Context;Ljava/lang/String;)Z

    :cond_92
    :goto_3a
    return v3

    :cond_93
    const/4 v3, 0x1

    iget-object v4, v0, Lc/P3;->B0:Landroid/graphics/RectF;

    invoke-virtual {v4, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    if-eqz v4, :cond_94

    iget-object v4, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v4, :cond_94

    iget-object v1, v0, Lc/P3;->b0:Lc/y;

    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lc/y;->b(Ljava/lang/String;)V

    return v3

    :cond_94
    iget-object v3, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v3, :cond_98

    iget-object v3, v0, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_95

    invoke-virtual {v0, v11}, Lc/P3;->q(Z)V

    goto :goto_3b

    :cond_95
    iget-object v3, v0, Lc/P3;->K0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_96

    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lc/P3;->q(Z)V

    goto :goto_3b

    :cond_96
    iget-object v3, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_99

    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    if-eqz v1, :cond_97

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v1

    const/4 v2, 0x3

    if-ne v1, v2, :cond_97

    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v1

    invoke-virtual {v1}, Landroid/media/session/MediaController$TransportControls;->pause()V

    goto :goto_3b

    :cond_97
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lc/i;

    const/16 v5, 0x8

    invoke-direct {v4, v2, v5}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-static {v1, v3, v4}, Lc/G8;->X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_3b

    :cond_98
    iget-object v3, v0, Lc/P3;->J0:Landroid/graphics/RectF;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_99

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, v0, Lc/P3;->C1:Lc/n1;

    invoke-static {v1, v2}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v1}, Lc/G8;->p0(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_99

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2, v1}, Lc/G8;->Y(Landroid/content/Context;Ljava/lang/String;)V

    :cond_99
    :goto_3b
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x1

    return v1

    :goto_3c
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    return v1
.end method

.method public final onVisibilityChanged(Landroid/view/View;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/view/View;->onVisibilityChanged(Landroid/view/View;I)V

    iget-boolean p1, p0, Lc/P3;->L1:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Lc/P3;->y1:Lc/P;

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getWindowVisibility()I

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p1}, Lc/P3;->f0(Z)V

    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result p1

    if-nez p1, :cond_2

    iget p1, p0, Lc/P3;->R1:I

    const/4 p2, -0x1

    if-eq p1, p2, :cond_2

    iput p2, p0, Lc/P3;->R1:I

    const/high16 p2, 0x10000

    invoke-virtual {p0, p1, p2}, Lc/P3;->e0(II)V

    :cond_2
    return-void
.end method

.method public final onWindowVisibilityChanged(I)V
    .locals 1

    invoke-super {p0, p1}, Landroid/view/View;->onWindowVisibilityChanged(I)V

    iget-boolean v0, p0, Lc/P3;->L1:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/P3;->y1:Lc/P;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {p0, p1}, Lc/P3;->f0(Z)V

    :cond_1
    return-void
.end method

.method public final p()V
    .locals 5

    iget-object v0, p0, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    iget-object v1, p0, Lc/P3;->K:Lc/a5;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    const/4 v0, 0x0

    iput-object v0, p0, Lc/P3;->K:Lc/a5;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-object v2, p0, Lc/P3;->v0:Lc/U4;

    iput-wide v0, v2, Lc/U4;->c:J

    iget v3, v2, Lc/U4;->f:F

    const/high16 v4, 0x3f800000    # 1.0f

    cmpl-float v3, v3, v4

    if-nez v3, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v2, v0, v1}, Lc/U4;->a(J)F

    move-result v3

    iput v3, v2, Lc/U4;->e:F

    iput v4, v2, Lc/U4;->f:F

    iput-wide v0, v2, Lc/U4;->d:J

    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final performClick()Z
    .locals 1

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 v0, 0x1

    return v0
.end method

.method public final q(Z)V
    .locals 2

    iget-object v0, p0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v1

    if-nez v1, :cond_1

    iget-boolean v1, p0, Lc/P3;->L1:Z

    if-nez v1, :cond_0

    invoke-virtual {v0}, Lc/n1;->k0()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    new-instance v0, Lc/K1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p1, v1}, Lc/K1;-><init>(Ljava/lang/Object;ZI)V

    iget-object v1, p0, Lc/P3;->N1:Lc/g5;

    invoke-virtual {v1, p1, v0}, Lc/g5;->k(ZLjava/lang/Runnable;)Z

    return-void

    :cond_1
    invoke-virtual {p0, p1}, Lc/P3;->r(Z)Z

    return-void
.end method

.method public final r(Z)Z
    .locals 6

    invoke-static {}, Lc/G8;->l()V

    iget-object v0, p0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Lc/n1;->D()Ljava/lang/String;

    move-result-object v0

    const-string v1, "com.syu.radio"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v0, p0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v0, :cond_1

    if-eqz p1, :cond_0

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/session/MediaController$TransportControls;->skipToNext()V

    const/4 v3, 0x1

    return v3

    :cond_0
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/session/MediaController$TransportControls;->skipToPrevious()V

    const/4 v3, 0x1

    return v3

    :cond_1
    const/4 v3, 0x0

    return v3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0440\u0430\u0434\u0438\u043e \u043d\u0435 \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u043b\u044f\u0435\u0442 \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0441\u0442\u0430\u043d\u0446\u0438\u0439"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    return v3

    :cond_2
    invoke-virtual {v0}, Lc/n1;->e0()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/P3;->y1:Lc/P;

    invoke-virtual {v0, p1}, Lc/P;->a(I)V

    return v3

    :cond_3
    iget-object v0, p0, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    if-eqz p1, :cond_4

    const-string p1, "next"

    goto :goto_0

    :cond_4
    const-string p1, "prev"

    :goto_0
    invoke-static {v0, p1}, Lru/drivedeck/launcher/StockMusicService;->a(Landroid/content/Context;Ljava/lang/String;)Z

    return v3

    :cond_5
    iget-object v0, p0, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-eqz v0, :cond_7

    if-eqz p1, :cond_6

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/session/MediaController$TransportControls;->skipToNext()V

    goto :goto_1

    :cond_6
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/session/MediaController$TransportControls;->skipToPrevious()V

    :goto_1
    return v3

    :cond_7
    return v2
.end method

.method public final s(F)F
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final t(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 33

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    const/4 v11, 0x4

    const/4 v12, 0x0

    const/4 v0, 0x2

    const/4 v13, 0x1

    iget-object v14, v8, Lc/P3;->C:Lc/A8;

    if-nez v14, :cond_0

    return-void

    :cond_0
    iget-boolean v1, v14, Lc/A8;->e:Z

    iget-boolean v2, v14, Lc/A8;->b:Z

    add-int/2addr v1, v2

    iget-boolean v2, v14, Lc/A8;->c:Z

    add-int/2addr v1, v2

    add-int/2addr v1, v13

    iget-object v2, v8, Lc/P3;->e:Lc/u0;

    iget-object v2, v2, Lc/u0;->c:Ljava/lang/Object;

    check-cast v2, Lc/q0;

    sget-object v3, Lc/h0;->k:Landroid/graphics/Typeface;

    sget-object v3, Lc/q0;->b:Lc/q0;

    sget-object v4, Lc/q0;->a:Lc/q0;

    if-ne v2, v3, :cond_1

    const/high16 v3, 0x43520000    # 210.0f

    goto :goto_0

    :cond_1
    if-ne v2, v4, :cond_2

    const/high16 v3, 0x435c0000    # 220.0f

    goto :goto_0

    :cond_2
    const/high16 v3, 0x43700000    # 240.0f

    :goto_0
    sget-object v5, Lc/q0;->c:Lc/q0;

    if-ne v2, v4, :cond_3

    const/high16 v2, 0x43080000    # 136.0f

    :goto_1
    move v15, v2

    goto :goto_2

    :cond_3
    if-ne v2, v5, :cond_4

    const/high16 v2, 0x430e0000    # 142.0f

    goto :goto_1

    :cond_4
    const/high16 v2, 0x41700000    # 15.0f

    goto :goto_1

    :goto_2
    sub-float/2addr v3, v15

    const/high16 v2, 0x41400000    # 12.0f

    sub-float/2addr v3, v2

    const/high16 v2, 0x42f00000    # 120.0f

    cmpg-float v2, v3, v2

    if-gez v2, :cond_5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v2

    move v7, v2

    goto :goto_3

    :cond_5
    move v7, v1

    :goto_3
    if-ge v7, v1, :cond_6

    move/from16 v16, v13

    goto :goto_4

    :cond_6
    move/from16 v16, v12

    :goto_4
    int-to-float v1, v7

    div-float/2addr v3, v1

    iget-object v1, v14, Lc/A8;->h:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    const-string v1, "\u2014"

    goto :goto_5

    :cond_7
    iget-object v1, v14, Lc/A8;->h:Ljava/lang/String;

    :goto_5
    iget-object v2, v14, Lc/A8;->i:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_8

    const-string v2, "Wi-Fi"

    goto :goto_6

    :cond_8
    iget-object v2, v14, Lc/A8;->i:Ljava/lang/String;

    :goto_6
    const-string v6, "VPN"

    invoke-virtual/range {p0 .. p0}, Lc/P3;->m()Ljava/lang/String;

    move-result-object v10

    filled-new-array {v1, v2, v6, v10}, [Ljava/lang/String;

    move-result-object v10

    iget v1, v14, Lc/A8;->f:I

    invoke-static {v1}, Lc/A8;->a(I)I

    move-result v1

    iget v2, v14, Lc/A8;->g:I

    invoke-static {v2}, Lc/A8;->e(I)I

    move-result v2

    const v6, 0x7f0300a0

    const v0, 0x7f030092

    filled-new-array {v1, v2, v6, v0}, [I

    move-result-object v19

    iget-boolean v0, v14, Lc/A8;->e:Z

    iget-boolean v1, v14, Lc/A8;->b:Z

    iget-boolean v2, v14, Lc/A8;->c:Z

    new-array v6, v11, [Z

    aput-boolean v0, v6, v12

    aput-boolean v1, v6, v13

    const/4 v0, 0x2

    aput-boolean v2, v6, v0

    const/4 v0, 0x3

    aput-boolean v13, v6, v0

    iget-object v0, v8, Lc/P3;->e:Lc/u0;

    iget-object v0, v0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v0, Lc/q0;

    if-ne v0, v4, :cond_9

    move/from16 v18, v13

    goto :goto_7

    :cond_9
    move/from16 v18, v12

    :goto_7
    if-eqz v16, :cond_b

    if-eqz v18, :cond_a

    const/16 v0, 0xc

    goto :goto_8

    :cond_a
    const/16 v0, 0xe

    :goto_8
    int-to-float v0, v0

    :goto_9
    move/from16 v20, v0

    goto :goto_a

    :cond_b
    const/high16 v0, 0x41a00000    # 20.0f

    goto :goto_9

    :goto_a
    const/high16 v0, 0x40c00000    # 6.0f

    sub-float v1, v3, v0

    if-eqz v16, :cond_d

    if-eqz v18, :cond_c

    const/4 v4, 0x7

    goto :goto_b

    :cond_c
    const/16 v4, 0x8

    :goto_b
    int-to-float v4, v4

    goto :goto_c

    :cond_d
    const/high16 v4, 0x41200000    # 10.0f

    :goto_c
    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    sget-object v2, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    move v0, v12

    move/from16 v23, v0

    move/from16 v2, v20

    move v13, v2

    :goto_d
    if-ge v0, v11, :cond_10

    aget-boolean v25, v6, v0

    if-eqz v25, :cond_f

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v11

    aget-object v12, v10, v0

    invoke-static {v11, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget-object v12, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v12, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v12, v8, Lc/P3;->N:Landroid/graphics/Paint;

    move-object/from16 v27, v10

    invoke-virtual {v12, v11}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v10

    move-object/from16 v28, v14

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-static {v14, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    div-float v10, v1, v10

    invoke-static {v14, v10}, Ljava/lang/Math;->min(FF)F

    move-result v10

    mul-float/2addr v10, v4

    invoke-virtual {v12, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v10, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v12

    iget-object v14, v8, Lc/P3;->W1:Landroid/graphics/Rect;

    move/from16 v29, v1

    const/4 v1, 0x0

    invoke-virtual {v10, v11, v1, v12, v14}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    iget-object v1, v8, Lc/P3;->W1:Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    move-result v1

    int-to-float v1, v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    rem-int v10, v23, v7

    if-nez v10, :cond_e

    invoke-static {v13, v1}, Ljava/lang/Math;->max(FF)F

    move-result v13

    :cond_e
    const/4 v1, 0x1

    add-int/lit8 v23, v23, 0x1

    goto :goto_e

    :cond_f
    move/from16 v29, v1

    move-object/from16 v27, v10

    move-object/from16 v28, v14

    const/4 v1, 0x1

    :goto_e
    add-int/2addr v0, v1

    move-object/from16 v10, v27

    move-object/from16 v14, v28

    move/from16 v1, v29

    const/4 v11, 0x4

    goto :goto_d

    :cond_10
    move-object/from16 v27, v10

    move-object/from16 v28, v14

    const/high16 v0, 0x41200000    # 10.0f

    add-float/2addr v2, v0

    invoke-static {v3, v2}, Ljava/lang/Math;->min(FF)F

    move-result v10

    const/high16 v0, 0x40c00000    # 6.0f

    sub-float v11, v10, v0

    iget-object v0, v8, Lc/P3;->h:Lc/h0;

    iget-object v1, v8, Lc/P3;->e:Lc/u0;

    iget-object v1, v1, Lc/u0;->c:Ljava/lang/Object;

    check-cast v1, Lc/q0;

    move-object/from16 v2, p2

    invoke-virtual {v0, v9, v2, v1}, Lc/h0;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;)I

    move-result v12

    iget-object v0, v8, Lc/P3;->e:Lc/u0;

    iget-object v0, v0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v0, Lc/q0;

    if-ne v0, v5, :cond_11

    const/4 v0, 0x0

    const/high16 v1, -0x3e300000    # -26.0f

    invoke-virtual {v9, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_11
    const/4 v5, 0x4

    const/4 v14, 0x0

    const/16 v21, 0x0

    :goto_f
    if-ge v14, v5, :cond_1c

    aget-boolean v0, v6, v14

    if-eqz v0, :cond_1b

    const/high16 v22, 0x40000000    # 2.0f

    div-float v0, v13, v22

    add-float/2addr v0, v15

    rem-int v1, v21, v7

    int-to-float v1, v1

    mul-float/2addr v1, v10

    add-float v23, v1, v0

    if-eqz v16, :cond_13

    div-int v0, v21, v7

    if-eqz v18, :cond_12

    mul-int/lit8 v0, v0, 0x12

    add-int/lit8 v0, v0, 0x65

    goto :goto_10

    :cond_12
    mul-int/lit8 v0, v0, 0x18

    add-int/lit8 v0, v0, 0x73

    :goto_10
    int-to-float v0, v0

    move/from16 v17, v0

    const/4 v3, 0x3

    goto :goto_11

    :cond_13
    if-eqz v18, :cond_14

    const/16 v0, 0x6e

    goto :goto_10

    :cond_14
    const/16 v0, 0x82

    goto :goto_10

    :goto_11
    move-object/from16 v2, v28

    if-ne v14, v3, :cond_16

    iget-boolean v0, v2, Lc/A8;->k:Z

    if-nez v0, :cond_16

    iget-boolean v0, v2, Lc/A8;->d:Z

    if-nez v0, :cond_16

    iget-object v0, v8, Lc/P3;->z1:Lc/x7;

    iget-boolean v0, v0, Lc/x7;->e:Z

    if-nez v0, :cond_16

    iget-object v0, v8, Lc/P3;->y1:Lc/P;

    iget-boolean v0, v0, Lc/P;->o:Z

    if-nez v0, :cond_16

    iget-object v0, v8, Lc/P3;->y1:Lc/P;

    iget-object v0, v0, Lc/P;->a:Lc/K;

    iget-boolean v0, v0, Lc/K;->f:Z

    if-eqz v0, :cond_15

    goto :goto_12

    :cond_15
    const/4 v1, 0x0

    goto :goto_13

    :cond_16
    :goto_12
    const/4 v1, 0x1

    :goto_13
    aget v25, v19, v14

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    if-eqz v1, :cond_17

    iget v0, v0, Lc/r4;->d:I

    :goto_14
    move/from16 v28, v0

    goto :goto_15

    :cond_17
    iget v0, v0, Lc/r4;->e:I

    goto :goto_14

    :goto_15
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v29, v2

    move/from16 v2, v25

    move/from16 v25, v3

    move/from16 v3, v23

    move/from16 v30, v7

    move v7, v4

    move/from16 v4, v17

    move/from16 v31, v5

    move/from16 v5, v20

    move-object/from16 v32, v6

    move/from16 v6, v28

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    aget-object v1, v27, v14

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    sget-object v1, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v0, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v6, v11}, Ljava/lang/Math;->max(FF)F

    move-result v0

    mul-float/2addr v0, v7

    iget-object v1, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    invoke-static {v6, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    div-float/2addr v0, v1

    invoke-static {v7, v0}, Ljava/lang/Math;->min(FF)F

    move-result v5

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v0, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v0, v8, Lc/P3;->N:Landroid/graphics/Paint;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v1

    iget-object v3, v8, Lc/P3;->W1:Landroid/graphics/Rect;

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v4, v1, v3}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    if-eqz v16, :cond_19

    if-eqz v18, :cond_18

    const/16 v0, 0x9

    goto :goto_16

    :cond_18
    const/16 v0, 0xd

    :goto_16
    int-to-float v0, v0

    add-float v17, v17, v0

    goto :goto_18

    :cond_19
    if-eqz v18, :cond_1a

    iget-object v0, v8, Lc/P3;->W1:Landroid/graphics/Rect;

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    rsub-int v0, v0, 0x83

    goto :goto_17

    :cond_1a
    const/16 v0, 0x97

    :goto_17
    int-to-float v0, v0

    move/from16 v17, v0

    :goto_18
    iget-object v0, v8, Lc/P3;->W1:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v0, v0, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v0

    int-to-float v0, v1

    div-float v0, v0, v22

    sub-float v3, v23, v0

    iget-object v0, v8, Lc/P3;->c0:Lc/r4;

    iget v1, v0, Lc/r4;->d:I

    const/16 v22, 0x0

    move-object/from16 v0, p0

    move/from16 v23, v1

    move-object/from16 v1, p1

    move/from16 v24, v4

    move/from16 v4, v17

    move/from16 v17, v6

    move/from16 v6, v23

    move/from16 v26, v7

    move/from16 v23, v30

    move/from16 v7, v22

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    const/4 v0, 0x1

    add-int/lit8 v21, v21, 0x1

    goto :goto_19

    :cond_1b
    move/from16 v26, v4

    move/from16 v31, v5

    move-object/from16 v32, v6

    move/from16 v23, v7

    move-object/from16 v29, v28

    const/4 v0, 0x1

    const/high16 v17, 0x3f800000    # 1.0f

    const/16 v24, 0x0

    const/16 v25, 0x3

    :goto_19
    add-int/2addr v14, v0

    move/from16 v7, v23

    move/from16 v4, v26

    move-object/from16 v28, v29

    move/from16 v5, v31

    move-object/from16 v6, v32

    goto/16 :goto_f

    :cond_1c
    invoke-virtual {v9, v12}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method

.method public final u(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V
    .locals 5

    iget-object v0, p0, Lc/P3;->N:Landroid/graphics/Paint;

    sget-object v1, Lc/P3;->Y1:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p7}, Landroid/graphics/Paint;->setColor(I)V

    if-eqz p8, :cond_0

    const/high16 p7, 0x40200000    # 2.5f

    invoke-virtual {p0, p7}, Lc/P3;->s(F)F

    move-result p7

    const/high16 p8, 0x3f800000    # 1.0f

    invoke-virtual {p0, p8}, Lc/P3;->s(F)F

    move-result p8

    const/high16 v1, -0x50000000

    const/4 v2, 0x0

    invoke-virtual {v0, p7, v2, p8, v1}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/graphics/Paint;->clearShadowLayer()V

    :goto_0
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p7

    cmpg-float p8, p7, p5

    if-gtz p8, :cond_1

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/Paint;->clearShadowLayer()V

    return-void

    :cond_1
    const/high16 p8, 0x42400000    # 48.0f

    invoke-virtual {p0, p8}, Lc/P3;->s(F)F

    move-result p8

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    long-to-float v1, v1

    const/high16 v2, 0x42000000    # 32.0f

    invoke-virtual {p0, v2}, Lc/P3;->s(F)F

    move-result v2

    mul-float/2addr v2, v1

    const/high16 v1, 0x447a0000    # 1000.0f

    div-float/2addr v2, v1

    add-float v1, p7, p8

    rem-float/2addr v2, v1

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    const v3, 0x3f99999a    # 1.2f

    mul-float/2addr v3, p6

    sub-float v3, p4, v3

    add-float/2addr p5, p3

    const v4, 0x3eb33333    # 0.35f

    mul-float/2addr p6, v4

    add-float/2addr p6, p4

    invoke-virtual {p1, p3, v3, p5, p6}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    sub-float/2addr p3, v2

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    add-float/2addr p3, p7

    add-float/2addr p3, p8

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual {v0}, Landroid/graphics/Paint;->clearShadowLayer()V

    const-wide/16 p1, 0x20

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->postInvalidateDelayed(J)V

    return-void
.end method

.method public final v(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 76

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    const-string v7, "music_auto_hide_keep_title"

    iget-object v15, v9, Lc/P3;->J0:Landroid/graphics/RectF;

    iget-object v3, v9, Lc/P3;->a0:Lc/z;

    const-string v16, "com.syu.music"

    iget-object v1, v9, Lc/P3;->N:Landroid/graphics/Paint;

    iget-boolean v0, v9, Lc/P3;->L1:Z

    iget-object v8, v9, Lc/P3;->n0:Landroid/graphics/RectF;

    iget-object v13, v9, Lc/P3;->L:Landroid/graphics/RectF;

    iget-object v12, v9, Lc/P3;->D0:Landroid/graphics/RectF;

    iget-object v14, v9, Lc/P3;->P:Landroid/text/TextPaint;

    const v25, 0x7f030096

    const v26, 0x7f030092

    iget-object v6, v9, Lc/P3;->B0:Landroid/graphics/RectF;

    iget-object v2, v9, Lc/P3;->C0:Landroid/graphics/RectF;

    move-object/from16 v29, v7

    const/high16 v31, 0x42180000    # 38.0f

    iget-object v4, v9, Lc/P3;->N1:Lc/g5;

    const/4 v7, 0x0

    iget-object v5, v9, Lc/P3;->C1:Lc/n1;

    if-eqz v0, :cond_23

    invoke-virtual {v2, v11}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v6}, Landroid/graphics/RectF;->setEmpty()V

    iput-boolean v7, v9, Lc/P3;->w0:Z

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, v9, Lc/P3;->A0:F

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v6

    const/high16 v0, 0x41c00000    # 24.0f

    mul-float v2, v6, v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const v17, 0x3d23d70a    # 0.04f

    mul-float v0, v0, v17

    invoke-static {v2, v0}, Ljava/lang/Math;->min(FF)F

    move-result v17

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v18, 0x44160000    # 600.0f

    mul-float v18, v18, v6

    cmpl-float v0, v0, v18

    if-ltz v0, :cond_0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v18

    const v19, 0x3f933333    # 1.15f

    mul-float v18, v18, v19

    cmpl-float v0, v0, v18

    if-lez v0, :cond_0

    const/16 v18, 0x1

    :goto_0
    const/high16 v42, 0x42400000    # 48.0f

    goto :goto_1

    :cond_0
    move/from16 v18, v7

    goto :goto_0

    :goto_1
    mul-float v0, v6, v42

    iget v7, v11, Landroid/graphics/RectF;->bottom:F

    const/high16 v44, 0x41000000    # 8.0f

    mul-float v19, v6, v44

    sub-float v7, v7, v19

    sub-float v27, v7, v0

    if-eqz v18, :cond_1

    move/from16 v7, v27

    goto :goto_2

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v7

    int-to-float v7, v7

    sub-float v7, v7, v19

    sub-float/2addr v7, v0

    :goto_2
    if-eqz v18, :cond_2

    move-object/from16 v45, v1

    iget v1, v11, Landroid/graphics/RectF;->top:F

    sub-float v1, v7, v1

    sub-float v1, v1, v17

    const/high16 v19, 0x41800000    # 16.0f

    mul-float v29, v6, v19

    sub-float v1, v1, v29

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v19

    const v29, 0x3eb851ec    # 0.36f

    move/from16 v46, v2

    mul-float v2, v19, v29

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    :goto_3
    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_4

    :cond_2
    move-object/from16 v45, v1

    move/from16 v46, v2

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x40000000    # 2.0f

    mul-float v19, v17, v2

    sub-float v1, v1, v19

    const v2, 0x3f3d70a4    # 0.74f

    mul-float/2addr v1, v2

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    const v19, 0x3ee147ae    # 0.44f

    mul-float v2, v2, v19

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    goto :goto_3

    :goto_4
    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const/high16 v19, 0x3e800000    # 0.25f

    if-eqz v18, :cond_3

    iget v2, v11, Landroid/graphics/RectF;->left:F

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v29

    mul-float v29, v29, v19

    add-float v29, v29, v2

    const/high16 v38, 0x40000000    # 2.0f

    div-float v2, v1, v38

    sub-float v29, v29, v2

    :goto_5
    move/from16 v2, v29

    goto :goto_6

    :cond_3
    const/high16 v38, 0x40000000    # 2.0f

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    div-float v29, v1, v38

    sub-float v29, v2, v29

    goto :goto_5

    :goto_6
    if-eqz v18, :cond_4

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerY()F

    move-result v29

    div-float v42, v1, v38

    move/from16 v47, v0

    sub-float v0, v29, v42

    const/high16 v29, 0x41800000    # 16.0f

    mul-float v42, v6, v29

    sub-float v29, v7, v42

    move-object/from16 v48, v3

    sub-float v3, v29, v1

    invoke-static {v0, v3}, Ljava/lang/Math;->min(FF)F

    move-result v0

    goto :goto_7

    :cond_4
    move/from16 v47, v0

    move-object/from16 v48, v3

    iget v0, v11, Landroid/graphics/RectF;->top:F

    add-float v0, v0, v17

    :goto_7
    add-float v3, v2, v1

    add-float/2addr v1, v0

    invoke-virtual {v8, v2, v0, v3, v1}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->R()Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_5

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_5

    const/4 v0, 0x1

    goto :goto_8

    :cond_5
    const/4 v0, 0x0

    :goto_8
    iput-boolean v0, v9, Lc/P3;->o0:Z

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget-object v1, v9, Lc/P3;->M1:Lc/b5;

    iget-object v3, v1, Lc/b5;->p:Lc/r4;

    if-ne v3, v0, :cond_8

    iget-object v0, v1, Lc/b5;->h:Landroid/graphics/Bitmap;

    if-ne v0, v2, :cond_8

    iget v0, v1, Lc/b5;->j:I

    if-eqz v2, :cond_7

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v3

    if-eqz v3, :cond_6

    goto :goto_9

    :cond_6
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getGenerationId()I

    move-result v3

    goto :goto_a

    :cond_7
    :goto_9
    const/4 v3, 0x0

    :goto_a
    if-eq v0, v3, :cond_9

    :cond_8
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_9

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/View;

    if-eqz v0, :cond_9

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    invoke-interface {v0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_9
    new-instance v0, Landroid/graphics/RectF;

    iget v3, v8, Landroid/graphics/RectF;->top:F

    move/from16 v29, v7

    const/high16 v41, 0x41800000    # 16.0f

    mul-float v7, v6, v41

    sub-float/2addr v3, v7

    if-eqz v18, :cond_a

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerX()F

    move-result v41

    move-object/from16 v50, v14

    move-object/from16 v49, v15

    move/from16 v15, v41

    goto :goto_b

    :cond_a
    move-object/from16 v49, v15

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v15

    int-to-float v15, v15

    move-object/from16 v50, v14

    :goto_b
    iget v14, v8, Landroid/graphics/RectF;->bottom:F

    add-float/2addr v14, v7

    move/from16 v41, v7

    const/4 v7, 0x0

    invoke-direct {v0, v7, v3, v15, v14}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v5}, Lc/n1;->l0()Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {v1, v10, v8, v6}, Lc/b5;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;F)V

    iget-boolean v0, v9, Lc/P3;->o0:Z

    if-eqz v0, :cond_b

    const/4 v7, 0x0

    const/4 v14, 0x0

    iget-object v0, v9, Lc/P3;->l0:Lc/T4;

    const/4 v15, 0x0

    move/from16 v4, v47

    const/high16 v3, 0x42800000    # 64.0f

    move-object/from16 v51, v45

    move-object/from16 v1, p1

    const/high16 v19, 0x3f800000    # 1.0f

    move-object/from16 v52, v48

    move-object v3, v8

    move/from16 v53, v4

    move/from16 v4, v46

    move-object/from16 v20, v5

    move v5, v15

    move v15, v6

    move v6, v7

    move-object/from16 v28, v13

    move/from16 v54, v29

    move/from16 v55, v41

    const/4 v13, 0x0

    move v7, v14

    invoke-virtual/range {v0 .. v7}, Lc/T4;->a(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FIIZ)V

    :goto_c
    move-object/from16 v30, v12

    move/from16 v6, v53

    const/4 v2, 0x2

    const/4 v14, 0x0

    goto/16 :goto_12

    :cond_b
    move-object/from16 v20, v5

    move v15, v6

    move-object/from16 v28, v13

    move/from16 v54, v29

    move/from16 v55, v41

    move-object/from16 v51, v45

    move/from16 v53, v47

    move-object/from16 v52, v48

    const/4 v13, 0x0

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->b:I

    move/from16 v14, v46

    invoke-virtual {v9, v10, v8, v14, v0}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    invoke-virtual {v9, v10, v8}, Lc/P3;->z(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    goto :goto_c

    :cond_c
    move-object/from16 v20, v5

    move v15, v6

    move-object/from16 v28, v13

    move/from16 v54, v29

    move/from16 v55, v41

    move-object/from16 v51, v45

    move/from16 v14, v46

    move/from16 v53, v47

    move-object/from16 v52, v48

    const/4 v13, 0x0

    iput-boolean v13, v4, Lc/g5;->D:Z

    iget-object v2, v4, Lc/g5;->b:Landroid/graphics/RectF;

    invoke-virtual {v2, v8}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object v3, v4, Lc/g5;->c:Landroid/graphics/RectF;

    invoke-virtual {v3, v0}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v3

    const v5, 0x3f428f5c    # 0.76f

    mul-float/2addr v3, v5

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v5

    const/high16 v7, 0x40000000    # 2.0f

    div-float/2addr v5, v7

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float v2, v2, v19

    sub-float/2addr v5, v2

    invoke-static {v3, v5}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iput v2, v4, Lc/g5;->z:F

    iget v2, v4, Lc/g5;->h:F

    iget v3, v0, Landroid/graphics/RectF;->left:F

    cmpl-float v2, v2, v3

    iget-object v5, v4, Lc/g5;->g:Landroid/graphics/Paint;

    if-nez v2, :cond_e

    iget v2, v4, Lc/g5;->i:F

    iget v6, v0, Landroid/graphics/RectF;->right:F

    cmpl-float v2, v2, v6

    if-eqz v2, :cond_d

    goto :goto_e

    :cond_d
    move-object/from16 v30, v12

    move/from16 v46, v14

    move/from16 v6, v53

    const/4 v2, 0x2

    :goto_d
    const/4 v14, 0x0

    goto :goto_f

    :cond_e
    :goto_e
    iput v3, v4, Lc/g5;->h:F

    iget v2, v0, Landroid/graphics/RectF;->right:F

    iput v2, v4, Lc/g5;->i:F

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v2

    const v3, 0x3df5c28f    # 0.12f

    mul-float/2addr v2, v3

    move/from16 v6, v53

    invoke-static {v6, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v3

    div-float/2addr v2, v3

    new-instance v3, Landroid/graphics/LinearGradient;

    iget v7, v4, Lc/g5;->h:F

    move/from16 v46, v14

    iget v14, v4, Lc/g5;->i:F

    move-object/from16 v30, v12

    const/4 v12, -0x1

    filled-new-array {v13, v12, v12, v13}, [I

    move-result-object v61

    const/high16 v12, 0x3f800000    # 1.0f

    sub-float v19, v12, v2

    const/4 v12, 0x4

    new-array v12, v12, [F

    const/16 v29, 0x0

    aput v29, v12, v13

    const/16 v29, 0x1

    aput v2, v12, v29

    const/4 v2, 0x2

    aput v19, v12, v2

    const/high16 v19, 0x3f800000    # 1.0f

    const/16 v24, 0x3

    aput v19, v12, v24

    sget-object v63, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v58, 0x0

    const/16 v60, 0x0

    move-object/from16 v56, v3

    move/from16 v57, v7

    move/from16 v59, v14

    move-object/from16 v62, v12

    invoke-direct/range {v56 .. v63}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    new-instance v3, Landroid/graphics/PorterDuffXfermode;

    sget-object v7, Landroid/graphics/PorterDuff$Mode;->DST_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v3, v7}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    goto :goto_d

    :goto_f
    invoke-virtual {v10, v0, v14}, Landroid/graphics/Canvas;->saveLayer(Landroid/graphics/RectF;Landroid/graphics/Paint;)I

    move-result v3

    invoke-virtual {v10, v0}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    iget v0, v4, Lc/g5;->w:F

    const/high16 v7, 0x3f000000    # 0.5f

    cmpl-float v7, v0, v7

    if-lez v7, :cond_f

    move v0, v13

    goto :goto_10

    :cond_f
    const/high16 v7, -0x41000000    # -0.5f

    cmpg-float v0, v0, v7

    if-gez v0, :cond_10

    move v0, v2

    goto :goto_10

    :cond_10
    const/4 v0, 0x1

    :goto_10
    move v7, v13

    :goto_11
    const/4 v12, 0x3

    if-ge v7, v12, :cond_12

    if-eq v7, v0, :cond_11

    invoke-virtual {v4, v10, v7, v1, v15}, Lc/g5;->c(Landroid/graphics/Canvas;ILc/b5;F)V

    :cond_11
    const/4 v12, 0x1

    add-int/2addr v7, v12

    goto :goto_11

    :cond_12
    invoke-virtual {v4, v10, v0, v1, v15}, Lc/g5;->c(Landroid/graphics/Canvas;ILc/b5;F)V

    invoke-virtual {v10, v5}, Landroid/graphics/Canvas;->drawPaint(Landroid/graphics/Paint;)V

    invoke-virtual {v10, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :goto_12
    if-eqz v18, :cond_13

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    :goto_13
    add-float v0, v0, v17

    move v12, v0

    goto :goto_14

    :cond_13
    iget v0, v11, Landroid/graphics/RectF;->left:F

    goto :goto_13

    :goto_14
    iget v0, v11, Landroid/graphics/RectF;->right:F

    sub-float v19, v0, v17

    sub-float v0, v19, v12

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v7

    if-eqz v18, :cond_14

    iget v0, v11, Landroid/graphics/RectF;->top:F

    add-float v0, v0, v17

    move/from16 v5, v55

    add-float/2addr v0, v5

    :goto_15
    move v4, v0

    goto :goto_16

    :cond_14
    move/from16 v5, v55

    iget v0, v8, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x41400000    # 12.0f

    mul-float/2addr v1, v15

    add-float/2addr v0, v1

    goto :goto_15

    :goto_16
    const/high16 v0, 0x43d20000    # 420.0f

    mul-float/2addr v0, v15

    div-float v0, v7, v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v1

    const/high16 v3, 0x43dc0000    # 440.0f

    mul-float/2addr v3, v15

    div-float/2addr v1, v3

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v1, 0x3fa00000    # 1.25f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v1, 0x3f266666    # 0.65f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v22

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->g:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_15

    const-string v0, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a"

    goto :goto_17

    :cond_15
    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->g:Ljava/lang/String;

    :goto_17
    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v3, 0x40000000    # 2.0f

    mul-float v17, v17, v3

    sub-float v1, v1, v17

    const/high16 v3, 0x42800000    # 64.0f

    mul-float/2addr v3, v15

    sub-float/2addr v1, v3

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {v9, v0, v1, v5, v13}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    sub-float v0, v0, v17

    move-object/from16 v1, v51

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    add-float/2addr v1, v3

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr v1, v0

    const/high16 v11, 0x40000000    # 2.0f

    div-float v3, v1, v11

    add-float/2addr v0, v3

    move/from16 v1, v54

    add-float v14, v1, v6

    move/from16 v17, v7

    move-object/from16 v7, v30

    invoke-virtual {v7, v3, v1, v0, v14}, Landroid/graphics/RectF;->set(FFFF)V

    div-float v14, v6, v11

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->c:I

    const v29, 0xffffff

    and-int v0, v0, v29

    const/high16 v29, 0x66000000

    or-int v0, v0, v29

    invoke-virtual {v9, v10, v7, v14, v0}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    add-float v7, v3, v46

    const/high16 v0, 0x41600000    # 14.0f

    mul-float/2addr v0, v15

    sub-float v11, v7, v0

    move/from16 v47, v6

    const/high16 v6, 0x41200000    # 10.0f

    mul-float/2addr v6, v15

    add-float/2addr v6, v1

    add-float/2addr v0, v7

    mul-float v29, v15, v31

    add-float v13, v29, v1

    move/from16 v55, v5

    move-object/from16 v5, v28

    invoke-virtual {v5, v11, v6, v0, v13}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->n:Z

    if-eqz v0, :cond_16

    const/4 v0, 0x0

    goto :goto_1a

    :cond_16
    iget-object v0, v9, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_17

    :goto_18
    move-object/from16 v0, v16

    move-object/from16 v13, v52

    goto :goto_19

    :cond_17
    iget-object v0, v9, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v0, :cond_18

    invoke-virtual/range {v20 .. v20}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v16

    goto :goto_18

    :cond_18
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v16

    goto :goto_18

    :goto_19
    invoke-virtual {v13, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    :goto_1a
    if-eqz v0, :cond_19

    iget-object v6, v9, Lc/P3;->c0:Lc/r4;

    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v10, v0, v5, v6}, Lc/s;->e(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    move/from16 v16, v1

    move-object/from16 v23, v2

    move/from16 v25, v3

    move v7, v4

    move/from16 v28, v47

    move/from16 v26, v55

    const/high16 v11, 0x41d00000    # 26.0f

    goto :goto_1b

    :cond_19
    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->n:Z

    if-eqz v0, :cond_1a

    move/from16 v25, v26

    :cond_1a
    add-float v5, v1, v46

    const/high16 v11, 0x41d00000    # 26.0f

    mul-float v6, v15, v11

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v13, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move/from16 v16, v1

    move-object/from16 v1, p1

    move-object/from16 v23, v2

    move/from16 v2, v25

    move/from16 v25, v3

    move v3, v7

    move v7, v4

    move v4, v5

    move/from16 v26, v55

    move v5, v6

    move/from16 v28, v47

    move v6, v13

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :goto_1b
    add-float v3, v25, v28

    const/high16 v0, 0x41f00000    # 30.0f

    mul-float v13, v15, v0

    add-float v4, v16, v13

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, v23

    move/from16 v5, v26

    move/from16 v66, v7

    move/from16 v65, v17

    const/high16 v11, 0x40000000    # 2.0f

    move/from16 v7, v16

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    const/high16 v0, 0x42900000    # 72.0f

    mul-float v6, v15, v0

    mul-float v6, v6, v22

    if-eqz v18, :cond_1b

    iget v0, v8, Landroid/graphics/RectF;->bottom:F

    mul-float v2, v46, v22

    sub-float/2addr v0, v2

    move/from16 v27, v0

    goto :goto_1c

    :cond_1b
    const/high16 v0, 0x40800000    # 4.0f

    mul-float/2addr v0, v15

    sub-float v27, v27, v0

    div-float v0, v6, v11

    sub-float v27, v27, v0

    :goto_1c
    div-float v16, v6, v11

    sub-float v8, v27, v16

    const/high16 v0, 0x42000000    # 32.0f

    mul-float v6, v15, v0

    sub-float v17, v8, v6

    mul-float v13, v13, v22

    const/high16 v0, 0x41a00000    # 20.0f

    mul-float v6, v15, v0

    mul-float v7, v6, v22

    const/high16 v0, 0x41e00000    # 28.0f

    mul-float v6, v15, v0

    move/from16 v5, v66

    sub-float v0, v17, v5

    const/high16 v1, 0x42380000    # 46.0f

    mul-float/2addr v1, v15

    mul-float v1, v1, v22

    sub-float/2addr v0, v1

    invoke-static {v6, v0}, Ljava/lang/Math;->max(FF)F

    move-result v23

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v2, v0, Lc/U0;->e:Ljava/lang/String;

    const/high16 v0, 0x42600000    # 56.0f

    mul-float v25, v15, v0

    move/from16 v6, v65

    sub-float v4, v6, v25

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v1, v0, Lc/r4;->d:I

    if-eqz v18, :cond_1c

    const/16 v64, 0x3

    goto :goto_1d

    :cond_1c
    const/16 v64, 0x2

    :goto_1d
    const/16 v18, 0x0

    const/16 v24, 0x1

    move-object/from16 v0, p0

    move/from16 v26, v1

    move-object/from16 v1, v50

    move v11, v4

    move v4, v13

    move/from16 v67, v5

    move/from16 v5, v26

    move/from16 v68, v6

    move/from16 v6, v24

    move/from16 v69, v7

    move/from16 v7, v64

    move/from16 v21, v8

    move/from16 p2, v14

    const/high16 v14, 0x42e00000    # 112.0f

    move/from16 v8, v18

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v0

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v1

    int-to-float v1, v1

    cmpl-float v1, v1, v23

    if-lez v1, :cond_1d

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    div-float v0, v23, v0

    const v1, 0x3f19999a    # 0.6f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    mul-float v4, v0, v13

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v2, v0, Lc/U0;->e:Ljava/lang/String;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, v11}, Ljava/lang/Math;->max(FF)F

    move-result v3

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v5, v0, Lc/r4;->d:I

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, v50

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v0

    :cond_1d
    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v1

    int-to-float v1, v1

    sub-float v1, v17, v1

    const/high16 v2, 0x42300000    # 44.0f

    mul-float v6, v15, v2

    mul-float v6, v6, v22

    sub-float/2addr v1, v6

    move/from16 v2, v67

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v2

    invoke-virtual {v10, v12, v1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-static {v10, v0}, Lc/q9;->d(Landroid/graphics/Canvas;Landroid/text/StaticLayout;)V

    invoke-virtual {v10, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget-object v2, v9, Lc/P3;->B:Lc/U0;

    iget-object v2, v2, Lc/U0;->f:Ljava/lang/String;

    move/from16 v8, v68

    move/from16 v6, v69

    const/4 v3, 0x0

    invoke-virtual {v9, v2, v8, v6, v3}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v0

    int-to-float v0, v0

    add-float/2addr v1, v0

    const/high16 v0, 0x41d00000    # 26.0f

    mul-float/2addr v0, v15

    mul-float v0, v0, v22

    add-float v4, v0, v1

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v7, v0, Lc/r4;->e:I

    const/4 v11, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v12

    move v5, v6

    move v6, v7

    move v7, v11

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    invoke-virtual/range {v20 .. v20}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_1e

    const/4 v5, 0x1

    const/4 v6, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v12

    move/from16 v3, v19

    move/from16 v4, v17

    invoke-virtual/range {v0 .. v6}, Lc/P3;->A(Landroid/graphics/Canvas;FFFZZ)V

    :cond_1e
    add-float v12, v12, v19

    const/high16 v11, 0x40000000    # 2.0f

    div-float v7, v12, v11

    const v0, 0x3e99999a    # 0.3f

    mul-float/2addr v0, v8

    mul-float v6, v15, v14

    mul-float v6, v6, v22

    invoke-static {v0, v6}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iget-object v1, v9, Lc/P3;->I0:Landroid/graphics/RectF;

    sub-float v3, v7, v0

    sub-float v2, v3, v16

    add-float v4, v3, v16

    add-float v5, v27, v16

    move/from16 v6, v21

    invoke-virtual {v1, v2, v6, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    sub-float v1, v7, v16

    add-float v2, v7, v16

    move-object/from16 v4, v49

    invoke-virtual {v4, v1, v6, v2, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v9, Lc/P3;->K0:Landroid/graphics/RectF;

    add-float v8, v7, v0

    sub-float v0, v8, v16

    add-float v2, v8, v16

    invoke-virtual {v1, v0, v6, v2, v5}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v0, 0x42100000    # 36.0f

    mul-float v6, v15, v0

    mul-float v11, v6, v22

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const v2, 0x7f030025

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v4, v27

    move v5, v11

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual/range {v20 .. v20}, Lc/n1;->l0()Z

    move-result v0

    if-eqz v0, :cond_1f

    const v0, 0x7f03009a

    :goto_1e
    move v2, v0

    goto :goto_1f

    :cond_1f
    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->o:Z

    if-eqz v0, :cond_20

    const v0, 0x7f030023

    goto :goto_1e

    :cond_20
    const v0, 0x7f030024

    goto :goto_1e

    :goto_1f
    mul-float v5, v28, v22

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v7

    move/from16 v4, v27

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const v2, 0x7f030022

    move-object/from16 v0, p0

    move v3, v8

    move v5, v11

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    iget-object v0, v9, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v1, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v1, v1, Lc/U0;->n:Z

    if-nez v1, :cond_22

    invoke-virtual/range {v20 .. v20}, Lc/n1;->l0()Z

    move-result v1

    if-nez v1, :cond_22

    sub-float v3, v19, p2

    mul-float v25, v25, v22

    sub-float v4, v17, v25

    sub-float v1, v3, p2

    sub-float v2, v4, p2

    add-float v14, v3, p2

    add-float v5, v4, p2

    invoke-virtual {v0, v1, v2, v14, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->f1:Lc/V4;

    if-eqz v0, :cond_21

    iget-boolean v0, v0, Lc/V4;->c:Z

    if-eqz v0, :cond_21

    const v0, 0x7f03001a

    :goto_20
    move v2, v0

    goto :goto_21

    :cond_21
    const v0, 0x7f03001b

    goto :goto_20

    :goto_21
    const v0, 0x420aaaab

    mul-float v5, v15, v0

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_22
    return-void

    :cond_23
    move-object/from16 v20, v5

    move-object/from16 v21, v6

    move-object v7, v12

    move-object v5, v13

    move-object/from16 v50, v14

    move-object/from16 v70, v15

    const/high16 v0, 0x41600000    # 14.0f

    const/high16 v6, 0x42900000    # 72.0f

    const/high16 v12, 0x42380000    # 46.0f

    const/high16 v14, 0x42000000    # 32.0f

    const/high16 v41, 0x41800000    # 16.0f

    const/high16 v42, 0x42400000    # 48.0f

    const/high16 v44, 0x41000000    # 8.0f

    move-object v13, v3

    move-object v15, v11

    const/high16 v3, 0x42800000    # 64.0f

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v32

    const/high16 v0, 0x43700000    # 240.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    cmpg-float v0, v32, v0

    if-ltz v0, :cond_24

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v3, 0x43960000    # 300.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    cmpg-float v0, v0, v3

    if-gez v0, :cond_25

    :cond_24
    move-object v13, v7

    move-object/from16 v14, v21

    move-object/from16 v6, v29

    move/from16 v11, v41

    move/from16 v12, v44

    const/16 v27, 0x0

    const/16 v34, -0x1

    move-object v7, v5

    move-object/from16 v21, v20

    move/from16 v5, v42

    goto/16 :goto_3e

    :cond_25
    move-object/from16 v3, v20

    iget-object v0, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v12, "music_widget_style"

    const/4 v6, 0x0

    invoke-interface {v0, v12, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v12, 0x1

    if-ne v0, v12, :cond_26

    iget-object v0, v9, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v0}, Lc/U4;->c()V

    iput-boolean v6, v9, Lc/P3;->w0:Z

    iput v11, v9, Lc/P3;->A0:F

    invoke-virtual/range {p0 .. p2}, Lc/P3;->w(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    return-void

    :cond_26
    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {v2, v15}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object v2, v9, Lc/P3;->B:Lc/U0;

    invoke-virtual/range {p0 .. p0}, Lc/P3;->R()Landroid/graphics/Bitmap;

    move-result-object v28

    invoke-virtual {v3}, Lc/n1;->k0()Z

    move-result v32

    if-eqz v32, :cond_29

    if-eqz v28, :cond_27

    invoke-virtual/range {v28 .. v28}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-eqz v0, :cond_28

    :cond_27
    invoke-virtual {v4}, Lc/g5;->e()Z

    move-result v0

    if-eqz v0, :cond_29

    :cond_28
    move v0, v12

    goto :goto_22

    :cond_29
    const/4 v0, 0x0

    :goto_22
    iput-boolean v0, v9, Lc/P3;->o0:Z

    iget-object v0, v9, Lc/P3;->U:Landroid/graphics/RectF;

    invoke-virtual {v0, v15}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-boolean v6, v9, Lc/P3;->o0:Z

    if-nez v6, :cond_2b

    if-eqz v32, :cond_2a

    iget-boolean v6, v4, Lc/g5;->C:Z

    if-nez v6, :cond_2b

    iget-object v4, v4, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-eqz v4, :cond_2a

    goto :goto_23

    :cond_2a
    move-object v12, v0

    move-object/from16 v71, v1

    move-object v11, v3

    move-object/from16 v72, v5

    move-object/from16 v33, v7

    const/16 v34, -0x1

    move-object v7, v2

    goto :goto_24

    :cond_2b
    :goto_23
    invoke-virtual {v9, v14}, Lc/P3;->s(F)F

    move-result v4

    const/4 v6, 0x1

    move-object v12, v0

    move-object/from16 v0, p0

    move-object/from16 v71, v1

    move-object/from16 v1, p1

    move-object/from16 v33, v7

    move-object v7, v2

    move-object/from16 v2, v28

    move-object v11, v3

    move-object/from16 v3, p2

    move-object/from16 v72, v5

    const/16 v34, -0x1

    move v5, v6

    invoke-virtual/range {v0 .. v5}, Lc/P3;->I(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FZ)V

    :goto_24
    invoke-virtual/range {p0 .. p0}, Lc/P3;->m0()V

    iget-object v0, v11, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    move-object/from16 v6, v29

    const/4 v1, 0x0

    invoke-interface {v0, v6, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v28

    iget v0, v12, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x42dc0000    # 110.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v2

    sub-float v29, v0, v2

    if-eqz v32, :cond_2c

    iget-boolean v0, v9, Lc/P3;->o0:Z

    if-nez v0, :cond_2c

    iget v0, v12, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v14}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    iget v0, v12, Landroid/graphics/RectF;->top:F

    const/high16 v6, 0x41c00000    # 24.0f

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v0

    iget v0, v12, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v14}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v0, v3

    const/high16 v3, 0x42900000    # 72.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v4

    sub-float v3, v29, v4

    invoke-virtual {v8, v1, v2, v0, v3}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v9, v10, v8}, Lc/P3;->z(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    goto :goto_25

    :cond_2c
    const/high16 v6, 0x41c00000    # 24.0f

    :goto_25
    iget v0, v9, Lc/P3;->A0:F

    const/4 v8, 0x0

    cmpg-float v0, v0, v8

    if-gtz v0, :cond_2d

    if-nez v28, :cond_2d

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    return-void

    :cond_2d
    iget v0, v12, Landroid/graphics/RectF;->left:F

    const/high16 v5, 0x41800000    # 16.0f

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v1

    add-float v4, v1, v0

    iget v0, v12, Landroid/graphics/RectF;->right:F

    sub-float/2addr v0, v4

    const/high16 v1, 0x42900000    # 72.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v3

    iget-boolean v2, v9, Lc/P3;->o0:Z

    if-eqz v2, :cond_2e

    move/from16 v35, v34

    goto :goto_26

    :cond_2e
    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    move/from16 v35, v0

    :goto_26
    invoke-virtual {v11}, Lc/n1;->t()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_2f

    const/16 v0, 0x18

    goto :goto_27

    :cond_2f
    invoke-virtual {v11}, Lc/n1;->t()I

    move-result v0

    if-nez v0, :cond_30

    const/16 v0, 0x12

    goto :goto_27

    :cond_30
    const/16 v0, 0x15

    :goto_27
    int-to-float v0, v0

    const v27, 0x3f99999a    # 1.2f

    mul-float v0, v0, v27

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v36

    invoke-virtual {v11}, Lc/n1;->t()I

    move-result v0

    if-ne v0, v1, :cond_31

    const/16 v0, 0x13

    goto :goto_28

    :cond_31
    invoke-virtual {v11}, Lc/n1;->t()I

    move-result v0

    if-nez v0, :cond_32

    const/16 v0, 0xf

    goto :goto_28

    :cond_32
    const/16 v0, 0x11

    :goto_28
    int-to-float v0, v0

    const v27, 0x3f99999a    # 1.2f

    mul-float v0, v0, v27

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-static {v8, v5}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v8

    invoke-static {v6, v8}, Ljava/lang/Math;->max(FF)F

    move-result v37

    if-eqz v28, :cond_33

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v6

    move v8, v6

    goto :goto_29

    :cond_33
    const/4 v6, 0x0

    invoke-virtual {v9, v10, v15, v6}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v8

    :goto_29
    if-nez v32, :cond_3a

    invoke-virtual {v11}, Lc/n1;->t()I

    move-result v0

    if-ne v0, v1, :cond_34

    const/high16 v6, 0x42500000    # 52.0f

    goto :goto_2a

    :cond_34
    if-nez v0, :cond_35

    move/from16 v6, v31

    goto :goto_2a

    :cond_35
    const/high16 v6, 0x42340000    # 45.0f

    :goto_2a
    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v36

    if-ne v0, v1, :cond_36

    :goto_2b
    move/from16 v0, v31

    goto :goto_2c

    :cond_36
    if-nez v0, :cond_37

    const/high16 v0, 0x41e00000    # 28.0f

    goto :goto_2c

    :cond_37
    const/high16 v31, 0x42040000    # 33.0f

    goto :goto_2b

    :goto_2c
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v31

    iget v0, v12, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41900000    # 18.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v0

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v5

    sub-float v1, v29, v5

    sub-float/2addr v1, v6

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v38

    iget-object v5, v7, Lc/U0;->e:Ljava/lang/String;

    const/16 v39, 0x1

    const/16 v40, 0x3

    move-object/from16 v0, p0

    move-object/from16 v1, v50

    move/from16 v41, v2

    move-object v2, v5

    move v5, v3

    move v14, v4

    move/from16 v4, v36

    move/from16 v42, v5

    move/from16 v5, v35

    move/from16 v73, v6

    move-object/from16 v52, v13

    move-object/from16 v13, v21

    const/high16 v43, 0x41c00000    # 24.0f

    move-object/from16 v21, v11

    const/high16 v11, 0x41200000    # 10.0f

    move/from16 v6, v39

    move-object v11, v7

    move-object/from16 v74, v33

    const/16 v27, 0x0

    move/from16 v7, v40

    move-object/from16 v33, v13

    move v13, v8

    move/from16 v8, v41

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v39

    iget-object v1, v9, Lc/P3;->Q:Landroid/text/TextPaint;

    iget-object v2, v11, Lc/U0;->f:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v7, 0x2

    move/from16 v3, v42

    move/from16 v4, v31

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v0

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v40

    invoke-virtual/range {v39 .. v39}, Landroid/text/Layout;->getHeight()I

    move-result v1

    int-to-float v1, v1

    add-float v1, v1, v40

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v2

    int-to-float v2, v2

    add-float/2addr v1, v2

    cmpl-float v2, v1, v38

    if-lez v2, :cond_38

    div-float v38, v38, v1

    mul-float v4, v36, v38

    mul-float v31, v31, v38

    iget-object v2, v11, Lc/U0;->e:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v7, 0x3

    move-object/from16 v0, p0

    move-object/from16 v1, v50

    move/from16 v3, v42

    move/from16 v5, v35

    move/from16 v8, v41

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v39

    iget-object v1, v9, Lc/P3;->Q:Landroid/text/TextPaint;

    iget-object v2, v11, Lc/U0;->f:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v7, 0x2

    move/from16 v4, v31

    invoke-virtual/range {v0 .. v8}, Lc/P3;->Q(Landroid/text/TextPaint;Ljava/lang/String;FFIZIZ)Landroid/text/StaticLayout;

    move-result-object v0

    :cond_38
    move-object/from16 v1, v39

    const/high16 v2, 0x41900000    # 18.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    sub-float v29, v29, v2

    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sub-float v29, v29, v2

    sub-float v29, v29, v40

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v2

    int-to-float v2, v2

    sub-float v2, v29, v2

    move/from16 v6, v73

    invoke-static {v6, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    if-eqz v28, :cond_39

    iget v3, v12, Landroid/graphics/RectF;->bottom:F

    const/high16 v8, 0x41800000    # 16.0f

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v3, v4

    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v3, v4

    sub-float v3, v3, v40

    invoke-virtual {v0}, Landroid/text/Layout;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v3, v4

    sub-float/2addr v3, v2

    iget v4, v9, Lc/P3;->A0:F

    const/high16 v5, 0x3f800000    # 1.0f

    sub-float v4, v5, v4

    mul-float/2addr v4, v3

    add-float/2addr v2, v4

    goto :goto_2d

    :cond_39
    const/high16 v8, 0x41800000    # 16.0f

    :goto_2d
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v3

    invoke-virtual {v10, v14, v2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-static {v10, v1}, Lc/q9;->d(Landroid/graphics/Canvas;Landroid/text/StaticLayout;)V

    invoke-virtual {v10, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    move-result v1

    int-to-float v1, v1

    add-float/2addr v2, v1

    add-float v2, v2, v40

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    invoke-virtual {v10, v14, v2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-static {v10, v0}, Lc/q9;->d(Landroid/graphics/Canvas;Landroid/text/StaticLayout;)V

    invoke-virtual {v10, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    move-object/from16 v20, v12

    goto/16 :goto_2e

    :cond_3a
    move/from16 v41, v2

    move/from16 v42, v3

    move v14, v4

    move-object/from16 v52, v13

    move-object/from16 v74, v33

    const/high16 v1, 0x42380000    # 46.0f

    const/16 v27, 0x0

    move v13, v8

    move-object/from16 v33, v21

    const/high16 v8, 0x41800000    # 16.0f

    move-object/from16 v21, v11

    move-object v11, v7

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float v29, v29, v1

    if-eqz v28, :cond_3b

    iget v1, v12, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    sub-float v1, v1, v29

    iget v2, v9, Lc/P3;->A0:F

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float v5, v3, v2

    mul-float/2addr v5, v1

    add-float v29, v5, v29

    :cond_3b
    iget-object v2, v11, Lc/U0;->e:Ljava/lang/String;

    move v7, v0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move/from16 v4, v29

    move/from16 v5, v42

    move/from16 v6, v36

    move-object/from16 v20, v12

    move v12, v7

    move/from16 v7, v35

    move/from16 v8, v41

    invoke-virtual/range {v0 .. v8}, Lc/P3;->u(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    iget-object v0, v11, Lc/U0;->f:Ljava/lang/String;

    move/from16 v2, v42

    const/4 v1, 0x0

    invoke-virtual {v9, v0, v2, v12, v1}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    const/high16 v0, 0x42000000    # 32.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v1

    add-float v4, v1, v29

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v5, v12

    move/from16 v6, v35

    move/from16 v7, v41

    invoke-virtual/range {v0 .. v7}, Lc/P3;->y(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    :goto_2e
    invoke-virtual {v10, v13}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget v0, v9, Lc/P3;->A0:F

    cmpg-float v0, v0, v27

    if-gtz v0, :cond_3c

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    return-void

    :cond_3c
    const/4 v12, 0x1

    invoke-virtual {v9, v10, v15, v12}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v8

    iget-object v13, v9, Lc/P3;->R:Landroid/graphics/RectF;

    if-eqz v32, :cond_42

    invoke-virtual/range {v20 .. v20}, Landroid/graphics/RectF;->height()F

    move-result v0

    const/high16 v1, 0x43870000    # 270.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v2

    cmpl-float v0, v0, v2

    if-ltz v0, :cond_42

    iget-boolean v0, v11, Lc/U0;->n:Z

    if-eqz v0, :cond_42

    move-object/from16 v7, v20

    iget v0, v7, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x42aa0000    # 85.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v6, v1, v0

    iget-boolean v0, v9, Lc/P3;->o0:Z

    if-eqz v0, :cond_3d

    move/from16 v5, v34

    goto :goto_2f

    :cond_3d
    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->e:I

    move v5, v0

    :goto_2f
    iget-object v4, v9, Lc/P3;->B:Lc/U0;

    iget v3, v4, Lc/U0;->k:I

    const/high16 v0, 0x40e00000    # 7.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v1

    add-float v20, v1, v14

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    sub-float v27, v6, v0

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v28

    const v29, 0x7f030092

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v29

    move/from16 v29, v3

    move/from16 v3, v20

    move-object v12, v4

    move/from16 v4, v27

    move/from16 v20, v5

    move/from16 v5, v28

    move-object/from16 v27, v7

    move v7, v6

    move/from16 v6, v20

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    const/high16 v6, 0x41c00000    # 24.0f

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v0

    add-float v5, v0, v14

    iget-object v4, v9, Lc/P3;->M:Landroid/graphics/Paint;

    move/from16 v3, v20

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x3fc00000    # 1.5f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v0, 0x41500000    # 13.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    sub-float v0, v7, v0

    const/high16 v1, 0x41c80000    # 25.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v5

    invoke-virtual {v13, v5, v0, v1, v7}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v2, 0x40000000    # 2.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v1

    invoke-virtual {v10, v13, v0, v1, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x41d00000    # 26.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v1, v0, v5

    const/high16 v0, 0x41100000    # 9.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v20

    sub-float v20, v7, v20

    const/high16 v0, 0x41e00000    # 28.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v31

    add-float v31, v31, v5

    const/high16 v0, 0x40800000    # 4.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v36

    sub-float v36, v7, v36

    const/high16 v6, 0x41100000    # 9.0f

    move-object/from16 v0, p1

    move/from16 v2, v20

    move/from16 v20, v3

    move/from16 v3, v31

    move-object/from16 v28, v4

    move/from16 v4, v36

    move/from16 v31, v5

    move-object/from16 v5, v28

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    if-lez v29, :cond_3f

    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v1

    add-float v1, v1, v31

    const/high16 v2, 0x41200000    # 10.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    sub-float v2, v7, v2

    const/16 v3, 0x13

    mul-int/lit8 v3, v29, 0x13

    int-to-float v3, v3

    const/high16 v4, 0x42c80000    # 100.0f

    div-float/2addr v3, v4

    add-float/2addr v3, v0

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    add-float v3, v3, v31

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    sub-float v4, v7, v0

    move-object/from16 v0, p1

    move-object/from16 v5, v28

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    :cond_3e
    move/from16 v36, v8

    move/from16 v38, v14

    move-object/from16 v8, v27

    const/high16 v29, 0x40000000    # 2.0f

    move v14, v7

    goto :goto_30

    :cond_3f
    if-gez v29, :cond_3e

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v0

    add-float v3, v0, v31

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v0

    sub-float v4, v7, v0

    const/high16 v0, 0x41200000    # 10.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    const/16 v17, 0x1

    const-string v2, "?"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v29, v6

    move/from16 v6, v20

    move/from16 v36, v8

    move/from16 v38, v14

    move-object/from16 v8, v27

    move v14, v7

    move/from16 v7, v17

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    :goto_30
    const/high16 v0, 0x42200000    # 40.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v0, v0, v31

    move/from16 v6, v20

    move-object/from16 v1, v28

    invoke-virtual {v1, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v7, 0x0

    :goto_31
    const/4 v2, 0x5

    iget v3, v12, Lc/U0;->l:I

    const/16 v4, 0xff

    if-ge v7, v2, :cond_41

    if-ltz v3, :cond_40

    if-ge v7, v3, :cond_40

    goto :goto_32

    :cond_40
    const/16 v4, 0x37

    :goto_32
    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    mul-int/lit8 v2, v7, 0x5

    int-to-float v3, v2

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    add-float/2addr v3, v0

    int-to-float v4, v7

    const/high16 v5, 0x40200000    # 2.5f

    mul-float/2addr v4, v5

    const/high16 v5, 0x40800000    # 4.0f

    add-float/2addr v4, v5

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    sub-float v4, v14, v4

    const/4 v5, 0x3

    add-int/2addr v2, v5

    int-to-float v2, v2

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v0

    invoke-virtual {v13, v3, v4, v2, v14}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v3

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v4

    invoke-virtual {v10, v13, v3, v4, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v2, 0x1

    add-int/2addr v7, v2

    goto :goto_31

    :cond_41
    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    if-gez v3, :cond_43

    const/high16 v1, 0x41d80000    # 27.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v3, v1, v0

    const/high16 v0, 0x41300000    # 11.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    const/4 v7, 0x1

    const-string v2, "?"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v14

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    goto :goto_33

    :cond_42
    move/from16 v36, v8

    move/from16 v38, v14

    move-object/from16 v8, v20

    const/high16 v29, 0x40000000    # 2.0f

    :cond_43
    :goto_33
    iget v0, v15, Landroid/graphics/RectF;->left:F

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    iget v0, v15, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v0

    iget v0, v15, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v0, v3

    iget v3, v15, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x42e40000    # 114.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v3, v4

    move-object/from16 v14, v33

    invoke-virtual {v14, v1, v2, v0, v3}, Landroid/graphics/RectF;->set(FFFF)V

    if-nez v32, :cond_44

    iget v0, v8, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v1

    sub-float/2addr v0, v1

    sub-float v0, v0, v37

    goto :goto_34

    :cond_44
    iget v0, v8, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v0, v1

    :goto_34
    iget v1, v8, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v1

    add-float v1, v0, v37

    iget v3, v8, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9, v12}, Lc/P3;->s(F)F

    move-result v4

    add-float/2addr v4, v3

    add-float v4, v4, v37

    move-object/from16 v12, v74

    invoke-virtual {v12, v0, v2, v1, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->A:Lc/g1;

    iget-boolean v0, v0, Lc/g1;->J:Z

    if-nez v0, :cond_4e

    iget-boolean v0, v11, Lc/U0;->n:Z

    if-eqz v0, :cond_45

    const/4 v0, 0x0

    goto :goto_37

    :cond_45
    iget-object v0, v9, Lc/P3;->o1:Lc/w8;

    if-eqz v0, :cond_46

    :goto_35
    move-object/from16 v0, v16

    move-object/from16 v1, v52

    goto :goto_36

    :cond_46
    iget-object v0, v9, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v0, :cond_47

    invoke-virtual/range {v21 .. v21}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v16

    goto :goto_35

    :cond_47
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v16

    goto :goto_35

    :goto_36
    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    :goto_37
    if-eqz v0, :cond_48

    const/high16 v7, 0x41e00000    # 28.0f

    goto :goto_38

    :cond_48
    const/high16 v7, 0x41c00000    # 24.0f

    :goto_38
    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v1

    const v2, 0x3fa66666    # 1.3f

    mul-float v5, v1, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    div-float v2, v5, v29

    sub-float/2addr v1, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    sub-float/2addr v3, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    add-float/2addr v4, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    add-float/2addr v6, v2

    move-object/from16 v7, v72

    invoke-virtual {v7, v1, v3, v4, v6}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v9, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v7}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v7}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    invoke-virtual {v1, v3, v4}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    invoke-static {v10, v7, v1}, Lc/s;->g(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v7

    if-eqz v0, :cond_4a

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    sub-float/2addr v1, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    sub-float/2addr v3, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    add-float/2addr v4, v2

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v5

    add-float/2addr v5, v2

    invoke-virtual {v13, v1, v3, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v9, Lc/P3;->K:Lc/a5;

    if-nez v1, :cond_49

    iget-object v1, v9, Lc/P3;->c0:Lc/r4;

    goto :goto_39

    :cond_49
    sget-object v1, Lc/r4;->o:Lc/r4;

    :goto_39
    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v10, v0, v13, v1}, Lc/s;->e(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_3c

    :cond_4a
    iget-boolean v0, v11, Lc/U0;->n:Z

    if-eqz v0, :cond_4b

    move/from16 v2, v26

    goto :goto_3a

    :cond_4b
    move/from16 v2, v25

    :goto_3a
    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v12}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    iget-object v0, v9, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_4c

    move/from16 v6, v35

    goto :goto_3b

    :cond_4c
    move/from16 v6, v34

    :goto_3b
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :goto_3c
    invoke-virtual {v10, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    if-eqz v32, :cond_4e

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v0

    const/high16 v1, 0x43870000    # 270.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_4e

    iget-boolean v0, v11, Lc/U0;->n:Z

    if-nez v0, :cond_4e

    iget-object v0, v9, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_4e

    const/high16 v0, 0x41400000    # 12.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v13

    iget v0, v12, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x41880000    # 17.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float v14, v1, v0

    const/high16 v0, 0x43200000    # 160.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x42000000    # 32.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iget-object v1, v11, Lc/U0;->g:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-virtual {v9, v1, v0, v13, v2}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v11

    iget-boolean v7, v9, Lc/P3;->o0:Z

    if-eqz v7, :cond_4d

    move/from16 v6, v34

    goto :goto_3d

    :cond_4d
    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->e:I

    move v6, v0

    :goto_3d
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v11

    move/from16 v3, v38

    move v4, v14

    move v5, v13

    invoke-virtual/range {v0 .. v7}, Lc/P3;->y(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    sub-float v0, v14, v13

    move-object/from16 v1, v71

    invoke-virtual {v1, v11}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    add-float v1, v1, v38

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v14

    invoke-virtual {v12, v3, v0, v1, v2}, Landroid/graphics/RectF;->union(FFFF)V

    :cond_4e
    move/from16 v0, v36

    invoke-virtual {v10, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v0, 0x0

    invoke-virtual {v9, v10, v15, v0}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v7

    invoke-virtual/range {v21 .. v21}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_4f

    iget v0, v8, Landroid/graphics/RectF;->left:F

    const/high16 v11, 0x41800000    # 16.0f

    invoke-virtual {v9, v11}, Lc/P3;->s(F)F

    move-result v1

    add-float v2, v1, v0

    iget v0, v8, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v11}, Lc/P3;->s(F)F

    move-result v1

    sub-float v3, v0, v1

    iget v0, v8, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x42dc0000    # 110.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float v4, v0, v1

    const/4 v5, 0x1

    iget-boolean v6, v9, Lc/P3;->o0:Z

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/P3;->A(Landroid/graphics/Canvas;FFFZZ)V

    :cond_4f
    invoke-virtual {v9, v10, v8}, Lc/P3;->x(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    invoke-virtual {v10, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    return-void

    :goto_3e
    invoke-virtual {v2, v15}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->R()Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual/range {v21 .. v21}, Lc/n1;->k0()Z

    move-result v0

    if-eqz v0, :cond_52

    if-eqz v2, :cond_50

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-eqz v0, :cond_51

    :cond_50
    invoke-virtual {v4}, Lc/g5;->e()Z

    move-result v0

    if-eqz v0, :cond_52

    :cond_51
    const/4 v0, 0x1

    goto :goto_3f

    :cond_52
    const/4 v0, 0x0

    :goto_3f
    iput-boolean v0, v9, Lc/P3;->o0:Z

    if-nez v0, :cond_54

    invoke-virtual/range {v21 .. v21}, Lc/n1;->k0()Z

    move-result v0

    if-eqz v0, :cond_53

    iget-boolean v0, v4, Lc/g5;->C:Z

    if-nez v0, :cond_54

    iget-object v0, v4, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_53

    goto :goto_40

    :cond_53
    move v12, v5

    goto :goto_41

    :cond_54
    :goto_40
    const/high16 v0, 0x42000000    # 32.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v4

    const/16 v16, 0x1

    const/high16 v3, 0x41600000    # 14.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v3, p2

    move v12, v5

    move/from16 v5, v16

    invoke-virtual/range {v0 .. v5}, Lc/P3;->I(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FZ)V

    :goto_41
    invoke-virtual/range {v21 .. v21}, Lc/n1;->k0()Z

    move-result v0

    if-eqz v0, :cond_55

    iget-boolean v0, v9, Lc/P3;->o0:Z

    if-nez v0, :cond_55

    iget v0, v15, Landroid/graphics/RectF;->left:F

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    iget v0, v15, Landroid/graphics/RectF;->top:F

    const/high16 v2, 0x42680000    # 58.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v0

    iget v0, v15, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v0, v3

    iget v3, v15, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x42e00000    # 112.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v3, v4

    invoke-virtual {v8, v1, v2, v0, v3}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v9, v10, v8}, Lc/P3;->z(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    goto :goto_42

    :cond_55
    const/high16 v5, 0x41c00000    # 24.0f

    :goto_42
    invoke-virtual/range {p0 .. p0}, Lc/P3;->m0()V

    move-object/from16 v8, v21

    iget-object v0, v8, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    invoke-interface {v0, v6, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iget v1, v9, Lc/P3;->A0:F

    cmpg-float v1, v1, v27

    if-gtz v1, :cond_56

    if-nez v0, :cond_56

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    goto/16 :goto_47

    :cond_56
    iget-boolean v1, v9, Lc/P3;->o0:Z

    if-eqz v1, :cond_57

    move/from16 v16, v34

    goto :goto_43

    :cond_57
    iget-object v1, v9, Lc/P3;->c0:Lc/r4;

    iget v1, v1, Lc/r4;->d:I

    move/from16 v16, v1

    :goto_43
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v12}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v1

    iget v2, v15, Landroid/graphics/RectF;->left:F

    invoke-virtual {v9, v11}, Lc/P3;->s(F)F

    move-result v3

    add-float v12, v3, v2

    iget v2, v15, Landroid/graphics/RectF;->right:F

    const/high16 v3, 0x41000000    # 8.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v2, v4

    sub-float/2addr v2, v1

    iget v4, v15, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v4

    iget v4, v15, Landroid/graphics/RectF;->right:F

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v17

    sub-float v4, v4, v17

    iget v5, v15, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v17

    add-float v17, v17, v5

    add-float v1, v17, v1

    invoke-virtual {v13, v2, v6, v4, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget v1, v13, Landroid/graphics/RectF;->left:F

    sub-float/2addr v1, v12

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v6

    if-eqz v0, :cond_58

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    move v5, v1

    goto :goto_44

    :cond_58
    const/4 v1, 0x0

    invoke-virtual {v9, v10, v15, v1}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v2

    move v5, v2

    :goto_44
    iget v1, v15, Landroid/graphics/RectF;->top:F

    const/high16 v2, 0x41c80000    # 25.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v1

    if-eqz v0, :cond_59

    iget v0, v15, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x42140000    # 37.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float/2addr v0, v1

    sub-float/2addr v0, v2

    iget v1, v9, Lc/P3;->A0:F

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float v1, v3, v1

    mul-float/2addr v1, v0

    add-float/2addr v2, v1

    :cond_59
    move/from16 v17, v2

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v2, v0, Lc/U0;->e:Ljava/lang/String;

    const/high16 v0, 0x41900000    # 18.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v18

    iget-boolean v4, v9, Lc/P3;->o0:Z

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v12

    move/from16 v19, v4

    move/from16 v4, v17

    move v11, v5

    move v5, v6

    move-object/from16 v21, v14

    move v14, v6

    move/from16 v6, v18

    move-object/from16 v75, v7

    move/from16 v7, v16

    move-object/from16 v18, v8

    move/from16 v8, v19

    invoke-virtual/range {v0 .. v8}, Lc/P3;->u(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-object v0, v0, Lc/U0;->f:Ljava/lang/String;

    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v9, v0, v14, v1, v2}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v3

    const/high16 v0, 0x41a80000    # 21.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v4, v0, v17

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v5

    iget-boolean v7, v9, Lc/P3;->o0:Z

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v3

    move v3, v12

    move/from16 v6, v16

    invoke-virtual/range {v0 .. v7}, Lc/P3;->y(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    invoke-virtual {v10, v11}, Landroid/graphics/Canvas;->restoreToCount(I)V

    iget v0, v9, Lc/P3;->A0:F

    cmpg-float v0, v0, v27

    if-gtz v0, :cond_5a

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    goto/16 :goto_47

    :cond_5a
    const/4 v0, 0x1

    invoke-virtual {v9, v10, v15, v0}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v7

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v1

    sub-float/2addr v0, v1

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v1, v2

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v3

    add-float/2addr v3, v2

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v4

    add-float/2addr v4, v2

    move-object/from16 v2, v75

    invoke-virtual {v2, v0, v1, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v3

    invoke-virtual {v0, v1, v3}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    invoke-static {v10, v2, v0}, Lc/s;->g(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v8

    iget-object v0, v9, Lc/P3;->A:Lc/g1;

    iget-boolean v0, v0, Lc/g1;->J:Z

    if-nez v0, :cond_5d

    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->n:Z

    if-eqz v0, :cond_5b

    move/from16 v2, v26

    goto :goto_45

    :cond_5b
    move/from16 v2, v25

    :goto_45
    invoke-virtual {v13}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v13}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    const/high16 v0, 0x41e00000    # 28.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_5c

    move/from16 v6, v16

    goto :goto_46

    :cond_5c
    move/from16 v6, v34

    :goto_46
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_5d
    iget v0, v15, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    iget v0, v13, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v0, v3

    iget v2, v15, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x42580000    # 54.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    add-float/2addr v3, v2

    move-object/from16 v2, v21

    invoke-virtual {v2, v12, v1, v0, v3}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v10, v8}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual {v10, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v0, 0x0

    invoke-virtual {v9, v10, v15, v0}, Lc/P3;->O(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v7

    invoke-virtual/range {p0 .. p2}, Lc/P3;->x(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    move-object/from16 v8, v70

    iget v0, v8, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float v4, v0, v1

    invoke-virtual/range {v18 .. v18}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_5e

    iget v0, v15, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x42800000    # 64.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    cmpl-float v0, v4, v1

    if-ltz v0, :cond_5e

    iget v0, v15, Landroid/graphics/RectF;->right:F

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float v3, v0, v1

    const/4 v5, 0x0

    iget-boolean v6, v9, Lc/P3;->o0:Z

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v12

    invoke-virtual/range {v0 .. v6}, Lc/P3;->A(Landroid/graphics/Canvas;FFFZZ)V

    iget-object v0, v9, Lc/P3;->W:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5e

    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    iget v2, v8, Landroid/graphics/RectF;->top:F

    const/high16 v3, 0x40800000    # 4.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    iput v1, v0, Landroid/graphics/RectF;->bottom:F

    :cond_5e
    invoke-virtual {v10, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual/range {p0 .. p0}, Lc/P3;->l()V

    :goto_47
    return-void
.end method

.method public final w(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 30

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    iget-object v0, v9, Lc/P3;->C0:Landroid/graphics/RectF;

    invoke-virtual {v0, v11}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object v12, v9, Lc/P3;->B:Lc/U0;

    invoke-virtual/range {p0 .. p0}, Lc/P3;->R()Landroid/graphics/Bitmap;

    move-result-object v2

    iget-object v13, v9, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->k0()Z

    move-result v0

    iget-object v1, v9, Lc/P3;->N1:Lc/g5;

    if-eqz v0, :cond_2

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    invoke-virtual {v1}, Lc/g5;->e()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    iput-boolean v0, v9, Lc/P3;->o0:Z

    const/high16 v0, 0x41800000    # 16.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v15

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v7

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/high16 v8, 0x43960000    # 300.0f

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v4

    cmpg-float v3, v3, v4

    if-gez v3, :cond_3

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/high16 v4, 0x43520000    # 210.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    cmpl-float v3, v3, v4

    if-ltz v3, :cond_3

    const/16 v16, 0x1

    goto :goto_1

    :cond_3
    const/16 v16, 0x0

    :goto_1
    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/high16 v4, 0x433e0000    # 190.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    cmpg-float v3, v3, v4

    if-ltz v3, :cond_5

    if-eqz v16, :cond_4

    goto :goto_2

    :cond_4
    const/16 v17, 0x0

    goto :goto_3

    :cond_5
    :goto_2
    const/16 v17, 0x1

    :goto_3
    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/high16 v4, 0x43d70000    # 430.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    cmpl-float v3, v3, v4

    if-ltz v3, :cond_6

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v4

    const/high16 v5, 0x3fa00000    # 1.25f

    mul-float/2addr v4, v5

    cmpl-float v3, v3, v4

    if-lez v3, :cond_6

    const/16 v18, 0x1

    goto :goto_4

    :cond_6
    const/16 v18, 0x0

    :goto_4
    if-eqz v17, :cond_7

    iget v3, v11, Landroid/graphics/RectF;->bottom:F

    const/high16 v4, 0x42800000    # 64.0f

    invoke-virtual {v9, v4}, Lc/P3;->s(F)F

    move-result v4

    sub-float/2addr v3, v4

    move/from16 v19, v3

    goto :goto_5

    :cond_7
    iget v3, v11, Landroid/graphics/RectF;->top:F

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v4

    const v5, 0x3f051eb8    # 0.52f

    mul-float/2addr v4, v5

    add-float/2addr v4, v3

    move/from16 v19, v4

    :goto_5
    const/high16 v5, 0x40000000    # 2.0f

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    if-eqz v16, :cond_8

    mul-float v4, v15, v5

    sub-float/2addr v3, v4

    goto :goto_6

    :cond_8
    const v4, 0x3ec28f5c    # 0.38f

    mul-float/2addr v3, v4

    :goto_6
    if-eqz v18, :cond_9

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v4

    mul-float v20, v15, v5

    sub-float v4, v4, v20

    goto :goto_8

    :cond_9
    iget v4, v11, Landroid/graphics/RectF;->top:F

    sub-float v4, v19, v4

    sub-float/2addr v4, v15

    if-eqz v16, :cond_a

    const/high16 v20, 0x42900000    # 72.0f

    move/from16 v6, v20

    goto :goto_7

    :cond_a
    move v6, v0

    :goto_7
    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v6

    sub-float/2addr v4, v6

    :goto_8
    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/high16 v6, 0x42400000    # 48.0f

    invoke-virtual {v9, v6}, Lc/P3;->s(F)F

    move-result v4

    invoke-static {v4, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    if-eqz v18, :cond_b

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v4

    mul-float v21, v15, v5

    sub-float v4, v4, v21

    goto :goto_9

    :cond_b
    move v4, v3

    :goto_9
    iget-object v14, v9, Lc/P3;->R:Landroid/graphics/RectF;

    iget v5, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v5, v15

    iget v6, v11, Landroid/graphics/RectF;->top:F

    add-float/2addr v6, v15

    add-float/2addr v3, v5

    add-float/2addr v4, v6

    invoke-virtual {v14, v5, v6, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-boolean v3, v9, Lc/P3;->o0:Z

    if-nez v3, :cond_d

    iget-boolean v3, v1, Lc/g5;->C:Z

    if-nez v3, :cond_d

    iget-object v1, v1, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-eqz v1, :cond_c

    goto :goto_a

    :cond_c
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    iget-object v1, v9, Lc/P3;->c0:Lc/r4;

    iget v1, v1, Lc/r4;->c:I

    invoke-virtual {v9, v10, v14, v0, v1}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    invoke-virtual {v9, v10, v14}, Lc/P3;->z(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V

    const/high16 v6, 0x40000000    # 2.0f

    goto :goto_b

    :cond_d
    :goto_a
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v4

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v3, v14

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual/range {v0 .. v5}, Lc/P3;->I(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FZ)V

    :goto_b
    if-eqz v16, :cond_e

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v0, v15

    :goto_c
    move/from16 v22, v0

    goto :goto_d

    :cond_e
    iget v0, v14, Landroid/graphics/RectF;->right:F

    add-float/2addr v0, v7

    goto :goto_c

    :goto_d
    if-eqz v18, :cond_f

    move/from16 v18, v22

    goto :goto_e

    :cond_f
    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v0, v15

    move/from16 v18, v0

    :goto_e
    iget v0, v11, Landroid/graphics/RectF;->right:F

    sub-float v24, v0, v15

    if-nez v17, :cond_10

    if-nez v16, :cond_10

    iget-boolean v0, v12, Lc/U0;->n:Z

    if-nez v0, :cond_10

    invoke-virtual {v13}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_10

    sub-float v0, v24, v18

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v1

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_10

    const/16 v20, 0x1

    goto :goto_f

    :cond_10
    const/16 v20, 0x0

    :goto_f
    const/high16 v8, 0x42000000    # 32.0f

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v0

    iget v1, v11, Landroid/graphics/RectF;->right:F

    sub-float/2addr v1, v15

    if-eqz v20, :cond_11

    const/4 v2, 0x0

    const/high16 v7, 0x42400000    # 48.0f

    goto :goto_10

    :cond_11
    const/high16 v7, 0x42400000    # 48.0f

    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v2

    :goto_10
    sub-float/2addr v1, v2

    sub-float v1, v1, v22

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v5

    const/high16 v4, 0x41a00000    # 20.0f

    if-eqz v17, :cond_12

    move v0, v4

    goto :goto_11

    :cond_12
    const/high16 v0, 0x41b80000    # 23.0f

    :goto_11
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v23

    if-eqz v17, :cond_13

    const/high16 v0, 0x41700000    # 15.0f

    goto :goto_12

    :cond_13
    const/high16 v0, 0x41900000    # 18.0f

    :goto_12
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v3

    const/high16 v2, 0x41d00000    # 26.0f

    if-eqz v16, :cond_14

    iget v0, v14, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v1

    add-float/2addr v1, v0

    :goto_13
    move/from16 v25, v1

    goto :goto_14

    :cond_14
    iget v0, v11, Landroid/graphics/RectF;->top:F

    add-float/2addr v0, v15

    add-float v1, v0, v23

    goto :goto_13

    :goto_14
    iget-object v1, v12, Lc/U0;->e:Ljava/lang/String;

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    const/16 v26, 0x0

    move/from16 v27, v0

    move-object/from16 v0, p0

    move-object/from16 v28, v1

    move-object/from16 v1, p1

    move-object/from16 v2, v28

    move/from16 v29, v3

    move/from16 v3, v22

    move/from16 v4, v25

    move/from16 v28, v5

    move v7, v6

    move/from16 v6, v23

    move v10, v7

    move/from16 v7, v27

    move/from16 v8, v26

    invoke-virtual/range {v0 .. v8}, Lc/P3;->u(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    iget-object v0, v12, Lc/U0;->f:Ljava/lang/String;

    move/from16 v2, v28

    move/from16 v5, v29

    const/4 v1, 0x0

    invoke-virtual {v9, v0, v2, v5, v1}, Lc/P3;->J(Ljava/lang/String;FFZ)Ljava/lang/String;

    move-result-object v2

    const/high16 v0, 0x41d00000    # 26.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    add-float v4, v0, v25

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->e:I

    const/4 v7, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/P3;->F(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V

    iget v0, v11, Landroid/graphics/RectF;->right:F

    sub-float/2addr v0, v15

    const/high16 v1, 0x41b00000    # 22.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v2

    sub-float v3, v0, v2

    if-eqz v16, :cond_15

    iget v0, v14, Landroid/graphics/RectF;->bottom:F

    const/high16 v7, 0x41a00000    # 20.0f

    invoke-virtual {v9, v7}, Lc/P3;->s(F)F

    move-result v1

    :goto_15
    add-float/2addr v1, v0

    move v4, v1

    goto :goto_16

    :cond_15
    const/high16 v7, 0x41a00000    # 20.0f

    iget v0, v11, Landroid/graphics/RectF;->top:F

    add-float/2addr v0, v15

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v1

    goto :goto_15

    :goto_16
    iget-object v8, v9, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v8}, Landroid/graphics/RectF;->setEmpty()V

    const v16, 0x7f03001b

    const v21, 0x7f03001a

    iget-boolean v12, v12, Lc/U0;->n:Z

    if-nez v20, :cond_17

    if-nez v12, :cond_17

    invoke-virtual {v13}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_17

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v6, 0x42400000    # 48.0f

    invoke-static {v0, v6}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    div-float/2addr v0, v10

    sub-float v1, v3, v0

    sub-float v2, v4, v0

    add-float v5, v3, v0

    add-float/2addr v0, v4

    invoke-virtual {v8, v1, v2, v5, v0}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->f1:Lc/V4;

    if-eqz v0, :cond_16

    iget-boolean v0, v0, Lc/V4;->c:Z

    if-eqz v0, :cond_16

    move/from16 v2, v21

    goto :goto_17

    :cond_16
    move/from16 v2, v16

    :goto_17
    const/high16 v0, 0x41c80000    # 25.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v1, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move/from16 v22, v1

    move-object/from16 v1, p1

    move v7, v6

    move/from16 v6, v22

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    goto :goto_18

    :cond_17
    const/high16 v7, 0x42400000    # 48.0f

    :goto_18
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v7}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    iget-object v1, v9, Lc/P3;->D0:Landroid/graphics/RectF;

    iget v2, v14, Landroid/graphics/RectF;->left:F

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v4

    add-float/2addr v4, v2

    iget v2, v14, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v2, v0

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v5

    sub-float/2addr v2, v5

    iget v5, v14, Landroid/graphics/RectF;->left:F

    add-float/2addr v5, v0

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v5

    iget v5, v14, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    sub-float/2addr v5, v3

    invoke-virtual {v1, v4, v2, v6, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v2, v9, Lc/P3;->A:Lc/g1;

    iget-boolean v2, v2, Lc/g1;->J:Z

    if-nez v2, :cond_22

    invoke-virtual {v1}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v10

    iget-boolean v3, v9, Lc/P3;->o0:Z

    if-eqz v3, :cond_18

    const/16 v3, 0xb4

    const/16 v4, 0xf

    const/16 v5, 0x14

    const/16 v6, 0x19

    invoke-static {v3, v4, v5, v6}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    :goto_19
    move v14, v10

    move-object/from16 v10, p1

    goto :goto_1a

    :cond_18
    iget-object v3, v9, Lc/P3;->c0:Lc/r4;

    iget v3, v3, Lc/r4;->b:I

    goto :goto_19

    :goto_1a
    invoke-virtual {v9, v10, v1, v2, v3}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    if-eqz v12, :cond_19

    const/4 v2, 0x0

    goto :goto_1c

    :cond_19
    iget-object v2, v9, Lc/P3;->o1:Lc/w8;

    if-eqz v2, :cond_1a

    const-string v2, "com.syu.music"

    goto :goto_1b

    :cond_1a
    iget-object v2, v9, Lc/P3;->c1:Landroid/media/session/MediaController;

    if-nez v2, :cond_1b

    invoke-virtual {v13}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v2

    goto :goto_1b

    :cond_1b
    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v2

    :goto_1b
    iget-object v3, v9, Lc/P3;->a0:Lc/z;

    invoke-virtual {v3, v2}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v2

    :goto_1c
    const v3, 0x3f0ccccd    # 0.55f

    if-eqz v2, :cond_1c

    const v4, 0x3f23d70a    # 0.64f

    goto :goto_1d

    :cond_1c
    move v4, v3

    :goto_1d
    mul-float/2addr v4, v0

    iget-object v5, v9, Lc/P3;->L:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    div-float/2addr v4, v14

    sub-float/2addr v6, v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v22

    sub-float v14, v22, v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v22

    add-float v7, v22, v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v22

    add-float v4, v22, v4

    invoke-virtual {v5, v6, v14, v7, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v4, v9, Lc/P3;->D1:Landroid/graphics/RectF;

    invoke-virtual {v5}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    invoke-virtual {v5}, Landroid/graphics/RectF;->centerY()F

    move-result v7

    invoke-virtual {v4, v6, v7}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v4

    invoke-static {v10, v5, v4}, Lc/s;->g(Landroid/graphics/Canvas;Landroid/graphics/RectF;Z)I

    move-result v7

    if-eqz v2, :cond_1e

    const v3, 0x3ea3d70a    # 0.32f

    mul-float/2addr v0, v3

    iget-object v3, v9, Lc/P3;->S:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    sub-float/2addr v4, v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v5

    sub-float/2addr v5, v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    add-float/2addr v6, v0

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    add-float/2addr v1, v0

    invoke-virtual {v3, v4, v5, v6, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_1d

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    goto :goto_1e

    :cond_1d
    sget-object v0, Lc/r4;->o:Lc/r4;

    :goto_1e
    iget-object v1, v2, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v10, v1, v3, v0}, Lc/s;->e(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_23

    :cond_1e
    if-eqz v12, :cond_1f

    const v2, 0x7f030092

    goto :goto_1f

    :cond_1f
    const v2, 0x7f030096

    :goto_1f
    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v5

    mul-float v6, v0, v3

    iget-object v0, v9, Lc/P3;->K:Lc/a5;

    if-nez v0, :cond_21

    iget-boolean v0, v9, Lc/P3;->o0:Z

    if-eqz v0, :cond_20

    goto :goto_21

    :cond_20
    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    :goto_20
    move v12, v0

    goto :goto_22

    :cond_21
    :goto_21
    const/4 v0, -0x1

    goto :goto_20

    :goto_22
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v4

    move v4, v5

    move v5, v6

    move v6, v12

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :goto_23
    invoke-virtual {v10, v7}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_24

    :cond_22
    move-object/from16 v10, p1

    :goto_24
    invoke-virtual {v13}, Lc/n1;->l0()Z

    move-result v0

    if-nez v0, :cond_23

    xor-int/lit8 v5, v17, 0x1

    const/4 v6, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v18

    move/from16 v3, v24

    move/from16 v4, v19

    invoke-virtual/range {v0 .. v6}, Lc/P3;->A(Landroid/graphics/Canvas;FFFZZ)V

    :cond_23
    if-eqz v17, :cond_24

    iget v0, v11, Landroid/graphics/RectF;->bottom:F

    const/high16 v1, 0x42000000    # 32.0f

    invoke-virtual {v9, v1}, Lc/P3;->s(F)F

    move-result v2

    sub-float/2addr v0, v2

    move v7, v0

    goto :goto_25

    :cond_24
    const/high16 v1, 0x42000000    # 32.0f

    iget v0, v11, Landroid/graphics/RectF;->top:F

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    const v3, 0x3f51eb85    # 0.82f

    mul-float/2addr v2, v3

    add-float/2addr v2, v0

    move v7, v2

    :goto_25
    sub-float v24, v24, v18

    if-eqz v20, :cond_25

    const/4 v0, 0x4

    goto :goto_26

    :cond_25
    const/4 v0, 0x3

    :goto_26
    int-to-float v0, v0

    div-float v24, v24, v0

    const/high16 v0, 0x42700000    # 60.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/high16 v3, 0x42400000    # 48.0f

    invoke-static {v2, v3}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v0, v2

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-virtual {v9, v3}, Lc/P3;->s(F)F

    move-result v3

    div-float v4, v24, v2

    invoke-virtual {v9, v2}, Lc/P3;->s(F)F

    move-result v5

    sub-float v2, v4, v5

    invoke-static {v3, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v0

    add-float v12, v18, v4

    const/high16 v2, 0x3fc00000    # 1.5f

    mul-float v2, v2, v24

    add-float v14, v2, v18

    const/high16 v2, 0x40200000    # 2.5f

    mul-float v2, v2, v24

    add-float v19, v2, v18

    iget-object v2, v9, Lc/P3;->I0:Landroid/graphics/RectF;

    sub-float v3, v12, v0

    sub-float v4, v7, v0

    add-float v5, v12, v0

    add-float v6, v7, v0

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v2, v9, Lc/P3;->J0:Landroid/graphics/RectF;

    sub-float v3, v14, v0

    add-float v5, v14, v0

    invoke-virtual {v2, v3, v4, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v3, v9, Lc/P3;->K0:Landroid/graphics/RectF;

    sub-float v5, v19, v0

    add-float v1, v19, v0

    invoke-virtual {v3, v5, v4, v1, v6}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v1

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v1, v3

    iget-object v3, v9, Lc/P3;->c0:Lc/r4;

    iget-boolean v3, v3, Lc/r4;->m:Z

    if-eqz v3, :cond_26

    const v3, 0x18207090

    goto :goto_27

    :cond_26
    const v3, 0x303e7590

    :goto_27
    invoke-virtual {v9, v10, v2, v1, v3}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    if-eqz v20, :cond_28

    const/high16 v1, 0x40600000    # 3.5f

    mul-float v24, v24, v1

    add-float v3, v24, v18

    sub-float v1, v3, v0

    add-float/2addr v0, v3

    invoke-virtual {v8, v1, v4, v0, v6}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v0, v9, Lc/P3;->f1:Lc/V4;

    if-eqz v0, :cond_27

    iget-boolean v0, v0, Lc/V4;->c:Z

    if-eqz v0, :cond_27

    move/from16 v2, v21

    :goto_28
    const/high16 v0, 0x42000000    # 32.0f

    goto :goto_29

    :cond_27
    move/from16 v2, v16

    goto :goto_28

    :goto_29
    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v7

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_28
    const/high16 v8, 0x42080000    # 34.0f

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const v2, 0x7f030025

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v12

    move v4, v7

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual {v13}, Lc/n1;->l0()Z

    move-result v0

    if-eqz v0, :cond_29

    const v0, 0x7f03009a

    :goto_2a
    move v2, v0

    goto :goto_2b

    :cond_29
    iget-object v0, v9, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->o:Z

    if-eqz v0, :cond_2a

    const v0, 0x7f030023

    goto :goto_2a

    :cond_2a
    const v0, 0x7f030024

    goto :goto_2a

    :goto_2b
    const/high16 v0, 0x42200000    # 40.0f

    invoke-virtual {v9, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move v4, v7

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual {v9, v8}, Lc/P3;->s(F)F

    move-result v5

    iget-object v0, v9, Lc/P3;->c0:Lc/r4;

    iget v6, v0, Lc/r4;->d:I

    const v2, 0x7f030022

    move-object/from16 v0, p0

    move/from16 v3, v19

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    iget-object v0, v9, Lc/P3;->B0:Landroid/graphics/RectF;

    iget v1, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v1, v15

    iget v2, v11, Landroid/graphics/RectF;->top:F

    add-float/2addr v2, v15

    iget v3, v11, Landroid/graphics/RectF;->right:F

    sub-float/2addr v3, v15

    iget v4, v11, Landroid/graphics/RectF;->bottom:F

    if-eqz v17, :cond_2b

    const/high16 v5, 0x42880000    # 68.0f

    :goto_2c
    invoke-virtual {v9, v5}, Lc/P3;->s(F)F

    move-result v5

    goto :goto_2d

    :cond_2b
    const/high16 v5, 0x42f00000    # 120.0f

    goto :goto_2c

    :goto_2d
    sub-float/2addr v4, v5

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    return-void
.end method

.method public final x(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 17

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v0, p2

    iget v1, v0, Landroid/graphics/RectF;->bottom:F

    const/high16 v2, 0x42300000    # 44.0f

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/high16 v4, 0x42400000    # 48.0f

    invoke-static {v3, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v3, v5

    const/high16 v6, 0x41000000    # 8.0f

    invoke-virtual {v7, v6}, Lc/P3;->s(F)F

    move-result v6

    add-float/2addr v6, v3

    invoke-static {v2, v6}, Ljava/lang/Math;->max(FF)F

    move-result v2

    sub-float v9, v1, v2

    iget v1, v0, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v7, v2}, Lc/P3;->s(F)F

    move-result v2

    add-float/2addr v2, v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v1, 0x42000000    # 32.0f

    invoke-virtual {v7, v1}, Lc/P3;->s(F)F

    move-result v1

    sub-float/2addr v0, v1

    iget-object v1, v7, Lc/P3;->B:Lc/U0;

    iget-boolean v1, v1, Lc/U0;->n:Z

    iget-object v10, v7, Lc/P3;->C1:Lc/n1;

    if-nez v1, :cond_1

    invoke-virtual {v10}, Lc/n1;->l0()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v1

    const/high16 v3, 0x40800000    # 4.0f

    mul-float/2addr v1, v3

    cmpl-float v1, v0, v1

    if-ltz v1, :cond_1

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    :goto_1
    if-eqz v1, :cond_2

    const/4 v3, 0x4

    goto :goto_2

    :cond_2
    const/4 v3, 0x3

    :goto_2
    int-to-float v3, v3

    div-float/2addr v0, v3

    const/high16 v3, 0x42700000    # 60.0f

    invoke-virtual {v7, v3}, Lc/P3;->s(F)F

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v3

    div-float/2addr v3, v5

    div-float v4, v0, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/high16 v4, 0x3f000000    # 0.5f

    mul-float/2addr v4, v0

    add-float/2addr v4, v2

    const/high16 v5, 0x3fc00000    # 1.5f

    mul-float/2addr v5, v0

    add-float/2addr v5, v2

    const/high16 v6, 0x40200000    # 2.5f

    mul-float/2addr v6, v0

    add-float/2addr v6, v2

    iget-object v11, v7, Lc/P3;->I0:Landroid/graphics/RectF;

    sub-float v12, v4, v3

    sub-float v13, v9, v3

    add-float/2addr v4, v3

    add-float v14, v9, v3

    invoke-virtual {v11, v12, v13, v4, v14}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v12, v7, Lc/P3;->J0:Landroid/graphics/RectF;

    sub-float v4, v5, v3

    add-float/2addr v5, v3

    invoke-virtual {v12, v4, v13, v5, v14}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v15, v7, Lc/P3;->K0:Landroid/graphics/RectF;

    sub-float v4, v6, v3

    add-float/2addr v6, v3

    invoke-virtual {v15, v4, v13, v6, v14}, Landroid/graphics/RectF;->set(FFFF)V

    iget-boolean v4, v7, Lc/P3;->o0:Z

    if-eqz v4, :cond_3

    const v4, -0x66efe7e0

    goto :goto_3

    :cond_3
    iget-object v4, v7, Lc/P3;->c0:Lc/r4;

    iget v4, v4, Lc/r4;->c:I

    :goto_3
    invoke-virtual {v7, v8, v11, v3, v4}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    invoke-virtual {v7, v8, v12, v3, v4}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    invoke-virtual {v7, v8, v15, v3, v4}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    iget-object v5, v7, Lc/P3;->E0:Landroid/graphics/RectF;

    invoke-virtual {v5}, Landroid/graphics/RectF;->setEmpty()V

    const/16 v16, -0x1

    if-eqz v1, :cond_6

    const/high16 v1, 0x40600000    # 3.5f

    mul-float/2addr v0, v1

    add-float v6, v0, v2

    sub-float v0, v6, v3

    add-float v1, v6, v3

    invoke-virtual {v5, v0, v13, v1, v14}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v7, v8, v5, v3, v4}, Lc/P3;->c0(Landroid/graphics/Canvas;Landroid/graphics/RectF;FI)V

    iget-object v0, v7, Lc/P3;->f1:Lc/V4;

    if-eqz v0, :cond_4

    iget-boolean v0, v0, Lc/V4;->c:Z

    if-eqz v0, :cond_4

    const v0, 0x7f03001a

    :goto_4
    move v2, v0

    goto :goto_5

    :cond_4
    const v0, 0x7f03001b

    goto :goto_4

    :goto_5
    const/high16 v0, 0x41f00000    # 30.0f

    invoke-virtual {v7, v0}, Lc/P3;->s(F)F

    move-result v5

    iget-boolean v0, v7, Lc/P3;->o0:Z

    if-eqz v0, :cond_5

    move/from16 v13, v16

    goto :goto_6

    :cond_5
    iget-object v0, v7, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    move v13, v0

    :goto_6
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v6

    move v4, v9

    move v6, v13

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_6
    iget-object v0, v7, Lc/P3;->B:Lc/U0;

    iget-boolean v13, v0, Lc/U0;->o:Z

    iget-boolean v0, v7, Lc/P3;->o0:Z

    if-eqz v0, :cond_7

    goto :goto_7

    :cond_7
    iget-object v0, v7, Lc/P3;->c0:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    move/from16 v16, v0

    :goto_7
    invoke-virtual {v11}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    const/high16 v11, 0x41f80000    # 31.0f

    invoke-virtual {v7, v11}, Lc/P3;->s(F)F

    move-result v5

    const v2, 0x7f030025

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v9

    move/from16 v6, v16

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual {v10}, Lc/n1;->l0()Z

    move-result v0

    if-eqz v0, :cond_8

    const v0, 0x7f03009a

    :goto_8
    move v2, v0

    goto :goto_9

    :cond_8
    if-eqz v13, :cond_9

    const v0, 0x7f030023

    goto :goto_8

    :cond_9
    const v0, 0x7f030024

    goto :goto_8

    :goto_9
    invoke-virtual {v12}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    const/high16 v0, 0x42100000    # 36.0f

    invoke-virtual {v7, v0}, Lc/P3;->s(F)F

    move-result v5

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v9

    move/from16 v6, v16

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    invoke-virtual {v15}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v7, v11}, Lc/P3;->s(F)F

    move-result v5

    const v2, 0x7f030022

    invoke-virtual/range {v0 .. v6}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    return-void
.end method

.method public final y(Landroid/graphics/Canvas;Ljava/lang/String;FFFIZ)V
    .locals 2

    iget-object v0, p0, Lc/P3;->N:Landroid/graphics/Paint;

    sget-object v1, Lc/P3;->X1:Landroid/graphics/Typeface;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setColor(I)V

    iget-object p5, p0, Lc/P3;->c0:Lc/r4;

    iget-boolean p5, p5, Lc/r4;->m:Z

    if-eqz p5, :cond_0

    if-eqz p7, :cond_0

    const/high16 p5, 0x40200000    # 2.5f

    invoke-virtual {p0, p5}, Lc/P3;->s(F)F

    move-result p5

    const/high16 p6, 0x3f800000    # 1.0f

    invoke-virtual {p0, p6}, Lc/P3;->s(F)F

    move-result p6

    const/high16 p7, -0x50000000

    const/4 v1, 0x0

    invoke-virtual {v0, p5, v1, p6, p7}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/graphics/Paint;->clearShadowLayer()V

    :goto_0
    if-nez p2, :cond_1

    const-string p2, ""

    :cond_1
    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/Paint;->clearShadowLayer()V

    return-void
.end method

.method public final z(Landroid/graphics/Canvas;Landroid/graphics/RectF;)V
    .locals 12

    iget-object v0, p0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v2, 0x3ee66666    # 0.45f

    mul-float v8, v0, v2

    cmpl-float v0, v8, v1

    if-lez v0, :cond_0

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerY()F

    move-result v7

    iget-object p2, p0, Lc/P3;->c0:Lc/r4;

    iget v9, p2, Lc/r4;->e:I

    const v5, 0x7f03009a

    move-object v3, p0

    move-object v4, p1

    invoke-virtual/range {v3 .. v9}, Lc/P3;->E(Landroid/graphics/Canvas;IFFFI)V

    :cond_0
    return-void

    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, p0, Lc/P3;->t0:J

    cmp-long v0, v2, v4

    if-gez v0, :cond_2

    return-void

    :cond_2
    iget-object v0, p0, Lc/P3;->B:Lc/U0;

    iget-boolean v0, v0, Lc/U0;->o:Z

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Lc/Q3;

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Lc/Q3;

    iget-boolean v0, v0, Lc/Q3;->T:Z

    if-eqz v0, :cond_4

    :cond_3
    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 v0, 0x1

    goto :goto_0

    :cond_4
    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Lc/P3;->m0:Lc/B0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    cmpg-float v3, v3, v1

    if-lez v3, :cond_8

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v3

    cmpg-float v3, v3, v1

    if-gtz v3, :cond_5

    goto/16 :goto_2

    :cond_5
    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v4

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    if-eqz v0, :cond_6

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    const-wide/16 v6, 0xc80

    rem-long/2addr v4, v6

    long-to-float v1, v4

    const/high16 v4, 0x45480000    # 3200.0f

    div-float/2addr v1, v4

    :cond_6
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v4

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    const/high16 v6, 0x40000000    # 2.0f

    div-float v6, v3, v6

    sub-float/2addr v5, v6

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerY()F

    move-result p2

    sub-float/2addr p2, v6

    invoke-virtual {p1, v5, p2}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 p2, 0x44000000    # 512.0f

    div-float/2addr v3, p2

    invoke-virtual {p1, v3, v3}, Landroid/graphics/Canvas;->scale(FF)V

    iget-object p2, v2, Lc/B0;->a:Ljava/lang/Object;

    check-cast p2, Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v5, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const v5, 0x1800bfff

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v5, 0x41400000    # 12.0f

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v11, 0x43800000    # 256.0f

    const/high16 v5, 0x43140000    # 148.0f

    invoke-virtual {p1, v11, v11, v5, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v6, 0x3000bfff

    invoke-virtual {p2, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-virtual {p2, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p1, v11, v11, v5, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v6, -0xff4001

    invoke-virtual {p2, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v6, 0x40200000    # 2.5f

    invoke-virtual {p2, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p1, v11, v11, v5, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v5, -0xfd3a01

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v5, 0x40800000    # 4.0f

    invoke-virtual {p2, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget-object v5, v2, Lc/B0;->c:Ljava/lang/Object;

    move-object v6, v5

    check-cast v6, Landroid/graphics/RectF;

    const/high16 v5, 0x43b40000    # 360.0f

    mul-float/2addr v5, v1

    const/high16 v7, -0x3d240000    # -110.0f

    add-float/2addr v7, v5

    const/4 v9, 0x0

    const/high16 v8, 0x42480000    # 50.0f

    move-object v5, p1

    move-object v10, p2

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v5

    if-eqz v0, :cond_7

    float-to-double v6, v1

    const-wide v8, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v6, v8

    const-wide/high16 v8, 0x4000000000000000L    # 2.0

    mul-double/2addr v6, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    move-result-wide v6

    double-to-float v1, v6

    const v6, 0x3d0f5c29    # 0.035f

    mul-float/2addr v1, v6

    const v6, 0x3f80a3d7    # 1.005f

    sub-float/2addr v6, v1

    goto :goto_1

    :cond_7
    const/high16 v6, 0x3f800000    # 1.0f

    :goto_1
    invoke-virtual {p1, v6, v6, v11, v11}, Landroid/graphics/Canvas;->scale(FFFF)V

    const/high16 v1, 0x41840000    # 16.5f

    const/high16 v6, -0x3f000000    # -8.0f

    invoke-virtual {p1, v1, v6}, Landroid/graphics/Canvas;->translate(FF)V

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-object v1, v2, Lc/B0;->d:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/LinearGradient;

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    iget-object v1, v2, Lc/B0;->b:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/Path;

    invoke-virtual {p1, v1, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_8
    :goto_2
    if-eqz v0, :cond_9

    const-wide/16 p1, 0x20

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->postInvalidateDelayed(J)V

    :cond_9
    return-void
.end method
