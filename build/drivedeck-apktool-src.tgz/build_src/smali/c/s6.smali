.class public final synthetic Lc/s6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/H6;

.field public final synthetic b:Landroid/widget/EditText;

.field public final synthetic c:Z

.field public final synthetic d:D

.field public final synthetic e:D

.field public final synthetic f:[D

.field public final synthetic g:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/H6;Landroid/widget/EditText;ZDD[DLjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/s6;->a:Lc/H6;

    iput-object p2, p0, Lc/s6;->b:Landroid/widget/EditText;

    iput-boolean p3, p0, Lc/s6;->c:Z

    iput-wide p4, p0, Lc/s6;->d:D

    iput-wide p6, p0, Lc/s6;->e:D

    iput-object p8, p0, Lc/s6;->f:[D

    iput-object p9, p0, Lc/s6;->g:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/s6;->f:[D

    iget-object v2, v0, Lc/s6;->g:Ljava/lang/String;

    iget-object v3, v0, Lc/s6;->a:Lc/H6;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "engine_litres"

    iget-object v5, v0, Lc/s6;->b:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x2c

    const/16 v8, 0x2e

    invoke-virtual {v6, v7, v8}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v6

    iget-boolean v7, v0, Lc/s6;->c:Z

    if-eqz v7, :cond_0

    const-string v8, "[0-9]+"

    goto :goto_0

    :cond_0
    const-string v8, "[0-9]+(?:\\.[0-9]+)?"

    :goto_0
    invoke-virtual {v6, v8}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    iget-wide v9, v0, Lc/s6;->d:D

    iget-wide v11, v0, Lc/s6;->e:D

    if-eqz v8, :cond_8

    :try_start_0
    invoke-static {v6}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Double;->isFinite(D)Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v6, :cond_6

    cmpg-double v6, v13, v9

    if-ltz v6, :cond_6

    cmpl-double v6, v13, v11

    if-gtz v6, :cond_6

    if-eqz v7, :cond_1

    double-to-int v6, v13

    move-wide v15, v11

    int-to-double v11, v6

    cmpl-double v6, v13, v11

    if-nez v6, :cond_7

    goto :goto_1

    :cond_1
    move-wide v15, v11

    :goto_1
    const/4 v6, 0x0

    :try_start_1
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setError(Ljava/lang/CharSequence;)V

    const/4 v8, 0x0

    aget-wide v11, v1, v8

    invoke-static {v11, v12, v13, v14}, Ljava/lang/Double;->compare(DD)I

    move-result v11

    if-nez v11, :cond_2

    goto/16 :goto_4

    :cond_2
    aput-wide v13, v1, v8

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    iget-object v8, v3, Lc/H6;->c:Lc/T5;

    if-eqz v1, :cond_4

    :try_start_2
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v13, v14}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_3

    const-wide/16 v1, 0x0

    cmpg-double v1, v13, v1

    if-lez v1, :cond_3

    iget-object v1, v8, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    double-to-float v2, v13

    invoke-interface {v1, v4, v2}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iput-object v6, v8, Lc/T5;->t2:Lc/X5;

    invoke-virtual {v8}, Lc/T5;->q()V

    goto :goto_4

    :cond_3
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Engine displacement"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_4
    iget-object v1, v8, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    if-eqz v7, :cond_5

    double-to-int v4, v13

    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_2

    :cond_5
    double-to-float v4, v13

    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    :goto_2
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v8}, Lc/T5;->q()V

    goto :goto_4

    :cond_6
    move-wide v15, v11

    :cond_7
    new-instance v1, Ljava/lang/NumberFormatException;

    invoke-direct {v1}, Ljava/lang/NumberFormatException;-><init>()V

    throw v1

    :catch_0
    move-wide v15, v11

    goto :goto_3

    :cond_8
    move-wide v15, v11

    new-instance v1, Ljava/lang/NumberFormatException;

    invoke-direct {v1}, Ljava/lang/NumberFormatException;-><init>()V

    throw v1
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    :catch_1
    :goto_3
    invoke-virtual {v5}, Landroid/view/View;->hasFocus()Z

    move-result v1

    if-nez v1, :cond_9

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, v3, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0414\u043e\u043f\u0443\u0441\u0442\u0438\u043c\u044b\u0439 \u0434\u0438\u0430\u043f\u0430\u0437\u043e\u043d"

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v9, v10, v7}, Lc/H6;->o(DZ)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\u2013"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-wide v2, v15

    invoke-static {v2, v3, v7}, Lc/H6;->o(DZ)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setError(Ljava/lang/CharSequence;)V

    :cond_9
    :goto_4
    return-void
.end method
