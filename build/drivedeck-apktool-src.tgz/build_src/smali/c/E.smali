.class public final synthetic Lc/E;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/b2;


# direct methods
.method public synthetic constructor <init>(Lc/b2;I)V
    .locals 0

    iput p2, p0, Lc/E;->a:I

    iput-object p1, p0, Lc/E;->b:Lc/b2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/E;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/E;->b:Lc/b2;

    iget-boolean v1, v0, Lc/b2;->k0:Z

    if-nez v1, :cond_0

    iget-boolean v1, v0, Lc/b2;->l0:Z

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v1, v0, Lc/b2;->l0:Z

    const/4 v2, 0x0

    iput-boolean v2, v0, Lc/b2;->l0:Z

    iput-boolean v2, v0, Lc/b2;->k0:Z

    const/4 v3, 0x1

    iput-boolean v3, v0, Lc/b2;->m0:Z

    iget-object v3, v0, Lc/b2;->I:Landroid/graphics/RectF;

    invoke-virtual {v3}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual {v0, v2}, Landroid/view/View;->performHapticFeedback(I)Z

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, v0, Lc/b2;->A:Lc/v8;

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lc/v8;->d()V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Lc/v8;->c()V

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/E;->b:Lc/b2;

    invoke-virtual {v0}, Lc/b2;->K()V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/E;->b:Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/E;->b:Lc/b2;

    invoke-virtual {v0}, Lc/b2;->A()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
