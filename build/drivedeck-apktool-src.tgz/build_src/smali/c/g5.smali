.class public final Lc/g5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final L:Ljava/util/concurrent/ExecutorService;


# instance fields
.field public A:Z

.field public B:Z

.field public C:Z

.field public D:Z

.field public E:Z

.field public F:Z

.field public G:I

.field public final H:Lc/d5;

.field public final I:Landroid/graphics/Path;

.field public J:Landroid/animation/ValueAnimator;

.field public final K:Lc/d5;

.field public final a:Lc/P3;

.field public final b:Landroid/graphics/RectF;

.field public final c:Landroid/graphics/RectF;

.field public final d:Landroid/graphics/RectF;

.field public final e:Landroid/graphics/Camera;

.field public final f:Landroid/graphics/Matrix;

.field public final g:Landroid/graphics/Paint;

.field public h:F

.field public i:F

.field public final j:[Lc/T4;

.field public final k:Landroid/graphics/drawable/Drawable;

.field public final l:Ljava/util/LinkedHashMap;

.field public final m:Ljava/util/LinkedHashMap;

.field public n:Ljava/lang/String;

.field public o:Landroid/graphics/Bitmap;

.field public p:Landroid/graphics/Bitmap;

.field public q:I

.field public final r:Ljava/util/ArrayList;

.field public s:I

.field public t:I

.field public u:[Lc/f5;

.field public v:[Lc/f5;

.field public w:F

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Lc/o3;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lc/o3;-><init>(I)V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lc/g5;->L:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method public constructor <init>(Lc/P3;)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/g5;->b:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/g5;->c:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/g5;->d:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/Camera;

    invoke-direct {v0}, Landroid/graphics/Camera;-><init>()V

    iput-object v0, p0, Lc/g5;->e:Landroid/graphics/Camera;

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Lc/g5;->f:Landroid/graphics/Matrix;

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/g5;->g:Landroid/graphics/Paint;

    const/high16 v0, 0x7fc00000    # Float.NaN

    iput v0, p0, Lc/g5;->h:F

    iput v0, p0, Lc/g5;->i:F

    new-instance v0, Lc/T4;

    invoke-direct {v0}, Lc/T4;-><init>()V

    new-instance v2, Lc/T4;

    invoke-direct {v2}, Lc/T4;-><init>()V

    new-instance v3, Lc/T4;

    invoke-direct {v3}, Lc/T4;-><init>()V

    filled-new-array {v0, v2, v3}, [Lc/T4;

    move-result-object v0

    iput-object v0, p0, Lc/g5;->j:[Lc/T4;

    new-instance v0, Ljava/util/LinkedHashMap;

    const/16 v2, 0x10

    const/high16 v3, 0x3f400000    # 0.75f

    invoke-direct {v0, v2, v3, v1}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object v0, p0, Lc/g5;->l:Ljava/util/LinkedHashMap;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc/g5;->m:Ljava/util/LinkedHashMap;

    const-string v0, ""

    iput-object v0, p0, Lc/g5;->n:Ljava/lang/String;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/g5;->r:Ljava/util/ArrayList;

    const/4 v2, -0x1

    iput v2, p0, Lc/g5;->s:I

    new-instance v2, Lc/f5;

    const/4 v3, 0x0

    invoke-direct {v2, v0, v3, v3}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v4, Lc/f5;

    invoke-direct {v4, v0, v3, v3}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v5, Lc/f5;

    invoke-direct {v5, v0, v3, v3}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    filled-new-array {v2, v4, v5}, [Lc/f5;

    move-result-object v0

    iput-object v0, p0, Lc/g5;->u:[Lc/f5;

    iput v1, p0, Lc/g5;->G:I

    new-instance v0, Lc/d5;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/d5;-><init>(Lc/g5;I)V

    iput-object v0, p0, Lc/g5;->H:Lc/d5;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/g5;->I:Landroid/graphics/Path;

    new-instance v0, Lc/d5;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/d5;-><init>(Lc/g5;I)V

    iput-object v0, p0, Lc/g5;->K:Lc/d5;

    iput-object p1, p0, Lc/g5;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f030026

    invoke-virtual {p1, v0}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    iput-object p1, p0, Lc/g5;->k:Landroid/graphics/drawable/Drawable;

    return-void
.end method

.method public static f(Ljava/io/InputStream;)[B
    .locals 5

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v1, 0x2000

    new-array v1, v1, [B

    :goto_0
    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v3

    add-int/2addr v3, v2

    const/high16 v4, 0x200000

    if-gt v3, v4, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string v0, "Cover too large"

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    return-object p0
.end method

.method public static h(Landroid/content/Context;Landroid/net/Uri;)Landroid/graphics/Bitmap;
    .locals 6

    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v0

    const-string v1, "content"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v1, :cond_8

    const-string v1, "android.resource"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_4

    :cond_0
    const-string p0, "https"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    new-instance v0, Ljava/net/URL;

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    move p1, v2

    :goto_0
    const/4 v1, 0x4

    if-ge p1, v1, :cond_6

    invoke-virtual {v0}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    return-object v3

    :cond_1
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    const/16 v4, 0xbb8

    invoke-virtual {v1, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v1, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    :try_start_0
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v4

    const/16 v5, 0x12c

    if-lt v4, v5, :cond_3

    const/16 v5, 0x190

    if-ge v4, v5, :cond_3

    const-string v4, "Location"

    invoke-virtual {v1, v4}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-nez v4, :cond_2

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object v3

    :cond_2
    :try_start_1
    new-instance v5, Ljava/net/URL;

    invoke-direct {v5, v0, v4}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    add-int/lit8 p1, p1, 0x1

    move-object v0, v5

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_3
    const/16 p0, 0xc8

    if-eq v4, p0, :cond_4

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object v3

    :cond_4
    :try_start_2
    invoke-virtual {v1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    invoke-static {p0}, Lc/g5;->f(Ljava/io/InputStream;)[B

    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_3

    :catchall_1
    move-exception p1

    if-eqz p0, :cond_5

    :try_start_5
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_1

    :catchall_2
    move-exception p0

    :try_start_6
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_5
    :goto_1
    throw p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_2
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p0

    :cond_6
    move-object p1, v3

    :goto_3
    if-nez p1, :cond_b

    :cond_7
    return-object v3

    :cond_8
    :goto_4
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    invoke-virtual {p0, p1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p0

    if-nez p0, :cond_a

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    :cond_9
    return-object v3

    :cond_a
    :try_start_7
    invoke-static {p0}, Lc/g5;->f(Ljava/io/InputStream;)[B

    move-result-object p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    :cond_b
    new-instance p0, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {p0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v1, p1

    invoke-static {p1, v2, v1, p0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    iget v1, p0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    if-lez v1, :cond_e

    iget v1, p0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    if-gtz v1, :cond_c

    goto :goto_6

    :cond_c
    iput v0, p0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    :goto_5
    iget v0, p0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    iget v1, p0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget v1, p0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    div-int/2addr v0, v1

    const/16 v3, 0x200

    if-le v0, v3, :cond_d

    mul-int/lit8 v1, v1, 0x2

    iput v1, p0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    goto :goto_5

    :cond_d
    iput-boolean v2, p0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v0, p1

    invoke-static {p1, v2, v0, p0}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    :cond_e
    :goto_6
    return-object v3

    :catchall_3
    move-exception p1

    :try_start_8
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    goto :goto_7

    :catchall_4
    move-exception p0

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_7
    throw p1
.end method


# virtual methods
.method public final a(Landroid/media/session/MediaSession$QueueItem;)Lc/f5;
    .locals 5

    if-nez p1, :cond_0

    new-instance p1, Lc/f5;

    const-string v0, ""

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1, v1}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    return-object p1

    :cond_0
    invoke-virtual {p1}, Landroid/media/session/MediaSession$QueueItem;->getDescription()Landroid/media/MediaDescription;

    move-result-object p1

    invoke-virtual {p1}, Landroid/media/MediaDescription;->getIconUri()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {p1}, Landroid/media/MediaDescription;->getMediaId()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    const-string v2, "media:"

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_2
    :goto_0
    invoke-virtual {p1}, Landroid/media/MediaDescription;->getTitle()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {p1}, Landroid/media/MediaDescription;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_1
    if-nez v0, :cond_3

    move-object v2, v1

    goto :goto_2

    :cond_3
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "uri:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_2
    iget-object v3, p0, Lc/g5;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/graphics/Bitmap;

    if-nez v4, :cond_4

    invoke-virtual {p1}, Landroid/media/MediaDescription;->getIconBitmap()Landroid/graphics/Bitmap;

    move-result-object v4

    if-eqz v4, :cond_4

    invoke-virtual {v4}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result p1

    if-nez p1, :cond_4

    invoke-virtual {p0, v2, v4}, Lc/g5;->i(Ljava/lang/String;Landroid/graphics/Bitmap;)V

    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    move-object v4, p1

    check-cast v4, Landroid/graphics/Bitmap;

    :cond_4
    new-instance p1, Lc/f5;

    invoke-direct {p1, v1, v4, v0}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    return-object p1
.end method

.method public final b()V
    .locals 5

    iget-object v0, p0, Lc/g5;->a:Lc/P3;

    iget-object v1, p0, Lc/g5;->K:Lc/d5;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v1, p0, Lc/g5;->H:Lc/d5;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g5;->F:Z

    iput-boolean v0, p0, Lc/g5;->E:Z

    iget-object v1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/animation/Animator;->removeAllListeners()V

    iget-object v1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v2, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    :cond_0
    iget v1, p0, Lc/g5;->t:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lc/g5;->t:I

    iput-object v2, p0, Lc/g5;->p:Landroid/graphics/Bitmap;

    iput-object v2, p0, Lc/g5;->o:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lc/g5;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v1, p0, Lc/g5;->m:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v1, p0, Lc/g5;->r:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v1, -0x1

    iput v1, p0, Lc/g5;->s:I

    const-string v1, ""

    iput-object v1, p0, Lc/g5;->n:Ljava/lang/String;

    const/4 v3, 0x0

    iput v3, p0, Lc/g5;->w:F

    iput-boolean v0, p0, Lc/g5;->B:Z

    iput-boolean v0, p0, Lc/g5;->A:Z

    iput-boolean v0, p0, Lc/g5;->C:Z

    iput-object v2, p0, Lc/g5;->v:[Lc/f5;

    new-instance v0, Lc/f5;

    invoke-direct {v0, v1, v2, v2}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v3, Lc/f5;

    invoke-direct {v3, v1, v2, v2}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v4, Lc/f5;

    invoke-direct {v4, v1, v2, v2}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    filled-new-array {v0, v3, v4}, [Lc/f5;

    move-result-object v0

    iput-object v0, p0, Lc/g5;->u:[Lc/f5;

    return-void
.end method

.method public final c(Landroid/graphics/Canvas;ILc/b5;F)V
    .locals 9

    add-int/lit8 v1, p2, -0x1

    int-to-float v1, v1

    iget v2, p0, Lc/g5;->w:F

    add-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v3, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const v4, 0x3e75c28f    # 0.24f

    mul-float/2addr v2, v4

    sub-float/2addr v3, v2

    iget-object v2, p0, Lc/g5;->b:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    iget v5, p0, Lc/g5;->z:F

    mul-float/2addr v5, v1

    add-float/2addr v5, v4

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v8

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    invoke-virtual {p1, v5, v4}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v4, p0, Lc/g5;->e:Landroid/graphics/Camera;

    invoke-virtual {v4}, Landroid/graphics/Camera;->save()V

    const/high16 v5, -0x3f000000    # -8.0f

    mul-float/2addr v5, p4

    const/4 v6, 0x0

    invoke-virtual {v4, v6, v6, v5}, Landroid/graphics/Camera;->setLocation(FFF)V

    neg-float v1, v1

    const/high16 v5, 0x42400000    # 48.0f

    mul-float/2addr v1, v5

    invoke-virtual {v4, v1}, Landroid/graphics/Camera;->rotateY(F)V

    iget-object v1, p0, Lc/g5;->f:Landroid/graphics/Matrix;

    invoke-virtual {v4, v1}, Landroid/graphics/Camera;->getMatrix(Landroid/graphics/Matrix;)V

    invoke-virtual {v4}, Landroid/graphics/Camera;->restore()V

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    invoke-virtual {p1, v3, v3}, Landroid/graphics/Canvas;->scale(FF)V

    iget-object v3, p0, Lc/g5;->d:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v1

    neg-float v1, v1

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v1, v4

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v5

    neg-float v5, v5

    div-float/2addr v5, v4

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v6

    div-float/2addr v6, v4

    invoke-virtual {v2}, Landroid/graphics/RectF;->height()F

    move-result v2

    div-float/2addr v2, v4

    invoke-virtual {v3, v1, v5, v6, v2}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {p3, p1, v3, p4}, Lc/b5;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;F)V

    iget-object v1, p0, Lc/g5;->u:[Lc/f5;

    aget-object v1, v1, p2

    iget-object v2, v1, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lc/g5;->j:[Lc/T4;

    aget-object v1, v1, p2

    const/high16 v4, 0x41c00000    # 24.0f

    mul-float/2addr v4, p4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v0, v1

    move-object v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/T4;->a(Landroid/graphics/Canvas;Landroid/graphics/Bitmap;Landroid/graphics/RectF;FIIZ)V

    goto :goto_0

    :cond_0
    iget v0, v3, Landroid/graphics/RectF;->left:F

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    iget v1, v3, Landroid/graphics/RectF;->top:F

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iget v2, v3, Landroid/graphics/RectF;->right:F

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v3, v3, Landroid/graphics/RectF;->bottom:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    iget-object v4, p0, Lc/g5;->k:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4, v0, v1, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :goto_0
    invoke-virtual {p1, v8}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method

.method public final d()V
    .locals 3

    iget-object v0, p0, Lc/g5;->v:[Lc/f5;

    if-eqz v0, :cond_2

    const/4 v1, 0x1

    aget-object v0, v0, v1

    iget-object v0, v0, Lc/f5;->a:Ljava/lang/String;

    iget-object v2, p0, Lc/g5;->u:[Lc/f5;

    aget-object v2, v2, v1

    iget-object v2, v2, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/g5;->F:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/g5;->v:[Lc/f5;

    aget-object v0, v0, v1

    iget-object v0, v0, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    return-void

    :cond_1
    iget-object v0, p0, Lc/g5;->v:[Lc/f5;

    iput-object v0, p0, Lc/g5;->u:[Lc/f5;

    const/4 v0, 0x0

    iput-object v0, p0, Lc/g5;->v:[Lc/f5;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g5;->C:Z

    const/4 v0, 0x0

    iput v0, p0, Lc/g5;->w:F

    iget-object v0, p0, Lc/g5;->a:Lc/P3;

    iget-object v1, p0, Lc/g5;->K:Lc/d5;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_2
    return-void
.end method

.method public final e()Z
    .locals 2

    iget-boolean v0, p0, Lc/g5;->D:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/g5;->u:[Lc/f5;

    const/4 v1, 0x1

    aget-object v0, v0, v1

    iget-object v0, v0, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final g(Lc/f5;)V
    .locals 10

    iget-object v0, p1, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-nez v0, :cond_3

    iget-object v0, p1, Lc/f5;->b:Landroid/net/Uri;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lc/g5;->n:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-object v2, p0, Lc/g5;->m:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Long;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    sub-long v3, v0, v3

    const-wide/16 v5, 0x7530

    cmp-long v3, v3, v5

    if-gez v3, :cond_1

    return-void

    :cond_1
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v2, v9, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    invoke-virtual {v2}, Ljava/util/AbstractMap;->size()I

    move-result v0

    const/16 v1, 0x40

    if-le v0, v1, :cond_2

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_2
    iget-object v8, p0, Lc/g5;->n:Ljava/lang/String;

    iget v7, p0, Lc/g5;->t:I

    iget-object v0, p0, Lc/g5;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    new-instance v0, Lc/c5;

    move-object v3, v0

    move-object v4, p0

    move-object v6, p1

    invoke-direct/range {v3 .. v9}, Lc/c5;-><init>(Lc/g5;Landroid/content/Context;Lc/f5;ILjava/lang/String;Ljava/lang/String;)V

    sget-object p1, Lc/g5;->L:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public final i(Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .locals 6

    iget-object v0, p0, Lc/g5;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    const/16 v2, 0x200

    if-le v1, v2, :cond_1

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    mul-int/2addr v3, v2

    div-int/2addr v3, v1

    const/4 v4, 0x1

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    mul-int/2addr v5, v2

    div-int/2addr v5, v1

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {p2, v3, v1, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object p2

    :cond_1
    invoke-virtual {v0, p1, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    invoke-virtual {v0}, Ljava/util/AbstractMap;->size()I

    move-result p1

    const/16 p2, 0xc

    if-le p1, p2, :cond_2

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final j(FLjava/lang/Runnable;)V
    .locals 4

    const/4 v0, 0x2

    iget-object v1, p0, Lc/g5;->a:Lc/P3;

    iget-object v2, p0, Lc/g5;->K:Lc/d5;

    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object v3, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-eqz v3, :cond_0

    invoke-virtual {v3}, Landroid/animation/Animator;->removeAllListeners()V

    iget-object v3, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    invoke-virtual {v3}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_0
    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v3

    if-nez v3, :cond_4

    iput p1, p0, Lc/g5;->w:F

    if-eqz p2, :cond_1

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :cond_1
    iget-boolean p1, p0, Lc/g5;->C:Z

    if-eqz p1, :cond_2

    invoke-virtual {p0}, Lc/g5;->d()V

    iget-boolean p1, p0, Lc/g5;->C:Z

    if-eqz p1, :cond_3

    const-wide/16 p1, 0x898

    invoke-virtual {v1, v2, p1, p2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    iput p1, p0, Lc/g5;->w:F

    :cond_3
    :goto_0
    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    return-void

    :cond_4
    iget v1, p0, Lc/g5;->w:F

    new-array v2, v0, [F

    const/4 v3, 0x0

    aput v1, v2, v3

    const/4 v1, 0x1

    aput p1, v2, v1

    invoke-static {v2}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v1

    iput-object v1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    const-wide/16 v2, 0x118

    invoke-virtual {v1, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object v1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    new-instance v2, Lc/X1;

    invoke-direct {v2, p0, v0}, Lc/X1;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object v0, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    new-instance v1, Lc/e5;

    invoke-direct {v1, p0, p1}, Lc/e5;-><init>(Lc/g5;F)V

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    iget-object p1, p0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    if-eqz p2, :cond_5

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    :cond_5
    return-void
.end method

.method public final k(ZLjava/lang/Runnable;)Z
    .locals 2

    iget-boolean v0, p0, Lc/g5;->C:Z

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/g5;->C:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc/g5;->v:[Lc/f5;

    iget-boolean v1, p0, Lc/g5;->D:Z

    if-eqz v1, :cond_2

    if-eqz p1, :cond_1

    move p1, v0

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    :goto_0
    iput p1, p0, Lc/g5;->G:I

    invoke-virtual {p0}, Lc/g5;->n()V

    invoke-interface {p2}, Ljava/lang/Runnable;->run()V

    goto :goto_2

    :cond_2
    if-eqz p1, :cond_3

    const/high16 p1, -0x40800000    # -1.0f

    goto :goto_1

    :cond_3
    const/high16 p1, 0x3f800000    # 1.0f

    :goto_1
    invoke-virtual {p0, p1, p2}, Lc/g5;->j(FLjava/lang/Runnable;)V

    :goto_2
    return v0
.end method

.method public final l(Z)V
    .locals 4

    iget-boolean v0, p0, Lc/g5;->E:Z

    if-eqz v0, :cond_5

    iget-object v0, p0, Lc/g5;->v:[Lc/f5;

    if-eqz v0, :cond_5

    const/4 v1, 0x1

    aget-object v0, v0, v1

    iget-object v0, v0, Lc/f5;->a:Ljava/lang/String;

    iget-object v2, p0, Lc/g5;->u:[Lc/f5;

    aget-object v2, v2, v1

    iget-object v2, v2, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/g5;->v:[Lc/f5;

    aget-object v0, v0, v1

    iget-object v0, v0, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-nez p1, :cond_2

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    return-void

    :cond_2
    iput-boolean v1, p0, Lc/g5;->C:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g5;->E:Z

    iput-boolean p1, p0, Lc/g5;->F:Z

    iget-object p1, p0, Lc/g5;->H:Lc/d5;

    iget-object v2, p0, Lc/g5;->a:Lc/P3;

    invoke-virtual {v2, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-object p1, p0, Lc/g5;->u:[Lc/f5;

    iget v2, p0, Lc/g5;->G:I

    if-lez v2, :cond_3

    const/4 v0, 0x2

    :cond_3
    iget-object v3, p0, Lc/g5;->v:[Lc/f5;

    aget-object v1, v3, v1

    aput-object v1, p1, v0

    if-lez v2, :cond_4

    const/high16 p1, -0x40800000    # -1.0f

    goto :goto_0

    :cond_4
    const/high16 p1, 0x3f800000    # 1.0f

    :goto_0
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lc/g5;->j(FLjava/lang/Runnable;)V

    :cond_5
    :goto_1
    return-void
.end method

.method public final m(Landroid/media/session/MediaController;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .locals 22

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    iget-object v5, v0, Lc/g5;->n:Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/g5;->b()V

    iput-object v1, v0, Lc/g5;->n:Ljava/lang/String;

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\n"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_5

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->isRecycled()Z

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_0

    :cond_1
    iget-object v7, v0, Lc/g5;->o:Landroid/graphics/Bitmap;

    if-ne v7, v4, :cond_2

    iget v7, v0, Lc/g5;->q:I

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getGenerationId()I

    move-result v8

    if-eq v7, v8, :cond_4

    :cond_2
    iput-object v4, v0, Lc/g5;->o:Landroid/graphics/Bitmap;

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getGenerationId()I

    move-result v7

    iput v7, v0, Lc/g5;->q:I

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v7

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v7

    const/16 v8, 0x200

    if-le v7, v8, :cond_3

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v9

    mul-int/2addr v9, v8

    div-int/2addr v9, v7

    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-virtual/range {p5 .. p5}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v10

    mul-int/2addr v10, v8

    div-int/2addr v10, v7

    invoke-static {v5, v10}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-static {v4, v9, v7, v5}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v4

    :cond_3
    iput-object v4, v0, Lc/g5;->p:Landroid/graphics/Bitmap;

    :cond_4
    iget-object v4, v0, Lc/g5;->p:Landroid/graphics/Bitmap;

    goto :goto_1

    :cond_5
    :goto_0
    move-object v4, v6

    :goto_1
    new-instance v7, Lc/f5;

    invoke-direct {v7, v1, v4, v6}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v1, Lc/f5;

    const-string v8, ""

    invoke-direct {v1, v8, v6, v6}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    new-instance v9, Lc/f5;

    invoke-direct {v9, v8, v6, v6}, Lc/f5;-><init>(Ljava/lang/String;Landroid/graphics/Bitmap;Landroid/net/Uri;)V

    if-nez p1, :cond_6

    move-object v12, v6

    goto :goto_2

    :cond_6
    :try_start_0
    invoke-virtual/range {p1 .. p1}, Landroid/media/session/MediaController;->getQueue()Ljava/util/List;

    move-result-object v12

    :goto_2
    if-nez p1, :cond_7

    move-object v13, v6

    goto :goto_3

    :cond_7
    invoke-virtual/range {p1 .. p1}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v13

    :goto_3
    if-nez p1, :cond_8

    move-object v14, v6

    goto :goto_4

    :cond_8
    invoke-virtual/range {p1 .. p1}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v14

    :goto_4
    if-nez v14, :cond_9

    goto :goto_5

    :cond_9
    const-string v6, "android.media.metadata.MEDIA_ID"

    invoke-virtual {v14, v6}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_5
    if-eqz v12, :cond_17

    if-nez v13, :cond_a

    const-wide/16 v16, -0x1

    goto :goto_6

    :cond_a
    invoke-virtual {v13}, Landroid/media/session/PlaybackState;->getActiveQueueItemId()J

    move-result-wide v16

    :goto_6
    const/4 v10, -0x1

    const/4 v11, 0x0

    const/4 v13, 0x0

    :goto_7
    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v5

    if-ge v13, v5, :cond_14

    invoke-interface {v12, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/media/session/MediaSession$QueueItem;

    if-nez v5, :cond_b

    :goto_8
    const-wide/16 v18, -0x1

    goto :goto_c

    :cond_b
    invoke-virtual {v5}, Landroid/media/session/MediaSession$QueueItem;->getDescription()Landroid/media/MediaDescription;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Landroid/media/MediaDescription;->getTitle()Ljava/lang/CharSequence;

    move-result-object v19

    if-nez v19, :cond_c

    move-object v14, v8

    goto :goto_9

    :cond_c
    invoke-virtual/range {v18 .. v18}, Landroid/media/MediaDescription;->getTitle()Ljava/lang/CharSequence;

    move-result-object v19

    move-object/from16 v14, v19

    :goto_9
    invoke-virtual {v2, v14}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v6, :cond_d

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_d

    invoke-virtual/range {v18 .. v18}, Landroid/media/MediaDescription;->getMediaId()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v6, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_d

    const/4 v15, 0x4

    goto :goto_a

    :cond_d
    const/4 v15, 0x0

    :goto_a
    if-eqz v14, :cond_e

    add-int/lit8 v15, v15, 0x2

    :cond_e
    if-nez v15, :cond_f

    goto :goto_8

    :cond_f
    invoke-virtual/range {v18 .. v18}, Landroid/media/MediaDescription;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v14

    if-nez v14, :cond_10

    move-object v14, v8

    goto :goto_b

    :cond_10
    invoke-virtual/range {v18 .. v18}, Landroid/media/MediaDescription;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v14

    :goto_b
    invoke-virtual {v3, v14}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_11

    add-int/lit8 v15, v15, 0x1

    :cond_11
    const-wide/16 v18, -0x1

    cmp-long v14, v16, v18

    if-eqz v14, :cond_12

    invoke-virtual {v5}, Landroid/media/session/MediaSession$QueueItem;->getQueueId()J

    move-result-wide v20

    cmp-long v5, v20, v16

    if-nez v5, :cond_12

    add-int/lit8 v15, v15, 0x1

    :cond_12
    if-le v15, v11, :cond_13

    move v10, v13

    move v11, v15

    :cond_13
    :goto_c
    add-int/lit8 v13, v13, 0x1

    goto :goto_7

    :cond_14
    if-ltz v10, :cond_17

    invoke-interface {v12, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaSession$QueueItem;

    invoke-virtual {v0, v2}, Lc/g5;->a(Landroid/media/session/MediaSession$QueueItem;)Lc/f5;

    move-result-object v7

    iget-object v2, v7, Lc/f5;->c:Landroid/graphics/Bitmap;

    if-nez v2, :cond_15

    iget-object v2, v7, Lc/f5;->b:Landroid/net/Uri;

    if-nez v2, :cond_15

    iput-object v4, v7, Lc/f5;->c:Landroid/graphics/Bitmap;

    :cond_15
    if-lez v10, :cond_16

    add-int/lit8 v2, v10, -0x1

    invoke-interface {v12, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaSession$QueueItem;

    invoke-virtual {v0, v2}, Lc/g5;->a(Landroid/media/session/MediaSession$QueueItem;)Lc/f5;

    move-result-object v1

    :cond_16
    const/4 v2, 0x1

    add-int/2addr v10, v2

    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v2

    if-ge v10, v2, :cond_17

    invoke-interface {v12, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaSession$QueueItem;

    invoke-virtual {v0, v2}, Lc/g5;->a(Landroid/media/session/MediaSession$QueueItem;)Lc/f5;

    move-result-object v9
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_17
    iget v2, v0, Lc/g5;->s:I

    const/4 v3, 0x0

    :goto_d
    iget-object v4, v0, Lc/g5;->r:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    iget-object v6, v7, Lc/f5;->a:Ljava/lang/String;

    if-ge v3, v5, :cond_19

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/f5;

    iget-object v5, v5, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_18

    goto :goto_e

    :cond_18
    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    :cond_19
    const/4 v3, -0x1

    :goto_e
    if-ltz v3, :cond_1a

    iput v3, v0, Lc/g5;->s:I

    invoke-virtual {v4, v3, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x1

    goto :goto_10

    :cond_1a
    :goto_f
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    iget v5, v0, Lc/g5;->s:I

    const/4 v8, 0x1

    add-int/2addr v5, v8

    if-le v3, v5, :cond_1b

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v8

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_f

    :cond_1b
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v5, 0xc

    if-le v3, v5, :cond_1c

    const/4 v3, 0x0

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_1c
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v8

    iput v3, v0, Lc/g5;->s:I

    :goto_10
    iget-object v3, v1, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1d

    iget v3, v0, Lc/g5;->s:I

    if-lez v3, :cond_1d

    sub-int/2addr v3, v8

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/f5;

    :cond_1d
    iget-object v3, v9, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1e

    iget v3, v0, Lc/g5;->s:I

    add-int/2addr v3, v8

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_1e

    iget v3, v0, Lc/g5;->s:I

    add-int/2addr v3, v8

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    move-object v9, v3

    check-cast v9, Lc/f5;

    :cond_1e
    filled-new-array {v1, v7, v9}, [Lc/f5;

    move-result-object v3

    invoke-virtual {v0, v1}, Lc/g5;->g(Lc/f5;)V

    invoke-virtual {v0, v7}, Lc/g5;->g(Lc/f5;)V

    invoke-virtual {v0, v9}, Lc/g5;->g(Lc/f5;)V

    iget-boolean v1, v0, Lc/g5;->C:Z

    if-eqz v1, :cond_20

    iput-object v3, v0, Lc/g5;->v:[Lc/f5;

    iget-boolean v1, v0, Lc/g5;->E:Z

    if-eqz v1, :cond_1f

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/g5;->l(Z)V

    goto :goto_12

    :cond_1f
    iget-object v1, v0, Lc/g5;->J:Landroid/animation/ValueAnimator;

    if-nez v1, :cond_23

    iget-object v1, v0, Lc/g5;->u:[Lc/f5;

    const/4 v4, 0x1

    aget-object v1, v1, v4

    iget-object v1, v1, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_23

    invoke-virtual/range {p0 .. p0}, Lc/g5;->d()V

    goto :goto_12

    :cond_20
    const/4 v4, 0x1

    iget-object v1, v0, Lc/g5;->u:[Lc/f5;

    aget-object v1, v1, v4

    iget-object v1, v1, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_22

    iget-object v1, v0, Lc/g5;->u:[Lc/f5;

    aget-object v1, v1, v4

    iget-object v1, v1, Lc/f5;->a:Ljava/lang/String;

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    iget v1, v0, Lc/g5;->s:I

    if-lt v1, v2, :cond_21

    move v10, v4

    goto :goto_11

    :cond_21
    const/4 v10, -0x1

    :goto_11
    iput v10, v0, Lc/g5;->G:I

    iput-object v3, v0, Lc/g5;->v:[Lc/f5;

    iput-boolean v4, v0, Lc/g5;->C:Z

    invoke-virtual/range {p0 .. p0}, Lc/g5;->n()V

    goto :goto_12

    :cond_22
    iput-object v3, v0, Lc/g5;->u:[Lc/f5;

    :cond_23
    :goto_12
    return-void
.end method

.method public final n()V
    .locals 5

    const/4 v0, 0x0

    iput v0, p0, Lc/g5;->w:F

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/g5;->E:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g5;->F:Z

    iget-object v1, p0, Lc/g5;->a:Lc/P3;

    iget-object v2, p0, Lc/g5;->H:Lc/d5;

    invoke-virtual {v1, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const-wide/16 v3, 0x9c4

    invoke-virtual {v1, v2, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {p0, v0}, Lc/g5;->l(Z)V

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    return-void
.end method
