.class public final Lc/R8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/a9;


# instance fields
.field public final synthetic a:Landroid/widget/TextView;

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:Lc/N8;

.field public final synthetic d:[Lc/U8;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/N8;[Lc/U8;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/R8;->a:Landroid/widget/TextView;

    iput-object p2, p0, Lc/R8;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/R8;->c:Lc/N8;

    iput-object p4, p0, Lc/R8;->d:[Lc/U8;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/R8;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lc/R8;->a:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lc/R8;->c:Lc/N8;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lc/N8;->setEnabled(Z)V

    return-void
.end method

.method public final b()V
    .locals 2

    iget-object v0, p0, Lc/R8;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v1, "\u041d\u043e\u0432\u044b\u0445 \u0432\u0435\u0440\u0441\u0438\u0439 \u0432 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u043c \u043a\u0430\u043d\u0430\u043b\u0435 \u043d\u0435\u0442."

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/R8;->a:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc/R8;->c:Lc/N8;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/N8;->setEnabled(Z)V

    return-void
.end method

.method public final c(Lc/U8;)V
    .locals 2

    iget-object v0, p0, Lc/R8;->d:[Lc/U8;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    iget-object v0, p0, Lc/R8;->a:Landroid/widget/TextView;

    iget-object v1, p0, Lc/R8;->c:Lc/N8;

    invoke-static {v0, v1, p1}, Lc/k6;->n0(Landroid/widget/TextView;Lc/N8;Lc/U8;)V

    const/4 p1, 0x1

    invoke-virtual {v1, p1}, Lc/N8;->setEnabled(Z)V

    return-void
.end method
