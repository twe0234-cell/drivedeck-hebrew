.class public final synthetic Lc/Z3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnSystemUiVisibilityChangeListener;


# instance fields
.field public final synthetic a:Landroid/view/View;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Landroid/view/View;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Z3;->a:Landroid/view/View;

    iput p2, p0, Lc/Z3;->b:I

    return-void
.end method


# virtual methods
.method public final onSystemUiVisibilityChange(I)V
    .locals 2

    iget-object v0, p0, Lc/Z3;->a:Landroid/view/View;

    invoke-static {v0}, Lc/b4;->c(Landroid/view/View;)Z

    move-result v1

    if-nez v1, :cond_0

    iget v1, p0, Lc/Z3;->b:I

    and-int/2addr p1, v1

    if-eq p1, v1, :cond_0

    new-instance p1, Lc/n1;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {p1, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lc/n1;->L()I

    move-result p1

    invoke-static {v0, p1}, Lc/b4;->a(Landroid/view/View;I)V

    :cond_0
    return-void
.end method
