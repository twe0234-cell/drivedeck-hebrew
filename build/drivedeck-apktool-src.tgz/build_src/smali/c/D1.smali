.class public final synthetic Lc/D1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/N1;


# direct methods
.method public synthetic constructor <init>(Lc/N1;I)V
    .locals 0

    iput p2, p0, Lc/D1;->a:I

    iput-object p1, p0, Lc/D1;->b:Lc/N1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 18

    move-object/from16 v1, p0

    iget v0, v1, Lc/D1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    iget-object v3, v0, Lc/N1;->D:Ljava/util/Set;

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/Activity;

    invoke-virtual {v0, v3}, Lc/N1;->a(Landroid/app/Activity;)V

    goto :goto_0

    :cond_1
    :goto_1
    return-void

    :pswitch_0
    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    invoke-virtual {v0}, Lc/N1;->w()V

    invoke-virtual {v0, v3}, Lc/N1;->l(Z)V

    :cond_2
    const/4 v0, 0x0

    invoke-static {v0, v3}, Lc/N1;->D(Lc/H;Z)V

    return-void

    :pswitch_1
    new-instance v0, Ljava/util/ArrayList;

    iget-object v2, v1, Lc/D1;->b:Lc/N1;

    iget-object v3, v2, Lc/N1;->C:Ljava/util/WeakHashMap;

    invoke-virtual {v3}, Ljava/util/WeakHashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/Activity;

    invoke-virtual {v2, v3}, Lc/N1;->f(Landroid/app/Activity;)V

    goto :goto_2

    :cond_3
    return-void

    :pswitch_2
    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iput-wide v2, v0, Lc/N1;->O:J

    iget-object v0, v0, Lc/N1;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :pswitch_3
    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    iget-object v2, v0, Lc/N1;->v:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-virtual {v0, v3}, Lc/N1;->l(Z)V

    return-void

    :pswitch_4
    const/4 v0, 0x0

    iget-object v2, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v2, v0}, Lc/N1;->l(Z)V

    return-void

    :pswitch_5
    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v0}, Lc/N1;->w()V

    return-void

    :pswitch_6
    iget-object v0, v1, Lc/D1;->b:Lc/N1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-wide v2, v0, Lc/N1;->N:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-lez v2, :cond_4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v4, v0, Lc/N1;->N:J

    cmp-long v2, v2, v4

    if-ltz v2, :cond_4

    iget-object v2, v0, Lc/N1;->F:Ljava/lang/Object;

    monitor-enter v2
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    iget-wide v3, v0, Lc/N1;->H:J

    iget-wide v5, v0, Lc/N1;->N:J

    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v0, v3, v4, v5, v6}, Lc/N1;->i(JJ)V

    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v2
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    if-nez v2, :cond_4

    goto/16 :goto_3

    :catchall_0
    move-exception v0

    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw v0

    :cond_4
    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v2

    if-nez v2, :cond_5

    goto :goto_3

    :cond_5
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-object v4, v0, Lc/N1;->a:Lru/drivedeck/launcher/DriveDeckApplication;

    const-class v5, Landroid/os/PowerManager;

    invoke-virtual {v4, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/os/PowerManager;

    iget-boolean v5, v0, Lc/N1;->M:Z

    if-eqz v5, :cond_6

    if-eqz v4, :cond_6

    invoke-virtual {v4}, Landroid/os/PowerManager;->isInteractive()Z

    move-result v4

    if-eqz v4, :cond_6

    iget-object v4, v0, Lc/N1;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    if-eqz v4, :cond_6

    iget-wide v4, v0, Lc/N1;->O:J

    sub-long v4, v2, v4

    const-wide/16 v6, 0xbb8

    cmp-long v4, v4, v6

    if-lez v4, :cond_6

    iget-wide v4, v0, Lc/N1;->P:J

    sub-long v4, v2, v4

    const-wide/32 v6, 0xea60

    cmp-long v4, v4, v6

    if-lez v4, :cond_6

    iput-wide v2, v0, Lc/N1;->P:J

    const-string v4, "main_thread_stall"

    const-string v5, "delay_ms"

    iget-wide v6, v0, Lc/N1;->O:J

    sub-long v6, v2, v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    const-string v7, "stack"

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v8

    invoke-virtual {v8}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v8

    invoke-static {v8}, Lc/N1;->v([Ljava/lang/StackTraceElement;)Lorg/json/JSONArray;

    move-result-object v8

    filled-new-array {v5, v6, v7, v8}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v4, v5}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_6
    iget-object v4, v0, Lc/N1;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v4

    if-eqz v4, :cond_7

    iput-wide v2, v0, Lc/N1;->O:J

    sget-object v2, Lc/N1;->W:Landroid/os/Handler;

    new-instance v3, Lc/D1;

    const/4 v4, 0x5

    invoke-direct {v3, v0, v4}, Lc/D1;-><init>(Lc/N1;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    :cond_7
    :goto_3
    return-void

    :pswitch_7
    iget-object v2, v1, Lc/D1;->b:Lc/N1;

    iget-object v0, v2, Lc/N1;->q:Lc/y1;

    iget-object v3, v0, Lc/y1;->b:Ljava/lang/Object;

    move-object v5, v3

    check-cast v5, Ljava/lang/String;

    iget-wide v3, v0, Lc/y1;->a:J

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/16 v0, 0x102

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    const-string v9, "0.6.7"

    const-string v10, "build_version_code"

    const-string v4, "version"

    const-string v6, "version_code"

    const-string v8, "build_version"

    filled-new-array/range {v4 .. v11}, [Ljava/lang/Object;

    move-result-object v0

    const-string v3, "process_start"

    invoke-static {v3, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-static {}, Lc/v7;->a()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_8

    const-string v0, "available"

    :cond_8
    invoke-static {}, Lc/j8;->v()Z

    move-result v3

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const-string v4, "activity_view_unavailable_reason"

    const-string v5, "system_uid"

    filled-new-array {v4, v0, v5, v3}, [Ljava/lang/Object;

    move-result-object v0

    const-string v3, "renderer_capabilities"

    invoke-static {v3, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, v2, Lc/N1;->a:Lru/drivedeck/launcher/DriveDeckApplication;

    invoke-virtual {v2}, Lc/N1;->u()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_c

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1e

    if-ge v3, v5, :cond_9

    goto/16 :goto_5

    :cond_9
    :try_start_5
    const-class v3, Landroid/app/ActivityManager;

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/ActivityManager;

    if-nez v3, :cond_a

    goto/16 :goto_5

    :cond_a
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lc/B1;->h(Landroid/app/ActivityManager;Ljava/lang/String;)Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_c

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_b

    goto :goto_5

    :cond_b
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lc/B1;->e(Ljava/lang/Object;)Landroid/app/ApplicationExitInfo;

    move-result-object v0

    const-string v3, "process_previous_exit"

    const-string v5, "timestamp_ms"

    invoke-static {v0}, Lc/B1;->d(Landroid/app/ApplicationExitInfo;)J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    const-string v7, "reason"

    invoke-static {v0}, Lc/B1;->b(Landroid/app/ApplicationExitInfo;)I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const-string v9, "status"

    invoke-static {v0}, Lc/B1;->n(Landroid/app/ApplicationExitInfo;)I

    move-result v10

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    const-string v11, "importance"

    invoke-static {v0}, Lc/B1;->r(Landroid/app/ApplicationExitInfo;)I

    move-result v12

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    const-string v13, "pss_kib"

    invoke-static {v0}, Lc/B1;->o(Landroid/app/ApplicationExitInfo;)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    const-string v15, "rss_kib"

    invoke-static {v0}, Lc/B1;->s(Landroid/app/ApplicationExitInfo;)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    filled-new-array/range {v5 .. v16}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v3, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_2
    .catch Ljava/lang/LinkageError; {:try_start_5 .. :try_end_5} :catch_1

    goto :goto_5

    :catch_1
    move-exception v0

    goto :goto_4

    :catch_2
    move-exception v0

    :goto_4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const-string v3, "error"

    filled-new-array {v3, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v3, "process_previous_exit_unavailable"

    invoke-static {v3, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_c
    :goto_5
    invoke-virtual {v2}, Lc/N1;->w()V

    invoke-virtual {v2, v4}, Lc/N1;->l(Z)V

    invoke-virtual {v2}, Lc/N1;->y()V

    const/4 v0, 0x0

    invoke-static {v0, v4}, Lc/N1;->D(Lc/H;Z)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
