.class public final Lc/N6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public volatile a:Ljava/net/Socket;

.field public b:Ljava/io/InputStream;

.field public c:Ljava/io/OutputStream;

.field public d:J

.field public e:Z


# virtual methods
.method public final a(Ljava/lang/String;Landroid/net/Network;)V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-boolean v0, p0, Lc/N6;->e:Z

    if-nez v0, :cond_4

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    invoke-static {p1}, Lc/d6;->b(Ljava/lang/String;)Lc/d6;

    move-result-object p1

    if-nez p2, :cond_0

    new-instance p2, Ljava/net/Socket;

    invoke-direct {p2}, Ljava/net/Socket;-><init>()V

    goto :goto_0

    :cond_0
    invoke-virtual {p2}, Landroid/net/Network;->getSocketFactory()Ljavax/net/SocketFactory;

    move-result-object p2

    invoke-virtual {p2}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object p2

    :goto_0
    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    invoke-virtual {p2, v0}, Ljava/net/Socket;->setKeepAlive(Z)V

    const/16 v0, 0x1388

    invoke-virtual {p2, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lc/N6;->e:Z

    if-nez v0, :cond_3

    iget-wide v0, p0, Lc/N6;->d:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/N6;->d:J

    iget-object v2, p0, Lc/N6;->a:Ljava/net/Socket;

    const/4 v3, 0x0

    iput-object v3, p0, Lc/N6;->a:Ljava/net/Socket;

    iput-object v3, p0, Lc/N6;->b:Ljava/io/InputStream;

    iput-object v3, p0, Lc/N6;->c:Ljava/io/OutputStream;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz v2, :cond_1

    :try_start_2
    invoke-virtual {v2}, Ljava/net/Socket;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catch_0
    :cond_1
    :try_start_3
    iput-object p2, p0, Lc/N6;->a:Ljava/net/Socket;

    iput-object v3, p0, Lc/N6;->b:Ljava/io/InputStream;

    iput-object v3, p0, Lc/N6;->c:Ljava/io/OutputStream;

    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    new-instance v2, Ljava/net/InetSocketAddress;

    iget-object v3, p1, Lc/d6;->a:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget p1, p1, Lc/d6;->b:I

    invoke-direct {v2, v3, p1}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 p1, 0xfa0

    invoke-virtual {p2, v2, p1}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    monitor-enter p0

    :try_start_5
    iget-wide v2, p0, Lc/N6;->d:J

    cmp-long p1, v0, v2

    if-nez p1, :cond_2

    invoke-virtual {p2}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    iput-object p1, p0, Lc/N6;->b:Ljava/io/InputStream;

    invoke-virtual {p2}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object p1

    iput-object p1, p0, Lc/N6;->c:Ljava/io/OutputStream;

    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    return-void

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_2
    :try_start_6
    invoke-virtual {p2}, Ljava/net/Socket;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :catch_1
    :try_start_7
    new-instance p1, Ljava/io/IOException;

    const-string p2, "TCP connect cancelled"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_1
    monitor-exit p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    throw p1

    :catch_2
    move-exception p1

    :try_start_8
    invoke-virtual {p2}, Ljava/net/Socket;->close()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_3

    :catch_3
    throw p1

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_3
    :try_start_9
    invoke-virtual {p2}, Ljava/net/Socket;->close()V

    new-instance p1, Ljava/io/IOException;

    const-string p2, "TCP transport closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_2
    monitor-exit p0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    throw p1

    :catchall_2
    move-exception p1

    goto :goto_3

    :cond_4
    :try_start_a
    new-instance p1, Ljava/io/IOException;

    const-string p2, "TCP transport closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_3
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    throw p1
.end method

.method public final declared-synchronized b()Ljava/io/InputStream;
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lc/N6;->b:Ljava/io/InputStream;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-object v0

    :cond_0
    :try_start_1
    new-instance v0, Ljava/io/IOException;

    const-string v1, "TCP disconnected"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final declared-synchronized c()Ljava/io/OutputStream;
    .locals 2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lc/N6;->c:Ljava/io/OutputStream;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    monitor-exit p0

    return-object v0

    :cond_0
    :try_start_1
    new-instance v0, Ljava/io/IOException;

    const-string v1, "TCP disconnected"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :catchall_0
    move-exception v0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public final declared-synchronized close()V
    .locals 4

    monitor-enter p0

    const/4 v0, 0x1

    :try_start_0
    iput-boolean v0, p0, Lc/N6;->e:Z

    iget-wide v0, p0, Lc/N6;->d:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/N6;->d:J

    iget-object v0, p0, Lc/N6;->a:Ljava/net/Socket;

    const/4 v1, 0x0

    iput-object v1, p0, Lc/N6;->a:Ljava/net/Socket;

    iput-object v1, p0, Lc/N6;->b:Ljava/io/InputStream;

    iput-object v1, p0, Lc/N6;->c:Ljava/io/OutputStream;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v0, :cond_0

    :try_start_1
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_0
    monitor-exit p0

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method
