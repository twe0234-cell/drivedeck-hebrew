.class public final synthetic Lc/e9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/g9;


# direct methods
.method public synthetic constructor <init>(Lc/g9;I)V
    .locals 0

    iput p2, p0, Lc/e9;->a:I

    iput-object p1, p0, Lc/e9;->b:Lc/g9;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/e9;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/e9;->b:Lc/g9;

    invoke-virtual {v0}, Lc/g9;->a()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "recognizing"

    iget-object v2, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "listening"

    invoke-virtual {v0, v1}, Lc/g9;->o(Ljava/lang/String;)V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/e9;->b:Lc/g9;

    iget-object v1, v0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getWindowVisibility()I

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lc/g9;->l()V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Lc/g9;->j()V

    :goto_0
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/e9;->b:Lc/g9;

    iget-boolean v1, v0, Lc/g9;->n:Z

    if-eqz v1, :cond_2

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/g9;->q(Z)V

    :cond_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
