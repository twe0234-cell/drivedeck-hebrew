.class public final synthetic Lc/r2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/f2;
.implements Lc/n;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/r2;->a:I

    iput-object p1, p0, Lc/r2;->b:Landroid/view/KeyEvent$Callback;

    iput-object p2, p0, Lc/r2;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lc/a;)V
    .locals 3

    iget v0, p0, Lc/r2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/r2;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    iget-object v1, p0, Lc/r2;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/function/Consumer;

    invoke-interface {v1, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/r2;->b:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lc/t2;

    iget-object v1, v0, Lc/t2;->b:Landroid/widget/FrameLayout;

    const-string v2, "app-grid"

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iget-object v1, p0, Lc/r2;->c:Ljava/lang/Object;

    check-cast v1, Lc/f2;

    invoke-interface {v1, p1}, Lc/f2;->a(Lc/a;)V

    invoke-virtual {v0}, Lc/t2;->n0()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
