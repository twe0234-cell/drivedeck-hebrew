.class public final synthetic Lc/A5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/T5;


# direct methods
.method public synthetic constructor <init>(Lc/T5;I)V
    .locals 0

    iput p2, p0, Lc/A5;->a:I

    iput-object p1, p0, Lc/A5;->b:Lc/T5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 25

    move-object/from16 v0, p0

    iget v1, v0, Lc/A5;->a:I

    packed-switch v1, :pswitch_data_0

    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-boolean v2, v1, Lc/T5;->u:Z

    if-eqz v2, :cond_0

    goto/16 :goto_7

    :cond_0
    invoke-virtual {v1}, Lc/T5;->L0()V

    iget-object v2, v1, Lc/T5;->A1:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    invoke-virtual {v1}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v3

    const-string v4, "wifi"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v3, "192.168.0.10:35000"

    iget-object v4, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v5, "wifi_endpoint"

    invoke-interface {v4, v5, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "ELM327 Wi-Fi"

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u0434\u0440\u0435\u0441 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430 Wi-Fi"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    goto/16 :goto_7

    :cond_1
    invoke-virtual {v1}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v3

    const-string v4, "usb"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    :try_start_0
    iget-object v3, v1, Lc/T5;->a:Landroid/content/Context;

    new-instance v5, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v5}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    new-instance v5, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v5}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    if-eqz v3, :cond_7

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/hardware/usb/UsbManager;

    if-eqz v3, :cond_6

    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v3}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_2
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/hardware/usb/UsbDevice;

    invoke-static {}, Lcom/hoho/android/usbserial/driver/UsbSerialProber;->getDefaultProber()Lcom/hoho/android/usbserial/driver/UsbSerialProber;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcom/hoho/android/usbserial/driver/UsbSerialProber;->probeDevice(Landroid/hardware/usb/UsbDevice;)Lcom/hoho/android/usbserial/driver/UsbSerialDriver;

    move-result-object v6

    if-eqz v6, :cond_2

    invoke-virtual {v5}, Landroid/hardware/usb/UsbDevice;->getDeviceName()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_3
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/hardware/usb/UsbDevice;

    invoke-virtual {v4}, Landroid/hardware/usb/UsbDevice;->getDeviceName()Ljava/lang/String;

    move-result-object v5

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v7, "USB \u00b7 %04X:%04X"

    invoke-virtual {v4}, Landroid/hardware/usb/UsbDevice;->getVendorId()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v4}, Landroid/hardware/usb/UsbDevice;->getProductId()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v8, v4}, [Ljava/lang/Object;

    move-result-object v4

    invoke-static {v6, v7, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_4
    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_5

    const-string v2, "USB-\u0430\u0434\u0430\u043f\u0442\u0435\u0440\u044b \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u044b"

    goto :goto_2

    :cond_5
    const-string v2, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 USB-\u0430\u0434\u0430\u043f\u0442\u0435\u0440"

    :goto_2
    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    goto :goto_3

    :cond_6
    new-instance v2, Ljava/lang/IllegalStateException;

    const-string v3, "USB Host unavailable"

    invoke-direct {v2, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_7
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "context"

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string v2, "USB Host \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    :goto_3
    invoke-virtual {v1}, Lc/T5;->q()V

    goto/16 :goto_7

    :cond_8
    invoke-virtual {v1}, Lc/T5;->e0()Z

    move-result v3

    if-nez v3, :cond_9

    const-string v2, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a Bluetooth \u0438 \u0433\u0435\u043e\u043f\u043e\u0437\u0438\u0446\u0438\u0438"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    goto/16 :goto_7

    :cond_9
    :try_start_1
    invoke-virtual {v1}, Lc/T5;->c()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v3

    if-eqz v3, :cond_f

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v4

    if-nez v4, :cond_a

    goto/16 :goto_6

    :cond_a
    invoke-virtual {v1}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v4

    const-string v5, "spp"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_d

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothAdapter;->getBondedDevices()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {v4}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_b

    invoke-virtual {v4}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v4

    goto :goto_5

    :cond_b
    invoke-virtual {v4}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v4

    :goto_5
    invoke-interface {v2, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_c
    const-string v2, "SPP: \u0432\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0441\u043e\u043f\u0440\u044f\u0436\u0451\u043d\u043d\u044b\u0439 \u0430\u0434\u0430\u043f\u0442\u0435\u0440. \u0421\u043e\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u2014 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 Android"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    goto :goto_7

    :cond_d
    invoke-virtual {v3}, Landroid/bluetooth/BluetoothAdapter;->getBluetoothLeScanner()Landroid/bluetooth/le/BluetoothLeScanner;

    move-result-object v2

    iput-object v2, v1, Lc/T5;->Z1:Landroid/bluetooth/le/BluetoothLeScanner;

    if-nez v2, :cond_e

    const-string v2, "Bluetooth \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    goto :goto_7

    :cond_e
    const/4 v3, 0x1

    iput-boolean v3, v1, Lc/T5;->G1:Z

    const-string v3, "\u041f\u043e\u0438\u0441\u043a \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u0432\u2026"

    iput-object v3, v1, Lc/T5;->C1:Ljava/lang/String;

    new-instance v3, Landroid/bluetooth/le/ScanSettings$Builder;

    invoke-direct {v3}, Landroid/bluetooth/le/ScanSettings$Builder;-><init>()V

    const/4 v4, 0x2

    invoke-virtual {v3, v4}, Landroid/bluetooth/le/ScanSettings$Builder;->setScanMode(I)Landroid/bluetooth/le/ScanSettings$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/bluetooth/le/ScanSettings$Builder;->build()Landroid/bluetooth/le/ScanSettings;

    move-result-object v3

    iget-object v4, v1, Lc/T5;->C2:Lc/I5;

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v3, v4}, Landroid/bluetooth/le/BluetoothLeScanner;->startScan(Ljava/util/List;Landroid/bluetooth/le/ScanSettings;Landroid/bluetooth/le/ScanCallback;)V

    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, v1, Lc/T5;->i2:Lc/A5;

    const-wide/16 v4, 0x2710

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {v1}, Lc/T5;->q()V

    goto :goto_7

    :cond_f
    :goto_6
    const-string v2, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 Bluetooth"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_7

    :catch_1
    const/4 v2, 0x0

    iput-boolean v2, v1, Lc/T5;->G1:Z

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0447\u0430\u0442\u044c \u043f\u043e\u0438\u0441\u043a"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    :goto_7
    return-void

    :pswitch_0
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->t0()V

    return-void

    :pswitch_1
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-boolean v2, v1, Lc/T5;->d1:Z

    if-nez v2, :cond_10

    goto :goto_8

    :cond_10
    iget v2, v1, Lc/T5;->k1:I

    iget-object v3, v1, Lc/T5;->i1:Ljava/util/HashSet;

    if-lez v2, :cond_11

    iget-object v2, v1, Lc/T5;->h1:Ljava/util/HashSet;

    invoke-interface {v2, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iget-boolean v4, v1, Lc/T5;->n1:Z

    if-eqz v4, :cond_11

    iget-object v4, v1, Lc/T5;->g:Lc/j6;

    if-eqz v4, :cond_11

    iget-object v4, v4, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_11

    iget-object v4, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const-string v2, "disabled_sensor_ids"

    invoke-interface {v4, v2, v5}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_11
    invoke-virtual {v3}, Ljava/util/HashSet;->clear()V

    const/4 v2, 0x0

    iput-boolean v2, v1, Lc/T5;->o1:Z

    iput-boolean v2, v1, Lc/T5;->d1:Z

    const/4 v2, 0x1

    iput-boolean v2, v1, Lc/T5;->b1:Z

    invoke-virtual {v1}, Lc/T5;->Y()V

    iget v2, v1, Lc/T5;->k1:I

    if-nez v2, :cond_12

    const-string v2, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u00b7 \u0434\u0430\u0442\u0447\u0438\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f \u043d\u0435 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d\u044b, \u0438\u0441\u0445\u043e\u0434\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    iput-object v2, v1, Lc/T5;->C1:Ljava/lang/String;

    :cond_12
    invoke-virtual {v1}, Lc/T5;->q()V

    invoke-virtual {v1}, Lc/T5;->Z()V

    :goto_8
    return-void

    :pswitch_2
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-object v2, v1, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v2, :cond_13

    iget-object v3, v1, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v1, v2, v3, v4}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_13
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/T5;->K(Z)V

    return-void

    :pswitch_3
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-boolean v2, v1, Lc/T5;->w:Z

    if-eqz v2, :cond_14

    iget-boolean v2, v1, Lc/T5;->A:Z

    if-eqz v2, :cond_14

    iget-boolean v2, v1, Lc/T5;->u:Z

    if-nez v2, :cond_14

    const-string v2, "ATPC"

    invoke-virtual {v1, v2}, Lc/T5;->O0(Ljava/lang/String;)V

    :cond_14
    return-void

    :pswitch_4
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, v1, Lc/T5;->F:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v2, v1, Lc/T5;->u:Z

    if-nez v2, :cond_29

    invoke-virtual {v1}, Lc/T5;->j()I

    move-result v2

    if-eqz v2, :cond_29

    iget-object v2, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "enabled"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_15

    goto/16 :goto_11

    :cond_15
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-boolean v5, v1, Lc/T5;->w:Z

    const-wide/16 v6, 0x3e8

    if-nez v5, :cond_27

    iget-boolean v5, v1, Lc/T5;->F1:Z

    if-eqz v5, :cond_27

    invoke-virtual {v1}, Lc/T5;->h()Lc/i6;

    move-result-object v5

    const/4 v9, 0x0

    if-nez v5, :cond_16

    move-object v5, v9

    goto :goto_9

    :cond_16
    iget-object v10, v1, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v5, v5, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v10, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/S5;

    invoke-static {v5, v2, v3}, Lc/T5;->k(Lc/S5;J)Ljava/lang/Double;

    move-result-object v5

    :goto_9
    iget-object v10, v1, Lc/T5;->v:Lc/s5;

    invoke-virtual {v1}, Lc/T5;->j()I

    move-result v11

    iget-object v12, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v13, "battery_delay"

    const/16 v14, 0x78

    const/16 v15, 0x708

    const/16 v4, 0x1e

    invoke-static {v12, v13, v14, v15, v4}, Lc/t;->b(Landroid/content/SharedPreferences;Ljava/lang/String;III)I

    move-result v4

    int-to-long v12, v4

    mul-long/2addr v12, v6

    const/16 v4, 0xc

    invoke-virtual {v1, v4, v2, v3}, Lc/T5;->i(IJ)Ljava/lang/Double;

    move-result-object v4

    const/16 v14, 0xd

    invoke-virtual {v1, v14, v2, v3}, Lc/T5;->i(IJ)Ljava/lang/Double;

    move-result-object v14

    iget-object v15, v1, Lc/T5;->C:Lc/S5;

    if-eqz v15, :cond_17

    iget-wide v6, v15, Lc/S5;->c:J

    sub-long v6, v2, v6

    const-wide/32 v16, 0xafc8

    cmp-long v6, v6, v16

    if-gtz v6, :cond_17

    iget-wide v6, v15, Lc/S5;->a:D

    invoke-static {v6, v7}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v9

    :cond_17
    const-string v6, "battery_stop_volts"

    const v7, 0x414ccccd    # 12.8f

    invoke-virtual {v1, v6, v7}, Lc/T5;->m(Ljava/lang/String;F)D

    move-result-wide v6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v15

    const/4 v8, 0x1

    const-wide/16 v17, 0x0

    if-eqz v15, :cond_18

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v19

    cmpl-double v15, v19, v17

    if-lez v15, :cond_18

    iput-boolean v8, v10, Lc/s5;->c:Z

    :cond_18
    invoke-static {v5}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v15

    if-eqz v15, :cond_1a

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v19

    cmpl-double v15, v19, v17

    if-eqz v15, :cond_19

    move v15, v8

    goto :goto_a

    :cond_19
    const/4 v15, 0x0

    :goto_a
    invoke-static {v15}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    iput-object v15, v10, Lc/s5;->d:Ljava/lang/Boolean;

    :cond_1a
    invoke-static {v5}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v15

    move-object/from16 v19, v9

    const-wide/16 v8, -0x1

    if-eqz v15, :cond_1b

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v21

    cmpl-double v5, v21, v17

    if-eqz v5, :cond_1b

    iput-wide v8, v10, Lc/s5;->a:J

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto/16 :goto_f

    :cond_1b
    invoke-static {v14}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v5

    const-wide/high16 v21, 0x3ff0000000000000L    # 1.0

    if-eqz v5, :cond_1c

    invoke-virtual {v14}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v23

    cmpl-double v5, v23, v21

    if-lez v5, :cond_1c

    const/4 v5, 0x1

    const/16 v20, 0x1

    goto :goto_b

    :cond_1c
    const/4 v5, 0x1

    const/16 v20, 0x0

    :goto_b
    if-eq v11, v5, :cond_21

    const/4 v15, 0x2

    if-eq v11, v15, :cond_20

    const/4 v6, 0x3

    if-eq v11, v6, :cond_1e

    :cond_1d
    const/4 v4, 0x0

    goto :goto_d

    :cond_1e
    iget-boolean v6, v10, Lc/s5;->c:Z

    if-eqz v6, :cond_1d

    invoke-static {v14}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v6

    if-eqz v6, :cond_1d

    invoke-virtual {v14}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v6

    cmpg-double v6, v6, v21

    if-gtz v6, :cond_1d

    invoke-static {v4}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v6

    if-eqz v6, :cond_1f

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v6

    cmpl-double v4, v6, v17

    if-nez v4, :cond_1d

    :cond_1f
    :goto_c
    move v4, v5

    goto :goto_d

    :cond_20
    invoke-static/range {v19 .. v19}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v11

    if-eqz v11, :cond_1d

    invoke-virtual/range {v19 .. v19}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v14

    cmpg-double v6, v14, v6

    if-gez v6, :cond_1d

    invoke-static {v4}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v6

    if-eqz v6, :cond_1f

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v6

    cmpl-double v4, v6, v17

    if-nez v4, :cond_1d

    goto :goto_c

    :cond_21
    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v6, v10, Lc/s5;->d:Ljava/lang/Boolean;

    invoke-virtual {v4, v6}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v4

    :goto_d
    if-eqz v4, :cond_24

    if-eqz v20, :cond_22

    goto :goto_e

    :cond_22
    iget-wide v6, v10, Lc/s5;->a:J

    const-wide/16 v8, 0x0

    cmp-long v4, v6, v8

    if-gez v4, :cond_23

    iput-wide v2, v10, Lc/s5;->a:J

    :cond_23
    iget-wide v6, v10, Lc/s5;->a:J

    sub-long v6, v2, v6

    cmp-long v4, v6, v12

    if-ltz v4, :cond_25

    move v4, v5

    goto :goto_f

    :cond_24
    :goto_e
    iput-wide v8, v10, Lc/s5;->a:J

    :cond_25
    const/4 v4, 0x0

    :goto_f
    if-eqz v4, :cond_27

    invoke-virtual {v1}, Lc/T5;->j()I

    move-result v2

    const/4 v4, 0x2

    if-ne v2, v4, :cond_26

    move v4, v5

    goto :goto_10

    :cond_26
    const/4 v4, 0x0

    :goto_10
    invoke-virtual {v1, v4}, Lc/T5;->c0(Z)V

    goto :goto_11

    :cond_27
    const/4 v4, 0x2

    invoke-virtual {v1}, Lc/T5;->j()I

    move-result v5

    if-ne v5, v4, :cond_28

    iget-wide v4, v1, Lc/T5;->D:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x3a98

    cmp-long v2, v2, v4

    if-ltz v2, :cond_28

    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, v1, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_28
    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, v1, Lc/T5;->F:Lc/A5;

    const-wide/16 v3, 0x3e8

    invoke-virtual {v2, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_29
    :goto_11
    return-void

    :pswitch_5
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->L0()V

    return-void

    :pswitch_6
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->Z()V

    return-void

    :pswitch_7
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->x()V

    return-void

    :pswitch_8
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->F()V

    return-void

    :pswitch_9
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-object v2, v1, Lc/T5;->a2:Ljava/lang/String;

    const/4 v3, 0x0

    const-string v4, "\u041d\u0435\u0442 \u043e\u0442\u0432\u0435\u0442\u0430 \u043e\u0442 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430"

    iget-object v5, v1, Lc/T5;->b2:Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    if-eqz v2, :cond_2f

    iget-boolean v7, v1, Lc/T5;->c1:Z

    if-eqz v7, :cond_2a

    goto/16 :goto_13

    :cond_2a
    iget v2, v1, Lc/T5;->a0:I

    if-lez v2, :cond_2b

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v6, v2}, Lc/T5;->M(ZLjava/lang/String;)V

    goto :goto_14

    :cond_2b
    iget-boolean v2, v1, Lc/T5;->v1:Z

    if-nez v2, :cond_2c

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v7, "SEARCHING"

    invoke-virtual {v2, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_2c

    iput-boolean v6, v1, Lc/T5;->v1:Z

    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-wide v5, v1, Lc/T5;->s1:J

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x1d4c

    sub-long/2addr v5, v3

    const-wide/16 v3, 0x0

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    iget-object v1, v1, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v2, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_14

    :cond_2c
    iget v2, v1, Lc/T5;->t1:I

    add-int/2addr v2, v6

    iput v2, v1, Lc/T5;->t1:I

    iget-boolean v7, v1, Lc/T5;->d1:Z

    if-eqz v7, :cond_2d

    iget-boolean v7, v1, Lc/T5;->n1:Z

    if-eqz v7, :cond_2d

    const/16 v7, 0xa

    goto :goto_12

    :cond_2d
    const/16 v7, 0x28

    :goto_12
    if-le v2, v7, :cond_2e

    iget-object v2, v1, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v2, v5, v6}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {v1, v3, v4}, Lc/T5;->J(ZLjava/lang/String;)V

    goto :goto_14

    :cond_2e
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v6, v2}, Lc/T5;->M(ZLjava/lang/String;)V

    goto :goto_14

    :cond_2f
    :goto_13
    if-eqz v2, :cond_30

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v2, v5, v6}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_30
    invoke-virtual {v1, v3, v4}, Lc/T5;->J(ZLjava/lang/String;)V

    :goto_14
    return-void

    :pswitch_a
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-boolean v2, v1, Lc/T5;->T1:Z

    if-nez v2, :cond_31

    goto :goto_15

    :cond_31
    iget-object v2, v1, Lc/T5;->W1:Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_33

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "elm"

    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_32

    const-string v3, ">"

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_33

    :cond_32
    const/4 v2, 0x0

    iput-boolean v2, v1, Lc/T5;->T1:Z

    iget-object v2, v1, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, v1, Lc/T5;->X1:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v1}, Lc/T5;->W()V

    goto :goto_15

    :cond_33
    invoke-virtual {v1}, Lc/T5;->a0()V

    :goto_15
    return-void

    :pswitch_b
    iget-object v1, v0, Lc/A5;->b:Lc/T5;

    iget-boolean v2, v1, Lc/T5;->U1:Z

    if-nez v2, :cond_35

    iget-boolean v2, v1, Lc/T5;->V1:Z

    if-eqz v2, :cond_34

    goto :goto_16

    :cond_34
    invoke-virtual {v1}, Lc/T5;->a0()V

    goto :goto_17

    :cond_35
    :goto_16
    const/4 v2, 0x0

    const-string v3, "\u041d\u0435\u0442 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d\u0438\u044f \u043a\u0430\u043d\u0430\u043b\u0430 BLE"

    invoke-virtual {v1, v2, v3}, Lc/T5;->J(ZLjava/lang/String;)V

    :goto_17
    return-void

    :pswitch_c
    const-string v1, "\u042d\u0411\u0423 \u043d\u0435 \u043e\u0442\u0432\u0435\u0442\u0438\u043b \u043d\u0430 PID \u0437\u0430 \u0432\u0440\u0435\u043c\u044f \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438"

    iget-object v2, v0, Lc/A5;->b:Lc/T5;

    invoke-virtual {v2, v1}, Lc/T5;->N(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
