.class public final synthetic Lc/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/g;->a:I

    iput-object p1, p0, Lc/g;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 6

    iget p1, p0, Lc/g;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/g;->b:Ljava/lang/Object;

    check-cast p1, Lc/T5;

    invoke-virtual {p1}, Lc/T5;->p()V

    return-void

    :pswitch_0
    const/4 p1, 0x0

    iget-object v0, p0, Lc/g;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iput-object p1, v0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/g;->b:Ljava/lang/Object;

    check-cast p1, Lc/u0;

    iget-object v0, p1, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, [Lc/k3;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v2, p1, Lc/u0;->d:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-ne v3, v0, :cond_7

    iget v0, v2, Lru/drivedeck/launcher/MainActivity;->l0:I

    iget v3, p1, Lc/u0;->a:I

    if-eq v0, v3, :cond_0

    goto/16 :goto_3

    :cond_0
    const/4 v0, 0x0

    iput-object v0, v2, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    iput-boolean v1, v2, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->m0:Ljava/lang/String;

    if-eqz v3, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->i0()Z

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v2, Lru/drivedeck/launcher/MainActivity;->m0:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    move v3, v1

    :goto_0
    iput-object v0, v2, Lru/drivedeck/launcher/MainActivity;->m0:Ljava/lang/String;

    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_2

    iget-object v4, v0, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v4}, Lc/t2;->J()V

    iget-object v0, v0, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->J()V

    :cond_2
    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_3

    iget-object v0, v0, Lc/m2;->t:[Lc/t2;

    array-length v4, v0

    :goto_1
    if-ge v1, v4, :cond_3

    aget-object v5, v0, v1

    invoke-virtual {v5}, Lc/t2;->J()V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Lc/Q3;->K()V

    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0}, Lc/Q3;->I()V

    if-eqz v3, :cond_4

    iget-object p1, v2, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {p1}, Lc/Q3;->z()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p1, Lc/Q3;->G:Ljava/lang/String;

    iget-object v1, p1, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v1, v0}, Lc/t2;->e0(Ljava/lang/String;)V

    iget-object v0, p1, Lc/Q3;->F:Lc/n1;

    iget-object p1, p1, Lc/Q3;->G:Ljava/lang/String;

    invoke-virtual {v0, p1}, Lc/n1;->x0(Ljava/lang/String;)V

    goto :goto_2

    :cond_4
    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v0

    iget-object p1, p1, Lc/u0;->c:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5

    iget-object p1, v2, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {p1}, Lc/Q3;->O()V

    :cond_5
    :goto_2
    iget-object p1, v2, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Lc/F;->d()V

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    iget-object p1, p1, Lc/F;->l:Landroid/view/View;

    if-eqz p1, :cond_7

    check-cast p1, Lc/b2;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Lc/b2;->j()V

    :cond_6
    invoke-virtual {p1}, Landroid/view/View;->invalidateOutline()V

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_7
    :goto_3
    return-void

    :pswitch_2
    iget-object p1, p0, Lc/g;->b:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
