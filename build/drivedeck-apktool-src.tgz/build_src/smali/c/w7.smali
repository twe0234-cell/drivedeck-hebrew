.class public final Lc/w7;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/w7;->a:I

    iput-object p1, p0, Lc/w7;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    iget p1, p0, Lc/w7;->a:I

    packed-switch p1, :pswitch_data_0

    new-instance p1, Lc/F7;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object p2, p0, Lc/w7;->b:Ljava/lang/Object;

    check-cast p2, Lc/C8;

    invoke-virtual {p2, p1}, Lc/C8;->a(Ljava/lang/Runnable;)V

    return-void

    :pswitch_0
    const-string p1, "android.bluetooth.device.extra.DEVICE"

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/bluetooth/BluetoothDevice;

    if-nez p1, :cond_0

    goto/16 :goto_1

    :cond_0
    const-string v0, "android.bluetooth.headsetclient.profile.action.CONNECTION_STATE_CHANGED"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, -0x1

    iget-object v4, p0, Lc/w7;->b:Ljava/lang/Object;

    check-cast v4, Lc/x7;

    if-eqz v0, :cond_3

    const-string v0, "android.bluetooth.profile.extra.STATE"

    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v0, 0x2

    if-ne p2, v0, :cond_2

    iget-object p2, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothDevice;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    iput v3, v4, Lc/x7;->g:I

    iput v3, v4, Lc/x7;->f:I

    :cond_1
    iput-object p1, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    iput-boolean v2, v4, Lc/x7;->e:Z

    goto :goto_0

    :cond_2
    if-nez p2, :cond_7

    iget-object p2, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {p1, p2}, Landroid/bluetooth/BluetoothDevice;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    iput-boolean v1, v4, Lc/x7;->e:Z

    const/4 p1, 0x0

    iput-object p1, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    iput v3, v4, Lc/x7;->g:I

    iput v3, v4, Lc/x7;->f:I

    goto :goto_0

    :cond_3
    iget-object v0, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    if-eqz v0, :cond_4

    invoke-virtual {p1, v0}, Landroid/bluetooth/BluetoothDevice;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_1

    :cond_4
    iput-object p1, v4, Lc/x7;->d:Landroid/bluetooth/BluetoothDevice;

    iput-boolean v2, v4, Lc/x7;->e:Z

    const-string p1, "android.bluetooth.headsetclient.extra.BATTERY_LEVEL"

    invoke-virtual {p2, p1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v0, 0x5

    if-ltz p1, :cond_5

    if-gt p1, v0, :cond_5

    mul-int/lit8 p1, p1, 0x14

    iput p1, v4, Lc/x7;->f:I

    :cond_5
    const-string p1, "android.bluetooth.headsetclient.extra.NETWORK_SIGNAL_STRENGTH"

    invoke-virtual {p2, p1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    if-ltz p1, :cond_6

    if-gt p1, v0, :cond_6

    iput p1, v4, Lc/x7;->g:I

    :cond_6
    const-string p1, "android.bluetooth.headsetclient.extra.NETWORK_STATUS"

    invoke-virtual {p2, p1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    if-nez p1, :cond_7

    iput v1, v4, Lc/x7;->g:I

    :cond_7
    :goto_0
    iget-object p1, v4, Lc/x7;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
