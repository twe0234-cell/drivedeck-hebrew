.class public final Lc/u5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Landroid/os/Handler;

.field public c:Lc/Z;

.field public d:Lc/E3;

.field public e:J

.field public final f:Lc/i;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Landroid/os/Handler;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc/i;

    const/16 v1, 0xc

    invoke-direct {v0, p0, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/u5;->f:Lc/i;

    iput-object p1, p0, Lc/u5;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/u5;->b:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 2

    iget-object v0, p0, Lc/u5;->f:Lc/i;

    iget-object v1, p0, Lc/u5;->b:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/u5;->c:Lc/Z;

    iput-object v0, p0, Lc/u5;->d:Lc/E3;

    return-void
.end method
