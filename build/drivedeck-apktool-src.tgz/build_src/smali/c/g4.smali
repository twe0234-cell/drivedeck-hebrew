.class public final Lc/g4;
.super Landroid/media/browse/MediaBrowser$ConnectionCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Landroid/os/Handler;

.field public final synthetic b:[Ljava/lang/Runnable;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Landroid/content/Context;

.field public final synthetic e:I

.field public final synthetic f:J

.field public final synthetic g:[Landroid/media/browse/MediaBrowser;

.field public final synthetic h:Lc/v1;


# direct methods
.method public constructor <init>(Landroid/os/Handler;[Ljava/lang/Runnable;Ljava/lang/String;Landroid/content/Context;IJ[Landroid/media/browse/MediaBrowser;Lc/v1;)V
    .locals 0

    iput-object p1, p0, Lc/g4;->a:Landroid/os/Handler;

    iput-object p2, p0, Lc/g4;->b:[Ljava/lang/Runnable;

    iput-object p3, p0, Lc/g4;->c:Ljava/lang/String;

    iput-object p4, p0, Lc/g4;->d:Landroid/content/Context;

    iput p5, p0, Lc/g4;->e:I

    iput-wide p6, p0, Lc/g4;->f:J

    iput-object p8, p0, Lc/g4;->g:[Landroid/media/browse/MediaBrowser;

    iput-object p9, p0, Lc/g4;->h:Lc/v1;

    invoke-direct {p0}, Landroid/media/browse/MediaBrowser$ConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onConnected()V
    .locals 9

    iget-object v0, p0, Lc/g4;->g:[Landroid/media/browse/MediaBrowser;

    iget-object v1, p0, Lc/g4;->d:Landroid/content/Context;

    iget-object v2, p0, Lc/g4;->b:[Ljava/lang/Runnable;

    const/4 v3, 0x0

    aget-object v2, v2, v3

    iget-object v4, p0, Lc/g4;->a:Landroid/os/Handler;

    invoke-virtual {v4, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v2, Lc/G8;->C:Ljava/lang/String;

    iget-object v4, p0, Lc/g4;->c:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const/4 v2, 0x0

    sput-object v2, Lc/G8;->C:Ljava/lang/String;

    :cond_0
    :try_start_0
    new-instance v2, Lc/n1;

    invoke-direct {v2, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iget v5, p0, Lc/g4;->e:I

    sget v6, Lc/G8;->B:I

    if-ne v5, v6, :cond_2

    iget-wide v5, p0, Lc/g4;->f:J

    invoke-virtual {v2}, Lc/n1;->t0()J

    move-result-wide v7

    cmp-long v5, v5, v7

    if-nez v5, :cond_2

    invoke-static {v1, v2}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-virtual {v2}, Lc/n1;->e0()Z

    move-result v2

    if-nez v2, :cond_2

    new-instance v2, Landroid/media/session/MediaController;

    aget-object v5, v0, v3

    invoke-virtual {v5}, Landroid/media/browse/MediaBrowser;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v5

    invoke-direct {v2, v1, v5}, Landroid/media/session/MediaController;-><init>(Landroid/content/Context;Landroid/media/session/MediaSession$Token;)V

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v5

    if-eqz v5, :cond_1

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v6

    const/4 v7, 0x3

    if-eq v6, v7, :cond_2

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v5

    const/4 v6, 0x6

    if-eq v5, v6, :cond_2

    :cond_1
    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lc/i;

    const/16 v7, 0x8

    invoke-direct {v6, v2, v7}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-static {v1, v5, v6}, Lc/G8;->X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/g4;->h:Lc/v1;

    invoke-static {v1, v4, v2}, Lc/G8;->u0(Landroid/content/Context;Ljava/lang/String;Lc/v1;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    aget-object v0, v0, v3

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->disconnect()V

    return-void
.end method

.method public final onConnectionFailed()V
    .locals 3

    iget-object v0, p0, Lc/g4;->b:[Ljava/lang/Runnable;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v2, p0, Lc/g4;->a:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v0, Lc/G8;->C:Ljava/lang/String;

    iget-object v2, p0, Lc/g4;->c:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    sput-object v0, Lc/G8;->C:Ljava/lang/String;

    :cond_0
    iget-object v0, p0, Lc/g4;->g:[Landroid/media/browse/MediaBrowser;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->disconnect()V

    return-void
.end method

.method public final onConnectionSuspended()V
    .locals 3

    iget-object v0, p0, Lc/g4;->b:[Ljava/lang/Runnable;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v2, p0, Lc/g4;->a:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object v0, Lc/G8;->C:Ljava/lang/String;

    iget-object v2, p0, Lc/g4;->c:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    sput-object v0, Lc/G8;->C:Ljava/lang/String;

    :cond_0
    iget-object v0, p0, Lc/g4;->g:[Landroid/media/browse/MediaBrowser;

    aget-object v0, v0, v1

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->disconnect()V

    return-void
.end method
