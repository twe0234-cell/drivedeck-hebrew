.class public final synthetic Lc/a8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/d8;


# direct methods
.method public synthetic constructor <init>(Lc/d8;I)V
    .locals 0

    iput p2, p0, Lc/a8;->a:I

    iput-object p1, p0, Lc/a8;->b:Lc/d8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    iget p1, p0, Lc/a8;->a:I

    packed-switch p1, :pswitch_data_0

    const/4 p1, 0x0

    iget-object v0, p0, Lc/a8;->b:Lc/d8;

    invoke-virtual {v0, p1}, Lc/d8;->a(Z)V

    return-void

    :pswitch_0
    const/4 p1, 0x1

    iget-object v0, p0, Lc/a8;->b:Lc/d8;

    invoke-virtual {v0, p1}, Lc/d8;->a(Z)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
