.class public final synthetic Lc/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/b;->a:I

    iput-object p1, p0, Lc/b;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/b;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 4

    iget v0, p0, Lc/b;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Ljava/util/List;

    iget-object v0, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast v0, Lc/d8;

    iget-object v1, v0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_3

    iget-object v1, v0, Lc/d8;->l:Ljava/lang/String;

    iget-object v2, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Lc/d8;->k()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/Q;

    iget-object v2, v1, Lc/Q;->b:Ljava/lang/String;

    iget-object v3, v0, Lc/d8;->b:Lc/Z7;

    iget-object v3, v3, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object p1, v1, Lc/Q;->a:Ljava/lang/String;

    iput-object p1, v0, Lc/d8;->m:Ljava/lang/String;

    :cond_2
    invoke-virtual {v0}, Lc/d8;->j()V

    :cond_3
    :goto_0
    return-void

    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_4

    iget-object p1, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast p1, Lc/S7;

    invoke-virtual {p1}, Lc/S7;->run()V

    goto :goto_1

    :cond_4
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v0, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/function/Consumer;

    invoke-interface {v0, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :goto_1
    return-void

    :pswitch_1
    check-cast p1, Lc/Q5;

    iget-object v0, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0, p1}, Lc/b7;->j(Lru/drivedeck/launcher/MainActivity;Lc/Q5;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_2
    check-cast p1, Ljava/lang/Boolean;

    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_5

    iget-boolean p1, v0, Lru/drivedeck/launcher/MainActivity;->c:Z

    if-eqz p1, :cond_5

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result p1

    if-nez p1, :cond_5

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result p1

    if-nez p1, :cond_5

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    const-class p1, Lc/G8;

    monitor-enter p1

    :try_start_0
    sput-object v1, Lc/G8;->a:Ljava/lang/String;

    const/4 v1, 0x0

    sput-object v1, Lc/G8;->b:[Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p1

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    goto :goto_2

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :cond_5
    :goto_2
    return-void

    :pswitch_3
    check-cast p1, Lc/s0;

    sget-object v0, Lc/s0;->m:Lc/s0;

    iget-object v1, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast v1, Lc/Q3;

    if-ne p1, v0, :cond_6

    const/4 p1, 0x1

    invoke-virtual {v1, p1}, Lc/Q3;->R(I)V

    goto :goto_3

    :cond_6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/function/Consumer;

    invoke-interface {v0, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :goto_3
    return-void

    :pswitch_4
    check-cast p1, Lc/W3;

    iget-object v0, p0, Lc/b;->b:Ljava/lang/Object;

    check-cast v0, [Lc/W3;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    iget-object p1, p0, Lc/b;->c:Ljava/lang/Object;

    check-cast p1, Lc/h;

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
