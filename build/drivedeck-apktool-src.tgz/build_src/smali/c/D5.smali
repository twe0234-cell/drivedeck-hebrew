.class public final synthetic Lc/D5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/y5;


# instance fields
.field public final synthetic a:Lc/T5;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lc/T5;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/D5;->a:Lc/T5;

    iput p2, p0, Lc/D5;->b:I

    return-void
.end method


# virtual methods
.method public final b(Lc/j6;Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, Lc/D5;->a:Lc/T5;

    iget v1, p0, Lc/D5;->b:I

    iget v2, v0, Lc/T5;->t:I

    if-ne v1, v2, :cond_4

    iget-object v2, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "enabled"

    const/4 v4, 0x0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    if-nez p2, :cond_2

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    iput-object p1, v0, Lc/T5;->h:Lc/j6;

    iget-object p2, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {p2, p1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object p1

    iput-object p1, v0, Lc/T5;->g:Lc/j6;

    invoke-virtual {v0, v1}, Lc/T5;->z(I)V

    goto :goto_1

    :cond_2
    :goto_0
    if-nez p2, :cond_3

    const-string p2, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    :cond_3
    iput-object p2, v0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v0}, Lc/T5;->q()V

    :cond_4
    :goto_1
    return-void
.end method
