.class public final Lc/u7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# instance fields
.field public final synthetic a:Landroid/view/SurfaceView;

.field public final synthetic b:Lc/v7;


# direct methods
.method public constructor <init>(Lc/v7;Landroid/view/SurfaceView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/u7;->b:Lc/v7;

    iput-object p2, p0, Lc/u7;->a:Landroid/view/SurfaceView;

    return-void
.end method


# virtual methods
.method public final surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 1

    const-string p2, "activity_surface_changed"

    iget-object v0, p0, Lc/u7;->b:Lc/v7;

    invoke-virtual {v0, p2, p1, p3, p4}, Lc/v7;->x(Ljava/lang/String;Landroid/view/SurfaceHolder;II)V

    iget-object p1, v0, Lc/v7;->G:Lc/q7;

    invoke-virtual {v0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 4

    iget-object v0, p0, Lc/u7;->a:Landroid/view/SurfaceView;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const-string v2, "activity_surface_created"

    iget-object v3, p0, Lc/u7;->b:Lc/v7;

    invoke-virtual {v3, v2, p1, v1, v0}, Lc/v7;->x(Ljava/lang/String;Landroid/view/SurfaceHolder;II)V

    iget-object p1, v3, Lc/v7;->G:Lc/q7;

    invoke-virtual {v3, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 4

    iget-object v0, p0, Lc/u7;->a:Landroid/view/SurfaceView;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const-string v2, "activity_surface_destroyed"

    iget-object v3, p0, Lc/u7;->b:Lc/v7;

    invoke-virtual {v3, v2, p1, v1, v0}, Lc/v7;->x(Ljava/lang/String;Landroid/view/SurfaceHolder;II)V

    iget-object p1, v3, Lc/v7;->G:Lc/q7;

    invoke-virtual {v3, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    return-void
.end method
