.class public final synthetic Lc/W8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Exception;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Exception;I)V
    .locals 0

    iput p2, p0, Lc/W8;->a:I

    iput-object p1, p0, Lc/W8;->b:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    iget v0, p0, Lc/W8;->a:I

    check-cast p1, Lc/b9;

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/W8;->b:Ljava/lang/Exception;

    invoke-static {v0}, Lc/c9;->j(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lc/b9;->a(Ljava/lang/String;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/W8;->b:Ljava/lang/Exception;

    invoke-static {v0}, Lc/c9;->j(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lc/b9;->a(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
