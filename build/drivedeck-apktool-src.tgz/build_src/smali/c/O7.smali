.class public final Lc/O7;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# static fields
.field public static final synthetic G:I


# instance fields
.field public final A:Landroid/widget/LinearLayout;

.field public B:I

.field public C:I

.field public final D:Landroid/widget/FrameLayout;

.field public E:Z

.field public F:Z

.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Lc/Z7;

.field public final c:Lc/r4;

.field public final d:Landroid/widget/EditText;

.field public final e:Lc/G7;

.field public final f:Landroid/widget/Button;

.field public final g:Landroid/widget/Button;

.field public final h:Landroid/widget/TextView;

.field public final i:Landroid/widget/TextView;

.field public final j:Landroid/widget/ImageView;

.field public final k:[Landroid/widget/LinearLayout;

.field public final l:[Landroid/widget/ImageView;

.field public final m:[Landroid/widget/TextView;

.field public final n:Landroid/widget/ScrollView;

.field public final o:Lc/N7;

.field public p:I

.field public q:Landroid/app/Dialog;

.field public r:Landroid/app/Dialog;

.field public s:I

.field public t:Ljava/lang/String;

.field public final u:Ljava/lang/Runnable;

.field public final v:Z

.field public final w:Landroid/widget/LinearLayout;

.field public final x:Landroid/widget/LinearLayout;

.field public final y:Landroid/widget/LinearLayout;

.field public final z:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;ZLjava/lang/Runnable;)V
    .locals 28

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct/range {p0 .. p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x4

    new-array v4, v3, [Landroid/widget/LinearLayout;

    iput-object v4, v0, Lc/O7;->k:[Landroid/widget/LinearLayout;

    new-array v4, v3, [Landroid/widget/ImageView;

    iput-object v4, v0, Lc/O7;->l:[Landroid/widget/ImageView;

    new-array v4, v3, [Landroid/widget/TextView;

    iput-object v4, v0, Lc/O7;->m:[Landroid/widget/TextView;

    const-string v4, ""

    iput-object v4, v0, Lc/O7;->t:Ljava/lang/String;

    const/4 v5, -0x1

    iput v5, v0, Lc/O7;->B:I

    iput v5, v0, Lc/O7;->C:I

    iput-object v1, v0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object v2, v0, Lc/O7;->b:Lc/Z7;

    move/from16 v6, p3

    iput-boolean v6, v0, Lc/O7;->v:Z

    move-object/from16 v6, p4

    iput-object v6, v0, Lc/O7;->u:Ljava/lang/Runnable;

    invoke-static/range {p1 .. p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v6

    iput-object v6, v0, Lc/O7;->c:Lc/r4;

    const/4 v7, 0x1

    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v8, 0x800033

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v8, 0x14

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v9

    const/16 v10, 0x10

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v9, v11, v8, v12}, Landroid/view/View;->setPadding(IIII)V

    iget v8, v6, Lc/r4;->a:I

    invoke-virtual {v0, v8}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v8

    new-instance v9, Lc/A7;

    const/4 v11, 0x0

    invoke-direct {v9, v0, v11}, Lc/A7;-><init>(Lc/O7;I)V

    const v11, 0x7f030090

    const-string v12, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    invoke-virtual {v0, v11, v9, v12}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v9

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x30

    invoke-virtual {v0, v12}, Lc/O7;->g(I)I

    move-result v13

    const/16 v14, 0x34

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v15

    invoke-direct {v11, v13, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v9

    const-string v11, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d"

    const/16 v13, 0x1e

    invoke-virtual {v0, v13, v11, v7}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v11, "\u0417\u0432\u043e\u043d\u043a\u0438 \u0438 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u043f\u043e Bluetooth"

    const/16 v13, 0xf

    const/4 v15, 0x0

    invoke-virtual {v0, v13, v11, v15}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v11

    iget v6, v6, Lc/r4;->e:I

    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v9, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v6, v15, v11, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v11, 0xc

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v3

    invoke-virtual {v6, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v8, v9, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v9

    invoke-direct {v3, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    new-instance v6, Lc/A7;

    const/4 v9, 0x1

    invoke-direct {v6, v0, v9}, Lc/A7;-><init>(Lc/O7;I)V

    const v9, 0x7f030052

    const-string v14, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-virtual {v0, v9, v6, v14}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v6

    invoke-virtual {v8, v6, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v3, 0x8

    invoke-virtual {v8, v3}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v6

    iput-object v6, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v6

    iput-object v6, v0, Lc/O7;->x:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v6, v8, v9, v12, v13}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->m()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    invoke-virtual {v6, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v6, "\u041d\u0430\u0431\u043e\u0440"

    const-string v8, "\u041d\u0435\u0434\u0430\u0432\u043d\u0438\u0435"

    const-string v9, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b"

    const-string v12, "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u044b\u0435"

    filled-new-array {v6, v8, v9, v12}, [Ljava/lang/String;

    move-result-object v6

    const v8, 0x7f030059

    const v9, 0x7f030041

    const v12, 0x7f030056

    const v13, 0x7f03005c

    filled-new-array {v8, v9, v12, v13}, [I

    move-result-object v8

    move v9, v15

    :goto_0
    iget-object v12, v0, Lc/O7;->k:[Landroid/widget/LinearLayout;

    array-length v12, v12

    const/4 v5, 0x2

    const/4 v11, 0x6

    const/16 v10, 0x11

    if-ge v9, v12, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual {v12, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v10

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v12, v15, v10, v13, v11}, Landroid/view/View;->setPadding(IIII)V

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "phone-section:"

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v12, v10}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v10, Lc/P2;

    const/4 v11, 0x2

    invoke-direct {v10, v0, v9, v11}, Lc/P2;-><init>(Landroid/view/KeyEvent$Callback;II)V

    invoke-virtual {v12, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v12, v7}, Landroid/view/View;->setFocusable(Z)V

    aget-object v10, v6, v9

    invoke-static {v1, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v12, v10}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v10, Lc/e3;

    const/4 v11, 0x2

    invoke-direct {v10, v11}, Lc/e3;-><init>(I)V

    invoke-virtual {v12, v10}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    new-instance v10, Landroid/widget/ImageView;

    invoke-direct {v10, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    aget v11, v8, v9

    iget-object v13, v0, Lc/O7;->c:Lc/r4;

    iget v13, v13, Lc/r4;->d:I

    invoke-virtual {v0, v11, v13}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v10, v5}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x24

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v13

    invoke-direct {v11, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v11, v0, Lc/O7;->l:[Landroid/widget/ImageView;

    aput-object v10, v11, v9

    aget-object v10, v6, v9

    const/16 v11, 0x10

    const/4 v13, 0x0

    invoke-virtual {v0, v11, v10, v13}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v10, v7}, Landroid/widget/TextView;->setMaxLines(I)V

    const/16 v11, 0xc

    const/16 v13, 0x12

    invoke-virtual {v10, v11, v13, v7, v5}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    invoke-virtual {v10, v5}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x1c

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v11

    const/4 v13, -0x1

    invoke-direct {v5, v13, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v11

    iput v11, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v12, v10, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v5, v0, Lc/O7;->m:[Landroid/widget/TextView;

    aput-object v10, v5, v9

    iget-object v5, v0, Lc/O7;->k:[Landroid/widget/LinearLayout;

    aput-object v12, v5, v9

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v5, v13, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v10, 0x4

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v11

    const/4 v13, 0x6

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v3

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v10

    invoke-virtual {v5, v11, v15, v3, v10}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    iget-object v3, v0, Lc/O7;->x:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v12, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v9, v9, 0x1

    const/16 v3, 0x8

    const/4 v5, -0x1

    const/16 v10, 0x10

    const/16 v11, 0xc

    const/4 v15, 0x0

    goto/16 :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v3

    iput-object v3, v0, Lc/O7;->A:Landroid/widget/LinearLayout;

    iget-object v6, v0, Lc/O7;->x:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    invoke-direct {v8, v9, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v6, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0x74

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v10

    invoke-direct {v8, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v3, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/FrameLayout;

    invoke-direct {v3, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lc/O7;->D:Landroid/widget/FrameLayout;

    invoke-virtual/range {p0 .. p0}, Lc/O7;->m()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setClipToOutline(Z)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const v8, 0x3fa66666    # 1.3f

    const/4 v10, 0x0

    invoke-direct {v6, v10, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v8, 0x10

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    iget-object v8, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/ScrollView;

    invoke-direct {v3, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    iput-object v3, v0, Lc/O7;->n:Landroid/widget/ScrollView;

    invoke-virtual {v3, v7}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v3

    const/16 v6, 0x12

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v10

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v3, v8, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    const/16 v6, 0x196

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v8, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget-object v9, v0, Lc/O7;->c:Lc/r4;

    iget v9, v9, Lc/r4;->c:I

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v9, 0x18

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v9

    int-to-float v9, v9

    invoke-virtual {v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v6, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v8, "\u041d\u043e\u043c\u0435\u0440 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430"

    const/4 v9, 0x3

    invoke-virtual {v0, v8, v9}, Lc/O7;->h(Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v8

    iput-object v8, v0, Lc/O7;->d:Landroid/widget/EditText;

    const/4 v10, 0x0

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setShowSoftInputOnFocus(Z)V

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    const/high16 v4, 0x41e00000    # 28.0f

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const v4, 0x800013

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v4, 0x0

    invoke-virtual {v8, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v11, 0x10

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v8, v12, v10, v13, v10}, Landroid/view/View;->setPadding(IIII)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v11, v10, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v8, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Lc/A7;

    const/4 v10, 0x3

    invoke-direct {v8, v0, v10}, Lc/A7;-><init>(Lc/O7;I)V

    const-string v10, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    const v11, 0x7f030054

    invoke-virtual {v0, v11, v8, v10}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v8

    iget-object v10, v0, Lc/O7;->c:Lc/r4;

    iget v10, v10, Lc/r4;->d:I

    invoke-virtual {v0, v11, v10}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    const/16 v11, 0x24

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v13

    const/4 v11, 0x0

    invoke-virtual {v10, v11, v11, v12, v13}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object v10, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/16 v10, 0x12

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v10

    invoke-virtual {v8, v11, v12, v13, v10}, Landroid/view/View;->setPadding(IIII)V

    const-string v10, "phone-key:\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual {v8, v10}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v10, Lc/E7;

    const/4 v11, 0x0

    invoke-direct {v10, v0, v11}, Lc/E7;-><init>(Lc/O7;I)V

    invoke-virtual {v8, v10}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    new-instance v10, Landroid/graphics/drawable/RippleDrawable;

    const/4 v11, 0x0

    invoke-static {v11}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v12

    invoke-direct {v10, v12, v4, v4}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v8, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x40

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v11

    const/4 v12, -0x1

    invoke-direct {v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v8, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0x50

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v10

    invoke-direct {v8, v12, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v8, v12, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v10, 0xc

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v11

    iput v11, v8, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v6, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v24, "9"

    const-string v25, "*"

    const-string v16, "1"

    const-string v17, "2"

    const-string v18, "3"

    const-string v19, "4"

    const-string v20, "5"

    const-string v21, "6"

    const-string v22, "7"

    const-string v23, "8"

    const-string v26, "0"

    const-string v27, "#"

    filled-new-array/range {v16 .. v27}, [Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x0

    :goto_1
    const/4 v11, 0x4

    if-ge v10, v11, :cond_3

    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v11

    const/4 v12, 0x0

    :goto_2
    if-ge v12, v9, :cond_2

    mul-int/lit8 v13, v10, 0x3

    add-int/2addr v13, v12

    aget-object v13, v8, v13

    new-instance v15, Lc/F7;

    const/4 v9, 0x0

    invoke-direct {v15, v0, v13, v9}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v13, v15}, Lc/O7;->b(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    new-instance v15, Ljava/lang/StringBuilder;

    const-string v5, "phone-key:"

    invoke-direct {v15, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v9, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v5, 0x11

    invoke-virtual {v9, v5}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v5, 0x6

    invoke-virtual {v0, v5}, Lc/O7;->g(I)I

    move-result v15

    const/4 v4, 0x4

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v7

    move-object/from16 v17, v8

    invoke-virtual {v0, v5}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v5

    invoke-virtual {v9, v15, v7, v8, v5}, Landroid/view/View;->setPadding(IIII)V

    const/4 v5, 0x1

    const/4 v7, 0x0

    invoke-virtual {v9, v7, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/16 v7, 0x15

    const/16 v8, 0x1d

    const/4 v15, 0x2

    invoke-virtual {v9, v7, v8, v5, v15}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    invoke-virtual {v9, v13}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const-string v5, "0"

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    new-instance v5, Landroid/text/SpannableString;

    const-string v7, "0\n+"

    invoke-direct {v5, v7}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    new-instance v7, Landroid/text/style/RelativeSizeSpan;

    const/high16 v8, 0x3f000000    # 0.5f

    invoke-direct {v7, v8}, Landroid/text/style/RelativeSizeSpan;-><init>(F)V

    const/16 v8, 0x21

    const/4 v13, 0x2

    const/4 v15, 0x3

    invoke-virtual {v5, v7, v13, v15, v8}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    invoke-virtual {v9, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v5, Lc/E7;

    const/4 v7, 0x1

    invoke-direct {v5, v0, v7}, Lc/E7;-><init>(Lc/O7;I)V

    invoke-virtual {v9, v5}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    goto :goto_3

    :cond_1
    const/4 v13, 0x2

    const/4 v15, 0x3

    :goto_3
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v7, -0x1

    const/4 v8, 0x0

    invoke-direct {v5, v8, v7, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v4, 0x5

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v7

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v4

    invoke-virtual {v5, v7, v8, v13, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v11, v9, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v12, v12, 0x1

    move v9, v15

    move-object/from16 v8, v17

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x1

    goto/16 :goto_2

    :cond_2
    move-object/from16 v17, v8

    move v15, v9

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v7, 0x0

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v4, v5, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v11, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v10, v10, 0x1

    move-object/from16 v8, v17

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x1

    goto/16 :goto_1

    :cond_3
    new-instance v4, Lc/G7;

    invoke-direct {v4, v0}, Lc/G7;-><init>(Lc/O7;)V

    iput-object v4, v0, Lc/O7;->e:Lc/G7;

    const-string v5, "\u041f\u043e\u0437\u0432\u043e\u043d\u0438\u0442\u044c"

    invoke-static {v1, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v5, Lc/B7;

    const/4 v6, 0x1

    invoke-direct {v5, v0, v6}, Lc/B7;-><init>(Lc/O7;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v5, 0x7f030053

    const/4 v6, 0x1

    invoke-virtual {v0, v4, v5, v6}, Lc/O7;->f(Landroid/widget/Button;IZ)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x4e

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    const/4 v7, -0x1

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v6, 0xe

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v8

    iput v8, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v4, v0, Lc/O7;->n:Landroid/widget/ScrollView;

    invoke-virtual {v4, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    iget-object v4, v0, Lc/O7;->D:Landroid/widget/FrameLayout;

    iget-object v5, v0, Lc/O7;->n:Landroid/widget/ScrollView;

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v8, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Lc/N7;

    invoke-direct {v4, v0}, Lc/N7;-><init>(Lc/O7;)V

    iput-object v4, v0, Lc/O7;->o:Lc/N7;

    invoke-virtual/range {p0 .. p0}, Lc/O7;->m()Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, 0x0

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v5, v8, v7, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v10, 0x10

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v5, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    iget-object v11, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v5, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v4

    iput-object v4, v0, Lc/O7;->y:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v5

    const/16 v7, 0xa

    invoke-virtual {v0, v7}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v10}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v0, v7}, Lc/O7;->g(I)I

    move-result v7

    invoke-virtual {v4, v5, v8, v9, v7}, Landroid/view/View;->setPadding(IIII)V

    new-instance v5, Landroid/widget/ImageView;

    invoke-direct {v5, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iput-object v5, v0, Lc/O7;->j:Landroid/widget/ImageView;

    iget-object v1, v0, Lc/O7;->c:Lc/r4;

    iget v1, v1, Lc/r4;->l:I

    const v7, 0x7f030092

    invoke-virtual {v0, v7, v1}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x24

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v8

    invoke-direct {v1, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v1

    iput-object v1, v0, Lc/O7;->z:Landroid/widget/LinearLayout;

    const-string v5, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u043d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d"

    const/4 v8, 0x1

    const/16 v9, 0x11

    invoke-virtual {v0, v9, v5, v8}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    iput-object v5, v0, Lc/O7;->h:Landroid/widget/TextView;

    const-string v8, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u043f\u043e Bluetooth \u0434\u043b\u044f \u0437\u0432\u043e\u043d\u043a\u043e\u0432 \u0438 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432"

    const/4 v9, 0x0

    invoke-virtual {v0, v6, v8, v9}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    iput-object v6, v0, Lc/O7;->i:Landroid/widget/TextView;

    iget-object v8, v0, Lc/O7;->c:Lc/r4;

    iget v8, v8, Lc/r4;->e:I

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v1, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v5, v9, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v6, 0xc

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v4, v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Lc/A7;

    const/4 v5, 0x4

    invoke-direct {v1, v0, v5}, Lc/A7;-><init>(Lc/O7;I)V

    const-string v5, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0442\u0435\u043b\u0435\u0444\u043e\u043d"

    invoke-virtual {v0, v5, v1}, Lc/O7;->b(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, v0, Lc/O7;->f:Landroid/widget/Button;

    invoke-virtual {v0, v1, v7, v9}, Lc/O7;->f(Landroid/widget/Button;IZ)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x108

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    const/16 v7, 0x32

    invoke-virtual {v0, v7}, Lc/O7;->g(I)I

    move-result v8

    invoke-direct {v5, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Lc/H;

    const/16 v6, 0x1d

    invoke-direct {v5, v0, v2, v6}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v2, "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u0437\u0432\u043e\u043d\u043e\u043a"

    invoke-virtual {v0, v2, v5}, Lc/O7;->b(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v2

    iput-object v2, v0, Lc/O7;->g:Landroid/widget/Button;

    iget-object v5, v0, Lc/O7;->c:Lc/r4;

    const/4 v6, 0x1

    invoke-static {v2, v5, v6}, Lc/k6;->p(Landroid/widget/Button;Lc/r4;Z)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0xf0

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v7}, Lc/O7;->g(I)I

    move-result v7

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x30

    invoke-virtual {v0, v5}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v5}, Lc/O7;->g(I)I

    move-result v5

    invoke-direct {v2, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v5, 0x8

    invoke-virtual {v0, v5}, Lc/O7;->g(I)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    new-instance v5, Lc/A7;

    const/4 v6, 0x1

    invoke-direct {v5, v0, v6}, Lc/A7;-><init>(Lc/O7;I)V

    const v6, 0x7f030052

    invoke-virtual {v0, v6, v5, v14}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v5

    invoke-virtual {v4, v5, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v2, 0x0

    invoke-virtual {v4, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    const/4 v7, 0x0

    invoke-direct {v5, v6, v7, v7}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v4}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v5, 0x1

    sub-int/2addr v1, v5

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-direct {v5, v6, v7, v7}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x4c

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v2

    const/4 v5, -0x1

    invoke-direct {v1, v5, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0x10

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v0, v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    iget-object v2, v0, Lc/O7;->A:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v1, v0, Lc/O7;->A:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x48

    invoke-virtual {v0, v4}, Lc/O7;->g(I)I

    move-result v4

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, v0, Lc/O7;->D:Landroid/widget/FrameLayout;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    iget-object v1, v0, Lc/O7;->d:Landroid/widget/EditText;

    const/16 v2, 0x11

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v1, v0, Lc/O7;->d:Landroid/widget/EditText;

    new-instance v2, Lc/A7;

    const/4 v3, 0x2

    invoke-direct {v2, v0, v3}, Lc/A7;-><init>(Lc/O7;I)V

    new-instance v3, Lc/D6;

    const/4 v4, 0x1

    invoke-direct {v3, v2, v4}, Lc/D6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/O7;->r(I)V

    return-void
.end method

.method public static a(Lc/O7;Lc/y7;Ljava/lang/String;Z)V
    .locals 9

    invoke-virtual {p0}, Lc/O7;->l()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->b()Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lc/O7;->c()V

    iget v5, p0, Lc/O7;->s:I

    iget-wide v1, p1, Lc/y7;->d:J

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-gtz v1, :cond_2

    iget-object v1, p1, Lc/y7;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_2

    invoke-virtual {v1, v3}, Ljava/lang/String;->codePointAt(I)I

    move-result v4

    invoke-static {v4}, Ljava/lang/Character;->isWhitespace(I)Z

    move-result v6

    if-nez v6, :cond_1

    new-instance v8, Lc/C7;

    move-object v2, v8

    move-object v3, p0

    move-object v4, p2

    move-object v6, p1

    move v7, p3

    invoke-direct/range {v2 .. v7}, Lc/C7;-><init>(Lc/O7;Ljava/lang/String;ILc/y7;Z)V

    invoke-virtual {v0, v1, v8}, Lc/Z7;->h(Ljava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_1
    invoke-static {v4}, Ljava/lang/Character;->charCount(I)I

    move-result v4

    add-int/2addr v3, v4

    goto :goto_0

    :cond_2
    iget-object p1, p1, Lc/y7;->b:Ljava/lang/String;

    invoke-virtual {p0, p1, p2, v5, p3}, Lc/O7;->q(Ljava/lang/String;Ljava/lang/String;IZ)V

    :cond_3
    :goto_1
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/Button;
    .locals 4

    iget-object v0, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v1

    invoke-static {v0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    iget-object v0, p0, Lc/O7;->c:Lc/r4;

    invoke-static {v1, v0, p1}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    const/16 p1, 0xb

    const/16 v0, 0x12

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, p1, v0, v2, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    new-instance p1, Lc/h1;

    const/16 v0, 0x8

    invoke-direct {p1, p2, v0}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v1, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v1
.end method

.method public final c()V
    .locals 1

    iget v0, p0, Lc/O7;->s:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/O7;->s:I

    iget-object v0, p0, Lc/O7;->r:Landroid/app/Dialog;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/O7;->r:Landroid/app/Dialog;

    :cond_0
    return-void
.end method

.method public final d()Landroid/widget/LinearLayout;
    .locals 2

    invoke-virtual {p0}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v1, 0x800033

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    return-object v0
.end method

.method public final e(Ljava/lang/String;I)Z
    .locals 2

    invoke-virtual {p0}, Lc/O7;->l()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->b()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget p1, p0, Lc/O7;->s:I

    if-ne p2, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final f(Landroid/widget/Button;IZ)V
    .locals 4

    iget-object v0, p0, Lc/O7;->c:Lc/r4;

    invoke-static {p1, v0, p3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    invoke-static {p1, v0, v1}, Lc/k6;->p(Landroid/widget/Button;Lc/r4;Z)V

    :cond_0
    const/16 p3, 0xb

    const/16 v0, 0x13

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, p3, v0, v2, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    iget-object p3, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p3, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p1}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    const/16 p3, 0x18

    invoke-virtual {p0, p3}, Lc/O7;->g(I)I

    move-result v0

    invoke-virtual {p0, p3}, Lc/O7;->g(I)I

    move-result p3

    invoke-virtual {p2, v1, v1, v0, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 p3, 0x0

    invoke-virtual {p1, p2, p3, p3, p3}, Landroid/widget/TextView;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/16 p2, 0x8

    invoke-virtual {p0, p2}, Lc/O7;->g(I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    return-void
.end method

.method public final g(I)I
    .locals 1

    int-to-float p1, p1

    iget-object v0, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final h(Ljava/lang/String;I)Landroid/widget/EditText;
    .locals 3

    new-instance v0, Landroid/widget/EditText;

    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lc/O7;->c:Lc/r4;

    iget v1, p1, Lc/r4;->d:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget v1, p1, Lc/r4;->e:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHintTextColor(I)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v2, 0x41880000    # 17.0f

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setInputType(I)V

    new-instance p2, Landroid/text/InputFilter$LengthFilter;

    const/16 v2, 0xa0

    invoke-direct {p2, v2}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    new-array v1, v1, [Landroid/text/InputFilter;

    const/4 v2, 0x0

    aput-object p2, v1, v2

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setFilters([Landroid/text/InputFilter;)V

    new-instance p2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget p1, p1, Lc/r4;->c:I

    invoke-virtual {p2, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 p1, 0x18

    invoke-virtual {p0, p1}, Lc/O7;->g(I)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {p2, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v0, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 p1, 0xc

    invoke-virtual {p0, p1}, Lc/O7;->g(I)I

    move-result p2

    invoke-virtual {p0, p1}, Lc/O7;->g(I)I

    move-result p1

    invoke-virtual {v0, p2, v2, p1, v2}, Landroid/view/View;->setPadding(IIII)V

    return-object v0
.end method

.method public final i(II)Landroid/graphics/drawable/Drawable;
    .locals 2

    iget-object v0, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p1}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/16 p2, 0x18

    invoke-virtual {p0, p2}, Lc/O7;->g(I)I

    move-result v0

    invoke-virtual {p0, p2}, Lc/O7;->g(I)I

    move-result p2

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v1, v0, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    return-object p1
.end method

.method public final j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;
    .locals 4

    new-instance v0, Landroid/widget/ImageButton;

    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    iget-object v2, p0, Lc/O7;->c:Lc/r4;

    iget v3, v2, Lc/r4;->d:I

    invoke-virtual {p0, p1, v3}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v1, p3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-static {v2}, Lc/G8;->V0(Lc/r4;)I

    move-result p3

    invoke-virtual {p1, p3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const p3, 0x461c4000    # 10000.0f

    invoke-virtual {p1, p3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance p3, Landroid/graphics/drawable/RippleDrawable;

    const/4 v1, 0x0

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v2, 0x0

    invoke-direct {p3, v1, p1, v2}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, p3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 p1, 0xc

    invoke-virtual {p0, p1}, Lc/O7;->g(I)I

    move-result p3

    const/16 v1, 0xa

    invoke-virtual {p0, v1}, Lc/O7;->g(I)I

    move-result v2

    invoke-virtual {p0, p1}, Lc/O7;->g(I)I

    move-result p1

    invoke-virtual {p0, v1}, Lc/O7;->g(I)I

    move-result v1

    invoke-virtual {v0, p3, v2, p1, v1}, Landroid/view/View;->setPadding(IIII)V

    new-instance p1, Lc/h1;

    const/4 p3, 0x7

    invoke-direct {p1, p2, p3}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method public final k(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lc/O7;->d:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/TextView;->length()I

    move-result v1

    const/16 v2, 0x15

    if-ge v1, v2, :cond_1

    const-string v1, "+"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroid/widget/TextView;->length()I

    move-result v1

    if-nez v1, :cond_1

    :cond_0
    invoke-virtual {v0}, Landroid/widget/TextView;->getSelectionStart()I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v0}, Landroid/widget/TextView;->getSelectionEnd()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0, v1, v2, p1}, Landroid/text/Editable;->replace(IILjava/lang/CharSequence;)Landroid/text/Editable;

    :cond_1
    return-void
.end method

.method public final l()Z
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getWindowVisibility()I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final m()Landroid/graphics/drawable/GradientDrawable;
    .locals 2

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget-object v1, p0, Lc/O7;->c:Lc/r4;

    iget v1, v1, Lc/r4;->b:I

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v1, 0x20

    invoke-virtual {p0, v1}, Lc/O7;->g(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public final n()V
    .locals 7

    iget-boolean v0, p0, Lc/O7;->E:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "|"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/O7;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    iget v2, v2, Lc/e8;->e:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/O7;->t:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    iput-object v0, p0, Lc/O7;->t:Ljava/lang/String;

    invoke-virtual {p0}, Lc/O7;->c()V

    :cond_1
    iget-object v0, p0, Lc/O7;->b:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_4

    iget-object v1, v0, Lc/e8;->b:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    move v4, v2

    :goto_0
    if-ge v4, v3, :cond_3

    invoke-virtual {v1, v4}, Ljava/lang/String;->codePointAt(I)I

    move-result v5

    invoke-static {v5}, Ljava/lang/Character;->isWhitespace(I)Z

    move-result v6

    if-nez v6, :cond_2

    iget-object v1, v0, Lc/e8;->b:Ljava/lang/String;

    goto :goto_2

    :cond_2
    invoke-static {v5}, Ljava/lang/Character;->charCount(I)I

    move-result v5

    add-int/2addr v4, v5

    goto :goto_0

    :cond_3
    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d"

    :goto_1
    invoke-static {v1, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :cond_4
    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u043d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d"

    goto :goto_1

    :goto_2
    iget-object v3, p0, Lc/O7;->h:Landroid/widget/TextView;

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lc/O7;->j:Landroid/widget/ImageView;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v3

    if-eqz v3, :cond_6

    iget-object v3, p0, Lc/O7;->c:Lc/r4;

    iget-boolean v4, v3, Lc/r4;->m:Z

    if-eqz v4, :cond_5

    const v3, -0xff9066

    goto :goto_3

    :cond_5
    invoke-static {v3}, Lc/k6;->a(Lc/r4;)I

    move-result v3

    goto :goto_3

    :cond_6
    iget-object v3, p0, Lc/O7;->c:Lc/r4;

    iget v3, v3, Lc/r4;->e:I

    :goto_3
    const v4, 0x7f030092

    invoke-virtual {p0, v4, v3}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object v1, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->K:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->K:Ljava/lang/String;

    goto :goto_4

    :cond_7
    iget-object v1, p0, Lc/O7;->b:Lc/Z7;

    iget-boolean v1, v1, Lc/Z7;->q:Z

    if-eqz v1, :cond_8

    const-string v1, "\u0418\u043c\u043f\u043e\u0440\u0442 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432\u2026"

    goto :goto_4

    :cond_8
    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v1

    if-eqz v1, :cond_9

    const-string v1, "\u041c\u043e\u0436\u043d\u043e \u0437\u0432\u043e\u043d\u0438\u0442\u044c \u0438 \u0438\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b"

    goto :goto_4

    :cond_9
    const-string v1, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u043f\u043e Bluetooth \u0434\u043b\u044f \u0437\u0432\u043e\u043d\u043a\u043e\u0432 \u0438 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432"

    :goto_4
    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v3

    if-eqz v3, :cond_c

    iget v1, v0, Lc/e8;->e:I

    const/4 v3, 0x2

    if-eq v1, v3, :cond_b

    const/4 v3, 0x3

    if-eq v1, v3, :cond_a

    const-string v1, "\u0420\u0430\u0437\u0433\u043e\u0432\u043e\u0440"

    goto :goto_5

    :cond_a
    const-string v1, "\u0412\u0445\u043e\u0434\u044f\u0449\u0438\u0439 \u0437\u0432\u043e\u043d\u043e\u043a"

    goto :goto_5

    :cond_b
    const-string v1, "\u0418\u0441\u0445\u043e\u0434\u044f\u0449\u0438\u0439 \u0437\u0432\u043e\u043d\u043e\u043a"

    :cond_c
    :goto_5
    iget-object v3, p0, Lc/O7;->i:Landroid/widget/TextView;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v1

    if-eqz v1, :cond_d

    iget-object v1, v0, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v5, " \u00b7 "

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, v0, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_6

    :cond_d
    const-string v1, ""

    :goto_6
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p0}, Lc/O7;->u()V

    iget-object v1, p0, Lc/O7;->f:Landroid/widget/Button;

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v0

    if-eqz v0, :cond_e

    const/16 v2, 0x8

    :cond_e
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lc/O7;->v()V

    iget-object v0, p0, Lc/O7;->o:Lc/N7;

    invoke-virtual {v0}, Lc/N7;->a()V

    return-void
.end method

.method public final o(Z)V
    .locals 2

    if-nez p1, :cond_0

    const-string p1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    iget-object v0, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x1

    invoke-static {v0, p1, v0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :cond_0
    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 1

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    invoke-virtual {p0}, Lc/O7;->l()Z

    move-result v0

    invoke-virtual {p0, v0}, Lc/O7;->s(Z)V

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/O7;->s(Z)V

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method public final onMeasure(II)V
    .locals 16

    move-object/from16 v0, p0

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    const/16 v3, 0x1e0

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-lt v1, v3, :cond_4

    iget-boolean v3, v0, Lc/O7;->v:Z

    if-nez v3, :cond_0

    move v3, v4

    goto :goto_1

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    :goto_0
    if-eqz v3, :cond_2

    instance-of v6, v3, Lc/F;

    if-eqz v6, :cond_1

    check-cast v3, Lc/F;

    invoke-virtual {v3}, Lc/F;->k()Z

    move-result v3

    goto :goto_1

    :cond_1
    invoke-interface {v3}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    goto :goto_0

    :cond_2
    move v3, v5

    :goto_1
    if-nez v3, :cond_3

    goto :goto_2

    :cond_3
    move v3, v5

    goto :goto_3

    :cond_4
    :goto_2
    move v3, v4

    :goto_3
    iget v6, v0, Lc/O7;->B:I

    if-ne v2, v6, :cond_5

    iget v6, v0, Lc/O7;->C:I

    if-ne v1, v6, :cond_5

    iget-boolean v6, v0, Lc/O7;->F:Z

    if-ne v6, v3, :cond_5

    goto/16 :goto_12

    :cond_5
    iput-boolean v3, v0, Lc/O7;->F:Z

    iput v2, v0, Lc/O7;->B:I

    iput v1, v0, Lc/O7;->C:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    int-to-float v1, v1

    div-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    int-to-float v2, v2

    div-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget-boolean v3, v0, Lc/O7;->F:Z

    const/16 v6, 0x10

    if-eqz v3, :cond_6

    move v3, v1

    goto :goto_4

    :cond_6
    div-int/lit8 v3, v1, 0x2

    sub-int/2addr v3, v6

    :goto_4
    add-int/lit8 v7, v3, -0x40

    const/4 v8, 0x3

    div-int/2addr v7, v8

    add-int/lit16 v2, v2, -0xe8

    int-to-float v2, v2

    const/high16 v9, 0x40b00000    # 5.5f

    div-float/2addr v2, v9

    float-to-int v2, v2

    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/16 v7, 0x52

    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/16 v7, 0x30

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    div-int/lit8 v7, v2, 0x6

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/16 v9, 0x8

    invoke-static {v9, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v10

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v10, v11, v12, v13}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    invoke-virtual {v10, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    invoke-virtual {v10, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    check-cast v11, Landroid/widget/TextView;

    const/high16 v12, 0x41c00000    # 24.0f

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v10, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    invoke-virtual {v10, v9}, Landroid/view/View;->setVisibility(I)V

    iget-object v10, v0, Lc/O7;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v10}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v11

    check-cast v11, Landroid/widget/LinearLayout$LayoutParams;

    iput v5, v11, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-boolean v11, v0, Lc/O7;->F:Z

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    iget-boolean v11, v0, Lc/O7;->F:Z

    const/4 v12, -0x1

    if-eqz v11, :cond_7

    move v13, v12

    goto :goto_5

    :cond_7
    move v13, v5

    :goto_5
    if-eqz v11, :cond_8

    move v11, v5

    goto :goto_6

    :cond_8
    move v11, v12

    :goto_6
    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v10, v13, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    iget-object v11, v0, Lc/O7;->D:Landroid/widget/FrameLayout;

    invoke-virtual {v11, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    iget-boolean v11, v0, Lc/O7;->F:Z

    if-eqz v11, :cond_9

    move v13, v12

    goto :goto_7

    :cond_9
    move v13, v5

    :goto_7
    if-eqz v11, :cond_a

    move v11, v5

    goto :goto_8

    :cond_a
    move v11, v12

    :goto_8
    invoke-direct {v10, v13, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    iget-boolean v11, v0, Lc/O7;->F:Z

    if-eqz v11, :cond_b

    move v11, v5

    goto :goto_9

    :cond_b
    const/16 v11, 0x14

    :goto_9
    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v11

    iput v11, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget-object v11, v0, Lc/O7;->o:Lc/N7;

    invoke-virtual {v11, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v10, v0, Lc/O7;->n:Landroid/widget/ScrollView;

    invoke-virtual {v10, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout;

    invoke-virtual {v10, v5}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v10, v5, v11, v5, v15}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v10, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    check-cast v11, Landroid/widget/LinearLayout;

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    sub-int/2addr v3, v6

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v3

    const/16 v6, 0x40

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v13

    invoke-direct {v15, v3, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v15}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v3, v0, Lc/O7;->d:Landroid/widget/EditText;

    const/high16 v13, 0x41f00000    # 30.0f

    invoke-virtual {v3, v13}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v11, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    invoke-direct {v11, v13, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v6

    iput v6, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v3, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v6, 0xc

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v3, v11, v13, v15, v14}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v10, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout;

    invoke-virtual {v3, v5}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    mul-int/lit8 v11, v2, 0x3

    mul-int/lit8 v13, v7, 0x2

    add-int/2addr v13, v11

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v11

    mul-int/lit8 v13, v2, 0x4

    mul-int/lit8 v14, v7, 0x3

    add-int/2addr v14, v13

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v13

    invoke-direct {v10, v11, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v11

    iput v11, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v3, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move v10, v5

    :goto_a
    const/4 v11, 0x4

    const/4 v13, 0x2

    const/16 v14, 0x1a

    if-ge v10, v11, :cond_f

    invoke-virtual {v3, v10}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    check-cast v11, Landroid/widget/LinearLayout;

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v9

    invoke-direct {v15, v12, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-nez v10, :cond_c

    move v9, v5

    goto :goto_b

    :cond_c
    move v9, v7

    :goto_b
    invoke-virtual {v0, v9}, Lc/O7;->g(I)I

    move-result v9

    iput v9, v15, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v11, v5}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v11, v15}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move v9, v5

    :goto_c
    if-ge v9, v8, :cond_e

    invoke-virtual {v11, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/Button;

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v6

    invoke-direct {v8, v12, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-nez v9, :cond_d

    move v6, v5

    goto :goto_d

    :cond_d
    move v6, v7

    :goto_d
    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    iput v6, v8, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v15, v8}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v15, v5}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v15, v5}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v15, v5}, Landroid/widget/TextView;->setMinWidth(I)V

    invoke-virtual {v15, v5}, Landroid/view/View;->setMinimumWidth(I)V

    invoke-virtual {v15, v5, v5, v5, v5}, Landroid/view/View;->setPadding(IIII)V

    const-string v6, "sans-serif-light"

    invoke-static {v6, v5}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v6

    invoke-virtual {v15, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    div-int/lit8 v6, v2, 0x2

    const/16 v8, 0x1e

    invoke-static {v8, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    invoke-virtual {v15, v14, v6, v4, v13}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    add-int/lit8 v9, v9, 0x1

    const/16 v6, 0xc

    const/4 v8, 0x3

    const/4 v12, -0x1

    goto :goto_c

    :cond_e
    add-int/lit8 v10, v10, 0x1

    const/16 v6, 0xc

    const/4 v8, 0x3

    const/16 v9, 0x8

    const/4 v12, -0x1

    goto :goto_a

    :cond_f
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v2

    invoke-direct {v3, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0xc

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v6

    iput v6, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    iget-object v2, v0, Lc/O7;->e:Lc/G7;

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v2, v0, Lc/O7;->x:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v3

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v7

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v2, v3, v6, v7, v8}, Landroid/view/View;->setPadding(IIII)V

    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget-object v6, v0, Lc/O7;->c:Lc/r4;

    iget v6, v6, Lc/r4;->b:I

    invoke-virtual {v3, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v6, 0x22

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v3, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x44

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v6

    const/4 v7, -0x1

    invoke-direct {v3, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iget-object v6, v0, Lc/O7;->A:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v7, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move v2, v5

    :goto_e
    iget-object v3, v0, Lc/O7;->k:[Landroid/widget/LinearLayout;

    array-length v6, v3

    if-ge v2, v6, :cond_10

    aget-object v3, v3, v2

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v3, v5, v6, v5, v8}, Landroid/view/View;->setPadding(IIII)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v6, v5, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v3, v0, Lc/O7;->l:[Landroid/widget/ImageView;

    aget-object v3, v3, v2

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v0, v14}, Lc/O7;->g(I)I

    move-result v9

    invoke-direct {v6, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x14

    invoke-virtual {v0, v6}, Lc/O7;->g(I)I

    move-result v8

    invoke-direct {v3, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v13}, Lc/O7;->g(I)I

    move-result v7

    iput v7, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v7, v0, Lc/O7;->m:[Landroid/widget/TextView;

    aget-object v8, v7, v2

    invoke-virtual {v8, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    aget-object v3, v7, v2

    const/16 v7, 0xb

    const/16 v8, 0xe

    invoke-virtual {v3, v7, v8, v4, v13}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    add-int/lit8 v2, v2, 0x1

    const/4 v7, -0x1

    goto :goto_e

    :cond_10
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x2c

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v6

    const/4 v7, -0x1

    invoke-direct {v2, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v6

    iput v6, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v6, v0, Lc/O7;->y:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x8

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v7

    invoke-virtual {v0, v2}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v6, v7, v5, v8, v5}, Landroid/view/View;->setPadding(IIII)V

    iget-object v7, v0, Lc/O7;->j:Landroid/widget/ImageView;

    invoke-virtual {v7, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    iget-object v7, v0, Lc/O7;->i:Landroid/widget/TextView;

    invoke-virtual {v7, v2}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x190

    if-ge v1, v2, :cond_11

    goto :goto_f

    :cond_11
    move v13, v4

    :goto_f
    iget-object v7, v0, Lc/O7;->h:Landroid/widget/TextView;

    invoke-virtual {v7, v13}, Landroid/widget/TextView;->setMaxLines(I)V

    if-ge v1, v2, :cond_12

    const/high16 v8, 0x41400000    # 12.0f

    goto :goto_10

    :cond_12
    const/high16 v8, 0x41500000    # 13.0f

    :goto_10
    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    sget-object v8, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v7, v5, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v8, 0xc

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v7, v9}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v0, v8}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginEnd(I)V

    iget-object v8, v0, Lc/O7;->z:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    if-ge v1, v2, :cond_13

    const/16 v1, 0x70

    goto :goto_11

    :cond_13
    iget-boolean v1, v0, Lc/O7;->F:Z

    if-eqz v1, :cond_14

    const/16 v1, 0x90

    goto :goto_11

    :cond_14
    const/16 v1, 0xb8

    :goto_11
    invoke-virtual {v0, v1}, Lc/O7;->g(I)I

    move-result v1

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v2

    invoke-direct {v7, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iget-object v1, v0, Lc/O7;->f:Landroid/widget/Button;

    invoke-virtual {v1, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v2

    invoke-virtual {v0, v11}, Lc/O7;->g(I)I

    move-result v3

    invoke-virtual {v1, v2, v5, v3, v5}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v6}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    sub-int/2addr v1, v4

    invoke-virtual {v6, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x28

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v4

    invoke-virtual {v0, v3}, Lc/O7;->g(I)I

    move-result v3

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->w()V

    invoke-virtual/range {p0 .. p0}, Lc/O7;->u()V

    :goto_12
    invoke-super/range {p0 .. p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    return-void
.end method

.method public final onVisibilityChanged(Landroid/view/View;I)V
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/view/View;->onVisibilityChanged(Landroid/view/View;I)V

    iget-object p1, p0, Lc/O7;->o:Lc/N7;

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lc/O7;->l()Z

    move-result p1

    invoke-virtual {p0, p1}, Lc/O7;->s(Z)V

    :cond_0
    return-void
.end method

.method public final onWindowVisibilityChanged(I)V
    .locals 0

    invoke-super {p0, p1}, Landroid/view/View;->onWindowVisibilityChanged(I)V

    iget-object p1, p0, Lc/O7;->o:Lc/N7;

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lc/O7;->l()Z

    move-result p1

    invoke-virtual {p0, p1}, Lc/O7;->s(Z)V

    :cond_0
    return-void
.end method

.method public final p()Landroid/widget/LinearLayout;
    .locals 2

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    return-object v0
.end method

.method public final q(Ljava/lang/String;Ljava/lang/String;IZ)V
    .locals 0

    invoke-virtual {p0, p2, p3}, Lc/O7;->e(Ljava/lang/String;I)Z

    move-result p2

    if-nez p2, :cond_0

    return-void

    :cond_0
    iget-object p2, p0, Lc/O7;->d:Landroid/widget/EditText;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz p4, :cond_3

    new-instance p2, Lc/E3;

    const/4 p3, 0x3

    invoke-direct {p2, p0, p3}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    iget-object p3, p0, Lc/O7;->b:Lc/Z7;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p4

    if-nez p4, :cond_2

    iget-object p4, p3, Lc/Z7;->a:Lc/e8;

    invoke-virtual {p4}, Lc/e8;->b()Z

    move-result p4

    if-nez p4, :cond_1

    goto :goto_0

    :cond_1
    const/4 p4, 0x7

    invoke-virtual {p3, p4, p1, p2}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_2
    :goto_0
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p2, p1}, Lc/E3;->accept(Ljava/lang/Object;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public final r(I)V
    .locals 7

    invoke-virtual {p0}, Lc/O7;->c()V

    iput p1, p0, Lc/O7;->p:I

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Lc/O7;->k:[Landroid/widget/LinearLayout;

    array-length v3, v2

    const/4 v4, 0x1

    if-ge v1, v3, :cond_6

    aget-object v2, v2, v1

    if-ne v1, p1, :cond_0

    goto :goto_1

    :cond_0
    move v4, v0

    :goto_1
    invoke-virtual {v2, v4}, Landroid/view/View;->setSelected(Z)V

    iget-object v3, p0, Lc/O7;->c:Lc/r4;

    if-eqz v4, :cond_3

    iget-boolean v4, v3, Lc/r4;->m:Z

    if-eqz v4, :cond_1

    iget v4, v3, Lc/r4;->c:I

    goto :goto_2

    :cond_1
    iget v4, v3, Lc/r4;->b:I

    :goto_2
    invoke-static {v3}, Lc/k6;->a(Lc/r4;)I

    move-result v5

    iget-boolean v6, v3, Lc/r4;->m:Z

    if-eqz v6, :cond_2

    const v6, 0x3df5c28f    # 0.12f

    goto :goto_3

    :cond_2
    const v6, 0x3da3d70a    # 0.08f

    :goto_3
    invoke-static {v6, v4, v5}, Lc/k6;->m(FII)I

    move-result v4

    goto :goto_4

    :cond_3
    move v4, v0

    :goto_4
    invoke-static {v2, v4}, Lc/k6;->k0(Landroid/view/View;I)V

    iget-object v2, p0, Lc/O7;->l:[Landroid/widget/ImageView;

    aget-object v2, v2, v1

    if-ne v1, p1, :cond_4

    invoke-static {v3}, Lc/k6;->a(Lc/r4;)I

    move-result v4

    goto :goto_5

    :cond_4
    iget v4, v3, Lc/r4;->d:I

    :goto_5
    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setColorFilter(I)V

    iget-object v2, p0, Lc/O7;->m:[Landroid/widget/TextView;

    aget-object v2, v2, v1

    if-ne v1, p1, :cond_5

    invoke-static {v3}, Lc/k6;->a(Lc/r4;)I

    move-result v3

    goto :goto_6

    :cond_5
    iget v3, v3, Lc/r4;->d:I

    :goto_6
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_6
    const/4 v1, 0x2

    if-ne p1, v1, :cond_7

    move v0, v4

    goto :goto_7

    :cond_7
    const/4 v2, 0x3

    if-ne p1, v2, :cond_8

    move v0, v1

    :cond_8
    :goto_7
    iget-object p1, p0, Lc/O7;->o:Lc/N7;

    iput v0, p1, Lc/N7;->a:I

    const-string v0, ""

    iput-object v0, p1, Lc/N7;->c:Ljava/lang/String;

    invoke-virtual {p1}, Lc/N7;->a()V

    invoke-virtual {p0}, Lc/O7;->v()V

    invoke-virtual {p0}, Lc/O7;->w()V

    return-void
.end method

.method public final s(Z)V
    .locals 3

    iget-boolean v0, p0, Lc/O7;->E:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Lc/O7;->E:Z

    const-string v0, ""

    iget-object v1, p0, Lc/O7;->o:Lc/N7;

    iget-object v2, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_1

    iget-object p1, v2, Lru/drivedeck/launcher/MainActivity;->b0:Ljava/util/HashSet;

    invoke-virtual {p1, p0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iput-object v0, v1, Lc/N7;->c:Ljava/lang/String;

    invoke-virtual {p0}, Lc/O7;->n()V

    iget-boolean p1, p0, Lc/O7;->v:Z

    if-eqz p1, :cond_3

    invoke-virtual {v2}, Lru/drivedeck/launcher/MainActivity;->Y()V

    goto :goto_0

    :cond_1
    iget-object p1, v2, Lru/drivedeck/launcher/MainActivity;->b0:Ljava/util/HashSet;

    invoke-virtual {p1, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget-object p1, p0, Lc/O7;->q:Landroid/app/Dialog;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    const/4 p1, 0x0

    iput-object p1, p0, Lc/O7;->q:Landroid/app/Dialog;

    :cond_2
    invoke-virtual {p0}, Lc/O7;->c()V

    iget p1, v1, Lc/N7;->b:I

    add-int/lit8 p1, p1, 0x1

    iput p1, v1, Lc/N7;->b:I

    iput-object v0, v1, Lc/N7;->c:Ljava/lang/String;

    :cond_3
    :goto_0
    return-void
.end method

.method public final t(ILjava/lang/String;Z)Landroid/widget/TextView;
    .locals 2

    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p2, p0, Lc/O7;->c:Lc/r4;

    iget p2, p2, Lc/r4;->d:I

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setTextColor(I)V

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    if-eqz p3, :cond_0

    const/4 p1, 0x0

    const/4 p2, 0x1

    invoke-virtual {v0, p1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_0
    return-object v0
.end method

.method public final u()V
    .locals 2

    iget-object v0, p0, Lc/O7;->b:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-boolean v0, p0, Lc/O7;->F:Z

    if-eqz v0, :cond_0

    const-string v0, "Bluetooth"

    goto :goto_0

    :cond_0
    const-string v0, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 Bluetooth"

    goto :goto_0

    :cond_1
    iget-boolean v0, p0, Lc/O7;->F:Z

    if-eqz v0, :cond_2

    const-string v0, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    goto :goto_0

    :cond_2
    const-string v0, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0442\u0435\u043b\u0435\u0444\u043e\u043d"

    :goto_0
    iget-object v1, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/O7;->f:Landroid/widget/Button;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final v()V
    .locals 8

    iget-object v0, p0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->d()Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v2, "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u0437\u0432\u043e\u043d\u043e\u043a"

    goto :goto_0

    :cond_0
    const-string v2, "\u041f\u043e\u0437\u0432\u043e\u043d\u0438\u0442\u044c"

    :goto_0
    iget-object v3, p0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v3, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lc/O7;->e:Lc/G7;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, p0, Lc/O7;->c:Lc/r4;

    invoke-static {v3, v2, v1}, Lc/k6;->p(Landroid/widget/Button;Lc/r4;Z)V

    const/16 v2, 0x12

    const/16 v4, 0x1a

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v3, v2, v4, v5, v6}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    if-eqz v1, :cond_1

    const v2, 0x7f030057

    goto :goto_1

    :cond_1
    const v2, 0x7f030053

    :goto_1
    const/4 v4, -0x1

    invoke-virtual {p0, v2, v4}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/16 v4, 0x22

    invoke-virtual {p0, v4}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {p0, v4}, Lc/O7;->g(I)I

    move-result v4

    const/4 v7, 0x0

    invoke-virtual {v2, v7, v7, v6, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v4, 0x0

    invoke-virtual {v3, v2, v4, v4, v4}, Landroid/widget/TextView;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    if-nez v1, :cond_3

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->b()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/O7;->d:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_2

    :cond_2
    move v5, v7

    :cond_3
    :goto_2
    invoke-virtual {v3, v5}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p0, Lc/O7;->g:Landroid/widget/Button;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method

.method public final w()V
    .locals 4

    iget-boolean v0, p0, Lc/O7;->F:Z

    const/4 v1, 0x0

    const/16 v2, 0x8

    if-eqz v0, :cond_1

    iget v0, p0, Lc/O7;->p:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move v0, v2

    goto :goto_1

    :cond_1
    :goto_0
    move v0, v1

    :goto_1
    iget-object v3, p0, Lc/O7;->D:Landroid/widget/FrameLayout;

    invoke-virtual {v3, v0}, Landroid/view/View;->setVisibility(I)V

    iget-boolean v0, p0, Lc/O7;->F:Z

    if-eqz v0, :cond_3

    iget v0, p0, Lc/O7;->p:I

    if-eqz v0, :cond_2

    goto :goto_2

    :cond_2
    move v1, v2

    :cond_3
    :goto_2
    iget-object v0, p0, Lc/O7;->o:Lc/N7;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    return-void
.end method
