.class public final Lc/E0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/F0;

.field public final b:Lc/i6;

.field public final c:I

.field public d:F

.field public e:F

.field public f:F

.field public g:F

.field public final h:F

.field public final i:F

.field public final j:F

.field public final k:Landroid/text/StaticLayout;


# direct methods
.method public constructor <init>(Lc/F0;FFFFFLandroid/text/StaticLayout;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/E0;->a:Lc/F0;

    const/4 v0, 0x0

    iput-object v0, p0, Lc/E0;->b:Lc/i6;

    iget p1, p1, Lc/F0;->f:I

    iput p1, p0, Lc/E0;->c:I

    iput p2, p0, Lc/E0;->d:F

    iput p3, p0, Lc/E0;->e:F

    iput p4, p0, Lc/E0;->h:F

    iput p5, p0, Lc/E0;->i:F

    iput p6, p0, Lc/E0;->j:F

    iput-object p7, p0, Lc/E0;->k:Landroid/text/StaticLayout;

    return-void
.end method

.method public constructor <init>(Lc/i6;FFFFFLandroid/text/StaticLayout;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/E0;->a:Lc/F0;

    iput-object p1, p0, Lc/E0;->b:Lc/i6;

    iget-object p1, p1, Lc/i6;->c:Ljava/lang/String;

    invoke-static {p1}, Lc/p6;->a(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lc/E0;->c:I

    iput p2, p0, Lc/E0;->d:F

    iput p3, p0, Lc/E0;->e:F

    iput p4, p0, Lc/E0;->h:F

    iput p5, p0, Lc/E0;->i:F

    iput p6, p0, Lc/E0;->j:F

    iput-object p7, p0, Lc/E0;->k:Landroid/text/StaticLayout;

    return-void
.end method
