.class public final Lc/o1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lc/F3;

.field public final c:Landroid/os/Handler;

.field public d:Landroid/os/HandlerThread;

.field public e:Landroid/os/Handler;

.field public f:Z

.field public volatile g:Landroid/os/IBinder;

.field public volatile h:J

.field public i:J

.field public volatile j:Lc/n1;

.field public final k:Lc/i;

.field public final l:Lc/O;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/o1;->c:Landroid/os/Handler;

    new-instance v0, Lc/i;

    const/4 v1, 0x5

    invoke-direct {v0, p0, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/o1;->k:Lc/i;

    new-instance v0, Lc/O;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/O;-><init>(Landroid/content/ServiceConnection;I)V

    iput-object v0, p0, Lc/o1;->l:Lc/O;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/o1;->a:Landroid/content/Context;

    iput-object p2, p0, Lc/o1;->b:Lc/F3;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lc/n1;
    .locals 10

    const-string v0, " \u00b7 "

    const/4 v1, 0x0

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x4000

    if-le v2, v3, :cond_0

    goto/16 :goto_7

    :cond_0
    :try_start_0
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "activeNavigationMode"

    invoke-static {v2, p0}, Lc/o1;->d(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v3, "car|carstepbystep|taxi|motorcycle|freeroam"

    invoke-virtual {p0, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_a

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v4, "badLocation"

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    goto/16 :goto_7

    :cond_1
    const-string v3, "speedLimit"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/lang/Number;

    if-eqz v4, :cond_2

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v3

    goto :goto_0

    :cond_2
    const-wide/high16 v3, -0x4010000000000000L    # -1.0

    :goto_0
    invoke-static {v3, v4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v5

    if-eqz v5, :cond_3

    const-wide v5, 0x400ccccccccccccdL    # 3.6

    mul-double/2addr v3, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    goto :goto_1

    :cond_3
    const-wide/16 v3, -0x1

    :goto_1
    const-wide/16 v5, 0x5

    cmp-long v5, v3, v5

    if-ltz v5, :cond_4

    const-wide/16 v5, 0xc7

    cmp-long v5, v3, v5

    if-gtz v5, :cond_4

    long-to-int v3, v3

    goto :goto_2

    :cond_4
    const/4 v3, -0x1

    :goto_2
    const-string v4, "freeroam"

    invoke-virtual {p0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v4, ""

    if-nez p0, :cond_9

    :try_start_1
    const-string p0, "maneuverDistance"

    invoke-static {v2, p0}, Lc/o1;->d(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v5, "maneuverDescription"

    invoke-static {v2, v5}, Lc/o1;->d(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "maneuverIcon"

    invoke-static {v2, v6}, Lc/o1;->d(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_9

    invoke-static {v2, v4}, Lc/j5;->b(Ljava/lang/String;Ljava/lang/String;)Lc/j5;

    move-result-object v6

    iget v6, v6, Lc/j5;->a:I

    const/16 v7, 0x10

    if-eq v6, v7, :cond_5

    const/4 v6, 0x1

    goto :goto_3

    :cond_5
    const/4 v6, 0x0

    :goto_3
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_6

    move-object p0, v4

    goto :goto_4

    :cond_6
    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_4
    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v6, :cond_7

    goto :goto_5

    :cond_7
    move-object v2, v5

    :goto_5
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    if-eqz v6, :cond_8

    move-object v4, v5

    :cond_8
    move-object v9, v4

    move-object v4, p0

    move-object p0, v9

    goto :goto_6

    :cond_9
    move-object p0, v4

    :goto_6
    new-instance v0, Lc/n1;

    invoke-direct {v0, v3, v4, p0}, Lc/n1;-><init>(ILjava/lang/String;Ljava/lang/Object;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    return-object v0

    :catch_0
    :cond_a
    :goto_7
    return-object v1
.end method

.method public static d(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/String;

    if-eqz p1, :cond_0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    const/16 v0, 0x100

    if-gt p1, v0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    const-string p0, ""

    :goto_0
    return-object p0
.end method

.method public static e(Landroid/os/IBinder;ILandroid/os/Binder;)Landroid/os/Parcel;
    .locals 3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const-string v2, "ru.dublgis.api.IDashboardInformationService"

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v2, 0x2

    if-eq p1, v2, :cond_0

    const/4 v2, 0x3

    if-ne p1, v2, :cond_1

    :cond_0
    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    :cond_1
    const/4 p2, 0x0

    invoke-interface {p0, p1, v0, v1, p2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p0

    if-eqz p0, :cond_2

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    return-object v1

    :catchall_0
    move-exception p0

    goto :goto_0

    :cond_2
    :try_start_1
    new-instance p0, Landroid/os/RemoteException;

    const-string p1, "2GIS transaction unavailable"

    invoke-direct {p0, p1}, Landroid/os/RemoteException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    throw p0
.end method


# virtual methods
.method public final b()V
    .locals 9

    iget-object v2, p0, Lc/o1;->g:Landroid/os/IBinder;

    iget-wide v3, p0, Lc/o1;->h:J

    if-nez v2, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_0
    invoke-static {v2, v0, v1}, Lc/o1;->e(Landroid/os/IBinder;ILandroid/os/Binder;)Landroid/os/Parcel;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-virtual {v0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    invoke-static {v5}, Lc/o1;->a(Ljava/lang/String;)Lc/n1;

    move-result-object v0

    move-object v5, v0

    goto :goto_0

    :catchall_0
    move-exception v5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw v5
    :try_end_2
    .catch Landroid/os/RemoteException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-object v5, v1

    :goto_0
    iget-object v7, p0, Lc/o1;->c:Landroid/os/Handler;

    new-instance v8, Lc/m1;

    const/4 v6, 0x0

    move-object v0, v8

    move-object v1, p0

    invoke-direct/range {v0 .. v6}, Lc/m1;-><init>(Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;I)V

    invoke-virtual {v7, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final c()V
    .locals 5

    iget-wide v0, p0, Lc/o1;->h:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/o1;->h:J

    iget-boolean v0, p0, Lc/o1;->f:Z

    if-eqz v0, :cond_0

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/o1;->i:J

    :cond_0
    iget-object v0, p0, Lc/o1;->g:Landroid/os/IBinder;

    const/4 v1, 0x0

    iput-object v1, p0, Lc/o1;->g:Landroid/os/IBinder;

    iput-object v1, p0, Lc/o1;->j:Lc/n1;

    monitor-enter p0

    :try_start_0
    iget-object v2, p0, Lc/o1;->e:Landroid/os/Handler;

    iput-object v1, p0, Lc/o1;->e:Landroid/os/Handler;

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v3, p0, Lc/o1;->d:Landroid/os/HandlerThread;

    iput-object v1, p0, Lc/o1;->d:Landroid/os/HandlerThread;

    if-eqz v2, :cond_1

    invoke-virtual {v2, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    new-instance v1, Lc/Z;

    const/4 v4, 0x1

    invoke-direct {v1, p0, v0, v3, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    iget-boolean v0, p0, Lc/o1;->f:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/o1;->f:Z

    :try_start_1
    iget-object v0, p0, Lc/o1;->a:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_2
    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 2

    invoke-virtual {p0}, Lc/o1;->c()V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/o1;->i:J

    iget-object p1, p0, Lc/o1;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method

.method public final onNullBinding(Landroid/content/ComponentName;)V
    .locals 0

    invoke-virtual {p0}, Lc/o1;->c()V

    iget-object p1, p0, Lc/o1;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 7

    iget-boolean p1, p0, Lc/o1;->f:Z

    if-nez p1, :cond_0

    return-void

    :cond_0
    iput-object p2, p0, Lc/o1;->g:Landroid/os/IBinder;

    iget-wide v3, p0, Lc/o1;->h:J

    iget-object p1, p0, Lc/o1;->e:Landroid/os/Handler;

    new-instance v6, Lc/k1;

    const/4 v5, 0x0

    move-object v0, v6

    move-object v1, p0

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Lc/k1;-><init>(Ljava/lang/Object;Ljava/lang/Object;JI)V

    invoke-virtual {p1, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lc/o1;->g:Landroid/os/IBinder;

    iput-object p1, p0, Lc/o1;->j:Lc/n1;

    iget-object p1, p0, Lc/o1;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method
