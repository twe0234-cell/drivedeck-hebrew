.class public final synthetic Lc/F5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/O;Landroid/os/IBinder;I[Ljava/lang/String;[I)V
    .locals 1

    .line 1
    const/4 v0, 0x5

    iput v0, p0, Lc/F5;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/F5;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/F5;->d:Ljava/lang/Object;

    iput p3, p0, Lc/F5;->c:I

    iput-object p4, p0, Lc/F5;->e:Ljava/lang/Object;

    iput-object p5, p0, Lc/F5;->f:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/Z7;Ljava/lang/String;Ljava/lang/String;ILjava/util/function/Consumer;)V
    .locals 1

    .line 2
    const/4 v0, 0x2

    iput v0, p0, Lc/F5;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/F5;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/F5;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/F5;->e:Ljava/lang/Object;

    iput p4, p0, Lc/F5;->c:I

    iput-object p5, p0, Lc/F5;->f:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 3
    iput p6, p0, Lc/F5;->a:I

    iput-object p1, p0, Lc/F5;->b:Ljava/lang/Object;

    iput p2, p0, Lc/F5;->c:I

    iput-object p3, p0, Lc/F5;->d:Ljava/lang/Object;

    iput-object p4, p0, Lc/F5;->e:Ljava/lang/Object;

    iput-object p5, p0, Lc/F5;->f:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 4
    iput p6, p0, Lc/F5;->a:I

    iput-object p1, p0, Lc/F5;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/F5;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/F5;->e:Ljava/lang/Object;

    iput-object p4, p0, Lc/F5;->f:Ljava/lang/Object;

    iput p5, p0, Lc/F5;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 19

    move-object/from16 v1, p0

    iget v0, v1, Lc/F5;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v2, "; \u0432\u0442\u043e\u0440\u043e\u0439: "

    const-string v3, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u0438\u0437 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443. \u041f\u0435\u0440\u0432\u044b\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    iget-object v0, v1, Lc/F5;->e:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Lc/Z6;

    iget-object v0, v1, Lc/F5;->f:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Ljava/lang/String;

    iget v13, v1, Lc/F5;->c:I

    const-string v14, "Voice package download/install failed: "

    new-instance v15, Ljava/io/File;

    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Landroid/content/Context;

    invoke-virtual {v10}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, v1, Lc/F5;->d:Ljava/lang/Object;

    move-object v9, v5

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ".apk"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v15, v0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v0, 0x0

    move-object v4, v10

    move-object v5, v15

    move-object v6, v11

    move-object v7, v12

    move-object v8, v9

    move-object/from16 v16, v9

    move v9, v13

    move-object/from16 v17, v10

    move v10, v0

    :try_start_0
    invoke-static/range {v4 .. v10}, Lc/c9;->e(Landroid/content/Context;Ljava/io/File;Lc/Z6;Ljava/lang/String;Ljava/lang/String;II)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v0

    move-object v10, v0

    const/4 v0, 0x1

    move-object/from16 v4, v17

    move-object v5, v15

    move-object v6, v11

    move-object v7, v12

    move-object/from16 v8, v16

    move v9, v13

    move-object/from16 v18, v10

    move v10, v0

    :try_start_1
    invoke-static/range {v4 .. v10}, Lc/c9;->e(Landroid/content/Context;Ljava/io/File;Lc/Z6;Ljava/lang/String;Ljava/lang/String;II)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    move-object/from16 v5, v16

    move-object/from16 v2, v17

    goto :goto_3

    :catch_1
    move-exception v0

    move-object v4, v0

    :try_start_2
    new-instance v0, Ljava/io/IOException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v0, v5, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object/from16 v4, v18

    invoke-virtual {v0, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_1
    move-object v10, v0

    goto :goto_2

    :catch_2
    move-exception v0

    goto :goto_1

    :goto_2
    const/4 v0, 0x2

    move-object/from16 v4, v17

    move-object v5, v15

    move-object v6, v11

    move-object v7, v12

    move-object/from16 v8, v16

    move v9, v13

    move-object v12, v10

    move v10, v0

    :try_start_3
    invoke-static/range {v4 .. v10}, Lc/c9;->e(Landroid/content/Context;Ljava/io/File;Lc/Z6;Ljava/lang/String;Ljava/lang/String;II)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_5
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_0

    :goto_3
    :try_start_4
    invoke-static {v2, v15, v5}, Lc/c9;->f(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V

    new-instance v0, Lc/b1;

    const/4 v2, 0x4

    invoke-direct {v0, v2}, Lc/b1;-><init>(I)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v4, 0x1

    :try_start_5
    invoke-virtual {v11, v0, v4}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_0

    :goto_4
    invoke-virtual {v15}, Ljava/io/File;->delete()Z

    goto :goto_6

    :catchall_0
    move-exception v0

    goto :goto_7

    :catch_3
    move-exception v0

    goto :goto_5

    :catch_4
    move-exception v0

    const/4 v4, 0x1

    goto :goto_5

    :catch_5
    move-exception v0

    move-object/from16 v5, v16

    const/4 v4, 0x1

    move-object v6, v0

    :try_start_6
    new-instance v0, Ljava/io/IOException;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v0, v12}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_5
    :try_start_7
    const-string v2, "DriveDeck"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v2, Lc/W8;

    const/4 v3, 0x1

    invoke-direct {v2, v0, v3}, Lc/W8;-><init>(Ljava/lang/Exception;I)V

    invoke-virtual {v11, v2, v4}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_4

    :cond_0
    :goto_6
    return-void

    :goto_7
    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {v15}, Ljava/io/File;->delete()Z

    :cond_1
    throw v0

    :pswitch_0
    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    check-cast v0, Lc/O;

    iget-object v2, v1, Lc/F5;->d:Ljava/lang/Object;

    check-cast v2, Landroid/os/IBinder;

    iget v3, v1, Lc/F5;->c:I

    iget-object v4, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v4, [Ljava/lang/String;

    iget-object v5, v1, Lc/F5;->f:Ljava/lang/Object;

    check-cast v5, [I

    iget-object v6, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v6, Lc/Z7;

    iget-boolean v6, v6, Lc/Z7;->r:Z

    if-nez v6, :cond_1b

    iget-object v6, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v6, Lc/Z7;

    iget-object v6, v6, Lc/Z7;->k:Landroid/os/IBinder;

    if-ne v6, v2, :cond_1b

    if-nez v2, :cond_2

    goto/16 :goto_d

    :cond_2
    const/16 v2, 0x16

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-ne v3, v2, :cond_a

    iget-object v0, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v0, Lc/Z7;

    iget-boolean v2, v0, Lc/Z7;->q:Z

    if-eqz v2, :cond_1b

    iget-boolean v2, v0, Lc/Z7;->n:Z

    if-eqz v2, :cond_1b

    iget v2, v0, Lc/Z7;->w:I

    if-eq v2, v8, :cond_3

    goto/16 :goto_d

    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iput-wide v2, v0, Lc/Z7;->A:J

    if-eqz v4, :cond_9

    array-length v2, v4

    if-eq v2, v8, :cond_4

    goto :goto_a

    :cond_4
    aget-object v2, v4, v7

    invoke-static {v2}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aget-object v3, v4, v9

    invoke-static {v3}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_5

    aget-object v2, v4, v7

    aget-object v3, v4, v9

    invoke-static {v2, v3}, Lc/z7;->i(Ljava/lang/String;Ljava/lang/String;)Lc/Q;

    move-result-object v6

    goto :goto_8

    :cond_5
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_6

    aget-object v2, v4, v9

    aget-object v3, v4, v7

    invoke-static {v2, v3}, Lc/z7;->i(Ljava/lang/String;Ljava/lang/String;)Lc/Q;

    move-result-object v6

    :cond_6
    :goto_8
    if-eqz v6, :cond_8

    iget-object v2, v0, Lc/Z7;->x:Ljava/util/LinkedHashMap;

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    const/16 v3, 0x4e20

    if-lt v2, v3, :cond_7

    goto :goto_9

    :cond_7
    iget-object v0, v0, Lc/Z7;->x:Ljava/util/LinkedHashMap;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v6, Lc/Q;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xa

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v3, v6, Lc/Q;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2, v6}, Ljava/util/Map;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_d

    :cond_8
    :goto_9
    iput-boolean v9, v0, Lc/Z7;->y:Z

    goto/16 :goto_d

    :cond_9
    :goto_a
    iput-boolean v9, v0, Lc/Z7;->y:Z

    goto/16 :goto_d

    :cond_a
    const/4 v2, 0x7

    const-string v10, ""

    if-eqz v4, :cond_b

    array-length v11, v4

    if-le v11, v9, :cond_b

    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    const-string v4, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043e\u0434\u0438\u043d \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u0434\u043b\u044f \u0437\u0432\u043e\u043d\u043a\u043e\u0432"

    iput-object v4, v3, Lc/Z7;->K:Ljava/lang/String;

    iput-object v10, v3, Lc/Z7;->s:Ljava/lang/String;

    goto/16 :goto_c

    :cond_b
    if-eqz v4, :cond_c

    array-length v11, v4

    if-ne v11, v9, :cond_c

    aget-object v4, v4, v7

    if-eqz v4, :cond_c

    goto :goto_b

    :cond_c
    move-object v4, v10

    :goto_b
    const/4 v11, 0x6

    if-ne v3, v11, :cond_d

    iget-object v12, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v12, Lc/Z7;

    invoke-static {v4}, Lc/e8;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    iput-object v13, v12, Lc/Z7;->s:Ljava/lang/String;

    :cond_d
    if-ne v3, v2, :cond_e

    iget-object v12, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v12, Lc/Z7;

    iput-object v4, v12, Lc/Z7;->t:Ljava/lang/String;

    :cond_e
    const/16 v12, 0x8

    if-ne v3, v12, :cond_f

    iget-object v12, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v12, Lc/Z7;

    invoke-static {v4}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v12, Lc/Z7;->u:Ljava/lang/String;

    :cond_f
    const/16 v4, 0x9

    if-ne v3, v4, :cond_16

    if-eqz v5, :cond_16

    array-length v4, v5

    if-lez v4, :cond_16

    iget-object v4, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v4, Lc/Z7;

    iget v12, v4, Lc/Z7;->v:I

    aget v13, v5, v7

    iput v13, v4, Lc/Z7;->v:I

    iput-boolean v9, v4, Lc/Z7;->m:Z

    if-eq v13, v8, :cond_10

    if-ne v13, v2, :cond_11

    :cond_10
    iput-object v10, v4, Lc/Z7;->u:Ljava/lang/String;

    :cond_11
    if-lt v13, v8, :cond_12

    if-ne v13, v11, :cond_13

    :cond_12
    iput-object v10, v4, Lc/Z7;->u:Ljava/lang/String;

    iput-object v10, v4, Lc/Z7;->t:Ljava/lang/String;

    iput-object v10, v4, Lc/Z7;->s:Ljava/lang/String;

    :cond_13
    if-eq v12, v13, :cond_16

    const/4 v10, 0x4

    if-eq v13, v8, :cond_14

    if-eq v13, v10, :cond_14

    if-ne v13, v2, :cond_15

    :cond_14
    invoke-virtual {v4, v9, v6}, Lc/Z7;->s(ZLc/b;)V

    :cond_15
    if-ne v12, v10, :cond_16

    iget-object v4, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v4, Lc/Z7;

    iget v6, v4, Lc/Z7;->v:I

    if-eq v6, v10, :cond_16

    invoke-virtual {v4, v7}, Lc/Z7;->r(Z)V

    :cond_16
    const/16 v4, 0x1d

    if-ne v3, v4, :cond_18

    if-eqz v5, :cond_18

    array-length v3, v5

    if-lez v3, :cond_18

    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    aget v4, v5, v7

    iput v4, v3, Lc/Z7;->w:I

    iget-boolean v3, v3, Lc/Z7;->q:Z

    if-eqz v3, :cond_17

    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    iget v4, v3, Lc/Z7;->w:I

    if-ne v4, v8, :cond_17

    iput-boolean v9, v3, Lc/Z7;->n:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    iput-wide v4, v3, Lc/Z7;->A:J

    :cond_17
    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    iget-boolean v3, v3, Lc/Z7;->q:Z

    if-eqz v3, :cond_18

    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    iget-boolean v4, v3, Lc/Z7;->n:Z

    if-eqz v4, :cond_18

    iget v4, v3, Lc/Z7;->w:I

    if-ne v4, v9, :cond_18

    iget v3, v3, Lc/Z7;->B:I

    iget-object v4, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v4, Lc/Z7;

    iget-object v4, v4, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v5, Lc/w;

    const/16 v6, 0xa

    invoke-direct {v5, v0, v3, v6}, Lc/w;-><init>(Ljava/lang/Object;II)V

    const-wide/16 v6, 0x5dc

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_18
    :goto_c
    iget-object v3, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v3, Lc/Z7;

    iget v4, v3, Lc/Z7;->v:I

    if-lt v4, v8, :cond_19

    const/4 v5, 0x5

    if-le v4, v5, :cond_1a

    :cond_19
    if-eq v4, v2, :cond_1a

    iget-object v2, v3, Lc/Z7;->a:Lc/e8;

    iget-object v2, v2, Lc/e8;->d:Ljava/lang/String;

    const-string v3, "Android HFP"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1b

    :cond_1a
    iget-object v0, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v0, Lc/Z7;

    invoke-virtual {v0}, Lc/Z7;->m()V

    :cond_1b
    :goto_d
    return-void

    :pswitch_1
    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    iget v2, v1, Lc/F5;->c:I

    iget-object v3, v1, Lc/F5;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v4, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v4, Lc/j2;

    iget-object v5, v1, Lc/F5;->f:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    iget-boolean v6, v0, Lc/Z7;->r:Z

    if-nez v6, :cond_1c

    iget v6, v0, Lc/Z7;->B:I

    if-ne v2, v6, :cond_1c

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1c

    invoke-virtual {v4, v5}, Lc/j2;->accept(Ljava/lang/Object;)V

    :cond_1c
    return-void

    :pswitch_2
    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    iget v2, v1, Lc/F5;->c:I

    iget-object v3, v1, Lc/F5;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v4, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v4, Ljava/util/function/Consumer;

    iget-object v5, v1, Lc/F5;->f:Ljava/lang/Object;

    check-cast v5, Ljava/util/List;

    iget-boolean v6, v0, Lc/Z7;->r:Z

    if-nez v6, :cond_1d

    iget v6, v0, Lc/Z7;->B:I

    if-ne v2, v6, :cond_1d

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1d

    invoke-interface {v4, v5}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_1d
    return-void

    :pswitch_3
    iget-object v0, v1, Lc/F5;->d:Ljava/lang/Object;

    move-object v5, v0

    check-cast v5, Ljava/lang/String;

    iget-object v0, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v2, v1, Lc/F5;->b:Ljava/lang/Object;

    move-object v3, v2

    check-cast v3, Lc/Z7;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_8
    iget-object v2, v3, Lc/Z7;->e:Lc/z7;

    invoke-virtual {v2, v5, v0}, Lc/z7;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_8
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_6

    :goto_e
    move-object v7, v0

    goto :goto_f

    :catch_6
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_e

    :goto_f
    iget-object v0, v3, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v9, Lc/F5;

    iget-object v2, v1, Lc/F5;->f:Ljava/lang/Object;

    move-object v6, v2

    check-cast v6, Ljava/util/function/Consumer;

    iget v4, v1, Lc/F5;->c:I

    const/4 v8, 0x3

    move-object v2, v9

    invoke-direct/range {v2 .. v8}, Lc/F5;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v9}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_4
    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget v2, v1, Lc/F5;->c:I

    iget-object v3, v1, Lc/F5;->d:Ljava/lang/Object;

    check-cast v3, Ljava/io/OutputStream;

    iget-object v4, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v4, [B

    iget-object v5, v1, Lc/F5;->f:Ljava/lang/Object;

    check-cast v5, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_9
    iget v6, v0, Lc/T5;->t:I

    if-ne v2, v6, :cond_1e

    iget-object v2, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-ne v2, v3, :cond_1e

    invoke-virtual {v0, v4}, Lc/T5;->k0([B)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    goto :goto_10

    :catchall_1
    move-exception v0

    goto :goto_11

    :cond_1e
    :goto_10
    array-length v0, v4

    neg-int v0, v0

    invoke-virtual {v5, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    return-void

    :goto_11
    array-length v2, v4

    neg-int v2, v2

    invoke-virtual {v5, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    throw v0

    :pswitch_5
    iget-object v0, v1, Lc/F5;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lc/T5;

    iget-object v0, v1, Lc/F5;->d:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lc/P6;

    iget-object v0, v1, Lc/F5;->e:Ljava/lang/Object;

    check-cast v0, Landroid/hardware/usb/UsbDevice;

    iget-object v4, v1, Lc/F5;->f:Ljava/lang/Object;

    check-cast v4, Lc/u0;

    iget v5, v1, Lc/F5;->c:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_a
    iget-object v6, v2, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v7, "usb_baud"

    iget v4, v4, Lc/u0;->a:I

    invoke-interface {v6, v7, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-virtual {v3, v0, v4}, Lc/P6;->c(Landroid/hardware/usb/UsbDevice;I)V

    iget v0, v2, Lc/T5;->t:I

    if-ne v5, v0, :cond_20

    iget-object v0, v2, Lc/T5;->M:Lc/P6;

    if-eq v0, v3, :cond_1f

    goto :goto_12

    :cond_1f
    new-instance v0, Lc/O5;

    invoke-direct {v0, v3}, Lc/O5;-><init>(Lc/P6;)V

    new-instance v4, Lc/P5;

    invoke-direct {v4, v3}, Lc/P5;-><init>(Lc/P6;)V

    invoke-virtual {v2, v0, v4, v5}, Lc/T5;->K0(Ljava/io/InputStream;Ljava/io/OutputStream;I)V

    goto :goto_14

    :catch_7
    move-exception v0

    goto :goto_13

    :catch_8
    move-exception v0

    goto :goto_13

    :cond_20
    :goto_12
    invoke-virtual {v3}, Lc/P6;->close()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_8
    .catch Ljava/lang/SecurityException; {:try_start_a .. :try_end_a} :catch_7

    goto :goto_14

    :goto_13
    invoke-virtual {v3}, Lc/P6;->close()V

    iget-object v3, v2, Lc/T5;->c:Landroid/os/Handler;

    new-instance v4, Lc/G5;

    const/4 v6, 0x1

    invoke-direct {v4, v2, v5, v0, v6}, Lc/G5;-><init>(Lc/T5;ILjava/lang/Exception;I)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_14
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
