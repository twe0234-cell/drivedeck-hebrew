.class public final Lc/G7;
.super Landroid/widget/Button;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/O7;


# direct methods
.method public constructor <init>(Lc/O7;)V
    .locals 0

    iput-object p1, p0, Lc/G7;->a:Lc/O7;

    iget-object p1, p1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0, p1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 6

    invoke-virtual {p0}, Landroid/widget/TextView;->getCompoundDrawablesRelative()[Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v1, 0x0

    aget-object v0, v0, v1

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    int-to-float v1, v1

    const v2, 0x3ee147ae    # 0.44f

    mul-float/2addr v1, v2

    iget-object v2, p0, Lc/G7;->a:Lc/O7;

    iget-object v2, v2, Lc/O7;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v2}, Lc/e8;->d()Z

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    sub-float/2addr v3, v1

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const v5, 0x3dcccccd    # 0.1f

    mul-float/2addr v5, v1

    :goto_0
    sub-float/2addr v3, v5

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v5

    int-to-float v5, v5

    sub-float/2addr v5, v1

    div-float/2addr v5, v4

    if-eqz v2, :cond_2

    const v2, 0x3d23d70a    # 0.04f

    goto :goto_1

    :cond_2
    const v2, -0x43333333    # -0.025f

    :goto_1
    mul-float/2addr v2, v1

    add-float/2addr v2, v5

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v4

    add-int/2addr v4, v3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {v0, v3, v2, v4, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method
