.class public final synthetic Lc/t6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# instance fields
.field public final synthetic a:Lc/H6;

.field public final synthetic b:Lc/s6;


# direct methods
.method public synthetic constructor <init>(Lc/H6;Lc/s6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/t6;->a:Lc/H6;

    iput-object p2, p0, Lc/t6;->b:Lc/s6;

    return-void
.end method


# virtual methods
.method public final onFocusChange(Landroid/view/View;Z)V
    .locals 0

    iget-object p1, p0, Lc/t6;->a:Lc/H6;

    if-nez p2, :cond_0

    iget-object p1, p1, Lc/H6;->m0:Landroid/os/Handler;

    iget-object p2, p0, Lc/t6;->b:Lc/s6;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p2}, Lc/s6;->run()V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_0
    return-void
.end method
