.class public final synthetic Lc/w5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/z5;


# direct methods
.method public synthetic constructor <init>(Lc/z5;I)V
    .locals 0

    iput p2, p0, Lc/w5;->a:I

    iput-object p1, p0, Lc/w5;->b:Lc/z5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/w5;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/w5;->b:Lc/z5;

    iget-boolean v1, v0, Lc/z5;->d:Z

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/z5;->d:Z

    const-string v1, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043a\u0430\u0442\u0430\u043b\u043e\u0433\u0430\u2026"

    iput-object v1, v0, Lc/z5;->b:Ljava/lang/String;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, v0, Lc/z5;->i:Ljava/util/HashSet;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Runnable;

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_1
    new-instance v1, Lc/w5;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lc/w5;-><init>(Lc/z5;I)V

    iget-object v0, v0, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_1
    return-void

    :pswitch_0
    iget-object v3, p0, Lc/w5;->b:Lc/z5;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "version"

    const-string v1, "catalog.json"

    const-string v2, ""

    const/high16 v4, 0x400000

    const/4 v5, 0x0

    :try_start_0
    const-string v6, "https://storage.yandexcloud.net/drivedeck-updates-ru/obd/v2/catalog.json"

    invoke-static {v6, v4}, Lc/z5;->a(Ljava/lang/String;I)[B

    move-result-object v6

    invoke-static {v6}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v7

    invoke-static {v7}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v6

    :try_start_1
    invoke-static {v1}, Lc/z5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v4}, Lc/z5;->a(Ljava/lang/String;I)[B

    move-result-object v7

    invoke-static {v7}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v8

    invoke-static {v8}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move-object v6, v7

    :goto_2
    :try_start_2
    invoke-static {v6}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v7

    invoke-static {v7}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v1, v6}, Lc/z5;->f(Ljava/lang/String;[B)V

    const-string v0, "\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u043e\u0431\u043d\u043e\u0432\u043b\u0451\u043d"

    :goto_3
    move-object v4, v0

    move-object v6, v2

    goto :goto_4

    :catch_1
    move-exception v7

    invoke-virtual {v7, v6}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v7
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    invoke-virtual {v3, v1, v4}, Lc/z5;->e(Ljava/lang/String;I)[B

    move-result-object v1

    invoke-static {v1}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v1

    invoke-static {v1}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v0, "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u043a\u0430\u0442\u0430\u043b\u043e\u0433 \u00b7 \u0441\u0435\u0442\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_3

    :catch_3
    const-string v0, "\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d. \u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0443 \u043f\u043e\u0437\u0436\u0435"

    goto :goto_3

    :goto_4
    iget-object v0, v3, Lc/z5;->h:Landroid/os/Handler;

    new-instance v1, Lc/C2;

    const/4 v7, 0x6

    move-object v2, v1

    invoke-direct/range {v2 .. v7}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
