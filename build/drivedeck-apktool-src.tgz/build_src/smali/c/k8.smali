.class public final synthetic Lc/k8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/l8;


# direct methods
.method public synthetic constructor <init>(Lc/l8;I)V
    .locals 0

    iput p2, p0, Lc/k8;->a:I

    iput-object p1, p0, Lc/k8;->b:Lc/l8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget v0, p0, Lc/k8;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/k8;->b:Lc/l8;

    invoke-virtual {v0}, Lc/l8;->a()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/k8;->b:Lc/l8;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lc/m8;->b:Lc/n1;

    monitor-enter v0

    :try_start_0
    iget-object v2, v0, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    if-eqz v2, :cond_0

    iget-object v1, v0, Lc/l8;->c:Lc/n1;

    goto :goto_0

    :catchall_0
    move-exception v1

    goto/16 :goto_e

    :cond_0
    :goto_0
    const/4 v3, 0x0

    iput-object v3, v0, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    iput-object v3, v0, Lc/l8;->c:Lc/n1;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    iget-boolean v4, v0, Lc/l8;->f:Z

    if-nez v4, :cond_10

    if-eqz v1, :cond_10

    sget-object v4, Lc/m8;->b:Lc/n1;

    if-eq v1, v4, :cond_1

    goto/16 :goto_9

    :cond_1
    iget-object v4, v0, Lc/l8;->d:Lc/n1;

    if-eq v4, v1, :cond_2

    invoke-virtual {v0}, Lc/l8;->a()V

    goto :goto_1

    :catchall_1
    move-exception v0

    move-object v4, v3

    goto/16 :goto_d

    :catch_0
    move-object v4, v3

    move-object v5, v4

    goto/16 :goto_a

    :cond_2
    :goto_1
    if-eqz v2, :cond_7

    invoke-virtual {v0}, Lc/l8;->a()V

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v4

    iput-object v4, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    iput-object v1, v0, Lc/l8;->d:Lc/n1;

    const/4 v4, 0x0

    :goto_2
    iget-object v5, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v5, :cond_7

    const/16 v6, 0x40

    if-ge v4, v6, :cond_7

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getParent()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v5

    if-nez v5, :cond_3

    goto :goto_5

    :cond_3
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getWindowId()I

    move-result v6

    iget-object v7, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->getWindowId()I

    move-result v7

    if-ne v6, v7, :cond_6

    iget-object v6, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v7

    if-nez v7, :cond_4

    const-string v7, ""

    goto :goto_3

    :cond_4
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v7

    :goto_3
    invoke-virtual {v6, v7}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_5

    goto :goto_4

    :cond_5
    iget-object v6, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    iput-object v5, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_6
    :goto_4
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_7
    :goto_5
    iget-object v4, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v4, :cond_c

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->refresh()Z

    move-result v4

    if-eqz v4, :cond_c

    iget-object v4, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->findFocus(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v4
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz v4, :cond_b

    :try_start_2
    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z

    move-result v5

    if-eqz v5, :cond_b

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v5

    if-eqz v5, :cond_b

    iget-object v5, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v6

    if-nez v6, :cond_8

    const-string v6, ""

    goto :goto_6

    :catchall_2
    move-exception v0

    goto/16 :goto_d

    :catch_1
    move-object v5, v3

    goto/16 :goto_a

    :cond_8
    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v6

    :goto_6
    invoke-virtual {v5, v6}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_b

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->getWindow()Landroid/view/accessibility/AccessibilityWindowInfo;

    move-result-object v5
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1e

    if-lt v6, v7, :cond_9

    if-eqz v5, :cond_a

    invoke-static {v5}, Lc/B1;->c(Landroid/view/accessibility/AccessibilityWindowInfo;)I

    move-result v6

    iget v7, v1, Lc/n1;->a:I

    if-ne v6, v7, :cond_a

    goto :goto_7

    :catchall_3
    move-exception v0

    move-object v3, v5

    goto/16 :goto_d

    :cond_9
    invoke-static {}, Lc/j8;->o()I

    move-result v6

    iget v7, v1, Lc/n1;->a:I

    if-ne v6, v7, :cond_a

    :goto_7
    new-instance v6, Landroid/graphics/Rect;

    invoke-direct {v6}, Landroid/graphics/Rect;-><init>()V

    new-instance v7, Landroid/graphics/Rect;

    invoke-direct {v7}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v4, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    iget-object v8, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v8, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v6}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_a

    invoke-virtual {v7}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_a

    new-instance v8, Lc/r5;

    invoke-direct {v8, v6, v7}, Lc/r5;-><init>(Landroid/graphics/Rect;Landroid/graphics/Rect;)V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    move-object v3, v8

    :cond_a
    move-object v9, v5

    move-object v5, v3

    move-object v3, v9

    goto :goto_8

    :cond_b
    move-object v5, v3

    goto :goto_8

    :cond_c
    :try_start_4
    invoke-virtual {v0}, Lc/l8;->a()V
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    move-object v4, v3

    move-object v5, v4

    :goto_8
    if-eqz v3, :cond_d

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    :cond_d
    if-eqz v4, :cond_e

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_e
    if-eqz v2, :cond_f

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    :cond_f
    move-object v3, v5

    goto :goto_b

    :cond_10
    :goto_9
    :try_start_5
    invoke-virtual {v0}, Lc/l8;->a()V
    :try_end_5
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    if-eqz v2, :cond_14

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    goto :goto_c

    :catch_2
    :goto_a
    :try_start_6
    invoke-virtual {v0}, Lc/l8;->a()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    if-eqz v5, :cond_11

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    :cond_11
    if-eqz v4, :cond_12

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_12
    if-eqz v2, :cond_13

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    :cond_13
    :goto_b
    sget-object v2, Lc/m8;->a:Landroid/os/Handler;

    new-instance v4, Lc/F7;

    const/4 v5, 0x2

    invoke-direct {v4, v1, v3, v5}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-boolean v2, v0, Lc/l8;->f:Z

    if-nez v2, :cond_14

    iget-object v2, v0, Lc/l8;->e:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v2, :cond_14

    sget-object v2, Lc/m8;->b:Lc/n1;

    if-ne v1, v2, :cond_14

    iget-object v1, v0, Lc/l8;->a:Landroid/os/Handler;

    iget-object v0, v0, Lc/l8;->g:Lc/k8;

    const-wide/16 v2, 0xc8

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_14
    :goto_c
    return-void

    :goto_d
    if-eqz v3, :cond_15

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    :cond_15
    if-eqz v4, :cond_16

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_16
    if-eqz v2, :cond_17

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    :cond_17
    throw v0

    :goto_e
    :try_start_7
    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    throw v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
