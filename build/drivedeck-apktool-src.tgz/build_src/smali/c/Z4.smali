.class public final Lc/Z4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic a:Lc/a5;


# direct methods
.method public constructor <init>(Lc/a5;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Z4;->a:Lc/a5;

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 3

    iget-object v0, p0, Lc/Z4;->a:Lc/a5;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    iget v1, v0, Lc/a5;->i:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lc/a5;->b(IZ)V

    const/4 v0, 0x1

    return v0
.end method
