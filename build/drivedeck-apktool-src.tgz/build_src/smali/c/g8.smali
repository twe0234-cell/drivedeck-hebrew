.class public final Lc/g8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# static fields
.field public static final j:[I


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lc/F3;

.field public final c:Landroid/os/Handler;

.field public d:Z

.field public e:Landroid/os/IBinder;

.field public f:I

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public final i:Lc/O;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/16 v0, 0xd

    const/16 v1, 0xe

    const/4 v2, 0x0

    const/4 v3, 0x1

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lc/g8;->j:[I

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/F3;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/g8;->c:Landroid/os/Handler;

    const/4 v0, -0x1

    iput v0, p0, Lc/g8;->f:I

    const-string v0, ""

    iput-object v0, p0, Lc/g8;->g:Ljava/lang/String;

    iput-object v0, p0, Lc/g8;->h:Ljava/lang/String;

    new-instance v0, Lc/O;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lc/O;-><init>(Landroid/content/ServiceConnection;I)V

    iput-object v0, p0, Lc/g8;->i:Lc/O;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/g8;->a:Landroid/content/Context;

    iput-object p2, p0, Lc/g8;->b:Lc/F3;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .locals 3

    iget v0, p0, Lc/g8;->f:I

    const/16 v1, 0x1388

    if-le v0, v1, :cond_0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    int-to-float v0, v0

    const/high16 v2, 0x42c80000    # 100.0f

    div-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v2, "%.2f \u041c\u0413\u0446"

    invoke-static {v1, v2, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    if-lez v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lc/g8;->f:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " \u043a\u0413\u0446"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const-string v0, ""

    :goto_0
    return-object v0
.end method

.method public final b()V
    .locals 5

    iget-boolean v0, p0, Lc/g8;->d:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    iget-object v0, p0, Lc/g8;->a:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "com.syu.ms.radio"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v2, Landroid/content/ComponentName;

    const-string v3, "com.syu.ms"

    const-string v4, "app.ModuleService"

    invoke-direct {v2, v3, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p0, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/g8;->d:Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public final c()V
    .locals 4

    iget-boolean v0, p0, Lc/g8;->d:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Lc/g8;->j:[I

    const/4 v1, 0x0

    move v2, v1

    :goto_0
    const/4 v3, 0x4

    if-ge v2, v3, :cond_1

    aget v3, v0, v2

    invoke-virtual {p0, v3, v1}, Lc/g8;->d(IZ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iput-boolean v1, p0, Lc/g8;->d:Z

    :try_start_0
    iget-object v0, p0, Lc/g8;->a:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v0, 0x0

    iput-object v0, p0, Lc/g8;->e:Landroid/os/IBinder;

    iget-object v1, p0, Lc/g8;->c:Landroid/os/Handler;

    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const-string v0, ""

    iput-object v0, p0, Lc/g8;->h:Ljava/lang/String;

    iput-object v0, p0, Lc/g8;->g:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p0, Lc/g8;->f:I

    return-void
.end method

.method public final d(IZ)V
    .locals 3

    iget-object v0, p0, Lc/g8;->e:Landroid/os/IBinder;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const-string v1, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    iget-object v1, p0, Lc/g8;->i:Lc/O;

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    if-eqz p2, :cond_3

    const/16 v2, 0xd

    if-eq p1, v2, :cond_2

    const/16 v2, 0xe

    if-ne p1, v2, :cond_1

    goto :goto_0

    :cond_1
    move p1, v1

    goto :goto_1

    :cond_2
    :goto_0
    const/4 p1, 0x0

    :goto_1
    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_2

    :catchall_0
    move-exception p1

    goto :goto_4

    :cond_3
    :goto_2
    iget-object p1, p0, Lc/g8;->e:Landroid/os/IBinder;

    if-eqz p2, :cond_4

    const/4 p2, 0x3

    goto :goto_3

    :cond_4
    const/4 p2, 0x4

    :goto_3
    const/4 v2, 0x0

    invoke-interface {p1, p2, v0, v2, v1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_5

    :goto_4
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1

    :goto_5
    return-void
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 0

    iget-boolean p1, p0, Lc/g8;->d:Z

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Lc/g8;->c()V

    invoke-virtual {p0}, Lc/g8;->b()V

    :cond_0
    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2

    iget-boolean p1, p0, Lc/g8;->d:Z

    if-nez p1, :cond_0

    return-void

    :cond_0
    iput-object p2, p0, Lc/g8;->e:Landroid/os/IBinder;

    sget-object p1, Lc/g8;->j:[I

    const/4 p2, 0x0

    :goto_0
    const/4 v0, 0x4

    if-ge p2, v0, :cond_1

    aget v0, p1, p2

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lc/g8;->d(IZ)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lc/g8;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lc/g8;->e:Landroid/os/IBinder;

    const-string p1, ""

    iput-object p1, p0, Lc/g8;->h:Ljava/lang/String;

    iput-object p1, p0, Lc/g8;->g:Ljava/lang/String;

    const/4 p1, -0x1

    iput p1, p0, Lc/g8;->f:I

    iget-object p1, p0, Lc/g8;->b:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method
