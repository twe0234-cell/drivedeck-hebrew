.class public final Lc/M;
.super Landroid/media/session/MediaController$Callback;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/M;->a:I

    iput-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/media/session/MediaController$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onMetadataChanged(Landroid/media/MediaMetadata;)V
    .locals 0

    iget p1, p0, Lc/M;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/m5;

    invoke-virtual {p1}, Lc/m5;->b()V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/P3;

    invoke-virtual {p1}, Lc/P3;->N()V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/P;

    invoke-virtual {p1}, Lc/P;->f()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onPlaybackStateChanged(Landroid/media/session/PlaybackState;)V
    .locals 0

    iget p1, p0, Lc/M;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/m5;

    invoke-virtual {p1}, Lc/m5;->b()V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/P3;

    invoke-virtual {p1}, Lc/P3;->N()V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast p1, Lc/P;

    invoke-virtual {p1}, Lc/P;->f()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onSessionDestroyed()V
    .locals 2

    iget v0, p0, Lc/M;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast v0, Lc/m5;

    invoke-virtual {v0}, Lc/m5;->a()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-boolean v1, v0, Lc/P3;->U1:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/P3;->X()V

    invoke-virtual {v0}, Lc/P3;->N()V

    :cond_0
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/M;->b:Ljava/lang/Object;

    check-cast v0, Lc/P;

    invoke-virtual {v0}, Lc/P;->b()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
