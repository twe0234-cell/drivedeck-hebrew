.class public final synthetic Lc/j4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/LauncherAccessibilityService;

.field public final synthetic c:J

.field public final synthetic d:Lc/z;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Ljava/util/ArrayList;

.field public final synthetic g:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLc/z;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/j4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/j4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iput-wide p2, p0, Lc/j4;->c:J

    iput-object p4, p0, Lc/j4;->d:Lc/z;

    iput-object p5, p0, Lc/j4;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/j4;->g:Ljava/lang/String;

    iput-object p7, p0, Lc/j4;->f:Ljava/util/ArrayList;

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLc/z;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/j4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/j4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iput-wide p2, p0, Lc/j4;->c:J

    iput-object p4, p0, Lc/j4;->d:Lc/z;

    iput-object p5, p0, Lc/j4;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/j4;->f:Ljava/util/ArrayList;

    iput-object p7, p0, Lc/j4;->g:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 13

    const/4 v0, 0x0

    const-string v1, "\u041f\u0435\u0440\u0432\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e"

    iget v2, p0, Lc/j4;->a:I

    packed-switch v2, :pswitch_data_0

    sget-object v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    iget-object v4, p0, Lc/j4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-wide v5, p0, Lc/j4;->c:J

    invoke-virtual {v4, v5, v6}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, p0, Lc/j4;->d:Lc/z;

    iget-object v8, p0, Lc/j4;->e:Ljava/lang/String;

    invoke-virtual {v2, v8}, Lc/z;->h(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_0

    :cond_1
    iget-object v0, v4, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v1, Lc/k4;

    iget-object v7, p0, Lc/j4;->f:Ljava/util/ArrayList;

    iget-object v9, p0, Lc/j4;->g:Ljava/lang/String;

    const/4 v10, 0x0

    move-object v3, v1

    invoke-direct/range {v3 .. v10}, Lc/k4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLjava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;I)V

    const-wide/16 v2, 0x352

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_0
    return-void

    :pswitch_0
    sget-object v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    iget-object v4, p0, Lc/j4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-wide v5, p0, Lc/j4;->c:J

    invoke-virtual {v4, v5, v6}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_1

    :cond_2
    const/4 v2, 0x7

    invoke-virtual {v4, v2}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    move-result v2

    iget-object v11, v4, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    iget-object v7, p0, Lc/j4;->d:Lc/z;

    iget-object v8, p0, Lc/j4;->e:Ljava/lang/String;

    iget-object v10, p0, Lc/j4;->g:Ljava/lang/String;

    iget-object v9, p0, Lc/j4;->f:Ljava/util/ArrayList;

    if-nez v2, :cond_5

    :try_start_0
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const-string v12, "com.fyt.screenbutton"

    invoke-virtual {v3, v12, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v4, v5, v6}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v2

    if-nez v2, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v7, v8}, Lc/z;->h(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_4

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    :cond_4
    new-instance v0, Lc/l4;

    move-object v3, v0

    move-object v7, v9

    move-object v9, v10

    invoke-direct/range {v3 .. v9}, Lc/l4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLjava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v1, 0x44c

    invoke-virtual {v11, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    :catch_0
    :cond_5
    if-nez v2, :cond_6

    const-string v0, "\u041f\u0440\u043e\u0448\u0438\u0432\u043a\u0430 \u043d\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0438\u043b\u0430 \u0440\u0430\u0437\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u044d\u043a\u0440\u0430\u043d\u0430"

    invoke-static {v4, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v4, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    :cond_6
    new-instance v0, Lc/j4;

    move-object v3, v0

    invoke-direct/range {v3 .. v10}, Lc/j4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLc/z;Ljava/lang/String;Ljava/util/ArrayList;Ljava/lang/String;)V

    const-wide/16 v1, 0x41a

    invoke-virtual {v11, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
