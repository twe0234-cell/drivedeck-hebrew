.class public final synthetic Lc/C4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/C4;->a:Lru/drivedeck/launcher/MainActivity;

    iput p2, p0, Lc/C4;->b:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 0

    sget p1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object p1, p0, Lc/C4;->a:Lru/drivedeck/launcher/MainActivity;

    iget p2, p0, Lc/C4;->b:I

    invoke-virtual {p1, p2}, Lru/drivedeck/launcher/MainActivity;->Q(I)V

    return-void
.end method
