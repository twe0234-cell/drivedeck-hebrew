.class public final synthetic Lc/M0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Dialog;Lru/drivedeck/launcher/MainActivity;Landroid/view/View;Landroid/view/Window;II)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/M0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/M0;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/M0;->e:Ljava/lang/Object;

    iput-object p3, p0, Lc/M0;->f:Ljava/lang/Object;

    iput-object p4, p0, Lc/M0;->g:Ljava/lang/Object;

    iput p5, p0, Lc/M0;->b:I

    iput p6, p0, Lc/M0;->c:I

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/io/Serializable;ILjava/io/Serializable;ILjava/lang/Object;I)V
    .locals 0

    .line 2
    iput p7, p0, Lc/M0;->a:I

    iput-object p1, p0, Lc/M0;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/M0;->e:Ljava/lang/Object;

    iput p3, p0, Lc/M0;->b:I

    iput-object p4, p0, Lc/M0;->f:Ljava/lang/Object;

    iput p5, p0, Lc/M0;->c:I

    iput-object p6, p0, Lc/M0;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/M0;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/M0;->e:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Ljava/lang/String;

    iget v0, p0, Lc/M0;->b:I

    iget-object v1, p0, Lc/M0;->f:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Lc/M0;->d:Ljava/lang/Object;

    check-cast v2, Lc/Z7;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v3, v2, Lc/Z7;->e:Lc/z7;

    invoke-virtual {v3, v0, v4, v1}, Lc/z7;->h(ILjava/lang/String;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    move-object v6, v0

    goto :goto_1

    :catch_0
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :goto_1
    iget-object v0, v2, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v8, Lc/F5;

    iget-object v1, p0, Lc/M0;->g:Ljava/lang/Object;

    move-object v5, v1

    check-cast v5, Lc/j2;

    iget v3, p0, Lc/M0;->c:I

    const/4 v7, 0x4

    move-object v1, v8

    invoke-direct/range {v1 .. v7}, Lc/F5;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/M0;->d:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/M0;->e:Ljava/lang/Object;

    check-cast v1, [I

    const/4 v2, 0x0

    aget v3, v1, v2

    iget-object v4, p0, Lc/M0;->f:Ljava/lang/Object;

    check-cast v4, [I

    iget v5, p0, Lc/M0;->b:I

    iget v6, p0, Lc/M0;->c:I

    const/4 v7, 0x2

    if-nez v3, :cond_1

    if-lez v5, :cond_0

    move v3, v7

    goto :goto_2

    :cond_0
    aget v3, v4, v6

    goto :goto_2

    :cond_1
    add-int/2addr v3, v5

    :goto_2
    if-ge v3, v7, :cond_2

    move v3, v2

    :cond_2
    aget v4, v4, v6

    if-le v3, v4, :cond_3

    goto :goto_6

    :cond_3
    aput v3, v1, v2

    if-nez v3, :cond_4

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v4, "\u0410\u0432\u0442\u043e"

    invoke-static {v1, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_3

    :cond_4
    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    :goto_3
    iget-object v4, p0, Lc/M0;->g:Ljava/lang/Object;

    check-cast v4, Landroid/widget/TextView;

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, v0, Lc/k3;->c:Lc/n1;

    if-nez v6, :cond_6

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    if-nez v3, :cond_5

    goto :goto_4

    :cond_5
    const/16 v1, 0xa

    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v2

    :goto_4
    const-string v1, "all_apps_columns"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_6

    :cond_6
    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    if-nez v3, :cond_7

    goto :goto_5

    :cond_7
    const/16 v1, 0x8

    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v2

    :goto_5
    const-string v1, "all_apps_rows"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_6
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/M0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/app/Dialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V

    const-string v1, "\u0414\u0430\u043d\u043d\u044b\u0435 OBD"

    iget-object v2, p0, Lc/M0;->e:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setTitle(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lc/M0;->f:Ljava/lang/Object;

    check-cast v1, Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    iget-object v0, p0, Lc/M0;->g:Ljava/lang/Object;

    check-cast v0, Landroid/view/Window;

    iget v1, p0, Lc/M0;->b:I

    iget v2, p0, Lc/M0;->c:I

    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setLayout(II)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
