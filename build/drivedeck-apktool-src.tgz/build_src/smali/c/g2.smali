.class public final Lc/g2;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# virtual methods
.method public final a(I)I
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    int-to-float p1, p1

    invoke-static {v0, p1}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    return p1
.end method
