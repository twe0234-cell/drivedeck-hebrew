.class public final synthetic Lc/P0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/P0;->a:I

    iput-object p1, p0, Lc/P0;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget p1, p0, Lc/P0;->a:I

    packed-switch p1, :pswitch_data_0

    new-instance p1, Landroid/content/Intent;

    iget-object v0, p0, Lc/P0;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "https://yandex.ru/pogoda/ru"

    goto :goto_0

    :cond_0
    const-string v1, "https://open-meteo.com/"

    :goto_0
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.intent.action.VIEW"

    invoke-direct {p1, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/P0;->b:Lru/drivedeck/launcher/MainActivity;

    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.ACCESSIBILITY_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string v0, "\u042d\u0442\u043e\u0442 \u0440\u0430\u0437\u0434\u0435\u043b \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0432 \u043f\u0440\u043e\u0448\u0438\u0432\u043a\u0435"

    const/4 v1, 0x0

    invoke-static {p1, v0, p1, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
