.class public final Lc/B0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 12

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/B0;->a:Ljava/lang/Object;

    .line 8
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/B0;->b:Ljava/lang/Object;

    .line 9
    new-instance v1, Landroid/graphics/RectF;

    const/high16 v2, 0x42b40000    # 90.0f

    const/high16 v3, 0x43d30000    # 422.0f

    invoke-direct {v1, v2, v2, v3, v3}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object v1, p0, Lc/B0;->c:Ljava/lang/Object;

    .line 10
    new-instance v1, Landroid/graphics/LinearGradient;

    const/4 v2, 0x6

    new-array v9, v2, [I

    fill-array-data v9, :array_0

    new-array v10, v2, [F

    fill-array-data v10, :array_1

    sget-object v11, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v7, 0x0

    const/high16 v8, 0x43190000    # 153.0f

    const/4 v5, 0x0

    const v6, 0x43bb8000    # 375.0f

    move-object v4, v1

    invoke-direct/range {v4 .. v11}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    iput-object v1, p0, Lc/B0;->d:Ljava/lang/Object;

    const/high16 v1, 0x43480000    # 200.0f

    const/high16 v2, 0x43340000    # 180.0f

    .line 11
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->moveTo(FF)V

    const v1, 0x43af8000    # 351.0f

    const/high16 v2, 0x43190000    # 153.0f

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x43980000    # 304.0f

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const v5, 0x43a58000    # 331.0f

    const/high16 v6, 0x43ab0000    # 342.0f

    const v3, 0x43af8000    # 351.0f

    const v4, 0x43a28000    # 325.0f

    const/high16 v7, 0x43990000    # 306.0f

    const/high16 v8, 0x43ab0000    # 342.0f

    move-object v2, v0

    .line 12
    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v5, 0x43830000    # 262.0f

    const/high16 v6, 0x43a40000    # 328.0f

    const v3, 0x438c8000    # 281.0f

    const/high16 v4, 0x43ab0000    # 342.0f

    const/high16 v7, 0x43830000    # 262.0f

    const v8, 0x439a8000    # 309.0f

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v5, 0x438d0000    # 282.0f

    const v6, 0x43898000    # 275.0f

    const/high16 v3, 0x43830000    # 262.0f

    const/high16 v4, 0x43910000    # 290.0f

    const/high16 v7, 0x43990000    # 306.0f

    const v8, 0x43898000    # 275.0f

    .line 13
    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const v5, 0x43a38000    # 327.0f

    const/high16 v6, 0x438b0000    # 278.0f

    const v3, 0x439e8000    # 317.0f

    const v4, 0x43898000    # 275.0f

    const/high16 v7, 0x43a70000    # 334.0f

    const/high16 v8, 0x438d0000    # 282.0f

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v1, 0x43a70000    # 334.0f

    const/high16 v2, 0x43560000    # 214.0f

    .line 14
    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v1, 0x43590000    # 217.0f

    const/high16 v2, 0x436b0000    # 235.0f

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const v2, 0x43a88000    # 337.0f

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v5, 0x43450000    # 197.0f

    const v6, 0x43bb8000    # 375.0f

    const/high16 v3, 0x43590000    # 217.0f

    const/high16 v4, 0x43b30000    # 358.0f

    const/high16 v7, 0x432c0000    # 172.0f

    const v8, 0x43bb8000    # 375.0f

    move-object v2, v0

    .line 15
    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v5, 0x43000000    # 128.0f

    const v6, 0x43b48000    # 361.0f

    const/high16 v3, 0x43130000    # 147.0f

    const v4, 0x43bb8000    # 375.0f

    const/high16 v7, 0x43000000    # 128.0f

    const/high16 v8, 0x43ab0000    # 342.0f

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v5, 0x43140000    # 148.0f

    const/high16 v6, 0x439a0000    # 308.0f

    const/high16 v3, 0x43000000    # 128.0f

    const v4, 0x43a18000    # 323.0f

    const/high16 v7, 0x432c0000    # 172.0f

    const/high16 v8, 0x439a0000    # 308.0f

    .line 16
    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v5, 0x43410000    # 193.0f

    const v6, 0x439b8000    # 311.0f

    const/high16 v3, 0x43370000    # 183.0f

    const/high16 v4, 0x439a0000    # 308.0f

    const/high16 v7, 0x43480000    # 200.0f

    const v8, 0x439d8000    # 315.0f

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    invoke-virtual {v0}, Landroid/graphics/Path;->close()V

    return-void

    :array_0
    .array-data 4
        -0xfcd690
        -0xf8cf88
        -0xeab971
        -0xd4954b
        -0xb66417
        -0xb25e10
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x3e0f5c29    # 0.14f
        0x3eb851ec    # 0.36f
        0x3f23d70a    # 0.64f
        0x3f7851ec    # 0.97f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public constructor <init>(Lc/T5;Landroid/widget/TextView;[B)V
    .locals 0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/B0;->c:Ljava/lang/Object;

    invoke-virtual {p1}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/B0;->a:Ljava/lang/Object;

    iput-object p2, p0, Lc/B0;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/B0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/B0;->a:Ljava/lang/Object;

    .line 3
    new-instance v0, Landroid/text/TextPaint;

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v0, p0, Lc/B0;->d:Ljava/lang/Object;

    .line 4
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/B0;->b:Ljava/lang/Object;

    .line 5
    iput-object p1, p0, Lc/B0;->c:Ljava/lang/Object;

    return-void
.end method

.method public static c(I)Ljava/lang/String;
    .locals 0

    invoke-static {p0}, Lc/t;->g(I)I

    move-result p0

    packed-switch p0, :pswitch_data_0

    const-string p0, ""

    return-object p0

    :pswitch_0
    const-string p0, "\u0424\u0438\u043d\u0438\u0448"

    return-object p0

    :pswitch_1
    const-string p0, "\u041a\u043e\u043b\u044c\u0446\u043e"

    return-object p0

    :pswitch_2
    const-string p0, "\u041f\u0440\u044f\u043c\u043e"

    return-object p0

    :pswitch_3
    const-string p0, "\u0420\u0430\u0437\u0432\u043e\u0440\u043e\u0442"

    return-object p0

    :pswitch_4
    const-string p0, "\u0421\u044a\u0435\u0437\u0434"

    return-object p0

    :pswitch_5
    const-string p0, "\u0420\u0435\u0437\u043a\u043e \u043d\u0430\u043f\u0440\u0430\u0432\u043e"

    return-object p0

    :pswitch_6
    const-string p0, "\u0420\u0435\u0437\u043a\u043e \u043d\u0430\u043b\u0435\u0432\u043e"

    return-object p0

    :pswitch_7
    const-string p0, "\u041f\u0440\u0430\u0432\u0435\u0435"

    return-object p0

    :pswitch_8
    const-string p0, "\u041b\u0435\u0432\u0435\u0435"

    return-object p0

    :pswitch_9
    const-string p0, "\u041d\u0430\u043f\u0440\u0430\u0432\u043e"

    return-object p0

    :pswitch_a
    const-string p0, "\u041d\u0430\u043b\u0435\u0432\u043e"

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_8
        :pswitch_7
        :pswitch_4
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;IFFFI)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v3

    move/from16 v4, p3

    move/from16 v5, p4

    invoke-virtual {v1, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 v4, 0x42c80000    # 100.0f

    div-float v5, p5, v4

    invoke-virtual {v1, v5, v5}, Landroid/graphics/Canvas;->scale(FF)V

    iget-object v5, v0, Lc/B0;->a:Ljava/lang/Object;

    check-cast v5, Landroid/graphics/Paint;

    invoke-static/range {p6 .. p6}, Lc/q9;->a(I)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v7, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    sget-object v7, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    iget-object v7, v0, Lc/B0;->b:Ljava/lang/Object;

    check-cast v7, Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->rewind()V

    invoke-static/range {p2 .. p2}, Lc/t;->g(I)I

    move-result v8

    const/high16 v9, 0x3f800000    # 1.0f

    const/16 v10, 0xb

    const/16 v11, 0x9

    const/4 v12, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x3

    const/high16 v15, -0x40800000    # -1.0f

    const/4 v6, 0x0

    if-eq v8, v14, :cond_0

    if-eq v8, v13, :cond_0

    if-eq v8, v12, :cond_0

    if-eq v8, v11, :cond_0

    if-eq v8, v10, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v1, v4, v6}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {v1, v15, v9}, Landroid/graphics/Canvas;->scale(FF)V

    :goto_0
    const/high16 v8, 0x42b40000    # 90.0f

    if-eq v2, v14, :cond_1

    const/4 v14, 0x4

    if-ne v2, v14, :cond_2

    :cond_1
    const/high16 v2, 0x42880000    # 68.0f

    goto/16 :goto_6

    :cond_2
    const/high16 v6, 0x42840000    # 66.0f

    if-eq v2, v13, :cond_3

    const/4 v13, 0x6

    if-ne v2, v13, :cond_4

    :cond_3
    const/high16 v2, 0x42780000    # 62.0f

    const/high16 v4, 0x41900000    # 18.0f

    const/high16 v9, 0x41a00000    # 20.0f

    const/high16 v10, 0x41880000    # 17.0f

    const/high16 v11, 0x42380000    # 46.0f

    const/high16 v12, 0x42940000    # 74.0f

    goto/16 :goto_5

    :cond_4
    const/high16 v14, 0x42a00000    # 80.0f

    const/high16 v13, 0x42480000    # 50.0f

    if-eq v2, v12, :cond_5

    const/16 v12, 0x8

    if-ne v2, v12, :cond_6

    :cond_5
    const/16 v2, 0x50

    goto/16 :goto_4

    :cond_6
    const/high16 v4, 0x42180000    # 38.0f

    const/high16 v12, 0x42860000    # 67.0f

    const/high16 v9, 0x41400000    # 12.0f

    if-eq v2, v11, :cond_7

    const/16 v11, 0xa

    if-ne v2, v11, :cond_8

    :cond_7
    const/16 v2, 0x50

    goto/16 :goto_3

    :cond_8
    const/16 v11, 0xf

    const/high16 v15, 0x41c00000    # 24.0f

    if-ne v2, v11, :cond_9

    invoke-virtual {v7, v15, v8}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v15, v9}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v14, v9}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x41f80000    # 31.0f

    invoke-virtual {v7, v12, v2}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v14, v13}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v15, v13}, Landroid/graphics/Path;->lineTo(FF)V

    goto/16 :goto_7

    :cond_9
    const/4 v11, 0x1

    const/high16 v12, 0x42b00000    # 88.0f

    const/4 v14, 0x2

    if-eq v2, v11, :cond_e

    if-ne v2, v14, :cond_a

    goto/16 :goto_2

    :cond_a
    if-eq v2, v10, :cond_d

    const/16 v9, 0xc

    if-ne v2, v9, :cond_b

    goto :goto_1

    :cond_b
    const/16 v9, 0xe

    if-ne v2, v9, :cond_c

    const/high16 v11, 0x42a40000    # 82.0f

    const/high16 v12, 0x42a40000    # 82.0f

    const/high16 v9, 0x41900000    # 18.0f

    const/high16 v10, 0x41900000    # 18.0f

    const/high16 v13, 0x42960000    # 75.0f

    const v14, 0x43938000    # 295.0f

    move-object v8, v7

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->addArc(FFFFFF)V

    invoke-virtual {v7, v6, v4}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v2, 0x42a20000    # 81.0f

    const/high16 v4, 0x42600000    # 56.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42bc0000    # 94.0f

    const/high16 v4, 0x42100000    # 36.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    goto/16 :goto_7

    :cond_c
    invoke-virtual {v7, v13, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v2, 0x41200000    # 10.0f

    invoke-virtual {v7, v13, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x41d80000    # 27.0f

    const/high16 v6, 0x42040000    # 33.0f

    invoke-virtual {v7, v4, v6}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v13, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42920000    # 73.0f

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    goto/16 :goto_7

    :cond_d
    :goto_1
    const/high16 v2, 0x42980000    # 76.0f

    invoke-virtual {v7, v2, v12}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x420c0000    # 35.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v11, 0x41c00000    # 24.0f

    const/high16 v12, 0x40400000    # 3.0f

    const/high16 v9, 0x42980000    # 76.0f

    const/high16 v10, 0x40400000    # 3.0f

    const/high16 v13, 0x41c00000    # 24.0f

    const/high16 v14, 0x420c0000    # 35.0f

    move-object v8, v7

    invoke-virtual/range {v8 .. v14}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    const/high16 v2, 0x42880000    # 68.0f

    invoke-virtual {v7, v15, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x40e00000    # 7.0f

    const/high16 v6, 0x424c0000    # 51.0f

    invoke-virtual {v7, v4, v6}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v15, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42240000    # 41.0f

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    goto/16 :goto_7

    :cond_e
    :goto_2
    if-ne v2, v14, :cond_f

    const/high16 v2, 0x42c80000    # 100.0f

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v4}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 v2, 0x3f800000    # 1.0f

    const/high16 v4, -0x40800000    # -1.0f

    invoke-virtual {v1, v4, v2}, Landroid/graphics/Canvas;->scale(FF)V

    :cond_f
    const/high16 v2, 0x42900000    # 72.0f

    invoke-virtual {v7, v2, v12}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x42400000    # 48.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v6, 0x41f00000    # 30.0f

    const/high16 v8, 0x42580000    # 54.0f

    invoke-virtual {v7, v2, v6, v8, v6}, Landroid/graphics/Path;->quadTo(FFFF)V

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v8, 0x42080000    # 34.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v8, v4}, Landroid/graphics/Path;->lineTo(FF)V

    goto/16 :goto_7

    :goto_3
    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    const/high16 v2, 0x42940000    # 74.0f

    invoke-virtual {v7, v2, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v1, v7, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual {v7}, Landroid/graphics/Path;->rewind()V

    const/16 v6, 0xff

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setAlpha(I)V

    invoke-virtual {v7, v2, v8}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v2, v12}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v6, 0x42740000    # 61.0f

    const/high16 v8, 0x422c0000    # 43.0f

    const/high16 v10, 0x42580000    # 54.0f

    invoke-virtual {v7, v2, v10, v6, v8}, Landroid/graphics/Path;->quadTo(FFFF)V

    const/high16 v2, 0x41a00000    # 20.0f

    invoke-virtual {v7, v2, v9}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v2, v9}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42380000    # 46.0f

    invoke-virtual {v7, v2, v9}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_7

    :goto_4
    invoke-virtual {v5, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    const/high16 v2, 0x42780000    # 62.0f

    invoke-virtual {v7, v13, v2}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x41700000    # 15.0f

    invoke-virtual {v7, v14, v4}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v1, v7, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual {v7}, Landroid/graphics/Path;->rewind()V

    const/16 v6, 0xff

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setAlpha(I)V

    invoke-virtual {v7, v13, v8}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v13, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v9, 0x41a00000    # 20.0f

    invoke-virtual {v7, v9, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42240000    # 41.0f

    const/high16 v10, 0x41880000    # 17.0f

    invoke-virtual {v7, v10, v2}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v9, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x41900000    # 18.0f

    const/high16 v11, 0x42380000    # 46.0f

    invoke-virtual {v7, v11, v4}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_7

    :goto_5
    invoke-virtual {v7, v12, v8}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v12, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x41100000    # 9.0f

    invoke-virtual {v7, v12, v4, v6, v10}, Landroid/graphics/Path;->quadTo(FFFF)V

    invoke-virtual {v7, v9, v2}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x42100000    # 36.0f

    invoke-virtual {v7, v9, v4}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v9, v2}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v7, v11, v2}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_7

    :goto_6
    invoke-virtual {v7, v2, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v4, 0x42680000    # 58.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v4, 0x426c0000    # 59.0f

    const/high16 v6, 0x421c0000    # 39.0f

    const/high16 v8, 0x42400000    # 48.0f

    invoke-virtual {v7, v2, v8, v4, v6}, Landroid/graphics/Path;->quadTo(FFFF)V

    const/high16 v2, 0x41d00000    # 26.0f

    const/high16 v4, 0x41200000    # 10.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v6, 0x42100000    # 36.0f

    invoke-virtual {v7, v2, v6}, Landroid/graphics/Path;->moveTo(FF)V

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v2, 0x42500000    # 52.0f

    invoke-virtual {v7, v2, v4}, Landroid/graphics/Path;->lineTo(FF)V

    :goto_7
    invoke-virtual {v1, v7, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual {v1, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method

.method public b(Landroid/graphics/Canvas;Ljava/lang/String;FFFFFIZZ)V
    .locals 2

    if-eqz p2, :cond_4

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_4

    const/high16 v0, 0x3f800000    # 1.0f

    cmpg-float v0, p5, v0

    if-gez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/B0;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lc/B0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/text/TextPaint;

    const-string v1, "sans"

    invoke-static {v1, p9}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p9

    invoke-virtual {v0, p9}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p9

    cmpl-float v1, p9, p5

    if-lez v1, :cond_1

    mul-float/2addr p6, p5

    div-float/2addr p6, p9

    invoke-static {p7, p6}, Ljava/lang/Math;->max(FF)F

    move-result p6

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTextSize(F)V

    :cond_1
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p6

    cmpl-float p6, p6, p5

    if-lez p6, :cond_2

    sget-object p6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {p2, v0, p5, p6}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object p2

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    :cond_2
    invoke-virtual {v0, p8}, Landroid/graphics/Paint;->setColor(I)V

    if-eqz p10, :cond_3

    sget-object p5, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    goto :goto_0

    :cond_3
    sget-object p5, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    :goto_0
    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    sget-object p1, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    :cond_4
    :goto_1
    return-void
.end method
