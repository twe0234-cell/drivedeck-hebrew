.class public final synthetic Lc/m1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;I)V
    .locals 0

    iput p6, p0, Lc/m1;->a:I

    iput-object p1, p0, Lc/m1;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/m1;->d:Ljava/lang/Object;

    iput-wide p3, p0, Lc/m1;->b:J

    iput-object p5, p0, Lc/m1;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 20

    move-object/from16 v1, p0

    iget v0, v1, Lc/m1;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v2, "; \u0432\u0442\u043e\u0440\u043e\u0439: "

    const-string v3, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u0438\u0437 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443. \u041f\u0435\u0440\u0432\u044b\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    const-string v4, "rollback.json"

    const-string v5, "stable"

    iget-object v0, v1, Lc/m1;->c:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v6, v1, Lc/m1;->d:Ljava/lang/Object;

    check-cast v6, Lc/Z6;

    iget-wide v8, v1, Lc/m1;->b:J

    iget-object v7, v1, Lc/m1;->e:Ljava/lang/Object;

    move-object v10, v7

    check-cast v10, Lc/n1;

    :try_start_0
    new-instance v7, Ljava/net/URI;

    invoke-static {v5}, Lc/k6;->Q(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v7, v11}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v4}, Ljava/net/URI;->resolve(Ljava/lang/String;)Ljava/net/URI;

    move-result-object v7

    invoke-virtual {v7}, Ljava/net/URI;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v11

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    invoke-virtual {v11, v0, v12}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v11

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1c

    if-lt v0, v12, :cond_0

    invoke-static {v11}, Lc/T;->b(Landroid/content/pm/PackageInfo;)J

    move-result-wide v14

    goto :goto_0

    :catch_0
    move-exception v0

    move-object v11, v0

    goto/16 :goto_6

    :cond_0
    iget v0, v11, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    int-to-long v14, v0

    :goto_0
    const-wide/16 v16, 0x4e20

    move-wide/from16 v18, v14

    :try_start_1
    invoke-static/range {v16 .. v17}, Lc/T8;->a(J)J

    move-result-wide v13

    invoke-static {v13, v14, v7}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    iget-object v7, v11, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    move-wide/from16 v14, v18

    :try_start_2
    invoke-static {v0, v14, v15, v7}, Lc/c9;->h(Lorg/json/JSONObject;JLjava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_5

    :catch_1
    move-exception v0

    :goto_1
    move-object v7, v0

    goto :goto_2

    :catch_2
    move-exception v0

    move-wide/from16 v14, v18

    goto :goto_1

    :goto_2
    :try_start_3
    invoke-static/range {v16 .. v17}, Lc/T8;->a(J)J

    move-result-wide v12

    invoke-static {v4, v5, v12, v13}, Lc/k6;->g0(Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v12, v13, v0}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    iget-object v4, v11, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    invoke-static {v0, v14, v15, v4}, Lc/c9;->h(Lorg/json/JSONObject;JLjava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_5

    :catch_3
    move-exception v0

    :try_start_4
    new-instance v4, Ljava/io/IOException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v4, v7}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v4
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    :goto_3
    move-object v4, v0

    goto :goto_4

    :catch_4
    move-exception v0

    goto :goto_3

    :goto_4
    :try_start_5
    invoke-static/range {v16 .. v17}, Lc/T8;->a(J)J

    move-result-wide v12

    const-string v0, "https://github.com/RotkivKiv/DriveDeck-Updates/releases/download/channels/stable-rollback.json"

    invoke-static {v12, v13, v0}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    iget-object v5, v11, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    invoke-static {v0, v14, v15, v5}, Lc/c9;->h(Lorg/json/JSONObject;JLjava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    :goto_5
    :try_start_6
    new-instance v2, Lc/F4;

    invoke-direct {v2, v8, v9, v10, v0}, Lc/F4;-><init>(JLc/n1;Ljava/util/List;)V

    const/4 v3, 0x1

    invoke-virtual {v6, v2, v3}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    goto :goto_7

    :catch_5
    move-exception v0

    new-instance v5, Ljava/io/IOException;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v5, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v5, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v5
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    :goto_6
    new-instance v0, Lc/X8;

    const/4 v12, 0x0

    move-object v7, v0

    invoke-direct/range {v7 .. v12}, Lc/X8;-><init>(JLc/n1;Ljava/lang/Exception;I)V

    const/4 v2, 0x1

    invoke-virtual {v6, v0, v2}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    :goto_7
    return-void

    :pswitch_0
    iget-object v0, v1, Lc/m1;->c:Ljava/lang/Object;

    check-cast v0, Lc/o1;

    iget-object v2, v1, Lc/m1;->d:Ljava/lang/Object;

    check-cast v2, Landroid/os/IBinder;

    iget-wide v3, v1, Lc/m1;->b:J

    iget-object v5, v1, Lc/m1;->e:Ljava/lang/Object;

    check-cast v5, Lc/n1;

    iget-boolean v6, v0, Lc/o1;->f:Z

    if-eqz v6, :cond_3

    iget-object v6, v0, Lc/o1;->g:Landroid/os/IBinder;

    if-ne v6, v2, :cond_3

    iget-wide v6, v0, Lc/o1;->h:J

    cmp-long v2, v6, v3

    if-nez v2, :cond_3

    iget-object v2, v0, Lc/o1;->j:Lc/n1;

    iput-object v5, v0, Lc/o1;->j:Lc/n1;

    if-nez v2, :cond_1

    if-eqz v5, :cond_3

    goto :goto_8

    :cond_1
    if-eqz v5, :cond_2

    iget v3, v2, Lc/n1;->a:I

    iget v4, v5, Lc/n1;->a:I

    if-ne v3, v4, :cond_2

    iget-object v3, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v4, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    iget-object v2, v2, Lc/n1;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v5, Lc/n1;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    :cond_2
    :goto_8
    iget-object v0, v0, Lc/o1;->b:Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    :cond_3
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
