.class public final Lc/O6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/hoho/android/usbserial/driver/UsbSerialPort;

.field public final synthetic b:Landroid/hardware/usb/UsbDeviceConnection;


# direct methods
.method public constructor <init>(Lcom/hoho/android/usbserial/driver/UsbSerialPort;Landroid/hardware/usb/UsbDeviceConnection;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/O6;->a:Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    iput-object p2, p0, Lc/O6;->b:Landroid/hardware/usb/UsbDeviceConnection;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    iget-object v0, p0, Lc/O6;->a:Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-interface {v0}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    iget-object v0, p0, Lc/O6;->b:Landroid/hardware/usb/UsbDeviceConnection;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/hardware/usb/UsbDeviceConnection;->close()V

    :cond_1
    return-void
.end method
