.class public final Lc/U8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public final e:J

.field public final f:Ljava/lang/String;

.field public g:Z

.field public h:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "stable"

    iput-object v0, p0, Lc/U8;->h:Ljava/lang/String;

    iput p1, p0, Lc/U8;->a:I

    iput-object p2, p0, Lc/U8;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/U8;->c:Ljava/lang/String;

    iput-object p4, p0, Lc/U8;->d:Ljava/lang/String;

    iput-wide p5, p0, Lc/U8;->e:J

    iput-object p7, p0, Lc/U8;->f:Ljava/lang/String;

    return-void
.end method
