.class public final Lc/G0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final K:I


# instance fields
.field public A:Ljava/lang/Object;

.field public B:Z

.field public C:I

.field public D:Ljava/lang/String;

.field public final E:Landroid/graphics/Paint$FontMetrics;

.field public F:I

.field public G:Ljava/lang/String;

.field public final H:Ljava/util/ArrayList;

.field public final I:Ljava/util/LinkedHashMap;

.field public final J:Ljava/util/LinkedHashMap;

.field public final a:Landroid/app/Activity;

.field public final b:Lc/n1;

.field public final c:Lc/T5;

.field public final d:Landroid/text/TextPaint;

.field public final e:Landroid/graphics/Paint;

.field public final f:Ljava/util/ArrayList;

.field public final g:[Ljava/lang/String;

.field public final h:[Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public final k:Landroid/graphics/RectF;

.field public final l:Ljava/util/LinkedHashMap;

.field public final m:Ljava/util/LinkedHashMap;

.field public n:Z

.field public o:Z

.field public p:Lc/D0;

.field public q:F

.field public r:F

.field public s:F

.field public t:I

.field public u:Ljava/lang/String;

.field public v:Ljava/lang/String;

.field public w:Ljava/lang/String;

.field public x:Ljava/lang/String;

.field public final y:[I

.field public final z:Landroid/graphics/RectF;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    array-length v0, v0

    const/4 v1, 0x1

    shl-int v0, v1, v0

    sub-int/2addr v0, v1

    sput v0, Lc/G0;->K:I

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;Lc/n1;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/text/TextPaint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v0, p0, Lc/G0;->d:Landroid/text/TextPaint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/G0;->e:Landroid/graphics/Paint;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/G0;->f:Ljava/util/ArrayList;

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [Ljava/lang/String;

    iput-object v0, p0, Lc/G0;->g:[Ljava/lang/String;

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    array-length v0, v0

    new-array v0, v0, [Ljava/lang/String;

    iput-object v0, p0, Lc/G0;->h:[Ljava/lang/String;

    const-string v0, "\u041d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    iput-object v0, p0, Lc/G0;->i:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, p0, Lc/G0;->j:Ljava/lang/String;

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/G0;->k:Landroid/graphics/RectF;

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v1, p0, Lc/G0;->l:Ljava/util/LinkedHashMap;

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v1, p0, Lc/G0;->m:Ljava/util/LinkedHashMap;

    iput-object v0, p0, Lc/G0;->w:Ljava/lang/String;

    iput-object v0, p0, Lc/G0;->x:Ljava/lang/String;

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v1

    array-length v1, v1

    new-array v1, v1, [I

    iput-object v1, p0, Lc/G0;->y:[I

    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    iput-object v1, p0, Lc/G0;->z:Landroid/graphics/RectF;

    iput-object v0, p0, Lc/G0;->D:Ljava/lang/String;

    new-instance v1, Landroid/graphics/Paint$FontMetrics;

    invoke-direct {v1}, Landroid/graphics/Paint$FontMetrics;-><init>()V

    iput-object v1, p0, Lc/G0;->E:Landroid/graphics/Paint$FontMetrics;

    iput-object v0, p0, Lc/G0;->G:Ljava/lang/String;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/G0;->H:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc/G0;->I:Ljava/util/LinkedHashMap;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc/G0;->J:Ljava/util/LinkedHashMap;

    iput-object p1, p0, Lc/G0;->a:Landroid/app/Activity;

    iput-object p2, p0, Lc/G0;->b:Lc/n1;

    invoke-static {p1}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object p1

    iput-object p1, p0, Lc/G0;->c:Lc/T5;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lc/G0;->j(Z)Z

    return-void
.end method

.method public static a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;
    .locals 41

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p5

    new-instance v3, Lc/D0;

    invoke-direct {v3}, Lc/D0;-><init>()V

    new-instance v4, Landroid/text/TextPaint;

    const/4 v5, 0x1

    invoke-direct {v4, v5}, Landroid/text/TextPaint;-><init>(I)V

    const/high16 v6, 0x41300000    # 11.0f

    mul-float v7, p3, v6

    invoke-virtual {v4, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v8, 0x42b00000    # 88.0f

    if-eqz v2, :cond_0

    mul-float v10, p3, v8

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    :goto_0
    iput v10, v3, Lc/D0;->e:F

    const/high16 v11, 0x41000000    # 8.0f

    mul-float v11, v11, p3

    sub-float v12, p2, v11

    sub-float v10, v12, v10

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-static {v13, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    new-instance v15, Ljava/util/LinkedHashMap;

    invoke-direct {v15}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual/range {p1 .. p1}, Lc/n1;->z()I

    move-result v16

    const-string v25, "100"

    const-string v26, "\u221240"

    const-string v17, "99,9"

    const-string v18, "399"

    const-string v19, "\u221240"

    const-string v20, "8000"

    const-string v21, "\u2248199,9"

    const-string v22, "\u2248199,9"

    const-string v23, "\u2248999,99"

    const-string v24, "100"

    const-string v27, "\u221240"

    const-string v28, "10"

    filled-new-array/range {v17 .. v28}, [Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {p1 .. p1}, Lc/n1;->x()Ljava/util/ArrayList;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :goto_1
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    const/high16 v20, 0x41d00000    # 26.0f

    const/high16 v21, 0x42a00000    # 80.0f

    const/high16 v22, 0x42180000    # 38.0f

    const/high16 v23, 0x42000000    # 32.0f

    const/high16 v24, 0x42c80000    # 100.0f

    const/high16 v9, 0x3e800000    # 0.25f

    if-eqz v19, :cond_4

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    move-object/from16 v5, v19

    check-cast v5, Lc/F0;

    invoke-virtual {v5}, Lc/F0;->a()I

    move-result v19

    and-int v19, v16, v19

    if-eqz v19, :cond_3

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    invoke-virtual {v1, v8}, Lc/n1;->y(I)I

    move-result v8

    int-to-float v8, v8

    div-float v8, v8, v24

    mul-float v8, v8, p4

    invoke-static {v9, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    const/high16 v9, 0x3f400000    # 0.75f

    div-float v9, v8, v9

    invoke-static {v13, v9}, Ljava/lang/Math;->min(FF)F

    move-result v9

    const/high16 v13, 0x42100000    # 36.0f

    mul-float v6, v8, v23

    invoke-static {v13, v6}, Ljava/lang/Math;->max(FF)F

    move-result v6

    mul-float v6, v6, p3

    mul-float/2addr v6, v9

    move/from16 v36, v12

    const/high16 v13, 0x41300000    # 11.0f

    mul-float v12, v8, v13

    const/high16 v13, 0x41600000    # 14.0f

    invoke-static {v13, v12}, Ljava/lang/Math;->max(FF)F

    move-result v12

    mul-float v12, v12, p3

    mul-float/2addr v12, v9

    sget-object v13, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v24

    aget-object v2, v17, v24

    invoke-virtual {v4, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    mul-float v22, v22, p3

    mul-float v22, v22, v8

    add-float v2, v22, v2

    move/from16 v38, v10

    sget-object v10, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v4, v10}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v10, Lc/F0;->g:Lc/F0;

    if-ne v5, v10, :cond_1

    const-string v10, "\u043b/100 \u043a\u043c"

    goto :goto_2

    :cond_1
    iget-object v10, v5, Lc/F0;->c:Ljava/lang/String;

    :goto_2
    invoke-static {v0, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4, v10}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v10

    mul-float v22, v11, v8

    add-float v10, v10, v22

    invoke-static {v2, v10}, Ljava/lang/Math;->max(FF)F

    move-result v2

    const/high16 v10, 0x42b00000    # 88.0f

    mul-float v24, p3, v10

    mul-float v10, v24, v8

    invoke-static {v2, v10}, Ljava/lang/Math;->max(FF)F

    move-result v2

    new-instance v10, Landroid/text/TextPaint;

    move-object/from16 v39, v3

    const/4 v3, 0x1

    invoke-direct {v10, v3}, Landroid/text/TextPaint;-><init>(I)V

    invoke-virtual {v10, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v3, 0x41400000    # 12.0f

    mul-float/2addr v3, v8

    const/high16 v13, 0x40000000    # 2.0f

    sub-float/2addr v3, v13

    const/high16 v13, 0x41600000    # 14.0f

    invoke-static {v13, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    mul-float v3, v3, p3

    mul-float/2addr v3, v9

    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v3, v5, Lc/F0;->b:Ljava/lang/String;

    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    sub-float v13, v2, v22

    float-to-int v13, v13

    move/from16 v40, v11

    const/4 v11, 0x1

    invoke-static {v11, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    const/4 v11, 0x0

    invoke-static {v9, v11, v3, v10, v13}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    sget-object v9, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    invoke-virtual {v3, v9}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    invoke-virtual {v3, v11}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object v3

    invoke-virtual {v3}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v34

    mul-float v3, p3, v21

    mul-float/2addr v3, v8

    invoke-virtual/range {v34 .. v34}, Landroid/text/Layout;->getHeight()I

    move-result v9

    int-to-float v9, v9

    add-float/2addr v9, v6

    add-float/2addr v9, v12

    mul-float v10, p3, v20

    mul-float/2addr v10, v8

    add-float/2addr v10, v9

    invoke-static {v3, v10}, Ljava/lang/Math;->max(FF)F

    move-result v3

    new-instance v9, Lc/E0;

    move-object/from16 v27, v9

    move-object/from16 v28, v5

    move/from16 v29, v2

    move/from16 v30, v3

    move/from16 v31, v8

    move/from16 v32, v6

    move/from16 v33, v12

    invoke-direct/range {v27 .. v34}, Lc/E0;-><init>(Lc/F0;FFFFFLandroid/text/StaticLayout;)V

    invoke-virtual {v14, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/PointF;

    if-nez v5, :cond_2

    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    new-instance v6, Landroid/graphics/PointF;

    invoke-direct {v6, v2, v3}, Landroid/graphics/PointF;-><init>(FF)V

    invoke-interface {v15, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :cond_2
    iget v6, v5, Landroid/graphics/PointF;->x:F

    invoke-static {v6, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iput v2, v5, Landroid/graphics/PointF;->x:F

    iget v2, v5, Landroid/graphics/PointF;->y:F

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iput v2, v5, Landroid/graphics/PointF;->y:F

    goto :goto_3

    :cond_3
    move-object/from16 v39, v3

    move/from16 v38, v10

    move/from16 v40, v11

    move/from16 v36, v12

    :goto_3
    move/from16 v2, p5

    move/from16 v12, v36

    move/from16 v10, v38

    move-object/from16 v3, v39

    move/from16 v11, v40

    const/4 v5, 0x1

    const/high16 v6, 0x41300000    # 11.0f

    const/high16 v8, 0x42b00000    # 88.0f

    const/high16 v13, 0x3f800000    # 1.0f

    goto/16 :goto_1

    :cond_4
    move-object/from16 v39, v3

    move/from16 v38, v10

    move/from16 v40, v11

    move/from16 v36, v12

    invoke-static/range {p0 .. p0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v2

    invoke-virtual {v2}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/i6;

    iget-object v6, v2, Lc/T5;->g:Lc/j6;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v10, "sensor:"

    invoke-direct {v8, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v10, v5, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v6, v8}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v6

    int-to-float v6, v6

    div-float v6, v6, v24

    mul-float v6, v6, p4

    invoke-static {v9, v6}, Ljava/lang/Math;->max(FF)F

    move-result v6

    mul-float v8, p3, v23

    mul-float/2addr v8, v6

    mul-float v10, v7, v6

    invoke-virtual/range {p1 .. p1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v11

    iget-boolean v12, v5, Lc/i6;->z:Z

    if-eqz v12, :cond_5

    iget-object v12, v5, Lc/i6;->d:Ljava/lang/String;

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_5

    goto :goto_5

    :cond_5
    invoke-virtual {v5, v11}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_5
    invoke-static {v0, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    sget-object v12, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v4, v8}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v13, 0x42b00000    # 88.0f

    mul-float v16, p3, v13

    mul-float v9, v16, v6

    const-string v13, "999,9"

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v13

    mul-float v16, p3, v22

    mul-float v16, v16, v6

    add-float v13, v16, v13

    invoke-static {v9, v13}, Ljava/lang/Math;->max(FF)F

    move-result v9

    sget-object v13, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v4, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    iget v13, v5, Lc/i6;->o:I

    invoke-static {v13}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v13

    invoke-static {v0, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v4, v13}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v13

    mul-float v16, v40, v6

    add-float v13, v13, v16

    invoke-static {v9, v13}, Ljava/lang/Math;->max(FF)F

    move-result v9

    new-instance v13, Landroid/text/TextPaint;

    move-object/from16 v18, v3

    const/4 v3, 0x1

    invoke-direct {v13, v3}, Landroid/text/TextPaint;-><init>(I)V

    invoke-virtual {v13, v12}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v13, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v12

    move-object/from16 v37, v4

    sub-float v4, v9, v16

    float-to-int v4, v4

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    const/4 v3, 0x0

    invoke-static {v11, v3, v12, v13, v4}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v4

    sget-object v11, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    invoke-virtual {v4, v11}, Landroid/text/StaticLayout$Builder;->setAlignment(Landroid/text/Layout$Alignment;)Landroid/text/StaticLayout$Builder;

    move-result-object v4

    invoke-virtual {v4, v3}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object v4

    const/4 v11, 0x2

    invoke-virtual {v4, v11}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    move-result-object v4

    sget-object v11, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v4, v11}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v35

    mul-float v4, p3, v21

    mul-float/2addr v4, v6

    invoke-virtual/range {v35 .. v35}, Landroid/text/Layout;->getHeight()I

    move-result v11

    int-to-float v11, v11

    add-float/2addr v11, v8

    add-float/2addr v11, v10

    mul-float v12, p3, v20

    mul-float/2addr v12, v6

    add-float/2addr v12, v11

    invoke-static {v4, v12}, Ljava/lang/Math;->max(FF)F

    move-result v4

    new-instance v11, Lc/E0;

    move-object/from16 v28, v11

    move-object/from16 v29, v5

    move/from16 v30, v9

    move/from16 v31, v4

    move/from16 v32, v6

    move/from16 v33, v8

    move/from16 v34, v10

    invoke-direct/range {v28 .. v35}, Lc/E0;-><init>(Lc/i6;FFFFFLandroid/text/StaticLayout;)V

    invoke-virtual {v14, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/PointF;

    if-nez v5, :cond_6

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    new-instance v6, Landroid/graphics/PointF;

    invoke-direct {v6, v9, v4}, Landroid/graphics/PointF;-><init>(FF)V

    invoke-interface {v15, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :cond_6
    iget v6, v5, Landroid/graphics/PointF;->x:F

    invoke-static {v6, v9}, Ljava/lang/Math;->max(FF)F

    move-result v6

    iput v6, v5, Landroid/graphics/PointF;->x:F

    iget v6, v5, Landroid/graphics/PointF;->y:F

    invoke-static {v6, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    iput v4, v5, Landroid/graphics/PointF;->y:F

    :goto_6
    move-object/from16 v3, v18

    move-object/from16 v4, v37

    const/high16 v9, 0x3e800000    # 0.25f

    goto/16 :goto_4

    :cond_7
    const/4 v3, 0x0

    iget-object v2, v2, Lc/T5;->g:Lc/j6;

    invoke-virtual {v1, v2}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v2

    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    move v11, v3

    :goto_7
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v11, v5, :cond_8

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v11, v11, 0x1

    goto :goto_7

    :cond_8
    new-instance v2, Lc/Y;

    const/4 v5, 0x1

    invoke-direct {v2, v4, v5}, Lc/Y;-><init>(Ljava/util/HashMap;I)V

    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    invoke-virtual {v14}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/E0;

    iget v5, v4, Lc/E0;->h:F

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/graphics/PointF;

    iget v6, v5, Landroid/graphics/PointF;->x:F

    iput v6, v4, Lc/E0;->d:F

    iget v5, v5, Landroid/graphics/PointF;->y:F

    iput v5, v4, Lc/E0;->e:F

    move-object/from16 v4, v39

    iget v5, v4, Lc/D0;->b:F

    add-float v6, v6, v40

    iget v8, v4, Lc/D0;->e:F

    add-float/2addr v6, v8

    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v5

    iput v5, v4, Lc/D0;->b:F

    goto :goto_8

    :cond_9
    move-object/from16 v4, v39

    move v11, v3

    :goto_9
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v2

    iget-object v5, v4, Lc/D0;->a:Ljava/util/ArrayList;

    if-ge v11, v2, :cond_17

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    const/4 v8, 0x0

    :goto_a
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v11, v9, :cond_b

    invoke-virtual {v14, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/E0;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_a

    iget v10, v9, Lc/E0;->d:F

    add-float/2addr v10, v6

    cmpl-float v10, v10, v38

    if-lez v10, :cond_a

    goto :goto_b

    :cond_a
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    iget v10, v9, Lc/E0;->d:F

    add-float/2addr v6, v10

    iget v9, v9, Lc/E0;->e:F

    invoke-static {v8, v9}, Ljava/lang/Math;->max(FF)F

    move-result v8

    goto :goto_a

    :cond_b
    :goto_b
    sub-float v10, v38, v6

    const/4 v6, 0x0

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v9

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v10

    int-to-float v10, v10

    div-float/2addr v9, v10

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v10

    move v12, v3

    move v13, v6

    :goto_c
    if-ge v12, v10, :cond_c

    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lc/E0;

    iget v3, v15, Lc/E0;->d:F

    add-float/2addr v3, v9

    iput v3, v15, Lc/E0;->d:F

    iput v13, v15, Lc/E0;->f:F

    iget v6, v4, Lc/D0;->c:F

    iput v6, v15, Lc/E0;->g:F

    add-float/2addr v13, v3

    add-int/lit8 v12, v12, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x0

    goto :goto_c

    :cond_c
    move/from16 v3, p5

    if-nez v3, :cond_16

    move v6, v11

    const/4 v11, 0x0

    :goto_d
    if-ge v11, v10, :cond_15

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/E0;

    iget v12, v12, Lc/E0;->e:F

    const/high16 v13, 0x3f000000    # 0.5f

    sub-float v15, v8, v13

    cmpl-float v12, v12, v15

    if-ltz v12, :cond_d

    add-int/lit8 v11, v11, 0x1

    goto :goto_d

    :cond_d
    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/E0;

    iget v12, v12, Lc/E0;->f:F

    const/4 v13, 0x0

    const/16 v16, 0x0

    :goto_e
    add-int/lit8 v1, v11, 0x1

    invoke-virtual {v2, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/E0;

    move/from16 v18, v6

    iget v6, v11, Lc/E0;->d:F

    add-float v16, v16, v6

    iget v6, v11, Lc/E0;->e:F

    invoke-static {v13, v6}, Ljava/lang/Math;->max(FF)F

    move-result v13

    if-ge v1, v10, :cond_f

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/E0;

    iget v6, v6, Lc/E0;->e:F

    cmpg-float v6, v6, v15

    if-ltz v6, :cond_e

    goto :goto_f

    :cond_e
    move v11, v1

    move/from16 v6, v18

    move-object/from16 v1, p1

    goto :goto_e

    :cond_f
    :goto_f
    move/from16 v6, v18

    :goto_10
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v11

    move/from16 v19, v1

    if-ge v6, v11, :cond_14

    move/from16 v20, v10

    const/4 v1, 0x0

    const/4 v11, 0x0

    const/4 v15, 0x0

    :goto_11
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v10

    if-ge v6, v10, :cond_12

    invoke-virtual {v14, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/E0;

    move-object/from16 v21, v14

    iget v14, v10, Lc/E0;->d:F

    add-float/2addr v14, v9

    add-float v18, v15, v14

    const/high16 v17, 0x3f000000    # 0.5f

    add-float v22, v16, v17

    cmpl-float v22, v18, v22

    if-gtz v22, :cond_11

    move/from16 v22, v9

    iget v9, v10, Lc/E0;->e:F

    add-float/2addr v9, v13

    add-float v23, v8, v17

    cmpl-float v9, v9, v23

    if-lez v9, :cond_10

    goto :goto_12

    :cond_10
    iput v14, v10, Lc/E0;->d:F

    add-float/2addr v15, v12

    iput v15, v10, Lc/E0;->f:F

    iget v9, v4, Lc/D0;->c:F

    add-float/2addr v9, v13

    iput v9, v10, Lc/E0;->g:F

    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v6, v6, 0x1

    add-int/lit8 v11, v11, 0x1

    iget v9, v10, Lc/E0;->e:F

    invoke-static {v1, v9}, Ljava/lang/Math;->max(FF)F

    move-result v1

    move/from16 v15, v18

    move-object/from16 v14, v21

    move/from16 v9, v22

    goto :goto_11

    :cond_11
    move/from16 v22, v9

    goto :goto_12

    :cond_12
    move/from16 v22, v9

    move-object/from16 v21, v14

    const/high16 v17, 0x3f000000    # 0.5f

    :goto_12
    if-nez v11, :cond_13

    goto :goto_13

    :cond_13
    add-float/2addr v13, v1

    move/from16 v1, v19

    move/from16 v10, v20

    move-object/from16 v14, v21

    move/from16 v9, v22

    goto :goto_10

    :cond_14
    move/from16 v22, v9

    move/from16 v20, v10

    move-object/from16 v21, v14

    :goto_13
    move-object/from16 v1, p1

    move/from16 v11, v19

    move/from16 v10, v20

    move-object/from16 v14, v21

    move/from16 v9, v22

    goto/16 :goto_d

    :cond_15
    move/from16 v18, v6

    move-object/from16 v21, v14

    move/from16 v11, v18

    goto :goto_14

    :cond_16
    move-object/from16 v21, v14

    :goto_14
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v1, v4, Lc/D0;->c:F

    add-float/2addr v1, v8

    iput v1, v4, Lc/D0;->c:F

    move-object/from16 v1, p1

    move-object/from16 v14, v21

    const/4 v3, 0x0

    goto/16 :goto_9

    :cond_17
    move/from16 v3, p5

    if-eqz v3, :cond_18

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x1

    if-eq v1, v2, :cond_18

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    invoke-static/range {v0 .. v5}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object v0

    return-object v0

    :cond_18
    iput-boolean v3, v4, Lc/D0;->f:Z

    if-eqz v3, :cond_19

    iget v1, v4, Lc/D0;->c:F

    const/high16 v2, 0x42400000    # 48.0f

    mul-float v2, v2, p3

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, v4, Lc/D0;->c:F

    :cond_19
    if-eqz v3, :cond_1a

    const/high16 v0, 0x40800000    # 4.0f

    :goto_15
    mul-float v0, v0, p3

    goto :goto_16

    :cond_1a
    new-instance v1, Landroid/text/TextPaint;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Landroid/text/TextPaint;-><init>(I)V

    invoke-virtual {v1, v7}, Landroid/graphics/Paint;->setTextSize(F)V

    const-string v2, "\u041d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    const/high16 v1, 0x42a40000    # 82.0f

    mul-float v1, v1, p3

    add-float/2addr v1, v0

    cmpg-float v0, v36, v1

    if-gez v0, :cond_1b

    const/high16 v0, 0x42780000    # 62.0f

    goto :goto_15

    :cond_1b
    const/high16 v0, 0x42200000    # 40.0f

    goto :goto_15

    :goto_16
    iput v0, v4, Lc/D0;->d:F

    iget v1, v4, Lc/D0;->c:F

    add-float/2addr v1, v0

    iput v1, v4, Lc/D0;->c:F

    return-object v4
.end method

.method public static f(Landroid/content/Context;Lc/n1;Lc/u0;Lc/o0;F)Lc/u0;
    .locals 11

    sget-object v0, Lc/s0;->l:Lc/s0;

    invoke-virtual {p2, v0}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    if-eqz v0, :cond_b

    iget-boolean v1, v0, Lc/r0;->g:Z

    if-eqz v1, :cond_0

    goto/16 :goto_5

    :cond_0
    iget-boolean v1, p3, Lc/o0;->f:Z

    const/4 v2, 0x0

    iget-object v3, p3, Lc/o0;->c:Lc/m0;

    if-eqz v1, :cond_1

    new-instance v1, Lc/m0;

    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v4

    invoke-static {v0, p4}, Lc/G8;->U(Lc/r0;F)F

    move-result v5

    invoke-direct {v1, v2, v2, v4, v5}, Lc/m0;-><init>(FFFF)V

    goto :goto_0

    :cond_1
    invoke-virtual {p3, v0}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v1

    :goto_0
    invoke-static {p0, p1, v1, p4}, Lc/G0;->g(Landroid/content/Context;Lc/n1;Lc/m0;F)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p2, v0}, Lc/u0;->a(Lc/r0;)Z

    move-result v1

    if-eqz v1, :cond_2

    return-object p2

    :cond_2
    const/4 v1, 0x0

    iget v4, v0, Lc/r0;->e:I

    move-object v5, v1

    :goto_1
    const/16 v6, 0x1e

    if-gt v4, v6, :cond_9

    iget v6, v0, Lc/r0;->f:I

    :goto_2
    iget v7, p3, Lc/o0;->h:I

    if-gt v6, v7, :cond_8

    invoke-virtual {v0, v4, v6}, Lc/r0;->c(II)Lc/r0;

    move-result-object v8

    rsub-int/lit8 v9, v4, 0x1e

    iget v10, v0, Lc/r0;->c:I

    invoke-static {v10, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    iget v10, v0, Lc/r0;->d:I

    sub-int/2addr v7, v6

    invoke-static {v10, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-virtual {v8, v9, v7}, Lc/r0;->a(II)Lc/r0;

    move-result-object v7

    iget-boolean v8, p3, Lc/o0;->f:Z

    if-eqz v8, :cond_3

    new-instance v8, Lc/m0;

    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v9

    invoke-static {v7, p4}, Lc/G8;->U(Lc/r0;F)F

    move-result v10

    invoke-direct {v8, v2, v2, v9, v10}, Lc/m0;-><init>(FFFF)V

    goto :goto_3

    :cond_3
    invoke-virtual {p3, v7}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v8

    :goto_3
    invoke-static {p0, p1, v8, p4}, Lc/G0;->g(Landroid/content/Context;Lc/n1;Lc/m0;F)Z

    move-result v8

    if-nez v8, :cond_4

    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_4
    invoke-virtual {p2, v7}, Lc/u0;->a(Lc/r0;)Z

    move-result v6

    if-eqz v6, :cond_5

    invoke-virtual {p2, v7}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object p0

    return-object p0

    :cond_5
    invoke-virtual {p2, v7}, Lc/u0;->e(Lc/r0;)Lc/r0;

    move-result-object v6

    if-eqz v6, :cond_6

    invoke-virtual {p2, v6}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object p0

    return-object p0

    :cond_6
    if-eqz v5, :cond_7

    iget v6, v7, Lc/r0;->e:I

    iget v8, v7, Lc/r0;->f:I

    mul-int/2addr v6, v8

    iget v8, v5, Lc/r0;->e:I

    iget v9, v5, Lc/r0;->f:I

    mul-int/2addr v8, v9

    if-ge v6, v8, :cond_8

    :cond_7
    move-object v5, v7

    :cond_8
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_9
    if-nez v5, :cond_a

    goto :goto_4

    :cond_a
    invoke-virtual {p2, v5}, Lc/u0;->p(Lc/r0;)Lc/u0;

    move-result-object v1

    :goto_4
    return-object v1

    :cond_b
    :goto_5
    return-object p2
.end method

.method public static g(Landroid/content/Context;Lc/n1;Lc/m0;F)Z
    .locals 6

    invoke-virtual {p2}, Lc/m0;->d()F

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move v3, p3

    invoke-static/range {v0 .. v5}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object p0

    invoke-virtual {p2}, Lc/m0;->d()F

    move-result p1

    invoke-virtual {p2}, Lc/m0;->b()F

    move-result p2

    invoke-static {p0, p1, p2}, Lc/G0;->h(Lc/D0;FF)Z

    move-result p0

    return p0
.end method

.method public static h(Lc/D0;FF)Z
    .locals 2

    iget v0, p0, Lc/D0;->b:F

    const/high16 v1, 0x3f000000    # 0.5f

    add-float/2addr p1, v1

    cmpg-float p1, v0, p1

    if-gtz p1, :cond_0

    iget p0, p0, Lc/D0;->c:F

    add-float/2addr p2, v1

    cmpg-float p0, p0, p2

    if-gtz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 8

    new-instance v0, Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc/G0;->c:Lc/T5;

    iget-object v2, v1, Lc/T5;->g:Lc/j6;

    iget-object v3, p0, Lc/G0;->b:Lc/n1;

    invoke-virtual {v3, v2}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/i6;

    const/16 v5, 0x7c

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v5, v4, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v5, 0x3d

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v5, v1, Lc/T5;->g:Lc/j6;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "sensor:"

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, v4, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v5, v4}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final c(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V
    .locals 10

    move v5, p5

    move-object v9, p0

    iget-object v0, v9, Lc/G0;->d:Landroid/text/TextPaint;

    if-eqz p8, :cond_0

    sget-object v1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_0
    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move/from16 v6, p6

    invoke-virtual {v0, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, p5}, Ljava/lang/Math;->max(FF)F

    move-result v1

    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    move-object v3, p2

    invoke-static {p2, v0, v1, v2}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    sub-float v0, v5, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float v3, v0, p3

    move-object v0, p0

    move-object v1, p1

    move v4, p4

    move v5, p5

    move/from16 v7, p7

    move/from16 v8, p8

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    return-void
.end method

.method public final d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/r4;FFF)V
    .locals 48

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    move-object/from16 v12, p3

    move/from16 v13, p4

    move/from16 v6, p5

    move/from16 v7, p6

    const/4 v14, 0x1

    iput-boolean v14, v9, Lc/G0;->o:Z

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    iget-object v8, v9, Lc/G0;->l:Ljava/util/LinkedHashMap;

    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    iget v4, v9, Lc/G0;->F:I

    invoke-virtual {v3}, Lc/F0;->a()I

    move-result v5

    and-int/2addr v4, v5

    if-nez v4, :cond_0

    invoke-interface {v8, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    iget-object v5, v9, Lc/G0;->m:Ljava/util/LinkedHashMap;

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    iget-object v4, v9, Lc/G0;->I:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    iget-object v3, v9, Lc/G0;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->z()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lc/G0;->b()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v0

    iget-object v15, v9, Lc/G0;->c:Lc/T5;

    invoke-virtual {v15}, Lc/T5;->f1()Ljava/lang/String;

    move-result-object v15

    iget-object v14, v9, Lc/G0;->p:Lc/D0;

    if-eqz v14, :cond_3

    iget v14, v9, Lc/G0;->q:F

    cmpl-float v14, v14, v6

    if-nez v14, :cond_3

    iget v14, v9, Lc/G0;->r:F

    cmpl-float v14, v14, v7

    if-nez v14, :cond_3

    iget v14, v9, Lc/G0;->s:F

    cmpl-float v14, v14, v13

    if-nez v14, :cond_3

    iget v14, v9, Lc/G0;->t:I

    if-ne v14, v2, :cond_3

    iget-object v14, v9, Lc/G0;->u:Ljava/lang/String;

    invoke-virtual {v1, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_3

    iget-object v14, v9, Lc/G0;->v:Ljava/lang/String;

    invoke-virtual {v0, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_3

    iget-object v14, v9, Lc/G0;->x:Ljava/lang/String;

    invoke-virtual {v15, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_2

    goto :goto_1

    :cond_2
    move-object/from16 v18, v0

    const/4 v14, 0x0

    goto :goto_2

    :cond_3
    :goto_1
    move-object/from16 v18, v0

    const/4 v14, 0x1

    :goto_2
    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    move-object/from16 v19, v1

    array-length v1, v0

    move/from16 v20, v14

    const/4 v14, 0x0

    :goto_3
    if-ge v14, v1, :cond_5

    aget-object v21, v0, v14

    move-object/from16 v22, v0

    invoke-virtual/range {v21 .. v21}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    invoke-virtual {v3, v0}, Lc/n1;->y(I)I

    move-result v0

    invoke-virtual/range {v21 .. v21}, Ljava/lang/Enum;->ordinal()I

    move-result v23

    move/from16 v24, v1

    iget-object v1, v9, Lc/G0;->y:[I

    move/from16 v25, v2

    aget v2, v1, v23

    if-eq v0, v2, :cond_4

    const/16 v20, 0x1

    :cond_4
    invoke-virtual/range {v21 .. v21}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aput v0, v1, v2

    add-int/lit8 v14, v14, 0x1

    move-object/from16 v0, v22

    move/from16 v1, v24

    move/from16 v2, v25

    goto :goto_3

    :cond_5
    move/from16 v25, v2

    const/high16 v14, 0x40800000    # 4.0f

    const/4 v2, 0x0

    const/high16 v21, 0x40000000    # 2.0f

    const/high16 v1, 0x3f800000    # 1.0f

    if-eqz v20, :cond_a

    mul-float v0, v7, v14

    cmpl-float v0, v6, v0

    if-ltz v0, :cond_6

    const/16 v20, 0x1

    goto :goto_4

    :cond_6
    const/16 v20, 0x0

    :goto_4
    const/high16 v22, 0x3f800000    # 1.0f

    iget-object v0, v9, Lc/G0;->a:Landroid/app/Activity;

    iget-object v14, v9, Lc/G0;->b:Lc/n1;

    move-object/from16 v26, v18

    move-object/from16 v18, v0

    move-object/from16 v24, v8

    move-object/from16 v8, v19

    move-object v1, v14

    move/from16 v28, v25

    move/from16 v2, p5

    move-object/from16 v29, v3

    move/from16 v3, p4

    move-object/from16 v30, v4

    move/from16 v4, v22

    move-object/from16 v31, v5

    move/from16 v5, v20

    invoke-static/range {v0 .. v5}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object v0

    invoke-static {v0, v6, v7}, Lc/G0;->h(Lc/D0;FF)Z

    move-result v1

    if-eqz v1, :cond_7

    goto :goto_7

    :cond_7
    const/4 v4, 0x0

    move-object/from16 v0, v18

    move-object v1, v14

    move/from16 v2, p5

    move/from16 v3, p4

    move/from16 v5, v20

    invoke-static/range {v0 .. v5}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object v0

    move-object/from16 v22, v0

    const/4 v5, 0x0

    const/high16 v25, 0x3f800000    # 1.0f

    const/16 v32, 0x0

    :goto_5
    const/16 v0, 0xa

    if-ge v5, v0, :cond_9

    add-float v0, v32, v25

    div-float v33, v0, v21

    move-object/from16 v0, v18

    move-object v1, v14

    move/from16 v2, p5

    move/from16 v3, p4

    move/from16 v4, v33

    move/from16 v34, v5

    move/from16 v5, v20

    invoke-static/range {v0 .. v5}, Lc/G0;->a(Landroid/content/Context;Lc/n1;FFFZ)Lc/D0;

    move-result-object v0

    invoke-static {v0, v6, v7}, Lc/G0;->h(Lc/D0;FF)Z

    move-result v1

    if-eqz v1, :cond_8

    move-object/from16 v22, v0

    move/from16 v32, v33

    goto :goto_6

    :cond_8
    move/from16 v25, v33

    :goto_6
    add-int/lit8 v5, v34, 0x1

    goto :goto_5

    :cond_9
    move-object/from16 v0, v22

    :goto_7
    iput-object v0, v9, Lc/G0;->p:Lc/D0;

    iput v6, v9, Lc/G0;->q:F

    iput v7, v9, Lc/G0;->r:F

    iput v13, v9, Lc/G0;->s:F

    move/from16 v0, v28

    iput v0, v9, Lc/G0;->t:I

    iput-object v8, v9, Lc/G0;->u:Ljava/lang/String;

    move-object/from16 v0, v26

    iput-object v0, v9, Lc/G0;->v:Ljava/lang/String;

    iput-object v15, v9, Lc/G0;->x:Ljava/lang/String;

    goto :goto_8

    :cond_a
    move-object/from16 v29, v3

    move-object/from16 v30, v4

    move-object/from16 v31, v5

    move-object/from16 v24, v8

    :goto_8
    iget-object v14, v9, Lc/G0;->p:Lc/D0;

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v1, 0x41000000    # 8.0f

    mul-float v15, v13, v1

    sub-float/2addr v0, v15

    iget v1, v14, Lc/D0;->e:F

    sub-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    sub-float v2, v6, v15

    iget v3, v14, Lc/D0;->e:F

    sub-float/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    div-float v18, v0, v2

    const/high16 v0, 0x40800000    # 4.0f

    mul-float v8, v13, v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    mul-float v2, v8, v21

    sub-float/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v20

    iget-object v7, v9, Lc/G0;->d:Landroid/text/TextPaint;

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v7, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v0, 0x41300000    # 11.0f

    mul-float v6, v13, v0

    invoke-virtual {v7, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-boolean v0, v14, Lc/D0;->f:Z

    if-eqz v0, :cond_c

    iget-boolean v0, v9, Lc/G0;->n:Z

    if-eqz v0, :cond_b

    const-string v0, "\u041f\u043e\u0434\u043a\u043b."

    goto :goto_9

    :cond_b
    const-string v0, "\u041d\u0435 \u043f\u043e\u0434\u043a\u043b."

    goto :goto_9

    :cond_c
    iget-object v0, v9, Lc/G0;->i:Ljava/lang/String;

    :goto_9
    iget-object v5, v9, Lc/G0;->a:Landroid/app/Activity;

    invoke-static {v5, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget v0, v14, Lc/D0;->d:F

    const/high16 v1, 0x42200000    # 40.0f

    mul-float/2addr v1, v13

    cmpl-float v0, v0, v1

    if-lez v0, :cond_d

    const/4 v0, 0x1

    goto :goto_a

    :cond_d
    const/4 v0, 0x0

    :goto_a
    iget v2, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v2, v8

    add-float/2addr v2, v15

    iget-boolean v3, v14, Lc/D0;->f:Z

    if-nez v3, :cond_f

    if-eqz v0, :cond_e

    goto :goto_b

    :cond_e
    const/high16 v22, 0x42080000    # 34.0f

    mul-float v22, v22, v13

    goto :goto_c

    :cond_f
    :goto_b
    const/16 v22, 0x0

    :goto_c
    add-float v2, v2, v22

    const/16 v22, 0x8

    const/high16 v23, 0x41800000    # 16.0f

    if-eqz v3, :cond_10

    iget v1, v14, Lc/D0;->e:F

    mul-float v3, v13, v23

    sub-float/2addr v1, v3

    move/from16 p5, v2

    goto :goto_e

    :cond_10
    if-eqz v0, :cond_11

    move/from16 v3, v22

    goto :goto_d

    :cond_11
    const/16 v3, 0x2a

    :goto_d
    int-to-float v3, v3

    mul-float/2addr v3, v13

    sub-float v3, v20, v3

    move/from16 p5, v2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-virtual {v7, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    add-float/2addr v2, v1

    invoke-static {v3, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    :goto_e
    iget v2, v11, Landroid/graphics/RectF;->top:F

    if-eqz v0, :cond_12

    const/16 v22, 0x1a

    :cond_12
    move/from16 v0, v22

    int-to-float v0, v0

    mul-float/2addr v0, v13

    add-float/2addr v0, v2

    iget-boolean v2, v14, Lc/D0;->f:Z

    iget-object v3, v9, Lc/G0;->E:Landroid/graphics/Paint$FontMetrics;

    const/high16 v22, 0x42000000    # 32.0f

    const/high16 v25, 0x41400000    # 12.0f

    if-eqz v2, :cond_14

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    mul-float v0, v13, v25

    invoke-virtual {v7, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    iget v0, v3, Landroid/graphics/Paint$FontMetrics;->descent:F

    iget v1, v3, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v0, v1

    iget-object v1, v9, Lc/G0;->j:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_13

    move v1, v15

    goto :goto_f

    :cond_13
    mul-float v1, v13, v22

    :goto_f
    const/high16 v2, 0x42900000    # 72.0f

    mul-float/2addr v2, v13

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v26

    sub-float v26, v26, v0

    sub-float v26, v26, v8

    sub-float v1, v26, v1

    invoke-static {v2, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerY()F

    move-result v19

    add-float v26, v0, v8

    add-float v26, v26, v1

    div-float v26, v26, v21

    sub-float v19, v19, v26

    iget v2, v3, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float v2, v19, v2

    move/from16 p5, v2

    iget v2, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v2, v8

    move-object/from16 v28, v3

    iget v3, v14, Lc/D0;->e:F

    sub-float/2addr v3, v1

    div-float v3, v3, v21

    add-float/2addr v2, v3

    add-float v19, v19, v0

    add-float v0, v19, v8

    move/from16 v32, p5

    move/from16 v19, v1

    goto :goto_10

    :cond_14
    move-object/from16 v28, v3

    move/from16 v2, p5

    move/from16 v19, v1

    const/16 v32, 0x0

    :goto_10
    iget-object v3, v9, Lc/G0;->k:Landroid/graphics/RectF;

    add-float v1, v2, v19

    move-object/from16 p5, v4

    iget-boolean v4, v14, Lc/D0;->f:Z

    if-eqz v4, :cond_15

    move/from16 v4, v19

    goto :goto_11

    :cond_15
    const/high16 v4, 0x41b00000    # 22.0f

    mul-float/2addr v4, v13

    :goto_11
    add-float/2addr v4, v0

    invoke-virtual {v3, v2, v0, v1, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-boolean v0, v14, Lc/D0;->f:Z

    if-eqz v0, :cond_16

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float v4, v0, v8

    iget v2, v14, Lc/D0;->e:F

    mul-float v33, v13, v25

    iget v1, v12, Lc/r4;->d:I

    const/16 v34, 0x1

    const-string v35, "OBD"

    move-object/from16 v0, p0

    move/from16 v36, v1

    move-object/from16 v1, p1

    move/from16 v37, v2

    const/high16 v26, 0x3f800000    # 1.0f

    move-object/from16 v2, v35

    move-object/from16 p6, v3

    move-object/from16 v38, v28

    move v3, v4

    move-object/from16 v28, p5

    move/from16 v4, v32

    move-object/from16 v39, v5

    move/from16 v5, v37

    move/from16 v32, v6

    move/from16 v6, v33

    move-object/from16 v40, v7

    move/from16 v7, v36

    move v10, v8

    move-object/from16 v41, v24

    move/from16 v8, v34

    invoke-virtual/range {v0 .. v8}, Lc/G0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    goto :goto_12

    :cond_16
    move-object/from16 p6, v3

    move-object/from16 v39, v5

    move/from16 v32, v6

    move-object/from16 v40, v7

    move v10, v8

    move-object/from16 v41, v24

    move-object/from16 v38, v28

    move-object/from16 v28, p5

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float/2addr v0, v10

    add-float v3, v0, v15

    iget v0, v11, Landroid/graphics/RectF;->top:F

    const/high16 v1, 0x41b80000    # 23.0f

    mul-float/2addr v1, v13

    add-float v4, v1, v0

    const/high16 v0, 0x41f00000    # 30.0f

    mul-float v5, v13, v0

    mul-float v6, v13, v25

    iget v7, v12, Lc/r4;->d:I

    const/4 v8, 0x1

    const-string v2, "OBD"

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :goto_12
    iget-boolean v0, v14, Lc/D0;->f:Z

    if-eqz v0, :cond_17

    mul-float v0, v13, v25

    goto :goto_13

    :cond_17
    invoke-virtual/range {p6 .. p6}, Landroid/graphics/RectF;->height()F

    move-result v0

    div-float v0, v0, v21

    :goto_13
    iget v1, v12, Lc/r4;->c:I

    sget-object v2, Lc/q9;->z:Ljava/lang/ThreadLocal;

    invoke-virtual {v2}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/q9;

    if-eqz v2, :cond_18

    iget-object v3, v2, Lc/q9;->h:Landroid/graphics/RectF;

    move-object/from16 v8, p6

    invoke-virtual {v3, v8}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iput v1, v2, Lc/q9;->i:I

    const/4 v1, 0x1

    iput-boolean v1, v2, Lc/q9;->j:Z

    goto :goto_14

    :cond_18
    move-object/from16 v8, p6

    :goto_14
    iget-object v1, v9, Lc/G0;->e:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v3, v12, Lc/r4;->c:I

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    iget-boolean v3, v14, Lc/D0;->f:Z

    move v7, v10

    move-object/from16 v10, p1

    if-nez v3, :cond_19

    invoke-virtual {v10, v8, v0, v0, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_19
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v1, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget v3, v12, Lc/r4;->h:I

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v10, v8, v0, v0, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget-boolean v0, v9, Lc/G0;->n:Z

    if-eqz v0, :cond_1a

    const v0, -0xd24292

    goto :goto_15

    :cond_1a
    const v0, -0x1ba9aa

    :goto_15
    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget-boolean v0, v14, Lc/D0;->f:Z

    iget-object v6, v9, Lc/G0;->z:Landroid/graphics/RectF;

    iget v5, v12, Lc/r4;->d:I

    if-eqz v0, :cond_1b

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    const v3, 0x3e8a3d71    # 0.27f

    mul-float v3, v3, v19

    sub-float/2addr v2, v3

    invoke-virtual {v10, v0, v2, v7, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    mul-float v0, v13, v22

    mul-float v1, v13, v23

    sub-float v1, v19, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-static {v4, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerX()F

    move-result v1

    div-float v0, v0, v21

    sub-float/2addr v1, v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerY()F

    move-result v2

    const v3, 0x3e23d70a    # 0.16f

    mul-float v19, v19, v3

    add-float v2, v2, v19

    sub-float/2addr v2, v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    add-float/2addr v3, v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerY()F

    move-result v22

    add-float v22, v22, v19

    add-float v0, v22, v0

    invoke-virtual {v6, v1, v2, v3, v0}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-static {v5}, Lc/q9;->a(I)I

    move-result v0

    const v1, 0x7f03003c

    move-object/from16 v3, v39

    invoke-static {v3, v10, v1, v0, v6}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    move-object/from16 v43, v3

    move/from16 v22, v5

    move-object/from16 v45, v6

    move/from16 v19, v7

    move-object v10, v8

    goto :goto_16

    :cond_1b
    move-object/from16 v3, v39

    const/high16 v4, 0x3f800000    # 1.0f

    iget v0, v8, Landroid/graphics/RectF;->left:F

    const/high16 v2, 0x41600000    # 14.0f

    mul-float/2addr v2, v13

    add-float/2addr v2, v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    invoke-virtual {v10, v2, v0, v7, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget v0, v8, Landroid/graphics/RectF;->left:F

    const/high16 v1, 0x41c80000    # 25.0f

    mul-float/2addr v1, v13

    add-float v22, v1, v0

    invoke-virtual {v8}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    add-float v23, v0, v7

    const/high16 v0, 0x42040000    # 33.0f

    mul-float/2addr v0, v13

    sub-float v0, v19, v0

    invoke-static {v4, v0}, Ljava/lang/Math;->max(FF)F

    move-result v19

    iget v2, v12, Lc/r4;->d:I

    const/16 v24, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v26, v2

    move-object/from16 v2, v28

    move-object/from16 v43, v3

    move/from16 v3, v22

    move/from16 v4, v23

    move/from16 v22, v5

    move/from16 v5, v19

    move-object/from16 v45, v6

    move/from16 v6, v32

    move/from16 v19, v7

    move/from16 v7, v26

    move-object v10, v8

    move/from16 v8, v24

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :goto_16
    iget-object v0, v9, Lc/G0;->j:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/high16 v23, 0x41200000    # 10.0f

    if-nez v0, :cond_1e

    iget-object v0, v9, Lc/G0;->j:Ljava/lang/String;

    move-object/from16 v8, v43

    invoke-static {v8, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-boolean v0, v14, Lc/D0;->f:Z

    if-eqz v0, :cond_1c

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float v3, v0, v19

    iget v0, v10, Landroid/graphics/RectF;->bottom:F

    mul-float v1, v13, v25

    add-float v4, v1, v0

    iget v5, v14, Lc/D0;->e:F

    iget v7, v12, Lc/r4;->e:I

    const/4 v10, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v6, v15

    move-object v15, v8

    move v8, v10

    invoke-virtual/range {v0 .. v8}, Lc/G0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :goto_17
    move-object v10, v15

    :goto_18
    const/high16 v15, 0x3f800000    # 1.0f

    goto :goto_19

    :cond_1c
    iget v0, v10, Landroid/graphics/RectF;->right:F

    add-float v3, v0, v15

    iget v0, v11, Landroid/graphics/RectF;->right:F

    sub-float v0, v0, v19

    sub-float v5, v0, v3

    const/high16 v0, 0x42700000    # 60.0f

    mul-float/2addr v0, v13

    cmpl-float v0, v5, v0

    if-ltz v0, :cond_1d

    invoke-virtual {v10}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    add-float v4, v0, v19

    mul-float v6, v13, v23

    iget v7, v12, Lc/r4;->e:I

    const/4 v10, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v15, v8

    move v8, v10

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    goto :goto_17

    :cond_1d
    move-object v10, v8

    iget v0, v11, Landroid/graphics/RectF;->left:F

    add-float v0, v0, v19

    add-float v3, v0, v15

    iget v0, v11, Landroid/graphics/RectF;->top:F

    iget v1, v14, Lc/D0;->d:F

    add-float/2addr v0, v1

    sub-float v4, v0, v19

    sub-float v0, v20, v15

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-static {v15, v0}, Ljava/lang/Math;->max(FF)F

    move-result v5

    const/high16 v0, 0x41100000    # 9.0f

    mul-float v6, v13, v0

    iget v7, v12, Lc/r4;->e:I

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    goto :goto_19

    :cond_1e
    move-object/from16 v10, v43

    goto :goto_18

    :goto_19
    iget-object v0, v14, Lc/D0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v8, 0x1

    if-ne v1, v8, :cond_1f

    move v1, v8

    goto :goto_1a

    :cond_1f
    const/4 v1, 0x0

    :goto_1a
    if-eqz v1, :cond_21

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_20
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_21

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/E0;

    iget v3, v3, Lc/E0;->g:F

    const/4 v7, 0x0

    cmpl-float v3, v3, v7

    if-lez v3, :cond_20

    const/16 v17, 0x0

    goto :goto_1b

    :cond_21
    const/4 v7, 0x0

    move/from16 v17, v1

    :goto_1b
    iget-boolean v1, v14, Lc/D0;->f:Z

    if-eqz v1, :cond_22

    iget v1, v11, Landroid/graphics/RectF;->top:F

    add-float v1, v1, v19

    :goto_1c
    move/from16 v20, v1

    goto :goto_1d

    :cond_22
    iget v1, v11, Landroid/graphics/RectF;->top:F

    iget v2, v14, Lc/D0;->d:F

    add-float/2addr v1, v2

    sub-float v1, v1, v19

    goto :goto_1c

    :goto_1d
    iget v1, v11, Landroid/graphics/RectF;->bottom:F

    sub-float v1, v1, v19

    sub-float v1, v1, v20

    invoke-static {v15, v1}, Ljava/lang/Math;->max(FF)F

    move-result v24

    const-string v1, "obd_widget_compact_readings"

    move-object/from16 v2, v29

    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v6, 0x0

    invoke-interface {v2, v1, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v16

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v25

    :goto_1e
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_31

    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Ljava/util/List;

    move v4, v6

    :goto_1f
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v0

    if-ge v4, v0, :cond_30

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/E0;

    iget-object v3, v0, Lc/E0;->a:Lc/F0;

    iget v1, v0, Lc/E0;->d:F

    mul-float v26, v1, v18

    if-eqz v17, :cond_23

    move/from16 v1, v24

    goto :goto_20

    :cond_23
    iget v1, v0, Lc/E0;->e:F

    :goto_20
    iget v2, v11, Landroid/graphics/RectF;->left:F

    add-float v2, v2, v19

    iget v6, v14, Lc/D0;->e:F

    add-float/2addr v2, v6

    iget v6, v0, Lc/E0;->f:F

    mul-float v6, v6, v18

    add-float/2addr v6, v2

    iget v2, v0, Lc/E0;->g:F

    add-float v2, v20, v2

    iget-object v8, v0, Lc/E0;->b:Lc/i6;

    move-object/from16 v7, v41

    if-eqz v3, :cond_24

    invoke-virtual {v7, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v29

    check-cast v29, Landroid/graphics/RectF;

    move-object/from16 v11, v31

    goto :goto_21

    :cond_24
    iget-object v15, v8, Lc/i6;->a:Ljava/lang/String;

    move-object/from16 v11, v31

    invoke-virtual {v11, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    move-object/from16 v29, v15

    check-cast v29, Landroid/graphics/RectF;

    :goto_21
    if-nez v29, :cond_26

    new-instance v15, Landroid/graphics/RectF;

    invoke-direct {v15}, Landroid/graphics/RectF;-><init>()V

    if-eqz v3, :cond_25

    invoke-interface {v7, v3, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move/from16 v31, v4

    goto :goto_22

    :cond_25
    move/from16 v31, v4

    iget-object v4, v8, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v11, v4, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_22

    :cond_26
    move/from16 v31, v4

    move-object/from16 v15, v29

    :goto_22
    add-float v4, v6, v26

    move-object/from16 p6, v5

    add-float v5, v2, v1

    invoke-virtual {v15, v6, v2, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v4, v9, Lc/G0;->J:Ljava/util/LinkedHashMap;

    iget-object v5, v9, Lc/G0;->h:[Ljava/lang/String;

    iget-object v15, v9, Lc/G0;->g:[Ljava/lang/String;

    move-object/from16 v41, v7

    iget v7, v0, Lc/E0;->c:I

    iget v9, v0, Lc/E0;->h:F

    if-eqz v16, :cond_2d

    iget-object v3, v0, Lc/E0;->a:Lc/F0;

    if-eqz v3, :cond_27

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v34

    aget-object v15, v15, v34

    move-object/from16 v34, v11

    move-object/from16 v11, v30

    goto :goto_23

    :cond_27
    iget-object v15, v8, Lc/i6;->a:Ljava/lang/String;

    move-object/from16 v34, v11

    move-object/from16 v11, v30

    invoke-virtual {v11, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    :goto_23
    if-eqz v3, :cond_28

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget-object v3, v5, v3

    goto :goto_24

    :cond_28
    iget-object v3, v8, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    :goto_24
    invoke-static {v10, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/high16 v3, 0x40c00000    # 6.0f

    mul-float/2addr v3, v13

    mul-float/2addr v3, v9

    const/high16 v4, 0x41c00000    # 24.0f

    mul-float/2addr v4, v13

    mul-float/2addr v4, v9

    iget v5, v0, Lc/E0;->i:F

    const v30, 0x3fa66666    # 1.3f

    mul-float v5, v5, v30

    move-object/from16 v30, v14

    sget-object v14, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    move-object/from16 v35, v11

    move-object/from16 v11, v40

    invoke-virtual {v11, v14}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v11, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    move-object/from16 v13, v38

    invoke-virtual {v11, v13}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    sub-float v32, v1, v4

    const/high16 v29, 0x40400000    # 3.0f

    mul-float v29, v29, v3

    sub-float v12, v32, v29

    move/from16 v36, v7

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v7, v12}, Ljava/lang/Math;->max(FF)F

    move-result v12

    iget v7, v13, Landroid/graphics/Paint$FontMetrics;->descent:F

    move-object/from16 v39, v10

    iget v10, v13, Landroid/graphics/Paint$FontMetrics;->ascent:F

    sub-float/2addr v7, v10

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v10, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    div-float/2addr v12, v7

    invoke-static {v10, v12}, Ljava/lang/Math;->min(FF)F

    move-result v7

    mul-float/2addr v5, v7

    iget v0, v0, Lc/E0;->j:F

    mul-float/2addr v0, v7

    invoke-virtual {v11, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v11, v15}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v7

    sget-object v10, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v11, v10}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v11, v8}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v12

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v29

    if-eqz v29, :cond_29

    const/4 v9, 0x0

    goto :goto_25

    :cond_29
    mul-float v9, v9, v19

    :goto_25
    mul-float v29, v3, v21

    move-object/from16 v33, v15

    sub-float v15, v26, v29

    move/from16 v29, v6

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v6, v15}, Ljava/lang/Math;->max(FF)F

    move-result v15

    add-float/2addr v9, v7

    add-float/2addr v9, v12

    div-float/2addr v15, v9

    invoke-static {v6, v15}, Ljava/lang/Math;->min(FF)F

    move-result v9

    mul-float v6, v5, v9

    mul-float v12, v0, v9

    mul-float/2addr v7, v9

    invoke-virtual {v11, v14}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v11, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v11, v13}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    iget v0, v13, Landroid/graphics/Paint$FontMetrics;->ascent:F

    iget v9, v13, Landroid/graphics/Paint$FontMetrics;->descent:F

    sub-float v5, v9, v0

    invoke-virtual {v11, v10}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v11, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v11, v13}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    iget v10, v13, Landroid/graphics/Paint$FontMetrics;->ascent:F

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_2a

    const/4 v14, 0x0

    goto :goto_26

    :cond_2a
    iget v14, v13, Landroid/graphics/Paint$FontMetrics;->descent:F

    sub-float/2addr v14, v10

    :goto_26
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_2b

    const/4 v15, 0x1

    goto :goto_27

    :cond_2b
    const/4 v15, 0x2

    :goto_27
    sub-float v32, v32, v5

    sub-float v32, v32, v14

    int-to-float v15, v15

    move-object/from16 v37, v8

    div-float v8, v32, v15

    move-object/from16 v38, v13

    const/4 v13, 0x0

    invoke-static {v13, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    invoke-static {v3, v8}, Ljava/lang/Math;->min(FF)F

    move-result v32

    sub-float v3, v1, v5

    sub-float/2addr v3, v14

    mul-float v15, v15, v32

    sub-float/2addr v3, v15

    invoke-static {v13, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-static {v4, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    add-float/2addr v15, v3

    add-float/2addr v15, v5

    add-float/2addr v15, v14

    sub-float/2addr v1, v15

    div-float v1, v1, v21

    add-float/2addr v1, v2

    add-float v2, v1, v3

    add-float v4, v2, v32

    sub-float v14, v4, v0

    sub-float v0, v26, v3

    div-float v0, v0, v21

    add-float v0, v0, v29

    add-float v3, v26, v3

    div-float v3, v3, v21

    add-float v3, v3, v29

    move-object/from16 v15, v45

    invoke-virtual {v15, v0, v1, v3, v2}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-static/range {v22 .. v22}, Lc/q9;->a(I)I

    move-result v0

    move-object/from16 v8, p1

    move/from16 v1, v36

    move-object/from16 v5, v39

    invoke-static {v5, v8, v1, v0, v15}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    sub-float v0, v26, v7

    div-float v0, v0, v21

    add-float v3, v0, v29

    const/high16 v0, 0x3f800000    # 1.0f

    add-float/2addr v7, v0

    move-object/from16 v4, p3

    iget v2, v4, Lc/r4;->d:I

    const/16 v36, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v39, v2

    move-object/from16 v2, v33

    move-object v13, v4

    move v4, v14

    move-object/from16 v40, p6

    move-object/from16 v46, v5

    move v5, v7

    move/from16 v43, v29

    const/16 v27, 0x0

    const/16 v44, 0x0

    move/from16 v7, v39

    move-object/from16 v39, v11

    move-object/from16 v29, v37

    const/16 v28, 0x1

    move-object v11, v8

    move/from16 v8, v36

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    invoke-virtual/range {v29 .. v29}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2c

    add-float/2addr v14, v9

    add-float v14, v14, v32

    sub-float v4, v14, v10

    iget v7, v13, Lc/r4;->e:I

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, v29

    move/from16 v3, v43

    move/from16 v5, v26

    move v6, v12

    invoke-virtual/range {v0 .. v8}, Lc/G0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :cond_2c
    move-object/from16 v45, v15

    move-object/from16 v12, v35

    move-object/from16 v37, v38

    move-object/from16 v15, v39

    move-object/from16 v14, v46

    const/high16 v39, 0x3f800000    # 1.0f

    goto/16 :goto_2a

    :cond_2d
    move/from16 v43, v6

    move v6, v7

    move-object/from16 v46, v10

    move-object/from16 v34, v11

    move-object v13, v12

    move-object/from16 v35, v30

    move-object/from16 v39, v40

    move-object/from16 v10, v45

    const/16 v27, 0x0

    const/16 v28, 0x1

    const/16 v44, 0x0

    move-object/from16 v11, p1

    move-object/from16 v40, p6

    move-object/from16 v30, v14

    iget-object v7, v0, Lc/E0;->k:Landroid/text/StaticLayout;

    invoke-virtual {v7}, Landroid/text/Layout;->getHeight()I

    move-result v12

    int-to-float v12, v12

    iget v14, v0, Lc/E0;->i:F

    add-float/2addr v12, v14

    const/high16 v36, 0x41a80000    # 21.0f

    move-object/from16 v37, v5

    move-object/from16 v5, v38

    mul-float v36, v36, p4

    move-object/from16 v38, v4

    mul-float v4, v36, v9

    mul-float v36, p4, v23

    mul-float v36, v36, v9

    iget v0, v0, Lc/E0;->j:F

    move/from16 v45, v6

    add-float v6, v36, v0

    invoke-static {v4, v6}, Ljava/lang/Math;->max(FF)F

    move-result v4

    add-float/2addr v4, v12

    sub-float/2addr v1, v4

    div-float v1, v1, v21

    add-float/2addr v1, v2

    invoke-virtual {v7}, Landroid/text/Layout;->getPaint()Landroid/text/TextPaint;

    move-result-object v2

    iget v4, v13, Lc/r4;->e:I

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {v7}, Landroid/text/Layout;->getWidth()I

    move-result v2

    int-to-float v2, v2

    sub-float v2, v26, v2

    div-float v2, v2, v21

    add-float v2, v2, v43

    invoke-virtual {v11, v2, v1}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-static {v11, v7}, Lc/q9;->d(Landroid/graphics/Canvas;Landroid/text/StaticLayout;)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    if-eqz v3, :cond_2e

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget-object v2, v15, v2

    move-object/from16 v12, v35

    goto :goto_28

    :cond_2e
    iget-object v2, v8, Lc/i6;->a:Ljava/lang/String;

    move-object/from16 v12, v35

    invoke-virtual {v12, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    :goto_28
    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    move-object/from16 v15, v39

    invoke-virtual {v15, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v15, v14}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v4, 0x41c00000    # 24.0f

    mul-float v4, v4, p4

    mul-float/2addr v4, v9

    const/high16 v6, 0x40c00000    # 6.0f

    mul-float v6, v6, p4

    mul-float/2addr v6, v9

    invoke-virtual {v15, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v32

    sub-float v33, v26, v4

    sub-float v33, v33, v6

    sub-float v33, v33, v32

    div-float v33, v33, v21

    move/from16 v35, v0

    add-float v0, v33, v43

    invoke-virtual {v7}, Landroid/text/Layout;->getHeight()I

    move-result v7

    int-to-float v7, v7

    add-float/2addr v1, v7

    const/high16 v7, 0x40400000    # 3.0f

    mul-float v7, v7, p4

    mul-float v29, v7, v9

    add-float v1, v1, v29

    add-float v33, v1, v14

    invoke-virtual {v15, v5}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    iget v1, v5, Landroid/graphics/Paint$FontMetrics;->ascent:F

    iget v7, v5, Landroid/graphics/Paint$FontMetrics;->descent:F

    add-float/2addr v1, v7

    div-float v1, v1, v21

    add-float v1, v1, v33

    div-float v7, v4, v21

    move-object/from16 v36, v3

    sub-float v3, v1, v7

    add-float/2addr v4, v0

    add-float/2addr v1, v7

    invoke-virtual {v10, v0, v3, v4, v1}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-static/range {v22 .. v22}, Lc/q9;->a(I)I

    move-result v0

    move/from16 v1, v45

    move-object/from16 v7, v46

    invoke-static {v7, v11, v1, v0, v10}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    add-float v3, v4, v6

    const/high16 v39, 0x3f800000    # 1.0f

    add-float v6, v32, v39

    iget v4, v13, Lc/r4;->d:I

    const/16 v32, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v47, v38

    move/from16 v38, v4

    move/from16 v4, v33

    move-object/from16 v42, v37

    move-object/from16 v37, v5

    move v5, v6

    move v6, v14

    move-object v14, v7

    move/from16 v7, v38

    move-object/from16 v45, v10

    move-object v10, v8

    move/from16 v8, v32

    invoke-virtual/range {v0 .. v8}, Lc/G0;->i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    if-eqz v36, :cond_2f

    invoke-virtual/range {v36 .. v36}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget-object v0, v42, v0

    goto :goto_29

    :cond_2f
    iget-object v0, v10, Lc/i6;->a:Ljava/lang/String;

    move-object/from16 v1, v47

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    :goto_29
    invoke-static {v14, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/high16 v0, 0x41700000    # 15.0f

    mul-float v0, v0, p4

    mul-float/2addr v0, v9

    add-float v1, v35, v29

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    add-float v4, v0, v33

    iget v7, v13, Lc/r4;->e:I

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v43

    move/from16 v5, v26

    move/from16 v6, v35

    invoke-virtual/range {v0 .. v8}, Lc/G0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :goto_2a
    add-int/lit8 v4, v31, 0x1

    move-object/from16 v9, p0

    move-object/from16 v11, p2

    move-object v10, v14

    move/from16 v6, v27

    move/from16 v8, v28

    move-object/from16 v14, v30

    move-object/from16 v31, v34

    move-object/from16 v38, v37

    move-object/from16 v5, v40

    move/from16 v7, v44

    move-object/from16 v30, v12

    move-object v12, v13

    move-object/from16 v40, v15

    move/from16 v15, v39

    move/from16 v13, p4

    goto/16 :goto_1f

    :cond_30
    move-object/from16 v11, p1

    move-object v13, v12

    move/from16 v39, v15

    move-object/from16 v12, v30

    move-object/from16 v9, p0

    move-object/from16 v11, p2

    move-object v12, v13

    move/from16 v13, p4

    goto/16 :goto_1e

    :cond_31
    return-void
.end method

.method public final e()Ljava/util/LinkedHashMap;
    .locals 5

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iget-object v1, p0, Lc/G0;->c:Lc/T5;

    iget-object v1, v1, Lc/T5;->g:Lc/j6;

    iget-object v2, p0, Lc/G0;->b:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->v(Lc/j6;)Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v3, "sensor:"

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    iget-object v3, p0, Lc/G0;->m:Ljava/util/LinkedHashMap;

    const/4 v4, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    :goto_1
    invoke-virtual {v3, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    goto :goto_2

    :cond_1
    iget-object v3, p0, Lc/G0;->l:Ljava/util/LinkedHashMap;

    invoke-static {v2}, Lc/F0;->valueOf(Ljava/lang/String;)Lc/F0;

    move-result-object v4

    goto :goto_1

    :goto_2
    if-eqz v3, :cond_0

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public final i(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V
    .locals 1

    iget-object v0, p0, Lc/G0;->d:Landroid/text/TextPaint;

    if-eqz p8, :cond_0

    sget-object p8, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_0
    sget-object p8, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {v0, p8}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p7}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 p6, 0x3f800000    # 1.0f

    invoke-static {p6, p5}, Ljava/lang/Math;->max(FF)F

    move-result p5

    sget-object p6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {p2, v0, p5, p6}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object p2

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final j(Z)Z
    .locals 26

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/G0;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->z()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lc/G0;->b()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v0, Lc/G0;->c:Lc/T5;

    invoke-virtual {v4}, Lc/T5;->f1()Ljava/lang/String;

    move-result-object v5

    iget v6, v0, Lc/G0;->F:I

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-ne v6, v2, :cond_1

    iget-boolean v6, v0, Lc/G0;->n:Z

    iget-boolean v9, v4, Lc/T5;->F1:Z

    if-ne v6, v9, :cond_1

    iget-object v6, v0, Lc/G0;->G:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    iget-object v6, v0, Lc/G0;->w:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_0

    goto :goto_0

    :cond_0
    move v6, v8

    goto :goto_1

    :cond_1
    :goto_0
    move v6, v7

    :goto_1
    iput-object v3, v0, Lc/G0;->G:Ljava/lang/String;

    iput-object v5, v0, Lc/G0;->w:Ljava/lang/String;

    iput v2, v0, Lc/G0;->F:I

    iget-object v2, v0, Lc/G0;->f:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v1}, Lc/n1;->x()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/F0;

    iget v5, v0, Lc/G0;->F:I

    invoke-virtual {v3}, Lc/F0;->a()I

    move-result v9

    and-int/2addr v5, v9

    if-eqz v5, :cond_2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    iget-object v1, v0, Lc/G0;->H:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v4}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    new-instance v3, Ljava/util/LinkedHashSet;

    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/i6;

    iget-object v9, v9, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v3, v9}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_4
    iget-object v5, v0, Lc/G0;->I:Ljava/util/LinkedHashMap;

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v9

    invoke-interface {v9, v3}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    iget-object v9, v0, Lc/G0;->J:Ljava/util/LinkedHashMap;

    invoke-virtual {v9}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v10

    invoke-interface {v10, v3}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    iget-boolean v3, v4, Lc/T5;->F1:Z

    iput-boolean v3, v0, Lc/G0;->n:Z

    if-eqz v3, :cond_5

    const-string v3, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    goto :goto_4

    :cond_5
    const-string v3, "\u041d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    :goto_4
    iput-object v3, v0, Lc/G0;->i:Ljava/lang/String;

    iget-object v3, v4, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v10, "enabled"

    invoke-interface {v3, v10, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    const-string v10, ""

    if-eqz v3, :cond_6

    iget-boolean v3, v0, Lc/G0;->n:Z

    if-nez v3, :cond_6

    iget-object v3, v4, Lc/T5;->C1:Ljava/lang/String;

    goto :goto_5

    :cond_6
    move-object v3, v10

    :goto_5
    iget-object v11, v0, Lc/G0;->j:Ljava/lang/String;

    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    xor-int/2addr v11, v7

    or-int/2addr v6, v11

    iput-object v3, v0, Lc/G0;->j:Ljava/lang/String;

    invoke-virtual {v4}, Lc/T5;->S()Ljava/lang/Double;

    move-result-object v3

    const/16 v11, 0xd

    invoke-virtual {v4, v11}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v11

    if-eqz p1, :cond_7

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    :cond_7
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    const-string v13, "\u043e/\u043c"

    const-string v14, "\u043e\u0431/\u043c\u0438\u043d"

    const-string v16, "\u2014"

    const-string v7, "f"

    const-string v8, "%."

    const-wide/high16 v17, 0x4059000000000000L    # 100.0

    if-eqz v12, :cond_1a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/F0;

    iget-object v15, v12, Lc/F0;->c:Ljava/lang/String;

    move-object/from16 v19, v2

    iget v2, v12, Lc/F0;->d:I

    move-object/from16 v20, v10

    invoke-virtual {v4, v2}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v10

    if-eqz v10, :cond_b

    iget-object v2, v10, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v2}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v2

    move-object/from16 v21, v5

    move/from16 v22, v6

    if-nez v2, :cond_8

    const/4 v5, 0x0

    goto :goto_7

    :cond_8
    iget-wide v5, v2, Lc/S5;->a:D

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    :goto_7
    if-nez v2, :cond_9

    iget v2, v10, Lc/i6;->o:I

    goto :goto_8

    :cond_9
    invoke-virtual {v2, v10}, Lc/S5;->a(Lc/i6;)I

    move-result v2

    :goto_8
    invoke-static {v2}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v15

    move-object v6, v1

    if-nez v5, :cond_a

    const/4 v1, 0x0

    goto :goto_9

    :cond_a
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    invoke-virtual {v10, v1, v2}, Lc/i6;->f(D)Ljava/lang/String;

    move-result-object v1

    :goto_9
    move-object v2, v1

    const/4 v1, 0x0

    goto/16 :goto_e

    :cond_b
    move-object/from16 v21, v5

    move/from16 v22, v6

    move-object v6, v1

    sget-object v1, Lc/F0;->g:Lc/F0;

    if-ne v12, v1, :cond_e

    if-eqz v3, :cond_c

    if-eqz v11, :cond_c

    invoke-virtual {v11}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    const-wide/high16 v23, 0x4014000000000000L    # 5.0

    cmpl-double v1, v1, v23

    if-ltz v1, :cond_c

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    mul-double v1, v1, v17

    invoke-virtual {v11}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v17

    div-double v1, v1, v17

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    const-string v2, "\u043b/100 \u043a\u043c"

    move-object v5, v1

    move-object v15, v2

    goto :goto_a

    :cond_c
    const-string v1, "\u043b/\u0447"

    move-object v15, v1

    move-object v5, v3

    :goto_a
    if-eqz v3, :cond_12

    invoke-virtual {v4}, Lc/T5;->T()Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u042d\u0411\u0423"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12

    :cond_d
    :goto_b
    const/4 v1, 0x1

    :goto_c
    const/4 v2, 0x0

    goto :goto_e

    :cond_e
    sget-object v1, Lc/F0;->h:Lc/F0;

    if-ne v12, v1, :cond_f

    invoke-virtual {v4}, Lc/T5;->R0()Ljava/lang/Double;

    move-result-object v5

    iget-boolean v1, v4, Lc/T5;->o2:Z

    if-nez v1, :cond_d

    iget-boolean v1, v4, Lc/T5;->p2:Z

    if-eqz v1, :cond_12

    goto :goto_b

    :cond_f
    sget-object v1, Lc/F0;->i:Lc/F0;

    if-ne v12, v1, :cond_11

    iget-boolean v1, v4, Lc/T5;->m2:Z

    if-eqz v1, :cond_10

    iget-wide v1, v4, Lc/T5;->j2:D

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    move-object v5, v1

    goto :goto_d

    :cond_10
    const/4 v5, 0x0

    :goto_d
    iget-boolean v1, v4, Lc/T5;->o2:Z

    if-nez v1, :cond_d

    iget-boolean v1, v4, Lc/T5;->p2:Z

    if-eqz v1, :cond_12

    goto :goto_b

    :cond_11
    invoke-virtual {v4, v2}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v5

    :cond_12
    const/4 v1, 0x0

    goto :goto_c

    :goto_e
    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_13

    goto :goto_f

    :cond_13
    move-object v13, v15

    :goto_f
    if-eqz v5, :cond_17

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Double;->isFinite(D)Z

    move-result v10

    if-nez v10, :cond_14

    goto :goto_11

    :cond_14
    if-eqz v2, :cond_15

    goto :goto_12

    :cond_15
    if-eqz v1, :cond_16

    const-string v1, "\u2248"

    goto :goto_10

    :cond_16
    move-object/from16 v1, v20

    :goto_10
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v8, v12, Lc/F0;->e:I

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v2, v7, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    :cond_17
    :goto_11
    move-object/from16 v2, v16

    :goto_12
    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    iget-object v5, v0, Lc/G0;->g:[Ljava/lang/String;

    aget-object v1, v5, v1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v7, v0, Lc/G0;->h:[Ljava/lang/String;

    if-eqz v1, :cond_19

    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget-object v1, v7, v1

    invoke-virtual {v13, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18

    goto :goto_13

    :cond_18
    const/4 v1, 0x0

    goto :goto_14

    :cond_19
    :goto_13
    const/4 v1, 0x1

    :goto_14
    or-int v1, v22, v1

    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    aput-object v2, v5, v8

    invoke-virtual {v12}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aput-object v13, v7, v2

    move-object/from16 v2, v19

    move-object/from16 v10, v20

    move-object/from16 v5, v21

    const/4 v7, 0x1

    const/4 v8, 0x0

    move-object/from16 v25, v6

    move v6, v1

    move-object/from16 v1, v25

    goto/16 :goto_6

    :cond_1a
    move-object/from16 v21, v5

    move/from16 v22, v6

    move-object v6, v1

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move/from16 v6, v22

    :goto_15
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_27

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    iget-object v3, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v3}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v3

    if-nez v3, :cond_1b

    const/4 v5, 0x0

    goto :goto_16

    :cond_1b
    iget-wide v10, v3, Lc/S5;->a:D

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    :goto_16
    if-nez v3, :cond_1c

    iget v10, v2, Lc/i6;->o:I

    :goto_17
    invoke-static {v10}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v10

    goto :goto_18

    :cond_1c
    invoke-virtual {v3, v2}, Lc/S5;->a(Lc/i6;)I

    move-result v10

    goto :goto_17

    :goto_18
    invoke-virtual {v14, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_1d

    move-object v10, v13

    :cond_1d
    if-eqz v3, :cond_1f

    if-nez v5, :cond_1e

    goto :goto_19

    :cond_1e
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v11

    invoke-virtual {v2, v11, v12}, Lc/i6;->f(D)Ljava/lang/String;

    move-result-object v3

    goto :goto_1a

    :cond_1f
    :goto_19
    const/4 v3, 0x0

    :goto_1a
    if-eqz v5, :cond_24

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v11

    invoke-static {v11, v12}, Ljava/lang/Double;->isFinite(D)Z

    move-result v11

    if-nez v11, :cond_20

    goto :goto_1c

    :cond_20
    if-eqz v3, :cond_21

    goto :goto_1d

    :cond_21
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v11

    invoke-static {v11, v12}, Ljava/lang/Math;->abs(D)D

    move-result-wide v11

    const-wide v19, 0x408f400000000000L    # 1000.0

    cmpl-double v3, v11, v19

    if-ltz v3, :cond_22

    const/4 v3, 0x0

    goto :goto_1b

    :cond_22
    cmpl-double v3, v11, v17

    if-ltz v3, :cond_23

    const/4 v3, 0x1

    goto :goto_1b

    :cond_23
    const/4 v3, 0x2

    :goto_1b
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v11

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    filled-new-array {v5}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v11, v3, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    goto :goto_1d

    :cond_24
    :goto_1c
    move-object/from16 v3, v16

    :goto_1d
    iget-object v2, v2, Lc/i6;->a:Ljava/lang/String;

    move-object/from16 v5, v21

    invoke-virtual {v5, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v3, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_26

    invoke-virtual {v9, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_25

    goto :goto_1e

    :cond_25
    const/4 v11, 0x0

    goto :goto_1f

    :cond_26
    :goto_1e
    const/4 v11, 0x1

    :goto_1f
    or-int/2addr v6, v11

    invoke-interface {v5, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v9, v2, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v21, v5

    goto/16 :goto_15

    :cond_27
    return v6
.end method

.method public final k(Ljava/lang/Object;Z)V
    .locals 3

    iget-object v0, p0, Lc/G0;->A:Ljava/lang/Object;

    if-ne v0, p1, :cond_1

    iget-boolean v0, p0, Lc/G0;->B:Z

    if-ne v0, p2, :cond_1

    if-eqz p2, :cond_0

    iget v0, p0, Lc/G0;->C:I

    iget v1, p0, Lc/G0;->F:I

    if-ne v0, v1, :cond_1

    iget-object v0, p0, Lc/G0;->D:Ljava/lang/String;

    iget-object v1, p0, Lc/G0;->w:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    return-void

    :cond_1
    iput-object p1, p0, Lc/G0;->A:Ljava/lang/Object;

    iput-boolean p2, p0, Lc/G0;->B:Z

    iget v0, p0, Lc/G0;->F:I

    iput v0, p0, Lc/G0;->C:I

    iget-object v0, p0, Lc/G0;->w:Ljava/lang/String;

    iput-object v0, p0, Lc/G0;->D:Ljava/lang/String;

    iget-object v0, p0, Lc/G0;->c:Lc/T5;

    if-nez p2, :cond_2

    invoke-virtual {v0, p1}, Lc/T5;->n0(Ljava/lang/Object;)V

    return-void

    :cond_2
    new-instance p2, Ljava/util/LinkedHashSet;

    invoke-direct {p2}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Lc/G0;->f:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/F0;

    iget v2, v2, Lc/F0;->d:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {p2, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v0, p1, p2}, Lc/T5;->r0(Ljava/lang/Object;Ljava/util/LinkedHashSet;)V

    return-void
.end method

.method public final l()V
    .locals 6

    iget-object v0, p0, Lc/G0;->c:Lc/T5;

    iget-object v1, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "enabled"

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/T5;->E()V

    goto :goto_0

    :cond_0
    const-string v1, "address"

    const-string v2, ""

    iget-object v4, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v4, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v2

    const-string v5, "ble"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v2

    const-string v5, "spp"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    :cond_1
    invoke-static {v1}, Landroid/bluetooth/BluetoothAdapter;->checkBluetoothAddress(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_2

    iget-object v0, p0, Lc/G0;->a:Landroid/app/Activity;

    const-string v1, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u0434\u0430\u043f\u0442\u0435\u0440 \u0432 \u0440\u0430\u0437\u0434\u0435\u043b\u0435 OBD"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    const-string v2, "name"

    invoke-interface {v4, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lc/T5;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    invoke-virtual {p0, v3}, Lc/G0;->j(Z)Z

    return-void
.end method
