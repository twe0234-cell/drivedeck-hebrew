.class public final synthetic Lc/i0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/i0;->a:I

    iput-object p1, p0, Lc/i0;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/i0;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    iget p1, p0, Lc/i0;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/i0;->b:Ljava/lang/Object;

    check-cast p1, Lc/H6;

    iget-boolean v0, p1, Lc/H6;->P:Z

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p1, Lc/H6;->w:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->z()I

    move-result v1

    iget-object v2, p0, Lc/i0;->c:Ljava/lang/Object;

    check-cast v2, Lc/F0;

    if-eqz p2, :cond_1

    invoke-virtual {v2}, Lc/F0;->a()I

    move-result p2

    or-int/2addr p2, v1

    goto :goto_0

    :cond_1
    invoke-virtual {v2}, Lc/F0;->a()I

    move-result p2

    not-int p2, p2

    and-int/2addr p2, v1

    :goto_0
    invoke-virtual {v0, p2}, Lc/n1;->N0(I)V

    iget-object p2, p1, Lc/H6;->c:Lc/T5;

    invoke-virtual {p2}, Lc/T5;->q()V

    invoke-virtual {p1}, Lc/H6;->A()V

    :goto_1
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/i0;->b:Ljava/lang/Object;

    check-cast p1, Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object v0, p0, Lc/i0;->c:Ljava/lang/Object;

    check-cast v0, Lc/a;

    iget-object v0, v0, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {p1, p2, v0}, Lc/n1;->K0(ZLjava/lang/String;)V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/i0;->b:Ljava/lang/Object;

    check-cast p1, Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "obd_widget_compact_readings"

    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object p1, p0, Lc/i0;->c:Ljava/lang/Object;

    check-cast p1, Ljava/util/function/BooleanSupplier;

    invoke-interface {p1}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/i0;->b:Ljava/lang/Object;

    check-cast p1, Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "clock_status_visible"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/i0;->c:Ljava/lang/Object;

    check-cast p1, Lc/J1;

    invoke-virtual {p1}, Lc/J1;->run()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
