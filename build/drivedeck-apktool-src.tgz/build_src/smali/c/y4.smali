.class public final synthetic Lc/y4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/y4;->a:I

    iput-object p1, p0, Lc/y4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 13

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget v2, p0, Lc/y4;->a:I

    check-cast p1, Ljava/lang/Boolean;

    packed-switch v2, :pswitch_data_0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/y4;->b:Lru/drivedeck/launcher/MainActivity;

    if-nez p1, :cond_0

    const-string p1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_0
    return-void

    :pswitch_0
    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/y4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_1

    const-string p1, "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440 \u043d\u0435 \u043f\u0440\u0438\u043d\u0438\u043c\u0430\u0435\u0442 \u044d\u0442\u0443 \u043a\u043e\u043c\u0430\u043d\u0434\u0443"

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    :cond_1
    return-void

    :pswitch_1
    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/y4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_6

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_3

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v2, :cond_3

    invoke-virtual {v2}, Lc/Q3;->I()V

    :cond_3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_4

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v2, :cond_4

    invoke-virtual {v2}, Lc/m2;->C()V

    :cond_4
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_5

    const-string p1, "\u041e\u0431\u043e\u0438 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u044b"

    goto :goto_1

    :cond_5
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435"

    :goto_1
    invoke-static {v0, p1, v0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :cond_6
    :goto_2
    return-void

    :pswitch_2
    sget v2, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v4, p0, Lc/y4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v4}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_c

    invoke-virtual {v4}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_7

    goto/16 :goto_7

    :cond_7
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_8

    const-string p1, "\u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0430 \u043e\u0442\u0447\u0451\u0442\u043e\u0432 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0430"

    goto :goto_3

    :cond_8
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u043e\u0442\u0447\u0451\u0442\u044b"

    :goto_3
    invoke-static {v4, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    invoke-virtual {v4}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/high16 v2, 0x41000000    # 8.0f

    invoke-static {v4, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    const/high16 v3, 0x42400000    # 48.0f

    mul-float/2addr p1, v3

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {v4}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v3

    invoke-static {v4}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v6

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-static {v4, v6, v5}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v8, "\u0421\u043e\u0431\u0438\u0440\u0430\u044e\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u0442\u0435\u0445\u043d\u0438\u0447\u0435\u0441\u043a\u0438\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u043e \u0440\u0430\u0431\u043e\u0442\u0435 DriveDeck. \u041e\u0442\u0447\u0451\u0442\u044b \u0448\u0438\u0444\u0440\u0443\u044e\u0442\u0441\u044f \u043d\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435; \u0441\u043d\u0438\u043c\u043a\u0438 \u044d\u043a\u0440\u0430\u043d\u0430, \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f \u0438 \u043c\u0430\u0440\u0448\u0440\u0443\u0442\u044b \u043d\u0435 \u0441\u043e\u0431\u0438\u0440\u0430\u044e\u0442\u0441\u044f."

    invoke-static {v4, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v8, v3, Lc/r4;->e:I

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x0

    const v10, 0x3f8ccccd    # 1.1f

    invoke-virtual {v7, v9, v10}, Landroid/widget/TextView;->setLineSpacing(FF)V

    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v7, Landroid/widget/Switch;

    invoke-direct {v7, v4}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v9, "\u0421\u0431\u043e\u0440 \u0438 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0430 \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0438"

    invoke-static {v4, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v9, v3, Lc/r4;->d:I

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextColor(I)V

    sget-object v9, Lc/N1;->X:Lc/N1;

    if-eqz v9, :cond_9

    sget-object v9, Lc/N1;->X:Lc/N1;

    iget-boolean v9, v9, Lc/N1;->K:Z

    if-eqz v9, :cond_9

    move v9, v1

    goto :goto_4

    :cond_9
    move v9, v0

    :goto_4
    invoke-virtual {v7, v9}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-virtual {v7, v0, v2, v0, v2}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v7, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-static {v7, v3}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    new-instance v9, Lc/O1;

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v7, v9}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, v4}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget v9, v3, Lc/r4;->e:I

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v7, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v4}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v8

    const-string v10, "\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u0432\u0441\u0435 \u043d\u0430\u043a\u043e\u043f\u043b\u0435\u043d\u043d\u044b\u0435 \u043e\u0442\u0447\u0451\u0442\u044b"

    invoke-static {v4, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v8}, Lc/G8;->r(Landroid/widget/TextView;)V

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setAllCaps(Z)V

    new-instance v10, Landroid/content/res/ColorStateList;

    const v11, -0x101009e

    filled-new-array {v11}, [I

    move-result-object v11

    new-array v12, v0, [I

    filled-new-array {v11, v12}, [[I

    move-result-object v11

    iget v12, v3, Lc/r4;->g:I

    filled-new-array {v9, v12}, [I

    move-result-object v9

    invoke-direct {v10, v11, v9}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v8, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-static {v8, v3, v1}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance v3, Lc/l;

    const/4 v9, 0x3

    invoke-direct {v3, v8, v7, v4, v9}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v8, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v4}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v3

    const-string v9, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u043a\u043e\u043f\u043b\u0435\u043d\u043d\u044b\u0435 \u043e\u0442\u0447\u0451\u0442\u044b \u0432 \u0444\u0430\u0439\u043b"

    invoke-static {v4, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v3}, Lc/G8;->r(Landroid/widget/TextView;)V

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setAllCaps(Z)V

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance p1, Lc/c;

    const/4 v9, 0x6

    invoke-direct {p1, v4, v9}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move p1, v1

    :goto_5
    invoke-virtual {v5}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge p1, v3, :cond_a

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v10, -0x2

    invoke-direct {v3, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iput v2, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    add-int/2addr p1, v1

    goto :goto_5

    :cond_a
    new-instance v3, Landroid/app/Dialog;

    invoke-direct {v3, v4}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const-string p1, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    invoke-static {v4, p1, v1}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    new-instance v2, Lc/a0;

    const/4 v5, 0x5

    invoke-direct {v2, v3, v5}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v5

    invoke-direct {v2, v5}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v10, Lc/P1;

    invoke-direct {v10, v7, v4, v8, v2}, Lc/P1;-><init>(Landroid/widget/TextView;Landroid/app/Activity;Landroid/widget/Button;Landroid/os/Handler;)V

    new-instance v5, Lc/c1;

    invoke-direct {v5, v2, v10, v1}, Lc/c1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v5}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-static {}, Lc/N1;->B()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {}, Lc/N1;->s()I

    move-result v2

    if-lez v2, :cond_b

    invoke-static {}, Lc/N1;->p()Z

    move-result v2

    if-nez v2, :cond_b

    invoke-static {}, Lc/N1;->o()Z

    move-result v2

    if-nez v2, :cond_b

    move v2, v1

    goto :goto_6

    :cond_b
    move v2, v0

    :goto_6
    invoke-virtual {v8, v2}, Landroid/view/View;->setEnabled(Z)V

    new-array v1, v1, [Landroid/view/View;

    aput-object p1, v1, v0

    invoke-static {v4, v1}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v7

    new-instance v8, Lc/i;

    const/4 p1, 0x4

    invoke-direct {v8, v3, p1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    const/4 v9, 0x1

    const-string v5, "\u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0430 DriveDeck"

    invoke-static/range {v3 .. v9}, Lc/G8;->J0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Ljava/lang/Runnable;Z)V

    invoke-virtual {v10}, Lc/P1;->run()V

    :cond_c
    :goto_7
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
