.class public final Lc/k3;
.super Landroid/app/Dialog;
.source "SourceFile"


# static fields
.field public static final M:[I

.field public static final N:[Ljava/lang/String;

.field public static final O:[Ljava/lang/String;

.field public static final P:[Ljava/lang/String;

.field public static final Q:[I


# instance fields
.field public A:Ljava/util/ArrayList;

.field public B:Ljava/lang/String;

.field public C:Landroid/widget/LinearLayout;

.field public D:Landroid/widget/TextView;

.field public E:Landroid/widget/Switch;

.field public F:Landroid/widget/Switch;

.field public G:Z

.field public H:I

.field public I:I

.field public J:Z

.field public K:Z

.field public L:Z

.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Lc/z;

.field public final c:Lc/n1;

.field public final d:Lc/u0;

.field public final e:Ljava/util/ArrayList;

.field public final f:I

.field public g:Lc/r4;

.field public h:Ljava/lang/String;

.field public i:Landroid/widget/LinearLayout;

.field public j:Landroid/widget/LinearLayout;

.field public k:Landroid/widget/LinearLayout;

.field public l:Lc/c0;

.field public final m:[Landroid/view/View;

.field public n:Landroid/animation/ValueAnimator;

.field public o:Z

.field public p:Ljava/lang/String;

.field public q:I

.field public r:I

.field public s:I

.field public t:Z

.field public final u:Ljava/util/HashMap;

.field public v:Ljava/lang/String;

.field public w:Ljava/lang/String;

.field public x:F

.field public y:I

.field public z:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    const/4 v0, 0x0

    const/16 v1, 0xc

    new-array v2, v1, [I

    fill-array-data v2, :array_0

    sput-object v2, Lc/k3;->M:[I

    sget-object v3, Ld/a;->j:[Ljava/lang/String;

    invoke-virtual {v3}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    invoke-static {v3}, Lc/k3;->I([Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lc/k3;->N:[Ljava/lang/String;

    sget-object v3, Ld/a;->k:[Ljava/lang/String;

    invoke-virtual {v3}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    invoke-static {v3}, Lc/k3;->I([Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lc/k3;->O:[Ljava/lang/String;

    const-string v12, "\u0414\u043e\u0441\u0442\u0443\u043f \u043a \u0444\u0443\u043d\u043a\u0446\u0438\u044f\u043c"

    const-string v13, "\u0423\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e \u0438 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    const-string v4, "\u0411\u044b\u0441\u0442\u0440\u044b\u0439 \u0434\u043e\u0441\u0442\u0443\u043f"

    const-string v5, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0438 \u043f\u0430\u0440\u044b"

    const-string v6, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432 \u043c\u0435\u043d\u044e"

    const-string v7, "\u0421\u0442\u0438\u043b\u044c, \u0442\u0435\u043c\u0430, \u043e\u0431\u043e\u0438"

    const-string v8, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u0438 \u0438 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435"

    const-string v9, "\u0414\u0430\u043d\u043d\u044b\u0435 \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f"

    const-string v10, "\u0410\u043a\u0442\u0438\u0432\u0430\u0446\u0438\u044f \u0438 \u043a\u043e\u043c\u0430\u043d\u0434\u044b"

    const-string v11, "\u0412\u044b\u0431\u043e\u0440 \u044f\u0437\u044b\u043a\u0430"

    const-string v14, "\u041f\u043e\u0434\u0441\u043a\u0430\u0437\u043a\u0438 \u0438 \u0441\u043e\u0432\u0435\u0442\u044b"

    const-string v15, "\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f"

    filled-new-array/range {v4 .. v15}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lc/k3;->I([Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lc/k3;->P:[Ljava/lang/String;

    new-array v3, v1, [I

    fill-array-data v3, :array_1

    new-array v4, v1, [I

    :goto_0
    if-ge v0, v1, :cond_0

    aget v5, v2, v0

    aget v5, v3, v5

    aput v5, v4, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    sput-object v4, Lc/k3;->Q:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x9
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
        0xb
        0x7
        0xa
        0x8
    .end array-data

    :array_1
    .array-data 4
        0x7f030049
        0x7f03004b
        0x7f030045
        0x7f03004f
        0x7f03004e
        0x7f030046
        0x7f03004d
        0x7f030047
        0x7f03004a
        0x7f030051
        0x7f030052
        0x7f030048
    .end array-data
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Ljava/util/ArrayList;ILc/u0;)V
    .locals 3

    const v0, 0x103022e

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const-string v0, "updates"

    iput-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    sget-object v0, Lc/k3;->N:[Ljava/lang/String;

    array-length v0, v0

    new-array v0, v0, [Landroid/view/View;

    iput-object v0, p0, Lc/k3;->m:[Landroid/view/View;

    const/4 v0, -0x1

    iput v0, p0, Lc/k3;->q:I

    iput v0, p0, Lc/k3;->r:I

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iput-object v1, p0, Lc/k3;->u:Ljava/util/HashMap;

    const-string v1, ""

    iput-object v1, p0, Lc/k3;->v:Ljava/lang/String;

    iput-object v1, p0, Lc/k3;->w:Ljava/lang/String;

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Lc/k3;->x:F

    const/16 v2, 0x64

    iput v2, p0, Lc/k3;->y:I

    iput v2, p0, Lc/k3;->z:I

    iput-object v1, p0, Lc/k3;->B:Ljava/lang/String;

    iput v0, p0, Lc/k3;->H:I

    iput v0, p0, Lc/k3;->I:I

    iput-object p1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/k3;->b:Lc/z;

    iput-object p5, p0, Lc/k3;->d:Lc/u0;

    const/4 p2, 0x1

    invoke-static {p2, p4}, Ljava/lang/Math;->max(II)I

    move-result p4

    iput p4, p0, Lc/k3;->f:I

    new-instance p4, Ljava/util/ArrayList;

    invoke-direct {p4, p3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object p4, p0, Lc/k3;->e:Ljava/util/ArrayList;

    new-instance p3, Lc/n1;

    invoke-direct {p3, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, Lc/k3;->c:Lc/n1;

    invoke-virtual {p4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput p1, p0, Lc/k3;->q:I

    invoke-virtual {p0, p2}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    if-eqz p1, :cond_1

    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setLayout(II)V

    :cond_1
    invoke-virtual {p0}, Lc/k3;->X()V

    return-void
.end method

.method public static I([Ljava/lang/String;)[Ljava/lang/String;
    .locals 5

    sget-object v0, Lc/k3;->M:[I

    const/16 v1, 0xc

    new-array v2, v1, [Ljava/lang/String;

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_0

    aget v4, v0, v3

    aget-object v4, p0, v4

    aput-object v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-object v2
.end method

.method public static V(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    :goto_0
    instance-of v0, p0, Landroid/view/View;

    if-eqz v0, :cond_1

    instance-of v0, p0, Landroid/widget/ScrollView;

    if-eqz v0, :cond_0

    check-cast p0, Landroid/widget/ScrollView;

    goto :goto_1

    :cond_0
    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_1
    if-nez p0, :cond_2

    goto :goto_2

    :cond_2
    const-string v0, "pairs"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    goto :goto_2

    :cond_3
    const-string v0, "dock"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    :cond_4
    :goto_2
    return-void
.end method

.method public static h(Landroid/view/View;)V
    .locals 2

    new-instance v0, Lc/e3;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc/e3;-><init>(I)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    return-void
.end method

.method public static j(Landroid/view/View;)V
    .locals 2

    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    instance-of v0, p0, Landroid/widget/Button;

    if-nez v0, :cond_0

    instance-of v0, p0, Landroid/widget/Switch;

    if-nez v0, :cond_0

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    if-nez v0, :cond_1

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    new-instance v0, Lc/Z2;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/Z2;-><init>(Landroid/widget/TextView;I)V

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    goto :goto_1

    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Lc/k3;->j(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public static l0(Ljava/lang/String;)I
    .locals 4

    const-string v0, "home_apps"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "home"

    :cond_0
    const-string v0, "pairs"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p0, "dock"

    :cond_1
    const/4 v0, 0x0

    move v1, v0

    :goto_0
    sget-object v2, Lc/k3;->N:[Ljava/lang/String;

    array-length v3, v2

    if-ge v1, v3, :cond_3

    aget-object v2, v2, v1

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    return v1

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    return v0
.end method

.method public static p0(Landroid/view/View;Ljava/lang/Runnable;)V
    .locals 3

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const v1, 0x3f75c28f    # 0.96f

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0x50

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Lc/H;

    const/16 v2, 0xa

    invoke-direct {v1, p0, p1, v2}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static z(Landroid/widget/TextView;I)V
    .locals 3

    int-to-float v0, p1

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v1, 0xb

    if-le p1, v1, :cond_0

    const v2, 0x3f4ccccd    # 0.8f

    mul-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v0, p1, v1, v2}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 3

    const/16 v0, 0xe

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v0, 0x41000000    # 8.0f

    invoke-virtual {p0, v0}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v0}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {p1, v1, v2, v1, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p1
.end method

.method public final A0(Ljava/lang/String;I)Landroid/widget/ImageButton;
    .locals 5

    new-instance v0, Landroid/widget/ImageButton;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object p2, p0, Lc/k3;->g:Lc/r4;

    iget p2, p2, Lc/r4;->d:I

    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    iget-object p2, p0, Lc/k3;->g:Lc/r4;

    invoke-static {p2}, Lc/G8;->V0(Lc/r4;)I

    move-result p2

    invoke-virtual {p0, p2}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 p2, 0x41400000    # 12.0f

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result p2

    invoke-virtual {v0, v2, v3, v4, p2}, Landroid/view/View;->setPadding(IIII)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    invoke-static {v0}, Lc/k3;->h(Landroid/view/View;)V

    return-object v0
.end method

.method public final B(I)Landroid/widget/LinearLayout;
    .locals 18

    move-object/from16 v0, p0

    move/from16 v1, p1

    iget-object v2, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->e(I)Lc/n1;

    move-result-object v3

    if-nez v1, :cond_0

    const-string v4, "\u041e\u043a\u043d\u043e 1"

    goto :goto_0

    :cond_0
    const-string v4, "\u041e\u043a\u043d\u043e 2"

    :goto_0
    const-string v5, ""

    const v6, 0x7f03008f

    invoke-virtual {v0, v6, v4, v5}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    if-nez v1, :cond_1

    invoke-virtual {v3}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_1
    invoke-virtual {v3}, Lc/n1;->F()Ljava/lang/String;

    move-result-object v6

    :goto_1
    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v9, v0, Lc/k3;->b:Lc/z;

    const/4 v10, 0x4

    if-nez v1, :cond_6

    invoke-virtual {v2, v7}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v2, v8}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v6, v11, v12}, Lc/k3;->F(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_6

    invoke-virtual {v2, v7}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v8}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v2

    const-string v11, "com.google.android.apps.maps"

    const-string v12, "ru.dublgis.dgismobile"

    const-string v13, "ru.yandex.yandexnavi"

    const-string v14, "ru.yandex.yandexmaps"

    filled-new-array {v13, v14, v11, v12}, [Ljava/lang/String;

    move-result-object v11

    move v12, v7

    :goto_2
    if-ge v12, v10, :cond_3

    aget-object v13, v11, v12

    invoke-virtual {v0, v13, v6, v2}, Lc/k3;->F(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_2

    move-object v6, v13

    goto :goto_3

    :cond_2
    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_3
    invoke-virtual {v9}, Lc/z;->c()Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_4
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_5

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/a;

    iget-object v13, v12, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v13, v6, v2}, Lc/k3;->F(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_4

    iget-object v2, v12, Lc/a;->a:Ljava/lang/String;

    move-object v6, v2

    goto :goto_3

    :cond_5
    move-object v6, v5

    :cond_6
    :goto_3
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/high16 v11, 0x41400000    # 12.0f

    invoke-virtual {v0, v11}, Lc/k3;->x(F)I

    move-result v12

    const/high16 v13, 0x41000000    # 8.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v0, v11}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v2, v12, v14, v15, v8}, Landroid/view/View;->setPadding(IIII)V

    const/high16 v8, 0x42600000    # 56.0f

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v2, v8}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v8, v0, Lc/k3;->g:Lc/r4;

    iget v8, v8, Lc/r4;->b:I

    invoke-virtual {v0, v8}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v9, v6}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v8

    if-eqz v8, :cond_7

    const/16 v8, 0x20

    invoke-virtual {v0, v6, v8}, Lc/k3;->C(Ljava/lang/String;I)Lc/f3;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_7
    invoke-virtual {v9, v6}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v8

    if-nez v8, :cond_8

    const-string v6, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    goto :goto_4

    :cond_8
    invoke-virtual {v0, v6}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_4
    const/16 v8, 0x10

    invoke-virtual {v0, v8, v6, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    const/4 v8, 0x2

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x2

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v9, v7, v12, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v11}, Lc/k3;->x(F)I

    move-result v12

    iput v12, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v11}, Lc/k3;->x(F)I

    move-result v11

    iput v11, v9, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v2, v6, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v9, "\u203a"

    const/16 v11, 0x16

    invoke-virtual {v0, v11, v9, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9, v8}, Landroid/view/View;->setImportantForAccessibility(I)V

    invoke-virtual {v2, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v9, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v11, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0432 \u043e\u043a\u043d\u0435: "

    invoke-static {v9, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v6, Lc/G2;

    invoke-direct {v6, v1, v3, v0}, Lc/G2;-><init>(ILc/n1;Lc/k3;)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {v2}, Lc/k3;->h(Landroid/view/View;)V

    const/16 v1, 0x8

    invoke-virtual {v0, v4, v2, v1, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v2, "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442\u0441\u044f \u0432 \u0432\u0438\u0434\u0436\u0435\u0442\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u043d\u0430 \u0433\u043b\u0430\u0432\u043d\u043e\u043c \u044d\u043a\u0440\u0430\u043d\u0435."

    invoke-virtual {v0, v2}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v9}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v6, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u043f\u043e\u043b\u043e\u0441\u0443"

    invoke-static {v9, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v6, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v6}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v6, "home_window_bar_visible"

    invoke-virtual {v3, v6}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v8, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v8, Landroid/content/SharedPreferences;

    invoke-interface {v8, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    invoke-virtual {v2, v6}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v6, Lc/H2;

    const/4 v11, 0x0

    invoke-direct {v6, v11, v3, v0}, Lc/H2;-><init>(ILc/n1;Lc/k3;)V

    invoke-virtual {v2, v6}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v0, v4, v2, v1, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v0, v4}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v2, "\u041a\u0440\u0430\u0439 \u043e\u043a\u043d\u0430"

    const v6, 0x7f03004c

    invoke-virtual {v0, v6, v2, v5}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v2, v7}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v2, v7, v7, v7, v7}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v5

    const/high16 v6, 0x40800000    # 4.0f

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v5, v11, v12, v15, v1}, Landroid/view/View;->setPadding(IIII)V

    iget-object v1, v0, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->b:I

    const/16 v11, 0x3e8

    invoke-virtual {v0, v1, v11}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v1, "always"

    const-string v11, "off"

    const-string v12, "driving"

    filled-new-array {v12, v1, v11}, [Ljava/lang/String;

    move-result-object v1

    const-string v11, "\u0412\u044b\u043a\u043b."

    const-string v15, "\u0412 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0438"

    const-string v10, "\u0412\u0441\u0435\u0433\u0434\u0430"

    filled-new-array {v15, v10, v11}, [Ljava/lang/String;

    move-result-object v10

    move v11, v7

    :goto_5
    const/4 v15, 0x3

    if-ge v11, v15, :cond_a

    aget-object v15, v1, v11

    const-string v14, "home_edges"

    invoke-virtual {v3, v14}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v8, v14, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v15, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    aget-object v7, v10, v11

    new-instance v13, Lc/Z;

    const/4 v6, 0x6

    invoke-direct {v13, v0, v3, v15, v6}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v7, v14, v13}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v6

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v13

    move-object/from16 v16, v1

    const/high16 v15, 0x41000000    # 8.0f

    invoke-virtual {v0, v15}, Lc/k3;->x(F)I

    move-result v1

    move-object/from16 v17, v10

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v10

    invoke-virtual {v0, v15}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v6, v13, v1, v10, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {v6, v14}, Landroid/widget/TextView;->setSelected(Z)V

    iget-object v1, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v6, v1, v14}, Lc/G8;->B0(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42400000    # 48.0f

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v7

    const/4 v10, 0x0

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v1, v10, v7, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v11, :cond_9

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v10

    iput v10, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_9
    invoke-virtual {v5, v6, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v11, v11, 0x1

    move v14, v13

    move v13, v15

    move-object/from16 v1, v16

    move-object/from16 v10, v17

    const/high16 v6, 0x40800000    # 4.0f

    const/4 v7, 0x0

    goto :goto_5

    :cond_a
    const/4 v1, 0x4

    const/16 v6, 0x8

    invoke-virtual {v0, v2, v5, v6, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v9}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v5, "\u0420\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u044b\u0432\u0430\u0442\u044c \u0432\u0441\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v9, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v5, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v5}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v5, "home_edge_fade_all_apps"

    invoke-virtual {v3, v5}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    invoke-interface {v8, v5, v6}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    invoke-virtual {v1, v5}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v5, Lc/H2;

    const/4 v6, 0x1

    invoke-direct {v5, v6, v3, v0}, Lc/H2;-><init>(ILc/n1;Lc/k3;)V

    invoke-virtual {v1, v5}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v5, 0x4

    const/16 v6, 0x8

    invoke-virtual {v0, v2, v1, v6, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v9}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3}, Lc/n1;->h0()Z

    move-result v5

    if-eqz v5, :cond_b

    const-string v5, "\u041e\u0432\u0430\u043b"

    goto :goto_6

    :cond_b
    const-string v5, "\u041f\u0440\u044f\u043c\u043e\u0443\u0433\u043e\u043b\u044c\u043d\u0438\u043a"

    :goto_6
    invoke-static {v9, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v5, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v5}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v3}, Lc/n1;->h0()Z

    move-result v5

    invoke-virtual {v1, v5}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v5, Lc/w0;

    invoke-direct {v5, v0, v3, v1}, Lc/w0;-><init>(Lc/k3;Lc/n1;Landroid/widget/Switch;)V

    invoke-virtual {v1, v5}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v5, 0x4

    const/16 v6, 0x8

    invoke-virtual {v0, v2, v1, v6, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v3}, Lc/n1;->q()I

    move-result v1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438"

    invoke-static {v9, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " \u2014 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "%"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0xf

    const/4 v7, 0x1

    invoke-virtual {v0, v6, v5, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    const/4 v6, 0x0

    const/16 v7, 0x8

    invoke-virtual {v0, v2, v5, v7, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v6, Landroid/widget/SeekBar;

    invoke-direct {v6, v9}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x7d

    invoke-virtual {v6, v7}, Landroid/widget/ProgressBar;->setMax(I)V

    add-int/lit8 v1, v1, -0x19

    invoke-virtual {v6, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const-string v1, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438 \u043e\u043a\u043d\u0430 \u043e\u0442 25 \u0434\u043e 150 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u043e\u0432"

    invoke-static {v9, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x42400000    # 48.0f

    invoke-virtual {v0, v1}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v7, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v6, v7}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v7, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v5, v7}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    new-instance v7, Lc/N3;

    invoke-direct {v7, v0, v5, v3}, Lc/N3;-><init>(Lc/k3;Landroid/widget/TextView;Lc/n1;)V

    invoke-virtual {v6, v7}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    invoke-virtual {v0, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-direct {v3, v5, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x40800000    # 4.0f

    invoke-virtual {v0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v2, v6, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u2014 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0430 \u0442\u043e\u043b\u044c\u043a\u043e \u0434\u043b\u044f \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u043e\u0432. \u0412\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u2014 \u0434\u043b\u044f \u043b\u044e\u0431\u043e\u0433\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432 \u043e\u043a\u043d\u0435 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430. \u0412 split-\u0440\u0435\u0436\u0438\u043c\u0435 \u043a\u0440\u0430\u044f \u043e\u0441\u0442\u0430\u044e\u0442\u0441\u044f \u0447\u0451\u0442\u043a\u0438\u043c\u0438. \u041f\u043e\u0441\u043b\u0435 \u043a\u0430\u0441\u0430\u043d\u0438\u044f \u043a\u0440\u0430\u044f \u043e\u0441\u0442\u0430\u044e\u0442\u0441\u044f \u0447\u0451\u0442\u043a\u0438\u043c\u0438 10 \u0441\u0435\u043a\u0443\u043d\u0434."

    invoke-virtual {v0, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v1, 0xc

    const/4 v3, 0x0

    invoke-virtual {v0, v4, v2, v1, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    return-object v4
.end method

.method public final C(Ljava/lang/String;I)Lc/f3;
    .locals 3

    invoke-static {p1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/k3;->b:Lc/z;

    invoke-virtual {v1, v0}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-static {p1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    new-instance v1, Lc/f3;

    iget-object v2, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v1, p0, v2, v0, p1}, Lc/f3;-><init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;Lc/a;Lc/a;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p2, p2

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result p2

    invoke-direct {p1, v0, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x2

    invoke-virtual {v1, p1}, Landroid/view/View;->setImportantForAccessibility(I)V

    return-object v1
.end method

.method public final D()Landroid/widget/LinearLayout$LayoutParams;
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x42400000    # 48.0f

    invoke-virtual {p0, v1}, Lc/k3;->o(F)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/k3;->o(F)I

    move-result v1

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    return-object v0
.end method

.method public final E(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 1

    invoke-virtual {p0, p1}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p1

    sget-object v0, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {p1, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    return-object p1
.end method

.method public final F(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 1

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-static {v0}, Lc/n1;->Z0(I)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_1

    :cond_0
    iget-object p2, p0, Lc/k3;->b:Lc/z;

    invoke-virtual {p2, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p1

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final G(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " + "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    iget-object v0, p0, Lc/k3;->b:Lc/z;

    invoke-virtual {v0, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object p1, v0, Lc/a;->b:Ljava/lang/String;

    :goto_0
    return-object p1
.end method

.method public final H()Landroid/view/View;
    .locals 2

    new-instance v0, Landroid/view/View;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    invoke-virtual {v1}, Lc/r4;->a()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    return-object v0
.end method

.method public final J(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x0

    invoke-static {v0, p1, v0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void
.end method

.method public final K(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    iget-object v0, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v1

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p2

    if-ltz v1, :cond_3

    if-ltz p2, :cond_3

    if-ne v1, p2, :cond_0

    goto :goto_2

    :cond_0
    iget v2, p0, Lc/k3;->r:I

    const/4 v3, 0x0

    if-ltz v2, :cond_1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    goto :goto_0

    :cond_1
    move-object v2, v3

    :goto_0
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    invoke-virtual {v0, p2, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    if-nez v2, :cond_2

    const/4 p2, -0x1

    goto :goto_1

    :cond_2
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p2

    :goto_1
    iput p2, p0, Lc/k3;->r:I

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    iput p1, p0, Lc/k3;->q:I

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/k3;->t:Z

    iput-object v3, p0, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {p0}, Lc/k3;->l()V

    invoke-virtual {p0}, Lc/k3;->S()V

    :cond_3
    :goto_2
    return-void
.end method

.method public final L(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/Runnable;)Landroid/widget/LinearLayout;
    .locals 10

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v3

    const/16 v4, 0x10

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v5

    const/high16 v6, 0x40c00000    # 6.0f

    invoke-virtual {p0, v6}, Lc/k3;->x(F)I

    move-result v7

    const/high16 v8, 0x41a00000    # 20.0f

    invoke-virtual {p0, v8}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {p0, v6}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v3, v5, v7, v8, v6}, Landroid/view/View;->setPadding(IIII)V

    const/high16 v5, 0x42600000    # 56.0f

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v3, p4}, Landroid/view/View;->setSelected(Z)V

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "settings-section:"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v5, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v5, v1}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    if-eqz p4, :cond_0

    new-instance v6, Landroid/graphics/drawable/LayerDrawable;

    new-instance v7, Landroid/graphics/drawable/ColorDrawable;

    iget-object v8, p0, Lc/k3;->g:Lc/r4;

    iget v8, v8, Lc/r4;->f:I

    invoke-direct {v7, v8}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    new-array v8, v2, [Landroid/graphics/drawable/Drawable;

    aput-object v5, v8, v1

    aput-object v7, v8, v0

    invoke-direct {v6, v8}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const v5, 0x40aaaaab

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v6, v0, v5}, Landroid/graphics/drawable/LayerDrawable;->setLayerWidth(II)V

    const/16 v5, 0x73

    invoke-virtual {v6, v0, v5}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    move-object v5, v6

    :cond_0
    new-instance v6, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    new-instance v8, Landroid/graphics/drawable/ColorDrawable;

    const/4 v9, -0x1

    invoke-direct {v8, v9}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-direct {v6, v7, v5, v8}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v5, Landroid/widget/ImageView;

    iget-object v6, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v5, v6}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, p3}, Landroid/widget/ImageView;->setImageResource(I)V

    const v7, 0x3f4ccccd    # 0.8f

    invoke-virtual {v5, v7}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setScaleY(F)V

    iget-object v7, p0, Lc/k3;->g:Lc/r4;

    iget v7, v7, Lc/r4;->d:I

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-virtual {v5, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v5, v2}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42000000    # 32.0f

    invoke-virtual {p0, v7}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {p0, v7}, Lc/k3;->x(F)I

    move-result v7

    invoke-direct {p3, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v5, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object p3

    invoke-virtual {p0, v4, p1, p4}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {p3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v4, 0xd

    invoke-virtual {p0, v4, p2, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const-string v5, "settings-nav-description"

    invoke-virtual {v4, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {p3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v4, v1, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v3, p3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object p3, p0, Lc/k3;->c:Lc/n1;

    invoke-virtual {p3}, Lc/n1;->g()Ljava/lang/String;

    move-result-object p3

    const-string v1, "en"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string p3, ", selected"

    goto :goto_0

    :cond_1
    const-string v1, "es"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string p3, ", seleccionado"

    goto :goto_0

    :cond_2
    const-string v1, "vi"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    const-string p3, ", \u0111\u00e3 ch\u1ecdn"

    goto :goto_0

    :cond_3
    const-string v1, "it"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_4

    const-string p3, ", selezionato"

    goto :goto_0

    :cond_4
    const-string p3, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    :goto_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v6, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v6, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p4, :cond_5

    goto :goto_1

    :cond_5
    const-string p3, ""

    :goto_1
    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v3, v0}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v3}, Lc/k3;->h(Landroid/view/View;)V

    new-instance p1, Lc/h1;

    invoke-direct {p1, p5, v2}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v3
.end method

.method public final M(Landroid/view/View;)V
    .locals 3

    instance-of v0, p1, Landroid/widget/Switch;

    if-nez v0, :cond_0

    instance-of v0, p1, Landroid/widget/Button;

    if-eqz v0, :cond_1

    :cond_0
    const/high16 v0, 0x42400000    # 48.0f

    invoke-virtual {p0, v0}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz v2, :cond_1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    iput v0, v1, Landroid/widget/LinearLayout$LayoutParams;->height:I

    invoke-virtual {p1, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/k3;->M(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final N(Landroid/content/Intent;)V
    .locals 1

    :try_start_0
    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p1, "\u042d\u0442\u043e\u0442 \u0440\u0430\u0437\u0434\u0435\u043b \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0432 \u043f\u0440\u043e\u0448\u0438\u0432\u043a\u0435"

    invoke-virtual {p0, p1}, Lc/k3;->J(Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method public final O(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 8

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3, v1, v3}, Landroid/view/View;->setPadding(IIII)V

    iget v1, p0, Lc/k3;->s:I

    const/4 v2, 0x1

    if-ne v1, p1, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    move v1, v3

    :goto_0
    if-eqz v1, :cond_1

    invoke-virtual {p0}, Lc/k3;->o0()I

    move-result v4

    goto :goto_1

    :cond_1
    iget-object v4, p0, Lc/k3;->g:Lc/r4;

    iget v4, v4, Lc/r4;->b:I

    :goto_1
    invoke-virtual {p0, v4}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2

    const/16 v4, 0x1c

    invoke-virtual {p0, p3, v4}, Lc/k3;->C(Ljava/lang/String;I)Lc/f3;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_2

    :cond_2
    const-string v4, "+"

    const/16 v5, 0x16

    invoke-virtual {p0, v5, v4, v3}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x41e00000    # 28.0f

    invoke-virtual {p0, v6}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {p0, v6}, Lc/k3;->x(F)I

    move-result v6

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_2
    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v4

    const/16 v5, 0xb

    invoke-virtual {p0, v5, p2, v3}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_3

    const-string v5, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    goto :goto_3

    :cond_3
    invoke-virtual {p0, p3}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_3
    const/16 v6, 0xe

    invoke-virtual {p0, v6, v5, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v5, v3, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v3, 0x41000000    # 8.0f

    invoke-virtual {p0, v3}, Lc/k3;->x(F)I

    move-result v3

    iput v3, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setSelected(Z)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v0}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ": "

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_4

    const-string p2, "\u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    goto :goto_4

    :cond_4
    invoke-virtual {p0, p3}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    :goto_4
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v1, :cond_5

    const-string p2, ", \u0432\u044b\u0431\u0440\u0430\u043d\u043e \u0434\u043b\u044f \u0440\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f"

    goto :goto_5

    :cond_5
    const-string p2, ""

    :goto_5
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    iget-object p3, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p3, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p2, Lc/P2;

    const/4 p3, 0x0

    invoke-direct {p2, p0, p1, p3}, Lc/P2;-><init>(Landroid/view/KeyEvent$Callback;II)V

    invoke-virtual {v0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method public final P(I)Landroid/widget/LinearLayout;
    .locals 8

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    if-nez p1, :cond_0

    iget v1, p0, Lc/k3;->y:I

    goto :goto_0

    :cond_0
    iget v1, p0, Lc/k3;->z:I

    :goto_0
    if-nez p1, :cond_1

    const-string v2, "\u0421\u043b\u0435\u0432\u0430 / \u0441\u0432\u0435\u0440\u0445\u0443"

    goto :goto_1

    :cond_1
    const-string v2, "\u0421\u043f\u0440\u0430\u0432\u0430 / \u0441\u043d\u0438\u0437\u0443"

    :goto_1
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v4, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " \u2014 "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "%"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0xe

    const/4 v6, 0x0

    invoke-virtual {p0, v5, v3, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v5, Landroid/widget/SeekBar;

    invoke-direct {v5, v4}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x46

    invoke-virtual {v5, v6}, Landroid/widget/ProgressBar;->setMax(I)V

    add-int/lit8 v1, v1, -0x32

    invoke-virtual {v5, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/high16 v1, 0x42400000    # 48.0f

    invoke-virtual {p0, v1}, Lc/k3;->o(F)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043e\u043a\u043d\u0430 "

    invoke-static {v4, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v4, p0, Lc/k3;->g:Lc/r4;

    invoke-static {v5, v4}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v4, p0, Lc/k3;->g:Lc/r4;

    invoke-static {v3, v4}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    iget-object v4, p0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v4

    const-string v6, "activity"

    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    xor-int/lit8 v4, v4, 0x1

    invoke-virtual {v5, v4}, Landroid/view/View;->setEnabled(Z)V

    new-instance v4, Lc/V2;

    invoke-direct {v4, p0, p1, v3, v2}, Lc/V2;-><init>(Lc/k3;ILandroid/widget/TextView;Ljava/lang/String;)V

    invoke-virtual {v5, v4}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-virtual {p0, v1}, Lc/k3;->o(F)I

    move-result v1

    invoke-direct {p1, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v5, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public final Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;
    .locals 8

    if-eqz p2, :cond_0

    const-string v0, "\u0414\u043e\u0441\u0442\u0443\u043f \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d"

    :goto_0
    move-object v4, v0

    goto :goto_1

    :cond_0
    const-string v0, "\u041d\u0443\u0436\u0435\u043d \u0434\u043e\u0441\u0442\u0443\u043f"

    goto :goto_0

    :goto_1
    const-string v6, "\u041d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u044c"

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v5, p3

    move-object v7, p4

    invoke-virtual/range {v1 .. v7}, Lc/k3;->R(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object p1

    return-object p1
.end method

.method public final R(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;
    .locals 2

    invoke-virtual {p0, p1}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object p1

    if-eqz p2, :cond_0

    const-string v0, "\u25cf "

    goto :goto_0

    :cond_0
    const-string v0, "\u25cb "

    :goto_0
    invoke-virtual {v0, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/16 v0, 0xf

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p3, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p3

    if-eqz p2, :cond_2

    iget-object p2, p0, Lc/k3;->g:Lc/r4;

    sget-object v0, Lc/r4;->p:Lc/r4;

    if-ne p2, v0, :cond_1

    const p2, -0xb350b0

    goto :goto_1

    :cond_1
    const p2, -0xe978d6    # -2.0008601E38f

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result p2

    :goto_1
    invoke-virtual {p3, p2}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 p2, 0x8

    invoke-virtual {p0, p1, p3, p2, p2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {p0, p4}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object p2

    const/16 p3, 0xc

    invoke-virtual {p0, p1, p2, v1, p3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    if-eqz p6, :cond_3

    const-string p2, "  \u203a"

    invoke-virtual {p5, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2, v1, p6}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p2

    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 p4, 0x42400000    # 48.0f

    invoke-virtual {p0, p4}, Lc/k3;->x(F)I

    move-result p4

    const/4 p5, -0x1

    invoke-direct {p3, p5, p4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    return-object p1
.end method

.method public final S()V
    .locals 6

    iget-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    const-string v1, "dock"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "music"

    const-string v3, "pairs"

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lc/k3;->X()V

    return-void

    :cond_0
    iget-object v0, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    instance-of v5, v0, Landroid/widget/ScrollView;

    if-eqz v5, :cond_1

    check-cast v0, Landroid/widget/ScrollView;

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v0

    goto :goto_0

    :cond_1
    move v0, v4

    :goto_0
    iget-object v5, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    iget-object v5, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    iget-object v5, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v5, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Lc/k3;->Z()V

    goto :goto_1

    :cond_2
    iget-object v1, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Lc/k3;->c0()V

    goto :goto_1

    :cond_3
    invoke-virtual {p0, v2}, Lc/k3;->Y(Ljava/lang/String;)V

    :goto_1
    invoke-virtual {p0}, Lc/k3;->a0()V

    iget-object v1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    instance-of v2, v1, Landroid/widget/ScrollView;

    if-eqz v2, :cond_4

    check-cast v1, Landroid/widget/ScrollView;

    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    new-instance v3, Lc/h3;

    invoke-direct {v3, v1, v0}, Lc/h3;-><init>(Landroid/widget/ScrollView;I)V

    invoke-virtual {v2, v3}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_4
    return-void
.end method

.method public final T()V
    .locals 4

    invoke-virtual {p0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_2

    const-string v0, "voice"

    iget-object v1, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_1

    iget-object v0, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getScrollY()I

    move-result v0

    goto :goto_0

    :cond_1
    move v0, v1

    :goto_0
    iget-object v2, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {p0}, Lc/k3;->g0()V

    iget-object v2, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    iget-object v3, p0, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->d:I

    invoke-static {v2, v3}, Lc/G8;->p(Landroid/widget/LinearLayout;I)V

    iget-object v2, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lc/w;

    const/4 v3, 0x3

    invoke-direct {v2, v1, v0, v3}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_2
    :goto_1
    return-void
.end method

.method public final U()V
    .locals 3

    iget-object v0, p0, Lc/k3;->D:Landroid/widget/TextView;

    if-eqz v0, :cond_2

    const-string v0, "voice"

    iget-object v1, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v0, :cond_2

    iget-object v1, p0, Lc/k3;->D:Landroid/widget/TextView;

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lc/g9;->p()Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_0
    const-string v2, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    :goto_0
    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc/k3;->E:Landroid/widget/Switch;

    iget-object v1, p0, Lc/k3;->c:Lc/n1;

    if-eqz v0, :cond_1

    invoke-virtual {v1}, Lc/n1;->r0()Z

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_1
    iget-object v0, p0, Lc/k3;->F:Landroid/widget/Switch;

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    iput-boolean v2, p0, Lc/k3;->G:Z

    invoke-virtual {v1}, Lc/n1;->q0()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/k3;->G:Z

    :cond_2
    return-void
.end method

.method public final W(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    if-gez p1, :cond_0

    return-void

    :cond_0
    iget v1, p0, Lc/k3;->r:I

    if-ltz v1, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    :goto_0
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v2, p0, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    if-nez v1, :cond_2

    const/4 v2, -0x1

    goto :goto_1

    :cond_2
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v2

    :goto_1
    iput v2, p0, Lc/k3;->r:I

    if-eqz v1, :cond_3

    if-gez v2, :cond_3

    const-string v1, ""

    iput-object v1, p0, Lc/k3;->w:Ljava/lang/String;

    iput-object v1, p0, Lc/k3;->v:Ljava/lang/String;

    const/high16 v1, 0x3f000000    # 0.5f

    iput v1, p0, Lc/k3;->x:F

    :cond_3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, p0, Lc/k3;->q:I

    const/4 p1, 0x0

    iput-boolean p1, p0, Lc/k3;->t:Z

    const-string p1, "\u0417\u043d\u0430\u0447\u043e\u043a \u0443\u0431\u0440\u0430\u043d \u0438\u0437 \u0434\u043e\u043a\u0430"

    iput-object p1, p0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {p0}, Lc/k3;->l()V

    invoke-virtual {p0}, Lc/k3;->S()V

    return-void
.end method

.method public final X()V
    .locals 16

    move-object/from16 v6, p0

    const/4 v0, 0x0

    iput-object v0, v6, Lc/k3;->p:Ljava/lang/String;

    const/4 v7, 0x0

    iput-boolean v7, v6, Lc/k3;->o:Z

    iget-object v1, v6, Lc/k3;->n:Landroid/animation/ValueAnimator;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/animation/Animator;->removeAllListeners()V

    iget-object v1, v6, Lc/k3;->n:Landroid/animation/ValueAnimator;

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v0, v6, Lc/k3;->n:Landroid/animation/ValueAnimator;

    :cond_0
    iput-boolean v7, v6, Lc/k3;->J:Z

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_1
    iget-object v8, v6, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v8}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iput-object v0, v6, Lc/k3;->g:Lc/r4;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    iput-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    iget-object v1, v6, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->b:I

    iget-object v2, v6, Lc/k3;->c:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->S()I

    move-result v2

    invoke-virtual {v6, v1, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    const/4 v9, 0x1

    invoke-virtual {v0, v9}, Landroid/view/View;->setClipToOutline(Z)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "settings-header"

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v1, 0x42600000    # 56.0f

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setMinimumHeight(I)V

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v2

    const/high16 v3, 0x40800000    # 4.0f

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v4

    const/high16 v10, 0x41a00000    # 20.0f

    invoke-virtual {v6, v10}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v0, v2, v4, v5, v3}, Landroid/view/View;->setPadding(IIII)V

    new-instance v2, Landroid/widget/ImageButton;

    invoke-direct {v2, v8}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    const v3, 0x1080038

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v3, v6, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->d:I

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v6, v7}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v2, v4, v5, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    const-string v4, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const-string v4, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    invoke-virtual {v2, v4}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    new-instance v4, Lc/z2;

    const/4 v5, 0x0

    invoke-direct {v4, v6, v5}, Lc/z2;-><init>(Lc/k3;I)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v12

    invoke-direct {v4, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-virtual {v6, v11}, Lc/k3;->x(F)I

    move-result v4

    const/high16 v12, 0x42000000    # 32.0f

    invoke-virtual {v6, v12}, Lc/k3;->x(F)I

    move-result v13

    invoke-direct {v2, v4, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual/range {p0 .. p0}, Lc/k3;->H()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v2, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043b\u0430\u0443\u043d\u0447\u0435\u0440\u0430"

    const/16 v4, 0x14

    invoke-virtual {v6, v4, v2, v9}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x2

    invoke-direct {v2, v7, v13, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v1, v2, v7, v3, v7}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setMinimumHeight(I)V

    invoke-virtual {v6, v7}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Landroid/widget/ImageView;

    invoke-direct {v2, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v3, 0x7f030052

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    const v3, 0x3f4ccccd    # 0.8f

    invoke-virtual {v2, v3}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setScaleY(F)V

    iget-object v3, v6, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->d:I

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x2

    invoke-virtual {v2, v3}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x41c00000    # 24.0f

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-direct {v3, v14, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0430\u043d\u0434\u0440\u043e\u0438\u0434"

    const/16 v3, 0xe

    invoke-virtual {v6, v3, v2, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v3, v9}, Landroid/widget/TextView;->setSingleLine(Z)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v13, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v14, 0x41200000    # 10.0f

    invoke-virtual {v6, v14}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v1, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v8, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v9}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v1}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v2, Lc/z2;

    const/4 v3, 0x1

    invoke-direct {v2, v6, v3}, Lc/z2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v3

    invoke-direct {v2, v13, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->H()Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v11}, Lc/k3;->x(F)I

    move-result v3

    const/4 v14, -0x1

    invoke-direct {v2, v14, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v15

    const/16 v0, 0x30

    invoke-virtual {v15, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    iput-object v0, v6, Lc/k3;->k:Landroid/widget/LinearLayout;

    move v5, v7

    :goto_0
    sget-object v0, Lc/k3;->N:[Ljava/lang/String;

    array-length v1, v0

    const/16 v2, 0x8

    const/high16 v3, 0x41000000    # 8.0f

    if-ge v5, v1, :cond_6

    aget-object v0, v0, v5

    if-ne v5, v2, :cond_2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->H()Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v11}, Lc/k3;->x(F)I

    move-result v4

    invoke-direct {v2, v14, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v10}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v6, v10}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v2, v4, v9, v12, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    iget-object v3, v6, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_2
    iget-object v1, v6, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "home"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, v6, Lc/k3;->h:Ljava/lang/String;

    const-string v2, "home_apps"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    :cond_3
    const-string v1, "dock"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v1, v6, Lc/k3;->h:Ljava/lang/String;

    const-string v2, "pairs"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_1

    :cond_4
    move v4, v7

    goto :goto_2

    :cond_5
    :goto_1
    const/4 v4, 0x1

    :goto_2
    sget-object v1, Lc/k3;->O:[Ljava/lang/String;

    aget-object v1, v1, v5

    sget-object v2, Lc/k3;->P:[Ljava/lang/String;

    aget-object v2, v2, v5

    sget-object v3, Lc/k3;->Q:[I

    aget v3, v3, v5

    new-instance v9, Lc/x2;

    const/4 v12, 0x3

    invoke-direct {v9, v6, v0, v12}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    move-object/from16 v0, p0

    move v12, v5

    move-object v5, v9

    invoke-virtual/range {v0 .. v5}, Lc/k3;->L(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iput v7, v1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    iget-object v2, v6, Lc/k3;->m:[Landroid/view/View;

    aput-object v0, v2, v12

    iget-object v2, v6, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v5, v12, 0x1

    const/4 v9, 0x1

    const/high16 v12, 0x42000000    # 32.0f

    goto/16 :goto_0

    :cond_6
    iget-object v0, v6, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v0}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v0

    new-instance v1, Landroid/widget/FrameLayout;

    invoke-direct {v1, v8}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const-string v4, "settings-sidebar"

    invoke-virtual {v1, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v6, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v1, v7, v4, v7, v3}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v14, v7, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u0415\u0449\u0451 \u0440\u0430\u0437\u0434\u0435\u043b\u044b \u043d\u0438\u0436\u0435"

    invoke-virtual {v6, v4}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v4, v2}, Landroid/view/View;->setVisibility(I)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42000000    # 32.0f

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v5

    invoke-direct {v2, v14, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Lc/K2;

    const/4 v5, 0x0

    invoke-direct {v2, v4, v0, v5}, Lc/K2;-><init>(Landroid/view/ViewTreeObserver$OnPreDrawListener;Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnScrollChangeListener(Landroid/view/View$OnScrollChangeListener;)V

    new-instance v2, Lc/H;

    const/16 v5, 0xb

    invoke-direct {v2, v4, v0, v5}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v0, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->w0()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v6, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-direct {v0, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v15, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->H()Landroid/view/View;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v11}, Lc/k3;->x(F)I

    move-result v2

    invoke-direct {v1, v2, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v15, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Lc/c0;

    const/4 v1, 0x1

    invoke-direct {v0, v6, v8, v1}, Lc/c0;-><init>(Ljava/lang/Object;Landroid/app/Activity;I)V

    iput-object v0, v6, Lc/k3;->l:Lc/c0;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k0()Landroid/widget/LinearLayout;

    move-result-object v0

    iput-object v0, v6, Lc/k3;->j:Landroid/widget/LinearLayout;

    iget-object v1, v6, Lc/k3;->l:Lc/c0;

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v6, Lc/k3;->l:Lc/c0;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v7, v14, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v14, v7, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v15, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    iget-object v0, v6, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lc/j1;

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Lc/j1;-><init>(Landroid/widget/LinearLayout;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    new-instance v1, Lc/L2;

    const/4 v2, 0x0

    invoke-direct {v1, v6, v0, v2}, Lc/L2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->e0()V

    return-void
.end method

.method public final Y(Ljava/lang/String;)V
    .locals 35

    move-object/from16 v8, p0

    move-object/from16 v0, p1

    const-string v1, "visibility"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    const-string v1, "home"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const-string v1, "music"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual {v8, v12}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v0

    iget-object v1, v8, Lc/k3;->j:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x1

    const/4 v14, 0x0

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v2, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v10, :cond_0

    new-instance v0, Lc/u2;

    const/16 v1, 0x10

    invoke-direct {v0, v8, v1}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v1, "\u2039 \u0413\u043b\u0430\u0432\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d"

    invoke-virtual {v8, v1, v14, v0}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->n()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v12, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    const v16, 0x3f266666    # 0.65f

    const/16 v7, 0x8

    const/4 v6, 0x4

    const/16 v2, 0xc

    iget-object v13, v8, Lc/k3;->c:Lc/n1;

    iget-object v1, v8, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v9, :cond_12

    const v3, 0x7f03008f

    const-string v15, "\u042d\u043a\u0440\u0430\u043d \u0438 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0439 \u0438\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441"

    const-string v4, ""

    invoke-virtual {v8, v3, v15, v4}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v15

    new-instance v3, Landroid/widget/Switch;

    invoke-direct {v3, v1}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v4, "\u041d\u0430 \u0432\u0435\u0441\u044c \u044d\u043a\u0440\u0430\u043d"

    invoke-static {v1, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v0, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v3, v0}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v13}, Lc/n1;->m0()Z

    move-result v0

    invoke-virtual {v3, v0}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v0, Lc/D2;

    const/4 v5, 0x6

    invoke-direct {v0, v8, v5}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v3, v0}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v0, "\u0421\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043f\u043e\u043b\u043e\u0441\u044b \u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u044f\u0435\u0442 \u0433\u043b\u0430\u0432\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d \u0438 \u043e\u043a\u043d\u0430. \u0423\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u043e\u0441\u0442\u0430\u0451\u0442\u0441\u044f \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u043c \u043f\u043e \u0436\u0435\u0441\u0442\u0443 \u043e\u0442 \u043a\u0440\u0430\u044f."

    invoke-virtual {v8, v4, v0, v3}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v8, v15, v0, v2, v14}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v8, v15}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v0, "\u0421\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0435 \u043f\u0430\u043d\u0435\u043b\u0438"

    invoke-virtual {v8, v0}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v8, v15, v0, v7, v14}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u043e\u0431\u0435"

    const-string v3, "\u0421\u043a\u0440\u044b\u0442\u044c \u0432\u0435\u0440\u0445\u043d\u044e\u044e"

    const-string v4, "\u0421\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0432\u0438\u0433\u0430\u0446\u0438\u044e"

    const-string v5, "\u0421\u043a\u0440\u044b\u0442\u044c \u043e\u0431\u0435"

    filled-new-array {v0, v3, v4, v5}, [Ljava/lang/String;

    move-result-object v0

    new-array v3, v6, [I

    sget-object v4, Lc/t;->a:[I

    const/4 v5, 0x0

    invoke-static {v4, v5, v3, v5, v6}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move v5, v14

    const/4 v4, 0x2

    :goto_0
    if-ge v5, v4, :cond_5

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    move v6, v14

    :goto_1
    if-ge v6, v4, :cond_4

    mul-int/lit8 v4, v5, 0x2

    add-int/2addr v4, v6

    aget v7, v3, v4

    invoke-virtual {v13}, Lc/n1;->L()I

    move-result v14

    if-ne v7, v14, :cond_1

    const/4 v14, 0x1

    goto :goto_2

    :cond_1
    const/4 v14, 0x0

    :goto_2
    aget-object v4, v0, v4

    move-object/from16 v25, v0

    new-instance v0, Lc/N2;

    move-object/from16 v26, v3

    const/4 v3, 0x0

    invoke-direct {v0, v8, v7, v3}, Lc/N2;-><init>(Lc/k3;II)V

    invoke-virtual {v8, v4, v14, v0}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Landroid/view/View;->setMinimumHeight(I)V

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v8, v3}, Lc/k3;->x(F)I

    move-result v4

    const/high16 v7, 0x40800000    # 4.0f

    invoke-virtual {v8, v7}, Lc/k3;->x(F)I

    move-result v14

    move/from16 v20, v11

    invoke-virtual {v8, v3}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v8, v7}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v0, v4, v14, v11, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v4, 0xd

    invoke-static {v0, v4}, Lc/k3;->z(Landroid/widget/TextView;I)V

    invoke-virtual {v13}, Lc/n1;->m0()Z

    move-result v4

    const/4 v7, 0x1

    xor-int/2addr v4, v7

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v13}, Lc/n1;->m0()Z

    move-result v4

    if-eqz v4, :cond_2

    const/high16 v4, 0x3f000000    # 0.5f

    goto :goto_3

    :cond_2
    const/high16 v4, 0x3f800000    # 1.0f

    :goto_3
    invoke-virtual {v0, v4}, Landroid/view/View;->setAlpha(F)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42200000    # 40.0f

    invoke-virtual {v8, v7}, Lc/k3;->x(F)I

    move-result v7

    const/4 v11, 0x0

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v4, v11, v7, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v7, 0x41000000    # 8.0f

    if-lez v6, :cond_3

    invoke-virtual {v8, v7}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_3
    invoke-virtual {v2, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v6, v6, 0x1

    move v14, v11

    move/from16 v11, v20

    move-object/from16 v0, v25

    move-object/from16 v3, v26

    const/4 v4, 0x2

    const/16 v7, 0x8

    goto/16 :goto_1

    :cond_4
    move-object/from16 v25, v0

    move-object/from16 v26, v3

    move v0, v7

    move/from16 v20, v11

    move v11, v14

    const/high16 v3, 0x41400000    # 12.0f

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v8, v15, v2, v0, v11}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    add-int/lit8 v5, v5, 0x1

    move/from16 v11, v20

    move-object/from16 v0, v25

    move-object/from16 v3, v26

    const/16 v2, 0xc

    const/4 v4, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    goto/16 :goto_0

    :cond_5
    move/from16 v20, v11

    move v11, v14

    const/high16 v3, 0x41400000    # 12.0f

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v13}, Lc/n1;->m0()Z

    move-result v0

    if-eqz v0, :cond_6

    const-string v0, "\u0412 \u0440\u0435\u0436\u0438\u043c\u0435 \u00ab\u041d\u0430 \u0432\u0435\u0441\u044c \u044d\u043a\u0440\u0430\u043d\u00bb \u043e\u0431\u0435 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u044b\u0435 \u043f\u0430\u043d\u0435\u043b\u0438 \u0441\u043a\u0440\u044b\u0442\u044b."

    invoke-virtual {v8, v0}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    const/4 v2, 0x4

    invoke-virtual {v8, v15, v0, v2, v11}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :cond_6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13}, Lc/n1;->S()I

    move-result v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " dp"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0xe

    invoke-virtual {v8, v2, v0, v11}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v8, v15}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v2, "\u0421\u043a\u0440\u0443\u0433\u043b\u0435\u043d\u0438\u0435 \u0443\u0433\u043b\u043e\u0432"

    const-string v4, "0 \u2014 \u0431\u0435\u0437 \u0441\u043a\u0440\u0443\u0433\u043b\u0435\u043d\u0438\u044f. \u041f\u043e\u043b\u044f \u0441\u043e \u0432\u0441\u0435\u0445 \u0441\u0442\u043e\u0440\u043e\u043d \u043e\u0434\u0438\u043d\u0430\u043a\u043e\u0432\u044b\u0435."

    invoke-virtual {v8, v2, v4, v0}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v4

    const/4 v6, 0x4

    invoke-virtual {v8, v15, v4, v6, v11}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v4, Landroid/widget/SeekBar;

    invoke-direct {v4, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v5, 0x40

    invoke-virtual {v4, v5}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v13}, Lc/n1;->S()I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/ProgressBar;->setProgress(I)V

    iget-object v5, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v4, v5}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v5, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v0, v5}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v2, Lc/Y2;

    const/4 v5, 0x0

    invoke-direct {v2, v8, v0, v5}, Lc/Y2;-><init>(Lc/k3;Ljava/lang/Object;I)V

    invoke-virtual {v4, v2}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42400000    # 48.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v5

    const/4 v2, -0x1

    invoke-direct {v0, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v15, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v0, 0x7f03004b

    const-string v2, "\u041c\u0435\u043d\u044e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    const-string v4, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438 \u0440\u0430\u0441\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0438\u043a\u043e\u043d\u043e\u043a \u0432 \u043c\u0435\u043d\u044e \u00ab\u0412\u0441\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f\u00bb"

    invoke-virtual {v8, v0, v2, v4}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v11

    invoke-virtual {v13}, Lc/n1;->f()I

    move-result v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v14, "%"

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/16 v5, 0x10

    invoke-virtual {v8, v5, v2, v4}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    const-string v5, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a"

    const-string v3, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u043e\u0431\u0449\u0435\u043c \u043c\u0435\u043d\u044e. \u0412 \u043e\u043a\u043d\u0430\u0445 \u0432\u044b\u0431\u043e\u0440\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0440\u0430\u0437\u043c\u0435\u0440 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f."

    invoke-virtual {v8, v5, v3, v2}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v3

    const/16 v7, 0x14

    invoke-virtual {v8, v11, v3, v7, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v3, Landroid/widget/SeekBar;

    invoke-direct {v3, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v4, 0x50

    invoke-virtual {v3, v4}, Landroid/widget/ProgressBar;->setMax(I)V

    add-int/lit8 v0, v0, -0x46

    invoke-virtual {v3, v0}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/high16 v0, 0x42400000    # 48.0f

    invoke-virtual {v8, v0}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/view/View;->setMinimumHeight(I)V

    const-string v0, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u043e\u0442 70 \u0434\u043e 150 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u043e\u0432"

    invoke-static {v1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v0, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v3, v0}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v0, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v0}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    new-instance v0, Lc/Y2;

    const/4 v4, 0x1

    invoke-direct {v0, v8, v2, v4}, Lc/Y2;-><init>(Lc/k3;Ljava/lang/Object;I)V

    invoke-virtual {v3, v0}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42400000    # 48.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v4

    const/4 v2, -0x1

    invoke-direct {v0, v2, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0421\u0442\u043e\u043b\u0431\u0446\u044b"

    const-string v2, "\u0421\u0442\u0440\u043e\u043a\u0438"

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v25

    const/16 v4, 0xa

    const/16 v0, 0x8

    filled-new-array {v4, v0}, [I

    move-result-object v26

    const/4 v0, 0x2

    const/4 v3, 0x0

    :goto_4
    if-ge v3, v0, :cond_f

    iget-object v2, v13, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    if-nez v3, :cond_8

    const-string v6, "all_apps_columns"

    const/4 v7, 0x0

    invoke-interface {v2, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-nez v2, :cond_7

    move/from16 v24, v7

    goto :goto_5

    :cond_7
    invoke-static {v4, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v24

    :goto_5
    move/from16 v2, v24

    :goto_6
    const/16 v7, 0x8

    goto :goto_7

    :cond_8
    const/4 v7, 0x0

    const-string v6, "all_apps_rows"

    invoke-interface {v2, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-nez v2, :cond_9

    const/4 v2, 0x0

    goto :goto_6

    :cond_9
    const/16 v7, 0x8

    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    :goto_7
    filled-new-array {v2}, [I

    move-result-object v23

    if-nez v2, :cond_a

    const-string v0, "\u0410\u0432\u0442\u043e"

    :goto_8
    const/16 v2, 0x10

    const/4 v6, 0x1

    goto :goto_9

    :cond_a
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    goto :goto_8

    :goto_9
    invoke-virtual {v8, v2, v0, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    const/16 v2, 0x11

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/4 v4, -0x1

    filled-new-array {v4, v6}, [I

    move-result-object v27

    const/4 v4, 0x0

    const/4 v6, 0x2

    :goto_a
    if-ge v4, v6, :cond_e

    aget v28, v27, v4

    if-gez v28, :cond_b

    const-string v29, "\u2212"

    :goto_b
    move-object/from16 v30, v29

    goto :goto_c

    :cond_b
    const-string v29, "+"

    goto :goto_b

    :goto_c
    new-instance v7, Lc/M0;

    const/16 v31, 0x1

    move-object/from16 v18, v0

    move-object v0, v7

    move-object/from16 v32, v1

    move-object/from16 v1, p0

    move-object/from16 v33, v2

    move-object/from16 v2, v23

    move/from16 v17, v3

    move/from16 v3, v28

    move/from16 v21, v4

    const/16 v19, 0xa

    move-object/from16 v4, v26

    move-object/from16 v34, v5

    move/from16 v5, v17

    move-object/from16 v6, v18

    move/from16 v22, v9

    move-object v9, v7

    move/from16 v7, v31

    invoke-direct/range {v0 .. v7}, Lc/M0;-><init>(Ljava/lang/Object;Ljava/io/Serializable;ILjava/io/Serializable;ILjava/lang/Object;I)V

    move-object/from16 v1, v30

    const/4 v0, 0x0

    invoke-virtual {v8, v1, v0, v9}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v2, v25, v17

    move-object/from16 v3, v32

    invoke-static {v3, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-gez v28, :cond_c

    const-string v2, " \u2212"

    goto :goto_d

    :cond_c
    const-string v2, " +"

    :goto_d
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42400000    # 48.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v5

    invoke-direct {v0, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v4, v33

    invoke-virtual {v4, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-gez v28, :cond_d

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x42580000    # 54.0f

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v5

    invoke-direct {v0, v1, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v6

    const/4 v7, 0x0

    invoke-virtual {v0, v5, v7, v6, v7}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    move-object/from16 v5, v18

    invoke-virtual {v4, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_e

    :cond_d
    move-object/from16 v5, v18

    const/high16 v1, 0x41000000    # 8.0f

    const/4 v7, 0x0

    :goto_e
    add-int/lit8 v0, v21, 0x1

    move-object v1, v3

    move-object v2, v4

    move/from16 v3, v17

    move/from16 v9, v22

    const/4 v6, 0x2

    const/16 v7, 0x8

    move v4, v0

    move-object v0, v5

    move-object/from16 v5, v34

    goto/16 :goto_a

    :cond_e
    move-object v4, v2

    move/from16 v17, v3

    move-object/from16 v34, v5

    move/from16 v22, v9

    const/high16 v2, 0x42400000    # 48.0f

    const/4 v7, 0x0

    const/16 v19, 0xa

    move-object v3, v1

    const/high16 v1, 0x41000000    # 8.0f

    aget-object v0, v25, v17

    const-string v5, "\u0410\u0432\u0442\u043e \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442 \u043f\u0440\u0435\u0436\u043d\u0435\u0435 \u0440\u0430\u0441\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435. \u041f\u0440\u0438 \u0432\u044b\u0431\u043e\u0440\u0435 \u0447\u0438\u0441\u043b\u0430 \u0441\u0442\u0440\u043e\u043a \u0438\u043a\u043e\u043d\u043a\u0438 \u0440\u0430\u0441\u043f\u0440\u0435\u0434\u0435\u043b\u044f\u044e\u0442\u0441\u044f \u043f\u043e \u0432\u044b\u0441\u043e\u0442\u0435 \u044d\u043a\u0440\u0430\u043d\u0430."

    invoke-virtual {v8, v0, v5, v4}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v4, 0xc

    invoke-virtual {v8, v11, v0, v4, v7}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    add-int/lit8 v0, v17, 0x1

    move-object v1, v3

    move/from16 v4, v19

    move-object/from16 v5, v34

    const/4 v6, 0x4

    const/16 v7, 0x14

    move v3, v0

    const/4 v0, 0x2

    goto/16 :goto_4

    :cond_f
    move-object v3, v1

    move-object/from16 v34, v5

    move/from16 v22, v9

    const/high16 v1, 0x41000000    # 8.0f

    const/high16 v2, 0x42400000    # 48.0f

    const/16 v4, 0xc

    const v0, 0x7f03008e

    const-string v5, "\u041a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0430"

    const-string v6, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0443 \u0432 \u043e\u043a\u043d\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-virtual {v8, v0, v5, v6}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v5, Landroid/widget/Switch;

    invoke-direct {v5, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v6, "\u0412 \u043e\u043a\u043d\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v3, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v7, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v5, v7}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v13}, Lc/n1;->i0()Z

    move-result v7

    invoke-virtual {v5, v7}, Landroid/widget/Switch;->setChecked(Z)V

    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x1d

    if-lt v7, v9, :cond_10

    invoke-static {}, Lc/j8;->v()Z

    move-result v7

    if-eqz v7, :cond_10

    const/4 v7, 0x1

    goto :goto_f

    :cond_10
    const/4 v7, 0x0

    :goto_f
    invoke-virtual {v5, v7}, Landroid/view/View;->setEnabled(Z)V

    if-eqz v7, :cond_11

    const/high16 v7, 0x3f800000    # 1.0f

    goto :goto_10

    :cond_11
    move/from16 v7, v16

    :goto_10
    invoke-virtual {v5, v7}, Landroid/view/View;->setAlpha(F)V

    new-instance v7, Lc/D2;

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v5, v7}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v7, "\u0420\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u0441 Gboard."

    invoke-virtual {v8, v6, v7, v5}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v5

    const/4 v6, 0x0

    const/16 v7, 0x14

    invoke-virtual {v8, v0, v5, v7, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const v5, 0x7f03008d

    const-string v7, "\u0414\u043e\u043a"

    const-string v9, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u0432 \u043f\u0430\u043d\u0435\u043b\u0438 \u0434\u043e\u043a\u0430"

    invoke-virtual {v8, v5, v7, v9}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13}, Lc/n1;->m()I

    move-result v9

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v9, 0x10

    invoke-virtual {v8, v9, v7, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v7

    const-string v14, "\u0420\u0430\u0437\u043c\u0435\u0440 \u043e\u0433\u0440\u0430\u043d\u0438\u0447\u0435\u043d \u0433\u0440\u0430\u043d\u0438\u0446\u0430\u043c\u0438 \u0434\u043e\u043a\u0430. \u0427\u0435\u043c \u043c\u0435\u043d\u044c\u0448\u0435 \u0438\u043a\u043e\u043d\u043e\u043a, \u0442\u0435\u043c \u0431\u043e\u043b\u044c\u0448\u0435 \u0438\u0445 \u043c\u043e\u0436\u043d\u043e \u0443\u0432\u0435\u043b\u0438\u0447\u0438\u0442\u044c."

    move-object/from16 v1, v34

    invoke-virtual {v8, v1, v14, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    const/16 v14, 0x14

    invoke-virtual {v8, v5, v1, v14, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v1, Landroid/widget/SeekBar;

    invoke-direct {v1, v3}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x6e

    invoke-virtual {v1, v6}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v13}, Lc/n1;->m()I

    move-result v6

    add-int/lit8 v6, v6, -0x46

    invoke-virtual {v1, v6}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v1, v6}, Landroid/view/View;->setMinimumHeight(I)V

    const-string v6, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u0434\u043e\u043a\u0430"

    invoke-static {v3, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v6, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v6}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v6, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v7, v6}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    new-instance v6, Lc/Y2;

    const/4 v14, 0x2

    invoke-direct {v6, v8, v7, v14}, Lc/Y2;-><init>(Lc/k3;Ljava/lang/Object;I)V

    invoke-virtual {v1, v6}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v7

    const/4 v14, -0x1

    invoke-direct {v6, v14, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v1, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x0

    invoke-virtual {v8, v12, v15, v11, v1}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    invoke-virtual {v8, v12, v5, v0, v4}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    goto :goto_11

    :cond_12
    move-object v3, v1

    move v4, v2

    move/from16 v22, v9

    move/from16 v20, v11

    const/high16 v2, 0x42400000    # 48.0f

    const/16 v9, 0x10

    :goto_11
    const-string v0, "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440"

    if-eqz v10, :cond_13

    const-string v1, "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u0432 \u0432\u0438\u0440\u0442\u0443\u0430\u043b\u044c\u043d\u043e\u043c \u043e\u043a\u043d\u0435"

    goto :goto_12

    :cond_13
    move-object v1, v0

    :goto_12
    invoke-virtual {v8, v1}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v5, "Bluetooth"

    const/4 v7, -0x2

    if-nez v22, :cond_1b

    if-eqz v20, :cond_14

    invoke-virtual {v13}, Lc/n1;->e0()Z

    move-result v11

    if-eqz v11, :cond_14

    const/4 v11, 0x1

    goto :goto_13

    :cond_14
    const/4 v11, 0x0

    :goto_13
    if-eqz v10, :cond_15

    invoke-virtual {v13}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v14

    goto :goto_14

    :cond_15
    invoke-virtual {v13}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v14

    :goto_14
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v15

    if-nez v11, :cond_17

    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v17

    if-nez v17, :cond_17

    if-eqz v20, :cond_16

    const/16 v17, 0x38

    move/from16 v6, v17

    goto :goto_15

    :cond_16
    const/16 v6, 0x24

    :goto_15
    invoke-virtual {v8, v14, v6}, Lc/k3;->C(Ljava/lang/String;I)Lc/f3;

    move-result-object v6

    invoke-virtual {v15, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_17
    if-eqz v11, :cond_18

    move-object v6, v5

    :goto_16
    const/4 v11, 0x0

    goto :goto_17

    :cond_18
    invoke-virtual {v14}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_19

    const-string v6, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    goto :goto_16

    :cond_19
    invoke-virtual {v8, v14}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_16

    :goto_17
    invoke-virtual {v8, v9, v6, v11}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    const/4 v14, 0x2

    invoke-virtual {v6, v14}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v9, v11, v7, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v14, 0x41400000    # 12.0f

    invoke-virtual {v8, v14}, Lc/k3;->x(F)I

    move-result v7

    iput v7, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v15, v6, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v20, :cond_1a

    new-instance v6, Lc/u2;

    const/16 v7, 0x11

    invoke-direct {v6, v8, v7}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v7, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c  \u203a"

    invoke-virtual {v8, v7, v11, v6}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual/range {p0 .. p0}, Lc/k3;->n()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v7

    invoke-virtual {v15, v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v1, v11}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "  \u24d8"

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/view/View;->setMinimumHeight(I)V

    const/4 v0, 0x1

    invoke-virtual {v6, v0}, Landroid/view/View;->setFocusable(Z)V

    new-instance v7, Lc/z2;

    const/4 v9, 0x2

    invoke-direct {v7, v8, v9}, Lc/z2;-><init>(Lc/k3;I)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_18
    const/16 v6, 0x8

    goto :goto_19

    :cond_1a
    const/4 v0, 0x1

    goto :goto_18

    :goto_19
    invoke-virtual {v8, v1, v15, v4, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_1a

    :cond_1b
    const/4 v0, 0x1

    const/16 v6, 0x8

    const/high16 v14, 0x41400000    # 12.0f

    :goto_1a
    if-nez v22, :cond_1d

    if-nez v20, :cond_1d

    if-eqz v10, :cond_1c

    const-string v4, "\u0412\u044b\u0431\u043e\u0440 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f \u0434\u043b\u044f \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430."

    goto :goto_1b

    :cond_1c
    const-string v4, "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440 \u0437\u0430\u043f\u0443\u0441\u043a\u0430\u0435\u0442\u0441\u044f \u0432 \u0444\u043e\u043d\u0435 \u0438 \u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f \u043f\u0440\u0438 \u0432\u043e\u0437\u0432\u0440\u0430\u0442\u0435 \u0441 Bluetooth."

    :goto_1b
    invoke-virtual {v8, v4}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    const/4 v7, 0x0

    invoke-virtual {v8, v1, v4, v7, v7}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :cond_1d
    iget-object v4, v8, Lc/k3;->b:Lc/z;

    if-eqz v20, :cond_21

    new-instance v7, Landroid/widget/Switch;

    invoke-direct {v7, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v9, "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f \u043e \u0441\u043c\u0435\u043d\u0435 \u0442\u0440\u0435\u043a\u0430"

    invoke-static {v3, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v10, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v7, v10}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    iget-object v10, v13, Lc/n1;->b:Ljava/lang/Object;

    check-cast v10, Landroid/content/SharedPreferences;

    const-string v11, "track_popup_enabled"

    const/4 v15, 0x0

    invoke-interface {v10, v11, v15}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    invoke-virtual {v7, v10}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v10, Lc/D2;

    const/16 v11, 0x8

    invoke-direct {v10, v8, v11}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v7, v10}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v8, v1}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v10, "\u041d\u0430 \u0433\u043b\u0430\u0432\u043d\u043e\u043c \u044d\u043a\u0440\u0430\u043d\u0435 \u043f\u043e\u044f\u0432\u0438\u0442\u0441\u044f \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0442\u0440\u0435\u043a\u0430 \u0438 \u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c."

    invoke-virtual {v8, v9, v10, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {v8, v1, v7, v6, v15}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v7, "\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b"

    invoke-virtual {v8, v7}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    new-instance v9, Landroid/widget/Switch;

    invoke-direct {v9, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v10, "\u041f\u0440\u043e\u0434\u043e\u043b\u0436\u0430\u0442\u044c \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439 \u0442\u0440\u0435\u043a"

    invoke-static {v3, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v11, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v9, v11}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    iget-object v11, v13, Lc/n1;->b:Ljava/lang/Object;

    check-cast v11, Landroid/content/SharedPreferences;

    const-string v15, "resume_music_on_start"

    const/4 v2, 0x0

    invoke-interface {v11, v15, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-virtual {v9, v0}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v0, Lc/D2;

    const/16 v14, 0x9

    invoke-direct {v0, v8, v14}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v9, v0}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v0, "\u041f\u0440\u0438 \u0437\u0430\u043f\u0443\u0441\u043a\u0435 \u043f\u043e\u043f\u0440\u043e\u0441\u0438\u043c \u043f\u043e\u0441\u043b\u0435\u0434\u043d\u0438\u0439 \u043f\u043b\u0435\u0435\u0440 \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c \u043c\u0443\u0437\u044b\u043a\u0443, \u0435\u0441\u043b\u0438 \u043e\u043d \u044d\u0442\u043e \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442."

    invoke-virtual {v8, v10, v0, v9}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v8, v7, v0, v6, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0416\u0434\u0430\u0442\u044c \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u043f\u0435\u0440\u0435\u0434 \u0430\u0432\u0442\u043e\u0437\u0430\u043f\u0443\u0441\u043a\u043e\u043c"

    invoke-static {v3, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v14}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v14, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v0, v14}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v14, "wait_for_internet_before_music"

    invoke-interface {v11, v14, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    invoke-virtual {v0, v14}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-interface {v11, v15, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    invoke-virtual {v0, v14}, Landroid/view/View;->setEnabled(Z)V

    invoke-interface {v11, v15, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    if-eqz v14, :cond_1e

    const/high16 v2, 0x3f800000    # 1.0f

    goto :goto_1c

    :cond_1e
    move/from16 v2, v16

    :goto_1c
    invoke-virtual {v0, v2}, Landroid/view/View;->setAlpha(F)V

    new-instance v2, Lc/E2;

    const/4 v14, 0x1

    invoke-direct {v2, v8, v0, v14}, Lc/E2;-><init>(Lc/k3;Landroid/widget/Switch;I)V

    invoke-virtual {v9, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v2, Lc/D2;

    const/4 v9, 0x3

    invoke-direct {v2, v8, v9}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v8, v7}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v2, "\u041f\u0440\u0438 \u0437\u0430\u043f\u0443\u0441\u043a\u0435 \u0438 \u043f\u043e\u0441\u043b\u0435 \u043f\u0440\u043e\u0431\u0443\u0436\u0434\u0435\u043d\u0438\u044f \u043c\u0443\u0437\u044b\u043a\u0430 \u0434\u043e\u0436\u0434\u0451\u0442\u0441\u044f \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443. \u0420\u0443\u0447\u043d\u043e\u0435 \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e \u0441\u0440\u0430\u0437\u0443."

    invoke-virtual {v8, v10, v2, v0}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v8, v7, v0, v6, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v9, "\u0417\u0432\u0443\u043a \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430 \u043f\u043e Bluetooth \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    invoke-static {v3, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v10, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v0, v10}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v10, "auto_bluetooth_audio"

    invoke-interface {v11, v10, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    invoke-virtual {v0, v10}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v10, Lc/D2;

    const/4 v11, 0x4

    invoke-direct {v10, v8, v11}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v10}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v8, v7}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    const-string v10, "\u041f\u0440\u0438 \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0438 \u043d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0435 \u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f Bluetooth-\u0437\u0432\u0443\u043a. \u041f\u043e\u0441\u043b\u0435 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0438 \u0432\u0435\u0440\u043d\u0451\u0442\u0441\u044f \u043f\u0440\u0435\u0436\u043d\u0438\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a."

    invoke-virtual {v8, v9, v10, v0}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v8, v7, v0, v6, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Lc/j3;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v9

    invoke-direct {v0, v9}, Lc/j3;-><init>(F)V

    iget-boolean v0, v0, Lc/j3;->a:Z

    if-eqz v0, :cond_1f

    invoke-virtual {v8, v12, v1, v7, v2}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    goto :goto_1d

    :cond_1f
    new-instance v0, Lc/u8;

    invoke-direct {v0, v3}, Lc/u8;-><init>(Landroid/content/Context;)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    const/4 v11, -0x2

    invoke-direct {v9, v2, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v2, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v7, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_1d
    const-string v0, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u0438 \u0432 \u0432\u0438\u0434\u0436\u0435\u0442\u0435 \u00ab\u041c\u0443\u0437\u044b\u043a\u0430\u00bb"

    invoke-virtual {v8, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f, \u043a\u043e\u0442\u043e\u0440\u044b\u0435 \u0431\u0443\u0434\u0443\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b \u0432 \u0441\u043f\u0438\u0441\u043a\u0435 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432 \u0432\u0438\u0434\u0436\u0435\u0442\u0430."

    invoke-virtual {v8, v1}, Lc/k3;->A(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v8, v0, v1, v6, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v13}, Lc/n1;->u0()Ljava/util/HashSet;

    move-result-object v1

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v7, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v7}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a"

    invoke-static {v3, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, ": Bluetooth"

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const-string v7, "com.android.bluetooth"

    invoke-virtual {v1, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x1

    xor-int/2addr v7, v10

    invoke-virtual {v2, v7}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v7, Lc/D2;

    const/16 v10, 0x10

    invoke-direct {v7, v8, v10}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v2, v7}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v7

    const/high16 v10, 0x42600000    # 56.0f

    invoke-virtual {v8, v10}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v11, Landroid/widget/ImageView;

    invoke-direct {v11, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v14, 0x7f030092

    invoke-virtual {v11, v14}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v14, v8, Lc/k3;->g:Lc/r4;

    iget v14, v14, Lc/r4;->d:I

    invoke-virtual {v11, v14}, Landroid/widget/ImageView;->setColorFilter(I)V

    const/4 v14, 0x2

    invoke-virtual {v11, v14}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v15, 0x42100000    # 36.0f

    invoke-virtual {v8, v15}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v8, v15}, Lc/k3;->x(F)I

    move-result v15

    invoke-direct {v14, v6, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v11, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x0

    const/16 v11, 0x10

    invoke-virtual {v8, v11, v5, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, -0x2

    invoke-direct {v11, v6, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v8, v6}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v11, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v8, v6}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v7, v5, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x42800000    # 64.0f

    invoke-virtual {v8, v6}, Lc/k3;->x(F)I

    move-result v11

    const/high16 v14, 0x42400000    # 48.0f

    invoke-virtual {v8, v14}, Lc/k3;->x(F)I

    move-result v15

    invoke-direct {v5, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Lc/I0;

    const/4 v11, 0x1

    invoke-direct {v5, v2, v11}, Lc/I0;-><init>(Landroid/widget/Switch;I)V

    invoke-virtual {v7, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x4

    invoke-virtual {v8, v0, v7, v2, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-static {v4, v13}, Lc/G8;->m(Lc/z;Lc/n1;)Ljava/util/ArrayList;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_20

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/a;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {v8, v10}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v11, v5, Lc/a;->a:Ljava/lang/String;

    const/16 v13, 0x24

    invoke-virtual {v8, v11, v13}, Lc/k3;->C(Ljava/lang/String;I)Lc/f3;

    move-result-object v11

    invoke-virtual {v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v11, v5, Lc/a;->b:Ljava/lang/String;

    const/4 v14, 0x0

    const/16 v15, 0x10

    invoke-virtual {v8, v15, v11, v14}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    const/4 v15, 0x1

    invoke-virtual {v10, v15}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v15, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v10, v15}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v15, v14, v2, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v15, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v15, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v7, v10, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v10, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v10}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v3, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, ": "

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v10, v5, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v10}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v10

    const/4 v11, 0x1

    xor-int/2addr v10, v11

    invoke-virtual {v2, v10}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v10, Lc/i0;

    const/4 v11, 0x2

    invoke-direct {v10, v8, v5, v11}, Lc/i0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v10}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8, v6}, Lc/k3;->x(F)I

    move-result v10

    const/high16 v11, 0x42400000    # 48.0f

    invoke-virtual {v8, v11}, Lc/k3;->x(F)I

    move-result v14

    invoke-direct {v5, v10, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Lc/I0;

    const/4 v10, 0x2

    invoke-direct {v5, v2, v10}, Lc/I0;-><init>(Landroid/widget/Switch;I)V

    invoke-virtual {v7, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x4

    invoke-virtual {v8, v0, v7, v2, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/high16 v10, 0x42600000    # 56.0f

    goto/16 :goto_1e

    :cond_20
    new-instance v1, Lc/u2;

    const/16 v2, 0x1a

    invoke-direct {v1, v8, v2}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v2, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435\u2026"

    const/4 v3, 0x0

    invoke-virtual {v8, v2, v3, v1}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v8, v0, v1, v2, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/16 v5, 0x10

    invoke-virtual {v8, v12, v0, v5, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    return-void

    :cond_21
    move v2, v6

    const/16 v5, 0x10

    if-nez v22, :cond_22

    invoke-virtual {v8, v12, v1, v5, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :cond_22
    new-instance v5, Landroid/widget/GridLayout;

    invoke-direct {v5, v3}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    const-string v0, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432 \u043e\u0431\u0449\u0435\u043c \u043c\u0435\u043d\u044e"

    if-eqz v22, :cond_23

    move-object v1, v0

    goto :goto_1f

    :cond_23
    const-string v1, "\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    :goto_1f
    invoke-virtual {v8, v1}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v9

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v8, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v9, v2, v6, v7, v1}, Landroid/view/View;->setPadding(IIII)V

    if-eqz v22, :cond_24

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v2, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 \u044f\u0440\u043b\u044b\u043a\u0438"

    invoke-static {v3, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v3, v8, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v3}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v3, "all_apps_activities"

    iget-object v6, v13, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v7, 0x1

    invoke-interface {v6, v3, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v3, Lc/D2;

    const/4 v6, 0x5

    invoke-direct {v3, v8, v6}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v3, 0x0

    invoke-virtual {v9, v3}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const-string v6, "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0437\u043d\u0430\u0447\u043e\u043a, \u0447\u0442\u043e\u0431\u044b \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0438\u043b\u0438 \u0441\u043a\u0440\u044b\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435. \u0417\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u0438\u044f \u0432 \u0434\u043e\u043a\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u0441\u044f."

    const/4 v7, 0x0

    invoke-virtual {v8, v0, v6, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v0, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 \u044f\u0440\u043b\u044b\u043a\u0438 \u043e\u0434\u043d\u043e\u0433\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432 \u043e\u0431\u0449\u0435\u043c \u043c\u0435\u043d\u044e."

    invoke-virtual {v8, v2, v0, v1}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v8, v9, v0, v1, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_20

    :cond_24
    const/4 v3, 0x0

    :goto_20
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x41000000    # 8.0f

    invoke-virtual {v8, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v9, v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0x10

    invoke-virtual {v8, v12, v9, v0, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    filled-new-array {v1}, [I

    move-result-object v11

    if-eqz v10, :cond_25

    invoke-virtual {v4}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v0

    :goto_21
    move-object v4, v0

    goto :goto_22

    :cond_25
    invoke-virtual {v4}, Lc/z;->c()Ljava/util/List;

    move-result-object v0

    goto :goto_21

    :goto_22
    new-instance v12, Lc/M2;

    move-object v0, v12

    move-object/from16 v1, p0

    move-object v2, v9

    move-object v3, v5

    move/from16 v5, v22

    move/from16 v6, v20

    move v7, v10

    invoke-direct/range {v0 .. v7}, Lc/M2;-><init>(Lc/k3;Landroid/widget/LinearLayout;Landroid/widget/GridLayout;Ljava/util/List;ZZZ)V

    new-instance v0, Lc/L2;

    const/4 v1, 0x1

    invoke-direct {v0, v11, v12, v1}, Lc/L2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v9, v0}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    invoke-virtual {v9, v12}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final Z()V
    .locals 26

    move-object/from16 v6, p0

    new-instance v7, Lc/j3;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v0

    invoke-direct {v7, v0}, Lc/j3;-><init>(F)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v8

    iget-object v0, v6, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v8}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v2, v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v6, v7, v10}, Lc/k3;->v(Lc/j3;Z)Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v12, 0x8

    invoke-virtual {v6, v8, v0, v12, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u041f\u043e\u0432\u0435\u0434\u0435\u043d\u0438\u0435 \u0434\u043e\u043a\u0430"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v13

    new-instance v0, Landroid/widget/Switch;

    iget-object v14, v6, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v14}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0410\u0432\u0442\u043e\u0441\u043a\u0440\u044b\u0442\u0438\u0435 \u0434\u043e\u043a\u0430"

    invoke-static {v14, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v0, v2}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-static {v14, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v15, v6, Lc/k3;->c:Lc/n1;

    invoke-virtual {v15}, Lc/n1;->f0()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v1, Lc/D2;

    const/4 v2, 0x1

    invoke-direct {v1, v6, v2}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v6, v13, v0, v12, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, v14}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v1, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v0, v1}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v1, "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0442\u044c \u0432\u0440\u0435\u043c\u044f \u0438 \u0437\u043d\u0430\u0447\u043a\u0438 \u0441\u0435\u0442\u0438"

    invoke-static {v14, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v15}, Lc/n1;->g0()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v1, Lc/D2;

    const/4 v2, 0x2

    invoke-direct {v1, v6, v2}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v6, v13, v0, v12, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v15}, Lc/n1;->i()Lc/u0;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v5

    const/high16 v1, 0x40000000    # 2.0f

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v5, v2, v3, v4, v12}, Landroid/view/View;->setPadding(IIII)V

    iget-object v2, v6, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->b:I

    const/16 v3, 0x3e8

    invoke-virtual {v6, v2, v3}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v5, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Lc/u2;

    const/16 v4, 0xe

    invoke-direct {v2, v6, v4}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v4, "\u0421\u043b\u0435\u0432\u0430"

    iget v12, v7, Lc/j3;->g:I

    invoke-virtual {v6, v12, v2, v4}, Lc/k3;->u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Lc/u2;

    const/16 v9, 0xf

    invoke-direct {v4, v6, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u0421\u043f\u0440\u0430\u0432\u0430"

    invoke-virtual {v6, v12, v4, v9}, Lc/k3;->u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    sget-object v9, Lc/Q1;->a:Lc/Q1;

    iget-object v0, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q1;

    if-ne v0, v9, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v16

    move/from16 v3, v16

    goto :goto_0

    :cond_0
    move v3, v10

    :goto_0
    invoke-virtual {v6, v3}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    sget-object v3, Lc/Q1;->b:Lc/Q1;

    if-ne v0, v3, :cond_1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v17

    move/from16 v1, v17

    goto :goto_1

    :cond_1
    move v1, v10

    :goto_1
    invoke-virtual {v6, v1}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x1

    if-ne v0, v9, :cond_2

    move v9, v1

    goto :goto_2

    :cond_2
    move v9, v10

    :goto_2
    invoke-virtual {v2, v9}, Landroid/widget/TextView;->setSelected(Z)V

    if-ne v0, v3, :cond_3

    move v0, v1

    goto :goto_3

    :cond_3
    move v0, v10

    :goto_3
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setSelected(Z)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float v9, v12

    invoke-virtual {v6, v9}, Lc/k3;->o(F)I

    move-result v3

    invoke-direct {v0, v10, v3, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v9}, Lc/k3;->o(F)I

    move-result v2

    invoke-direct {v0, v10, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0421\u043a\u0440\u044b\u0432\u0430\u0442\u044c \u0447\u0435\u0440\u0435\u0437"

    const/16 v4, 0xe

    invoke-virtual {v6, v4, v0, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    const/16 v3, 0xc

    const/4 v2, 0x4

    invoke-virtual {v6, v13, v0, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/high16 v0, 0x40000000    # 2.0f

    invoke-virtual {v6, v0}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v6, v0}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v6, v0}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v6, v0}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {v2, v1, v3, v4, v0}, Landroid/view/View;->setPadding(IIII)V

    iget-object v0, v6, Lc/k3;->g:Lc/r4;

    iget v0, v0, Lc/r4;->b:I

    const/16 v1, 0x3e8

    invoke-virtual {v6, v0, v1}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v4, 0x5dc

    const/16 v3, 0xbb8

    const/16 v1, 0x1388

    filled-new-array {v4, v3, v1}, [I

    move-result-object v16

    const-string v0, "5 \u0441\u0435\u043a"

    const-string v1, "1,5 \u0441\u0435\u043a"

    const-string v3, "3 \u0441\u0435\u043a"

    filled-new-array {v1, v3, v0}, [Ljava/lang/String;

    move-result-object v20

    const/4 v3, 0x3

    new-array v1, v3, [Landroid/widget/TextView;

    move v0, v10

    :goto_4
    if-ge v0, v3, :cond_8

    aget v10, v16, v0

    aget-object v11, v20, v0

    move-object/from16 v21, v5

    new-instance v5, Lc/N;

    const/16 v22, 0x1

    move/from16 v23, v0

    move-object v0, v5

    move-object/from16 v17, v1

    move-object/from16 v1, p0

    move-object/from16 v24, v2

    move v2, v10

    move/from16 v18, v3

    move-object/from16 v3, v17

    move-object/from16 v19, v8

    move v8, v4

    move-object/from16 v4, v16

    move-object v8, v5

    move-object/from16 v25, v21

    move/from16 v5, v22

    invoke-direct/range {v0 .. v5}, Lc/N;-><init>(Landroid/view/KeyEvent$Callback;ILjava/io/Serializable;Ljava/io/Serializable;I)V

    invoke-virtual {v6, v12, v8, v11}, Lc/k3;->u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    iget-object v1, v15, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "dock_auto_hide_delay_ms"

    const/16 v3, 0x5dc

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    const/16 v1, 0xbb8

    const/16 v2, 0x1388

    if-eq v4, v1, :cond_5

    if-ne v4, v2, :cond_4

    goto :goto_5

    :cond_4
    move v4, v3

    :cond_5
    :goto_5
    if-ne v4, v10, :cond_6

    const/4 v4, 0x1

    goto :goto_6

    :cond_6
    const/4 v4, 0x0

    :goto_6
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setSelected(Z)V

    if-eqz v4, :cond_7

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v4

    goto :goto_7

    :cond_7
    const/4 v4, 0x0

    :goto_7
    invoke-virtual {v6, v4}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    aput-object v0, v17, v23

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v9}, Lc/k3;->o(F)I

    move-result v5

    const/4 v8, 0x0

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v4, v8, v5, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v5, v24

    invoke-virtual {v5, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v0, v23, 0x1

    move v4, v3

    move-object v2, v5

    move v10, v8

    move-object/from16 v1, v17

    move/from16 v3, v18

    move-object/from16 v8, v19

    move-object/from16 v5, v25

    const/high16 v11, 0x3f800000    # 1.0f

    goto :goto_4

    :cond_8
    move-object/from16 v25, v5

    move-object/from16 v19, v8

    move v8, v10

    move-object v5, v2

    invoke-virtual {v6, v13, v5, v8, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0434\u043e\u043a: \u0441\u0432\u0430\u0439\u043f \u043a \u0446\u0435\u043d\u0442\u0440\u0443 \u043e\u0442 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e \u043a\u0440\u0430\u044f \u0438\u043b\u0438 \u043a\u0430\u0441\u0430\u043d\u0438\u0435 \u043f\u043e\u043b\u043e\u0441\u043a\u0438 \u0432 \u0440\u0435\u0436\u0438\u043c\u0435 \u043e\u043a\u043e\u043d."

    invoke-virtual {v6, v0}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0xc

    invoke-virtual {v6, v13, v0, v1, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v2

    iget v3, v6, Lc/k3;->q:I

    if-ltz v3, :cond_9

    iget-object v4, v6, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ge v3, v5, :cond_9

    iget v3, v6, Lc/k3;->q:I

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_9

    iget v3, v6, Lc/k3;->q:I

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    goto :goto_8

    :cond_9
    const-string v3, ""

    :goto_8
    invoke-virtual {v15, v3}, Lc/n1;->G(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_a

    const-string v5, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0432 \u0434\u043e\u043a\u0435"

    goto :goto_9

    :cond_a
    invoke-virtual {v6, v3}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_9
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_b

    invoke-static {v14, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_a

    :cond_b
    move-object v8, v5

    :goto_a
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431: "

    invoke-static {v14, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, " \u2014 "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, "%"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x1

    const/16 v11, 0xe

    invoke-virtual {v6, v11, v9, v10}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v2, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v11, Landroid/widget/SeekBar;

    invoke-direct {v11, v14}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v12, 0x46

    invoke-virtual {v11, v12}, Landroid/widget/ProgressBar;->setMax(I)V

    add-int/lit8 v4, v4, -0x32

    invoke-virtual {v11, v4}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/high16 v4, 0x42400000    # 48.0f

    invoke-virtual {v6, v4}, Lc/k3;->o(F)I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043e\u0434\u0438\u043d\u043e\u0447\u043d\u043e\u0433\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f "

    invoke-static {v14, v15}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v11, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v5, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v11, v5}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    iget-object v5, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v9, v5}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_c

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v5

    const-string v12, "activity"

    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_c

    move v5, v10

    goto :goto_b

    :cond_c
    const/4 v5, 0x0

    :goto_b
    invoke-virtual {v11, v5}, Landroid/view/View;->setEnabled(Z)V

    new-instance v5, Lc/Z0;

    invoke-direct {v5, v6, v9, v8, v3}, Lc/Z0;-><init>(Lc/k3;Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v11, v5}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v4}, Lc/k3;->o(F)I

    move-result v4

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v11, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v3, "50\u2013120%. \u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f \u043e\u0442\u0434\u0435\u043b\u044c\u043d\u043e \u0434\u043b\u044f \u043a\u0430\u0436\u0434\u043e\u0433\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f."

    invoke-virtual {v6, v3}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v3, 0x0

    const/16 v4, 0x8

    invoke-virtual {v6, v0, v2, v4, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v2, "\u041f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0434\u043e\u043a\u0430"

    invoke-virtual {v6, v2}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    move-object/from16 v5, v25

    invoke-virtual {v6, v2, v5, v4, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v4

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/4 v9, -0x1

    invoke-direct {v5, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v6, v4, v2, v1, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v6, v0, v4, v13, v3}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    iget-boolean v1, v7, Lc/j3;->a:Z

    if-eqz v1, :cond_d

    invoke-virtual {v6, v7}, Lc/k3;->w(Lc/j3;)Landroid/widget/HorizontalScrollView;

    move-result-object v2

    goto :goto_c

    :cond_d
    invoke-virtual/range {p0 .. p0}, Lc/k3;->r0()Lc/b2;

    move-result-object v2

    :goto_c
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v3

    const-string v4, "settings-card:\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    invoke-virtual {v3, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v4, 0x10

    iget v5, v7, Lc/j3;->e:I

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v9

    int-to-float v9, v9

    invoke-virtual {v6, v9}, Lc/k3;->x(F)I

    move-result v9

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v6, v11}, Lc/k3;->x(F)I

    move-result v11

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v12

    int-to-float v12, v12

    invoke-virtual {v6, v12}, Lc/k3;->x(F)I

    move-result v12

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v3, v9, v11, v12, v5}, Landroid/view/View;->setPadding(IIII)V

    iget-object v5, v6, Lc/k3;->g:Lc/r4;

    iget v5, v5, Lc/r4;->c:I

    iget v9, v7, Lc/j3;->f:I

    invoke-virtual {v6, v5, v9}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v5, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-virtual {v6, v4, v5, v10}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v4, "dock"

    invoke-virtual {v6, v3, v4}, Lc/k3;->a(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    iget v4, v7, Lc/j3;->d:I

    if-eqz v1, :cond_e

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42900000    # 72.0f

    invoke-virtual {v6, v5}, Lc/k3;->x(F)I

    move-result v5

    const/4 v9, -0x1

    invoke-direct {v1, v9, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    int-to-float v4, v4

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    move-object/from16 v5, v19

    invoke-virtual {v5, v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void

    :cond_e
    move-object/from16 v5, v19

    const/4 v9, -0x1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v10, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x0

    invoke-virtual {v6, v1, v3, v4, v0}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v3, 0x30

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    iget v7, v7, Lc/j3;->c:I

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Lc/k3;->x(F)I

    move-result v7

    invoke-direct {v3, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    int-to-float v4, v4

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v7

    iput v7, v3, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v2, v3, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v4}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final a(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 8

    new-instance v4, Landroid/widget/GridLayout;

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v4, v0}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    filled-new-array {v1}, [I

    move-result-object v6

    new-instance v7, Lc/C2;

    const/4 v5, 0x2

    move-object v0, v7

    move-object v1, p0

    move-object v2, p2

    move-object v3, p1

    invoke-direct/range {v0 .. v5}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance p2, Lc/L2;

    const/4 v0, 0x2

    invoke-direct {p2, v6, v7, v0}, Lc/L2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p1, p2}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    invoke-virtual {p1, v7}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final a0()V
    .locals 6

    iget-object v0, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->d:I

    invoke-static {v0, v1}, Lc/G8;->p(Landroid/widget/LinearLayout;I)V

    iget-object v0, p0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    iget-object v1, p0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lc/k3;->A(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, 0x0

    const/4 v4, -0x2

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v2, v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lc/k3;->A:Ljava/util/ArrayList;

    if-eqz v1, :cond_0

    new-instance v1, Lc/u2;

    const/16 v2, 0xd

    invoke-direct {v1, p0, v2}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v2, "\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c"

    invoke-virtual {p0, v2, v3, v1}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    iget-object v1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_1
    return-void
.end method

.method public final b(Lc/u8;Landroid/widget/LinearLayout;Z)V
    .locals 4

    const/4 v0, 0x0

    const/4 v1, -0x2

    if-eqz p3, :cond_0

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_0

    :cond_0
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v2, v0, v1, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    :goto_0
    const/high16 v1, 0x41800000    # 16.0f

    if-eqz p3, :cond_2

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    if-nez p3, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v0

    :goto_1
    iput v0, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p3

    if-lez p3, :cond_3

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result p3

    iput p3, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_3
    :goto_2
    invoke-virtual {p1, p2, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final b0()V
    .locals 18

    move-object/from16 v0, p0

    const/4 v2, 0x3

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v3

    iget-object v4, v0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v5

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, 0x0

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u042f\u0437\u044b\u043a \u0438\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430"

    const-string v5, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u044f\u0437\u044b\u043a \u0438\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441\u0430 DriveDeck."

    const/4 v6, 0x0

    invoke-virtual {v0, v4, v5, v6}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v4

    const/4 v5, 0x4

    const/16 v10, 0x8

    invoke-virtual {v0, v3, v4, v5, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v14, "vi"

    const-string v15, "it"

    const-string v11, "ru"

    const-string v12, "en"

    const-string v13, "es"

    const-string v16, "lt"

    const-string v17, "zh-TW"

    filled-new-array/range {v11 .. v17}, [Ljava/lang/String;

    move-result-object v4

    const-string v13, "Ti\u1ebfng Vi\u1ec7t"

    const-string v14, "Italiano"

    const-string v10, "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"

    const-string v11, "English"

    const-string v12, "Espa\u00f1ol"

    const-string v15, "Lietuvi\u0173"

    const-string v16, "\u7e41\u9ad4\u4e2d\u6587"

    filled-new-array/range {v10 .. v16}, [Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x7

    new-array v11, v10, [I

    fill-array-data v11, :array_0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v12

    const/high16 v13, 0x40800000    # 4.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v12, v14, v15, v6, v9}, Landroid/view/View;->setPadding(IIII)V

    iget-object v6, v0, Lc/k3;->g:Lc/r4;

    iget v6, v6, Lc/r4;->c:I

    const/16 v9, 0x10

    invoke-virtual {v0, v6, v9}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v12, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    move v14, v8

    const/4 v6, 0x0

    :goto_0
    if-ge v14, v10, :cond_b

    rem-int/lit8 v15, v14, 0x3

    if-nez v15, :cond_1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x42500000    # 52.0f

    invoke-virtual {v0, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-direct {v10, v7, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-lez v14, :cond_0

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_0
    invoke-virtual {v12, v6, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    aget-object v1, v4, v14

    iget-object v10, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v10}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    aget-object v13, v5, v14

    new-instance v7, Lc/a1;

    invoke-direct {v7, v2}, Lc/a1;-><init>(I)V

    invoke-virtual {v0, v13, v10, v7}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v7

    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v13

    invoke-virtual {v7, v2, v8, v13, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    aget v2, v11, v14

    invoke-virtual {v7, v2, v8, v8, v8}, Landroid/widget/TextView;->setCompoundDrawablesRelativeWithIntrinsicBounds(IIII)V

    const/high16 v2, 0x41200000    # 10.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/4 v2, 0x1

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v2, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v2, Lc/l;

    const/4 v13, 0x5

    invoke-direct {v2, v0, v1, v7, v13}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v7, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v13, "settings-language:"

    invoke-direct {v2, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setSelected(Z)V

    if-eqz v10, :cond_2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v2

    goto :goto_1

    :cond_2
    move v2, v8

    :goto_1
    invoke-virtual {v0, v2}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v2

    invoke-virtual {v7, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->d:I

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const-string v2, "en"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    const-string v1, ", selected"

    goto :goto_2

    :cond_3
    const-string v2, "es"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    const-string v1, ", seleccionado"

    goto :goto_2

    :cond_4
    const-string v2, "vi"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5

    const-string v1, ", \u0111\u00e3 ch\u1ecdn"

    goto :goto_2

    :cond_5
    const-string v2, "it"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    const-string v1, ", selezionato"

    goto :goto_2

    :cond_6
    const-string v2, "lt"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_7

    const-string v1, ", pasirinkta"

    goto :goto_2

    :cond_7
    const-string v2, "zh-TW"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8

    const-string v1, "\uff0c\u5df2\u9078\u53d6"

    goto :goto_2

    :cond_8
    const-string v1, "\uff0c\u5df2\u9078"

    :goto_2
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v13, v5, v14

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v10, :cond_9

    goto :goto_3

    :cond_9
    const-string v1, ""

    :goto_3
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v1, v8, v2, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v13, 0x40800000    # 4.0f

    if-eqz v15, :cond_a

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v15

    iput v15, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_a
    invoke-virtual {v6, v7, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x1

    add-int/2addr v14, v1

    move v7, v2

    const/4 v2, 0x3

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_b
    invoke-virtual {v0, v3, v12, v9, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    return-void

    :array_0
    .array-data 4
        0x7f030011
        0x7f03000e
        0x7f03000d
        0x7f030013
        0x7f03000f
        0x7f030010
        0x7f030012
    .end array-data
.end method

.method public final c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V
    .locals 6

    new-instance v0, Lc/j3;

    invoke-virtual {p0}, Lc/k3;->s0()F

    move-result v1

    invoke-direct {v0, v1}, Lc/j3;-><init>(F)V

    iget-boolean v0, v0, Lc/j3;->a:Z

    const/4 v1, 0x0

    if-nez v0, :cond_1

    new-instance v0, Lc/u8;

    iget-object v2, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v2}, Lc/u8;-><init>(Landroid/content/Context;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v3, v1, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p2, v1, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, p2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, p3, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p2, -0x1

    if-lez p4, :cond_0

    new-instance p3, Landroid/view/View;

    invoke-direct {p3, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float p4, p4

    invoke-virtual {p0, p4}, Lc/k3;->x(F)I

    move-result p4

    invoke-direct {v1, p2, p4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p3, p2, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v0, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, p1, p2, p4, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/16 p2, 0xc

    invoke-virtual {p0, p1, p3, p2, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_0
    return-void
.end method

.method public final c0()V
    .locals 27

    move-object/from16 v0, p0

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v5, Lc/j3;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v6

    invoke-direct {v5, v6}, Lc/j3;-><init>(F)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v7

    iget-object v8, v0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v7}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v9

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x1

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v10, v11, v3, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v8

    new-instance v9, Lc/u2;

    const/16 v10, 0xa

    invoke-direct {v9, v0, v10}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v10, "+ \u041d\u043e\u0432\u0430\u044f \u043f\u0430\u0440\u0430"

    invoke-virtual {v0, v10, v3, v9}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    const/high16 v10, 0x42400000    # 48.0f

    invoke-virtual {v0, v10}, Lc/k3;->o(F)I

    move-result v13

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    iget-object v13, v0, Lc/k3;->g:Lc/r4;

    iget v13, v13, Lc/r4;->b:I

    invoke-virtual {v0, v13}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v13

    invoke-virtual {v9, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v10}, Lc/k3;->o(F)I

    move-result v14

    invoke-direct {v13, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v9, Lc/u2;

    const/16 v13, 0xb

    invoke-direct {v9, v0, v13}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v13, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    invoke-virtual {v0, v13, v2, v9}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v0, v10}, Lc/k3;->o(F)I

    move-result v13

    invoke-virtual {v9, v13}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setSingleLine(Z)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v10}, Lc/k3;->o(F)I

    move-result v14

    invoke-direct {v13, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v14, 0x41000000    # 8.0f

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v15

    iput v15, v13, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v8, v9, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v5, v2}, Lc/k3;->v(Lc/j3;Z)Landroid/widget/LinearLayout;

    move-result-object v9

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v15, -0x2

    invoke-direct {v13, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v4

    iput v4, v13, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget-object v4, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-boolean v10, v5, Lc/j3;->a:Z

    if-eqz v10, :cond_0

    new-instance v1, Landroid/widget/HorizontalScrollView;

    invoke-direct {v1, v4}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setHorizontalScrollBarEnabled(Z)V

    new-instance v14, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v14, v15, v15}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v9, v14}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v7, v1, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_0

    :cond_0
    invoke-virtual {v7, v9, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/16 v9, 0x30

    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    if-eqz v10, :cond_1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    :cond_1
    iget v13, v5, Lc/j3;->c:I

    if-eqz v10, :cond_2

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v9, 0x42900000    # 72.0f

    invoke-virtual {v0, v9}, Lc/k3;->x(F)I

    move-result v9

    invoke-direct {v14, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_1

    :cond_2
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float v9, v13

    invoke-virtual {v0, v9}, Lc/k3;->x(F)I

    move-result v9

    invoke-direct {v14, v9, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    :goto_1
    iget v9, v5, Lc/j3;->d:I

    if-eqz v10, :cond_3

    int-to-float v2, v9

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v14, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    goto :goto_2

    :cond_3
    int-to-float v2, v9

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v14, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    :goto_2
    if-eqz v10, :cond_4

    invoke-virtual {v0, v5}, Lc/k3;->w(Lc/j3;)Landroid/widget/HorizontalScrollView;

    move-result-object v2

    goto :goto_3

    :cond_4
    invoke-virtual/range {p0 .. p0}, Lc/k3;->r0()Lc/b2;

    move-result-object v2

    :goto_3
    invoke-virtual {v1, v2, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v2

    if-eqz v10, :cond_5

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v14, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_4

    :cond_5
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v14, v3, v15, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    :goto_4
    invoke-virtual {v1, v2, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v14, v11, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    int-to-float v9, v9

    invoke-virtual {v0, v9}, Lc/k3;->x(F)I

    move-result v15

    iput v15, v14, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v7, v1, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v7, "settings-card:\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043f\u0430\u0440\u044b"

    invoke-virtual {v1, v7}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v7, 0x41400000    # 12.0f

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v1, v14, v15, v11, v3}, Landroid/view/View;->setPadding(IIII)V

    iget-object v3, v0, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->c:I

    const/16 v11, 0x10

    invoke-virtual {v0, v3, v11}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v3

    const v14, 0x443b8000    # 750.0f

    cmpl-float v14, v6, v14

    if-ltz v14, :cond_6

    const/4 v14, 0x1

    goto :goto_5

    :cond_6
    const/4 v14, 0x0

    :goto_5
    int-to-float v13, v13

    sub-float/2addr v6, v13

    sub-float/2addr v6, v9

    const/high16 v13, 0x41c00000    # 24.0f

    sub-float/2addr v6, v13

    if-eqz v14, :cond_7

    const/16 v13, 0xc0

    goto :goto_6

    :cond_7
    const/4 v13, 0x0

    :goto_6
    int-to-float v13, v13

    sub-float/2addr v6, v13

    iget v13, v0, Lc/k3;->r:I

    if-ltz v13, :cond_8

    const/16 v13, 0x38

    goto :goto_7

    :cond_8
    const/4 v13, 0x0

    :goto_7
    int-to-float v13, v13

    sub-float v13, v6, v13

    const/high16 v15, 0x41000000    # 8.0f

    sub-float/2addr v13, v15

    const/high16 v15, 0x40000000    # 2.0f

    div-float/2addr v13, v15

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    const/16 v15, 0xa0

    invoke-static {v15, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    const/16 v15, 0xdc

    invoke-static {v15, v13}, Ljava/lang/Math;->min(II)I

    move-result v13

    const/high16 v15, 0x42600000    # 56.0f

    if-eqz v10, :cond_9

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v15}, Lc/k3;->x(F)I

    move-result v7

    const/4 v15, 0x0

    invoke-direct {v11, v15, v7, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    :goto_8
    const/high16 v7, 0x41000000    # 8.0f

    goto :goto_9

    :cond_9
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float v7, v13

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v7

    const/high16 v15, 0x42600000    # 56.0f

    invoke-virtual {v0, v15}, Lc/k3;->x(F)I

    move-result v12

    invoke-direct {v11, v7, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    goto :goto_8

    :goto_9
    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v12

    iput v12, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    const-string v7, "\u0421\u043b\u0435\u0432\u0430"

    iget-object v12, v0, Lc/k3;->v:Ljava/lang/String;

    const/4 v15, 0x0

    invoke-virtual {v0, v15, v7, v12}, Lc/k3;->O(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {v3, v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v7, "\u0421\u043f\u0440\u0430\u0432\u0430"

    iget-object v11, v0, Lc/k3;->w:Ljava/lang/String;

    const/4 v12, 0x1

    invoke-virtual {v0, v12, v7, v11}, Lc/k3;->O(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    if-eqz v10, :cond_a

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42600000    # 56.0f

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v11, v15, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    goto :goto_a

    :cond_a
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float v12, v13

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v12

    const/high16 v13, 0x42600000    # 56.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v15

    invoke-direct {v11, v12, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    :goto_a
    invoke-virtual {v3, v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget v7, v0, Lc/k3;->r:I

    if-ltz v7, :cond_b

    new-instance v7, Lc/u2;

    const/16 v11, 0xc

    invoke-direct {v7, v0, v11}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v11, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0430\u0440\u0443"

    invoke-virtual {v0, v11, v7}, Lc/k3;->t(Ljava/lang/String;Ljava/lang/Runnable;)Lc/X2;

    move-result-object v7

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v0, v12}, Lc/k3;->o(F)I

    move-result v13

    invoke-virtual {v0, v12}, Lc/k3;->o(F)I

    move-result v15

    invoke-direct {v11, v13, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v13

    iput v13, v11, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v3, v7, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_b
    if-eqz v14, :cond_c

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v7

    goto :goto_b

    :cond_c
    move-object v7, v1

    :goto_b
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42600000    # 56.0f

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v12

    const/4 v13, -0x1

    invoke-direct {v11, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v3, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v3

    const-string v11, "\u041f\u0440\u043e\u043f\u043e\u0440\u0446\u0438\u0438"

    const/16 v12, 0xd

    const/4 v13, 0x0

    invoke-virtual {v0, v12, v11, v13}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v11

    invoke-virtual/range {p0 .. p0}, Lc/k3;->y0()I

    move-result v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x2

    invoke-direct {v12, v13, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v13, 0x41800000    # 16.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v15

    iput v15, v12, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v3, v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v11

    const/high16 v12, 0x40800000    # 4.0f

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v13

    move/from16 v17, v9

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v9

    move-object/from16 v18, v2

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v11, v15, v13, v9, v2}, Landroid/view/View;->setPadding(IIII)V

    iget-object v2, v0, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->b:I

    const/16 v9, 0x3e8

    invoke-virtual {v0, v2, v9}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v11, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget v2, v5, Lc/j3;->h:I

    if-eqz v14, :cond_d

    const/high16 v5, 0x43340000    # 180.0f

    sub-float/2addr v6, v5

    const/high16 v5, 0x40400000    # 3.0f

    div-float/2addr v6, v5

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v2, v5}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/16 v5, 0x46

    invoke-static {v5, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    :cond_d
    const/4 v6, 0x3

    new-array v13, v6, [F

    fill-array-data v13, :array_0

    const/4 v15, 0x0

    :goto_c
    if-ge v15, v6, :cond_11

    aget v6, v13, v15

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    int-to-float v12, v2

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v12

    move/from16 v21, v2

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v0, v5}, Lc/k3;->o(F)I

    move-result v2

    invoke-direct {v9, v12, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const v2, 0x3f333333    # 0.7f

    cmpg-float v5, v6, v2

    if-gez v5, :cond_e

    const/high16 v5, 0x40800000    # 4.0f

    invoke-virtual {v0, v5}, Lc/k3;->x(F)I

    move-result v12

    iput v12, v9, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    goto :goto_d

    :cond_e
    const/high16 v5, 0x40800000    # 4.0f

    :goto_d
    iget v12, v0, Lc/k3;->x:F

    sub-float v12, v6, v12

    invoke-static {v12}, Ljava/lang/Math;->abs(F)F

    move-result v12

    const v20, 0x3c23d70a    # 0.01f

    cmpg-float v12, v12, v20

    if-gez v12, :cond_f

    const/4 v12, 0x1

    goto :goto_e

    :cond_f
    const/4 v12, 0x0

    :goto_e
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v5, 0x11

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    move-object/from16 v22, v13

    const/16 v16, 0x0

    invoke-static/range {v16 .. v16}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v13

    if-eqz v12, :cond_10

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v23

    move-object/from16 v19, v8

    const/16 v8, 0x3e8

    move/from16 v26, v23

    move-object/from16 v23, v1

    move/from16 v1, v26

    goto :goto_f

    :cond_10
    move-object/from16 v23, v1

    move-object/from16 v19, v8

    const/4 v1, 0x0

    const/16 v8, 0x3e8

    :goto_f
    invoke-virtual {v0, v1, v8}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    move-object/from16 v25, v7

    move/from16 v24, v14

    const/4 v14, -0x1

    invoke-virtual {v0, v14, v8}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-direct {v5, v13, v1, v7}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Lc/W2;

    invoke-direct {v1, v0, v4, v6}, Lc/W2;-><init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;F)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x41d00000    # 26.0f

    invoke-virtual {v0, v7}, Lc/k3;->x(F)I

    move-result v7

    const/high16 v13, 0x41e00000    # 28.0f

    invoke-virtual {v0, v13}, Lc/k3;->x(F)I

    move-result v13

    invoke-direct {v5, v7, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/high16 v5, 0x42c80000    # 100.0f

    mul-float v7, v6, v5

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, "/"

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/high16 v13, 0x3f800000    # 1.0f

    sub-float v14, v13, v6

    mul-float/2addr v14, v5

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v5, 0xc

    invoke-virtual {v0, v5, v1, v12}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iget-object v13, v0, Lc/k3;->g:Lc/r4;

    iget v13, v13, Lc/r4;->d:I

    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    invoke-direct {v13, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v5, 0x41000000    # 8.0f

    invoke-virtual {v0, v5}, Lc/k3;->x(F)I

    move-result v8

    iput v8, v13, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v2, v1, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u041f\u0440\u043e\u043f\u043e\u0440\u0446\u0438\u0438 \u043e\u043a\u043e\u043d "

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " \u043d\u0430 "

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v2, v12}, Landroid/view/View;->setSelected(Z)V

    const/4 v1, 0x1

    invoke-virtual {v2, v1}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v2}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v5, Lc/O2;

    invoke-direct {v5, v0, v6}, Lc/O2;-><init>(Lc/k3;F)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v11, v2, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/2addr v15, v1

    move-object/from16 v8, v19

    move/from16 v2, v21

    move-object/from16 v13, v22

    move-object/from16 v1, v23

    move/from16 v14, v24

    move-object/from16 v7, v25

    const/4 v6, 0x3

    const/16 v9, 0x3e8

    const/high16 v12, 0x40800000    # 4.0f

    goto/16 :goto_c

    :cond_11
    move-object/from16 v23, v1

    move-object/from16 v25, v7

    move-object/from16 v19, v8

    move/from16 v24, v14

    invoke-virtual {v3, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x42400000    # 48.0f

    invoke-virtual {v0, v2}, Lc/k3;->o(F)I

    move-result v5

    invoke-virtual {v0, v2}, Lc/k3;->o(F)I

    move-result v2

    invoke-direct {v1, v5, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x41000000    # 8.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    new-instance v2, Lc/X2;

    const/4 v5, 0x0

    invoke-direct {v2, v0, v4, v5}, Lc/X2;-><init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;I)V

    iget-object v5, v0, Lc/k3;->g:Lc/r4;

    invoke-static {v5}, Lc/G8;->V0(Lc/r4;)I

    move-result v5

    invoke-virtual {v0, v5}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x1

    invoke-virtual {v2, v5}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v2}, Lc/k3;->h(Landroid/view/View;)V

    const-string v5, "\u041f\u043e\u043c\u0435\u043d\u044f\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u043c\u0435\u0441\u0442\u0430\u043c\u0438"

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    new-instance v5, Lc/z2;

    const/4 v6, 0x3

    invoke-direct {v5, v0, v6}, Lc/z2;-><init>(Lc/k3;I)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v3, v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v4}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v2, v6, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v5, -0x2

    invoke-direct {v1, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v7

    iput v7, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    if-eqz v10, :cond_12

    new-instance v2, Landroid/widget/HorizontalScrollView;

    invoke-direct {v2, v4}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setHorizontalScrollBarEnabled(Z)V

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3, v4}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v7, v25

    invoke-virtual {v7, v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_10

    :cond_12
    move-object/from16 v7, v25

    invoke-virtual {v7, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_10
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x43300000    # 176.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-direct {v1, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-eqz v24, :cond_13

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v3, 0x30

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    invoke-direct {v3, v6, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v7, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v3, 0x41800000    # 16.0f

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v4

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    move-object/from16 v3, v19

    invoke-virtual {v2, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v4, v23

    invoke-virtual {v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_11

    :cond_13
    move-object/from16 v3, v19

    move-object/from16 v4, v23

    const/high16 v2, 0x41000000    # 8.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const v2, 0x800005

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    invoke-virtual {v4, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_11
    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0432 \u043e\u043a\u043d\u0430\u0445 \u043f\u0430\u0440\u044b"

    const/16 v2, 0xf

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v1, v3}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x4

    const/16 v3, 0x10

    invoke-virtual {v0, v4, v1, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lc/k3;->P(I)Landroid/widget/LinearLayout;

    move-result-object v3

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, -0x2

    invoke-direct {v5, v2, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v3, v2, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41800000    # 16.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lc/k3;->P(I)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual {v1, v5, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043c\u0435\u043d\u044f\u0435\u0442 \u0440\u0430\u0437\u043c\u0435\u0440 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0433\u043e \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0439 \u043f\u0430\u0440\u044b. 100% \u2014 \u043e\u0431\u044b\u0447\u043d\u044b\u0439 \u0440\u0430\u0437\u043c\u0435\u0440."

    invoke-virtual {v0, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v1, v18

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v2

    const-string v3, "settings-card:\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v2, v4, v5, v6, v3}, Landroid/view/View;->setPadding(IIII)V

    iget-object v3, v0, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->c:I

    const/16 v4, 0x10

    invoke-virtual {v0, v3, v4}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v3, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    const/4 v5, 0x1

    invoke-virtual {v0, v4, v3, v5}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move/from16 v4, v17

    invoke-virtual {v0, v4}, Lc/k3;->x(F)I

    move-result v4

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "pairs"

    invoke-virtual {v0, v2, v1}, Lc/k3;->a(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    return-void

    :array_0
    .array-data 4
        0x3e99999a    # 0.3f
        0x3f000000    # 0.5f
        0x3f333333    # 0.7f
    .end array-data
.end method

.method public final d(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Consumer;)V
    .locals 8

    iget-object v0, p0, Lc/k3;->b:Lc/z;

    invoke-virtual {v0, p3}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v0

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-nez v0, :cond_0

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {v1, p4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    goto :goto_0

    :cond_0
    iget-object p3, v0, Lc/a;->b:Ljava/lang/String;

    :cond_1
    :goto_0
    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object p4

    const-string v2, "voice-app:"

    invoke-virtual {v2, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p4, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v2, 0x42800000    # 64.0f

    invoke-virtual {p0, v2}, Lc/k3;->o(F)I

    move-result v2

    invoke-virtual {p4, v2}, Landroid/view/View;->setMinimumHeight(I)V

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v3

    const/high16 v4, 0x40800000    # 4.0f

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {p4, v3, v5, v6, v4}, Landroid/view/View;->setPadding(IIII)V

    iget-object v3, p0, Lc/k3;->g:Lc/r4;

    invoke-static {v3}, Lc/G8;->V0(Lc/r4;)I

    move-result v3

    invoke-virtual {p0, v3}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v3

    invoke-virtual {p4, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    if-eqz v0, :cond_2

    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v3, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1

    :cond_2
    const v0, 0x7f03004b

    invoke-virtual {v3, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    iget v0, v0, Lc/r4;->e:I

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    :goto_1
    const/4 v0, 0x2

    invoke-virtual {v3, v0}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x42000000    # 32.0f

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-direct {v0, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p4, v3, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {p0, p2}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v3, 0xf

    const/4 v4, 0x1

    invoke-virtual {p0, v3, p3, v4}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v5, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x0

    const/4 v6, -0x2

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v3, v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {p4, v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p4, p3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {p4, v4}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {p4}, Lc/k3;->h(Landroid/view/View;)V

    new-instance p3, Lc/l;

    const/4 v0, 0x4

    invoke-direct {p3, p0, p2, p5, v0}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p4, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 p2, 0x8

    invoke-virtual {p0, p1, p4, p2, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    return-void
.end method

.method public final d0()V
    .locals 13

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    iget-object v1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v5, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v3, v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->B()Z

    move-result v3

    if-eqz v3, :cond_0

    move v8, v2

    goto :goto_0

    :cond_0
    move v8, v5

    :goto_0
    if-eqz v8, :cond_1

    const-string v3, "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e"

    :goto_1
    move-object v9, v3

    goto :goto_2

    :cond_1
    const-string v3, "\u041d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e"

    goto :goto_1

    :goto_2
    new-instance v12, Lc/u2;

    const/16 v3, 0x12

    invoke-direct {v12, p0, v3}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v10, "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 DriveDeck \u043f\u0440\u0438 \u043d\u0430\u0436\u0430\u0442\u0438\u0438 \u043a\u043d\u043e\u043f\u043a\u0438 Home."

    const-string v11, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e"

    const-string v7, "\u041b\u0430\u0443\u043d\u0447\u0435\u0440 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e"

    move-object v6, p0

    invoke-virtual/range {v6 .. v12}, Lc/k3;->R(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v3

    const-string v4, "\u041d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c\u044b \u0434\u043b\u044f \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u043e\u0439 \u0440\u0430\u0431\u043e\u0442\u044b DriveDeck. \u0412\u0441\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f \u0437\u0430\u043f\u0440\u0430\u0448\u0438\u0432\u0430\u044e\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0438 \u0444\u0443\u043d\u043a\u0446\u0438\u0438."

    invoke-virtual {p0, v4}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v4

    new-instance v6, Lc/u2;

    const/16 v7, 0x13

    invoke-direct {v6, p0, v7}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v7, "\u041f\u043e\u0432\u0435\u0440\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    const-string v8, "\u041d\u0443\u0436\u043d\u043e \u0434\u043b\u044f \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0433\u043e \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u044f \u044d\u043a\u0440\u0430\u043d\u0430."

    invoke-virtual {p0, v7, v4, v8, v6}, Lc/k3;->Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-static {v1}, Lru/drivedeck/launcher/NotificationBridgeService;->a(Landroid/content/Context;)Z

    move-result v6

    new-instance v7, Lc/u2;

    const/16 v8, 0x16

    invoke-direct {v7, p0, v8}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v8, "\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f \u0438 \u043c\u0443\u0437\u044b\u043a\u0430"

    const-string v9, "\u0422\u0440\u0435\u043a\u0438, \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u043f\u043b\u0435\u0435\u0440\u043e\u043c \u0438 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f \u0432 \u0432\u0438\u0434\u0436\u0435\u0442\u0430\u0445."

    invoke-virtual {p0, v8, v6, v9, v7}, Lc/k3;->Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v6

    const-string v7, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v1, v7}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v7

    if-nez v7, :cond_2

    move v7, v2

    goto :goto_3

    :cond_2
    move v7, v5

    :goto_3
    new-instance v8, Lc/u2;

    const/16 v9, 0x19

    invoke-direct {v8, p0, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u041c\u0435\u0441\u0442\u043e\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    const-string v10, "\u041f\u043e\u0433\u043e\u0434\u0430 \u0438 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u044f \u043f\u043e GPS."

    invoke-virtual {p0, v9, v7, v10, v8}, Lc/k3;->Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v8

    new-instance v9, Lc/u2;

    const/16 v10, 0x1b

    invoke-direct {v9, p0, v10}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v10, "\u0421\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0435 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438"

    const-string v11, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0441\u043b\u0443\u0436\u0431\u0443 \u00abDriveDeck: \u0434\u0432\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f\u00bb."

    invoke-virtual {p0, v10, v8, v11, v9}, Lc/k3;->Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v8

    const-string v9, "android.permission.INJECT_EVENTS"

    invoke-virtual {v1, v9}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v9

    if-nez v9, :cond_3

    move v9, v2

    goto :goto_4

    :cond_3
    move v9, v5

    :goto_4
    if-eqz v9, :cond_4

    const-string v10, "\u041a\u0430\u0441\u0430\u043d\u0438\u044f \u043f\u0435\u0440\u0435\u0434\u0430\u044e\u0442\u0441\u044f \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f\u043c \u0432 \u0432\u0438\u0440\u0442\u0443\u0430\u043b\u044c\u043d\u044b\u0445 \u043e\u043a\u043d\u0430\u0445."

    goto :goto_5

    :cond_4
    const-string v10, "\u041d\u0443\u0436\u043d\u0430 \u0441\u0438\u0441\u0442\u0435\u043c\u043d\u0430\u044f \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u043b\u0430\u0443\u043d\u0447\u0435\u0440\u0430. \u041e\u0431\u044b\u0447\u043d\u043e\u0433\u043e \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f Android \u043d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e."

    :goto_5
    const/4 v11, 0x0

    const-string v12, "\u0423\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u043e\u043a\u043d\u0430\u043c\u0438"

    invoke-virtual {p0, v12, v9, v10, v11}, Lc/k3;->Q(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v9

    const/16 v10, 0xc

    invoke-virtual {p0, v0, v3, v4, v10}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    invoke-virtual {p0, v0, v6, v7, v10}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    const/16 v3, 0x10

    invoke-virtual {p0, v0, v8, v9, v3}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    invoke-static {v1}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const-string v6, "android.permission.RECORD_AUDIO"

    const-string v7, "ru.drivedeck.voice"

    invoke-virtual {v1, v6, v7}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_5

    move v8, v2

    goto :goto_6

    :cond_5
    move v8, v5

    :goto_6
    if-nez v4, :cond_6

    const-string v1, "\u041c\u043e\u0434\u0443\u043b\u044c \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    :goto_7
    move-object v9, v1

    goto :goto_8

    :cond_6
    if-eqz v8, :cond_7

    const-string v1, "\u0414\u043e\u0441\u0442\u0443\u043f \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d"

    goto :goto_7

    :cond_7
    const-string v1, "\u041d\u0443\u0436\u0435\u043d \u0434\u043e\u0441\u0442\u0443\u043f"

    goto :goto_7

    :goto_8
    new-instance v12, Lc/K1;

    const/4 v1, 0x1

    invoke-direct {v12, p0, v4, v1}, Lc/K1;-><init>(Ljava/lang/Object;ZI)V

    const-string v10, "\u0414\u043e\u0441\u0442\u0443\u043f \u043a \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d\u0443 \u0434\u043b\u044f \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0433\u043e \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u044f DriveDeck Voice."

    const-string v11, "\u041d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u044c"

    const-string v7, "\u041c\u0438\u043a\u0440\u043e\u0444\u043e\u043d"

    move-object v6, p0

    invoke-virtual/range {v6 .. v12}, Lc/k3;->R(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {p0, v0, v1, v3, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    return-void
.end method

.method public final dismiss()V
    .locals 2

    const/4 v0, 0x0

    iput-object v0, p0, Lc/k3;->p:Ljava/lang/String;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lc/k3;->o:Z

    iget-object v1, p0, Lc/k3;->n:Landroid/animation/ValueAnimator;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/animation/Animator;->removeAllListeners()V

    iget-object v1, p0, Lc/k3;->n:Landroid/animation/ValueAnimator;

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v0, p0, Lc/k3;->n:Landroid/animation/ValueAnimator;

    :cond_0
    invoke-super {p0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method public final e(Ljava/lang/String;)V
    .locals 3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    :try_start_0
    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0, p1}, Lc/Y3;->b(Landroid/content/Context;Ljava/lang/String;)Lc/Y3;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u043d\u0430\u0431\u043e\u0440 \u0438\u043a\u043e\u043d\u043e\u043a. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0441\u043e\u0432\u043c\u0435\u0441\u0442\u0438\u043c\u043e\u0441\u0442\u044c \u0441 Nova/ADW."

    invoke-virtual {p0, p1}, Lc/k3;->J(Ljava/lang/String;)V

    return-void

    :cond_0
    :goto_0
    iget-object v0, p0, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "icon_pack_package"

    invoke-interface {v1, v2, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object p1, p0, Lc/k3;->b:Lc/z;

    invoke-virtual {p1}, Lc/z;->k()V

    iget-object p1, p0, Lc/k3;->d:Lc/u0;

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {p0}, Lc/k3;->X()V

    return-void
.end method

.method public final e0()V
    .locals 36

    move-object/from16 v10, p0

    const-string v2, "visibility"

    const-string v5, "music"

    const-string v7, "home"

    iget-object v12, v10, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v8, v10, Lc/k3;->c:Lc/n1;

    const-string v6, ""

    iget-object v11, v10, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/high16 v9, 0x3f800000    # 1.0f

    const/4 v3, -0x1

    const/4 v1, 0x0

    const/high16 v19, 0x44340000    # 720.0f

    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    move-result v20

    sparse-switch v20, :sswitch_data_0

    :goto_0
    move v12, v3

    goto/16 :goto_1

    :sswitch_0
    const-string v14, "home_apps"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_0

    goto :goto_0

    :cond_0
    const/16 v12, 0xc

    goto/16 :goto_1

    :sswitch_1
    invoke-virtual {v12, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_1

    goto :goto_0

    :cond_1
    const/16 v12, 0xb

    goto/16 :goto_1

    :sswitch_2
    const-string v14, "permissions"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_2

    goto :goto_0

    :cond_2
    const/16 v12, 0xa

    goto/16 :goto_1

    :sswitch_3
    const-string v14, "voice"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_3

    goto :goto_0

    :cond_3
    const/16 v12, 0x9

    goto/16 :goto_1

    :sswitch_4
    const-string v14, "theme"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_4

    goto :goto_0

    :cond_4
    const/16 v12, 0x8

    goto :goto_1

    :sswitch_5
    const-string v14, "pairs"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_5

    goto :goto_0

    :cond_5
    const/4 v12, 0x7

    goto :goto_1

    :sswitch_6
    invoke-virtual {v12, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_6

    goto :goto_0

    :cond_6
    const/4 v12, 0x6

    goto :goto_1

    :sswitch_7
    invoke-virtual {v12, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_7

    goto :goto_0

    :cond_7
    const/4 v12, 0x5

    goto :goto_1

    :sswitch_8
    const-string v14, "dock"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_8

    goto :goto_0

    :cond_8
    const/4 v12, 0x4

    goto :goto_1

    :sswitch_9
    const-string v14, "obd"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_9

    goto :goto_0

    :cond_9
    const/4 v12, 0x3

    goto :goto_1

    :sswitch_a
    const-string v14, "updates"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_a

    goto :goto_0

    :cond_a
    const/4 v12, 0x2

    goto :goto_1

    :sswitch_b
    const-string v14, "author"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_b

    goto/16 :goto_0

    :cond_b
    const/4 v12, 0x1

    goto :goto_1

    :sswitch_c
    const-string v14, "language"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_c

    goto/16 :goto_0

    :cond_c
    move v12, v1

    :goto_1
    packed-switch v12, :pswitch_data_0

    goto/16 :goto_32

    :pswitch_0
    invoke-virtual {v10, v7}, Lc/k3;->Y(Ljava/lang/String;)V

    goto/16 :goto_32

    :pswitch_1
    invoke-virtual {v10, v2}, Lc/k3;->Y(Ljava/lang/String;)V

    goto/16 :goto_32

    :pswitch_2
    invoke-virtual/range {p0 .. p0}, Lc/k3;->d0()V

    goto/16 :goto_32

    :pswitch_3
    invoke-virtual/range {p0 .. p0}, Lc/k3;->g0()V

    goto/16 :goto_32

    :pswitch_4
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v5

    cmpg-float v5, v5, v19

    if-gez v5, :cond_d

    const/4 v5, 0x1

    goto :goto_2

    :cond_d
    move v5, v1

    :goto_2
    iget-object v7, v10, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v2}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v12

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v14, v3, v1, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v12, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v7

    const-string v12, "light"

    const-string v14, "dark"

    const-string v3, "black"

    const-string v9, "auto"

    filled-new-array {v12, v14, v3, v9}, [Ljava/lang/String;

    move-result-object v12

    const-string v1, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    const-string v13, "\u0421\u0432\u0435\u0442\u043b\u0430\u044f"

    const-string v4, "\u0422\u0451\u043c\u043d\u0430\u044f"

    const-string v0, "\u0427\u0451\u0440\u043d\u0430\u044f"

    filled-new-array {v13, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v1

    const-string v15, "\u041f\u043e\u0447\u0442\u0438 \u0447\u0451\u0440\u043d\u044b\u0435 \u043f\u043e\u0432\u0435\u0440\u0445\u043d\u043e\u0441\u0442\u0438 \u0434\u043b\u044f \u0442\u0451\u043c\u043d\u043e\u0439 \u043a\u0430\u0431\u0438\u043d\u044b"

    move-object/from16 v21, v9

    const-string v9, "\u041f\u043e \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u043c \u0443\u0441\u043b\u043e\u0432\u0438\u044f\u043c"

    move/from16 v22, v5

    const-string v5, "\u0421\u0432\u0435\u0442\u043b\u044b\u0435 \u043f\u043e\u0432\u0435\u0440\u0445\u043d\u043e\u0441\u0442\u0438 \u0438 \u0442\u0451\u043c\u043d\u044b\u0439 \u0442\u0435\u043a\u0441\u0442"

    move-object/from16 v23, v0

    const-string v0, "\u041f\u0440\u0438\u0433\u043b\u0443\u0448\u0451\u043d\u043d\u044b\u0435 \u0446\u0432\u0435\u0442\u0430 \u0434\u043b\u044f \u043d\u043e\u0447\u043d\u044b\u0445 \u043f\u043e\u0435\u0437\u0434\u043e\u043a"

    filled-new-array {v5, v0, v15, v9}, [Ljava/lang/String;

    move-result-object v0

    const-string v5, "\u0426\u0432\u0435\u0442\u043e\u0432\u0430\u044f \u0442\u0435\u043c\u0430"

    invoke-virtual {v10, v5}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v9

    const/16 v15, 0x30

    invoke-virtual {v9, v15}, Landroid/widget/LinearLayout;->setGravity(I)V

    move-object/from16 v24, v14

    const/4 v15, 0x0

    :goto_3
    const-string v14, ", \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    move-object/from16 v25, v2

    const/4 v2, 0x4

    if-ge v15, v2, :cond_17

    aget-object v2, v12, v15

    move-object/from16 v26, v12

    invoke-virtual {v8}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    move-object/from16 v27, v4

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v4

    move-object/from16 v29, v6

    move-object/from16 v28, v13

    const/high16 v13, 0x40800000    # 4.0f

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v6

    move-object/from16 v30, v7

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v7

    move-object/from16 v31, v5

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v5

    move-object/from16 v32, v9

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v4, v6, v7, v5, v9}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v5

    if-nez v15, :cond_e

    const/4 v6, 0x1

    new-array v7, v6, [Lc/r4;

    sget-object v9, Lc/r4;->n:Lc/r4;

    const/4 v13, 0x0

    aput-object v9, v7, v13

    goto :goto_5

    :cond_e
    const/4 v6, 0x1

    const/4 v13, 0x0

    if-ne v15, v6, :cond_f

    new-array v7, v6, [Lc/r4;

    sget-object v9, Lc/r4;->o:Lc/r4;

    aput-object v9, v7, v13

    goto :goto_5

    :cond_f
    const/4 v7, 0x2

    if-ne v15, v7, :cond_10

    new-array v7, v6, [Lc/r4;

    sget-object v6, Lc/r4;->p:Lc/r4;

    aput-object v6, v7, v13

    goto :goto_5

    :cond_10
    sget-object v6, Lc/r4;->n:Lc/r4;

    invoke-virtual {v8}, Lc/n1;->h()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_11

    sget-object v7, Lc/r4;->p:Lc/r4;

    goto :goto_4

    :cond_11
    sget-object v7, Lc/r4;->o:Lc/r4;

    :goto_4
    filled-new-array {v6, v7}, [Lc/r4;

    move-result-object v7

    :goto_5
    const/4 v6, 0x0

    :goto_6
    array-length v9, v7

    if-ge v6, v9, :cond_13

    aget-object v9, v7, v6

    const-string v13, "Aa"

    move-object/from16 v34, v3

    move-object/from16 v33, v7

    const/16 v3, 0x16

    const/4 v7, 0x1

    invoke-virtual {v10, v3, v13, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v13

    const/16 v3, 0x11

    invoke-virtual {v13, v3}, Landroid/widget/TextView;->setGravity(I)V

    iget v3, v9, Lc/r4;->d:I

    invoke-virtual {v13, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget v3, v9, Lc/r4;->b:I

    const/16 v7, 0xc

    invoke-virtual {v10, v3, v7}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v13, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42400000    # 48.0f

    invoke-virtual {v10, v7}, Lc/k3;->x(F)I

    move-result v9

    move-object/from16 v35, v8

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    invoke-direct {v3, v8, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v6, :cond_12

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v10, v7}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_12
    invoke-virtual {v5, v13, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x1

    add-int/2addr v6, v3

    move-object/from16 v7, v33

    move-object/from16 v3, v34

    move-object/from16 v8, v35

    goto :goto_6

    :cond_13
    move-object/from16 v34, v3

    move-object/from16 v35, v8

    const/4 v3, 0x4

    const/4 v8, 0x0

    invoke-virtual {v10, v4, v5, v8, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    aget-object v3, v1, v15

    const/16 v5, 0xc

    invoke-virtual {v10, v5, v3, v12}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    const/16 v5, 0x11

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v5, 0x2

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/4 v7, -0x1

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v3, v10, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->c:I

    const/16 v5, 0x10

    invoke-virtual {v10, v3, v5}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    if-eqz v12, :cond_14

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {v10, v6}, Lc/k3;->x(F)I

    move-result v6

    const v7, -0xe98801    # -2.0000725E38f

    invoke-virtual {v3, v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_14
    new-instance v6, Landroid/graphics/drawable/RippleDrawable;

    const/4 v7, 0x0

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v8

    const/4 v7, -0x1

    invoke-virtual {v10, v7, v5}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    invoke-direct {v6, v8, v3, v9}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v4, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v4, v12}, Landroid/view/View;->setSelected(Z)V

    const/4 v3, 0x1

    invoke-virtual {v4, v3}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v4}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v5, v1, v15

    invoke-static {v11, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ". "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v5, v0, v15

    invoke-static {v11, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v12, :cond_15

    invoke-static {v11, v14}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_7

    :cond_15
    move-object/from16 v5, v29

    :goto_7
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v3, Lc/I2;

    const/4 v5, 0x3

    invoke-direct {v3, v10, v2, v5}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v4, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    invoke-direct {v2, v6, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v15, :cond_16

    const/high16 v5, 0x41000000    # 8.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v7

    iput v7, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_16
    move-object/from16 v5, v32

    invoke-virtual {v5, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    add-int/2addr v15, v2

    move-object v9, v5

    move-object/from16 v2, v25

    move-object/from16 v12, v26

    move-object/from16 v4, v27

    move-object/from16 v13, v28

    move-object/from16 v6, v29

    move-object/from16 v7, v30

    move-object/from16 v5, v31

    move-object/from16 v3, v34

    move-object/from16 v8, v35

    goto/16 :goto_3

    :cond_17
    move-object/from16 v34, v3

    move-object/from16 v27, v4

    move-object v4, v5

    move-object/from16 v29, v6

    move-object/from16 v30, v7

    move-object/from16 v35, v8

    move-object v5, v9

    move-object/from16 v28, v13

    const/16 v2, 0x8

    const/4 v3, -0x2

    const/4 v6, 0x0

    invoke-virtual {v10, v4, v5, v2, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v1, v30

    invoke-virtual {v1, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041d\u0430\u0431\u043e\u0440 \u0438\u043a\u043e\u043d\u043e\u043a"

    invoke-virtual {v10, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    sget-object v4, Lc/Y3;->e:[Ljava/lang/String;

    const/4 v5, 0x0

    :goto_8
    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ge v5, v7, :cond_1d

    aget-object v7, v4, v5

    :try_start_0
    invoke-virtual {v11}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v8

    new-instance v9, Landroid/content/Intent;

    invoke-direct {v9, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    invoke-virtual {v8, v9, v7}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v8
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v8, :cond_19

    :catch_0
    :cond_18
    const/4 v6, 0x1

    goto :goto_b

    :cond_19
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :catch_1
    :goto_9
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_18

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/content/pm/ResolveInfo;

    iget-object v9, v8, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-nez v9, :cond_1a

    goto :goto_9

    :cond_1a
    iget-object v9, v9, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v3, v9}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1b

    goto :goto_9

    :cond_1b
    :try_start_1
    iget-object v8, v8, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v8, v8, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    invoke-virtual {v11}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v12

    invoke-virtual {v8, v12}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v8

    new-instance v12, Lc/Y3;

    if-nez v8, :cond_1c

    move-object v8, v9

    goto :goto_a

    :cond_1c
    invoke-interface {v8}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v8

    :goto_a
    invoke-direct {v12, v9, v8, v6, v6}, Lc/Y3;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/res/Resources;Ljava/util/HashMap;)V

    invoke-virtual {v3, v9, v12}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_9

    :goto_b
    add-int/2addr v5, v6

    goto :goto_8

    :cond_1d
    new-instance v4, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v3, Lc/v;

    const/4 v5, 0x5

    invoke-direct {v3, v5}, Lc/v;-><init>(I)V

    sget-object v5, Ljava/lang/String;->CASE_INSENSITIVE_ORDER:Ljava/util/Comparator;

    invoke-static {v3, v5}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;Ljava/util/Comparator;)Ljava/util/Comparator;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    move-object/from16 v3, v35

    iget-object v5, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    const-string v7, "icon_pack_package"

    move-object/from16 v8, v29

    invoke-interface {v5, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0435 \u0438\u043a\u043e\u043d\u043a\u0438"

    invoke-static {v11, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_1e
    :goto_c
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_1f

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lc/Y3;

    iget-object v15, v13, Lc/Y3;->a:Ljava/lang/String;

    invoke-virtual {v15, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_1e

    iget-object v9, v13, Lc/Y3;->b:Ljava/lang/String;

    goto :goto_c

    :cond_1f
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_20

    invoke-static {v11, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_20

    const-string v12, "\u041d\u0430\u0431\u043e\u0440 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u2014 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u044e\u0442\u0441\u044f \u0441\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0435 \u0438\u043a\u043e\u043d\u043a\u0438."

    invoke-virtual {v10, v12}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v12

    const/16 v13, 0x8

    const/4 v15, 0x0

    invoke-virtual {v10, v2, v12, v15, v13}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_d

    :cond_20
    const/16 v13, 0x8

    :goto_d
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual {v12, v13}, Landroid/view/View;->setVisibility(I)V

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, "  \u25be"

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    new-instance v15, Lc/j1;

    const/4 v6, 0x2

    invoke-direct {v15, v12, v6}, Lc/j1;-><init>(Landroid/widget/LinearLayout;I)V

    const/4 v6, 0x0

    invoke-virtual {v10, v13, v6, v15}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v13

    const/16 v6, 0x10

    invoke-virtual {v13, v6}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v6, 0x41c00000    # 24.0f

    invoke-virtual {v10, v6}, Lc/k3;->x(F)I

    move-result v15

    move-object/from16 v29, v8

    move-object/from16 v26, v14

    const/high16 v14, 0x41000000    # 8.0f

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v10, v6}, Lc/k3;->x(F)I

    move-result v6

    move-object/from16 v35, v3

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v13, v15, v8, v6, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v11, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ": "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    new-instance v3, Lc/S2;

    const/4 v6, 0x3

    invoke-direct {v3, v10, v6}, Lc/S2;-><init>(Lc/k3;I)V

    invoke-virtual {v10, v7, v0, v3}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setSelected(Z)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x42400000    # 48.0f

    invoke-virtual {v10, v6}, Lc/k3;->x(F)I

    move-result v7

    const/4 v6, -0x1

    invoke-direct {v3, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v0, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_e
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_21

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/Y3;

    iget-object v4, v3, Lc/Y3;->b:Ljava/lang/String;

    iget-object v6, v3, Lc/Y3;->a:Ljava/lang/String;

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    new-instance v8, Lc/H;

    const/16 v9, 0x8

    invoke-direct {v8, v10, v3, v9}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v4, v7, v8}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v4, 0x0

    invoke-virtual {v10, v12, v3, v9, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_e

    :cond_21
    const/4 v4, 0x0

    const/16 v9, 0x8

    invoke-virtual {v10, v2, v13, v9, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Lc/u2;

    invoke-direct {v0, v10, v4}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v3, "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c APK\u2026"

    invoke-virtual {v10, v3, v4, v0}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v10, v2, v0, v9, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Lc/u2;

    const/4 v3, 0x1

    invoke-direct {v0, v10, v3}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v3, "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a"

    invoke-virtual {v10, v3, v4, v0}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v10, v2, v0, v9, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v10, v2, v12, v9, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 APK-\u043d\u0430\u0431\u043e\u0440 \u0434\u043b\u044f Nova/ADW \u0438 \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u0435 \u0441\u043f\u0438\u0441\u043e\u043a. \u0415\u0441\u043b\u0438 \u0437\u0430\u043c\u0435\u043d\u044b \u043d\u0435\u0442, \u043e\u0441\u0442\u0430\u043d\u0435\u0442\u0441\u044f \u043e\u0431\u044b\u0447\u043d\u0430\u044f \u0438\u043a\u043e\u043d\u043a\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f."

    invoke-virtual {v10, v0}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v10, v2, v0, v9, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/16 v0, 0xc

    invoke-virtual {v10, v1, v2, v0, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0422\u0435\u043c\u0430 \u043f\u043e \u0432\u0440\u0435\u043c\u0435\u043d\u0438"

    invoke-virtual {v10, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v3, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v3}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v3, "\u041f\u043e \u0440\u0430\u0441\u043f\u0438\u0441\u0430\u043d\u0438\u044e"

    invoke-static {v11, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const-string v4, "theme_schedule_enabled"

    move-object/from16 v5, v35

    iget-object v6, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v7, 0x0

    invoke-interface {v6, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v4, Lc/D2;

    const/16 v7, 0xa

    invoke-direct {v4, v10, v7}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v2, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const-string v4, "\u041c\u0435\u0441\u0442\u043d\u043e\u0435 \u0432\u0440\u0435\u043c\u044f \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0430. \u0420\u0430\u0441\u043f\u0438\u0441\u0430\u043d\u0438\u0435 \u0438\u043c\u0435\u0435\u0442 \u043f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442 \u043f\u0435\u0440\u0435\u0434 \u0444\u0430\u0440\u0430\u043c\u0438 \u0438 \u0437\u0430\u043a\u0430\u0442\u043e\u043c."

    invoke-virtual {v10, v3, v4, v2}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v4, v28

    invoke-static {v11, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " \u00b7 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lc/n1;->N()I

    move-result v7

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v8

    div-int/lit8 v9, v7, 0x3c

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    rem-int/lit8 v7, v7, 0x3c

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v9, v7}, [Ljava/lang/Object;

    move-result-object v7

    const-string v9, "%02d:%02d"

    invoke-static {v8, v9, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    new-instance v7, Lc/u2;

    const/16 v8, 0x14

    invoke-direct {v7, v10, v8}, Lc/u2;-><init>(Lc/k3;I)V

    const/4 v8, 0x0

    invoke-virtual {v10, v3, v8, v7}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v3

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v8, v27

    invoke-static {v11, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Lc/n1;->M()I

    move-result v4

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v12

    div-int/lit8 v13, v4, 0x3c

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    rem-int/lit8 v4, v4, 0x3c

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v13, v4}, [Ljava/lang/Object;

    move-result-object v4

    invoke-static {v12, v9, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v7, Lc/u2;

    const/16 v9, 0x15

    invoke-direct {v7, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const/4 v9, 0x0

    invoke-virtual {v10, v4, v9, v7}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v7, v9, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v7

    invoke-direct {v3, v9, v7, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v7, 0x41400000    # 12.0f

    invoke-virtual {v10, v7}, Lc/k3;->x(F)I

    move-result v12

    iput v12, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v2, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v3, 0xc

    invoke-virtual {v10, v0, v2, v3, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move-object/from16 v3, v25

    const/16 v2, 0x10

    invoke-virtual {v10, v3, v0, v2, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u043e\u0435 \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435"

    invoke-virtual {v10, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v4, "\u041f\u043e \u0441\u0438\u0433\u043d\u0430\u043b\u0443 \u0444\u0430\u0440"

    invoke-static {v11, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v7, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v7}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v5}, Lc/n1;->d0()Z

    move-result v7

    invoke-virtual {v2, v7}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v7, Lc/D2;

    const/16 v9, 0xb

    invoke-direct {v7, v10, v9}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v2, v7}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v7, Landroid/widget/Switch;

    invoke-direct {v7, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v9, "\u041d\u0435 \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0430\u0442\u044c \u043f\u043e \u0444\u0430\u0440\u0430\u043c \u0434\u043d\u0451\u043c"

    invoke-static {v11, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v7, v12}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v12, "ignore_daytime_headlights"

    const/4 v13, 0x0

    invoke-interface {v6, v12, v13}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    invoke-virtual {v7, v14}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-virtual {v5}, Lc/n1;->d0()Z

    move-result v13

    invoke-virtual {v7, v13}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v5}, Lc/n1;->d0()Z

    move-result v13

    if-eqz v13, :cond_22

    const/high16 v13, 0x3f800000    # 1.0f

    goto :goto_f

    :cond_22
    const v13, 0x3f266666    # 0.65f

    :goto_f
    invoke-virtual {v7, v13}, Landroid/view/View;->setAlpha(F)V

    new-instance v13, Lc/D2;

    const/16 v15, 0xc

    invoke-direct {v13, v10, v15}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v7, v13}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v13, Landroid/widget/Switch;

    invoke-direct {v13, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v15, "\u041f\u043e\u0441\u043b\u0435 \u0437\u0430\u043a\u0430\u0442\u0430"

    invoke-static {v11, v15}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v14, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v13, v14}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v14, "auto_theme_sunset"

    move-object/from16 v30, v1

    const/4 v1, 0x1

    invoke-interface {v6, v14, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    invoke-virtual {v13, v14}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v1, Lc/D2;

    const/16 v14, 0xd

    invoke-direct {v1, v10, v14}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v13, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v14, "\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u0442\u0435\u043c\u0443 \u043f\u0440\u0438 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0438 \u0441\u0432\u0435\u0442\u0430."

    invoke-virtual {v10, v4, v14, v2}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v2, "\u0414\u043d\u0451\u043c \u0441\u0438\u0433\u043d\u0430\u043b \u0444\u0430\u0440 \u043d\u0435 \u043c\u0435\u043d\u044f\u0435\u0442 \u0442\u0435\u043c\u0443. \u0411\u0435\u0437 \u0434\u0430\u043d\u043d\u044b\u0445 \u043f\u043e\u0433\u043e\u0434\u044b \u0434\u0435\u043d\u044c \u2014 \u0441 07:00 \u0434\u043e 19:00."

    invoke-virtual {v10, v9, v2, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v4, "\u0411\u0435\u0437 \u0434\u0430\u043d\u043d\u044b\u0445 \u043f\u043e\u0433\u043e\u0434\u044b \u0437\u0430\u043a\u0430\u0442 \u2014 19:00."

    invoke-virtual {v10, v15, v4, v13}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v4, 0x4

    const/4 v7, 0x0

    invoke-virtual {v10, v0, v1, v4, v7}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-interface {v6, v12, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_23

    goto :goto_10

    :cond_23
    const-string v2, "\u041b\u044e\u0431\u043e\u0435 \u0443\u0441\u043b\u043e\u0432\u0438\u0435 \u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u0442\u0451\u043c\u043d\u0443\u044e \u0442\u0435\u043c\u0443. \u0411\u0435\u0437 \u0434\u0430\u043d\u043d\u044b\u0445 \u043f\u043e\u0433\u043e\u0434\u044b \u0437\u0430\u043a\u0430\u0442 \u2014 19:00."

    :goto_10
    invoke-virtual {v10, v2}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v10, v0, v1, v7, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u0422\u0451\u043c\u043d\u044b\u0439 \u0432\u0430\u0440\u0438\u0430\u043d\u0442"

    invoke-virtual {v10, v1}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v10, v0, v1, v4, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {v10, v2}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v10, v2}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v10, v2}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v10, v2}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v1, v4, v7, v9, v12}, Landroid/view/View;->setPadding(IIII)V

    iget-object v2, v10, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->b:I

    const/16 v4, 0x3e8

    invoke-virtual {v10, v2, v4}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    move-object/from16 v2, v24

    move-object/from16 v4, v34

    filled-new-array {v2, v4}, [Ljava/lang/String;

    move-result-object v2

    move-object/from16 v4, v23

    filled-new-array {v8, v4}, [Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    :goto_11
    const/4 v8, 0x2

    if-ge v7, v8, :cond_27

    aget-object v8, v2, v7

    invoke-virtual {v5}, Lc/n1;->h()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    aget-object v12, v4, v7

    new-instance v13, Lc/x2;

    const/4 v14, 0x7

    invoke-direct {v13, v10, v8, v14}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    const/4 v8, 0x0

    invoke-virtual {v10, v12, v8, v13}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v12

    invoke-virtual {v12, v9}, Landroid/widget/TextView;->setSelected(Z)V

    if-eqz v9, :cond_24

    invoke-virtual/range {p0 .. p0}, Lc/k3;->o0()I

    move-result v8

    goto :goto_12

    :cond_24
    const/4 v8, 0x0

    :goto_12
    invoke-virtual {v10, v8}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v8

    invoke-virtual {v12, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v13, v4, v7

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v9, :cond_25

    const-string v9, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    goto :goto_13

    :cond_25
    move-object/from16 v9, v29

    :goto_13
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v11, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v8}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {v12}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v9, 0x42400000    # 48.0f

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v9, 0x3f800000    # 1.0f

    const/4 v14, 0x0

    invoke-direct {v8, v14, v13, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v7, :cond_26

    const/high16 v9, 0x40800000    # 4.0f

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v13

    iput v13, v8, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_26
    invoke-virtual {v1, v12, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x1

    add-int/2addr v7, v8

    goto :goto_11

    :cond_27
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x42600000    # 56.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v4

    const/4 v7, -0x1

    invoke-direct {v2, v7, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v22, :cond_28

    move-object/from16 v2, v30

    const/4 v1, 0x0

    invoke-virtual {v10, v3, v2, v1, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/16 v2, 0xc

    invoke-virtual {v10, v3, v0, v2, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_14

    :cond_28
    move-object/from16 v2, v30

    const/4 v1, 0x0

    new-instance v4, Lc/u8;

    invoke-direct {v4, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x30

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const v8, 0x3fcccccd    # 1.6f

    const/4 v9, -0x2

    invoke-direct {v7, v1, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v8, 0x41400000    # 12.0f

    invoke-virtual {v10, v8}, Lc/k3;->x(F)I

    move-result v12

    iput v12, v7, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v4, v2, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v2, v1, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    invoke-direct {v0, v1, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_14
    const-string v0, "\u041e\u0431\u043e\u0438"

    invoke-virtual {v10, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/16 v2, 0x30

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v2, 0x0

    :goto_15
    const/4 v4, 0x3

    if-ge v2, v4, :cond_2d

    sget-object v4, Lc/G8;->x:[Ljava/lang/String;

    aget-object v4, v4, v2

    invoke-virtual {v5}, Lc/n1;->a0()Z

    move-result v7

    if-eqz v7, :cond_29

    invoke-virtual {v5}, Lc/n1;->T()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_29

    const/4 v7, 0x1

    goto :goto_16

    :cond_29
    const/4 v7, 0x0

    :goto_16
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v8

    const/high16 v9, 0x40800000    # 4.0f

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v13

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v8, v12, v13, v14, v15}, Landroid/view/View;->setPadding(IIII)V

    const/4 v9, 0x0

    invoke-virtual {v10, v9}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v12

    invoke-virtual {v8, v12}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v9, Landroid/widget/ImageView;

    invoke-direct {v9, v11}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    iget-boolean v12, v12, Lc/r4;->m:Z

    const/16 v13, 0xc8

    const/16 v14, 0x78

    invoke-static {v13, v14, v4, v12}, Lc/G8;->s(IILjava/lang/String;Z)Landroid/graphics/Bitmap;

    move-result-object v12

    invoke-virtual {v9, v12}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    sget-object v12, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v9, v12}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    iget v12, v12, Lc/r4;->b:I

    const/16 v13, 0x8

    invoke-virtual {v10, v12, v13}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v12

    invoke-virtual {v9, v12}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v12, 0x1

    invoke-virtual {v9, v12}, Landroid/view/View;->setClipToOutline(Z)V

    if-eqz v7, :cond_2a

    const/4 v12, 0x0

    invoke-virtual {v10, v12, v13}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v14

    const/high16 v12, 0x40000000    # 2.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    iget v12, v12, Lc/r4;->d:I

    invoke-virtual {v14, v13, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {v9, v14}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    :cond_2a
    const/4 v12, 0x2

    invoke-virtual {v9, v12}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x42c00000    # 96.0f

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v14

    const/4 v15, -0x1

    invoke-direct {v13, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    sget-object v9, Lc/G8;->y:[Ljava/lang/String;

    aget-object v13, v9, v2

    const/16 v14, 0xe

    invoke-virtual {v10, v14, v13, v7}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v13

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, -0x2

    invoke-direct {v12, v15, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v14, 0x40800000    # 4.0f

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v15

    iput v15, v12, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v8, v13, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v8, v7}, Landroid/view/View;->setSelected(Z)V

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v9, v9, v2

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v7, :cond_2b

    move-object/from16 v7, v26

    goto :goto_17

    :cond_2b
    move-object/from16 v7, v29

    :goto_17
    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v11, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v8, v7}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {v8}, Lc/k3;->h(Landroid/view/View;)V

    new-instance v7, Lc/I2;

    const/4 v9, 0x0

    invoke-direct {v7, v10, v4, v9}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v8, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v4, v9, v7, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v2, :cond_2c

    const/high16 v7, 0x41000000    # 8.0f

    invoke-virtual {v10, v7}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_2c
    invoke-virtual {v1, v8, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    add-int/2addr v2, v4

    goto/16 :goto_15

    :cond_2d
    const/4 v4, 0x1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v7

    new-instance v8, Lc/u2;

    const/4 v9, 0x6

    invoke-direct {v8, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435\u2026"

    invoke-virtual {v10, v9, v4, v8}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v8

    const/4 v4, 0x0

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/4 v9, 0x2

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setMaxLines(I)V

    const/high16 v9, 0x41000000    # 8.0f

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v12

    const/high16 v13, 0x40800000    # 4.0f

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v8, v12, v14, v15, v9}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v9, v4, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Lc/u2;

    const/4 v9, 0x7

    invoke-direct {v8, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u0411\u0435\u0437 \u043e\u0431\u043e\u0435\u0432"

    invoke-virtual {v10, v9, v4, v8}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v5}, Lc/n1;->a0()Z

    move-result v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v5}, Lc/n1;->a0()Z

    move-result v9

    if-eqz v9, :cond_2e

    const/high16 v9, 0x3f800000    # 1.0f

    goto :goto_18

    :cond_2e
    const v9, 0x3f266666    # 0.65f

    :goto_18
    invoke-virtual {v8, v9}, Landroid/view/View;->setAlpha(F)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v9, v4, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    iput v13, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v7, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    const/4 v12, -0x1

    invoke-direct {v8, v12, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v7

    new-instance v8, Lc/u2;

    const/16 v9, 0x8

    invoke-direct {v8, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u0414\u043b\u044f \u0434\u043d\u044f\u2026"

    invoke-virtual {v10, v9, v4, v8}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v8

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v9, v4, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v9

    invoke-direct {v8, v4, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v9, 0x41000000    # 8.0f

    invoke-virtual {v10, v9}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v8, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    new-instance v9, Lc/u2;

    const/16 v12, 0x9

    invoke-direct {v9, v10, v12}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v12, "\u0414\u043b\u044f \u043d\u043e\u0447\u0438\u2026"

    invoke-virtual {v10, v12, v4, v9}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v7, v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v8, 0x8

    invoke-virtual {v10, v2, v7, v8, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v7

    cmpg-float v7, v7, v19

    if-gez v7, :cond_2f

    const/4 v7, 0x4

    invoke-virtual {v10, v0, v1, v8, v7}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v10, v0, v2, v8, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/4 v2, 0x4

    goto :goto_19

    :cond_2f
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v7

    const/16 v8, 0x30

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const v9, 0x3f99999a    # 1.2f

    const/4 v12, -0x2

    invoke-direct {v8, v4, v12, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v7, v1, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v1, v4, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v8, 0x41800000    # 16.0f

    invoke-virtual {v10, v8}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v7, v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x8

    const/4 v2, 0x4

    invoke-virtual {v10, v0, v7, v1, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_19
    const-string v1, "\u041f\u0430\u043b\u0438\u0442\u0440\u0430 \u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0432\u043c\u0435\u0441\u0442\u0435 \u0441 \u0442\u0435\u043c\u043e\u0439."

    invoke-virtual {v10, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v10, v0, v1, v2, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u0421\u0432\u043e\u0438 \u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u044f \u0434\u043b\u044f \u0441\u0432\u0435\u0442\u043b\u043e\u0439 \u0438 \u0442\u0451\u043c\u043d\u043e\u0439 \u0442\u0435\u043c\u044b. \u0413\u043e\u0442\u043e\u0432\u0430\u044f \u043f\u0430\u043b\u0438\u0442\u0440\u0430 \u0438\u043b\u0438 \u043e\u0431\u0449\u0430\u044f \u043a\u0430\u0440\u0442\u0438\u043d\u043a\u0430 \u0437\u0430\u043c\u0435\u043d\u044f\u0435\u0442 \u043e\u0431\u0430 \u0432\u044b\u0431\u043e\u0440\u0430."

    invoke-virtual {v10, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v1, 0xc

    invoke-virtual {v10, v3, v0, v1, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0435 \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u0435"

    invoke-virtual {v10, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v2, "\u0422\u043e\u043b\u044c\u043a\u043e \u0432 \u0442\u0451\u043c\u043d\u043e\u0439 \u0442\u0435\u043c\u0435"

    invoke-static {v11, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v4, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v4}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v4, "dimmer_dark_only"

    const/4 v7, 0x0

    invoke-interface {v6, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/Switch;->setChecked(Z)V

    const-string v4, "dimmer_by_headlights"

    invoke-interface {v6, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    if-nez v8, :cond_31

    invoke-virtual {v5}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v7

    move-object/from16 v8, v21

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_30

    invoke-virtual {v5}, Lc/n1;->d0()Z

    move-result v7

    if-nez v7, :cond_31

    :cond_30
    const/4 v7, 0x1

    goto :goto_1a

    :cond_31
    const/4 v7, 0x0

    :goto_1a
    invoke-virtual {v1, v7}, Landroid/view/View;->setEnabled(Z)V

    new-instance v7, Lc/D2;

    const/4 v8, 0x0

    invoke-direct {v7, v10, v8}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v7}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v7, Landroid/widget/Switch;

    invoke-direct {v7, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v9, "\u0412\u043a\u043b\u044e\u0447\u0430\u0442\u044c \u043f\u043e \u0441\u0438\u0433\u043d\u0430\u043b\u0443 \u0444\u0430\u0440"

    invoke-static {v11, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v7, v12}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-interface {v6, v4, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-virtual {v7, v4}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v4, Lc/E2;

    invoke-direct {v4, v10, v1, v8}, Lc/E2;-><init>(Lc/k3;Landroid/widget/Switch;I)V

    invoke-virtual {v7, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v4

    const-string v6, "\u0421\u0432\u0435\u0442 \u0432\u043a\u043b\u044e\u0447\u0451\u043d \u2014 \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f, \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d \u2014 \u0441\u043d\u0438\u043c\u0430\u0435\u0442\u0441\u044f."

    invoke-virtual {v10, v9, v6, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v6, "\u0417\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f \u0442\u043e\u043b\u044c\u043a\u043e \u0432 \u0442\u0451\u043c\u043d\u043e\u0439 \u0442\u0435\u043c\u0435. \u0421\u0438\u0433\u043d\u0430\u043b \u0444\u0430\u0440 \u0438\u043c\u0435\u0435\u0442 \u043f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442."

    invoke-virtual {v10, v2, v6, v1}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v2, "\u0418\u043d\u0442\u0435\u043d\u0441\u0438\u0432\u043d\u043e\u0441\u0442\u044c"

    const-string v6, "0% \u2014 \u0431\u0435\u0437 \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u044f, \u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c \u2014 75%."

    const/4 v7, 0x0

    invoke-virtual {v10, v2, v6, v7}, Lc/k3;->r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5}, Lc/n1;->k()I

    move-result v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "%"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/16 v7, 0x16

    invoke-virtual {v10, v7, v2, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v6

    const/16 v7, 0x10

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x42400000    # 48.0f

    invoke-virtual {v10, v8}, Lc/k3;->x(F)I

    move-result v9

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v12, 0x0

    invoke-direct {v7, v12, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v2, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/SeekBar;

    invoke-direct {v7, v11}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v8, 0x4b

    invoke-virtual {v7, v8}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v5}, Lc/n1;->k()I

    move-result v5

    invoke-virtual {v7, v5}, Landroid/widget/ProgressBar;->setProgress(I)V

    const-string v5, "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u044f \u0432 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u0430\u0445"

    invoke-static {v11, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v7, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v8, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v7, v8}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v9

    const/4 v5, -0x1

    invoke-direct {v8, v5, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v5, 0x40800000    # 4.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v8, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    new-instance v5, Lc/Y2;

    const/4 v9, 0x3

    invoke-direct {v5, v10, v2, v9}, Lc/Y2;-><init>(Lc/k3;Ljava/lang/Object;I)V

    invoke-virtual {v7, v5}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v2, Lc/H;

    const/16 v5, 0x9

    invoke-direct {v2, v10, v7, v5}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v5, "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    const/4 v9, 0x0

    invoke-virtual {v10, v5, v9, v2}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual/range {p0 .. p0}, Lc/k3;->n()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v6, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v5

    const/4 v12, -0x1

    invoke-direct {v2, v12, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v1, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v22, :cond_32

    const/16 v2, 0x8

    invoke-virtual {v10, v0, v4, v2, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v10, v0, v1, v2, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move v1, v2

    goto :goto_1b

    :cond_32
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v5, 0x30

    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-direct {v5, v9, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v9, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v5, 0x41800000    # 16.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v2, v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x8

    invoke-virtual {v10, v0, v2, v1, v9}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_1b
    const-string v2, "\u041a\u0430\u043a \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0434\u0438\u043c\u043c\u0435\u0440"

    invoke-virtual {v10, v2}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    const-string v4, "\u0417\u0430\u0442\u0435\u043c\u043d\u044f\u0435\u0442 \u0432\u0435\u0441\u044c \u044d\u043a\u0440\u0430\u043d, \u0432\u043a\u043b\u044e\u0447\u0430\u044f \u043e\u0442\u043a\u0440\u044b\u0442\u044b\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f. \u0417\u0430\u0432\u043e\u0434\u0441\u043a\u0430\u044f \u044f\u0440\u043a\u043e\u0441\u0442\u044c \u043f\u043e\u0434\u0441\u0432\u0435\u0442\u043a\u0438 \u043d\u0435 \u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f. 0% \u2014 \u0431\u0435\u0437 \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u044f, \u043c\u0430\u043a\u0441\u0438\u043c\u0443\u043c \u2014 75%."

    invoke-virtual {v10, v4}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v10, v2, v4, v1, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u00ab\u0412\u043a\u043b\u044e\u0447\u0430\u0442\u044c \u043f\u043e \u0441\u0438\u0433\u043d\u0430\u043b\u0443 \u0444\u0430\u0440\u00bb: \u0441\u0432\u0435\u0442 \u0432\u043a\u043b\u044e\u0447\u0451\u043d \u2014 \u0437\u0430\u0442\u0435\u043c\u043d\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u044f\u0435\u0442\u0441\u044f, \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d \u2014 \u0441\u043d\u0438\u043c\u0430\u0435\u0442\u0441\u044f. \u0420\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u0441 \u043b\u044e\u0431\u043e\u0439 \u0442\u0435\u043c\u043e\u0439 \u0438 \u0438\u043c\u0435\u0435\u0442 \u043f\u0440\u0438\u043e\u0440\u0438\u0442\u0435\u0442 \u043d\u0430\u0434 \u00ab\u0422\u043e\u043b\u044c\u043a\u043e \u0432 \u0442\u0451\u043c\u043d\u043e\u0439 \u0442\u0435\u043c\u0435\u00bb."

    invoke-virtual {v10, v1}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v11}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_33

    const/4 v1, 0x0

    invoke-virtual {v7, v1}, Landroid/view/View;->setEnabled(Z)V

    const-string v4, "\u041d\u0443\u0436\u0435\u043d \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u043f\u043e\u043a\u0430\u0437\u0443 \u043f\u043e\u0432\u0435\u0440\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439."

    invoke-virtual {v10, v4}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    const/16 v5, 0xc

    invoke-virtual {v10, v2, v4, v5, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v4, Lc/u2;

    const/4 v5, 0x4

    invoke-direct {v4, v10, v5}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v5, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044c \u0434\u043e\u0441\u0442\u0443\u043f"

    invoke-virtual {v10, v5, v1, v4}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual/range {p0 .. p0}, Lc/k3;->n()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_1c

    :cond_33
    const/4 v1, 0x0

    :goto_1c
    if-eqz v22, :cond_34

    const/16 v4, 0x10

    invoke-virtual {v10, v3, v0, v4, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v10, v3, v2, v4, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto/16 :goto_32

    :cond_34
    new-instance v4, Lc/u8;

    invoke-direct {v4, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/high16 v7, 0x40000000    # 2.0f

    invoke-direct {v5, v1, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v5, 0x41400000    # 12.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v4, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0x10

    invoke-virtual {v10, v3, v4, v0, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto/16 :goto_32

    :pswitch_5
    invoke-virtual/range {p0 .. p0}, Lc/k3;->c0()V

    goto/16 :goto_32

    :pswitch_6
    invoke-virtual {v10, v5}, Lc/k3;->Y(Ljava/lang/String;)V

    goto/16 :goto_32

    :pswitch_7
    move-object/from16 v29, v6

    move-object v5, v8

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v1

    cmpg-float v1, v1, v19

    if-gez v1, :cond_35

    const/4 v1, 0x1

    goto :goto_1d

    :cond_35
    const/4 v1, 0x0

    :goto_1d
    iget-object v2, v10, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v0}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, -0x1

    const/4 v8, 0x0

    invoke-direct {v4, v7, v8, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v2, 0x7f03004b

    const-string v3, "\u041a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0438 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430"

    move-object/from16 v4, v29

    invoke-virtual {v10, v2, v3, v4}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-static {v11}, Lc/q4;->s(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v3

    const-string v6, "drivedeck_presets"

    invoke-virtual {v11, v6, v8}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "selected"

    invoke-interface {v6, v7, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v11}, Lc/q4;->s(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v7

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_36

    goto :goto_1e

    :cond_36
    move-object v6, v4

    :goto_1e
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v8

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v9

    new-instance v12, Landroid/widget/EditText;

    invoke-direct {v12, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v13, 0x41800000    # 16.0f

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v13, v10, Lc/k3;->g:Lc/r4;

    iget v13, v13, Lc/r4;->d:I

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->y0()I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setHintTextColor(I)V

    const-string v13, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0438"

    invoke-static {v11, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    invoke-static {v11, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v13, Landroid/text/InputFilter$LengthFilter;

    const/16 v14, 0x40

    invoke-direct {v13, v14}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    const/4 v14, 0x1

    new-array v15, v14, [Landroid/text/InputFilter;

    const/4 v14, 0x0

    aput-object v13, v15, v14

    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setFilters([Landroid/text/InputFilter;)V

    iget-object v13, v10, Lc/k3;->g:Lc/r4;

    iget v13, v13, Lc/r4;->b:I

    const/16 v15, 0x10

    invoke-virtual {v10, v13, v15}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v13

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v13

    invoke-virtual {v12, v15, v14, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    move/from16 v16, v1

    const/high16 v15, 0x42400000    # 48.0f

    invoke-virtual {v10, v15}, Lc/k3;->x(F)I

    move-result v1

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v13, v14, v1, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v1, 0x7f030021

    const-string v13, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443"

    invoke-virtual {v10, v13, v1}, Lc/k3;->A0(Ljava/lang/String;I)Landroid/widget/ImageButton;

    move-result-object v1

    new-instance v13, Lc/w2;

    invoke-direct {v13, v10, v12, v14}, Lc/w2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x42400000    # 48.0f

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v15

    move-object/from16 v35, v5

    invoke-virtual {v10, v14}, Lc/k3;->x(F)I

    move-result v5

    invoke-direct {v13, v15, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v5, 0x41000000    # 8.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v13, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v9, v1, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x2

    new-array v5, v1, [Landroid/widget/TextView;

    new-instance v1, Lc/i3;

    invoke-direct {v1, v3, v5}, Lc/i3;-><init>(Ljava/util/ArrayList;[Landroid/widget/TextView;)V

    invoke-virtual {v12, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    invoke-virtual {v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_37

    const-string v1, "\u041d\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0445 \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043e\u043a"

    invoke-virtual {v10, v1}, Lc/k3;->A(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_37
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_39

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v13

    invoke-virtual {v9, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    new-instance v15, Lc/x2;

    move-object/from16 v17, v1

    const/4 v1, 0x0

    invoke-direct {v15, v10, v9, v1}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v10, v9, v14, v15}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v14

    const/4 v15, 0x2

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v15, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v18, v0

    move-object/from16 v29, v4

    const/high16 v4, 0x42400000    # 48.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v0

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-direct {v15, v1, v0, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443: "

    invoke-virtual {v0, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lc/x2;

    const/4 v4, 0x1

    invoke-direct {v1, v10, v9, v4}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v10, v0, v1}, Lc/k3;->t(Ljava/lang/String;Ljava/lang/Runnable;)Lc/X2;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x42400000    # 48.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v14

    invoke-direct {v1, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v4, 0x41000000    # 8.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v13, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-nez v0, :cond_38

    const/4 v0, 0x0

    :goto_20
    const/4 v1, 0x0

    goto :goto_21

    :cond_38
    const/16 v0, 0x8

    goto :goto_20

    :goto_21
    invoke-virtual {v10, v8, v13, v0, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move-object/from16 v1, v17

    move-object/from16 v0, v18

    move-object/from16 v4, v29

    goto :goto_1f

    :cond_39
    move-object/from16 v18, v0

    move-object/from16 v29, v4

    const/4 v1, 0x0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v4, Lc/u2;

    const/4 v9, 0x2

    invoke-direct {v4, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u0443\u044e"

    invoke-virtual {v10, v9, v1, v4}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v9

    const/4 v13, 0x1

    xor-int/2addr v9, v13

    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setEnabled(Z)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x42400000    # 48.0f

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v14

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v9, v1, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v4, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Lc/u2;

    const/4 v9, 0x3

    invoke-direct {v4, v10, v9}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v9, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0444\u0430\u0439\u043b"

    invoke-virtual {v10, v9, v1, v4}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v14

    invoke-direct {v9, v1, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v13, 0x41000000    # 8.0f

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v4, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x8

    invoke-virtual {v10, v7, v0, v4, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v4, Lc/y2;

    invoke-direct {v4, v10, v12, v1}, Lc/y2;-><init>(Lc/k3;Landroid/widget/EditText;I)V

    const-string v9, "\u042d\u043a\u0441\u043f\u043e\u0440\u0442 \u0432 \u0444\u0430\u0439\u043b"

    invoke-virtual {v10, v9, v1, v4}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    new-instance v9, Lc/y2;

    const/4 v13, 0x1

    invoke-direct {v9, v10, v12, v13}, Lc/y2;-><init>(Lc/k3;Landroid/widget/EditText;I)V

    const-string v12, "\u041f\u043e\u0434\u0435\u043b\u0438\u0442\u044c\u0441\u044f"

    invoke-virtual {v10, v12, v1, v9}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    aput-object v4, v5, v1

    aput-object v9, v5, v13

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    invoke-virtual {v9, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x42400000    # 48.0f

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v6

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v3, v1, v6, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v5}, Lc/k3;->x(F)I

    move-result v4

    invoke-direct {v3, v1, v4, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v4, 0x41000000    # 8.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v4

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v9, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v3, 0x8

    invoke-virtual {v10, v7, v0, v3, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v0, Landroid/widget/ScrollView;

    invoke-direct {v0, v11}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v8}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v1

    cmpg-float v1, v1, v19

    if-gez v1, :cond_3a

    const/4 v1, 0x1

    goto :goto_22

    :cond_3a
    const/4 v1, 0x0

    :goto_22
    if-eqz v1, :cond_3b

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v3

    goto :goto_23

    :cond_3b
    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v3

    :goto_23
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz v1, :cond_3c

    const/4 v5, -0x1

    goto :goto_24

    :cond_3c
    const/4 v5, 0x0

    :goto_24
    const/4 v6, 0x0

    if-eqz v1, :cond_3d

    move v8, v6

    :goto_25
    const/4 v9, -0x2

    goto :goto_26

    :cond_3d
    const/high16 v8, 0x3f800000    # 1.0f

    goto :goto_25

    :goto_26
    invoke-direct {v4, v5, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz v1, :cond_3e

    const/4 v5, -0x1

    goto :goto_27

    :cond_3e
    const/4 v5, 0x0

    :goto_27
    const/high16 v7, 0x43200000    # 160.0f

    invoke-virtual {v10, v7}, Lc/k3;->x(F)I

    move-result v7

    if-eqz v1, :cond_3f

    goto :goto_28

    :cond_3f
    const/high16 v6, 0x3f800000    # 1.0f

    :goto_28
    invoke-direct {v4, v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-eqz v1, :cond_40

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v10, v1}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    goto :goto_29

    :cond_40
    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v10, v1}, Lc/k3;->x(F)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :goto_29
    invoke-virtual {v3, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0x8

    const/4 v1, 0x0

    invoke-virtual {v10, v2, v3, v0, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0421\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442 \u0441\u043e\u0441\u0442\u0430\u0432, \u0440\u0430\u0441\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0438 \u043e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u0435 \u0432\u0438\u0434\u0436\u0435\u0442\u043e\u0432 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430. \u041e\u0442\u0434\u0435\u043b\u044c\u043d\u044b\u0439 \u0444\u0430\u0439\u043b \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u0442 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u0443\u044e \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443. \u0424\u0430\u0439\u043b\u044b \u043e\u0431\u043e\u0435\u0432 \u0438 \u0432\u0441\u0435 \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0438 \u0442\u0430\u043a\u0436\u0435 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u044b \u0432 \u043f\u043e\u043b\u043d\u044b\u0439 \u0430\u0440\u0445\u0438\u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a."

    invoke-virtual {v10, v0}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v3, v18

    const/16 v0, 0xc

    invoke-virtual {v10, v3, v2, v1, v0}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b"

    const v1, 0x7f030052

    move-object/from16 v2, v29

    invoke-virtual {v10, v1, v0, v2}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v4, "\u0421\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0441 \u0434\u0432\u0443\u043c\u044f \u043e\u043a\u043d\u0430\u043c\u0438"

    invoke-static {v11, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v4, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v4}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual/range {v35 .. v35}, Lc/n1;->o0()Z

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v4, Lc/D2;

    const/16 v5, 0xe

    invoke-direct {v4, v10, v5}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v4, 0x8

    const/4 v5, 0x4

    invoke-virtual {v10, v0, v1, v4, v5}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043d\u0430 \u0441\u043b\u0430\u0431\u044b\u0445 \u0413\u0423 \u0441 Android 8.1, \u0447\u0442\u043e\u0431\u044b \u043e\u0441\u0442\u0430\u0432\u0438\u0442\u044c \u0442\u043e\u043b\u044c\u043a\u043e \u0433\u043b\u0430\u0432\u043d\u043e\u0435 \u043e\u043a\u043d\u043e."

    invoke-virtual {v10, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v10, v0}, Lc/k3;->q(Landroid/widget/LinearLayout;)V

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v4, "\u041e\u0434\u0438\u043d\u043e\u0447\u043d\u044b\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0438\u0437 \u0434\u043e\u043a\u0430 \u2014 \u043d\u0430 \u0432\u0435\u0441\u044c \u044d\u043a\u0440\u0430\u043d"

    invoke-static {v11, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v4, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v4}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const-string v4, "dock_single_fullscreen"

    move-object/from16 v5, v35

    iget-object v6, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v7, 0x0

    invoke-interface {v6, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    invoke-virtual {v1, v4}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v4, Lc/D2;

    const/16 v6, 0xf

    invoke-direct {v4, v10, v6}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v4, 0x8

    const/4 v6, 0x4

    invoke-virtual {v10, v0, v1, v4, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041f\u0430\u0440\u044b \u0438\u0437 \u0434\u043e\u043a\u0430 \u043f\u043e-\u043f\u0440\u0435\u0436\u043d\u0435\u043c\u0443 \u043e\u0442\u043a\u0440\u044b\u0432\u0430\u044e\u0442\u0441\u044f \u0432 \u0434\u0432\u0443\u0445 \u043e\u043a\u043d\u0430\u0445."

    invoke-virtual {v10, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v1, "\u041f\u043e\u043b\u043e\u0441\u044b \u043e\u043a\u043e\u043d"

    const v4, 0x7f03008d

    invoke-virtual {v10, v4, v1, v2}, Lc/k3;->p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/high16 v4, 0x40800000    # 4.0f

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v10, v4}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v2, v6, v7, v8, v9}, Landroid/view/View;->setPadding(IIII)V

    iget-object v4, v10, Lc/k3;->g:Lc/r4;

    iget v4, v4, Lc/r4;->b:I

    const/16 v6, 0x3e8

    invoke-virtual {v10, v4, v6}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v4, "\u041e\u0431\u044b\u0447\u043d\u044b\u0435"

    const-string v6, "\u00bd \u0440\u0430\u0437\u043c\u0435\u0440\u0430"

    const-string v7, "\u0421\u043a\u0440\u044b\u0442\u044b"

    filled-new-array {v4, v6, v7}, [Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v7, 0x2

    :goto_2a
    if-gt v6, v7, :cond_43

    invoke-virtual {v5}, Lc/n1;->Z()I

    move-result v8

    if-ne v6, v8, :cond_41

    const/4 v8, 0x1

    goto :goto_2b

    :cond_41
    const/4 v8, 0x0

    :goto_2b
    aget-object v9, v4, v6

    new-instance v12, Lc/N2;

    const/4 v13, 0x1

    invoke-direct {v12, v10, v6, v13}, Lc/N2;-><init>(Lc/k3;II)V

    invoke-virtual {v10, v9, v8, v12}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setSelected(Z)V

    iget-object v12, v10, Lc/k3;->g:Lc/r4;

    invoke-static {v9, v12, v8}, Lc/G8;->B0(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v12, 0x42400000    # 48.0f

    invoke-virtual {v10, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v14, 0x3f800000    # 1.0f

    const/4 v15, 0x0

    invoke-direct {v8, v15, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v13, 0x40800000    # 4.0f

    if-lez v6, :cond_42

    invoke-virtual {v10, v13}, Lc/k3;->x(F)I

    move-result v14

    iput v14, v8, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_42
    invoke-virtual {v2, v9, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x1

    add-int/2addr v6, v8

    goto :goto_2a

    :cond_43
    const/16 v6, 0x8

    const/4 v8, 0x4

    invoke-virtual {v10, v1, v2, v6, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v2, "\u041f\u043e\u043b\u043e\u0441\u044b \u043e\u043a\u043e\u043d \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u044e\u0442\u0441\u044f \u0432 \u043e\u0431\u044b\u0447\u043d\u043e\u043c \u0440\u0430\u0437\u043c\u0435\u0440\u0435."

    const-string v4, "\u041f\u043e\u043b\u043e\u0441\u044b \u043e\u043a\u043e\u043d \u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0430\u044e\u0442\u0441\u044f \u0432 \u043f\u043e\u043b\u043e\u0432\u0438\u043d\u043d\u043e\u043c \u0440\u0430\u0437\u043c\u0435\u0440\u0435."

    const-string v6, "\u0421\u043a\u0440\u044b\u0442\u044b\u0435 \u043f\u043e\u043b\u043e\u0441\u044b \u043f\u043e\u044f\u0432\u043b\u044f\u044e\u0442\u0441\u044f \u0441\u0432\u0430\u0439\u043f\u043e\u043c \u0432\u0432\u0435\u0440\u0445 \u043e\u0442 \u043d\u0438\u0436\u043d\u0435\u0433\u043e \u043a\u0440\u0430\u044f \u043d\u0430 5 \u0441\u0435\u043a\u0443\u043d\u0434."

    filled-new-array {v2, v4, v6}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5}, Lc/n1;->Z()I

    move-result v4

    aget-object v2, v2, v4

    invoke-virtual {v10, v2}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v2, 0x0

    invoke-virtual {v10, v2}, Lc/k3;->B(I)Landroid/widget/LinearLayout;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {v10, v5}, Lc/k3;->B(I)Landroid/widget/LinearLayout;

    move-result-object v5

    if-nez v16, :cond_44

    new-instance v6, Lc/u8;

    invoke-direct {v6, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x30

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x2

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v7, v2, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v11, 0x41800000    # 16.0f

    invoke-virtual {v10, v11}, Lc/k3;->x(F)I

    move-result v11

    iput v11, v7, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v6, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v2, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    invoke-direct {v2, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x10

    goto :goto_2c

    :cond_44
    const/4 v7, -0x1

    const/4 v8, -0x2

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x10

    invoke-virtual {v10, v3, v5, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_2c
    invoke-virtual {v10, v3, v0, v1, v4}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    goto/16 :goto_32

    :pswitch_8
    invoke-virtual/range {p0 .. p0}, Lc/k3;->Z()V

    goto/16 :goto_32

    :pswitch_9
    iget-object v0, v10, Lc/k3;->j:Landroid/widget/LinearLayout;

    new-instance v1, Lc/H6;

    iget-object v2, v10, Lc/k3;->g:Lc/r4;

    invoke-direct {v1, v11, v2}, Lc/H6;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/r4;)V

    iget-object v2, v10, Lc/k3;->h:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object v5, v10, Lc/k3;->u:Ljava/util/HashMap;

    invoke-virtual {v5, v2, v4}, Ljava/util/HashMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v5

    new-instance v6, Lc/d3;

    invoke-direct {v6, v10, v1, v4, v2}, Lc/d3;-><init>(Lc/k3;Landroid/widget/ScrollView;ILjava/lang/String;)V

    invoke-virtual {v5, v6}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, -0x1

    invoke-direct {v2, v5, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto/16 :goto_32

    :pswitch_a
    invoke-virtual/range {p0 .. p0}, Lc/k3;->f0()V

    goto/16 :goto_32

    :pswitch_b
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual/range {p0 .. p0}, Lc/k3;->s0()F

    move-result v0

    cmpg-float v0, v0, v19

    if-ltz v0, :cond_47

    invoke-virtual {v11}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iget-object v1, v10, Lc/k3;->i:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_45

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    if-lez v1, :cond_45

    iget-object v1, v10, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    :goto_2d
    int-to-float v1, v1

    div-float/2addr v1, v0

    goto :goto_2e

    :cond_45
    invoke-virtual {v11}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    goto :goto_2d

    :goto_2e
    const/high16 v0, 0x441b0000    # 620.0f

    cmpg-float v0, v1, v0

    if-gez v0, :cond_46

    goto :goto_2f

    :cond_46
    const/4 v13, 0x0

    goto :goto_30

    :cond_47
    :goto_2f
    const/4 v13, 0x1

    :goto_30
    iget-object v0, v10, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v12}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, -0x1

    const/4 v5, 0x0

    invoke-direct {v2, v4, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v14, Lc/u8;

    invoke-direct {v14, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    if-eqz v13, :cond_48

    const/4 v0, 0x1

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    :cond_48
    const v8, 0x7f0300cd

    const-string v9, "QR-\u043a\u043e\u0434 Telegram-\u043a\u0430\u043d\u0430\u043b\u0430 \u0430\u0432\u0442\u043e\u0440\u0430"

    const-string v1, "telegram"

    const v2, -0xdd6127

    const-string v3, "Telegram-\u043a\u0430\u043d\u0430\u043b"

    const-string v4, "\u0421\u043b\u0435\u0434\u0438\u0442\u0435 \u0437\u0430 \u043d\u043e\u0432\u043e\u0441\u0442\u044f\u043c\u0438"

    const-string v6, "\u041d\u043e\u0432\u043e\u0441\u0442\u0438, \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u0438 \u0430\u043d\u043e\u043d\u0441\u044b \u043d\u043e\u0432\u044b\u0445 \u0444\u0443\u043d\u043a\u0446\u0438\u0439 DriveDeck."

    const-string v7, "https://t.me/drivedeck"

    const-string v15, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c Telegram"

    move-object/from16 v0, p0

    move-object v5, v6

    move-object v6, v7

    move-object v7, v15

    invoke-virtual/range {v0 .. v9}, Lc/k3;->f(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v10, v14, v0, v13}, Lc/k3;->b(Lc/u8;Landroid/widget/LinearLayout;Z)V

    const v8, 0x7f030014

    const-string v9, "QR-\u043a\u043e\u0434 \u0442\u0435\u043c\u044b DriveDeck \u043d\u0430 4PDA"

    const-string v1, "?"

    const v2, -0x928a27

    const-string v3, "\u041e\u0431\u0441\u0443\u0436\u0434\u0435\u043d\u0438\u0435 \u043d\u0430 4PDA"

    const-string v4, "\u0412\u043e\u043f\u0440\u043e\u0441\u044b \u0438 \u043e\u0431\u0440\u0430\u0442\u043d\u0430\u044f \u0441\u0432\u044f\u0437\u044c"

    const-string v5, "\u041e\u0431\u0441\u0443\u0436\u0434\u0435\u043d\u0438\u0435, \u043f\u043e\u043c\u043e\u0449\u044c \u043e\u0442 \u0441\u043e\u043e\u0431\u0449\u0435\u0441\u0442\u0432\u0430 \u0438 \u043f\u0440\u0435\u0434\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u043f\u043e \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044e."

    const-string v6, "https://4pda.to/forum/index.php?showtopic=1126294"

    const-string v7, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u0442\u0435\u043c\u0443 \u043d\u0430 4PDA"

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v9}, Lc/k3;->f(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v10, v14, v0, v13}, Lc/k3;->b(Lc/u8;Landroid/widget/LinearLayout;Z)V

    if-nez v13, :cond_49

    const/16 v0, 0x10

    const/4 v15, 0x0

    invoke-virtual {v10, v12, v14, v0, v15}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v14, Lc/u8;

    invoke-direct {v14, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    goto :goto_31

    :cond_49
    const/4 v15, 0x0

    :goto_31
    const v8, 0x7f03000c

    const-string v9, "QR-\u043a\u043e\u0434 \u0434\u043b\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0438 \u043f\u0440\u043e\u0435\u043a\u0442\u0430"

    const-string v1, "\u2665"

    const v2, -0x28c390

    const-string v3, "\u041f\u043e\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044c \u043f\u0440\u043e\u0435\u043a\u0442"

    const-string v4, "\u0421\u043f\u0430\u0441\u0438\u0431\u043e \u0437\u0430 \u0432\u0430\u0448\u0443 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0443"

    const-string v5, "\u0414\u043e\u0431\u0440\u043e\u0432\u043e\u043b\u044c\u043d\u0430\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430 \u043f\u043e\u043c\u043e\u0433\u0430\u0435\u0442 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044c DriveDeck."

    const-string v6, "https://pay.cloudtips.ru/p/f9a01c46"

    const-string v7, "\u041f\u043e\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044c \u043f\u0440\u043e\u0435\u043a\u0442"

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v9}, Lc/k3;->f(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v10, v14, v0, v13}, Lc/k3;->b(Lc/u8;Landroid/widget/LinearLayout;Z)V

    const v8, 0x7f03000b

    const-string v9, "QR-\u043a\u043e\u0434 Boosty \u0434\u043b\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0438 \u043f\u0440\u043e\u0435\u043a\u0442\u0430"

    const-string v1, "B"

    const v2, -0xea0d4

    const-string v3, "\u041f\u043e\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044c \u0447\u0435\u0440\u0435\u0437 Boosty"

    const-string v4, "\u0414\u043b\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0438 \u0438\u0437 \u0434\u0440\u0443\u0433\u0438\u0445 \u0441\u0442\u0440\u0430\u043d"

    const-string v5, "\u0414\u043e\u0431\u0440\u043e\u0432\u043e\u043b\u044c\u043d\u0430\u044f \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0430 \u043f\u043e\u043c\u043e\u0433\u0430\u0435\u0442 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044c DriveDeck."

    const-string v6, "https://boosty.to/drivedeck"

    const-string v7, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c Boosty"

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v9}, Lc/k3;->f(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v10, v14, v0, v13}, Lc/k3;->b(Lc/u8;Landroid/widget/LinearLayout;Z)V

    const/16 v0, 0x10

    invoke-virtual {v10, v12, v14, v0, v15}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_32

    :pswitch_c
    invoke-virtual/range {p0 .. p0}, Lc/k3;->b0()V

    :goto_32
    invoke-virtual/range {p0 .. p0}, Lc/k3;->a0()V

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0x602d6ca8 -> :sswitch_c
        -0x53d2de75 -> :sswitch_b
        -0xdf91f36 -> :sswitch_a
        0x1acf1 -> :sswitch_9
        0x2f2233 -> :sswitch_8
        0x30f4df -> :sswitch_7
        0x636ee25 -> :sswitch_6
        0x657f8d9 -> :sswitch_5
        0x69375c9 -> :sswitch_4
        0x6b2e132 -> :sswitch_3
        0x4392f484 -> :sswitch_2
        0x73b66312 -> :sswitch_1
        0x7e38c1d2 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final f(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/widget/LinearLayout;
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p6

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v5

    const-string v6, "settings-card:"

    invoke-virtual {v6, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v5, v7, v8, v9, v6}, Landroid/view/View;->setPadding(IIII)V

    iget-object v6, v0, Lc/k3;->g:Lc/r4;

    iget v6, v6, Lc/r4;->c:I

    const/16 v7, 0x10

    invoke-virtual {v0, v6, v7}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v8, "telegram"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    iget-object v9, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v10, -0x1

    const/4 v11, 0x1

    const/16 v12, 0x12

    if-eqz v8, :cond_0

    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, v9}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v8, 0x7f0300a2

    invoke-virtual {v1, v8}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v8, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v8}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v8, 0x41600000    # 14.0f

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v13

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v14

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v15

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v1, v13, v14, v15, v8}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v0, v2, v12}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v2, "Telegram"

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    const/16 v8, 0x1e

    invoke-virtual {v0, v8, v1, v11}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    const/16 v8, 0x11

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v1, v10}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v0, v2, v12}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v8, 0x42600000    # 56.0f

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v12

    invoke-virtual {v0, v8}, Lc/k3;->x(F)I

    move-result v8

    invoke-direct {v2, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v0, v7, v3, v11}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v2, p4

    invoke-virtual {v0, v2}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v11}, Landroid/widget/TextView;->setSingleLine(Z)V

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    const/4 v12, -0x2

    invoke-direct {v2, v8, v12, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v6, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    move-object/from16 v1, p5

    invoke-virtual {v0, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0xc

    const/16 v3, 0x8

    invoke-virtual {v0, v5, v1, v2, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v1, Landroid/widget/ImageView;

    invoke-direct {v1, v9}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move/from16 v2, p8

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    sget-object v2, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/high16 v2, 0x41200000    # 10.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v1, v6, v8, v9, v2}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v0, v10, v7}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    move-object/from16 v2, p9

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x43040000    # 132.0f

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v0, v6}, Lc/k3;->x(F)I

    move-result v6

    invoke-direct {v2, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iput v11, v2, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    invoke-virtual {v5, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v4}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMinLines(I)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, v5, v1, v3, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v1, Lc/x2;

    const/4 v2, 0x5

    invoke-direct {v1, v0, v4, v2}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    move-object/from16 v2, p7

    invoke-virtual {v0, v2, v11, v1}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x42400000    # 48.0f

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v3

    invoke-direct {v2, v10, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v5
.end method

.method public final f0()V
    .locals 37

    move-object/from16 v0, p0

    const/4 v2, 0x1

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v3

    iget-object v4, v0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v3}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v5

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, 0x0

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u041a\u043e\u043d\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u044f \u0438 \u043f\u0440\u0435\u0441\u0435\u0442\u044b"

    invoke-virtual {v0, v4}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    new-instance v5, Lc/S2;

    invoke-direct {v5, v0, v8}, Lc/S2;-><init>(Lc/k3;I)V

    const-string v6, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c, \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c, \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442"

    invoke-virtual {v0, v6, v8, v5}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v5

    const/16 v6, 0x8

    invoke-virtual {v0, v4, v5, v6, v6}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v5, "\u0420\u0435\u0437\u0435\u0440\u0432\u043d\u0430\u044f \u043a\u043e\u043f\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a \u0438 \u043e\u0431\u043e\u0435\u0432. \u041f\u0440\u0435\u0441\u0435\u0442\u044b \u0441\u043e\u0441\u0442\u0430\u0432\u0430, \u0440\u0430\u0441\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0438 \u043e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u044f \u0432\u0438\u0434\u0436\u0435\u0442\u043e\u0432."

    invoke-virtual {v0, v5}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v5

    const-string v10, "\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f \u043e\u0431 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435"

    invoke-virtual {v0, v10}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v10

    new-instance v11, Landroid/util/DisplayMetrics;

    invoke-direct {v11}, Landroid/util/DisplayMetrics;-><init>()V

    iget-object v15, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v15}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v12

    invoke-interface {v12}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v12

    invoke-virtual {v12, v11}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    const-string v20, "\u0421\u0431\u043e\u0440\u043a\u0430"

    const-string v21, "\u042d\u043a\u0440\u0430\u043d"

    const-string v16, "\u041f\u0440\u043e\u0438\u0437\u0432\u043e\u0434\u0438\u0442\u0435\u043b\u044c"

    const-string v17, "\u041c\u043e\u0434\u0435\u043b\u044c"

    const-string v18, "\u0423\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u043e"

    const-string v19, "Android"

    filled-new-array/range {v16 .. v21}, [Ljava/lang/String;

    move-result-object v12

    sget-object v16, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    sget-object v17, Landroid/os/Build;->MODEL:Ljava/lang/String;

    sget-object v18, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v14, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, " \u00b7 API "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    sget-object v20, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    iget v14, v11, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v14, " \u00d7 "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v14, v11, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v14, " px \u00b7 "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v11, v11, Landroid/util/DisplayMetrics;->densityDpi:I

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, " dpi"

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v21

    filled-new-array/range {v16 .. v21}, [Ljava/lang/String;

    move-result-object v11

    move v13, v8

    :goto_0
    const/4 v14, 0x6

    const/16 v7, 0xe

    const/16 v6, 0x30

    if-ge v13, v14, :cond_0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v14

    invoke-virtual {v14, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    aget-object v6, v12, v13

    invoke-virtual {v0, v6}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    aget-object v1, v11, v13

    invoke-virtual {v0, v7, v1, v8}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v7, v8, v2, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v9, 0x41400000    # 12.0f

    invoke-virtual {v0, v9}, Lc/k3;->x(F)I

    move-result v9

    iput v9, v7, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v14, v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x40000000    # 2.0f

    invoke-direct {v6, v8, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v14, v1, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x8

    invoke-virtual {v0, v10, v14, v1, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/4 v1, 0x1

    add-int/2addr v13, v1

    move v2, v1

    const/16 v6, 0x8

    const/4 v7, -0x1

    const/high16 v9, 0x3f800000    # 1.0f

    goto :goto_0

    :cond_0
    const/4 v2, -0x2

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    invoke-direct {v1, v9, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v10, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0430"

    invoke-virtual {v0, v1}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-static {}, Lc/N1;->C()J

    move-result-wide v9

    const-wide/16 v11, 0x0

    cmp-long v2, v9, v11

    if-lez v2, :cond_1

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v12, "\u0421\u0431\u043e\u0440 \u0432\u043a\u043b\u044e\u0447\u0451\u043d, \u043e\u0441\u0442\u0430\u043b\u043e\u0441\u044c \u043e\u043a\u043e\u043b\u043e "

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-wide/32 v12, 0xea5f

    add-long/2addr v9, v12

    const-wide/32 v12, 0xea60

    div-long/2addr v9, v12

    invoke-virtual {v11, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v9, " \u043c\u0438\u043d."

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_1

    :cond_1
    invoke-static {}, Lc/N1;->s()I

    move-result v9

    if-lez v9, :cond_2

    const-string v9, "\u0415\u0441\u0442\u044c \u0433\u043e\u0442\u043e\u0432\u044b\u0435 \u0437\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u0447\u0451\u0442\u044b."

    goto :goto_1

    :cond_2
    const-string v9, "\u0421\u0431\u043e\u0440 \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d. \u041e\u043d \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0447\u0435\u0440\u0435\u0437 10 \u043c\u0438\u043d\u0443\u0442."

    :goto_1
    invoke-virtual {v0, v9}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v9

    const/16 v10, 0xc

    invoke-virtual {v0, v1, v9, v10, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    if-lez v2, :cond_3

    const-string v9, "\u0421\u0431\u043e\u0440 \u043b\u043e\u0433\u043e\u0432 \u0438\u0434\u0451\u0442"

    goto :goto_2

    :cond_3
    const-string v9, "\u0421\u043e\u0431\u0440\u0430\u0442\u044c \u043b\u043e\u0433\u0438 \u0437\u0430 10 \u043c\u0438\u043d\u0443\u0442"

    :goto_2
    if-nez v2, :cond_4

    const/4 v11, 0x1

    goto :goto_3

    :cond_4
    move v11, v8

    :goto_3
    new-instance v12, Lc/S2;

    const/4 v13, 0x1

    invoke-direct {v12, v0, v13}, Lc/S2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v9, v11, v12}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v9

    if-nez v2, :cond_5

    const/4 v11, 0x1

    goto :goto_4

    :cond_5
    move v11, v8

    :goto_4
    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v11

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/4 v12, 0x2

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setMaxLines(I)V

    const/high16 v12, 0x41000000    # 8.0f

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v13

    const/high16 v14, 0x40800000    # 4.0f

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v7

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v10

    invoke-virtual {v9, v13, v6, v7, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42400000    # 48.0f

    invoke-virtual {v0, v7}, Lc/k3;->o(F)I

    move-result v10

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v6, v8, v10, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v11, v9, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-boolean v6, v0, Lc/k3;->K:Z

    if-eqz v6, :cond_6

    const-string v6, "\u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0430 \u043d\u0430\u043a\u043e\u043f\u043b\u0435\u043d\u043d\u044b\u0445 \u043e\u0442\u0447\u0451\u0442\u043e\u0432\u2026"

    goto :goto_5

    :cond_6
    const-string v6, "\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u0433\u043e\u0442\u043e\u0432\u044b\u0435 \u043b\u043e\u0433\u0438"

    :goto_5
    new-instance v9, Lc/S2;

    const/4 v10, 0x2

    invoke-direct {v9, v0, v10}, Lc/S2;-><init>(Lc/k3;I)V

    invoke-virtual {v0, v6, v8, v9}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v6

    iget-boolean v9, v0, Lc/k3;->K:Z

    if-nez v9, :cond_8

    invoke-static {}, Lc/N1;->p()Z

    move-result v9

    if-nez v9, :cond_8

    invoke-static {}, Lc/N1;->o()Z

    move-result v9

    if-nez v9, :cond_8

    invoke-static {}, Lc/N1;->s()I

    move-result v9

    if-gtz v9, :cond_7

    if-lez v2, :cond_8

    :cond_7
    const/4 v2, 0x1

    goto :goto_6

    :cond_8
    move v2, v8

    :goto_6
    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/4 v2, 0x2

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setMaxLines(I)V

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v9

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v10

    invoke-virtual {v0, v14}, Lc/k3;->x(F)I

    move-result v13

    invoke-virtual {v6, v2, v9, v10, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v0, v7}, Lc/k3;->o(F)I

    move-result v7

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v2, v8, v7, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v12}, Lc/k3;->x(F)I

    move-result v7

    iput v7, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v11, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v7, -0x2

    invoke-direct {v2, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v11, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {}, Lc/N1;->d()Z

    move-result v2

    if-eqz v2, :cond_9

    const-string v2, "\u041f\u043e\u0441\u043b\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0438\u044f \u0437\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u0447\u0451\u0442\u044b \u043e\u0442\u043f\u0440\u0430\u0432\u044f\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438. \u041a\u043d\u043e\u043f\u043a\u0430 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438 \u043e\u0441\u0442\u0430\u0451\u0442\u0441\u044f \u0437\u0430\u043f\u0430\u0441\u043d\u044b\u043c \u0441\u043f\u043e\u0441\u043e\u0431\u043e\u043c."

    goto :goto_7

    :cond_9
    const-string v2, "\u041f\u043e\u043a\u0430 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a \u043d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d: \u0432\u044b\u0431\u0435\u0440\u0438\u0442\u0435 Telegram, \u043f\u043e\u0447\u0442\u0443 \u0438\u043b\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u0435 \u043d\u0430 \u0444\u043b\u0435\u0448\u043a\u0443. \u0412\u0441\u0435 \u0444\u0430\u0439\u043b\u044b \u0437\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u044b."

    :goto_7
    invoke-virtual {v0, v2}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    const/16 v6, 0x8

    invoke-virtual {v0, v1, v2, v6, v8}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x1

    invoke-virtual {v2, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    int-to-float v7, v6

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v2, v8, v8, v8, v6}, Landroid/view/View;->setPadding(IIII)V

    invoke-static {v15}, Lc/k6;->q(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v9

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    iput v10, v9, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v2, v6, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0422\u0435\u043a\u0443\u0449\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f"

    invoke-static {v15, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v10, 0x10

    invoke-static {v9, v10}, Lc/k6;->D(Landroid/widget/TextView;I)V

    sget-object v11, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v12, 0x1

    invoke-virtual {v9, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v11

    invoke-virtual {v6, v9, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v11, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v12, Landroid/widget/ImageView;

    invoke-direct {v12, v15}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v13, 0x7f03001d

    invoke-virtual {v15, v13}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v13

    invoke-static {v15, v13}, Lc/s;->f(Landroid/content/Context;Landroid/graphics/drawable/Drawable;)Lc/q;

    move-result-object v13

    invoke-virtual {v12, v13}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget-object v13, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v12, v13}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const-string v13, "DriveDeck"

    invoke-virtual {v12, v13}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0x48

    int-to-float v14, v14

    invoke-static {v15, v14}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v15, v14}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v14

    invoke-direct {v13, v10, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v10, Landroid/widget/TextView;

    invoke-direct {v10, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    new-instance v13, Ljava/lang/StringBuilder;

    const-string v14, "DriveDeck\n"

    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {v15}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v14
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_2

    move-object/from16 v31, v3

    :try_start_1
    invoke-virtual {v15}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v14, v3, v8}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v3

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v8, v3, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    invoke-virtual {v14, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, " ("

    invoke-virtual {v14, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    move-object/from16 v32, v1

    const/16 v1, 0x1c

    if-lt v8, v1, :cond_a

    :try_start_2
    invoke-static {v3}, Lc/T;->b(Landroid/content/pm/PackageInfo;)J

    move-result-wide v19

    move-object v8, v4

    move-wide/from16 v3, v19

    goto :goto_9

    :catch_0
    :goto_8
    move-object v8, v4

    goto :goto_a

    :cond_a
    iget v1, v3, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_0

    move-object v8, v4

    int-to-long v3, v1

    :goto_9
    :try_start_3
    invoke-virtual {v14, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v14, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_3
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_b

    :catch_1
    move-object/from16 v32, v1

    goto :goto_8

    :catch_2
    move-object/from16 v32, v1

    move-object/from16 v31, v3

    goto :goto_8

    :catch_3
    :goto_a
    const-string v1, "\u2014"

    :goto_b
    invoke-virtual {v13, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v1, 0x10

    invoke-static {v10, v1}, Lc/k6;->D(Landroid/widget/TextView;I)V

    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v3, 0x1

    invoke-virtual {v10, v1, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x0

    const/high16 v13, 0x3f800000    # 1.0f

    const/4 v14, -0x2

    invoke-direct {v3, v4, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v4, 0xc

    int-to-float v13, v4

    invoke-static {v15, v13}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v11, v10, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v6, v11, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iget-object v4, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->P()Ljava/lang/String;

    move-result-object v11

    const-string v13, "alpha"

    invoke-virtual {v13, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    move-object/from16 v33, v8

    const-string v8, "beta"

    if-eqz v14, :cond_b

    const-string v11, "\u0420\u0430\u043d\u043d\u0438\u0435 \u0442\u0435\u0441\u0442\u043e\u0432\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u0431\u0443\u0434\u0443\u0442 \u043f\u0440\u0438\u0445\u043e\u0434\u0438\u0442\u044c \u0438\u0437 \u0430\u043b\u044c\u0444\u0430-\u043a\u0430\u043d\u0430\u043b\u0430."

    goto :goto_c

    :cond_b
    invoke-virtual {v8, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_c

    const-string v11, "\u0422\u0435\u0441\u0442\u043e\u0432\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u041f\u043e\u0441\u043b\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u0431\u0435\u0442\u0430-\u043a\u0430\u043d\u0430\u043b\u0430 \u0432\u044b \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u0435 \u0441\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0441\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u044b\u0439 \u0432\u044b\u043f\u0443\u0441\u043a. \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f \u043e\u0441\u0442\u0430\u043d\u0435\u0442\u0441\u044f."

    goto :goto_c

    :cond_c
    const-string v11, "\u0421\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u041f\u043e\u0441\u043b\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u0442\u0435\u0441\u0442\u043e\u0432\u044b\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u0434\u0451\u0442 \u0441 \u0432\u044b\u0445\u043e\u0434\u043e\u043c \u0431\u043e\u043b\u0435\u0435 \u043d\u043e\u0432\u043e\u0433\u043e \u0441\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u043e\u0433\u043e \u0432\u044b\u043f\u0443\u0441\u043a\u0430."

    :goto_c
    invoke-static {v15, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v11, 0xe

    invoke-static {v3, v11}, Lc/k6;->D(Landroid/widget/TextView;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v11

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v14

    iput v14, v11, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    sget-object v14, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {v3, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v6, v3, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v15}, Lc/k6;->q(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/LinearLayout;

    move-result-object v11

    move-object/from16 v34, v5

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v0

    iput v0, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v2, v11, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v5, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0438 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0439"

    invoke-static {v15, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v5, 0x10

    invoke-static {v0, v5}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v11, v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v5, "\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u0442\u044c \u043a\u0430\u0436\u0434\u044b\u0439 \u0447\u0430\u0441"

    invoke-static {v15, v5}, Lc/k6;->b0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;)Landroid/widget/Switch;

    move-result-object v5

    move-object/from16 v25, v6

    const-string v6, "update_auto"

    move-object/from16 v26, v0

    iget-object v0, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    move-object/from16 v27, v10

    const/4 v10, 0x1

    invoke-interface {v0, v6, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v6, Lc/w6;

    const/4 v10, 0x2

    invoke-direct {v6, v4, v10}, Lc/w6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v5, v6}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v6

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v11, v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v6, "\u0411\u0435\u0442\u0430-\u043a\u0430\u043d\u0430\u043b"

    invoke-static {v15, v6}, Lc/k6;->b0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;)Landroid/widget/Switch;

    move-result-object v6

    invoke-virtual {v4}, Lc/n1;->P()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    invoke-virtual {v6, v8}, Landroid/widget/Switch;->setChecked(Z)V

    const-string v8, "test_update_channels_unlocked_10"

    const/4 v10, 0x0

    invoke-interface {v0, v8, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v19

    if-eqz v19, :cond_d

    const/4 v10, 0x0

    goto :goto_d

    :cond_d
    const/16 v10, 0x8

    :goto_d
    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v10

    invoke-virtual {v11, v6, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v10, "\u0410\u043b\u044c\u0444\u0430-\u043a\u0430\u043d\u0430\u043b"

    invoke-static {v15, v10}, Lc/k6;->b0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;)Landroid/widget/Switch;

    move-result-object v10

    move-object/from16 v28, v5

    invoke-virtual {v4}, Lc/n1;->P()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v13, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    invoke-virtual {v10, v5}, Landroid/widget/Switch;->setChecked(Z)V

    const/4 v5, 0x0

    invoke-interface {v0, v8, v5}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_e

    move v0, v5

    goto :goto_e

    :cond_e
    const/16 v0, 0x8

    :goto_e
    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v11, v10, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    filled-new-array {v5}, [I

    move-result-object v21

    new-instance v0, Lc/j0;

    const/16 v24, 0x6

    move-object/from16 v19, v0

    move-object/from16 v20, v4

    move-object/from16 v22, v6

    move-object/from16 v23, v10

    invoke-direct/range {v19 .. v24}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v12, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {v15}, Lc/k6;->q(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v8, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0438 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430"

    invoke-static {v15, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v8, 0x10

    invoke-static {v5, v8}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/4 v8, 0x1

    invoke-virtual {v5, v1, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    invoke-virtual {v0, v5, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v8, Landroid/widget/TextView;

    invoke-direct {v8, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/16 v12, 0xe

    invoke-static {v8, v12}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/4 v12, 0x2

    int-to-float v13, v12

    invoke-static {v15, v13}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v12

    int-to-float v12, v12

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-virtual {v8, v12, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v12

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v13

    iput v13, v12, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v13

    iput v13, v12, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v0, v8, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v13, Lc/N8;

    invoke-direct {v13, v15}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-static {v15}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v12

    move-object/from16 v24, v11

    const/4 v11, 0x0

    invoke-static {v13, v12, v11}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    invoke-virtual {v13, v11}, Landroid/widget/TextView;->setAllCaps(Z)V

    const-string v11, "\u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-static {v15, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v13, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v13}, Lc/G8;->r(Landroid/widget/TextView;)V

    const/16 v11, 0xe

    invoke-static {v13, v11}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/16 v11, 0x30

    int-to-float v11, v11

    invoke-static {v15, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v12

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setMinHeight(I)V

    const/16 v12, 0x18

    int-to-float v12, v12

    move-object/from16 v21, v5

    invoke-static {v15, v12}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    move-object/from16 v22, v9

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    invoke-static {v15, v12}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v12

    move-object/from16 v23, v3

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v13, v5, v9, v12, v3}, Landroid/view/View;->setPadding(IIII)V

    const/4 v3, 0x0

    invoke-virtual {v13, v3}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v15, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    const/4 v12, -0x2

    invoke-direct {v5, v12, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v13, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v15}, Lc/k6;->q(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v9

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v12

    iput v12, v9, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v2, v5, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v12, "\u041f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0435 \u0432\u0435\u0440\u0441\u0438\u0438"

    invoke-static {v15, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v12, 0x10

    invoke-static {v9, v12}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/4 v12, 0x1

    invoke-virtual {v9, v1, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v5, v9, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v12, ""

    invoke-virtual {v1, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v3, 0xe

    invoke-static {v1, v3}, Lc/k6;->D(Landroid/widget/TextView;I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    move-object/from16 v16, v12

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v12

    iput v12, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v1, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v12, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0442\u0441\u044f. \u0414\u043e\u0441\u0442\u0443\u043f\u043d\u044b \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043b\u0435\u043d\u043d\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438."

    invoke-static {v15, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v3, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v12

    invoke-virtual {v5, v3, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v12, 0x1

    invoke-virtual {v3, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v12

    invoke-virtual {v5, v3, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v15}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v12

    move-object/from16 v18, v13

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    const-string v13, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0432\u0435\u0440\u0441\u0438\u0438"

    invoke-static {v15, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v12}, Lc/G8;->r(Landroid/widget/TextView;)V

    const/16 v13, 0xe

    invoke-static {v12, v13}, Lc/k6;->D(Landroid/widget/TextView;I)V

    invoke-static {v15, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance v13, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v15, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    move-object/from16 v17, v14

    const/4 v14, -0x2

    invoke-direct {v13, v14, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {v15, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v13, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Lc/I3;

    move-object v14, v12

    move-object/from16 v11, v16

    move-object v12, v7

    move-object/from16 v35, v2

    move-object/from16 v2, v18

    move-object v13, v14

    move-object/from16 v30, v5

    move-object/from16 v29, v9

    move-object v5, v14

    move-object/from16 v9, v17

    move-object v14, v3

    move-object/from16 v36, v15

    move-object v15, v1

    move-object/from16 v16, v36

    move-object/from16 v17, v4

    invoke-direct/range {v12 .. v17}, Lc/I3;-><init>(Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/n1;)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v7, 0x0

    filled-new-array {v7}, [Lc/U8;

    move-result-object v20

    const/4 v7, 0x0

    aget-object v12, v20, v7

    if-eqz v12, :cond_f

    invoke-static {v8, v2, v12}, Lc/k6;->n0(Landroid/widget/TextView;Lc/N8;Lc/U8;)V

    goto :goto_f

    :cond_f
    invoke-virtual {v8, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_f
    new-instance v7, Landroid/widget/TextView;

    move-object/from16 v11, v36

    invoke-direct {v7, v11}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v12, "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435, \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430 \u043b\u0438 \u043d\u043e\u0432\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f \u043b\u0430\u0443\u043d\u0447\u0435\u0440\u0430."

    invoke-static {v11, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v7, v9}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v9

    invoke-virtual {v0, v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Lc/L0;

    move-object v12, v7

    move-object/from16 v13, v20

    move-object v14, v2

    move-object v15, v6

    move-object/from16 v16, v10

    move-object/from16 v17, v8

    move-object/from16 v18, v11

    move-object/from16 v19, v4

    invoke-direct/range {v12 .. v19}, Lc/L0;-><init>([Lc/U8;Lc/N8;Landroid/widget/Switch;Landroid/widget/Switch;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/n1;)V

    invoke-virtual {v2, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v7, Lc/K8;

    move-object v12, v7

    move-object v13, v4

    move-object v14, v11

    move-object/from16 v15, v20

    move-object/from16 v16, v3

    move-object/from16 v17, v5

    move-object/from16 v18, v1

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v12 .. v20}, Lc/K8;-><init>(Lc/n1;Lru/drivedeck/launcher/MainActivity;[Lc/U8;Landroid/widget/LinearLayout;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;Lc/N8;)V

    const/4 v3, 0x1

    new-array v4, v3, [Z

    const/4 v9, 0x0

    aput-boolean v9, v4, v9

    new-instance v12, Lc/L8;

    invoke-direct {v12, v4, v10, v7, v9}, Lc/L8;-><init>([ZLandroid/widget/Switch;Lc/K8;I)V

    invoke-virtual {v6, v12}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v9, Lc/L8;

    invoke-direct {v9, v4, v6, v7, v3}, Lc/L8;-><init>([ZLandroid/widget/Switch;Lc/K8;I)V

    invoke-virtual {v10, v9}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v3, Lc/M8;

    move-object v12, v3

    move-object v13, v11

    move-object/from16 v14, v22

    move-object/from16 v15, v27

    move-object/from16 v16, v26

    move-object/from16 v17, v8

    move-object/from16 v18, v21

    move-object/from16 v20, v28

    move-object/from16 v21, v6

    move-object/from16 v22, v10

    move-object/from16 v23, v25

    move-object/from16 v25, v0

    move-object/from16 v26, v30

    move-object/from16 v27, v29

    move-object/from16 v28, v1

    move-object/from16 v29, v5

    move-object/from16 v30, v2

    invoke-direct/range {v12 .. v30}, Lc/M8;-><init>(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Switch;Landroid/widget/Switch;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;Lc/N8;)V

    invoke-virtual {v3}, Lc/M8;->run()V

    new-instance v0, Lc/a4;

    const/4 v1, 0x1

    invoke-direct {v0, v3, v1}, Lc/a4;-><init>(Ljava/lang/Object;I)V

    move-object/from16 v1, v35

    invoke-virtual {v1, v0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    move-object/from16 v0, p0

    iput-object v1, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Lc/k3;->M(Landroid/view/View;)V

    iget-object v1, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-eqz v1, :cond_10

    iget-object v1, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    iget-object v2, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_10
    iget-object v1, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    iget-object v3, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v3, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    iget-object v4, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    iget-object v5, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    const/4 v6, 0x2

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    iget-object v6, v0, Lc/k3;->C:Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v3, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    move-object v6, v1

    check-cast v6, Landroid/widget/LinearLayout;

    const/16 v7, 0xc

    invoke-virtual {v0, v6, v3, v7, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move-object/from16 v6, v34

    const/16 v3, 0x8

    invoke-virtual {v0, v6, v1, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x1

    const/4 v9, -0x2

    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v8, v33

    invoke-virtual {v1, v8, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v7, v32

    invoke-virtual {v0, v1, v7, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v0, v1, v4, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v0, v1, v5, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-static {v4}, Lc/k3;->j(Landroid/view/View;)V

    invoke-static {v5}, Lc/k3;->j(Landroid/view/View;)V

    new-instance v3, Lc/u8;

    invoke-direct {v3, v11}, Lc/u8;-><init>(Landroid/content/Context;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v7, -0x2

    invoke-direct {v4, v2, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v2, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41400000    # 12.0f

    invoke-virtual {v0, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v3, v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v2, v31

    invoke-virtual {v2, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;
    .locals 1

    const/16 v0, 0xe

    invoke-virtual {p0, v0, p1, p2}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    invoke-static {p1, v0, p2}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance p2, Lc/h1;

    const/4 v0, 0x3

    invoke-direct {p2, p3, v0}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setFocusable(Z)V

    return-object p1
.end method

.method public final g0()V
    .locals 30

    move-object/from16 v6, p0

    const/16 v13, 0x8

    const/4 v4, 0x3

    const/4 v3, 0x1

    iget-object v2, v6, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v1

    iget-object v0, v6, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v1}, Lc/k3;->j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;

    move-result-object v8

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v10, 0x0

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v7, v9, v10, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v8, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u0413\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u043c\u043e\u0434\u0443\u043b\u044c"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    :try_start_0
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v8, "ru.drivedeck.voice"

    invoke-virtual {v0, v8, v10}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    const-string v8, " "

    if-nez v0, :cond_0

    const-string v9, "\u041c\u043e\u0434\u0443\u043b\u044c \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    invoke-static {v2, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_1

    :cond_0
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "\u0412\u0435\u0440\u0441\u0438\u044f"

    invoke-static {v2, v15}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v15, v0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    :goto_1
    invoke-virtual {v6, v9}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v9

    const-string v15, "voice-module-version"

    invoke-virtual {v9, v15}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v15

    const v12, 0x7f0300c3

    const v14, 0x7f030051

    const/4 v5, -0x2

    if-nez v0, :cond_1

    new-instance v0, Lc/a1;

    invoke-direct {v0, v4}, Lc/a1;-><init>(I)V

    const-string v15, "\u0421\u043a\u0430\u0447\u0430\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c"

    invoke-virtual {v6, v15, v3, v0}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v6, v7, v9, v13, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v6, v7, v0, v13, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/4 v14, 0x4

    goto :goto_2

    :cond_1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v10, v5, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v15, v9, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c"

    invoke-virtual {v6, v0, v14}, Lc/k3;->A0(Ljava/lang/String;I)Landroid/widget/ImageButton;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->D()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    invoke-virtual {v15, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c"

    invoke-virtual {v6, v4, v12}, Lc/k3;->A0(Ljava/lang/String;I)Landroid/widget/ImageButton;

    move-result-object v4

    new-instance v5, Lc/z2;

    const/4 v14, 0x4

    invoke-direct {v5, v6, v14}, Lc/z2;-><init>(Lc/k3;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->D()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v5

    invoke-virtual {v15, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v6, v7, v15, v13, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_2
    new-instance v4, Lc/l;

    const/4 v5, 0x6

    invoke-direct {v4, v6, v0, v9, v5}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "\u042f\u0437\u044b\u043a \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044f"

    invoke-virtual {v6, v0}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v6, v7, v4, v13, v10}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    iget-object v9, v6, Lc/k3;->c:Lc/n1;

    invoke-virtual {v9}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v15

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Ld/a;->b:[Ljava/lang/String;

    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v22

    aget-object v14, v5, v22

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, " \u25be"

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v14, Lc/u2;

    const/16 v13, 0x1c

    invoke-direct {v14, v6, v13}, Lc/u2;-><init>(Lc/k3;I)V

    invoke-virtual {v6, v4, v10, v14}, Lc/k3;->m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object v4

    const-string v13, "voice-language-choice"

    invoke-virtual {v4, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ": "

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v0

    aget-object v0, v5, v0

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v13

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v0, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v14, 0x42400000    # 48.0f

    invoke-virtual {v6, v14}, Lc/k3;->o(F)I

    move-result v5

    invoke-direct {v0, v10, v5, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v2, v15}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v27

    if-eqz v27, :cond_2

    const-string v0, "\u042f\u0437\u044b\u043a \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    goto :goto_3

    :cond_2
    const-string v0, "\u042f\u0437\u044b\u043a \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    :goto_3
    invoke-virtual {v6, v0}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    const-string v0, "voice-language-status"

    invoke-virtual {v5, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    if-eqz v27, :cond_3

    const v0, 0x7f030051

    goto :goto_4

    :cond_3
    const v0, 0x7f030043

    :goto_4
    if-eqz v27, :cond_4

    const-string v4, "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u044f\u0437\u044b\u043a"

    goto :goto_5

    :cond_4
    const-string v4, "\u0421\u043a\u0430\u0447\u0430\u0442\u044c \u044f\u0437\u044b\u043a"

    :goto_5
    invoke-virtual {v6, v4, v0}, Lc/k3;->A0(Ljava/lang/String;I)Landroid/widget/ImageButton;

    move-result-object v4

    invoke-virtual/range {p0 .. p0}, Lc/k3;->D()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v0

    invoke-virtual {v13, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Lc/j0;

    const/16 v25, 0x3

    move-object/from16 v28, v0

    move-object v11, v1

    move-object/from16 v1, p0

    move-object v14, v2

    move-object v2, v4

    move-object v3, v5

    move-object v10, v4

    move-object v4, v15

    move-object/from16 v29, v5

    move/from16 v5, v25

    invoke-direct/range {v0 .. v5}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz v27, :cond_5

    const-string v0, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u044f\u0437\u044b\u043a"

    invoke-virtual {v6, v0, v12}, Lc/k3;->A0(Ljava/lang/String;I)Landroid/widget/ImageButton;

    move-result-object v0

    new-instance v1, Lc/I2;

    const/4 v2, 0x5

    invoke-direct {v1, v6, v15, v2}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->D()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v1

    invoke-virtual {v13, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_5
    const/4 v0, 0x0

    const/4 v10, 0x4

    invoke-virtual {v6, v7, v13, v10, v0}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move-object/from16 v1, v29

    invoke-virtual {v6, v7, v1, v10, v0}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041f\u043e\u0441\u043b\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438 \u044f\u0437\u044b\u043a\u0430 \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u043d\u0435 \u043d\u0443\u0436\u0435\u043d. \u0410\u0443\u0434\u0438\u043e \u043d\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u0435\u0442\u0441\u044f \u0438 \u043d\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442\u0441\u044f."

    invoke-virtual {v6, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v6, v7, v1, v2, v0}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v0, "\u0413\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0435 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v14}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iput-object v1, v6, Lc/k3;->E:Landroid/widget/Switch;

    const-string v2, "\u041f\u043e\u0441\u0442\u043e\u044f\u043d\u043d\u043e\u0435 \u043f\u0440\u043e\u0441\u043b\u0443\u0448\u0438\u0432\u0430\u043d\u0438\u0435"

    invoke-static {v14, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v2}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v9}, Lc/n1;->r0()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-static {v14}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_7

    if-nez v27, :cond_6

    invoke-virtual {v9}, Lc/n1;->r0()Z

    move-result v2

    if-eqz v2, :cond_7

    :cond_6
    if-eqz v14, :cond_7

    const/4 v3, 0x1

    goto :goto_6

    :cond_7
    const/4 v3, 0x0

    :goto_6
    invoke-virtual {v1, v3}, Landroid/view/View;->setEnabled(Z)V

    new-instance v2, Lc/E2;

    const/4 v3, 0x2

    invoke-direct {v2, v6, v1, v3}, Lc/E2;-><init>(Lc/k3;Landroid/widget/Switch;I)V

    invoke-virtual {v1, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v2, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    if-eqz v14, :cond_8

    iget-object v3, v14, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v3, :cond_8

    invoke-virtual {v3}, Lc/g9;->p()Ljava/lang/String;

    move-result-object v2

    :cond_8
    invoke-virtual {v6, v2}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    iput-object v2, v6, Lc/k3;->D:Landroid/widget/TextView;

    const/16 v3, 0x8

    invoke-virtual {v6, v0, v2, v10, v3}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    new-instance v2, Landroid/widget/Switch;

    invoke-direct {v2, v14}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v3, "voice-assistant-button"

    invoke-virtual {v2, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v3, "\u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u043f\u043e \u043a\u043d\u043e\u043f\u043a\u0435"

    invoke-static {v14, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v3, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v3}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v9}, Lc/n1;->p0()Z

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-static {v14}, Lc/g9;->b(Landroid/app/Activity;)Z

    move-result v3

    if-nez v3, :cond_9

    invoke-virtual {v9}, Lc/n1;->p0()Z

    move-result v3

    if-eqz v3, :cond_a

    :cond_9
    if-eqz v14, :cond_a

    const/4 v3, 0x1

    goto :goto_7

    :cond_a
    const/4 v3, 0x0

    :goto_7
    invoke-virtual {v2, v3}, Landroid/view/View;->setEnabled(Z)V

    new-instance v3, Lc/E2;

    const/4 v12, 0x3

    invoke-direct {v3, v6, v1, v12}, Lc/E2;-><init>(Lc/k3;Landroid/widget/Switch;I)V

    invoke-virtual {v2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v1, 0x0

    invoke-virtual {v6, v0, v2, v10, v1}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041a\u043d\u043e\u043f\u043a\u0430 \u043f\u043e\u043c\u043e\u0449\u043d\u0438\u043a\u0430: \u043e\u0434\u043d\u0430 \u043a\u043e\u043c\u0430\u043d\u0434\u0430, \u0437\u0430\u0442\u0435\u043c \u043c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f. \u041d\u0430\u0437\u043d\u0430\u0447\u044c\u0442\u0435 DriveDeck \u043f\u043e\u043c\u043e\u0449\u043d\u0438\u043a\u043e\u043c \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 Android \u0438\u043b\u0438 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u044b."

    invoke-static {v14, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DriveDeck"

    const-string v3, "DriveDeck \u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a"

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v14}, Lc/g9;->b(Landroid/app/Activity;)Z

    move-result v2

    if-eqz v2, :cond_b

    goto :goto_8

    :cond_b
    const-string v1, "\u0414\u043b\u044f \u0430\u043a\u0442\u0438\u0432\u0430\u0446\u0438\u0438 \u043f\u043e \u043a\u043d\u043e\u043f\u043a\u0435 \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u0435 \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u043c\u043e\u0434\u0443\u043b\u044c \u0434\u043e 0.7.0."

    :goto_8
    invoke-virtual {v6, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0x8

    invoke-virtual {v6, v0, v1, v10, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u0427\u0443\u0432\u0441\u0442\u0432\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u044c"

    invoke-virtual {v6, v1}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/widget/SeekBar;

    invoke-direct {v2, v14}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    iget-object v3, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v2, v3}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    const/16 v3, 0x19

    invoke-virtual {v2, v3}, Landroid/widget/ProgressBar;->setMax(I)V

    const-string v3, "voice_confidence"

    const/16 v4, 0x55

    iget-object v5, v9, Lc/n1;->b:Ljava/lang/Object;

    move-object v13, v5

    check-cast v13, Landroid/content/SharedPreferences;

    invoke-interface {v13, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    const/16 v4, 0x5f

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/16 v5, 0x46

    invoke-static {v5, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    sub-int/2addr v4, v3

    invoke-virtual {v2, v4}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-static {v14, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 v1, 0x42400000    # 48.0f

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setMinimumHeight(I)V

    new-instance v3, Lc/u2;

    const/16 v4, 0x1d

    invoke-direct {v3, v6, v4}, Lc/u2;-><init>(Lc/k3;I)V

    new-instance v4, Lc/Y2;

    invoke-direct {v4, v6, v3, v10}, Lc/Y2;-><init>(Lc/k3;Ljava/lang/Object;I)V

    invoke-virtual {v2, v4}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v6, v1}, Lc/k3;->x(F)I

    move-result v1

    const/4 v4, -0x1

    invoke-direct {v3, v4, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/Switch;

    invoke-direct {v1, v14}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iput-object v1, v6, Lc/k3;->F:Landroid/widget/Switch;

    const-string v2, "\u0417\u0432\u043e\u043d\u043a\u0438 \u0447\u0435\u0440\u0435\u0437 Bluetooth"

    invoke-static {v14, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v6, Lc/k3;->g:Lc/r4;

    invoke-static {v1, v2}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v9}, Lc/n1;->q0()Z

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/Switch;->setChecked(Z)V

    invoke-static {v14}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_c

    invoke-virtual {v9}, Lc/n1;->q0()Z

    move-result v2

    if-eqz v2, :cond_d

    :cond_c
    if-eqz v14, :cond_d

    const/4 v3, 0x1

    goto :goto_9

    :cond_d
    const/4 v3, 0x0

    :goto_9
    invoke-virtual {v1, v3}, Landroid/view/View;->setEnabled(Z)V

    new-instance v2, Lc/D2;

    const/16 v3, 0x11

    invoke-direct {v2, v6, v3}, Lc/D2;-><init>(Lc/k3;I)V

    invoke-virtual {v1, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/4 v2, 0x0

    invoke-virtual {v6, v0, v1, v10, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u0438\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0432 \u0440\u0430\u0437\u0434\u0435\u043b\u0435 \u00ab\u0422\u0435\u043b\u0435\u0444\u043e\u043d\u00bb. \u0414\u043b\u044f \u0437\u0432\u043e\u043d\u043a\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d\u043d\u044b\u0439 \u0442\u0435\u043b\u0435\u0444\u043e\u043d."

    invoke-virtual {v6, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v6, v0, v1, v10, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v6, v11, v7, v0, v2}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    const-string v0, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0434\u043b\u044f \u043a\u043e\u043c\u0430\u043d\u0434"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    const-string v0, "voice_music_app"

    const-string v5, ""

    invoke-interface {v13, v0, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-virtual {v9}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v0

    :cond_e
    move-object v3, v0

    new-instance v4, Lc/R2;

    const/4 v0, 0x0

    invoke-direct {v4, v9, v0}, Lc/R2;-><init>(Lc/n1;I)V

    const-string v2, "\u041e\u0442\u043a\u0440\u043e\u0439 \u043c\u0443\u0437\u044b\u043a\u0443"

    const-string v18, "\u0422\u0435\u043a\u0443\u0449\u0438\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u043c\u0443\u0437\u044b\u043a\u0438"

    move-object/from16 v0, p0

    move-object v1, v7

    move-object/from16 v19, v4

    move-object/from16 v4, v18

    move-object v10, v5

    move-object/from16 v5, v19

    invoke-virtual/range {v0 .. v5}, Lc/k3;->d(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Consumer;)V

    invoke-virtual {v9}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v0

    const-string v1, "voice_navigator_app"

    invoke-interface {v13, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Lc/R2;

    const/4 v4, 0x1

    invoke-direct {v5, v9, v4}, Lc/R2;-><init>(Lc/n1;I)V

    const-string v2, "\u041e\u0442\u043a\u0440\u043e\u0439 \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440"

    const-string v18, "\u041d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    move-object/from16 v0, p0

    move-object v1, v7

    move v12, v4

    move-object/from16 v4, v18

    invoke-virtual/range {v0 .. v5}, Lc/k3;->d(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Consumer;)V

    const-string v0, "voice_application"

    invoke-interface {v13, v0, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v5, Lc/R2;

    const/4 v0, 0x2

    invoke-direct {v5, v9, v0}, Lc/R2;-><init>(Lc/n1;I)V

    const-string v2, "\u041e\u0442\u043a\u0440\u043e\u0439 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    const-string v4, "\u041d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    move-object/from16 v0, p0

    move-object v1, v7

    invoke-virtual/range {v0 .. v5}, Lc/k3;->d(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Consumer;)V

    const-string v0, "\u041a\u043e\u043c\u0430\u043d\u0434\u044b"

    invoke-virtual {v6, v0}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v2, "zh_tw"

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    sget-object v3, Ld/a;->c:[[Ljava/lang/String;

    if-eqz v2, :cond_f

    sget-object v2, Ld/a;->d:[Ljava/lang/String;

    invoke-virtual {v2}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    goto :goto_a

    :cond_f
    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v2

    aget-object v2, v3, v2

    invoke-virtual {v2}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    :goto_a
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v5

    filled-new-array {v4, v5}, [Landroid/widget/LinearLayout;

    move-result-object v4

    const-string v5, "\u042d\u043a\u0440\u0430\u043d \u0438 \u043e\u0444\u043e\u0440\u043c\u043b\u0435\u043d\u0438\u0435"

    const-string v13, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    const-string v12, "\u041c\u0443\u0437\u044b\u043a\u0430"

    filled-new-array {v13, v12, v5}, [Ljava/lang/String;

    move-result-object v5

    const/16 v12, 0xd

    move-object/from16 v18, v7

    const/16 v7, 0x8

    const/4 v13, 0x1

    filled-new-array {v13, v7, v12}, [I

    move-result-object v12

    new-array v7, v7, [I

    fill-array-data v7, :array_0

    const/4 v13, 0x7

    new-array v13, v13, [I

    fill-array-data v13, :array_1

    filled-new-array {v12, v7, v13}, [[I

    move-result-object v7

    const/4 v12, 0x0

    :goto_b
    const-string v13, "\u00bb"

    move-object/from16 v17, v11

    const-string v11, "\u00ab"

    move-object/from16 v19, v0

    const/4 v0, 0x3

    if-ge v12, v0, :cond_18

    const/4 v0, 0x1

    if-ne v12, v0, :cond_10

    const/4 v0, 0x1

    goto :goto_c

    :cond_10
    const/4 v0, 0x0

    :goto_c
    aget-object v0, v4, v0

    move-object/from16 v20, v9

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v9

    move-object/from16 v22, v1

    new-instance v1, Ljava/lang/StringBuilder;

    move-object/from16 v23, v4

    const-string v4, "voice-command-group:"

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    aget-object v4, v5, v12

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    aget-object v1, v5, v12

    move-object/from16 v24, v5

    const/4 v4, 0x1

    const/16 v5, 0xe

    invoke-virtual {v6, v5, v1, v4}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    aget-object v1, v7, v12

    array-length v4, v1

    const/4 v5, 0x0

    :goto_d
    if-ge v5, v4, :cond_11

    aget v25, v1, v5

    move-object/from16 v26, v1

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    move/from16 v27, v4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v28, v7

    aget-object v7, v2, v25

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x0

    const/4 v7, 0x4

    invoke-virtual {v6, v9, v1, v7, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/4 v1, 0x1

    add-int/2addr v5, v1

    move-object/from16 v1, v26

    move/from16 v4, v27

    move-object/from16 v7, v28

    goto :goto_d

    :cond_11
    move-object/from16 v28, v7

    const/4 v1, 0x2

    if-ne v12, v1, :cond_12

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v7

    aget-object v7, v3, v7

    invoke-virtual {v7}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/String;

    const/16 v16, 0x9

    aget-object v7, v7, v16

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v7, Ld/a;->l:[[Ljava/lang/String;

    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v25

    aget-object v7, v7, v25

    const/16 v21, 0x6

    aget-object v7, v7, v21

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v5, v7}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\u00bb\n"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0440\u0430\u0437\u0434\u0435\u043b\u0430 \u0438\u0437 \u043c\u0435\u043d\u044e \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a"

    invoke-static {v14, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v6, v9, v1, v5, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_e

    :cond_12
    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v16, 0x9

    const/16 v21, 0x6

    :goto_e
    const-string v1, "ru"

    const/4 v7, 0x2

    if-ne v12, v7, :cond_13

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_13

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v7

    move-object/from16 v25, v2

    const-string v2, "\u00ab\u0421\u043f\u043b\u0438\u0442 \u043e\u0434\u0438\u043d\u00bb, \u00ab\u0421\u043f\u043b\u0438\u0442 \u0434\u0432\u0430\u00bb\u2026 \u041f\u043e \u043f\u043e\u0440\u044f\u0434\u043a\u0443 \u0432 \u0434\u043e\u043a\u0435, \u0431\u0435\u0437 \u043e\u0434\u0438\u043d\u043e\u0447\u043d\u044b\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439."

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v9, v7, v5, v4}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_f
    const/4 v2, 0x1

    goto :goto_10

    :cond_13
    move-object/from16 v25, v2

    goto :goto_f

    :goto_10
    if-ne v12, v2, :cond_16

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v15, v2}, Ld/a;->h(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\u00bb, \u00ab"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    invoke-static {v15, v2}, Ld/a;->h(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\u00bb\u2026\n"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\u041f\u043e \u043f\u043e\u0440\u044f\u0434\u043a\u0443 \u043f\u043b\u0435\u0435\u0440\u043e\u0432 \u0432 \u0432\u0438\u0434\u0436\u0435\u0442\u0435, \u0431\u0435\u0437 Bluetooth"

    invoke-static {v14, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, 0x0

    const/4 v5, 0x4

    invoke-virtual {v6, v9, v4, v5, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    invoke-virtual {v1, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const-string v4, "\u00ab\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0434\u0432\u0430\u0434\u0446\u0430\u0442\u044c\u00bb\n\u00ab\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c \u0441\u0435\u043c\u044c\u0434\u0435\u0441\u044f\u0442\u00bb \u00b7 0\u2013100%"

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v6, v9, v1, v5, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :cond_14
    invoke-static {v14}, Lc/g9;->k(Landroid/app/Activity;)Z

    move-result v1

    if-eqz v1, :cond_15

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v15}, Ld/a;->f(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    aget-object v5, v5, v2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x4

    invoke-virtual {v6, v9, v1, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const-string v1, "\u041d\u0430\u0437\u043e\u0432\u0438\u0442\u0435 \u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044f \u0438, \u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e, \u0442\u0440\u0435\u043a"

    invoke-virtual {v6, v1}, Lc/k3;->E(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v6, v9, v1, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_11
    const/4 v1, 0x2

    goto :goto_12

    :cond_15
    const/4 v4, 0x4

    const-string v1, "\u0414\u043b\u044f \u043f\u043e\u0438\u0441\u043a\u0430 \u043c\u0443\u0437\u044b\u043a\u0438 \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u0435 \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u043c\u043e\u0434\u0443\u043b\u044c"

    invoke-virtual {v6, v1}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v6, v9, v1, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    goto :goto_11

    :cond_16
    const/4 v2, 0x0

    goto :goto_11

    :goto_12
    if-ne v12, v1, :cond_17

    const/16 v4, 0xc

    goto :goto_13

    :cond_17
    move v4, v2

    :goto_13
    invoke-virtual {v6, v0, v9, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    const/4 v0, 0x1

    add-int/2addr v12, v0

    move-object/from16 v11, v17

    move-object/from16 v0, v19

    move-object/from16 v9, v20

    move-object/from16 v1, v22

    move-object/from16 v4, v23

    move-object/from16 v5, v24

    move-object/from16 v2, v25

    move-object/from16 v7, v28

    goto/16 :goto_b

    :cond_18
    move-object/from16 v22, v1

    move-object/from16 v23, v4

    move-object/from16 v20, v9

    const/4 v1, 0x2

    const/4 v2, 0x0

    move v0, v2

    :goto_14
    if-ge v0, v1, :cond_1a

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, -0x2

    invoke-direct {v3, v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-eqz v0, :cond_19

    const/high16 v2, 0x41000000    # 8.0f

    invoke-virtual {v6, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_19
    aget-object v2, v23, v0

    move-object/from16 v7, v22

    invoke-virtual {v7, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    add-int/2addr v0, v2

    const/4 v2, 0x0

    goto :goto_14

    :cond_1a
    move-object/from16 v7, v22

    const/4 v2, 0x1

    invoke-static {v14}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-virtual/range {v20 .. v20}, Lc/n1;->q0()Z

    move-result v0

    if-eqz v0, :cond_1b

    invoke-virtual/range {p0 .. p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "voice-command-group:\u0422\u0435\u043b\u0435\u0444\u043e\u043d"

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d"

    const/16 v3, 0xe

    invoke-virtual {v6, v3, v1, v2}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v6, v10}, Lc/k3;->i(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v15}, Ld/a;->f(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    aget-object v2, v4, v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\n\u00ab"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Ld/a;->g:[[Ljava/lang/String;

    invoke-static {v15}, Ld/a;->b(Ljava/lang/String;)I

    move-result v4

    aget-object v3, v3, v4

    invoke-virtual {v3}, [Ljava/lang/String;->clone()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    const-string v4, "\u00bb\n\u00ab"

    invoke-static {v4, v3}, Ljava/lang/String;->join(Ljava/lang/CharSequence;[Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v6, v0, v1, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    aget-object v1, v23, v2

    const/16 v4, 0xc

    invoke-virtual {v6, v1, v0, v4, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    :goto_15
    move-object/from16 v0, v19

    goto :goto_16

    :cond_1b
    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 v4, 0xc

    goto :goto_15

    :goto_16
    invoke-virtual {v6, v0, v7, v3, v2}, Lc/k3;->x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V

    move-object/from16 v1, v17

    move-object/from16 v2, v18

    invoke-virtual {v6, v1, v2, v0, v4}, Lc/k3;->c(Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;I)V

    return-void

    nop

    :array_0
    .array-data 4
        0x2
        0x3
        0x4
        0x5
        0x6
        0x7
        0xe
        0xf
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x9
        0xa
        0xb
        0xc
        0x10
        0x11
    .end array-data
.end method

.method public final h0(I)Landroid/graphics/drawable/RippleDrawable;
    .locals 4

    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v1, 0x0

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/16 v2, 0x3e8

    invoke-virtual {p0, p1, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    const/4 v3, -0x1

    invoke-virtual {p0, v3, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-direct {v0, v1, p1, v2}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method public final i(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 2

    const/16 v0, 0xe

    const/4 v1, 0x0

    invoke-virtual {p0, v0, p1, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    return-object p1
.end method

.method public final i0()Landroid/widget/LinearLayout;
    .locals 2

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    return-object v0
.end method

.method public final j0(Landroid/widget/LinearLayout;)Landroid/widget/ScrollView;
    .locals 4

    new-instance v0, Landroid/widget/ScrollView;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    invoke-virtual {v0, p1}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    iget-object p1, p0, Lc/k3;->h:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Lc/k3;->u:Ljava/util/HashMap;

    invoke-virtual {v2, p1, v1}, Ljava/util/HashMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v2

    new-instance v3, Lc/d3;

    invoke-direct {v3, p0, v0, v1, p1}, Lc/d3;-><init>(Lc/k3;Landroid/widget/ScrollView;ILjava/lang/String;)V

    invoke-virtual {v2, v3}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    return-object v0
.end method

.method public final k()Landroid/widget/LinearLayout;
    .locals 2

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    return-object v0
.end method

.method public final k0()Landroid/widget/LinearLayout;
    .locals 5

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "settings-content"

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->b:I

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundColor(I)V

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    const/high16 v4, 0x41800000    # 16.0f

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v0, v2, v3, v1, v4}, Landroid/view/View;->setPadding(IIII)V

    return-object v0
.end method

.method public final l()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v1, p0, Lc/k3;->d:Lc/u0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v2, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v1, Lc/u0;->d:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v0}, Lru/drivedeck/launcher/MainActivity;->b0(Ljava/util/ArrayList;)V

    return-void
.end method

.method public final m(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;
    .locals 4

    invoke-virtual {p0, p1, p2, p3}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p1

    const/high16 p3, 0x42400000    # 48.0f

    invoke-virtual {p0, p3}, Lc/k3;->o(F)I

    move-result p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance p3, Landroid/content/res/ColorStateList;

    const v0, -0x101009e

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [I

    filled-new-array {v0, v2}, [[I

    move-result-object v0

    iget-object v2, p0, Lc/k3;->g:Lc/r4;

    iget v3, v2, Lc/r4;->e:I

    if-eqz p2, :cond_0

    iget v2, v2, Lc/r4;->g:I

    goto :goto_0

    :cond_0
    iget v2, v2, Lc/r4;->d:I

    :goto_0
    filled-new-array {v3, v2}, [I

    move-result-object v2

    invoke-direct {p3, v0, v2}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    new-instance p3, Landroid/graphics/drawable/StateListDrawable;

    invoke-direct {p3}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    const v0, 0x101009e

    filled-new-array {v0}, [I

    move-result-object v0

    if-eqz p2, :cond_1

    iget-object p2, p0, Lc/k3;->g:Lc/r4;

    iget p2, p2, Lc/r4;->f:I

    goto :goto_1

    :cond_1
    iget-object p2, p0, Lc/k3;->g:Lc/r4;

    invoke-static {p2}, Lc/G8;->V0(Lc/r4;)I

    move-result p2

    :goto_1
    const/16 v2, 0x3e8

    invoke-virtual {p0, p2, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p3, v0, p2}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    new-array p2, v1, [I

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    iget-boolean v3, v0, Lc/r4;->m:Z

    if-eqz v3, :cond_2

    const v0, -0x120e0d

    goto :goto_2

    :cond_2
    iget v0, v0, Lc/r4;->b:I

    :goto_2
    invoke-virtual {p0, v0, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {p3, p2, v0}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    new-instance p2, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v1, -0x1

    invoke-virtual {p0, v1, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-direct {p2, v0, p3, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object p1
.end method

.method public final m0(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v0

    iput v0, p0, Lc/k3;->q:I

    if-gez v0, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/k3;->t:Z

    const-string v0, "pairs"

    iget-object v1, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget p1, p0, Lc/k3;->q:I

    invoke-virtual {p0, p1}, Lc/k3;->y(I)V

    return-void

    :cond_1
    invoke-virtual {p0}, Lc/k3;->S()V

    return-void
.end method

.method public final n()Landroid/widget/LinearLayout$LayoutParams;
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x42400000    # 48.0f

    invoke-virtual {p0, v1}, Lc/k3;->o(F)I

    move-result v1

    const/4 v2, -0x2

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    return-object v0
.end method

.method public final n0(Ljava/lang/String;)V
    .locals 16

    move-object/from16 v7, p0

    move-object/from16 v6, p1

    iget-boolean v0, v7, Lc/k3;->o:Z

    if-eqz v0, :cond_0

    iput-object v6, v7, Lc/k3;->p:Ljava/lang/String;

    return-void

    :cond_0
    iget-object v0, v7, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    invoke-static/range {p1 .. p1}, Lc/k3;->l0(Ljava/lang/String;)I

    move-result v0

    iget-object v1, v7, Lc/k3;->h:Ljava/lang/String;

    invoke-static {v1}, Lc/k3;->l0(Ljava/lang/String;)I

    move-result v1

    const/4 v9, -0x1

    if-lt v0, v1, :cond_2

    const/4 v10, 0x1

    goto :goto_0

    :cond_2
    move v10, v9

    :goto_0
    iget-object v11, v7, Lc/k3;->j:Landroid/widget/LinearLayout;

    iget-object v12, v7, Lc/k3;->l:Lc/c0;

    iput-object v6, v7, Lc/k3;->h:Ljava/lang/String;

    const-string v0, ""

    iput-object v0, v7, Lc/k3;->B:Ljava/lang/String;

    const/4 v14, 0x0

    :goto_1
    sget-object v0, Lc/k3;->N:[Ljava/lang/String;

    array-length v1, v0

    if-ge v14, v1, :cond_7

    aget-object v0, v0, v14

    iget-object v15, v7, Lc/k3;->m:[Landroid/view/View;

    aget-object v5, v15, v14

    if-nez v5, :cond_3

    goto :goto_4

    :cond_3
    invoke-virtual {v5}, Landroid/view/View;->isSelected()Z

    move-result v1

    invoke-static/range {p1 .. p1}, Lc/k3;->l0(Ljava/lang/String;)I

    move-result v2

    if-ne v14, v2, :cond_4

    const/4 v2, 0x1

    goto :goto_2

    :cond_4
    const/4 v2, 0x0

    :goto_2
    if-ne v1, v2, :cond_5

    goto :goto_4

    :cond_5
    sget-object v1, Lc/k3;->O:[Ljava/lang/String;

    aget-object v1, v1, v14

    sget-object v2, Lc/k3;->P:[Ljava/lang/String;

    aget-object v2, v2, v14

    sget-object v3, Lc/k3;->Q:[I

    aget v3, v3, v14

    invoke-static/range {p1 .. p1}, Lc/k3;->l0(Ljava/lang/String;)I

    move-result v4

    if-ne v14, v4, :cond_6

    const/4 v4, 0x1

    goto :goto_3

    :cond_6
    const/4 v4, 0x0

    :goto_3
    new-instance v13, Lc/x2;

    const/4 v8, 0x4

    invoke-direct {v13, v7, v0, v8}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    move-object/from16 v0, p0

    move-object v8, v5

    move-object v5, v13

    invoke-virtual/range {v0 .. v5}, Lc/k3;->L(Ljava/lang/String;Ljava/lang/String;IZLjava/lang/Runnable;)Landroid/widget/LinearLayout;

    move-result-object v0

    iget-object v1, v7, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v8}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v1

    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    iget-object v3, v7, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v1}, Landroid/view/ViewGroup;->removeViewAt(I)V

    iget-object v3, v7, Lc/k3;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v3, v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    aput-object v0, v15, v14

    :goto_4
    add-int/lit8 v14, v14, 0x1

    goto :goto_1

    :cond_7
    invoke-virtual/range {p0 .. p0}, Lc/k3;->k0()Landroid/widget/LinearLayout;

    move-result-object v2

    iput-object v2, v7, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v12}, Landroid/view/View;->getHeight()I

    move-result v6

    if-lez v6, :cond_8

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 v13, 0x1

    goto :goto_5

    :cond_8
    const/4 v13, 0x0

    :goto_5
    if-eqz v13, :cond_9

    mul-int v0, v10, v6

    int-to-float v0, v0

    invoke-virtual {v2, v0}, Landroid/view/View;->setTranslationY(F)V

    :cond_9
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v0, v9, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p0 .. p0}, Lc/k3;->e0()V

    if-nez v13, :cond_a

    invoke-virtual {v12, v11}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    return-void

    :cond_a
    const/4 v0, 0x0

    invoke-virtual {v11, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v0, 0x4

    invoke-virtual {v11, v0}, Landroid/view/View;->setImportantForAccessibility(I)V

    const/4 v0, 0x1

    iput-boolean v0, v7, Lc/k3;->o:Z

    invoke-virtual {v2}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v8

    new-instance v9, Lc/g3;

    move-object v0, v9

    move-object/from16 v1, p0

    move-object v3, v12

    move-object v4, v11

    move v5, v10

    invoke-direct/range {v0 .. v6}, Lc/g3;-><init>(Lc/k3;Landroid/widget/LinearLayout;Lc/c0;Landroid/widget/LinearLayout;II)V

    invoke-virtual {v8, v9}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    return-void
.end method

.method public final o(F)I
    .locals 1

    const/high16 v0, 0x42400000    # 48.0f

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    invoke-virtual {p0, p1}, Lc/k3;->x(F)I

    move-result p1

    return p1
.end method

.method public final o0()I
    .locals 5

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    sget-object v1, Lc/r4;->p:Lc/r4;

    if-ne v0, v1, :cond_0

    iget v0, v0, Lc/r4;->f:I

    return v0

    :cond_0
    iget-boolean v1, v0, Lc/r4;->m:Z

    if-eqz v1, :cond_1

    const v1, 0x3df5c28f    # 0.12f

    goto :goto_0

    :cond_1
    const v1, 0x3dcccccd    # 0.1f

    :goto_0
    iget v0, v0, Lc/r4;->b:I

    invoke-static {v0}, Landroid/graphics/Color;->red(I)I

    move-result v0

    int-to-float v0, v0

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float/2addr v2, v1

    mul-float/2addr v0, v2

    iget-object v3, p0, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->f:I

    invoke-static {v3}, Landroid/graphics/Color;->red(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, v1

    add-float/2addr v3, v0

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v0

    iget-object v3, p0, Lc/k3;->g:Lc/r4;

    iget v3, v3, Lc/r4;->b:I

    invoke-static {v3}, Landroid/graphics/Color;->green(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, v2

    iget-object v4, p0, Lc/k3;->g:Lc/r4;

    iget v4, v4, Lc/r4;->f:I

    invoke-static {v4}, Landroid/graphics/Color;->green(I)I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v4, v1

    add-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v3

    iget-object v4, p0, Lc/k3;->g:Lc/r4;

    iget v4, v4, Lc/r4;->b:I

    invoke-static {v4}, Landroid/graphics/Color;->blue(I)I

    move-result v4

    int-to-float v4, v4

    mul-float/2addr v4, v2

    iget-object v2, p0, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->f:I

    invoke-static {v2}, Landroid/graphics/Color;->blue(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v1

    add-float/2addr v2, v4

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {v0, v3, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    return v0
.end method

.method public final onWindowFocusChanged(Z)V
    .locals 1

    invoke-super {p0, p1}, Landroid/app/Dialog;->onWindowFocusChanged(Z)V

    if-eqz p1, :cond_1

    iget-object p1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    if-eqz p1, :cond_1

    const-string p1, "permissions"

    iget-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {p0}, Lc/k3;->d0()V

    iget-object p1, p0, Lc/k3;->j:Landroid/widget/LinearLayout;

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    invoke-static {p1, v0}, Lc/G8;->p(Landroid/widget/LinearLayout;I)V

    goto :goto_0

    :cond_0
    const-string p1, "voice"

    iget-object v0, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lc/k3;->T()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final p(ILjava/lang/String;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 7

    invoke-virtual {p0, p2}, Lc/k3;->q0(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const/high16 v2, 0x41a00000    # 20.0f

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v3

    const/high16 v4, 0x41800000    # 16.0f

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v5

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v0, v3, v5, v2, v4}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v3, 0x30

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v3, Landroid/widget/ImageView;

    iget-object v4, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v3, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    iget-object p1, p0, Lc/k3;->g:Lc/r4;

    iget p1, p1, Lc/r4;->d:I

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {v3, p1}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 p1, 0x2

    invoke-virtual {v3, p1}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v6

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v5

    invoke-direct {p1, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object p1

    const/16 v5, 0x12

    const/4 v6, 0x1

    invoke-virtual {p0, v5, p2, v6}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {p1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual {v3, v6}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v4, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, ". "

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4, p3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v3, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setFocusable(Z)V

    new-instance p2, Lc/I2;

    const/4 v4, 0x1

    invoke-direct {p2, p0, p3, v4}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v3, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_0
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p3, -0x2

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {p2, v1, p3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 p3, 0x41600000    # 14.0f

    invoke-virtual {p0, p3}, Lc/k3;->x(F)I

    move-result p3

    iput p3, p2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v2, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method public final q(Landroid/widget/LinearLayout;)V
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    const/4 v2, -0x1

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/high16 v1, 0x40800000    # 4.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {p0}, Lc/k3;->H()Landroid/view/View;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final q0(Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 5

    invoke-virtual {p0}, Lc/k3;->k()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "settings-card:"

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/view/View;->setPadding(IIII)V

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->c:I

    const/16 v2, 0x10

    invoke-virtual {p0, v1, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x1

    invoke-virtual {p0, v2, p1, v1}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-object v0
.end method

.method public final r(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;
    .locals 8

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/16 v2, 0x10

    const/4 v3, 0x0

    invoke-virtual {p0, v2, p1, v3}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    const/4 v4, 0x2

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v4, v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u24d8"

    const/16 v4, 0x14

    invoke-virtual {p0, v4, v2, v3}, Lc/k3;->z0(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {p0}, Lc/k3;->y0()I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v4, 0x11

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v7, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ". "

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v7, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 p1, 0x1

    invoke-virtual {v2, p1}, Landroid/view/View;->setFocusable(Z)V

    new-instance p1, Lc/I2;

    const/4 v4, 0x4

    invoke-direct {p1, p0, p2, v4}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 p2, 0x42400000    # 48.0f

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result p2

    invoke-direct {p1, v4, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz p3, :cond_0

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    return-object v0
.end method

.method public final r0()Lc/b2;
    .locals 9

    new-instance v7, Lc/b2;

    iget-object v8, p0, Lc/k3;->e:Ljava/util/ArrayList;

    const/4 v5, 0x1

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, p0, Lc/k3;->b:Lc/z;

    const/4 v4, 0x0

    const/4 v6, 0x1

    move-object v0, v7

    move-object v3, v8

    invoke-direct/range {v0 .. v6}, Lc/b2;-><init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;ZZ)V

    new-instance v0, Lc/v8;

    const/4 v1, 0x5

    invoke-direct {v0, p0, v1}, Lc/v8;-><init>(Ljava/lang/Object;I)V

    iget-boolean v1, p0, Lc/k3;->t:Z

    if-eqz v1, :cond_0

    iget v1, p0, Lc/k3;->q:I

    if-ltz v1, :cond_0

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_0

    iget v1, p0, Lc/k3;->q:I

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput-object v0, v7, Lc/b2;->Q:Lc/v8;

    iput-object v1, v7, Lc/b2;->R:Ljava/lang/String;

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    const/4 v0, 0x0

    invoke-virtual {v7, v0}, Lc/b2;->E(Z)V

    const/4 v0, 0x1

    iput-boolean v0, v7, Lc/b2;->i:Z

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v0

    mul-int/lit8 v0, v0, 0x46

    add-int/lit16 v0, v0, 0xfc

    const/16 v1, 0x1e0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0, v0}, Lc/k3;->x(F)I

    move-result v0

    invoke-virtual {v7, v0}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v1, "\u041f\u0440\u0435\u0434\u043f\u0440\u043e\u0441\u043c\u043e\u0442\u0440 \u0434\u043e\u043a\u0430 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-object v7
.end method

.method public final s()I
    .locals 2

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getDisplay()Landroid/view/Display;

    move-result-object v1

    if-nez v1, :cond_0

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    return v0

    :cond_0
    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v0, v0, Landroid/graphics/Point;->x:I

    return v0
.end method

.method public final s0()F
    .locals 3

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    iget-object v2, p0, Lc/k3;->i:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    if-lez v2, :cond_0

    iget-object v0, p0, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    :goto_0
    int-to-float v0, v0

    :goto_1
    div-float/2addr v0, v1

    goto :goto_2

    :cond_0
    iget v2, p0, Lc/k3;->H:I

    if-lez v2, :cond_1

    int-to-float v0, v2

    goto :goto_1

    :cond_1
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    goto :goto_0

    :goto_2
    invoke-virtual {p0}, Lc/k3;->w0()I

    move-result v1

    int-to-float v1, v1

    sub-float/2addr v0, v1

    const/high16 v1, 0x42400000    # 48.0f

    sub-float/2addr v0, v1

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    return v0
.end method

.method public final t(Ljava/lang/String;Ljava/lang/Runnable;)Lc/X2;
    .locals 3

    new-instance v0, Lc/X2;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v2, 0x1

    invoke-direct {v0, p0, v1, v2}, Lc/X2;-><init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;I)V

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    invoke-static {v1}, Lc/G8;->V0(Lc/r4;)I

    move-result v1

    invoke-virtual {p0, v1}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    invoke-static {v0}, Lc/k3;->h(Landroid/view/View;)V

    const/4 p1, 0x1

    invoke-virtual {v0, p1}, Landroid/view/View;->setFocusable(Z)V

    new-instance p1, Lc/h1;

    const/4 v1, 0x1

    invoke-direct {p1, p2, v1}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method public final t0(II)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    int-to-float p1, p2

    invoke-virtual {p0, p1}, Lc/k3;->x(F)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public final u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;
    .locals 3

    const/4 v0, 0x0

    invoke-virtual {p0, p3, v0, p2}, Lc/k3;->g(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/TextView;

    move-result-object p3

    new-instance v1, Lc/w2;

    const/4 v2, 0x1

    invoke-direct {v1, p0, p2, v2}, Lc/w2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p3, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 p2, 0x28

    if-gt p1, p2, :cond_0

    const/16 v1, 0xd

    goto :goto_0

    :cond_0
    const/16 v1, 0xe

    :goto_0
    invoke-static {p3, v1}, Lc/k3;->z(Landroid/widget/TextView;I)V

    if-gt p1, p2, :cond_1

    const/16 p2, 0xc

    goto :goto_1

    :cond_1
    const/16 p2, 0x10

    :goto_1
    int-to-float p2, p2

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {p0, p2}, Lc/k3;->x(F)I

    move-result p2

    invoke-virtual {p3, v1, v0, p2, v0}, Landroid/widget/TextView;->setPadding(IIII)V

    int-to-float p1, p1

    invoke-virtual {p0, p1}, Lc/k3;->o(F)I

    move-result p1

    invoke-virtual {p3, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    return-object p3
.end method

.method public final u0(Ljava/lang/String;)V
    .locals 3

    sget-object v0, Lc/k3;->N:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "tutorial"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lc/k3;->dismiss()V

    iget-object p1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    iget-object v0, p0, Lc/k3;->d:Lc/u0;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Lc/i;

    const/4 v2, 0x6

    invoke-direct {v1, v0, v2}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1}, Lc/k3;->n0(Ljava/lang/String;)V

    :goto_0
    return-void

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Unknown settings page"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final v(Lc/j3;Z)Landroid/widget/LinearLayout;
    .locals 10

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v0

    const/high16 v1, 0x40000000    # 2.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v3

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v1

    invoke-virtual {v0, v2, v3, v4, v1}, Landroid/view/View;->setPadding(IIII)V

    iget-object v1, p0, Lc/k3;->g:Lc/r4;

    iget v1, v1, Lc/r4;->c:I

    const/16 v2, 0x3e8

    invoke-virtual {p0, v1, v2}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Lc/u2;

    const/16 v2, 0x17

    invoke-direct {v1, p0, v2}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v2, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    iget v3, p1, Lc/j3;->g:I

    invoke-virtual {p0, v3, v1, v2}, Lc/k3;->u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Lc/u2;

    const/16 v4, 0x18

    invoke-direct {v2, p0, v4}, Lc/u2;-><init>(Lc/k3;I)V

    const-string v4, "\u041f\u0430\u0440\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    invoke-virtual {p0, v3, v2, v4}, Lc/k3;->u(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v2

    xor-int/lit8 v4, p2, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v2, p2}, Landroid/widget/TextView;->setSelected(Z)V

    const/4 v4, 0x0

    if-nez p2, :cond_0

    invoke-virtual {p0}, Lc/k3;->o0()I

    move-result v5

    goto :goto_0

    :cond_0
    move v5, v4

    :goto_0
    invoke-virtual {p0, v5}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    if-eqz p2, :cond_1

    invoke-virtual {p0}, Lc/k3;->o0()I

    move-result p2

    goto :goto_1

    :cond_1
    move p2, v4

    :goto_1
    invoke-virtual {p0, p2}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object p2

    invoke-virtual {v2, p2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    iget-boolean p1, p1, Lc/j3;->a:Z

    if-eqz p1, :cond_2

    const/high16 v5, 0x43040000    # 132.0f

    invoke-virtual {p0, v5}, Lc/k3;->x(F)I

    move-result v5

    goto :goto_2

    :cond_2
    move v5, v4

    :goto_2
    int-to-float v3, v3

    invoke-virtual {p0, v3}, Lc/k3;->o(F)I

    move-result v6

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    if-eqz p1, :cond_3

    move v9, v8

    goto :goto_3

    :cond_3
    move v9, v7

    :goto_3
    invoke-direct {p2, v5, v6, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz p1, :cond_4

    const/high16 v1, 0x432c0000    # 172.0f

    invoke-virtual {p0, v1}, Lc/k3;->x(F)I

    move-result v4

    :cond_4
    invoke-virtual {p0, v3}, Lc/k3;->o(F)I

    move-result v1

    if-eqz p1, :cond_5

    move v7, v8

    :cond_5
    invoke-direct {p2, v4, v1, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public final v0(Z)V
    .locals 9

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance v2, Landroid/app/Dialog;

    iget-object v3, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v2, v3}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v3}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v5

    new-instance v4, Landroid/widget/TimePicker;

    invoke-direct {v4, v3}, Landroid/widget/TimePicker;-><init>(Landroid/content/Context;)V

    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v4, v6}, Landroid/widget/TimePicker;->setIs24HourView(Ljava/lang/Boolean;)V

    iget-object v6, p0, Lc/k3;->c:Lc/n1;

    if-eqz p1, :cond_0

    invoke-virtual {v6}, Lc/n1;->N()I

    move-result v6

    goto :goto_0

    :cond_0
    invoke-virtual {v6}, Lc/n1;->M()I

    move-result v6

    :goto_0
    div-int/lit8 v7, v6, 0x3c

    invoke-virtual {v4, v7}, Landroid/widget/TimePicker;->setHour(I)V

    rem-int/lit8 v6, v6, 0x3c

    invoke-virtual {v4, v6}, Landroid/widget/TimePicker;->setMinute(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, -0x2

    invoke-direct {v6, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v6, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v3, v6, v1}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    new-instance v7, Lc/a0;

    const/4 v8, 0x6

    invoke-direct {v7, v2, v8}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v7, "\u0413\u043e\u0442\u043e\u0432\u043e"

    invoke-static {v3, v7, v0}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v7

    new-instance v8, Lc/U2;

    invoke-direct {v8, p0, v4, p1, v2}, Lc/U2;-><init>(Lc/k3;Landroid/widget/TimePicker;ZLandroid/app/Dialog;)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-eqz p1, :cond_1

    const-string p1, "\u0421\u0432\u0435\u0442\u043b\u0430\u044f \u0442\u0435\u043c\u0430"

    :goto_1
    move-object v4, p1

    goto :goto_2

    :cond_1
    const-string p1, "\u0422\u0451\u043c\u043d\u0430\u044f \u0442\u0435\u043c\u0430"

    goto :goto_1

    :goto_2
    const/4 p1, 0x2

    new-array p1, p1, [Landroid/view/View;

    aput-object v6, p1, v1

    aput-object v7, p1, v0

    invoke-static {v3, p1}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v7, Lc/i;

    const/4 p1, 0x4

    invoke-direct {v7, v2, p1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    const/4 v8, 0x1

    invoke-static/range {v2 .. v8}, Lc/G8;->J0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Ljava/lang/Runnable;Z)V

    return-void
.end method

.method public final w(Lc/j3;)Landroid/widget/HorizontalScrollView;
    .locals 13

    const/4 v0, 0x1

    invoke-virtual {p0}, Lc/k3;->i0()Landroid/widget/LinearLayout;

    move-result-object v1

    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget v2, p1, Lc/j3;->e:I

    int-to-float v3, v2

    invoke-virtual {p0, v3}, Lc/k3;->x(F)I

    move-result v3

    const/high16 v4, 0x40c00000    # 6.0f

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v5

    int-to-float v2, v2

    invoke-virtual {p0, v2}, Lc/k3;->x(F)I

    move-result v2

    invoke-virtual {p0, v4}, Lc/k3;->x(F)I

    move-result v4

    invoke-virtual {v1, v3, v5, v2, v4}, Landroid/view/View;->setPadding(IIII)V

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    iget-object v4, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    iget-object v6, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-ge v3, v5, :cond_3

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    new-instance v5, Landroid/widget/FrameLayout;

    invoke-direct {v5, v6}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iget-boolean v7, p0, Lc/k3;->t:Z

    if-eqz v7, :cond_0

    iget v7, p0, Lc/k3;->q:I

    if-ne v7, v3, :cond_0

    move v7, v0

    goto :goto_1

    :cond_0
    move v7, v2

    :goto_1
    invoke-virtual {v5, v7}, Landroid/view/View;->setSelected(Z)V

    invoke-virtual {p0, v2}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "\u041c\u0435\u0441\u0442\u043e "

    invoke-static {v6, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v6, v3, 0x1

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Lc/k3;->G(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {v5}, Lc/k3;->h(Landroid/view/View;)V

    const/16 v8, 0x28

    invoke-virtual {p0, v4, v8}, Lc/k3;->C(Ljava/lang/String;I)Lc/f3;

    move-result-object v8

    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v10, 0x42300000    # 44.0f

    invoke-virtual {p0, v10}, Lc/k3;->x(F)I

    move-result v11

    invoke-virtual {p0, v10}, Lc/k3;->x(F)I

    move-result v10

    const/16 v12, 0x11

    invoke-direct {v9, v11, v10, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v5, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v7, :cond_1

    new-instance v7, Lc/x2;

    const/4 v8, 0x6

    invoke-direct {v7, p0, v4, v8}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    const-string v8, "\u0423\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0434\u043e\u043a\u0430"

    invoke-virtual {p0, v8, v7}, Lc/k3;->t(Ljava/lang/String;Ljava/lang/Runnable;)Lc/X2;

    move-result-object v7

    const/4 v8, -0x1

    const/16 v9, 0x8

    invoke-virtual {p0, v8, v9}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    const/high16 v9, 0x41d00000    # 26.0f

    invoke-virtual {p0, v9}, Lc/k3;->x(F)I

    move-result v10

    invoke-virtual {p0, v9}, Lc/k3;->x(F)I

    move-result v9

    const v11, 0x800035

    invoke-direct {v8, v10, v9, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {v5, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    new-array v7, v0, [F

    const/4 v8, 0x0

    aput v8, v7, v2

    new-instance v8, Lc/Q2;

    invoke-direct {v8, p0, v7, v4}, Lc/Q2;-><init>(Lc/k3;[FLjava/lang/String;)V

    invoke-virtual {v5, v8}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v7, Lc/I2;

    const/4 v8, 0x2

    invoke-direct {v7, p0, v4, v8}, Lc/I2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-virtual {v5, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42700000    # 60.0f

    invoke-virtual {p0, v7}, Lc/k3;->x(F)I

    move-result v8

    invoke-virtual {p0, v7}, Lc/k3;->x(F)I

    move-result v7

    invoke-direct {v4, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-lez v3, :cond_2

    const/high16 v3, 0x40800000    # 4.0f

    invoke-virtual {p0, v3}, Lc/k3;->x(F)I

    move-result v3

    iput v3, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_2
    invoke-virtual {v1, v5, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move v3, v6

    goto/16 :goto_0

    :cond_3
    new-instance v2, Landroid/widget/HorizontalScrollView;

    invoke-direct {v2, v6}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v0}, Landroid/widget/HorizontalScrollView;->setFillViewport(Z)V

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    iget v0, v0, Lc/r4;->c:I

    iget p1, p1, Lc/j3;->f:I

    invoke-virtual {p0, v0, p1}, Lc/k3;->t0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v0, -0x2

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v1, p1}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v2
.end method

.method public final w0()I
    .locals 10

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    const/high16 v3, 0x41800000    # 16.0f

    const/4 v4, 0x2

    invoke-static {v4, v3, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    const-string v2, "sans"

    const/4 v3, 0x1

    invoke-static {v2, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    sget-object v3, Lc/k3;->O:[Ljava/lang/String;

    array-length v5, v3

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v8, v7

    :goto_0
    if-ge v8, v5, :cond_0

    aget-object v9, v3, v8

    invoke-static {v1, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v9

    invoke-static {v6, v9}, Ljava/lang/Math;->max(FF)F

    move-result v6

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_0
    invoke-static {v2, v7}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    const/high16 v3, 0x41500000    # 13.0f

    invoke-static {v4, v3, v2}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setTextSize(F)V

    sget-object v2, Lc/k3;->P:[Ljava/lang/String;

    array-length v3, v2

    :goto_1
    if-ge v7, v3, :cond_1

    aget-object v4, v2, v7

    invoke-static {v1, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    invoke-static {v6, v4}, Ljava/lang/Math;->max(FF)F

    move-result v6

    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v6, v0

    const/high16 v0, 0x42000000    # 32.0f

    add-float/2addr v6, v0

    const/high16 v0, 0x41e00000    # 28.0f

    add-float/2addr v6, v0

    const/high16 v0, 0x41600000    # 14.0f

    add-float/2addr v6, v0

    add-float/2addr v6, v0

    const/high16 v0, 0x41400000    # 12.0f

    add-float/2addr v6, v0

    const/high16 v0, 0x40800000    # 4.0f

    add-float/2addr v6, v0

    const/high16 v0, 0x43800000    # 256.0f

    invoke-static {v0, v6}, Ljava/lang/Math;->max(FF)F

    move-result v0

    float-to-double v0, v0

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v0

    double-to-int v0, v0

    return v0
.end method

.method public final x(F)I
    .locals 1

    iget-object v0, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final x0(Landroid/widget/LinearLayout;Landroid/view/View;II)V
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    int-to-float p3, p3

    invoke-virtual {p0, p3}, Lc/k3;->x(F)I

    move-result p3

    iput p3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    int-to-float p3, p4

    invoke-virtual {p0, p3}, Lc/k3;->x(F)I

    move-result p3

    iput p3, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {p1, p2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final y(I)V
    .locals 3

    iput p1, p0, Lc/k3;->r:I

    iget-object v0, p0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lc/k3;->v:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lc/k3;->w:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v1

    iput v1, p0, Lc/k3;->x:F

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const/4 v2, 0x3

    invoke-static {v1, v2}, Lc/G8;->A0(Ljava/lang/String;I)I

    move-result v1

    iput v1, p0, Lc/k3;->y:I

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const/4 v0, 0x4

    invoke-static {p1, v0}, Lc/G8;->A0(Ljava/lang/String;I)I

    move-result p1

    iput p1, p0, Lc/k3;->z:I

    const/4 p1, 0x0

    iput p1, p0, Lc/k3;->s:I

    const-string p1, "pairs"

    iput-object p1, p0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {p0}, Lc/k3;->X()V

    return-void
.end method

.method public final y0()I
    .locals 3

    iget-object v0, p0, Lc/k3;->g:Lc/r4;

    iget-boolean v1, v0, Lc/r4;->m:Z

    if-eqz v1, :cond_0

    const/16 v0, 0x5c

    const/16 v1, 0x67

    const/16 v2, 0x4f

    invoke-static {v2, v0, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v0

    goto :goto_0

    :cond_0
    iget v0, v0, Lc/r4;->e:I

    :goto_0
    return v0
.end method

.method public final z0(ILjava/lang/String;Z)Landroid/widget/TextView;
    .locals 2

    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v0, p1}, Lc/k3;->z(Landroid/widget/TextView;I)V

    iget-object p1, p0, Lc/k3;->g:Lc/r4;

    iget p1, p1, Lc/r4;->d:I

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz p3, :cond_0

    const/4 p1, 0x0

    const/4 p2, 0x1

    invoke-virtual {v0, p1, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_0
    return-object v0
.end method
