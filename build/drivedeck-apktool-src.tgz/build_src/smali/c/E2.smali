.class public final synthetic Lc/E2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;

.field public final synthetic c:Landroid/widget/Switch;


# direct methods
.method public synthetic constructor <init>(Lc/k3;Landroid/widget/Switch;I)V
    .locals 0

    iput p3, p0, Lc/E2;->a:I

    iput-object p1, p0, Lc/E2;->b:Lc/k3;

    iput-object p2, p0, Lc/E2;->c:Landroid/widget/Switch;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 4

    iget p1, p0, Lc/E2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/E2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v1, "voice_button_enabled"

    invoke-static {v0, v1, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/accessibilityservice/AccessibilityService;->getServiceInfo()Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-result-object v1

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    iget v2, v1, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    or-int/lit8 v2, v2, 0x20

    iput v2, v1, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    invoke-virtual {v0, v1}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    :goto_0
    const/4 v0, 0x0

    iget-object v1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p2, :cond_3

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v2, :cond_2

    invoke-virtual {v2, v0}, Lc/g9;->n(Z)V

    :cond_2
    iget-object v2, p0, Lc/E2;->c:Landroid/widget/Switch;

    invoke-virtual {v2, v0}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_3
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->l()V

    invoke-virtual {p1}, Lc/k3;->S()V

    if-eqz p2, :cond_7

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p2, 0x1d

    if-lt p1, p2, :cond_5

    :try_start_0
    invoke-static {}, Lc/A1;->f()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lc/A1;->b(Ljava/lang/Object;)Landroid/app/role/RoleManager;

    move-result-object p1

    if-eqz p1, :cond_5

    invoke-static {p1}, Lc/A1;->k(Landroid/app/role/RoleManager;)Z

    move-result p2

    if-eqz p2, :cond_5

    invoke-static {p1}, Lc/A1;->l(Landroid/app/role/RoleManager;)Z

    move-result p2

    if-eqz p2, :cond_4

    goto :goto_2

    :cond_4
    invoke-static {p1}, Lc/A1;->i(Landroid/app/role/RoleManager;)Landroid/content/Intent;

    move-result-object p1

    const/16 p2, 0x1f92

    invoke-virtual {v1, p1, p2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    :cond_5
    const-string p1, "android.settings.VOICE_INPUT_SETTINGS"

    const-string p2, "android.settings.MANAGE_DEFAULT_APPS_SETTINGS"

    filled-new-array {p1, p2}, [Ljava/lang/String;

    move-result-object p1

    move p2, v0

    :goto_1
    const/4 v2, 0x2

    if-ge p2, v2, :cond_6

    aget-object v2, p1, p2

    :try_start_1
    new-instance v3, Landroid/content/Intent;

    invoke-direct {v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_6
    const-string p1, "\u042d\u0442\u043e\u0442 \u0440\u0430\u0437\u0434\u0435\u043b \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0432 \u043f\u0440\u043e\u0448\u0438\u0432\u043a\u0435"

    invoke-static {v1, p1, v1, v0}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :cond_7
    :goto_2
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/E2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v1, :cond_8

    invoke-virtual {v1, p2}, Lc/g9;->n(Z)V

    :cond_8
    invoke-virtual {p1}, Lc/k3;->U()V

    if-eqz p2, :cond_9

    invoke-virtual {p1}, Lc/k3;->S()V

    :cond_9
    if-nez p2, :cond_b

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_a

    goto :goto_3

    :cond_a
    const/4 p1, 0x0

    goto :goto_4

    :cond_b
    :goto_3
    const/4 p1, 0x1

    :goto_4
    iget-object p2, p0, Lc/E2;->c:Landroid/widget/Switch;

    invoke-virtual {p2, p1}, Landroid/view/View;->setEnabled(Z)V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/E2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "resume_music_on_start"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/E2;->c:Landroid/widget/Switch;

    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    if-eqz p2, :cond_c

    const/high16 p2, 0x3f800000    # 1.0f

    goto :goto_5

    :cond_c
    const p2, 0x3f266666    # 0.65f

    :goto_5
    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/E2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "dimmer_by_headlights"

    invoke-static {v1, v2, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-nez p2, :cond_e

    const-string p2, "auto"

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_d

    invoke-virtual {v0}, Lc/n1;->d0()Z

    move-result p2

    if-nez p2, :cond_e

    :cond_d
    const/4 p2, 0x1

    goto :goto_6

    :cond_e
    const/4 p2, 0x0

    :goto_6
    iget-object v0, p0, Lc/E2;->c:Landroid/widget/Switch;

    invoke-virtual {v0, p2}, Landroid/view/View;->setEnabled(Z)V

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p1}, Lc/R1;->b(Landroid/content/Context;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
