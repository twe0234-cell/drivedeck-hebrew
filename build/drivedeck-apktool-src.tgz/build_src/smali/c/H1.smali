.class public final synthetic Lc/H1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;ZI)V
    .locals 0

    .line 1
    iput p4, p0, Lc/H1;->a:I

    iput-object p1, p0, Lc/H1;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/H1;->d:Ljava/lang/Object;

    iput-boolean p3, p0, Lc/H1;->b:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ZLjava/lang/Object;I)V
    .locals 0

    .line 2
    iput p4, p0, Lc/H1;->a:I

    iput-object p1, p0, Lc/H1;->c:Ljava/lang/Object;

    iput-boolean p2, p0, Lc/H1;->b:Z

    iput-object p3, p0, Lc/H1;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    iget v0, p0, Lc/H1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/function/Consumer;

    iget-boolean v1, p0, Lc/H1;->b:Z

    iget-object v2, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v2, Lc/Z6;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v2, Lc/Z6;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x0

    :try_start_0
    iget-object v5, v2, Lc/Z6;->b:Ljava/lang/Object;

    if-eqz v5, :cond_0

    invoke-interface {v0, v5}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    if-eqz v1, :cond_1

    iput-object v4, v2, Lc/Z6;->b:Ljava/lang/Object;

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {v0, v2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_1
    return-void

    :goto_1
    if-eqz v1, :cond_2

    iput-object v4, v2, Lc/Z6;->b:Ljava/lang/Object;

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/View;

    if-eqz v1, :cond_2

    invoke-virtual {v1, v2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_2
    throw v0

    :pswitch_0
    iget-object v0, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v0, Lc/p2;

    iget-boolean v6, p0, Lc/H1;->b:Z

    iget-object v1, p0, Lc/H1;->d:Ljava/lang/Object;

    move-object v7, v1

    check-cast v7, Ljava/lang/RuntimeException;

    iget v1, v0, Lc/p2;->a:I

    packed-switch v1, :pswitch_data_1

    iget-object v1, v0, Lc/p2;->b:Lc/t2;

    iget-wide v2, v1, Lc/t2;->o:J

    iget-wide v4, v0, Lc/p2;->c:J

    cmp-long v2, v4, v2

    if-nez v2, :cond_7

    iget-object v2, v1, Lc/t2;->d:Lc/v7;

    iget-object v3, v0, Lc/p2;->d:Lc/v7;

    if-ne v3, v2, :cond_7

    iget-object v2, v1, Lc/t2;->h:Lc/v7;

    iget-object v0, v0, Lc/p2;->e:Lc/v7;

    if-eq v0, v2, :cond_3

    goto :goto_3

    :cond_3
    iget-object v0, v1, Lc/t2;->q:Lc/i2;

    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x0

    iput-boolean v0, v1, Lc/t2;->l:Z

    iput-boolean v0, v1, Lc/t2;->m:Z

    iget-boolean v0, v1, Lc/t2;->t:Z

    if-eqz v0, :cond_4

    invoke-virtual {v1}, Lc/t2;->N()V

    goto :goto_3

    :cond_4
    if-nez v7, :cond_6

    if-nez v6, :cond_5

    goto :goto_2

    :cond_5
    invoke-virtual {v1}, Lc/t2;->Q()V

    goto :goto_3

    :cond_6
    :goto_2
    const-string v0, "DriveDeckRenderer"

    const-string v2, "Keeping both displays after renderer failure"

    invoke-static {v0, v2, v7}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u044c \u043f\u0435\u0440\u0435\u043d\u043e\u0441 \u043e\u043a\u043e\u043d. \u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0432\u044b\u0431\u043e\u0440 \u0440\u0435\u0436\u0438\u043c\u0430 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445."

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    invoke-static {v0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    iget-object v0, v1, Lc/t2;->n:Lc/i2;

    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    goto :goto_3

    :pswitch_1
    iget-object v1, v0, Lc/p2;->b:Lc/t2;

    iget-wide v2, v0, Lc/p2;->c:J

    iget-object v4, v0, Lc/p2;->d:Lc/v7;

    iget-object v5, v0, Lc/p2;->e:Lc/v7;

    invoke-virtual/range {v1 .. v7}, Lc/t2;->s(JLc/v7;Lc/v7;ZLjava/lang/RuntimeException;)V

    :cond_7
    :goto_3
    return-void

    :pswitch_2
    iget-object v0, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    iget-object v1, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/function/Consumer;

    iget-boolean v2, p0, Lc/H1;->b:Z

    iget-boolean v3, v0, Lc/Z7;->r:Z

    if-nez v3, :cond_8

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lc/Z7;->n()V

    :cond_8
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v0, Lc/a;

    iget-boolean v1, p0, Lc/H1;->b:Z

    iget-object v2, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v2, Lc/a5;

    if-nez v1, :cond_a

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lc/G8;->k0(Lc/a;)Z

    move-result v1

    if-eqz v1, :cond_9

    goto :goto_4

    :cond_9
    const/4 v1, 0x0

    goto :goto_5

    :cond_a
    :goto_4
    const/4 v1, 0x1

    :goto_5
    iget-object v2, v2, Lc/a5;->c:Lc/M3;

    invoke-virtual {v2, v0, v1}, Lc/M3;->a(Lc/a;Z)V

    return-void

    :pswitch_4
    iget-object v0, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->x:Z

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_c

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-nez v2, :cond_c

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v3, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v3, Landroid/view/View;

    if-ne v2, v3, :cond_c

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    if-nez v2, :cond_c

    invoke-virtual {v0, v1}, Landroid/app/Activity;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v4, "first_run_tutorial_complete"

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_b

    iget-boolean v2, p0, Lc/H1;->b:Z

    if-nez v2, :cond_b

    iget-boolean v2, v0, Lru/drivedeck/launcher/MainActivity;->y:Z

    if-nez v2, :cond_b

    goto :goto_6

    :cond_b
    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->y:Z

    new-instance v1, Lc/n3;

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->z()Z

    move-result v2

    new-instance v4, Lc/M4;

    invoke-direct {v4, v0}, Lc/M4;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    invoke-direct {v1, v0, v3, v2, v4}, Lc/n3;-><init>(Landroid/content/Context;Landroid/view/View;ZLc/M4;)V

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    iput-object v3, v0, Lru/drivedeck/launcher/MainActivity;->w:Landroid/view/View;

    const/4 v1, 0x1

    invoke-static {v3, v1}, Lru/drivedeck/launcher/MainActivity;->e0(Landroid/view/View;Z)V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v3, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_c
    :goto_6
    return-void

    :pswitch_5
    iget-object v0, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-boolean v1, p0, Lc/H1;->b:Z

    iget-object v2, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v2, Landroid/content/Context;

    sget-object v3, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-static {v0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v3

    const/4 v5, 0x0

    iput-object v5, v3, Lc/T5;->g:Lc/j6;

    iput-object v5, v3, Lc/T5;->h:Lc/j6;

    iget-object v6, v3, Lc/T5;->h1:Ljava/util/HashSet;

    invoke-virtual {v6}, Ljava/util/HashSet;->clear()V

    iget-object v6, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v7, "adapter_error"

    const-string v8, ""

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iput-object v6, v3, Lc/T5;->E1:Ljava/lang/String;

    iput-boolean v4, v3, Lc/T5;->u:Z

    invoke-virtual {v3}, Lc/T5;->j()I

    move-result v6

    if-nez v6, :cond_d

    invoke-virtual {v3}, Lc/T5;->r()V

    :cond_d
    iget-object v6, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v7, "profile_id"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget v7, v3, Lc/T5;->t:I

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_e

    iget-object v6, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v6, v5}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object v6

    iput-object v6, v3, Lc/T5;->g:Lc/j6;

    invoke-virtual {v3}, Lc/T5;->A0()V

    invoke-virtual {v3}, Lc/T5;->u0()V

    invoke-virtual {v3}, Lc/T5;->q()V

    goto :goto_7

    :cond_e
    iget-object v8, v3, Lc/T5;->a:Landroid/content/Context;

    invoke-static {v8}, Lc/z5;->b(Landroid/content/Context;)Lc/z5;

    move-result-object v8

    new-instance v9, Lc/H5;

    const/4 v10, 0x0

    invoke-direct {v9, v3, v7, v6, v10}, Lc/H5;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lc/Z;

    const/16 v7, 0xe

    invoke-direct {v3, v8, v6, v9, v7}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object v6, v8, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v6, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_7
    if-eqz v1, :cond_10

    sput-object v5, Lc/X3;->d:Lc/W3;

    sget-object v1, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v1

    :try_start_1
    const-string v3, "yandex_weather"

    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    invoke-static {v2}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v6, "yandex_provider"

    invoke-static {v2}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v2

    invoke-interface {v3, v6, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_f

    const-string v3, "manual_city"

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_8

    :catchall_1
    move-exception v0

    goto :goto_9

    :cond_f
    :goto_8
    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    sget-wide v2, Lc/y9;->k:J

    const-wide/16 v6, 0x1

    add-long/2addr v2, v6

    sput-wide v2, Lc/y9;->k:J

    const-string v2, "\u2212\u00b0"

    sput-object v2, Lc/y9;->e:Ljava/lang/String;

    const-string v2, ""

    sput-object v2, Lc/y9;->f:Ljava/lang/String;

    sput-boolean v4, Lc/y9;->g:Z

    sput-boolean v4, Lc/y9;->h:Z

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object v2

    invoke-virtual {v2, v5}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v2

    sput-object v2, Lc/y9;->i:Lc/R0;

    const-string v2, ""

    sput-object v2, Lc/y9;->j:Ljava/lang/String;

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const-string v1, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u044b"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    goto :goto_a

    :goto_9
    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0

    :cond_10
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :cond_11
    :goto_a
    return-void

    :pswitch_6
    iget-object v0, p0, Lc/H1;->c:Ljava/lang/Object;

    check-cast v0, Lc/N1;

    iget-boolean v1, p0, Lc/H1;->b:Z

    iget-object v2, p0, Lc/H1;->d:Ljava/lang/Object;

    check-cast v2, Lc/H;

    const/4 v3, 0x0

    const/4 v4, 0x0

    :try_start_3
    iget-object v5, v0, Lc/N1;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v5, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v5, v0, Lc/N1;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v5, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    if-nez v1, :cond_13

    if-eqz v5, :cond_12

    goto :goto_b

    :cond_12
    move v1, v4

    goto :goto_c

    :cond_13
    :goto_b
    const/4 v1, 0x1

    :goto_c
    if-nez v1, :cond_14

    :try_start_4
    iget-boolean v5, v0, Lc/N1;->L:Z

    if-nez v5, :cond_14

    iget-object v5, v0, Lc/N1;->m:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v5

    if-eqz v5, :cond_15

    goto :goto_d

    :catchall_2
    move-exception v5

    goto :goto_e

    :cond_14
    :goto_d
    invoke-virtual {v0, v1}, Lc/N1;->E(Z)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :cond_15
    iget-object v5, v0, Lc/N1;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v5, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    if-eqz v2, :cond_16

    sget-object v5, Lc/N1;->W:Landroid/os/Handler;

    invoke-virtual {v5, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_16
    if-eqz v1, :cond_17

    iget-object v2, v0, Lc/N1;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_17

    invoke-virtual {v0}, Lc/N1;->k()V

    :cond_17
    iget-object v2, v0, Lc/N1;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v2

    if-eqz v1, :cond_18

    iget-object v1, v0, Lc/N1;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-nez v1, :cond_18

    iget-object v0, v0, Lc/N1;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_18
    if-eqz v2, :cond_19

    invoke-static {v3, v4}, Lc/N1;->D(Lc/H;Z)V

    :cond_19
    return-void

    :catchall_3
    move-exception v5

    move v1, v4

    :goto_e
    iget-object v6, v0, Lc/N1;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v6, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    if-eqz v2, :cond_1a

    sget-object v6, Lc/N1;->W:Landroid/os/Handler;

    invoke-virtual {v6, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1a
    if-eqz v1, :cond_1b

    iget-object v2, v0, Lc/N1;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_1b

    invoke-virtual {v0}, Lc/N1;->k()V

    :cond_1b
    iget-object v2, v0, Lc/N1;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v2

    if-eqz v1, :cond_1c

    iget-object v1, v0, Lc/N1;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-nez v1, :cond_1c

    iget-object v0, v0, Lc/N1;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_1c
    if-eqz v2, :cond_1d

    invoke-static {v3, v4}, Lc/N1;->D(Lc/H;Z)V

    :cond_1d
    throw v5

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_1
    .end packed-switch
.end method
