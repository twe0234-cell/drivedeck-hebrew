.class public final Lc/u;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# instance fields
.field public final a:Landroid/widget/ImageView;

.field public b:Landroid/widget/ImageView;

.field public final c:Landroid/widget/TextView;

.field public final d:Landroid/widget/TextView;

.field public final e:Landroid/widget/Switch;


# direct methods
.method public constructor <init>(Landroid/content/Context;Z)V
    .locals 2

    if-eqz p2, :cond_0

    const/16 v0, 0x2c

    goto :goto_0

    :cond_0
    const/16 v0, 0x32

    :goto_0
    const/4 v1, 0x0

    .line 1
    invoke-direct {p0, p1, p2, v0, v1}, Lc/u;-><init>(Landroid/content/Context;ZIZ)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;ZIZ)V
    .locals 11

    .line 2
    invoke-direct {p0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3
    invoke-static {p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    const/4 v1, 0x1

    .line 4
    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 5
    invoke-virtual {p0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v2, 0x40800000    # 4.0f

    .line 6
    invoke-virtual {p0, v2}, Lc/u;->b(F)I

    move-result v3

    invoke-virtual {p0, v2}, Lc/u;->b(F)I

    move-result v4

    invoke-virtual {p0, v2}, Lc/u;->b(F)I

    move-result v5

    const/high16 v6, 0x40000000    # 2.0f

    invoke-virtual {p0, v6}, Lc/u;->b(F)I

    move-result v6

    invoke-virtual {p0, v3, v4, v5, v6}, Landroid/view/View;->setPadding(IIII)V

    if-eqz p2, :cond_0

    const/high16 v3, 0x42c40000    # 98.0f

    goto :goto_0

    :cond_0
    add-int/lit8 v3, p3, 0x3e

    int-to-float v3, v3

    .line 7
    :goto_0
    invoke-virtual {p0, v3}, Lc/u;->b(F)I

    move-result v3

    invoke-virtual {p0, v3}, Landroid/view/View;->setMinimumHeight(I)V

    .line 8
    invoke-virtual {p0, v1}, Landroid/view/View;->setFocusable(Z)V

    .line 9
    invoke-virtual {p0, v1}, Landroid/view/View;->setClickable(Z)V

    add-int/lit8 v3, p3, 0x8

    int-to-float v3, v3

    .line 10
    invoke-virtual {p0, v3}, Lc/u;->b(F)I

    move-result v3

    .line 11
    new-instance v4, Landroid/widget/FrameLayout;

    invoke-direct {v4, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 12
    invoke-virtual {v4, v1}, Landroid/view/View;->setDuplicateParentStateEnabled(Z)V

    .line 13
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v5, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 14
    new-instance v3, Landroid/widget/ImageView;

    invoke-direct {v3, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lc/u;->a:Landroid/widget/ImageView;

    .line 15
    invoke-virtual {v3, v1}, Landroid/view/View;->setDuplicateParentStateEnabled(Z)V

    .line 16
    sget-object v5, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 17
    new-instance v5, Landroid/content/res/ColorStateList;

    const v6, 0x10100a7

    filled-new-array {v6}, [I

    move-result-object v6

    const/4 v7, 0x0

    new-array v8, v7, [I

    filled-new-array {v6, v8}, [[I

    move-result-object v6

    const/high16 v8, 0x50000000

    filled-new-array {v8, v7}, [I

    move-result-object v8

    invoke-direct {v5, v6, v8}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    .line 18
    sget-object v5, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    int-to-float v5, p3

    .line 19
    invoke-virtual {p0, v5}, Lc/u;->b(F)I

    move-result v5

    .line 20
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v8, 0x11

    invoke-direct {v6, v5, v5, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 21
    invoke-virtual {v4, v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 22
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lc/u;->c:Landroid/widget/TextView;

    .line 23
    const-string v5, "\u2713"

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz p2, :cond_1

    const/high16 v5, 0x41200000    # 10.0f

    goto :goto_1

    :cond_1
    const/high16 v5, 0x41300000    # 11.0f

    .line 24
    :goto_1
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 25
    sget-object v5, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v3, v5, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 26
    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setGravity(I)V

    .line 27
    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 28
    iget v5, v0, Lc/r4;->b:I

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 29
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 30
    invoke-virtual {v5, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 31
    iget v6, v0, Lc/r4;->d:I

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 32
    invoke-virtual {v3, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x2

    if-eqz p2, :cond_2

    const/high16 p3, 0x41900000    # 18.0f

    goto :goto_2

    :cond_2
    mul-int/2addr p3, v5

    .line 33
    div-int/lit8 p3, p3, 0x5

    const/16 v9, 0x14

    invoke-static {v9, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    int-to-float p3, p3

    :goto_2
    invoke-virtual {p0, p3}, Lc/u;->b(F)I

    move-result p3

    .line 34
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const v10, 0x800035

    invoke-direct {v9, p3, p3, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 35
    invoke-virtual {v4, v3, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 36
    new-instance p3, Landroid/widget/TextView;

    invoke-direct {p3, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, Lc/u;->d:Landroid/widget/TextView;

    .line 37
    invoke-virtual {p3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41600000    # 14.0f

    .line 38
    invoke-virtual {p3, v3}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v3, 0xb

    const/16 v4, 0xe

    .line 39
    invoke-virtual {p3, v3, v4, v1, v5}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    .line 40
    invoke-virtual {p3, v8}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v1, 0x4

    .line 41
    invoke-virtual {p3, v1}, Landroid/view/View;->setTextAlignment(I)V

    .line 42
    invoke-virtual {p3, v7}, Landroid/widget/TextView;->setIncludeFontPadding(Z)V

    .line 43
    invoke-virtual {p3, v5}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 44
    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p3, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 45
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz p2, :cond_3

    const/high16 v3, 0x42080000    # 34.0f

    goto :goto_3

    :cond_3
    const/high16 v3, 0x42100000    # 36.0f

    :goto_3
    invoke-virtual {p0, v3}, Lc/u;->b(F)I

    move-result v3

    const/4 v4, -0x1

    invoke-direct {v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-eqz p2, :cond_4

    goto :goto_4

    :cond_4
    const/high16 v2, 0x40c00000    # 6.0f

    .line 46
    :goto_4
    invoke-virtual {p0, v2}, Lc/u;->b(F)I

    move-result p2

    iput p2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 47
    invoke-virtual {p0, p3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz p4, :cond_5

    .line 48
    new-instance p2, Landroid/widget/Switch;

    invoke-direct {p2, p1}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    goto :goto_5

    :cond_5
    const/4 p2, 0x0

    :goto_5
    iput-object p2, p0, Lc/u;->e:Landroid/widget/Switch;

    if-eqz p2, :cond_6

    const/high16 p3, 0x42400000    # 48.0f

    .line 49
    invoke-virtual {p0, p3}, Lc/u;->b(F)I

    move-result p4

    invoke-virtual {p2, p4}, Landroid/widget/TextView;->setMinHeight(I)V

    .line 50
    invoke-virtual {p0, p3}, Lc/u;->b(F)I

    move-result p4

    invoke-virtual {p2, p4}, Landroid/view/View;->setMinimumWidth(I)V

    .line 51
    invoke-static {p2, v0}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    .line 52
    new-instance p4, Landroid/widget/LinearLayout$LayoutParams;

    .line 53
    invoke-static {p1, p3}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 p3, -0x2

    .line 54
    invoke-direct {p4, p3, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, p2, p4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_6
    return-void
.end method


# virtual methods
.method public final a(Lc/a;I)V
    .locals 9

    const/4 v0, 0x0

    if-nez p1, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    iget-object v1, p1, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    :goto_0
    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v0

    :goto_1
    iget-object v2, p0, Lc/u;->a:Landroid/widget/ImageView;

    if-nez v0, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :goto_2
    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Lc/u;->c()V

    iget-object v0, p0, Lc/u;->d:Landroid/widget/TextView;

    const-string v1, ""

    if-nez p1, :cond_3

    move-object v3, v1

    goto :goto_3

    :cond_3
    iget-object v3, p1, Lc/a;->b:Ljava/lang/String;

    :goto_3
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-ne p2, v4, :cond_4

    move v4, v3

    goto :goto_4

    :cond_4
    move v4, v5

    :goto_4
    const v6, 0x3ee66666    # 0.45f

    const/high16 v7, 0x3f800000    # 1.0f

    if-eqz v4, :cond_5

    move v8, v6

    goto :goto_5

    :cond_5
    move v8, v7

    :goto_5
    invoke-virtual {v2, v8}, Landroid/view/View;->setAlpha(F)V

    iget-object v2, p0, Lc/u;->b:Landroid/widget/ImageView;

    if-eqz v2, :cond_7

    if-eqz v4, :cond_6

    goto :goto_6

    :cond_6
    move v6, v7

    :goto_6
    invoke-virtual {v2, v6}, Landroid/view/View;->setAlpha(F)V

    :cond_7
    if-eqz v4, :cond_8

    const v7, 0x3f0ccccd    # 0.55f

    :cond_8
    invoke-virtual {v0, v7}, Landroid/view/View;->setAlpha(F)V

    iget-object v0, p0, Lc/u;->c:Landroid/widget/TextView;

    const/4 v2, 0x2

    if-ne p2, v2, :cond_9

    move v6, v5

    goto :goto_7

    :cond_9
    const/4 v6, 0x4

    :goto_7
    invoke-virtual {v0, v6}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lc/u;->e:Landroid/widget/Switch;

    if-eqz v0, :cond_a

    xor-int/lit8 v6, v4, 0x1

    invoke-virtual {v0, v6}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_a
    if-ne p2, v2, :cond_b

    goto :goto_8

    :cond_b
    move v3, v5

    :goto_8
    invoke-virtual {p0, v3}, Landroid/view/View;->setSelected(Z)V

    if-ne p2, v2, :cond_c

    const-string p2, ", \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    goto :goto_9

    :cond_c
    if-eqz v4, :cond_d

    const-string p2, ", \u0441\u043a\u0440\u044b\u0442\u043e"

    goto :goto_9

    :cond_d
    move-object p2, v1

    :goto_9
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    if-nez p1, :cond_e

    goto :goto_a

    :cond_e
    iget-object v1, p1, Lc/a;->b:Ljava/lang/String;

    :goto_a
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final b(F)I
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    return p1
.end method

.method public final c()V
    .locals 6

    iget-object v0, p0, Lc/u;->b:Landroid/widget/ImageView;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/u;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-nez v1, :cond_1

    iget-object v0, p0, Lc/u;->b:Landroid/widget/ImageView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iget v0, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v0, v0, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    new-instance v3, Landroid/graphics/Rect;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    const/4 v4, 0x0

    invoke-virtual {v1, v4, v4, v0, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    new-instance v0, Landroid/graphics/Canvas;

    invoke-direct {v0, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    invoke-virtual {v1, v3}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    iget-object v0, p0, Lc/u;->b:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v1, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    const/high16 v3, 0x75000000

    const/high16 v4, 0x40e00000    # 7.0f

    const/16 v5, 0xc

    invoke-static {v2, v1, v4, v5, v3}, Lc/G8;->t(Landroid/graphics/Bitmap;FFII)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->recycle()V

    return-void
.end method
