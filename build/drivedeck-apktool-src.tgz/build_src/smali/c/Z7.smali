.class public final Lc/Z7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# static fields
.field public static volatile Q:Ljava/lang/ref/WeakReference;

.field public static final R:[I


# instance fields
.field public A:J

.field public volatile B:I

.field public volatile C:I

.field public D:I

.field public E:Ljava/lang/String;

.field public F:Ljava/lang/String;

.field public G:Ljava/lang/String;

.field public H:J

.field public I:Z

.field public J:Z

.field public K:Ljava/lang/String;

.field public L:I

.field public M:Ljava/lang/String;

.field public final N:Lc/P7;

.field public final O:Lc/X7;

.field public final P:Lc/O;

.field public final a:Lc/e8;

.field public final b:Landroid/content/Context;

.field public final c:Landroid/os/Handler;

.field public final d:Ljava/util/concurrent/ExecutorService;

.field public final e:Lc/z7;

.field public final f:Lc/C8;

.field public final g:Lc/J1;

.field public h:Landroid/bluetooth/BluetoothAdapter;

.field public volatile i:Landroid/bluetooth/BluetoothProfile;

.field public volatile j:Landroid/bluetooth/BluetoothProfile;

.field public volatile k:Landroid/os/IBinder;

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public volatile q:Z

.field public volatile r:Z

.field public s:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public u:Ljava/lang/String;

.field public v:I

.field public w:I

.field public final x:Ljava/util/LinkedHashMap;

.field public y:Z

.field public z:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lc/Z7;->Q:Ljava/lang/ref/WeakReference;

    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lc/Z7;->R:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x6
        0x7
        0x8
        0x9
        0x16
        0x1d
    .end array-data
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/J1;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc/e8;

    invoke-direct {v0}, Lc/e8;-><init>()V

    iput-object v0, p0, Lc/Z7;->a:Lc/e8;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/Z7;->c:Landroid/os/Handler;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    const-string v1, ""

    iput-object v1, p0, Lc/Z7;->s:Ljava/lang/String;

    iput-object v1, p0, Lc/Z7;->t:Ljava/lang/String;

    iput-object v1, p0, Lc/Z7;->u:Ljava/lang/String;

    const/4 v2, -0x1

    iput v2, p0, Lc/Z7;->v:I

    iput v2, p0, Lc/Z7;->w:I

    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v2, p0, Lc/Z7;->x:Ljava/util/LinkedHashMap;

    iput-object v1, p0, Lc/Z7;->E:Ljava/lang/String;

    iput-object v1, p0, Lc/Z7;->F:Ljava/lang/String;

    iput-object v1, p0, Lc/Z7;->G:Ljava/lang/String;

    iput-object v1, p0, Lc/Z7;->K:Ljava/lang/String;

    new-instance v1, Lc/P7;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lc/P7;-><init>(Lc/Z7;I)V

    iput-object v1, p0, Lc/Z7;->N:Lc/P7;

    new-instance v1, Lc/X7;

    invoke-direct {v1, p0}, Lc/X7;-><init>(Lc/Z7;)V

    iput-object v1, p0, Lc/Z7;->O:Lc/X7;

    new-instance v1, Lc/O;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v2}, Lc/O;-><init>(Landroid/content/ServiceConnection;I)V

    iput-object v1, p0, Lc/Z7;->P:Lc/O;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/Z7;->b:Landroid/content/Context;

    iput-object p2, p0, Lc/Z7;->g:Lc/J1;

    new-instance p2, Lc/z7;

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v3, "bluetooth_phonebook.db"

    invoke-direct {p2, p1, v3, v1, v2}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V

    iput-object p2, p0, Lc/Z7;->e:Lc/z7;

    new-instance p2, Lc/C8;

    new-instance v1, Lc/P7;

    const/4 v2, 0x3

    invoke-direct {v1, p0, v2}, Lc/P7;-><init>(Lc/Z7;I)V

    invoke-direct {p2, p1, v0, v1}, Lc/C8;-><init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;Lc/P7;)V

    iput-object p2, p0, Lc/Z7;->f:Lc/C8;

    invoke-static {}, Lc/j8;->v()Z

    move-result p2

    if-eqz p2, :cond_0

    const-string p2, "ru.drivedeck.launcher"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    new-instance p1, Lc/a1;

    const/16 p2, 0x8

    invoke-direct {p1, p2}, Lc/a1;-><init>(I)V

    invoke-interface {v0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_0
    new-instance p1, Ljava/lang/ref/WeakReference;

    invoke-direct {p1, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object p1, Lc/Z7;->Q:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Lc/Z7;->g()V

    return-void
.end method

.method public static d(Landroid/content/Context;)Z
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    if-lt v0, v1, :cond_1

    const-string v0, "android.permission.BLUETOOTH_CONNECT"

    invoke-virtual {p0, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static p(Landroid/os/IBinder;ILjava/lang/String;)Z
    .locals 2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const-string v1, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeIntArray([I)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeFloatArray([F)V

    if-nez p2, :cond_0

    move-object p2, p1

    goto :goto_0

    :cond_0
    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object p2

    :goto_0
    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    const/4 p2, 0x1

    invoke-interface {p0, p2, v0, p1, p2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    return p0

    :catchall_0
    move-exception p0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p0

    :catch_0
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;
    .locals 4

    iget-object v0, p0, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v2, p0, Lc/Z7;->b:Landroid/content/Context;

    invoke-static {v2}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-interface {v0}, Landroid/bluetooth/BluetoothProfile;->getConnectedDevices()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_1

    const/4 v2, 0x0

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    check-cast v1, Landroid/bluetooth/BluetoothDevice;

    :cond_1
    :goto_0
    return-object v1
.end method

.method public final b(Ljava/util/function/Consumer;)V
    .locals 2

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget v0, v0, Lc/e8;->e:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    const/16 v0, 0x9

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1, p1}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :goto_0
    return-void
.end method

.method public final c(IILjava/lang/String;)V
    .locals 2

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/Z7;->q:Z

    if-eqz v0, :cond_2

    iget v0, p0, Lc/Z7;->B:I

    if-ne p2, v0, :cond_2

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    if-nez p1, :cond_1

    iget-object p1, p0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v0, Lc/R7;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p3, p2, v1}, Lc/R7;-><init>(Lc/Z7;Ljava/lang/String;II)V

    const-wide/16 p2, 0x7d0

    invoke-virtual {p1, v0, p2, p3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0, p2}, Lc/Z7;->k(I)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final e(Landroid/view/KeyEvent;)Z
    .locals 7

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/4 v1, 0x5

    const/16 v2, 0x4f

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ne v0, v1, :cond_0

    move v1, v5

    goto :goto_0

    :cond_0
    if-ne v0, v3, :cond_1

    const/4 v1, 0x2

    goto :goto_0

    :cond_1
    if-ne v0, v2, :cond_2

    const/4 v1, 0x4

    goto :goto_0

    :cond_2
    move v1, v4

    :goto_0
    if-eqz v1, :cond_e

    iget-boolean v6, p0, Lc/Z7;->r:Z

    if-eqz v6, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    if-ne v6, v5, :cond_5

    iget p1, p0, Lc/Z7;->L:I

    and-int v0, p1, v1

    if-eqz v0, :cond_4

    move v4, v5

    :cond_4
    not-int v0, v1

    and-int/2addr p1, v0

    iput p1, p0, Lc/Z7;->L:I

    return v4

    :cond_5
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    if-eqz v6, :cond_6

    return v4

    :cond_6
    iget v6, p0, Lc/Z7;->L:I

    and-int/2addr v6, v1

    if-eqz v6, :cond_7

    return v5

    :cond_7
    iget-object v6, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v6}, Lc/e8;->c()Z

    move-result v6

    if-eqz v6, :cond_e

    iget-object v6, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v6}, Lc/e8;->d()Z

    move-result v6

    if-nez v6, :cond_8

    goto :goto_2

    :cond_8
    iget v4, p0, Lc/Z7;->L:I

    or-int/2addr v1, v4

    iput v1, p0, Lc/Z7;->L:I

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-eqz p1, :cond_9

    return v5

    :cond_9
    new-instance p1, Lc/E3;

    const/4 v1, 0x4

    invoke-direct {p1, p0, v1}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    const/4 v1, 0x3

    if-ne v0, v3, :cond_b

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget v0, v0, Lc/e8;->e:I

    if-ne v0, v1, :cond_a

    invoke-virtual {p0, p1}, Lc/Z7;->o(Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_a
    invoke-virtual {p0, p1}, Lc/Z7;->j(Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_b
    iget-object v3, p0, Lc/Z7;->a:Lc/e8;

    iget v3, v3, Lc/e8;->e:I

    if-ne v3, v1, :cond_c

    invoke-virtual {p0, p1}, Lc/Z7;->b(Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_c
    if-ne v0, v2, :cond_d

    invoke-virtual {p0, p1}, Lc/Z7;->j(Ljava/util/function/Consumer;)V

    :cond_d
    :goto_1
    return v5

    :cond_e
    :goto_2
    return v4
.end method

.method public final f(ILjava/lang/String;Ljava/util/function/Consumer;)V
    .locals 11

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_2

    :cond_0
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v4, v0, Lc/e8;->a:Ljava/lang/String;

    iget-object v0, v0, Lc/e8;->d:Ljava/lang/String;

    const-string v1, "TEYES / FYT"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/Z7;->k:Landroid/os/IBinder;

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iget v3, p0, Lc/Z7;->C:I

    new-instance v10, Lc/S7;

    const/4 v9, 0x0

    move-object v1, v10

    move-object v2, p0

    move-object v5, v0

    move-object v6, p3

    move v7, p1

    move-object v8, p2

    invoke-direct/range {v1 .. v9}, Lc/S7;-><init>(Lc/Z7;ILjava/lang/String;Landroid/os/IBinder;Ljava/util/function/Consumer;ILjava/lang/String;I)V

    if-eqz v0, :cond_2

    const/4 p2, 0x7

    if-ne p1, p2, :cond_2

    new-instance p1, Lc/b;

    const/4 p2, 0x4

    invoke-direct {p1, v10, p3, p2}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 p2, 0x1

    invoke-virtual {p0, p2, p1}, Lc/Z7;->s(ZLc/b;)V

    goto :goto_1

    :cond_2
    invoke-virtual {v10}, Lc/S7;->run()V

    :goto_1
    return-void

    :cond_3
    :goto_2
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p3, p1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public final g()V
    .locals 5

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/Z7;->b:Landroid/content/Context;

    invoke-static {v0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_3

    :try_start_0
    iget-object v0, p0, Lc/Z7;->b:Landroid/content/Context;

    const-class v1, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/BluetoothManager;

    if-nez v0, :cond_1

    const/4 v0, 0x0

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    :goto_0
    iput-object v0, p0, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    if-eqz v0, :cond_2

    iget-boolean v1, p0, Lc/Z7;->o:Z

    if-nez v1, :cond_2

    iget-object v1, p0, Lc/Z7;->b:Landroid/content/Context;

    iget-object v2, p0, Lc/Z7;->O:Lc/X7;

    const/16 v3, 0x10

    invoke-virtual {v0, v1, v2, v3}, Landroid/bluetooth/BluetoothAdapter;->getProfileProxy(Landroid/content/Context;Landroid/bluetooth/BluetoothProfile$ServiceListener;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/Z7;->o:Z

    :cond_2
    iget-object v0, p0, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    if-eqz v0, :cond_3

    iget-boolean v1, p0, Lc/Z7;->p:Z

    if-nez v1, :cond_3

    iget-object v1, p0, Lc/Z7;->b:Landroid/content/Context;

    iget-object v2, p0, Lc/Z7;->O:Lc/X7;

    const/16 v3, 0x11

    invoke-virtual {v0, v1, v2, v3}, Landroid/bluetooth/BluetoothAdapter;->getProfileProxy(Landroid/content/Context;Landroid/bluetooth/BluetoothProfile$ServiceListener;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/Z7;->p:Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string v0, "\u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u0430 \u043a Bluetooth"

    iput-object v0, p0, Lc/Z7;->K:Ljava/lang/String;

    :cond_3
    :goto_1
    iget-boolean v0, p0, Lc/Z7;->l:Z

    if-nez v0, :cond_4

    iget-object v0, p0, Lc/Z7;->b:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const-string v2, "com.syu.ms"

    invoke-virtual {v1, v0, v2}, Landroid/content/pm/PackageManager;->checkSignatures(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "com.syu.bt"

    invoke-virtual {v1, v0, v2}, Landroid/content/pm/PackageManager;->checkSignatures(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_4

    :try_start_1
    iget-object v0, p0, Lc/Z7;->b:Landroid/content/Context;

    new-instance v1, Landroid/content/Intent;

    const-string v3, "com.syu.ms.bt"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v3, Landroid/content/ComponentName;

    const-string v4, "app.ModuleService"

    invoke-direct {v3, v2, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, p0, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/Z7;->l:Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    const-string v0, "Bluetooth-\u0441\u043b\u0443\u0436\u0431\u0430 CC3 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"

    iput-object v0, p0, Lc/Z7;->K:Ljava/lang/String;

    :cond_4
    :goto_2
    invoke-virtual {p0}, Lc/Z7;->n()V

    return-void
.end method

.method public final h(Ljava/lang/String;Ljava/util/function/Consumer;)V
    .locals 8

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v3, v0, Lc/e8;->a:Ljava/lang/String;

    iget v5, p0, Lc/Z7;->B:I

    iget-object v0, p0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v7, Lc/F5;

    move-object v1, v7

    move-object v2, p0

    move-object v4, p1

    move-object v6, p2

    invoke-direct/range {v1 .. v6}, Lc/F5;-><init>(Lc/Z7;Ljava/lang/String;Ljava/lang/String;ILjava/util/function/Consumer;)V

    invoke-interface {v0, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final i(Ljava/lang/String;I)V
    .locals 6

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lc/Z7;->q:Z

    if-eqz v0, :cond_1

    iget v0, p0, Lc/Z7;->B:I

    if-ne p2, v0, :cond_1

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lc/Z7;->A:J

    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-lez v4, :cond_0

    sub-long v2, v0, v2

    const-wide/16 v4, 0x7530

    cmp-long v2, v2, v4

    if-gez v2, :cond_0

    iget-wide v2, p0, Lc/Z7;->z:J

    sub-long/2addr v0, v2

    const-wide/32 v2, 0x2bf20

    cmp-long v0, v0, v2

    if-gez v0, :cond_0

    iget-object v0, p0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v1, Lc/R7;

    const/4 v2, 0x1

    invoke-direct {v1, p0, p1, p2, v2}, Lc/R7;-><init>(Lc/Z7;Ljava/lang/String;II)V

    const-wide/16 p1, 0x3a98

    invoke-virtual {v0, v1, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_0
    const/4 p1, 0x0

    iput-boolean p1, p0, Lc/Z7;->q:Z

    const-string p1, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u043d\u0435 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u044b. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043f\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432 \u043d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0435 \u0438 \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0438\u043c\u043f\u043e\u0440\u0442"

    iput-object p1, p0, Lc/Z7;->K:Ljava/lang/String;

    iget-object p1, p0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {p1}, Lc/J1;->run()V

    :cond_1
    return-void
.end method

.method public final j(Ljava/util/function/Consumer;)V
    .locals 2

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xa

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1, p1}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :goto_0
    return-void
.end method

.method public final k(I)V
    .locals 8

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/Z7;->q:Z

    if-eqz v0, :cond_2

    iget v0, p0, Lc/Z7;->B:I

    if-eq p1, v0, :cond_0

    goto :goto_2

    :cond_0
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v5, v0, Lc/e8;->a:Ljava/lang/String;

    iget-object v0, v0, Lc/e8;->d:Ljava/lang/String;

    const-string v1, "TEYES / FYT"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    iget-boolean v0, p0, Lc/Z7;->y:Z

    if-nez v0, :cond_1

    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lc/Z7;->x:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    :goto_0
    move-object v3, v0

    goto :goto_1

    :cond_1
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    goto :goto_0

    :goto_1
    iget-object v0, p0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v7, Lc/U7;

    move-object v1, v7

    move-object v2, p0

    move v6, p1

    invoke-direct/range {v1 .. v6}, Lc/U7;-><init>(Lc/Z7;Ljava/util/List;ZLjava/lang/String;I)V

    invoke-interface {v0, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_2
    :goto_2
    return-void
.end method

.method public final l()V
    .locals 9

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, v0, Lc/e8;->a:Ljava/lang/String;

    :goto_0
    move-object v4, v1

    goto :goto_1

    :cond_0
    const-string v1, ""

    goto :goto_0

    :goto_1
    iget-object v6, v0, Lc/e8;->c:Ljava/lang/String;

    iget v5, v0, Lc/e8;->e:I

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/Z7;->E:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    return-void

    :cond_1
    iput-object v0, p0, Lc/Z7;->E:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    new-instance v0, Lc/T7;

    move-object v2, v0

    move-object v3, p0

    invoke-direct/range {v2 .. v8}, Lc/T7;-><init>(Lc/Z7;Ljava/lang/String;ILjava/lang/String;J)V

    iget-object v1, p0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final m()V
    .locals 10

    iget-boolean v0, p0, Lc/Z7;->m:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v1, v0, Lc/e8;->a:Ljava/lang/String;

    iget v2, v0, Lc/e8;->e:I

    iget-object v3, v0, Lc/e8;->c:Ljava/lang/String;

    const-string v4, ""

    iput-object v4, v0, Lc/e8;->c:Ljava/lang/String;

    const/4 v5, 0x0

    iput v5, v0, Lc/e8;->e:I

    const-string v6, "TEYES / FYT"

    iput-object v6, v0, Lc/e8;->d:Ljava/lang/String;

    iget-object v6, p0, Lc/Z7;->s:Ljava/lang/String;

    iput-object v6, v0, Lc/e8;->a:Ljava/lang/String;

    iget-object v6, p0, Lc/Z7;->t:Ljava/lang/String;

    iput-object v6, v0, Lc/e8;->b:Ljava/lang/String;

    iget v6, p0, Lc/Z7;->v:I

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eq v6, v8, :cond_2

    const/4 v9, 0x3

    if-eq v6, v9, :cond_3

    const/4 v8, 0x4

    if-eq v6, v8, :cond_1

    const/4 v9, 0x5

    if-eq v6, v9, :cond_3

    const/4 v8, 0x7

    if-eq v6, v8, :cond_2

    move v8, v5

    goto :goto_0

    :cond_1
    move v8, v9

    goto :goto_0

    :cond_2
    move v8, v7

    :cond_3
    :goto_0
    iput v8, v0, Lc/e8;->e:I

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v6

    if-nez v6, :cond_4

    iput-object v4, v0, Lc/e8;->c:Ljava/lang/String;

    :cond_4
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v6, p0, Lc/Z7;->u:Ljava/lang/String;

    iput-object v6, v0, Lc/e8;->c:Ljava/lang/String;

    :cond_5
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    iget v0, p0, Lc/Z7;->B:I

    add-int/2addr v0, v7

    iput v0, p0, Lc/Z7;->B:I

    iput-boolean v5, p0, Lc/Z7;->q:Z

    iput-boolean v5, p0, Lc/Z7;->n:Z

    iput-object v4, p0, Lc/Z7;->K:Ljava/lang/String;

    :cond_6
    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget v1, v0, Lc/e8;->e:I

    if-ne v2, v1, :cond_7

    iget-object v0, v0, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    :cond_7
    iget v0, p0, Lc/Z7;->C:I

    add-int/2addr v0, v7

    iput v0, p0, Lc/Z7;->C:I

    :cond_8
    invoke-virtual {p0}, Lc/Z7;->l()V

    iget-object v0, p0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    return-void
.end method

.method public final n()V
    .locals 3

    iget-boolean v0, p0, Lc/Z7;->r:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/Z7;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/Z7;->N:Lc/P7;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lc/P7;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Lc/P7;-><init>(Lc/Z7;I)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final o(Ljava/util/function/Consumer;)V
    .locals 2

    iget-object v0, p0, Lc/Z7;->a:Lc/e8;

    iget v0, v0, Lc/e8;->e:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    const/16 v0, 0xb

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1, p1}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {p1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :goto_0
    return-void
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 3

    invoke-virtual {p0, p1}, Lc/Z7;->onServiceDisconnected(Landroid/content/ComponentName;)V

    iget-boolean p1, p0, Lc/Z7;->l:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Lc/Z7;->b:Landroid/content/Context;

    invoke-virtual {p1, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Lc/Z7;->l:Z

    :cond_0
    iget-object p1, p0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v0, Lc/P7;

    const/4 v1, 0x5

    invoke-direct {v0, p0, v1}, Lc/P7;-><init>(Lc/Z7;I)V

    const-wide/16 v1, 0x7d0

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    iget-boolean p1, p0, Lc/Z7;->r:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    :try_start_0
    const-string p1, "com.syu.ipc.IRemoteModule"

    invoke-interface {p2}, Landroid/os/IBinder;->getInterfaceDescriptor()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez p1, :cond_1

    return-void

    :cond_1
    iput-object p2, p0, Lc/Z7;->k:Landroid/os/IBinder;

    const/4 p1, 0x0

    const/4 p2, 0x1

    invoke-virtual {p0, p2, p1}, Lc/Z7;->s(ZLc/b;)V

    sget-object p1, Lc/Z7;->R:[I

    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    aget v2, p1, v1

    invoke-virtual {p0, v2, p2}, Lc/Z7;->q(IZ)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :catch_0
    :cond_2
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lc/Z7;->r(Z)V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/Z7;->k:Landroid/os/IBinder;

    iput-boolean p1, p0, Lc/Z7;->m:Z

    const/4 v0, -0x1

    iput v0, p0, Lc/Z7;->v:I

    const-string v0, ""

    iput-object v0, p0, Lc/Z7;->u:Ljava/lang/String;

    iput-object v0, p0, Lc/Z7;->t:Ljava/lang/String;

    iput-object v0, p0, Lc/Z7;->s:Ljava/lang/String;

    iput-boolean p1, p0, Lc/Z7;->q:Z

    invoke-virtual {p0}, Lc/Z7;->n()V

    return-void
.end method

.method public final q(IZ)V
    .locals 3

    iget-object v0, p0, Lc/Z7;->k:Landroid/os/IBinder;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const-string v2, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    iget-object v2, p0, Lc/Z7;->P:Lc/O;

    invoke-virtual {v1, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    invoke-virtual {v1, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 p1, 0x1

    if-eqz p2, :cond_1

    invoke-virtual {v1, p1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_1
    :goto_0
    if-eqz p2, :cond_2

    const/4 p2, 0x3

    goto :goto_1

    :cond_2
    const/4 p2, 0x4

    :goto_1
    const/4 v2, 0x0

    invoke-interface {v0, p2, v1, v2, p1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catch_0
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    goto :goto_3

    :goto_2
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    throw p1

    :goto_3
    return-void
.end method

.method public final r(Z)V
    .locals 5

    const-string v0, "syu.bt.show.pip"

    const-class v1, Ljava/lang/String;

    if-nez p1, :cond_0

    iget-object v2, p0, Lc/Z7;->M:Ljava/lang/String;

    if-nez v2, :cond_0

    return-void

    :cond_0
    :try_start_0
    const-string v2, "android.os.SystemProperties"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const-string v3, "get"

    filled-new-array {v1, v1}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const-string v4, "set"

    filled-new-array {v1, v1}, [Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v2, v4, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const-string v2, "false"

    filled-new-array {v0, v2}, [Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    invoke-virtual {v3, v4, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v3, "true"

    if-eqz p1, :cond_1

    :try_start_1
    filled-new-array {v0, v3}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v1, v4, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p1, p0, Lc/Z7;->M:Ljava/lang/String;

    if-nez p1, :cond_3

    iput-object v2, p0, Lc/Z7;->M:Ljava/lang/String;

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_0

    :catch_1
    move-exception p1

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lc/Z7;->M:Ljava/lang/String;

    if-eqz p1, :cond_3

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lc/Z7;->M:Ljava/lang/String;

    filled-new-array {v0, p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v1, v4, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    iput-object v4, p0, Lc/Z7;->M:Ljava/lang/String;
    :try_end_1
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :goto_0
    const-string v0, "DriveDeckPhone"

    const-string v1, "FYT incoming steering-key mode unavailable"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    :goto_1
    return-void
.end method

.method public final s(ZLc/b;)V
    .locals 11

    iget-boolean v0, p0, Lc/Z7;->l:Z

    if-eqz v0, :cond_4

    iget-object v0, p0, Lc/Z7;->k:Landroid/os/IBinder;

    if-nez v0, :cond_0

    goto :goto_2

    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.android.ecar.send"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "com.syu.ms"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    if-eqz p1, :cond_1

    const-string v1, "BluetoothMakeCall"

    goto :goto_0

    :cond_1
    const-string v1, "HideCallUI"

    :goto_0
    const-string v2, "ecarSendKey"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    :try_start_0
    iget-object v3, p0, Lc/Z7;->b:Landroid/content/Context;

    new-instance v6, Lc/Y7;

    invoke-direct {v6, p0, p1, p2}, Lc/Y7;-><init>(Lc/Z7;ZLc/b;)V

    iget-object v7, p0, Lc/Z7;->c:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual/range {v3 .. v10}, Landroid/content/Context;->sendOrderedBroadcast(Landroid/content/Intent;Ljava/lang/String;Landroid/content/BroadcastReceiver;Landroid/os/Handler;ILjava/lang/String;Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const-string p1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    iput-object p1, p0, Lc/Z7;->K:Ljava/lang/String;

    iget-boolean p1, p0, Lc/Z7;->r:Z

    if-nez p1, :cond_3

    if-eqz p2, :cond_2

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p2, p1}, Lc/b;->accept(Ljava/lang/Object;)V

    :cond_2
    iget-object p1, p0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {p1}, Lc/J1;->run()V

    :cond_3
    :goto_1
    return-void

    :cond_4
    :goto_2
    if-eqz p2, :cond_5

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p2, p1}, Lc/b;->accept(Ljava/lang/Object;)V

    :cond_5
    return-void
.end method
