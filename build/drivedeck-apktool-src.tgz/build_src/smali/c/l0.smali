.class public final synthetic Lc/l0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/ToIntFunction;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, Lc/l0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final applyAsInt(Ljava/lang/Object;)I
    .locals 1

    iget v0, p0, Lc/l0;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lc/F0;

    iget p1, p1, Lc/F0;->f:I

    return p1

    :pswitch_0
    check-cast p1, Lc/r0;

    iget-object p1, p1, Lc/r0;->a:Lc/s0;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    return p1

    :pswitch_1
    check-cast p1, Lc/r0;

    iget p1, p1, Lc/r0;->c:I

    return p1

    :pswitch_2
    check-cast p1, Lc/r0;

    iget p1, p1, Lc/r0;->d:I

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
