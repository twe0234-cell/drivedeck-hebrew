.class public final Lc/I5;
.super Landroid/bluetooth/le/ScanCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/T5;


# direct methods
.method public constructor <init>(Lc/T5;)V
    .locals 0

    iput-object p1, p0, Lc/I5;->a:Lc/T5;

    invoke-direct {p0}, Landroid/bluetooth/le/ScanCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final onScanFailed(I)V
    .locals 3

    iget-object v0, p0, Lc/I5;->a:Lc/T5;

    iget-object v0, v0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v1, Lc/w;

    const/4 v2, 0x7

    invoke-direct {v1, p0, p1, v2}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final onScanResult(ILandroid/bluetooth/le/ScanResult;)V
    .locals 2

    iget-object p1, p0, Lc/I5;->a:Lc/T5;

    iget-object p1, p1, Lc/T5;->c:Landroid/os/Handler;

    new-instance v0, Lc/H;

    const/16 v1, 0x18

    invoke-direct {v0, p0, p2, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
