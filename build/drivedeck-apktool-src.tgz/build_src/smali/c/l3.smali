.class public final synthetic Lc/l3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/n3;


# direct methods
.method public synthetic constructor <init>(Lc/n3;I)V
    .locals 0

    iput p2, p0, Lc/l3;->a:I

    iput-object p1, p0, Lc/l3;->b:Lc/n3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget-object p1, p0, Lc/l3;->b:Lc/n3;

    iget v0, p0, Lc/l3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p1, Lc/n3;->i:Landroid/view/View;

    instance-of v0, v0, Lc/Q3;

    iget-object v1, p1, Lc/n3;->e:Landroid/widget/TextView;

    iget-object v2, p1, Lc/n3;->d:Landroid/widget/TextView;

    iget-object v3, p1, Lc/n3;->a:Lc/m3;

    const-string v4, ". "

    if-eqz v0, :cond_2

    iget v0, p1, Lc/n3;->l:I

    const/4 v5, 0x2

    if-ge v0, v5, :cond_0

    add-int/lit8 v0, v0, 0x1

    iput v0, p1, Lc/n3;->l:I

    invoke-virtual {p1}, Lc/n3;->g()V

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/View;->announceForAccessibility(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_0
    iget-boolean v0, p1, Lc/n3;->j:Z

    if-eqz v0, :cond_1

    iget-object p1, p1, Lc/n3;->h:Lc/M4;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object p1, p1, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->S()V

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Lc/n3;->c()V

    goto :goto_0

    :cond_2
    iget v0, p1, Lc/n3;->l:I

    const/4 v5, 0x5

    if-ge v0, v5, :cond_3

    add-int/lit8 v0, v0, 0x1

    iput v0, p1, Lc/n3;->l:I

    invoke-virtual {p1}, Lc/n3;->g()V

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/View;->announceForAccessibility(Ljava/lang/CharSequence;)V

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, Lc/n3;->c()V

    :goto_0
    return-void

    :pswitch_0
    invoke-virtual {p1}, Lc/n3;->c()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
