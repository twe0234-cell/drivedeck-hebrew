.class public final Lc/P4;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/P4;->a:I

    iput-object p1, p0, Lc/P4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 13

    const/4 p1, -0x1

    const/4 v0, 0x1

    iget-object v1, p0, Lc/P4;->b:Lru/drivedeck/launcher/MainActivity;

    const/4 v2, 0x0

    iget v3, p0, Lc/P4;->a:I

    packed-switch v3, :pswitch_data_0

    const-string v0, "key"

    invoke-virtual {p2, v0, p1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const-string v0, "hold"

    invoke-virtual {p2, v0, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p2

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->isOrderedBroadcast()Z

    move-result v0

    if-eqz v0, :cond_4

    iget-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-eqz v0, :cond_4

    const/16 v0, 0x17

    if-eqz p2, :cond_0

    if-ne p1, v0, :cond_4

    goto :goto_0

    :cond_0
    if-eq p1, v0, :cond_1

    const/4 v0, 0x4

    if-eq p1, v0, :cond_1

    const/16 v0, 0x15

    if-eq p1, v0, :cond_1

    const/16 v0, 0x16

    if-eq p1, v0, :cond_1

    const/16 v0, 0x13

    if-eq p1, v0, :cond_1

    const/16 v0, 0x14

    if-eq p1, v0, :cond_1

    const/16 v0, 0x104

    if-eq p1, v0, :cond_1

    const/16 v0, 0x105

    if-ne p1, v0, :cond_4

    :cond_1
    :goto_0
    invoke-virtual {v1}, Landroid/app/Activity;->hasWindowFocus()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-eqz v0, :cond_4

    iget-object v0, v0, Lc/t8;->c:Lc/r8;

    if-eqz v0, :cond_4

    :cond_2
    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object v0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v11

    new-instance v2, Landroid/view/KeyEvent;

    const/4 v8, 0x0

    const/4 v10, 0x0

    move-object v3, v2

    move-wide v4, v11

    move-wide v6, v11

    move v9, p1

    invoke-direct/range {v3 .. v10}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-virtual {v1, v2}, Lru/drivedeck/launcher/MainActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    new-instance v2, Lc/Q4;

    move-object v3, v2

    move-object v4, p0

    move-wide v5, v11

    move v7, p1

    move-object v8, v0

    invoke-direct/range {v3 .. v8}, Lc/Q4;-><init>(Lc/P4;JILandroid/content/BroadcastReceiver$PendingResult;)V

    if-eqz p2, :cond_3

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result p1

    int-to-long p1, p1

    const-wide/16 v3, 0x32

    add-long/2addr p1, v3

    goto :goto_1

    :cond_3
    const-wide/16 p1, 0x14

    :goto_1
    invoke-virtual {v1, v2, p1, p2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    return-void

    :pswitch_0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    const-string v4, "android.intent.action.PACKAGE_REMOVED"

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const-string v5, "android.intent.extra.REPLACING"

    if-eqz v3, :cond_5

    invoke-virtual {p2, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_5

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    if-eqz v3, :cond_5

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    const-string v6, "icon_pack_package"

    const-string v7, ""

    invoke-interface {v3, v6, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v8

    invoke-virtual {v8}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3, v6, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_5
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    const-string v6, "ru.drivedeck.voice"

    if-eqz v3, :cond_6

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-virtual {p2, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_6

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    if-eqz v3, :cond_6

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    invoke-virtual {v3, v2}, Lc/g9;->n(Z)V

    :cond_6
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v3}, Lc/z;->k()V

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    if-eqz v3, :cond_9

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_7

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ld/a;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v6

    invoke-virtual {v6}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    :cond_7
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-virtual {p2, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_9

    :cond_8
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->l()V

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v3, :cond_9

    invoke-virtual {v3}, Lc/k3;->T()V

    :cond_9
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {p2, v5, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    if-nez v3, :cond_c

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    if-eqz v3, :cond_c

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p2

    invoke-virtual {p2}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object p2

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v3

    new-instance v4, Lc/F2;

    invoke-direct {v4, p2, v0}, Lc/F2;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->removeIf(Ljava/util/function/Predicate;)Z

    move-result v4

    if-nez v4, :cond_a

    goto :goto_2

    :cond_a
    invoke-virtual {v1, v3}, Lru/drivedeck/launcher/MainActivity;->b0(Ljava/util/ArrayList;)V

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v3, :cond_c

    invoke-virtual {v3}, Landroid/app/Dialog;->isShowing()Z

    move-result v3

    if-eqz v3, :cond_c

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    iget-object v3, v1, Lc/k3;->e:Ljava/util/ArrayList;

    new-instance v4, Lc/F2;

    invoke-direct {v4, p2, v2}, Lc/F2;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->removeIf(Ljava/util/function/Predicate;)Z

    move-result p2

    if-nez p2, :cond_b

    goto :goto_2

    :cond_b
    iget p2, v1, Lc/k3;->q:I

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v0

    invoke-static {p2, v2}, Ljava/lang/Math;->min(II)I

    move-result p2

    iput p2, v1, Lc/k3;->q:I

    iput p1, v1, Lc/k3;->r:I

    const/4 p1, 0x0

    iput-object p1, v1, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v1}, Lc/k3;->S()V

    :cond_c
    :goto_2
    return-void

    :pswitch_1
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string v3, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/16 v3, 0x80

    if-eqz p1, :cond_d

    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->z:Z

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/view/Window;->clearFlags(I)V

    goto/16 :goto_4

    :cond_d
    const-string p1, "android.intent.action.SCREEN_ON"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_10

    iget-boolean p1, v1, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-eqz p1, :cond_e

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1, v3}, Landroid/view/Window;->addFlags(I)V

    :cond_e
    iget-boolean p1, v1, Lru/drivedeck/launcher/MainActivity;->z:Z

    if-eqz p1, :cond_13

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->z:Z

    invoke-static {v1}, Lc/G8;->t0(Landroid/content/Context;)V

    iget-object p1, v1, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object p2, v1, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne p1, p2, :cond_f

    if-eqz p2, :cond_f

    invoke-virtual {p2}, Lc/Q3;->M()V

    goto :goto_4

    :cond_f
    iget-object p2, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne p1, p2, :cond_13

    if-eqz p2, :cond_13

    invoke-virtual {p2}, Lc/m2;->D()V

    goto :goto_4

    :cond_10
    const-string p1, "android.intent.action.TIMEZONE_CHANGED"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_12

    const-string p1, "android.intent.action.TIME_SET"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_11

    goto :goto_3

    :cond_11
    const-string p1, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_13

    sget p1, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_4

    :cond_12
    :goto_3
    iget-object p1, v1, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object p2, v1, Lru/drivedeck/launcher/MainActivity;->x0:Lc/N4;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p2}, Lc/N4;->run()V

    :cond_13
    :goto_4
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
