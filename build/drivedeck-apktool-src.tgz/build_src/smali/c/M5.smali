.class public final Lc/M5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public a:I

.field public final synthetic b:I

.field public final synthetic c:Landroid/bluetooth/BluetoothDevice;

.field public final synthetic d:Lc/T5;


# direct methods
.method public constructor <init>(Lc/T5;ILandroid/bluetooth/BluetoothDevice;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/M5;->d:Lc/T5;

    iput p2, p0, Lc/M5;->b:I

    iput-object p3, p0, Lc/M5;->c:Landroid/bluetooth/BluetoothDevice;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v0, "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u0443\u0434\u0430\u043b\u0435\u043d\u044b. \u0421\u043e\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u0443\u0434\u0430\u043b\u0438\u0442\u0435 \u0432 Bluetooth Android"

    iget v1, p0, Lc/M5;->b:I

    iget-object v2, p0, Lc/M5;->d:Lc/T5;

    iget v2, v2, Lc/T5;->t:I

    if-eq v1, v2, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x1

    :try_start_0
    iget-object v2, p0, Lc/M5;->c:Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothDevice;->getBondState()I

    move-result v2

    const/16 v3, 0xa

    if-ne v2, v3, :cond_1

    iget-object v2, p0, Lc/M5;->d:Lc/T5;

    const-string v3, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440, \u0441\u043e\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u0438 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 OBD \u0443\u0434\u0430\u043b\u0435\u043d\u044b"

    iput-object v3, v2, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v2}, Lc/T5;->q()V

    goto :goto_0

    :cond_1
    iget v2, p0, Lc/M5;->a:I

    add-int/2addr v2, v1

    iput v2, p0, Lc/M5;->a:I

    if-ge v2, v3, :cond_2

    iget-object v2, p0, Lc/M5;->d:Lc/T5;

    iget-object v2, v2, Lc/T5;->c:Landroid/os/Handler;

    const-wide/16 v3, 0x3e8

    invoke-virtual {v2, p0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_2
    iget-object v2, p0, Lc/M5;->d:Lc/T5;

    iput-boolean v1, v2, Lc/T5;->I1:Z

    iput-object v0, v2, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v2}, Lc/T5;->q()V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    iget-object v2, p0, Lc/M5;->d:Lc/T5;

    iput-boolean v1, v2, Lc/T5;->I1:Z

    iput-object v0, v2, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v2}, Lc/T5;->q()V

    :goto_0
    return-void
.end method
