.class public final Lc/N7;
.super Landroid/widget/LinearLayout;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:I

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public final e:Landroid/widget/TextView;

.field public final f:Landroid/widget/TextView;

.field public final g:Landroid/widget/EditText;

.field public final h:Landroid/widget/ImageButton;

.field public final i:Lc/f1;

.field public final synthetic j:Lc/O7;


# direct methods
.method public constructor <init>(Lc/O7;)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lc/N7;->j:Lc/O7;

    iget-object v2, v1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    iput v2, v0, Lc/N7;->a:I

    const-string v3, ""

    iput-object v3, v0, Lc/N7;->c:Ljava/lang/String;

    iput-object v3, v0, Lc/N7;->d:Ljava/lang/String;

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0x12

    invoke-virtual {v1, v4}, Lc/O7;->g(I)I

    move-result v5

    invoke-virtual {v1, v4}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v1, v4}, Lc/O7;->g(I)I

    move-result v7

    invoke-virtual {v1, v4}, Lc/O7;->g(I)I

    move-result v4

    invoke-virtual {v0, v5, v6, v7, v4}, Landroid/view/View;->setPadding(IIII)V

    const-string v4, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b"

    const/16 v5, 0x17

    invoke-virtual {v1, v5, v4, v2}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    iput-object v4, v0, Lc/N7;->e:Landroid/widget/TextView;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x11

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, -0x1

    const/4 v9, -0x2

    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p1 .. p1}, Lc/O7;->p()Landroid/widget/LinearLayout;

    move-result-object v4

    const-string v7, "\u041f\u043e\u0438\u0441\u043a \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432"

    invoke-virtual {v1, v7, v2}, Lc/O7;->h(Ljava/lang/String;I)Landroid/widget/EditText;

    move-result-object v7

    iput-object v7, v0, Lc/N7;->g:Landroid/widget/EditText;

    const/high16 v10, 0x41700000    # 15.0f

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v10, v1, Lc/O7;->c:Lc/r4;

    iget v11, v10, Lc/r4;->e:I

    const v12, 0x7f03003e

    invoke-virtual {v1, v12, v11}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    const/4 v12, 0x0

    invoke-virtual {v7, v11, v12, v12, v12}, Landroid/widget/TextView;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v11, 0x6

    invoke-virtual {v1, v11}, Lc/O7;->g(I)I

    move-result v12

    invoke-virtual {v7, v12}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x30

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v14

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v12, v5, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v7, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v12, Lc/L7;

    const/4 v14, 0x0

    invoke-direct {v12, v0, v14}, Lc/L7;-><init>(Lc/N7;I)V

    const v14, 0x7f030043

    const-string v2, "\u0418\u043c\u043f\u043e\u0440\u0442 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432"

    invoke-virtual {v1, v14, v12, v2}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object v2

    iput-object v2, v0, Lc/N7;->h:Landroid/widget/ImageButton;

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v13

    invoke-direct {v12, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v11}, Lc/O7;->g(I)I

    move-result v11

    invoke-virtual {v12, v11}, Landroid/view/ViewGroup$MarginLayoutParams;->setMarginStart(I)V

    invoke-virtual {v4, v2, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0x10

    invoke-virtual {v1, v11}, Lc/O7;->g(I)I

    move-result v12

    iput v12, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v0, v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/FrameLayout;

    iget-object v4, v1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v2, v4}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v12, v8, v5, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual/range {p1 .. p1}, Lc/O7;->d()Landroid/widget/LinearLayout;

    move-result-object v12

    invoke-virtual {v12, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v13, 0x14

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v8

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v1, v13}, Lc/O7;->g(I)I

    move-result v13

    invoke-virtual {v12, v14, v8, v9, v13}, Landroid/view/View;->setPadding(IIII)V

    new-instance v8, Landroid/widget/ImageView;

    invoke-direct {v8, v4}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const v9, 0x7f030056

    iget v13, v10, Lc/r4;->e:I

    invoke-virtual {v1, v9, v13}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v14, 0x1

    invoke-virtual {v9, v14}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    iget v14, v10, Lc/r4;->c:I

    invoke-virtual {v9, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v9, 0xe

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v15

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v6

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v9

    invoke-virtual {v8, v14, v15, v6, v9}, Landroid/view/View;->setPadding(IIII)V

    const/4 v6, 0x2

    invoke-virtual {v8, v6}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x40

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v14

    invoke-virtual {v1, v9}, Lc/O7;->g(I)I

    move-result v9

    invoke-direct {v6, v14, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v8, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v1, v11, v3, v5}, Lc/O7;->t(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    iput-object v3, v0, Lc/N7;->f:Landroid/widget/TextView;

    invoke-virtual {v3, v13}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v5, 0x11

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v5, 0x3

    invoke-virtual {v1, v5}, Lc/O7;->g(I)I

    move-result v5

    int-to-float v5, v5

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-virtual {v3, v5, v6}, Landroid/widget/TextView;->setLineSpacing(FF)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v8, -0x2

    invoke-direct {v5, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v11}, Lc/O7;->g(I)I

    move-result v6

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v12, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/ListView;

    invoke-direct {v3, v4}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    new-instance v4, Landroid/graphics/drawable/ColorDrawable;

    iget-boolean v5, v10, Lc/r4;->m:Z

    if-eqz v5, :cond_0

    const v5, 0x3e2e147b    # 0.17f

    goto :goto_0

    :cond_0
    const v5, 0x3e6b851f    # 0.23f

    :goto_0
    iget v6, v10, Lc/r4;->d:I

    iget v8, v10, Lc/r4;->b:I

    invoke-static {v5, v8, v6}, Lc/k6;->m(FII)I

    move-result v5

    invoke-direct {v4, v5}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lc/O7;->g(I)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/widget/ListView;->setDividerHeight(I)V

    invoke-virtual {v3, v4}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    new-instance v4, Lc/f1;

    invoke-direct {v4, v1, v0}, Lc/f1;-><init>(Lc/O7;Lc/N7;)V

    iput-object v4, v0, Lc/N7;->i:Lc/f1;

    invoke-virtual {v3, v4}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v1, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v1, v4, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3, v12}, Landroid/widget/AdapterView;->setEmptyView(Landroid/view/View;)V

    new-instance v1, Lc/M7;

    invoke-direct {v1, v0}, Lc/M7;-><init>(Lc/N7;)V

    invoke-virtual {v3, v1}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    new-instance v1, Lc/L7;

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Lc/L7;-><init>(Lc/N7;I)V

    new-instance v2, Lc/D6;

    const/4 v3, 0x1

    invoke-direct {v2, v1, v3}, Lc/D6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 10

    iget-object v0, p0, Lc/N7;->j:Lc/O7;

    invoke-virtual {v0}, Lc/O7;->l()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/N7;->e:Landroid/widget/TextView;

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    iget v2, p0, Lc/N7;->a:I

    const/4 v3, 0x2

    if-nez v2, :cond_1

    const-string v2, "\u041d\u0435\u0434\u0430\u0432\u043d\u0438\u0435"

    goto :goto_0

    :cond_1
    if-ne v2, v3, :cond_2

    const-string v2, "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u044b\u0435"

    goto :goto_0

    :cond_2
    const-string v2, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b"

    :goto_0
    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc/N7;->h:Landroid/widget/ImageButton;

    iget v1, p0, Lc/N7;->a:I

    const/4 v2, 0x0

    const/4 v4, 0x1

    if-ne v1, v4, :cond_3

    move v1, v2

    goto :goto_1

    :cond_3
    const/16 v1, 0x8

    :goto_1
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, p0, Lc/N7;->h:Landroid/widget/ImageButton;

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->c()Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-boolean v1, v1, Lc/Z7;->q:Z

    if-nez v1, :cond_4

    move v2, v4

    :cond_4
    invoke-virtual {v0, v2}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p0, Lc/N7;->f:Landroid/widget/TextView;

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v2, v1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->c()Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u043f\u043e Bluetooth \u0434\u043b\u044f \u0437\u0432\u043e\u043d\u043a\u043e\u0432 \u0438 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432"

    goto :goto_2

    :cond_5
    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-boolean v1, v1, Lc/Z7;->q:Z

    if-eqz v1, :cond_6

    const-string v1, "\u0418\u043c\u043f\u043e\u0440\u0442 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432\u2026"

    goto :goto_2

    :cond_6
    iget v1, p0, Lc/N7;->a:I

    if-nez v1, :cond_7

    const-string v1, "\u041d\u0435\u0434\u0430\u0432\u043d\u0438\u0445 \u0437\u0432\u043e\u043d\u043a\u043e\u0432 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442"

    goto :goto_2

    :cond_7
    if-ne v1, v3, :cond_8

    const-string v1, "\u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435"

    goto :goto_2

    :cond_8
    const-string v1, "\u0418\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d\u043d\u043e\u0433\u043e \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430"

    :goto_2
    invoke-static {v2, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "|"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lc/N7;->a:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/N7;->g:Landroid/widget/EditText;

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/N7;->j:Lc/O7;

    iget-object v2, v2, Lc/O7;->b:Lc/Z7;

    iget v2, v2, Lc/Z7;->D:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/N7;->j:Lc/O7;

    iget-object v2, v2, Lc/O7;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    iget v2, v2, Lc/e8;->e:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-boolean v1, v1, Lc/Z7;->q:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/N7;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    return-void

    :cond_9
    iput-object v0, p0, Lc/N7;->c:Ljava/lang/String;

    iget v0, p0, Lc/N7;->b:I

    add-int/2addr v0, v4

    iput v0, p0, Lc/N7;->b:I

    iget-object v1, p0, Lc/N7;->d:Ljava/lang/String;

    iget-object v2, p0, Lc/N7;->j:Lc/O7;

    iget-object v2, v2, Lc/O7;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    iget-object v2, v2, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    iget-object v1, p0, Lc/N7;->i:Lc/f1;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, Lc/f1;->c:Ljava/lang/Object;

    iget-object v1, p0, Lc/N7;->i:Lc/f1;

    invoke-virtual {v1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_a
    iget-object v1, p0, Lc/N7;->j:Lc/O7;

    iget-object v3, v1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v3, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    iput-object v1, p0, Lc/N7;->d:Ljava/lang/String;

    iget v5, p0, Lc/N7;->a:I

    iget-object v1, p0, Lc/N7;->g:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    new-instance v8, Lc/j2;

    const/4 v1, 0x2

    invoke-direct {v8, p0, v0, v1}, Lc/j2;-><init>(Landroid/view/ViewGroup;II)V

    iget-object v0, v3, Lc/Z7;->a:Lc/e8;

    iget-object v4, v0, Lc/e8;->a:Ljava/lang/String;

    iget v7, v3, Lc/Z7;->B:I

    iget-object v0, v3, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Lc/M0;

    const/4 v9, 0x2

    move-object v2, v1

    invoke-direct/range {v2 .. v9}, Lc/M0;-><init>(Ljava/lang/Object;Ljava/io/Serializable;ILjava/io/Serializable;ILjava/lang/Object;I)V

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
