.class public final synthetic Lc/t7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/v7;

.field public final synthetic b:J

.field public final synthetic c:Z

.field public final synthetic d:Lc/q2;

.field public final synthetic e:J

.field public final synthetic f:J


# direct methods
.method public synthetic constructor <init>(Lc/v7;JZLc/q2;JJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/t7;->a:Lc/v7;

    iput-wide p2, p0, Lc/t7;->b:J

    iput-boolean p4, p0, Lc/t7;->c:Z

    iput-object p5, p0, Lc/t7;->d:Lc/q2;

    iput-wide p6, p0, Lc/t7;->e:J

    iput-wide p8, p0, Lc/t7;->f:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 29

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/t7;->a:Lc/v7;

    iget-wide v2, v1, Lc/v7;->O:J

    iget-boolean v4, v1, Lc/v7;->N:Z

    iget-wide v5, v0, Lc/t7;->b:J

    cmp-long v2, v5, v2

    iget-object v3, v0, Lc/t7;->d:Lc/q2;

    iget-wide v7, v0, Lc/t7;->e:J

    if-nez v2, :cond_6

    iget-boolean v2, v0, Lc/t7;->c:Z

    if-ne v2, v4, :cond_6

    iget-boolean v4, v1, Lc/v7;->o:Z

    if-nez v4, :cond_6

    iget-boolean v4, v1, Lc/v7;->p:Z

    if-eqz v4, :cond_0

    goto/16 :goto_6

    :cond_0
    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    iget-object v12, v1, Lc/v7;->P:Ljava/lang/String;

    iget v4, v1, Lc/v7;->b:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    invoke-virtual {v1}, Lc/v7;->f()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v20

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v22

    if-eqz v2, :cond_1

    const-string v4, "shown"

    :goto_0
    move-object/from16 v24, v4

    goto :goto_1

    :cond_1
    const-string v4, "hidden"

    goto :goto_0

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    iget-wide v6, v0, Lc/t7;->f:J

    sub-long/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v26

    iget-object v4, v1, Lc/v7;->i:Landroid/view/View;

    if-eqz v4, :cond_3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "activity:"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v5, v1, Lc/v7;->i:Landroid/view/View;

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ":surface:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v1, Lc/v7;->j:Landroid/view/SurfaceView;

    if-nez v5, :cond_2

    const/4 v5, -0x1

    goto :goto_2

    :cond_2
    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    :goto_2
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_3
    move-object/from16 v28, v4

    goto :goto_4

    :cond_3
    iget-object v4, v1, Lc/v7;->h:Landroid/view/TextureView;

    if-eqz v4, :cond_4

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "texture:"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ":available:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Landroid/view/TextureView;->isAvailable()Z

    move-result v4

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_3

    :cond_4
    const-string v4, "missing"

    goto :goto_3

    :goto_4
    const-string v25, "duration_ms"

    const-string v27, "surface_state"

    const-string v9, "transition_id"

    const-string v11, "pane_id"

    const-string v13, "renderer_id"

    const-string v15, "renderer_generation"

    const-string v17, "renderer_type"

    iget-object v1, v1, Lc/v7;->c:Ljava/lang/String;

    move-object/from16 v18, v1

    const-string v19, "display_id"

    const-string v21, "active"

    const-string v23, "action"

    filled-new-array/range {v9 .. v28}, [Ljava/lang/Object;

    move-result-object v1

    const-string v4, "pane_presentation"

    invoke-static {v4, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    if-eqz v3, :cond_7

    if-eqz v2, :cond_5

    const/4 v1, 0x1

    goto :goto_5

    :cond_5
    const/4 v1, 0x2

    :goto_5
    invoke-virtual {v3, v1}, Lc/q2;->a(I)V

    goto :goto_7

    :cond_6
    :goto_6
    const/4 v4, 0x5

    const-string v9, "superseded"

    move-object v2, v3

    move v3, v4

    move-wide v4, v5

    move-wide v6, v7

    move-object v8, v9

    invoke-virtual/range {v1 .. v8}, Lc/v7;->d(Lc/q2;IJJLjava/lang/String;)V

    :cond_7
    :goto_7
    return-void
.end method
