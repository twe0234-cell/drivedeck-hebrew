.class public final Lc/b5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/Matrix;

.field public final c:[Landroid/graphics/Shader;

.field public final d:[I

.field public final e:[I

.field public final f:[I

.field public final g:[F

.field public h:Landroid/graphics/Bitmap;

.field public i:Landroid/graphics/Bitmap;

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:J

.field public p:Lc/r4;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/b5;->a:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Lc/b5;->b:Landroid/graphics/Matrix;

    new-array v0, v1, [Landroid/graphics/Shader;

    iput-object v0, p0, Lc/b5;->c:[Landroid/graphics/Shader;

    new-array v0, v1, [I

    iput-object v0, p0, Lc/b5;->d:[I

    new-array v0, v1, [I

    iput-object v0, p0, Lc/b5;->e:[I

    new-array v0, v1, [I

    iput-object v0, p0, Lc/b5;->f:[I

    new-array v0, v1, [F

    iput-object v0, p0, Lc/b5;->g:[F

    return-void
.end method

.method public static a(FII)I
    .locals 4

    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v1, p0

    mul-float/2addr v0, v1

    invoke-static {p2}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, p0

    add-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v1

    invoke-static {p2}, Landroid/graphics/Color;->green(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, p0

    add-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v1

    invoke-static {p2}, Landroid/graphics/Color;->blue(I)I

    move-result p2

    int-to-float p2, p2

    mul-float/2addr p2, p0

    add-float/2addr p2, p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-static {v0, v2, p0}, Landroid/graphics/Color;->rgb(III)I

    move-result p0

    return p0
.end method

.method public static c(I)Landroid/graphics/RadialGradient;
    .locals 8

    new-instance v7, Landroid/graphics/RadialGradient;

    const v0, 0xffffff

    and-int/2addr v0, p0

    const/high16 v1, -0x50000000

    or-int/2addr v1, v0

    filled-new-array {p0, v1, v0}, [I

    move-result-object v4

    const/4 p0, 0x3

    new-array v5, p0, [F

    fill-array-data v5, :array_0

    sget-object v6, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v2, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v1, 0x0

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    return-object v7

    :array_0
    .array-data 4
        0x0
        0x3eb33333    # 0.35f
        0x3f800000    # 1.0f
    .end array-data
.end method


# virtual methods
.method public final b(Landroid/graphics/Canvas;Landroid/graphics/RectF;F)V
    .locals 15

    move-object v0, p0

    move-object/from16 v1, p2

    const/high16 v2, 0x41e00000    # 28.0f

    mul-float v2, v2, p3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    const/4 v4, 0x1

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    iget-object v6, v0, Lc/b5;->i:Landroid/graphics/Bitmap;

    if-eqz v6, :cond_0

    iget v6, v0, Lc/b5;->k:I

    if-ne v6, v3, :cond_0

    iget v6, v0, Lc/b5;->l:I

    if-eq v6, v5, :cond_1

    :cond_0
    iput v3, v0, Lc/b5;->k:I

    iput v5, v0, Lc/b5;->l:I

    mul-int/lit8 v6, v2, 0x2

    add-int v7, v3, v6

    add-int/2addr v6, v5

    sget-object v8, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v7, v6, v8}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v6

    iput-object v6, v0, Lc/b5;->i:Landroid/graphics/Bitmap;

    new-instance v14, Landroid/graphics/Paint;

    invoke-direct {v14, v4}, Landroid/graphics/Paint;-><init>(I)V

    const/high16 v4, -0x1000000

    invoke-virtual {v14, v4}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v4, 0x41800000    # 16.0f

    mul-float v4, v4, p3

    const/high16 v6, 0x41000000    # 8.0f

    mul-float v6, v6, p3

    const/high16 v7, 0x50000000

    const/4 v8, 0x0

    invoke-virtual {v14, v4, v8, v6, v7}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    new-instance v7, Landroid/graphics/Canvas;

    iget-object v4, v0, Lc/b5;->i:Landroid/graphics/Bitmap;

    invoke-direct {v7, v4}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float v9, v2

    add-int/2addr v3, v2

    int-to-float v10, v3

    add-int/2addr v5, v2

    int-to-float v11, v5

    const/high16 v3, 0x41c00000    # 24.0f

    mul-float v13, p3, v3

    move v8, v9

    move v12, v13

    invoke-virtual/range {v7 .. v14}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    :cond_1
    iget-object v3, v0, Lc/b5;->a:Landroid/graphics/Paint;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/16 v4, 0xff

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    iget-object v4, v0, Lc/b5;->i:Landroid/graphics/Bitmap;

    iget v5, v1, Landroid/graphics/RectF;->left:F

    int-to-float v2, v2

    sub-float/2addr v5, v2

    iget v1, v1, Landroid/graphics/RectF;->top:F

    sub-float/2addr v1, v2

    move-object/from16 v2, p1

    invoke-virtual {v2, v4, v5, v1, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final d(JZ)F
    .locals 3

    const/high16 v0, 0x3f800000    # 1.0f

    if-eqz p3, :cond_0

    iget-wide v1, p0, Lc/b5;->o:J

    sub-long/2addr p1, v1

    long-to-float p1, p1

    const/high16 p2, 0x44af0000    # 1400.0f

    div-float/2addr p1, p2

    invoke-static {v0, p1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    :cond_0
    mul-float p1, v0, v0

    const/high16 p2, 0x40000000    # 2.0f

    mul-float/2addr v0, p2

    const/high16 p2, 0x40400000    # 3.0f

    sub-float/2addr p2, v0

    mul-float/2addr p2, p1

    return p2
.end method
