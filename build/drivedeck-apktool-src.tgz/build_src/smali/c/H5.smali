.class public final synthetic Lc/H5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/y5;
.implements Lc/n;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;I)V
    .locals 0

    iput p4, p0, Lc/H5;->a:I

    iput-object p1, p0, Lc/H5;->b:Ljava/lang/Object;

    iput p2, p0, Lc/H5;->c:I

    iput-object p3, p0, Lc/H5;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc/a;)V
    .locals 5

    iget-object v0, p0, Lc/H5;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H5;->d:Ljava/lang/Object;

    check-cast v1, Lc/n1;

    iget v2, p0, Lc/H5;->c:I

    if-nez v2, :cond_0

    invoke-virtual {v1}, Lc/n1;->F()Ljava/lang/String;

    move-result-object v3

    goto :goto_0

    :cond_0
    invoke-virtual {v1}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v3

    :goto_0
    iget-object v4, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    iget-object v4, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v3, :cond_1

    const-string p1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u043e\u0442\u043a\u0440\u044b\u0442\u043e \u0432 \u0434\u0440\u0443\u0433\u043e\u043c \u043e\u043a\u043d\u0435"

    const/4 v0, 0x0

    invoke-static {v4, p1, v4, v0}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_2

    :cond_1
    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    if-nez v2, :cond_2

    invoke-virtual {v1, p1}, Lc/n1;->G0(Ljava/lang/String;)Z

    move-result p1

    goto :goto_1

    :cond_2
    invoke-virtual {v1, p1}, Lc/n1;->O0(Ljava/lang/String;)Z

    move-result p1

    :goto_1
    if-nez p1, :cond_3

    goto :goto_2

    :cond_3
    if-eqz v4, :cond_4

    invoke-virtual {v4}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_4
    invoke-virtual {v0}, Lc/k3;->X()V

    :goto_2
    return-void
.end method

.method public b(Lc/j6;Ljava/lang/String;)V
    .locals 4

    iget p2, p0, Lc/H5;->a:I

    packed-switch p2, :pswitch_data_0

    iget-object p2, p0, Lc/H5;->b:Ljava/lang/Object;

    check-cast p2, Lc/T5;

    iget v0, p0, Lc/H5;->c:I

    iget-object v1, p0, Lc/H5;->d:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget v2, p2, Lc/T5;->t:I

    if-ne v0, v2, :cond_1

    iget-object v0, p2, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_1

    iget-object v0, p2, Lc/T5;->h:Lc/j6;

    if-nez v0, :cond_1

    iget-object v0, p2, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "profile_id"

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    if-eqz p1, :cond_1

    iput-object p1, p2, Lc/T5;->h:Lc/j6;

    iget-object v0, p2, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v0, p1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object p1

    iput-object p1, p2, Lc/T5;->g:Lc/j6;

    invoke-virtual {p2}, Lc/T5;->A0()V

    invoke-virtual {p2}, Lc/T5;->q()V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-object p2, p0, Lc/H5;->b:Ljava/lang/Object;

    check-cast p2, Lc/T5;

    iget v0, p0, Lc/H5;->c:I

    iget-object v1, p0, Lc/H5;->d:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget v2, p2, Lc/T5;->t:I

    if-ne v0, v2, :cond_4

    iget-object v0, p2, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "profile_id"

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_2

    :cond_2
    if-eqz p1, :cond_3

    iput-object p1, p2, Lc/T5;->h:Lc/j6;

    iget-object v0, p2, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v0, p1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object p1

    iput-object p1, p2, Lc/T5;->g:Lc/j6;

    invoke-virtual {p2}, Lc/T5;->A0()V

    invoke-virtual {p2}, Lc/T5;->u0()V

    goto :goto_1

    :cond_3
    const-string p1, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0443\u0436\u043d\u043e \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0441\u043d\u043e\u0432\u0430"

    iput-object p1, p2, Lc/T5;->C1:Ljava/lang/String;

    :goto_1
    invoke-virtual {p2}, Lc/T5;->q()V

    :cond_4
    :goto_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
