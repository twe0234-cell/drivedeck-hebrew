.class public final synthetic Lc/p2;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/t2;

.field public final synthetic c:J

.field public final synthetic d:Lc/v7;

.field public final synthetic e:Lc/v7;


# direct methods
.method public synthetic constructor <init>(Lc/t2;JLc/v7;Lc/v7;I)V
    .locals 0

    iput p6, p0, Lc/p2;->a:I

    iput-object p1, p0, Lc/p2;->b:Lc/t2;

    iput-wide p2, p0, Lc/p2;->c:J

    iput-object p4, p0, Lc/p2;->d:Lc/v7;

    iput-object p5, p0, Lc/p2;->e:Lc/v7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
