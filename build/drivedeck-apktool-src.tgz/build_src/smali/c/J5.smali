.class public final synthetic Lc/J5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;IILc/p2;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/J5;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J5;->d:Ljava/lang/Object;

    iput p2, p0, Lc/J5;->b:I

    iput p3, p0, Lc/J5;->c:I

    iput-object p4, p0, Lc/J5;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/K5;Landroid/bluetooth/BluetoothGatt;II)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/J5;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J5;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/J5;->e:Ljava/lang/Object;

    iput p3, p0, Lc/J5;->b:I

    iput p4, p0, Lc/J5;->c:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lc/J5;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/J5;->d:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget v1, p0, Lc/J5;->b:I

    iget v2, p0, Lc/J5;->c:I

    :try_start_0
    invoke-static {v0, v1, v2}, Lc/j8;->z(Landroid/content/Context;II)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v0, 0x0

    :goto_0
    sget-object v2, Lc/j8;->b:Landroid/os/Handler;

    new-instance v3, Lc/H1;

    iget-object v4, p0, Lc/J5;->e:Ljava/lang/Object;

    check-cast v4, Lc/p2;

    const/4 v5, 0x5

    invoke-direct {v3, v4, v0, v1, v5}, Lc/H1;-><init>(Ljava/lang/Object;ZLjava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/J5;->d:Ljava/lang/Object;

    check-cast v0, Lc/K5;

    iget-object v0, v0, Lc/K5;->a:Lc/T5;

    iget-object v1, v0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v2, p0, Lc/J5;->e:Ljava/lang/Object;

    check-cast v2, Landroid/bluetooth/BluetoothGatt;

    if-eq v2, v1, :cond_0

    goto :goto_2

    :cond_0
    iget v1, p0, Lc/J5;->b:I

    if-nez v1, :cond_2

    iget v3, p0, Lc/J5;->c:I

    if-nez v3, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x2

    if-ne v3, v1, :cond_3

    const/4 v1, 0x0

    :try_start_1
    invoke-virtual {v2}, Landroid/bluetooth/BluetoothGatt;->discoverServices()Z

    move-result v2

    if-nez v2, :cond_3

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u0430\u0434\u0430\u043f\u0442\u0435\u0440"

    invoke-virtual {v0, v1, v2}, Lc/T5;->J(ZLjava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    const-string v2, "\u041d\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f Bluetooth"

    invoke-virtual {v0, v1, v2}, Lc/T5;->J(ZLjava/lang/String;)V

    goto :goto_2

    :cond_2
    :goto_1
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\u0421\u0432\u044f\u0437\u044c \u0441 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u043c \u043f\u043e\u0442\u0435\u0440\u044f\u043d\u0430 ("

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->Q0(Ljava/lang/String;)V

    :cond_3
    :goto_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
