.class public final Lc/N4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/N4;->a:I

    iput-object p1, p0, Lc/N4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-wide/32 v0, 0xea60

    const/4 v2, 0x0

    iget-object v3, p0, Lc/N4;->b:Lru/drivedeck/launcher/MainActivity;

    iget v4, p0, Lc/N4;->a:I

    packed-switch v4, :pswitch_data_0

    iget-object v4, v3, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    if-eqz v4, :cond_0

    new-instance v4, Lc/I4;

    const/4 v5, 0x3

    invoke-direct {v4, v3, v5}, Lc/I4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-static {v3, v4, v2, v2}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    invoke-static {v3}, Lru/drivedeck/launcher/MainActivity;->a(Lru/drivedeck/launcher/MainActivity;)V

    :cond_0
    iget-object v2, v3, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :pswitch_0
    invoke-virtual {v3}, Landroid/app/Activity;->isFinishing()Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual {v3}, Landroid/app/Activity;->isDestroyed()Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_0

    :cond_1
    iget-object v4, v3, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v5, Lc/R4;

    invoke-direct {v5, v3}, Lc/R4;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    sget-object v6, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-virtual {v3}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v6

    invoke-static {v3, v4, v2, v6, v5}, Lc/c9;->a(Landroid/content/Context;Lc/n1;ZLandroid/view/View;Lc/a9;)V

    iget-object v2, v3, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    invoke-virtual {v2, p0, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
