.class public final Lc/I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public a:Z

.field public final synthetic b:I

.field public final synthetic c:Ljava/util/function/BooleanSupplier;

.field public final synthetic d:Landroid/content/Context;

.field public final synthetic e:I

.field public final synthetic f:Lc/H;


# direct methods
.method public constructor <init>(ILjava/util/function/BooleanSupplier;Landroid/content/Context;ILc/H;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/I;->b:I

    iput-object p2, p0, Lc/I;->c:Ljava/util/function/BooleanSupplier;

    iput-object p3, p0, Lc/I;->d:Landroid/content/Context;

    iput p4, p0, Lc/I;->e:I

    iput-object p5, p0, Lc/I;->f:Lc/H;

    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 9

    iget-boolean p1, p0, Lc/I;->a:Z

    if-eqz p1, :cond_0

    return-void

    :cond_0
    sget-object p1, Lc/J;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    iget v0, p0, Lc/I;->b:I

    if-ne v0, p1, :cond_2

    iget-object v4, p0, Lc/I;->c:Ljava/util/function/BooleanSupplier;

    invoke-interface {v4}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    iget p1, p0, Lc/I;->e:I

    invoke-static {p2, p1}, Lc/J;->a(Landroid/os/IBinder;I)V

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Lc/S7;

    iget-object v7, p0, Lc/I;->d:Landroid/content/Context;

    iget-object v8, p0, Lc/I;->f:Lc/H;

    iget v3, p0, Lc/I;->b:I

    iget v6, p0, Lc/I;->e:I

    move-object v1, v0

    move-object v2, p0

    move-object v5, p2

    invoke-direct/range {v1 .. v8}, Lc/S7;-><init>(Lc/I;ILjava/util/function/BooleanSupplier;Landroid/os/IBinder;ILandroid/content/Context;Lc/H;)V

    const-wide/16 v1, 0x12c

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_2
    :goto_0
    iget-object p1, p0, Lc/I;->d:Landroid/content/Context;

    iget-boolean p2, p0, Lc/I;->a:Z

    if-eqz p2, :cond_3

    goto :goto_1

    :cond_3
    const/4 p2, 0x1

    iput-boolean p2, p0, Lc/I;->a:Z

    :try_start_0
    invoke-virtual {p1, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_1
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    iget-boolean p1, p0, Lc/I;->a:Z

    const/4 v0, 0x1

    if-nez p1, :cond_0

    sget-object p1, Lc/J;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p1

    iget v1, p0, Lc/I;->b:I

    if-ne v1, p1, :cond_0

    iget-object p1, p0, Lc/I;->c:Ljava/util/function/BooleanSupplier;

    invoke-interface {p1}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result p1

    if-eqz p1, :cond_0

    move p1, v0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget-object v1, p0, Lc/I;->d:Landroid/content/Context;

    iget-boolean v2, p0, Lc/I;->a:Z

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    iput-boolean v0, p0, Lc/I;->a:Z

    :try_start_0
    invoke-virtual {v1, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_1
    if-eqz p1, :cond_2

    iget-object p1, p0, Lc/I;->f:Lc/H;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lc/H;->run()V

    :cond_2
    return-void
.end method
