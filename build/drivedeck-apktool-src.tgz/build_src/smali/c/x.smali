.class public final synthetic Lc/x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;I)V
    .locals 0

    .line 1
    iput p4, p0, Lc/x;->a:I

    iput-object p1, p0, Lc/x;->c:Ljava/lang/Object;

    iput p2, p0, Lc/x;->b:I

    iput-object p3, p0, Lc/x;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;II)V
    .locals 0

    .line 2
    iput p4, p0, Lc/x;->a:I

    iput-object p1, p0, Lc/x;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/x;->d:Ljava/lang/Object;

    iput p3, p0, Lc/x;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v3, p0, Lc/x;->a:I

    packed-switch v3, :pswitch_data_0

    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/d8;

    iget-object v2, v0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_0

    iget-object v2, v0, Lc/d8;->l:Ljava/lang/String;

    iget-object v3, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, v0, Lc/d8;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    iget v2, v2, Lc/e8;->e:I

    iget v3, p0, Lc/x;->b:I

    if-ne v2, v3, :cond_0

    iput-boolean v1, v0, Lc/d8;->n:Z

    invoke-virtual {v0}, Lc/d8;->j()V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/d6;

    iget v1, p0, Lc/x;->b:I

    iget-object v2, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Exception;

    iget-object v3, v0, Lc/d6;->a:Ljava/lang/Object;

    check-cast v3, Lc/T5;

    iget v3, v3, Lc/T5;->t:I

    if-ne v1, v3, :cond_1

    iget-object v0, v0, Lc/d6;->a:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    const-string v1, "\u0421\u0432\u044f\u0437\u044c SPP \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"

    invoke-static {v0, v1, v2}, Lc/T5;->b(Lc/T5;Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_1
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/d6;

    iget v1, p0, Lc/x;->b:I

    iget-object v2, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v2, Ljava/io/IOException;

    iget-object v3, v0, Lc/d6;->a:Ljava/lang/Object;

    check-cast v3, Lc/T5;

    iget v3, v3, Lc/T5;->t:I

    if-ne v1, v3, :cond_2

    iget-object v0, v0, Lc/d6;->a:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u043f\u043e\u0442\u043e\u043a SPP"

    invoke-static {v0, v1, v2}, Lc/T5;->b(Lc/T5;Ljava/lang/String;Ljava/lang/Exception;)V

    :cond_2
    return-void

    :pswitch_2
    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/K5;

    iget-object v0, v0, Lc/K5;->a:Lc/T5;

    iget-object v3, v0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v4, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v4, Landroid/bluetooth/BluetoothGatt;

    if-eq v4, v3, :cond_3

    goto/16 :goto_5

    :cond_3
    iget-object v3, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v5, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v3, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget v3, p0, Lc/x;->b:I

    if-eqz v3, :cond_4

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u0442\u044c \u043a\u0430\u043d\u0430\u043b\u044b BLE"

    invoke-virtual {v0, v1, v2}, Lc/T5;->J(ZLjava/lang/String;)V

    goto/16 :goto_5

    :cond_4
    iget-object v3, v0, Lc/T5;->N1:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    iput v1, v0, Lc/T5;->O1:I

    invoke-virtual {v4}, Landroid/bluetooth/BluetoothGatt;->getServices()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_c

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/bluetooth/BluetoothGattService;

    invoke-virtual {v5}, Landroid/bluetooth/BluetoothGattService;->getCharacteristics()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v7

    new-array v8, v7, [Ljava/util/UUID;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v9

    new-array v10, v9, [I

    move v11, v1

    :goto_1
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v12

    if-ge v11, v12, :cond_5

    invoke-interface {v6, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v12}, Landroid/bluetooth/BluetoothGattCharacteristic;->getUuid()Ljava/util/UUID;

    move-result-object v12

    aput-object v12, v8, v11

    invoke-interface {v6, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v12}, Landroid/bluetooth/BluetoothGattCharacteristic;->getProperties()I

    move-result v12

    aput v12, v10, v11

    add-int/2addr v11, v2

    goto :goto_1

    :cond_5
    invoke-virtual {v5}, Landroid/bluetooth/BluetoothGattService;->getUuid()Ljava/util/UUID;

    move-result-object v5

    sget-object v6, Lc/t5;->d:Ljava/util/UUID;

    if-eqz v5, :cond_b

    if-ne v7, v9, :cond_b

    move v6, v1

    :goto_2
    if-ge v6, v7, :cond_7

    aget-object v9, v8, v6

    if-eqz v9, :cond_6

    add-int/2addr v6, v2

    goto :goto_2

    :cond_6
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Missing characteristic UUID"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    move v9, v1

    :goto_3
    if-ge v9, v7, :cond_a

    aget v11, v10, v9

    and-int/lit8 v11, v11, 0x30

    if-eqz v11, :cond_9

    move v11, v1

    :goto_4
    if-ge v11, v7, :cond_9

    aget v12, v10, v11

    and-int/lit8 v12, v12, 0xc

    if-eqz v12, :cond_8

    new-instance v12, Lc/t5;

    aget-object v13, v8, v9

    aget-object v14, v8, v11

    invoke-direct {v12, v5, v13, v14}, Lc/t5;-><init>(Ljava/util/UUID;Ljava/util/UUID;Ljava/util/UUID;)V

    invoke-virtual {v6, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_8
    add-int/2addr v11, v2

    goto :goto_4

    :cond_9
    add-int/2addr v9, v2

    goto :goto_3

    :cond_a
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto/16 :goto_0

    :cond_b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Invalid BLE service"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    invoke-virtual {v0}, Lc/T5;->a0()V

    :goto_5
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget-object v3, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v3, Lc/N6;

    iget v4, p0, Lc/x;->b:I

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v5, v0, Lc/T5;->a:Landroid/content/Context;

    const-class v6, Landroid/net/ConnectivityManager;

    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/net/ConnectivityManager;

    iget-object v6, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v7, "wifi_bind"

    invoke-interface {v6, v7, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_e

    if-eqz v5, :cond_e

    invoke-virtual {v5}, Landroid/net/ConnectivityManager;->getAllNetworks()[Landroid/net/Network;

    move-result-object v6

    array-length v7, v6

    move v8, v1

    :goto_6
    if-ge v8, v7, :cond_e

    aget-object v9, v6, v8

    invoke-virtual {v5, v9}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v10

    if-eqz v10, :cond_d

    invoke-virtual {v10, v2}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v10

    if-nez v10, :cond_f

    goto :goto_7

    :catch_0
    move-exception v2

    goto :goto_9

    :catch_1
    move-exception v2

    goto :goto_9

    :cond_d
    :goto_7
    add-int/2addr v8, v2

    goto :goto_6

    :cond_e
    const/4 v9, 0x0

    :cond_f
    iget-object v2, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v5, "address"

    const-string v6, ""

    invoke-interface {v2, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v9}, Lc/N6;->a(Ljava/lang/String;Landroid/net/Network;)V

    iget v2, v0, Lc/T5;->t:I

    if-ne v4, v2, :cond_11

    iget-object v2, v0, Lc/T5;->L:Lc/N6;

    if-eq v2, v3, :cond_10

    goto :goto_8

    :cond_10
    invoke-virtual {v3}, Lc/N6;->b()Ljava/io/InputStream;

    move-result-object v2

    invoke-virtual {v3}, Lc/N6;->c()Ljava/io/OutputStream;

    move-result-object v5

    invoke-virtual {v0, v2, v5, v4}, Lc/T5;->K0(Ljava/io/InputStream;Ljava/io/OutputStream;I)V

    goto :goto_a

    :cond_11
    :goto_8
    invoke-virtual {v3}, Lc/N6;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_a

    :goto_9
    invoke-virtual {v3}, Lc/N6;->close()V

    iget-object v3, v0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v5, Lc/G5;

    invoke-direct {v5, v0, v4, v2, v1}, Lc/G5;-><init>(Lc/T5;ILjava/lang/Exception;I)V

    invoke-virtual {v3, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_a
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget v1, p0, Lc/x;->b:I

    iget-object v2, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget v3, v0, Lc/T5;->t:I

    if-ne v1, v3, :cond_12

    iget-object v1, v0, Lc/T5;->H0:Lc/e6;

    if-eqz v1, :cond_12

    iget-object v1, v0, Lc/T5;->a2:Ljava/lang/String;

    if-nez v1, :cond_12

    invoke-virtual {v0, v2}, Lc/T5;->O0(Ljava/lang/String;)V

    :cond_12
    return-void

    :pswitch_5
    filled-new-array {v1, v2}, [I

    move-result-object v3

    :goto_b
    if-ge v1, v0, :cond_13

    aget v4, v3, v1

    new-instance v5, Landroid/content/Intent;

    iget-object v6, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v6, Landroid/content/Intent;

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    new-instance v6, Landroid/view/KeyEvent;

    iget v7, p0, Lc/x;->b:I

    invoke-direct {v6, v4, v7}, Landroid/view/KeyEvent;-><init>(II)V

    const-string v4, "android.intent.extra.KEY_EVENT"

    invoke-virtual {v5, v4, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object v4

    iget-object v5, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v5, Landroid/content/Context;

    invoke-virtual {v5, v4}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    add-int/2addr v1, v2

    goto :goto_b

    :cond_13
    return-void

    :pswitch_6
    iget-object v3, p0, Lc/x;->c:Ljava/lang/Object;

    check-cast v3, Lc/z;

    iput-boolean v1, v3, Lc/z;->g:Z

    iget v1, v3, Lc/z;->h:I

    iget v4, p0, Lc/x;->b:I

    if-ne v4, v1, :cond_15

    iget-object v1, v3, Lc/z;->c:Ljava/util/List;

    if-nez v1, :cond_15

    iget-object v1, p0, Lc/x;->d:Ljava/lang/Object;

    check-cast v1, Lc/z;

    iget-object v4, v1, Lc/z;->c:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_14

    iget-object v4, v3, Lc/z;->d:Ljava/util/HashMap;

    invoke-virtual {v4}, Ljava/util/HashMap;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_14

    iget-object v4, v1, Lc/z;->d:Ljava/util/HashMap;

    iget-object v5, v3, Lc/z;->d:Ljava/util/HashMap;

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->putAll(Ljava/util/Map;)V

    :cond_14
    new-instance v4, Ljava/util/ArrayList;

    iget-object v5, v1, Lc/z;->d:Ljava/util/HashMap;

    invoke-virtual {v5}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v4, v3, Lc/z;->c:Ljava/util/List;

    new-instance v5, Lc/v;

    invoke-direct {v5, v0}, Lc/v;-><init>(I)V

    invoke-static {v5}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    iget-object v0, v1, Lc/z;->d:Ljava/util/HashMap;

    iput-object v0, v3, Lc/z;->d:Ljava/util/HashMap;

    iget-object v0, v1, Lc/z;->j:Lc/Y3;

    iput-object v0, v3, Lc/z;->j:Lc/Y3;

    iput-boolean v2, v3, Lc/z;->f:Z

    iget-object v0, v3, Lc/z;->e:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    :cond_15
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, v3, Lc/z;->i:Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_c

    :cond_16
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
