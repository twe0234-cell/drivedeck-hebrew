.class public final synthetic Lc/d9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field public final synthetic a:Lc/g9;


# direct methods
.method public synthetic constructor <init>(Lc/g9;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/d9;->a:Lc/g9;

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .locals 16

    move-object/from16 v0, p1

    const-string v1, "error"

    move-object/from16 v2, p0

    iget-object v3, v2, Lc/d9;->a:Lc/g9;

    iget-boolean v4, v3, Lc/g9;->m:Z

    if-nez v4, :cond_12

    iget-boolean v4, v3, Lc/g9;->k:Z

    if-eqz v4, :cond_12

    iget-object v4, v3, Lc/g9;->j:Landroid/os/Messenger;

    if-eqz v4, :cond_12

    invoke-virtual {v3}, Lc/g9;->a()Z

    move-result v4

    if-eqz v4, :cond_12

    iget v4, v0, Landroid/os/Message;->sendingUid:I

    iget v5, v3, Lc/g9;->r:I

    if-ne v4, v5, :cond_12

    iget v4, v0, Landroid/os/Message;->arg2:I

    const/4 v5, 0x3

    if-eq v4, v5, :cond_0

    goto/16 :goto_1

    :cond_0
    :try_start_0
    invoke-virtual/range {p1 .. p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v4

    const-string v6, "session"

    const-wide/16 v7, -0x1

    invoke-virtual {v4, v6, v7, v8}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    move-result-wide v6

    iget-wide v8, v3, Lc/g9;->s:J

    cmp-long v4, v6, v8

    if-eqz v4, :cond_1

    goto/16 :goto_1

    :cond_1
    iget v4, v0, Landroid/os/Message;->what:I
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v6, v3, Lc/g9;->u:Landroid/os/Handler;

    const/4 v7, 0x5

    const-string v8, "recognizing"

    const-string v9, "state"

    const/16 v10, 0x1f

    iget-object v11, v3, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v12, ""

    const/4 v13, 0x0

    if-ne v4, v7, :cond_4

    :try_start_1
    iget v4, v0, Landroid/os/Message;->arg1:I

    invoke-static {v4}, Ld/a;->e(I)Z

    move-result v4

    if-eqz v4, :cond_4

    iget v1, v0, Landroid/os/Message;->arg1:I

    invoke-static {v1}, Ld/a;->c(I)Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {v11}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2

    goto/16 :goto_1

    :cond_2
    iget v1, v0, Landroid/os/Message;->arg1:I

    invoke-static {v1}, Ld/a;->a(I)I

    move-result v1

    if-ltz v1, :cond_3

    iget v1, v3, Lc/g9;->g:I

    if-ne v1, v10, :cond_12

    iget-object v1, v3, Lc/g9;->f:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_12

    iget-object v1, v3, Lc/g9;->f:Ljava/lang/String;

    invoke-virtual/range {p1 .. p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v4

    invoke-virtual {v4, v9, v12}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_12

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    iget-wide v9, v3, Lc/g9;->h:J
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    cmp-long v1, v4, v9

    if-lez v1, :cond_3

    goto/16 :goto_1

    :cond_3
    iget-object v1, v3, Lc/g9;->y:Lc/e9;

    :try_start_2
    invoke-virtual {v6, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v13, v3, Lc/g9;->o:Z

    invoke-virtual {v3, v8}, Lc/g9;->o(Ljava/lang/String;)V

    const-wide/16 v4, 0x2bc

    invoke-virtual {v6, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v1, v3, Lc/g9;->c:Lc/x3;

    iget v0, v0, Landroid/os/Message;->arg1:I

    invoke-virtual {v1, v0}, Lc/x3;->accept(I)V

    goto/16 :goto_1

    :cond_4
    iget v4, v0, Landroid/os/Message;->what:I
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v7, 0x7

    const/4 v14, 0x6

    iget-object v15, v3, Lc/g9;->b:Lc/n1;

    iget-object v5, v3, Lc/g9;->e:Lc/u4;

    if-eq v4, v14, :cond_5

    if-ne v4, v7, :cond_a

    :cond_5
    :try_start_3
    invoke-static {v11}, Lc/g9;->k(Landroid/app/Activity;)Z

    move-result v4

    if-eqz v4, :cond_a

    iget v4, v0, Landroid/os/Message;->arg1:I

    const/16 v13, 0x1e

    if-eq v4, v13, :cond_6

    if-ne v4, v10, :cond_a

    :cond_6
    invoke-virtual/range {p1 .. p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v1

    invoke-virtual {v1, v9, v12}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ld/a;->i(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_12

    iget v4, v0, Landroid/os/Message;->arg1:I

    if-ne v4, v10, :cond_7

    invoke-static {v11}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result v4

    if-eqz v4, :cond_12

    invoke-virtual {v15}, Lc/n1;->q0()Z

    move-result v4

    if-eqz v4, :cond_12

    invoke-static {v11}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v4

    if-nez v4, :cond_7

    goto/16 :goto_1

    :cond_7
    iget v4, v0, Landroid/os/Message;->arg1:I

    if-ne v4, v13, :cond_8

    iget v0, v0, Landroid/os/Message;->what:I

    if-ne v0, v7, :cond_12

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v5, v0, v1}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_8
    iget v6, v0, Landroid/os/Message;->what:I

    if-ne v6, v14, :cond_9

    iput-object v1, v3, Lc/g9;->f:Ljava/lang/String;

    iput v4, v3, Lc/g9;->g:I

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    const-wide/16 v8, 0x2ee0

    add-long/2addr v6, v8

    iput-wide v6, v3, Lc/g9;->h:J

    const-string v0, "call_lookup"

    invoke-virtual {v3, v0}, Lc/g9;->o(Ljava/lang/String;)V

    iget v0, v3, Lc/g9;->g:I

    neg-int v0, v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v5, v0, v1}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_9
    iget v6, v3, Lc/g9;->g:I

    iget-object v7, v3, Lc/g9;->f:Ljava/lang/String;

    iget-wide v8, v3, Lc/g9;->h:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v13

    if-ne v4, v10, :cond_12

    if-ne v4, v6, :cond_12

    invoke-static {v1}, Ld/a;->i(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_12

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_12

    const-wide/16 v6, 0x0

    cmp-long v4, v8, v6

    if-lez v4, :cond_12

    cmp-long v4, v13, v8

    if-gtz v4, :cond_12

    iput-object v12, v3, Lc/g9;->f:Ljava/lang/String;

    const/4 v4, 0x0

    iput v4, v3, Lc/g9;->g:I

    iget v0, v0, Landroid/os/Message;->arg1:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v5, v0, v1}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_a
    iget v4, v0, Landroid/os/Message;->what:I

    const/4 v7, 0x3

    if-ne v4, v7, :cond_12

    invoke-virtual/range {p1 .. p1}, Landroid/os/Message;->getData()Landroid/os/Bundle;

    move-result-object v4

    invoke-virtual {v4, v9, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iput-object v12, v3, Lc/g9;->f:Ljava/lang/String;

    const/4 v7, 0x0

    iput v7, v3, Lc/g9;->g:I

    const-string v7, "music_query"

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_11

    invoke-virtual {v15}, Lc/n1;->q0()Z

    move-result v7

    if-eqz v7, :cond_b

    const-string v7, "call_query"

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_b

    goto :goto_0

    :cond_b
    const-string v0, "disabled"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v0, v15, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "voice_enabled"

    const/4 v4, 0x0

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-boolean v0, v3, Lc/g9;->n:Z

    invoke-virtual {v3, v0}, Lc/g9;->q(Z)V

    goto :goto_1

    :cond_c
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-virtual {v3}, Lc/g9;->e()V

    goto :goto_1

    :cond_d
    iget-boolean v0, v3, Lc/g9;->n:Z

    const-string v1, "starting"

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_0

    const-string v5, "paused"

    const-string v7, "listening"

    if-nez v1, :cond_e

    :try_start_4
    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    if-eqz v0, :cond_12

    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    :cond_e
    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    :cond_f
    const/16 v0, 0x3e8

    iput v0, v3, Lc/g9;->w:I

    iget-object v0, v3, Lc/g9;->x:Lc/e9;

    invoke-virtual {v6, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_10
    invoke-virtual {v3, v4}, Lc/g9;->o(Ljava/lang/String;)V

    goto :goto_1

    :cond_11
    :goto_0
    invoke-virtual {v3, v4}, Lc/g9;->o(Ljava/lang/String;)V

    iget v0, v0, Landroid/os/Message;->arg1:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v5, v0, v12}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_1

    :catch_0
    invoke-virtual {v3}, Lc/g9;->e()V

    :cond_12
    :goto_1
    const/4 v0, 0x1

    return v0
.end method
