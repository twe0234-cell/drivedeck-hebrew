.class public final synthetic Lc/f0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/n;


# instance fields
.field public final synthetic a:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, Lc/f0;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc/a;)V
    .locals 4

    iget-object v0, p0, Lc/f0;->a:Ljava/lang/Object;

    check-cast v0, Lc/g0;

    iget-object v1, v0, Lc/g0;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->U()Ljava/util/ArrayList;

    move-result-object v2

    iput-object v2, v0, Lc/g0;->h:Ljava/util/ArrayList;

    iget-object v3, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    iget-object v2, v0, Lc/g0;->h:Ljava/util/ArrayList;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, v0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Lc/n1;->W0(Ljava/util/ArrayList;)V

    :cond_0
    iget-object p1, v0, Lc/g0;->a:Lc/P3;

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    return-void
.end method
