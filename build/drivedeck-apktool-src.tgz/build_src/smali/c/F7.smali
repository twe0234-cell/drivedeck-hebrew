.class public final synthetic Lc/F7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/F7;->a:I

    iput-object p1, p0, Lc/F7;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/F7;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/F7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/w7;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const-string v2, "action.hicar.onconnect"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v0, v0, Lc/w7;->b:Ljava/lang/Object;

    check-cast v0, Lc/C8;

    iput-boolean v1, v0, Lc/C8;->l:Z

    const/4 v2, 0x0

    iput-boolean v2, v0, Lc/C8;->j:Z

    if-nez v1, :cond_0

    iget-object v0, v0, Lc/C8;->c:Lc/P7;

    invoke-virtual {v0}, Lc/P7;->run()V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/C8;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Runnable;

    iget-boolean v0, v0, Lc/C8;->m:Z

    if-nez v0, :cond_1

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    :cond_1
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/t8;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    move-object v3, v1

    check-cast v3, Landroid/view/View;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_6

    move-object v1, v3

    check-cast v1, Lc/s8;

    check-cast v1, Lc/t2;

    invoke-virtual {v1}, Lc/t2;->Y()Z

    move-result v2

    if-nez v2, :cond_2

    goto/16 :goto_0

    :cond_2
    new-instance v5, Landroid/graphics/Rect;

    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v3, v5}, Landroid/view/View;->getLocalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v2

    if-nez v2, :cond_3

    goto/16 :goto_0

    :cond_3
    new-instance v8, Lc/r8;

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    move-object v2, v8

    invoke-direct/range {v2 .. v7}, Lc/r8;-><init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    iput-object v8, v0, Lc/t8;->b:Lc/r8;

    iput-object v8, v0, Lc/t8;->c:Lc/r8;

    iget-object v2, v0, Lc/t8;->j:Lc/p8;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Lc/i;

    const/16 v4, 0x11

    invoke-direct {v3, v2, v4}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1}, Lc/t2;->Y()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {v1}, Lc/t2;->y()I

    move-result v2

    iget-object v4, v1, Lc/t2;->u:Ljava/lang/String;

    const/4 v5, 0x0

    sput-object v5, Lc/m8;->c:Lc/r5;

    if-lez v2, :cond_4

    if-eqz v4, :cond_4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_4

    new-instance v5, Lc/n1;

    invoke-direct {v5, v2, v4, v3}, Lc/n1;-><init>(ILjava/lang/String;Ljava/lang/Object;)V

    :cond_4
    sput-object v5, Lc/m8;->b:Lc/n1;

    invoke-virtual {v1}, Lc/t2;->y()I

    move-result v2

    invoke-static {v2}, Lc/j8;->l(I)V

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v2

    if-nez v2, :cond_5

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0414\u043b\u044f \u0440\u0430\u043c\u043a\u0438 \u0432\u043d\u0443\u0442\u0440\u0438 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0441\u043b\u0443\u0436\u0431\u0443 DriveDeck \u0432 \u0441\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0445 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u044f\u0445"

    const/4 v3, 0x1

    invoke-static {v1, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    :cond_5
    iget-object v1, v0, Lc/t8;->j:Lc/p8;

    iget-object v2, v0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    iget-object v3, v0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v1, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    iget-object v1, v0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object v1

    iget-object v2, v0, Lc/t8;->j:Lc/p8;

    invoke-virtual {v1, v2}, Landroid/view/ViewOverlay;->add(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, v0, Lc/t8;->j:Lc/p8;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_6
    :goto_0
    return-void

    :pswitch_2
    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/n1;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    check-cast v1, Lc/r5;

    sget-object v2, Lc/m8;->b:Lc/n1;

    if-eq v0, v2, :cond_7

    goto :goto_1

    :cond_7
    sput-object v1, Lc/m8;->c:Lc/r5;

    iget-object v0, v0, Lc/n1;->c:Ljava/lang/Object;

    check-cast v0, Lc/i;

    invoke-virtual {v0}, Lc/i;->run()V

    :goto_1
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/function/Consumer;

    iget-boolean v0, v0, Lc/Z7;->r:Z

    if-nez v0, :cond_8

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    :cond_8
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/F7;->b:Ljava/lang/Object;

    check-cast v0, Lc/O7;

    iget-object v1, p0, Lc/F7;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/O7;->k(Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
