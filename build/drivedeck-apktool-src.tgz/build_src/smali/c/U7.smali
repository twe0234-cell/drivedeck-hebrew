.class public final synthetic Lc/U7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/Z7;

.field public final synthetic b:Ljava/util/List;

.field public final synthetic c:Z

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:I


# direct methods
.method public synthetic constructor <init>(Lc/Z7;Ljava/util/List;ZLjava/lang/String;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/U7;->a:Lc/Z7;

    iput-object p2, p0, Lc/U7;->b:Ljava/util/List;

    iput-boolean p3, p0, Lc/U7;->c:Z

    iput-object p4, p0, Lc/U7;->d:Ljava/lang/String;

    iput p5, p0, Lc/U7;->e:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget-object v1, p0, Lc/U7;->a:Lc/Z7;

    iget-object v0, p0, Lc/U7;->b:Ljava/util/List;

    iget-boolean v5, p0, Lc/U7;->c:Z

    iget-object v3, p0, Lc/U7;->d:Ljava/lang/String;

    iget v2, p0, Lc/U7;->e:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x0

    if-nez v5, :cond_0

    :try_start_0
    iget-object v0, v1, Lc/Z7;->b:Landroid/content/Context;

    invoke-static {v0, v3}, Lc/z7;->b(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    if-eqz v6, :cond_1

    :try_start_1
    new-instance v0, Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v6

    const-string v7, "mybtinfo"

    invoke-direct {v0, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0, v3}, Lc/z7;->c(Ljava/io/File;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_0
    :try_start_2
    iget-object v0, v1, Lc/Z7;->b:Landroid/content/Context;

    invoke-static {v0, v3}, Lc/z7;->b(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    :cond_1
    :goto_0
    iget-boolean v6, v1, Lc/Z7;->r:Z

    if-nez v6, :cond_2

    iget-boolean v6, v1, Lc/Z7;->q:Z

    if-eqz v6, :cond_2

    iget v6, v1, Lc/Z7;->B:I

    if-ne v2, v6, :cond_2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_2

    iget-object v6, v1, Lc/Z7;->e:Lc/z7;

    invoke-virtual {v6, v3, v0}, Lc/z7;->g(Ljava/lang/String;Ljava/util/List;)V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1

    const-string v0, ""

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    if-eqz v5, :cond_3

    :try_start_3
    const-string v0, "\u041f\u0440\u043e\u0448\u0438\u0432\u043a\u0430 \u043d\u0435 \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u0438\u043b\u0430 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d\u043d\u043e\u0433\u043e \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430"

    goto :goto_1

    :cond_3
    const-string v0, "\u041a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u043d\u0435 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u044b. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u043f\u0435\u0440\u0435\u0434\u0430\u0447\u0443 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u043e\u0432 \u043d\u0430 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0435 \u0438 \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0438\u043c\u043f\u043e\u0440\u0442"
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_1

    :goto_1
    move-object v6, v0

    goto :goto_2

    :catch_1
    const-string v0, "\u0414\u043e\u0441\u0442\u0443\u043f \u043a \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u043d\u043e\u0439 \u043a\u043d\u0438\u0433\u0435 Bluetooth \u043f\u043e\u043a\u0430 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    goto :goto_1

    :goto_2
    iget-object v7, v1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v8, Lc/V7;

    move-object v0, v8

    invoke-direct/range {v0 .. v6}, Lc/V7;-><init>(Lc/Z7;ILjava/lang/String;ZZLjava/lang/String;)V

    invoke-virtual {v7, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
