.class public final Lc/d8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lc/Z7;

.field public final c:Landroid/view/WindowManager;

.field public final d:Landroid/os/Handler;

.field public e:Landroid/widget/LinearLayout;

.field public f:Landroid/widget/LinearLayout;

.field public g:Lc/Q1;

.field public h:Landroid/widget/TextView;

.field public i:Landroid/widget/FrameLayout;

.field public j:Landroid/widget/Button;

.field public k:Landroid/widget/Button;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Z

.field public o:F

.field public p:F

.field public q:I

.field public r:I

.field public s:Z

.field public t:I


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/d8;->d:Landroid/os/Handler;

    const-string v0, ""

    iput-object v0, p0, Lc/d8;->l:Ljava/lang/String;

    iput-object v0, p0, Lc/d8;->m:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, Lc/d8;->t:I

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/d8;->a:Landroid/content/Context;

    iput-object p2, p0, Lc/d8;->b:Lc/Z7;

    const-class p2, Landroid/view/WindowManager;

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/view/WindowManager;

    iput-object p1, p0, Lc/d8;->c:Landroid/view/WindowManager;

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 6

    iget-boolean v0, p0, Lc/d8;->n:Z

    if-nez v0, :cond_4

    invoke-virtual {p0}, Lc/d8;->k()Z

    move-result v0

    if-eqz v0, :cond_4

    const/4 v0, 0x3

    iget-object v1, p0, Lc/d8;->b:Lc/Z7;

    if-eqz p1, :cond_0

    iget-object v2, v1, Lc/Z7;->a:Lc/e8;

    iget v2, v2, Lc/e8;->e:I

    if-ne v2, v0, :cond_4

    :cond_0
    iget-object v2, p0, Lc/d8;->l:Ljava/lang/String;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v1, Lc/Z7;->a:Lc/e8;

    iget-object v4, v4, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lc/Z7;->a:Lc/e8;

    iget-object v5, v4, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    iput-boolean v2, p0, Lc/d8;->n:Z

    invoke-virtual {p0}, Lc/d8;->j()V

    iget-object v2, p0, Lc/d8;->l:Ljava/lang/String;

    iget v3, v4, Lc/e8;->e:I

    new-instance v4, Lc/c8;

    invoke-direct {v4, p0, v2, v3}, Lc/c8;-><init>(Lc/d8;Ljava/lang/String;I)V

    if-eqz p1, :cond_2

    invoke-virtual {v1, v4}, Lc/Z7;->b(Ljava/util/function/Consumer;)V

    goto :goto_0

    :cond_2
    if-ne v3, v0, :cond_3

    invoke-virtual {v1, v4}, Lc/Z7;->o(Ljava/util/function/Consumer;)V

    goto :goto_0

    :cond_3
    invoke-virtual {v1, v4}, Lc/Z7;->j(Ljava/util/function/Consumer;)V

    :cond_4
    :goto_0
    return-void
.end method

.method public final b(Landroid/widget/Button;I)V
    .locals 4

    const/16 v0, 0x12

    const/16 v1, 0x16

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    const-string v0, "sans-serif-medium"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    iget-object v0, p0, Lc/d8;->a:Landroid/content/Context;

    invoke-virtual {v0, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p1}, Landroid/widget/TextView;->getTextColors()Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    const/16 v0, 0x18

    invoke-virtual {p0, v0}, Lc/d8;->e(I)I

    move-result v2

    invoke-virtual {p0, v0}, Lc/d8;->e(I)I

    move-result v0

    invoke-virtual {p2, v1, v1, v2, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawablesRelative(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 p2, 0x6

    invoke-virtual {p0, p2}, Lc/d8;->e(I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/16 p2, 0x10

    invoke-virtual {p0, p2}, Lc/d8;->e(I)I

    move-result v0

    const/16 v1, 0x8

    invoke-virtual {p0, v1}, Lc/d8;->e(I)I

    move-result v2

    invoke-virtual {p0, p2}, Lc/d8;->e(I)I

    move-result p2

    invoke-virtual {p0, v1}, Lc/d8;->e(I)I

    move-result v1

    invoke-virtual {p1, v0, v2, p2, v1}, Landroid/view/View;->setPadding(IIII)V

    return-void
.end method

.method public final c()I
    .locals 4

    const/16 v0, 0xb8

    invoke-virtual {p0, v0}, Lc/d8;->e(I)I

    move-result v0

    invoke-virtual {p0}, Lc/d8;->g()I

    move-result v1

    const/16 v2, 0x38

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v2

    sub-int/2addr v1, v2

    iget-object v2, p0, Lc/d8;->b:Lc/Z7;

    iget-object v2, v2, Lc/Z7;->a:Lc/e8;

    iget v2, v2, Lc/e8;->e:I

    const/4 v3, 0x3

    if-ne v2, v3, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    :goto_0
    div-int/2addr v1, v3

    const/4 v2, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    return v0
.end method

.method public final d()V
    .locals 6

    iget-object v0, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager$LayoutParams;

    iget-object v1, p0, Lc/d8;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v2, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v3, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v2, v3

    div-int/lit8 v2, v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v3}, Lc/d8;->e(I)I

    move-result v3

    sub-int/2addr v2, v3

    const/4 v3, 0x0

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    neg-int v3, v2

    iget v4, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/16 v2, 0xc

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v3

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v4

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    iget-object v5, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v5}, Landroid/view/View;->getHeight()I

    move-result v5

    sub-int/2addr v1, v5

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget v2, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    iget-object v1, p0, Lc/d8;->c:Landroid/view/WindowManager;

    iget-object v2, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-interface {v1, v2, v0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final e(I)I
    .locals 1

    int-to-float p1, p1

    iget-object v0, p0, Lc/d8;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final f()V
    .locals 3

    iget-object v0, p0, Lc/d8;->d:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const-string v0, ""

    iput-object v0, p0, Lc/d8;->m:Ljava/lang/String;

    iput-object v0, p0, Lc/d8;->l:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/d8;->n:Z

    iput v0, p0, Lc/d8;->t:I

    iget-object v0, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v0, p0, Lc/d8;->c:Landroid/view/WindowManager;

    iget-object v2, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-interface {v0, v2}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iput-object v1, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    iput-object v1, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    :cond_0
    return-void
.end method

.method public final g()I
    .locals 3

    iget-object v0, p0, Lc/d8;->b:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget v0, v0, Lc/e8;->e:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    const/16 v0, 0x280

    goto :goto_0

    :cond_0
    const/16 v0, 0x1e0

    :goto_0
    invoke-virtual {p0, v0}, Lc/d8;->e(I)I

    move-result v0

    iget-object v1, p0, Lc/d8;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v2, 0x28

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v2

    sub-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v1, 0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public final h()V
    .locals 5

    iget-object v0, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/d8;->f:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v0, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/d8;->f:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lc/d8;->g:Lc/Q1;

    sget-object v3, Lc/Q1;->a:Lc/Q1;

    const/4 v4, 0x0

    if-ne v2, v3, :cond_0

    move v2, v4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    :goto_0
    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    iget-object v0, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout$LayoutParams;

    iget-object v1, p0, Lc/d8;->g:Lc/Q1;

    const/16 v2, 0xc

    if-ne v1, v3, :cond_1

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v1

    goto :goto_1

    :cond_1
    move v1, v4

    :goto_1
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget-object v1, p0, Lc/d8;->g:Lc/Q1;

    sget-object v3, Lc/Q1;->b:Lc/Q1;

    if-ne v1, v3, :cond_2

    invoke-virtual {p0, v2}, Lc/d8;->e(I)I

    move-result v4

    :cond_2
    iput v4, v0, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    iget-object v1, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final i()I
    .locals 7

    iget-object v0, p0, Lc/d8;->b:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget v0, v0, Lc/e8;->e:I

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v3

    :goto_0
    iget-object v1, p0, Lc/d8;->h:Landroid/widget/TextView;

    if-nez v1, :cond_1

    move v1, v3

    goto :goto_1

    :cond_1
    invoke-virtual {v1}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1

    iget-object v4, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    float-to-double v4, v1

    invoke-static {v4, v5}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v4

    double-to-int v1, v4

    :goto_1
    iget-object v4, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-nez v4, :cond_2

    const/16 v4, 0x24

    invoke-virtual {p0, v4}, Lc/d8;->e(I)I

    move-result v4

    goto :goto_2

    :cond_2
    invoke-virtual {v4}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    iget-object v5, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    add-int/2addr v4, v5

    :goto_2
    invoke-virtual {p0}, Lc/d8;->c()I

    move-result v5

    const/4 v6, 0x2

    if-eqz v0, :cond_3

    move v2, v6

    :cond_3
    mul-int/2addr v5, v2

    add-int/2addr v5, v1

    add-int/2addr v5, v4

    const/16 v1, 0xc

    invoke-virtual {p0, v1}, Lc/d8;->e(I)I

    move-result v1

    add-int/2addr v1, v5

    if-eqz v0, :cond_4

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Lc/d8;->e(I)I

    move-result v3

    :cond_4
    add-int/2addr v1, v3

    invoke-virtual {p0, v6}, Lc/d8;->e(I)I

    move-result v0

    add-int/2addr v0, v1

    invoke-virtual {p0}, Lc/d8;->g()I

    move-result v1

    iget-object v2, p0, Lc/d8;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v3, 0x28

    invoke-virtual {p0, v3}, Lc/d8;->e(I)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    return v0
.end method

.method public final j()V
    .locals 12

    iget-object v0, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/d8;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->c:Ljava/lang/String;

    iget-object v2, p0, Lc/d8;->m:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    iget-object v3, p0, Lc/d8;->a:Landroid/content/Context;

    if-nez v2, :cond_1

    iget-object v1, p0, Lc/d8;->m:Ljava/lang/String;

    goto :goto_0

    :cond_1
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    const-string v1, "\u041d\u043e\u043c\u0435\u0440 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    invoke-static {v3, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_2
    :goto_0
    iget-object v2, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v2, :cond_3

    iget-object v2, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setSelected(Z)V

    iget-object v2, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v1, p0, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setSelected(Z)V

    :cond_3
    iget-object v1, p0, Lc/d8;->j:Landroid/widget/Button;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    iget v2, v0, Lc/e8;->e:I

    const/16 v6, 0x8

    const/4 v7, 0x3

    if-ne v2, v7, :cond_4

    move v2, v5

    goto :goto_1

    :cond_4
    move v2, v6

    :goto_1
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    iget-object v1, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/view/WindowManager$LayoutParams;

    new-instance v2, Lc/n1;

    invoke-direct {v2, v3}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lc/n1;->i()Lc/u0;

    move-result-object v2

    iget-object v8, p0, Lc/d8;->g:Lc/Q1;

    iget-object v2, v2, Lc/u0;->b:Ljava/lang/Object;

    check-cast v2, Lc/Q1;

    if-eq v8, v2, :cond_5

    iput-object v2, p0, Lc/d8;->g:Lc/Q1;

    invoke-virtual {p0}, Lc/d8;->h()V

    :cond_5
    invoke-virtual {p0}, Lc/d8;->i()I

    move-result v2

    const/16 v8, 0x10

    invoke-virtual {p0, v8}, Lc/d8;->e(I)I

    move-result v8

    add-int/2addr v8, v2

    iget v2, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    const/16 v9, 0x51

    if-ne v2, v8, :cond_6

    iget v2, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    if-eq v2, v9, :cond_7

    :cond_6
    iput v8, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    iput v9, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    iget-object v2, p0, Lc/d8;->i:Landroid/widget/FrameLayout;

    iget-object v8, p0, Lc/d8;->c:Landroid/view/WindowManager;

    invoke-interface {v8, v2, v1}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_7
    iget-object v1, p0, Lc/d8;->j:Landroid/widget/Button;

    iget-object v2, p0, Lc/d8;->k:Landroid/widget/Button;

    filled-new-array {v1, v2}, [Landroid/widget/Button;

    move-result-object v1

    move v2, v5

    :goto_2
    const/4 v8, 0x2

    if-ge v2, v8, :cond_9

    aget-object v8, v1, v2

    invoke-virtual {v8}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroid/widget/LinearLayout$LayoutParams;

    iget v10, v9, Landroid/widget/LinearLayout$LayoutParams;->width:I

    invoke-virtual {p0}, Lc/d8;->c()I

    move-result v11

    if-eq v10, v11, :cond_8

    invoke-virtual {p0}, Lc/d8;->c()I

    move-result v10

    iput v10, v9, Landroid/widget/LinearLayout$LayoutParams;->width:I

    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_8
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_9
    iget-object v1, p0, Lc/d8;->k:Landroid/widget/Button;

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Landroid/widget/LinearLayout$LayoutParams;

    iget-object v2, p0, Lc/d8;->j:Landroid/widget/Button;

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v2

    if-nez v2, :cond_a

    invoke-virtual {p0, v6}, Lc/d8;->e(I)I

    move-result v5

    :cond_a
    iput v5, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget-object v1, p0, Lc/d8;->f:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    iget-object v1, p0, Lc/d8;->e:Landroid/widget/LinearLayout;

    iget v0, v0, Lc/e8;->e:I

    if-ne v0, v7, :cond_b

    const-string v0, "\u0412\u0445\u043e\u0434\u044f\u0449\u0438\u0439 \u0437\u0432\u043e\u043d\u043e\u043a"

    goto :goto_3

    :cond_b
    if-ne v0, v8, :cond_c

    const-string v0, "\u0418\u0441\u0445\u043e\u0434\u044f\u0449\u0438\u0439 \u0437\u0432\u043e\u043d\u043e\u043a"

    goto :goto_3

    :cond_c
    const-string v0, "\u0420\u0430\u0437\u0433\u043e\u0432\u043e\u0440"

    :goto_3
    invoke-static {v3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v0, p0, Lc/d8;->j:Landroid/widget/Button;

    iget-boolean v1, p0, Lc/d8;->n:Z

    xor-int/2addr v1, v4

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p0, Lc/d8;->k:Landroid/widget/Button;

    iget-boolean v1, p0, Lc/d8;->n:Z

    xor-int/2addr v1, v4

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    return-void
.end method

.method public final k()Z
    .locals 2

    iget-object v0, p0, Lc/d8;->b:Lc/Z7;

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v1}, Lc/e8;->c()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->d()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
