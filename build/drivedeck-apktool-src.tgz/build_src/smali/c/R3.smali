.class public final synthetic Lc/R3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/util/function/Consumer;

.field public final synthetic c:Lc/W3;


# direct methods
.method public synthetic constructor <init>(Ljava/util/function/Consumer;Lc/W3;I)V
    .locals 0

    iput p3, p0, Lc/R3;->a:I

    iput-object p1, p0, Lc/R3;->b:Ljava/util/function/Consumer;

    iput-object p2, p0, Lc/R3;->c:Lc/W3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget v0, p0, Lc/R3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/R3;->b:Ljava/util/function/Consumer;

    iget-object v1, p0, Lc/R3;->c:Lc/W3;

    invoke-interface {v0, v1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/R3;->b:Ljava/util/function/Consumer;

    iget-object v1, p0, Lc/R3;->c:Lc/W3;

    invoke-interface {v0, v1}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
