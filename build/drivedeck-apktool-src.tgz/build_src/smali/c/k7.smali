.class public final Lc/k7;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final u:[Ljava/lang/String;

.field public static final v:[Ljava/lang/String;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/util/ArrayDeque;

.field public final e:Ljava/io/ByteArrayOutputStream;

.field public f:Lc/j7;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:[B

.field public k:[B

.field public l:[B

.field public m:I

.field public n:I

.field public o:I

.field public p:I

.field public q:Z

.field public r:Z

.field public s:Z

.field public t:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string v0, "ATSP6"

    const-string v1, "ATCM000"

    const-string v2, "ATCAF0"

    const-string v3, "ATV1"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/k7;->u:[Ljava/lang/String;

    const-string v0, "ATV0"

    const-string v1, "ATAR"

    const-string v2, "ATSPDEF"

    const-string v3, "ATCAF1"

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/k7;->v:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lc/k7;->d:Ljava/util/ArrayDeque;

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iput-object v0, p0, Lc/k7;->e:Ljava/io/ByteArrayOutputStream;

    const-string v0, ""

    iput-object v0, p0, Lc/k7;->h:Ljava/lang/String;

    iput-object v0, p0, Lc/k7;->i:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p0, Lc/k7;->n:I

    iput v0, p0, Lc/k7;->o:I

    if-eqz p1, :cond_0

    const-string v0, "[0-9A-Fa-f]{2}"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const/16 v1, 0x300

    if-lt p2, v1, :cond_0

    const/16 v1, 0x3ff

    if-gt p2, v1, :cond_0

    const-string v1, "64"

    invoke-virtual {v1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/k7;->a:Ljava/lang/String;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string p2, "%03X"

    invoke-static {v0, p2, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/k7;->b:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/k7;->c:Ljava/lang/String;

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "VWTP channel"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static e([B)Ljava/lang/String;
    .locals 6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%02X"

    invoke-static {v4, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static i(I)V
    .locals 1

    if-ltz p0, :cond_0

    const/16 v0, 0xff

    if-gt p0, v0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "VWTP timing"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static j(Ljava/lang/String;)[B
    .locals 5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    new-array v1, v0, [B

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    mul-int/lit8 v3, v2, 0x2

    add-int/lit8 v4, v3, 0x2

    invoke-virtual {p0, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v1
.end method


# virtual methods
.method public final a(JLjava/lang/String;)Lc/j7;
    .locals 16

    move-object/from16 v0, p0

    move-wide/from16 v1, p1

    move-object/from16 v3, p3

    iget-object v4, v0, Lc/k7;->f:Lc/j7;

    if-eqz v4, :cond_34

    const/4 v5, 0x0

    iput-object v5, v0, Lc/k7;->f:Lc/j7;

    if-eqz v3, :cond_33

    invoke-virtual/range {p3 .. p3}, Ljava/lang/String;->length()I

    move-result v6

    const/high16 v7, 0x10000

    if-le v6, v7, :cond_0

    goto/16 :goto_13

    :cond_0
    iget-object v6, v0, Lc/k7;->d:Ljava/util/ArrayDeque;

    iget v7, v4, Lc/j7;->b:I

    if-nez v7, :cond_2

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v3, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "?"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "ERROR"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "UNABLE"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_32

    :cond_1
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v5

    :cond_2
    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v3, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    const-string v9, "[\\r\\n]+"

    invoke-virtual {v3, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v9, v3

    const/4 v10, 0x0

    move v11, v10

    :goto_0
    const/4 v12, 0x3

    if-ge v11, v9, :cond_5

    aget-object v13, v3, v11

    const-string v14, " "

    const-string v15, ""

    invoke-virtual {v13, v14, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v13

    const-string v14, "\t"

    invoke-virtual {v13, v14, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v13

    const-string v14, ">"

    invoke-virtual {v13, v14, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v13

    iget-object v14, v4, Lc/j7;->a:Ljava/lang/String;

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_4

    const-string v14, "[0-7][0-9A-F]{2}(?:[0-9A-F]{2}){1,8}"

    invoke-virtual {v13, v14}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_3

    goto :goto_1

    :cond_3
    new-instance v14, Lc/i7;

    invoke-virtual {v13, v10, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Lc/k7;->j(Ljava/lang/String;)[B

    move-result-object v12

    invoke-direct {v14, v15, v12}, Lc/i7;-><init>(Ljava/lang/String;[B)V

    invoke-virtual {v8, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_4
    :goto_1
    add-int/lit8 v11, v11, 0x1

    goto :goto_0

    :cond_5
    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v9, 0x5

    const/4 v11, 0x4

    const/4 v13, 0x7

    if-ne v7, v4, :cond_f

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i7;

    iget-object v7, v2, Lc/i7;->b:[B

    array-length v14, v7

    if-ne v14, v13, :cond_6

    aget-byte v7, v7, v4

    and-int/lit16 v7, v7, 0xff

    const/16 v14, 0xd0

    if-ne v7, v14, :cond_6

    goto :goto_2

    :cond_7
    move-object v2, v5

    :goto_2
    const-string v1, "A00F8AFF32FF"

    iget-object v7, v0, Lc/k7;->c:Ljava/lang/String;

    const-string v14, "ATST"

    const-string v15, "ATSH"

    if-nez v2, :cond_c

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move v8, v10

    :cond_8
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_9

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/i7;

    iget-object v9, v9, Lc/i7;->b:[B

    array-length v11, v9

    if-lt v11, v3, :cond_8

    aget-byte v9, v9, v4

    and-int/lit16 v9, v9, 0xff

    const/16 v11, 0xd8

    if-ne v9, v11, :cond_8

    move v8, v4

    goto :goto_3

    :cond_9
    if-eqz v8, :cond_b

    iget-object v2, v0, Lc/k7;->j:[B

    if-eqz v2, :cond_b

    iget-object v2, v0, Lc/k7;->h:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_a

    goto :goto_4

    :cond_a
    iget-object v2, v0, Lc/k7;->j:[B

    invoke-static {v2}, Lc/k7;->e([B)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v13}, Lc/k7;->b(Ljava/lang/String;I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, v0, Lc/k7;->h:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, Lc/k7;->b(Ljava/lang/String;I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, Lc/k7;->b(Ljava/lang/String;I)V

    invoke-virtual {v0, v1, v3}, Lc/k7;->b(Ljava/lang/String;I)V

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/j7;

    iput-object v1, v0, Lc/k7;->f:Lc/j7;

    return-object v1

    :cond_b
    :goto_4
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v5

    :cond_c
    iget-object v2, v2, Lc/i7;->b:[B

    aget-byte v4, v2, v3

    and-int/lit16 v4, v4, 0xff

    aget-byte v8, v2, v12

    and-int/lit16 v8, v8, 0xff

    shl-int/lit8 v8, v8, 0x8

    or-int/2addr v4, v8

    aget-byte v8, v2, v11

    and-int/lit16 v8, v8, 0xff

    aget-byte v2, v2, v9

    and-int/lit16 v2, v2, 0xff

    shl-int/lit8 v2, v2, 0x8

    or-int/2addr v2, v8

    const/16 v8, 0x7ff

    if-gt v4, v8, :cond_e

    if-gt v2, v8, :cond_e

    if-ne v4, v2, :cond_d

    goto :goto_5

    :cond_d
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v8, "%03X"

    invoke-static {v5, v8, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iput-object v4, v0, Lc/k7;->i:Ljava/lang/String;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v5, v8, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lc/k7;->h:Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, v0, Lc/k7;->h:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, Lc/k7;->b(Ljava/lang/String;I)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v10}, Lc/k7;->b(Ljava/lang/String;I)V

    invoke-virtual {v0, v1, v3}, Lc/k7;->b(Ljava/lang/String;I)V

    goto/16 :goto_12

    :cond_e
    :goto_5
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v5

    :cond_f
    if-eq v7, v3, :cond_2c

    if-ne v7, v12, :cond_10

    goto/16 :goto_f

    :cond_10
    if-ne v7, v13, :cond_11

    iput-wide v1, v0, Lc/k7;->t:J

    iget-object v1, v0, Lc/k7;->k:[B

    if-nez v1, :cond_32

    iget-boolean v1, v0, Lc/k7;->r:Z

    if-nez v1, :cond_32

    iget v1, v0, Lc/k7;->p:I

    if-nez v1, :cond_32

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_32

    invoke-virtual {v0, v5, v9}, Lc/k7;->b(Ljava/lang/String;I)V

    goto/16 :goto_12

    :cond_11
    const/16 v1, 0xa3

    if-ne v7, v11, :cond_13

    iget v2, v0, Lc/k7;->p:I

    sub-int/2addr v2, v4

    iput v2, v0, Lc/k7;->p:I

    if-lez v2, :cond_13

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_12
    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_32

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i7;

    iget-object v5, v3, Lc/i7;->a:Ljava/lang/String;

    iget-object v7, v0, Lc/k7;->i:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_12

    iget-object v3, v3, Lc/i7;->b:[B

    array-length v5, v3

    if-ne v5, v4, :cond_12

    aget-byte v3, v3, v10

    and-int/lit16 v3, v3, 0xff

    if-ne v3, v1, :cond_12

    iget-object v3, v0, Lc/k7;->j:[B

    if-eqz v3, :cond_12

    new-instance v5, Lc/j7;

    invoke-static {v3}, Lc/k7;->e([B)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v5, v3, v13}, Lc/j7;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v6, v5}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    goto :goto_6

    :cond_13
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move-object v8, v5

    :goto_7
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    iget-object v9, v0, Lc/k7;->e:Ljava/io/ByteArrayOutputStream;

    if-eqz v15, :cond_20

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Lc/i7;

    iget-object v14, v15, Lc/i7;->a:Ljava/lang/String;

    iget-object v5, v0, Lc/k7;->i:Ljava/lang/String;

    invoke-virtual {v14, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_14

    goto :goto_8

    :cond_14
    iget-object v5, v15, Lc/i7;->b:[B

    array-length v14, v5

    if-ne v14, v4, :cond_15

    aget-byte v14, v5, v10

    and-int/lit16 v14, v14, 0xff

    if-ne v14, v1, :cond_15

    iget-object v5, v0, Lc/k7;->j:[B

    if-eqz v5, :cond_16

    invoke-static {v5}, Lc/k7;->e([B)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5, v13}, Lc/k7;->b(Ljava/lang/String;I)V

    goto :goto_8

    :cond_15
    aget-byte v14, v5, v10

    and-int/lit16 v1, v14, 0xff

    ushr-int/2addr v1, v11

    if-le v1, v12, :cond_17

    :cond_16
    :goto_8
    const/16 v1, 0xa3

    const/4 v5, 0x0

    const/4 v9, 0x5

    goto :goto_7

    :cond_17
    array-length v1, v5

    if-lt v1, v3, :cond_18

    iget-boolean v1, v0, Lc/k7;->r:Z

    if-eqz v1, :cond_19

    :cond_18
    const/4 v1, 0x0

    goto :goto_c

    :cond_19
    and-int/lit8 v1, v14, 0xf

    iget v8, v0, Lc/k7;->n:I

    if-ltz v8, :cond_1a

    if-eq v1, v8, :cond_1a

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    :goto_9
    const/4 v1, 0x0

    return-object v1

    :cond_1a
    add-int/lit8 v1, v1, 0x1

    and-int/lit8 v1, v1, 0xf

    iput v1, v0, Lc/k7;->n:I

    array-length v1, v5

    sub-int/2addr v1, v4

    invoke-virtual {v9, v5, v4, v1}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v1

    const/16 v8, 0x1001

    if-le v1, v8, :cond_1b

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    goto :goto_9

    :cond_1b
    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    iget v8, v0, Lc/k7;->o:I

    if-gez v8, :cond_1c

    array-length v8, v1

    if-lt v8, v3, :cond_1c

    aget-byte v8, v1, v10

    and-int/lit16 v8, v8, 0xff

    shl-int/lit8 v8, v8, 0x8

    aget-byte v1, v1, v4

    and-int/lit16 v1, v1, 0xff

    or-int/2addr v1, v8

    iput v1, v0, Lc/k7;->o:I

    :cond_1c
    iget v1, v0, Lc/k7;->o:I

    const/16 v8, 0xfff

    if-gt v1, v8, :cond_1f

    if-nez v1, :cond_1d

    goto :goto_b

    :cond_1d
    aget-byte v1, v5, v10

    const/16 v5, 0x10

    and-int/2addr v1, v5

    if-eqz v1, :cond_1e

    move v1, v4

    goto :goto_a

    :cond_1e
    move v1, v10

    :goto_a
    iput-boolean v1, v0, Lc/k7;->r:Z

    move-object v8, v15

    goto :goto_8

    :cond_1f
    :goto_b
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    goto :goto_9

    :goto_c
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v1

    :cond_20
    if-eqz v8, :cond_21

    iget-object v1, v8, Lc/i7;->b:[B

    aget-byte v1, v1, v10

    and-int/lit8 v2, v1, 0x20

    if-nez v2, :cond_21

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    add-int/2addr v1, v4

    and-int/lit8 v1, v1, 0xf

    or-int/lit16 v1, v1, 0xb0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v5, "%02X"

    invoke-static {v2, v5, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x6

    invoke-virtual {v0, v1, v2}, Lc/k7;->b(Ljava/lang/String;I)V

    :cond_21
    iget-boolean v1, v0, Lc/k7;->r:Z

    if-eqz v1, :cond_2a

    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1

    iget v2, v0, Lc/k7;->o:I

    if-lt v2, v4, :cond_29

    array-length v4, v1

    add-int/lit8 v5, v2, 0x2

    if-eq v4, v5, :cond_22

    goto/16 :goto_e

    :cond_22
    if-ne v2, v12, :cond_25

    aget-byte v2, v1, v3

    and-int/lit16 v2, v2, 0xff

    const/16 v4, 0x7f

    if-ne v2, v4, :cond_25

    aget-byte v2, v1, v12

    and-int/lit16 v2, v2, 0xff

    iget-object v4, v0, Lc/k7;->g:Ljava/lang/String;

    invoke-virtual {v4, v10, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x10

    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    if-ne v2, v4, :cond_25

    aget-byte v1, v1, v11

    and-int/lit16 v1, v1, 0xff

    const/16 v2, 0x78

    if-ne v1, v2, :cond_23

    iput-boolean v10, v0, Lc/k7;->r:Z

    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->reset()V

    const/4 v1, -0x1

    iput v1, v0, Lc/k7;->n:I

    iput v1, v0, Lc/k7;->o:I

    :cond_23
    iget-boolean v1, v0, Lc/k7;->r:Z

    if-nez v1, :cond_24

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_24

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, v1, v2}, Lc/k7;->b(Ljava/lang/String;I)V

    :cond_24
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/j7;

    iput-object v1, v0, Lc/k7;->f:Lc/j7;

    return-object v1

    :cond_25
    iget-object v2, v0, Lc/k7;->g:Ljava/lang/String;

    invoke-static {v2}, Lc/k7;->j(Ljava/lang/String;)[B

    move-result-object v2

    aget-byte v4, v2, v10

    and-int/lit16 v4, v4, 0xff

    add-int/lit8 v4, v4, 0x40

    int-to-byte v4, v4

    aput-byte v4, v2, v10

    iget v4, v0, Lc/k7;->o:I

    array-length v5, v2

    if-ge v4, v5, :cond_26

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    const/4 v4, 0x0

    return-object v4

    :cond_26
    :goto_d
    const/4 v4, 0x0

    array-length v5, v2

    if-ge v10, v5, :cond_28

    add-int/lit8 v5, v10, 0x2

    aget-byte v5, v1, v5

    aget-byte v7, v2, v10

    if-eq v5, v7, :cond_27

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v4

    :cond_27
    add-int/lit8 v10, v10, 0x1

    goto :goto_d

    :cond_28
    array-length v4, v2

    add-int/2addr v4, v3

    array-length v5, v1

    invoke-static {v1, v4, v5}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v4

    iput-object v4, v0, Lc/k7;->k:[B

    array-length v2, v2

    add-int/2addr v2, v3

    array-length v3, v1

    invoke-static {v1, v2, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v1

    iput-object v1, v0, Lc/k7;->l:[B

    goto/16 :goto_12

    :cond_29
    :goto_e
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    goto/16 :goto_9

    :cond_2a
    const/4 v1, 0x0

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_32

    if-nez v8, :cond_2b

    const/4 v2, 0x6

    if-eq v7, v2, :cond_2b

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    return-object v1

    :cond_2b
    const/4 v2, 0x5

    invoke-virtual {v0, v1, v2}, Lc/k7;->b(Ljava/lang/String;I)V

    goto :goto_12

    :cond_2c
    :goto_f
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_2d
    :goto_10
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/i7;

    iget-object v9, v8, Lc/i7;->a:Ljava/lang/String;

    iget-object v12, v0, Lc/k7;->i:Ljava/lang/String;

    invoke-virtual {v9, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2e

    iget-object v9, v8, Lc/i7;->b:[B

    array-length v12, v9

    const/4 v13, 0x6

    if-lt v12, v13, :cond_2d

    aget-byte v9, v9, v10

    and-int/lit16 v9, v9, 0xff

    const/16 v12, 0xa1

    if-ne v9, v12, :cond_2d

    goto :goto_11

    :cond_2e
    const/4 v13, 0x6

    goto :goto_10

    :cond_2f
    const/4 v8, 0x0

    :goto_11
    if-nez v8, :cond_30

    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    goto/16 :goto_9

    :cond_30
    if-ne v7, v3, :cond_31

    iget-object v5, v8, Lc/i7;->b:[B

    invoke-virtual {v5}, [B->clone()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [B

    iput-object v5, v0, Lc/k7;->j:[B

    aget-byte v8, v5, v4

    aget-byte v5, v5, v3

    and-int/lit16 v5, v5, 0xff

    invoke-static {v5}, Lc/k7;->i(I)V

    iget-object v5, v0, Lc/k7;->j:[B

    aget-byte v5, v5, v11

    and-int/lit16 v5, v5, 0xff

    invoke-static {v5}, Lc/k7;->i(I)V

    iput v10, v0, Lc/k7;->m:I

    iput-boolean v4, v0, Lc/k7;->q:Z

    :cond_31
    iput-wide v1, v0, Lc/k7;->t:J

    if-ne v7, v3, :cond_32

    invoke-virtual/range {p0 .. p0}, Lc/k7;->g()V

    :cond_32
    :goto_12
    invoke-virtual {v6}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/j7;

    iput-object v1, v0, Lc/k7;->f:Lc/j7;

    return-object v1

    :cond_33
    :goto_13
    invoke-virtual/range {p0 .. p0}, Lc/k7;->d()V

    goto/16 :goto_9

    :cond_34
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "No VWTP step"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final b(Ljava/lang/String;I)V
    .locals 2

    iget-object v0, p0, Lc/k7;->d:Ljava/util/ArrayDeque;

    new-instance v1, Lc/j7;

    invoke-direct {v1, p1, p2}, Lc/j7;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final c(JLjava/lang/String;)Lc/j7;
    .locals 5

    iget-object v0, p0, Lc/k7;->f:Lc/j7;

    if-nez v0, :cond_7

    iget-object v0, p0, Lc/k7;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "(?i)VWTP:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/k7;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":(?:[0-9A-F]{2}){1,256}"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    const/16 v1, 0x8

    invoke-virtual {p3, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p3

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p3, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    iput-object p3, p0, Lc/k7;->g:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-virtual {p3, v1, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p3

    const/16 v3, 0x10

    invoke-static {p3, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result p3

    const/16 v3, 0xbf

    if-gt p3, v3, :cond_5

    iput-boolean v1, p0, Lc/k7;->s:Z

    const/4 p3, 0x0

    iput-object p3, p0, Lc/k7;->k:[B

    iput-object p3, p0, Lc/k7;->l:[B

    iget-object p3, p0, Lc/k7;->e:Ljava/io/ByteArrayOutputStream;

    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->reset()V

    const/4 p3, -0x1

    iput p3, p0, Lc/k7;->n:I

    iput p3, p0, Lc/k7;->o:I

    iput-boolean v1, p0, Lc/k7;->r:Z

    iget-wide v3, p0, Lc/k7;->t:J

    sub-long/2addr p1, v3

    iget-boolean p3, p0, Lc/k7;->q:Z

    if-eqz p3, :cond_3

    const-wide/16 v3, 0x802

    cmp-long p3, p1, v3

    if-lez p3, :cond_0

    goto :goto_2

    :cond_0
    new-instance p3, Ljava/lang/StringBuilder;

    const-string v2, "ATSH"

    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/k7;->h:Ljava/lang/String;

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p0, p3, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v2, "ATST"

    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/k7;->c:Ljava/lang/String;

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p0, p3, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    const-wide/16 v1, 0x3e8

    cmp-long p3, p1, v1

    if-lez p3, :cond_1

    iget-object p1, p0, Lc/k7;->j:[B

    invoke-static {p1}, Lc/k7;->e([B)Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x7

    :goto_0
    invoke-virtual {p0, p1, p2}, Lc/k7;->b(Ljava/lang/String;I)V

    goto :goto_1

    :cond_1
    const-wide/16 v1, 0x258

    cmp-long p1, p1, v1

    if-lez p1, :cond_2

    const-string p1, "A3"

    const/4 p2, 0x3

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {p0}, Lc/k7;->g()V

    goto :goto_4

    :cond_3
    :goto_2
    iput-boolean v1, p0, Lc/k7;->q:Z

    iput v1, p0, Lc/k7;->m:I

    sget-object p1, Lc/k7;->u:[Ljava/lang/String;

    move p2, v1

    :goto_3
    const/4 p3, 0x4

    if-ge p2, p3, :cond_4

    aget-object p3, p1, p2

    invoke-virtual {p0, p3, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_3

    :cond_4
    const-string p1, "ATSH200"

    invoke-virtual {p0, p1, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    const-string p1, "ATST0A"

    invoke-virtual {p0, p1, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "C00010"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p0, Lc/k7;->b:Ljava/lang/String;

    const/4 p3, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "0"

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v1, p3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "011"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, p3}, Lc/k7;->b(Ljava/lang/String;I)V

    :goto_4
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/j7;

    iput-object p1, p0, Lc/k7;->f:Lc/j7;

    return-object p1

    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "VWTP service"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "VWTP query"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "VWTP busy"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final d()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/k7;->s:Z

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/k7;->q:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/k7;->k:[B

    iget-object v1, p0, Lc/k7;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->clear()V

    iput-object v0, p0, Lc/k7;->f:Lc/j7;

    return-void
.end method

.method public final f()[B
    .locals 1

    iget-object v0, p0, Lc/k7;->f:Lc/j7;

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/k7;->d:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/k7;->s:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/k7;->k:[B

    if-eqz v0, :cond_0

    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final g()V
    .locals 10

    iget-object v0, p0, Lc/k7;->g:Ljava/lang/String;

    invoke-static {v0}, Lc/k7;->j(Ljava/lang/String;)[B

    move-result-object v0

    array-length v0, v0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-gt v0, v3, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    iget v5, p0, Lc/k7;->m:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v5, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v5, "1%X%04X"

    invoke-static {v4, v5, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lc/k7;->g:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    iget v0, p0, Lc/k7;->m:I

    add-int/2addr v0, v2

    and-int/lit8 v0, v0, 0xf

    iput v0, p0, Lc/k7;->m:I

    iput v2, p0, Lc/k7;->p:I

    return-void

    :cond_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    iget v6, p0, Lc/k7;->m:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v6, v7}, [Ljava/lang/Object;

    move-result-object v6

    const-string v7, "2%X%04X"

    invoke-static {v5, v7, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lc/k7;->g:Ljava/lang/String;

    const/16 v6, 0xa

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0, v4, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    iget v4, p0, Lc/k7;->m:I

    add-int/2addr v4, v2

    and-int/lit8 v4, v4, 0xf

    iput v4, p0, Lc/k7;->m:I

    iput v2, p0, Lc/k7;->p:I

    :goto_0
    if-ge v3, v0, :cond_3

    const/4 v4, 0x7

    sub-int v5, v0, v3

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    add-int/2addr v4, v3

    if-ne v4, v0, :cond_1

    move v5, v2

    goto :goto_1

    :cond_1
    move v5, v7

    :goto_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    if-eqz v5, :cond_2

    move v5, v2

    goto :goto_2

    :cond_2
    const/4 v5, 0x2

    :goto_2
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v9, p0, Lc/k7;->m:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v5, v9}, [Ljava/lang/Object;

    move-result-object v5

    const-string v9, "%X%X"

    invoke-static {v8, v9, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lc/k7;->g:Ljava/lang/String;

    mul-int/lit8 v3, v3, 0x2

    mul-int/lit8 v8, v4, 0x2

    invoke-virtual {v5, v3, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3, v1}, Lc/k7;->b(Ljava/lang/String;I)V

    iget v3, p0, Lc/k7;->m:I

    add-int/2addr v3, v2

    and-int/lit8 v3, v3, 0xf

    iput v3, p0, Lc/k7;->m:I

    iget v3, p0, Lc/k7;->p:I

    add-int/2addr v3, v2

    iput v3, p0, Lc/k7;->p:I

    move v3, v4

    goto :goto_0

    :cond_3
    return-void
.end method

.method public final h()[B
    .locals 1

    invoke-virtual {p0}, Lc/k7;->f()[B

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/k7;->l:[B

    if-eqz v0, :cond_0

    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [B

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method
