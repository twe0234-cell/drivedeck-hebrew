.class public final Lc/G6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field public final synthetic a:Landroid/widget/EditText;

.field public final synthetic b:Lc/s6;

.field public final synthetic c:Lc/H6;


# direct methods
.method public constructor <init>(Landroid/widget/EditText;Lc/s6;Lc/H6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc/G6;->c:Lc/H6;

    iput-object p1, p0, Lc/G6;->a:Landroid/widget/EditText;

    iput-object p2, p0, Lc/G6;->b:Lc/s6;

    return-void
.end method


# virtual methods
.method public final afterTextChanged(Landroid/text/Editable;)V
    .locals 0

    return-void
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 2

    iget-object p1, p0, Lc/G6;->a:Landroid/widget/EditText;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setError(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lc/G6;->c:Lc/H6;

    iget-object p2, p1, Lc/H6;->m0:Landroid/os/Handler;

    iget-object p3, p0, Lc/G6;->b:Lc/s6;

    invoke-virtual {p2, p3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p1, Lc/H6;->m0:Landroid/os/Handler;

    const-wide/16 v0, 0x2bc

    invoke-virtual {p1, p3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
