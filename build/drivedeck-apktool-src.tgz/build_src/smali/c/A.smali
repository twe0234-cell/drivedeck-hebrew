.class public final synthetic Lc/A;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/A;->a:I

    iput-object p1, p0, Lc/A;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iget v2, v0, Lc/A;->a:I

    packed-switch v2, :pswitch_data_0

    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/d8;

    iget-object v3, v2, Lc/d8;->i:Landroid/widget/FrameLayout;

    const/4 v4, 0x0

    if-eqz v3, :cond_7

    invoke-virtual {v3}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v3

    if-nez v3, :cond_0

    goto/16 :goto_1

    :cond_0
    iget-object v3, v2, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/view/WindowManager$LayoutParams;

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_6

    if-eq v5, v6, :cond_4

    const/4 v7, 0x2

    if-eq v5, v7, :cond_2

    const/4 v1, 0x3

    if-eq v5, v1, :cond_1

    :goto_0
    move v4, v6

    goto :goto_1

    :cond_1
    iput-boolean v4, v2, Lc/d8;->s:Z

    goto :goto_0

    :cond_2
    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v4

    iget v5, v2, Lc/d8;->o:F

    sub-float/2addr v4, v5

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iget v5, v2, Lc/d8;->p:F

    sub-float/2addr v1, v5

    iget-object v5, v2, Lc/d8;->a:Landroid/content/Context;

    invoke-static {v5}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v5

    iget-boolean v7, v2, Lc/d8;->s:Z

    if-nez v7, :cond_3

    mul-float v7, v4, v4

    mul-float v8, v1, v1

    add-float/2addr v8, v7

    mul-int/2addr v5, v5

    int-to-float v5, v5

    cmpg-float v5, v8, v5

    if-gtz v5, :cond_3

    goto :goto_0

    :cond_3
    iput-boolean v6, v2, Lc/d8;->s:Z

    iget v5, v2, Lc/d8;->q:I

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    add-int/2addr v4, v5

    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    iget v4, v2, Lc/d8;->r:I

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    sub-int/2addr v4, v1

    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-virtual {v2}, Lc/d8;->d()V

    goto :goto_0

    :cond_4
    iget-boolean v1, v2, Lc/d8;->s:Z

    if-nez v1, :cond_5

    iget-object v1, v2, Lc/d8;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->performClick()Z

    :cond_5
    iput-boolean v4, v2, Lc/d8;->s:Z

    goto :goto_0

    :cond_6
    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v5

    iput v5, v2, Lc/d8;->o:F

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iput v1, v2, Lc/d8;->p:F

    iget v1, v3, Landroid/view/WindowManager$LayoutParams;->x:I

    iput v1, v2, Lc/d8;->q:I

    iget v1, v3, Landroid/view/WindowManager$LayoutParams;->y:I

    iput v1, v2, Lc/d8;->r:I

    iput-boolean v4, v2, Lc/d8;->s:Z

    goto :goto_0

    :cond_7
    :goto_1
    return v4

    :pswitch_0
    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/v7;

    invoke-virtual {v2, v1}, Lc/v7;->j(Landroid/view/MotionEvent;)Z

    move-result v1

    return v1

    :pswitch_1
    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/C6;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v3, v5, :cond_8

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v3, 0x3

    if-eq v1, v3, :cond_8

    goto :goto_2

    :cond_8
    move v5, v4

    :goto_2
    iget-object v1, v2, Lc/C6;->a:Lc/H6;

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    return v4

    :pswitch_2
    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/H6;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v3, v5, :cond_9

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v3, 0x3

    if-eq v1, v3, :cond_9

    goto :goto_3

    :cond_9
    move v5, v4

    :goto_3
    invoke-virtual {v2, v5}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    return v4

    :pswitch_3
    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/m2;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/4 v4, 0x1

    iget-object v5, v2, Lc/m2;->t:[Lc/t2;

    iget-object v6, v2, Lc/m2;->w:Lc/l2;

    const/4 v7, 0x0

    if-nez v3, :cond_b

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v3

    iput v3, v2, Lc/m2;->P:F

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iput v1, v2, Lc/m2;->Q:F

    iget v1, v2, Lc/m2;->H:F

    iput v1, v2, Lc/m2;->R:F

    iput-boolean v4, v2, Lc/m2;->S:Z

    iget-boolean v1, v6, Lc/l2;->c:Z

    if-ne v1, v4, :cond_a

    goto :goto_4

    :cond_a
    iput-boolean v4, v6, Lc/l2;->c:Z

    invoke-virtual {v6}, Landroid/view/View;->invalidate()V

    :goto_4
    array-length v1, v5

    :goto_5
    if-ge v7, v1, :cond_20

    aget-object v2, v5, v7

    invoke-virtual {v2, v4}, Lc/t2;->i0(Z)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_5

    :cond_b
    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/4 v8, 0x2

    const/high16 v9, 0x3e800000    # 0.25f

    const/high16 v10, 0x3f400000    # 0.75f

    const/high16 v11, 0x3f800000    # 1.0f

    if-ne v3, v8, :cond_d

    iget-boolean v3, v2, Lc/m2;->S:Z

    if-eqz v3, :cond_20

    invoke-virtual {v2}, Lc/F;->q()Z

    move-result v3

    invoke-virtual {v2, v3}, Lc/m2;->x(Z)F

    move-result v5

    iget v6, v2, Lc/m2;->R:F

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v7

    iget v8, v2, Lc/m2;->P:F

    sub-float/2addr v7, v8

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iget v8, v2, Lc/m2;->Q:F

    sub-float/2addr v1, v8

    invoke-static {v11, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    if-eqz v3, :cond_c

    move v7, v1

    :cond_c
    div-float/2addr v7, v5

    add-float/2addr v7, v6

    invoke-static {v10, v7}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, v2, Lc/m2;->H:F

    invoke-virtual {v2}, Landroid/view/View;->requestLayout()V

    goto/16 :goto_10

    :cond_d
    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    const/4 v8, 0x3

    if-eq v3, v4, :cond_f

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-ne v3, v8, :cond_e

    goto :goto_6

    :cond_e
    move v4, v7

    goto/16 :goto_10

    :cond_f
    :goto_6
    iget-boolean v3, v2, Lc/m2;->S:Z

    if-eqz v3, :cond_1f

    iput-boolean v7, v2, Lc/m2;->S:Z

    invoke-virtual {v2}, Lc/F;->q()Z

    move-result v3

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v12

    const v13, 0x3a83126f    # 0.001f

    if-ne v12, v4, :cond_1a

    iget v12, v2, Lc/m2;->R:F

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v14

    iget v15, v2, Lc/m2;->P:F

    sub-float/2addr v14, v15

    invoke-virtual/range {p2 .. p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iget v15, v2, Lc/m2;->Q:F

    sub-float/2addr v1, v15

    invoke-virtual {v2, v3}, Lc/m2;->x(Z)F

    move-result v15

    invoke-static {v11, v15}, Ljava/lang/Math;->max(FF)F

    move-result v11

    if-eqz v3, :cond_10

    move v14, v1

    :cond_10
    div-float/2addr v14, v11

    add-float/2addr v14, v12

    invoke-static {v10, v14}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    iput v1, v2, Lc/m2;->H:F

    iget-object v3, v2, Lc/m2;->y:Lc/n1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Lc/n1;->b(F)F

    move-result v1

    invoke-virtual {v3, v7}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v4}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v3}, Lc/n1;->I()F

    move-result v11

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v12

    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_7
    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_12

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-static {v15}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v16

    if-eqz v16, :cond_11

    invoke-static {v15}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_11

    invoke-static {v15}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_11

    invoke-static {v15}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v4

    sub-float/2addr v4, v11

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpl-float v4, v4, v13

    if-ltz v4, :cond_11

    invoke-static {v15}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v4

    sub-float/2addr v4, v1

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    cmpg-float v4, v4, v13

    if-gez v4, :cond_11

    move v1, v7

    goto/16 :goto_b

    :cond_11
    const/4 v4, 0x1

    goto :goto_7

    :cond_12
    move v4, v7

    move v14, v4

    :goto_8
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v15

    if-ge v4, v15, :cond_17

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    invoke-static {v15}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v16

    sub-float v16, v16, v11

    invoke-static/range {v16 .. v16}, Ljava/lang/Math;->abs(F)F

    move-result v16

    cmpg-float v16, v16, v13

    if-gez v16, :cond_15

    invoke-static {v15}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v16

    if-eqz v16, :cond_15

    invoke-static {v15}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v9, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_15

    invoke-static {v15}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_13

    goto :goto_9

    :cond_13
    const-string v13, "\\|"

    const/4 v7, -0x1

    invoke-virtual {v15, v13, v7}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v7

    array-length v7, v7

    const/4 v13, 0x5

    if-ge v7, v13, :cond_14

    invoke-static {v9, v10, v1}, Lc/G8;->a0(Ljava/lang/String;Ljava/lang/String;F)Ljava/lang/String;

    move-result-object v7

    goto :goto_a

    :cond_14
    invoke-static {v15, v8}, Lc/G8;->A0(Ljava/lang/String;I)I

    move-result v7

    const/4 v13, 0x4

    invoke-static {v15, v13}, Lc/G8;->A0(Ljava/lang/String;I)I

    move-result v13

    invoke-static {v9, v10, v1, v7, v13}, Lc/G8;->b0(Ljava/lang/String;Ljava/lang/String;FII)Ljava/lang/String;

    move-result-object v7

    goto :goto_a

    :cond_15
    :goto_9
    move-object v7, v15

    :goto_a
    invoke-virtual {v7, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_16

    invoke-virtual {v12, v4, v7}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v14, 0x1

    :cond_16
    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x0

    const v13, 0x3a83126f    # 0.001f

    goto :goto_8

    :cond_17
    iget-object v4, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v7, "split_ratio"

    invoke-interface {v4, v7, v1}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    if-eqz v14, :cond_18

    const-string v4, ","

    invoke-static {v4, v12}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "dock"

    invoke-interface {v1, v7, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :cond_18
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v1

    :goto_b
    if-nez v1, :cond_19

    iget v1, v2, Lc/m2;->R:F

    iput v1, v2, Lc/m2;->H:F

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v4, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043f\u0440\u043e\u043f\u043e\u0440\u0446\u0438\u0438 \u043f\u0430\u0440\u044b"

    invoke-static {v3, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-static {v1, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    goto :goto_c

    :cond_19
    iget-object v1, v2, Lc/F;->l:Landroid/view/View;

    check-cast v1, Lc/b2;

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v1, v3}, Lc/b2;->D(Ljava/util/ArrayList;)V

    goto :goto_c

    :cond_1a
    iget v1, v2, Lc/m2;->R:F

    iput v1, v2, Lc/m2;->H:F

    :goto_c
    iget v1, v2, Lc/m2;->H:F

    iget v3, v2, Lc/m2;->R:F

    sub-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const v3, 0x3a83126f    # 0.001f

    cmpl-float v1, v1, v3

    if-lez v1, :cond_1b

    const/4 v4, 0x1

    goto :goto_d

    :cond_1b
    const/4 v4, 0x0

    :goto_d
    array-length v1, v5

    const/4 v3, 0x0

    :goto_e
    if-ge v3, v1, :cond_1d

    aget-object v7, v5, v3

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lc/t2;->i0(Z)V

    if-eqz v4, :cond_1c

    invoke-virtual {v7}, Lc/t2;->m0()V

    :cond_1c
    add-int/lit8 v3, v3, 0x1

    goto :goto_e

    :cond_1d
    const/4 v8, 0x0

    iget-boolean v1, v6, Lc/l2;->c:Z

    if-nez v1, :cond_1e

    goto :goto_f

    :cond_1e
    iput-boolean v8, v6, Lc/l2;->c:Z

    invoke-virtual {v6}, Landroid/view/View;->invalidate()V

    :goto_f
    invoke-virtual {v2}, Landroid/view/View;->requestLayout()V

    :cond_1f
    const/4 v4, 0x1

    :cond_20
    :goto_10
    return v4

    :pswitch_4
    iget-object v2, v0, Lc/A;->b:Ljava/lang/Object;

    check-cast v2, Lc/F;

    invoke-virtual {v2, v1}, Lc/F;->p(Landroid/view/MotionEvent;)V

    const/4 v1, 0x0

    return v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
