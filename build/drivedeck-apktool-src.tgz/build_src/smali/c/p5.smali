.class public final synthetic Lc/p5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/ToLongFunction;


# virtual methods
.method public final applyAsLong(Ljava/lang/Object;)J
    .locals 2

    check-cast p1, Lc/q5;

    sget-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->a:Ljava/util/concurrent/CopyOnWriteArraySet;

    iget-wide v0, p1, Lc/q5;->d:J

    return-wide v0
.end method
