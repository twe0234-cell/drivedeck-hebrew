.class public final Lc/C0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/P3;

.field public final b:Lc/n1;

.field public final c:Lc/G0;

.field public final d:Lc/K3;

.field public final e:Landroid/graphics/Paint;

.field public final f:Landroid/graphics/RectF;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Lc/j6;

.field public j:Lc/j6;

.field public k:Ljava/util/ArrayList;

.field public l:I

.field public m:F

.field public n:F

.field public o:Z

.field public p:Z


# direct methods
.method public constructor <init>(Lc/P3;Lc/n1;Lc/G0;Lc/K3;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/C0;->e:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/C0;->f:Landroid/graphics/RectF;

    iput-object p1, p0, Lc/C0;->a:Lc/P3;

    iput-object p2, p0, Lc/C0;->b:Lc/n1;

    iput-object p3, p0, Lc/C0;->c:Lc/G0;

    iput-object p4, p0, Lc/C0;->d:Lc/K3;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    iget-object v0, p0, Lc/C0;->h:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/C0;->k:Ljava/util/ArrayList;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lc/C0;->j:Lc/j6;

    iget-object v2, p0, Lc/C0;->b:Lc/n1;

    invoke-virtual {v2, v1, v0}, Lc/n1;->L0(Lc/j6;Ljava/util/ArrayList;)V

    iget-object v0, p0, Lc/C0;->j:Lc/j6;

    iget-object v1, p0, Lc/C0;->h:Ljava/lang/String;

    iget v3, p0, Lc/C0;->l:I

    invoke-virtual {v2, v0, v1, v3}, Lc/n1;->M0(Lc/j6;Ljava/lang/String;I)V

    iget-object v0, p0, Lc/C0;->d:Lc/K3;

    invoke-virtual {v0}, Lc/K3;->getAsBoolean()Z

    const/4 v0, 0x0

    iget-object v1, p0, Lc/C0;->c:Lc/G0;

    invoke-virtual {v1, v0}, Lc/G0;->j(Z)Z

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lc/C0;->h:Ljava/lang/String;

    iput-object v0, p0, Lc/C0;->k:Ljava/util/ArrayList;

    iput-object v0, p0, Lc/C0;->j:Lc/j6;

    iget-object v0, p0, Lc/C0;->f:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v0, p0, Lc/C0;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final b(Landroid/graphics/Canvas;Lc/r4;Z)V
    .locals 9

    iget-object v0, p0, Lc/C0;->f:Landroid/graphics/RectF;

    invoke-virtual {v0}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v1, 0x0

    if-nez p3, :cond_0

    iput-object v1, p0, Lc/C0;->g:Ljava/lang/String;

    return-void

    :cond_0
    iget-object p3, p0, Lc/C0;->i:Lc/j6;

    iget-object v2, p0, Lc/C0;->c:Lc/G0;

    iget-object v3, v2, Lc/G0;->c:Lc/T5;

    iget-object v3, v3, Lc/T5;->g:Lc/j6;

    if-eq p3, v3, :cond_1

    iput-object v1, p0, Lc/C0;->g:Ljava/lang/String;

    :cond_1
    iget-object p3, p0, Lc/C0;->a:Lc/P3;

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v1, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    iget-object v3, p0, Lc/C0;->e:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v3, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {v2}, Lc/G0;->e()Ljava/util/LinkedHashMap;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    new-instance v5, Landroid/graphics/RectF;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/graphics/RectF;

    invoke-direct {v5, v6}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    invoke-virtual {v5, v1, v1}, Landroid/graphics/RectF;->inset(FF)V

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    iget-object v7, p0, Lc/C0;->g:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    iget v6, p2, Lc/r4;->f:I

    goto :goto_1

    :cond_3
    iget v6, p2, Lc/r4;->h:I

    :goto_1
    invoke-virtual {v3, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v6, 0x40c00000    # 6.0f

    mul-float/2addr v6, v1

    invoke-virtual {p1, v5, v6, v6, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v6, p0, Lc/C0;->g:Ljava/lang/String;

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    const/high16 v4, 0x41e00000    # 28.0f

    mul-float/2addr v4, v1

    iget v6, v5, Landroid/graphics/RectF;->right:F

    sub-float v7, v6, v4

    const/high16 v8, 0x41800000    # 16.0f

    mul-float/2addr v8, v1

    sub-float/2addr v7, v8

    iget v5, v5, Landroid/graphics/RectF;->bottom:F

    sub-float v4, v5, v4

    sub-float/2addr v4, v8

    sub-float/2addr v6, v8

    sub-float/2addr v5, v8

    invoke-virtual {v0, v7, v4, v6, v5}, Landroid/graphics/RectF;->set(FFFF)V

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v4, p2, Lc/r4;->f:I

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v4

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    invoke-virtual {v0}, Landroid/graphics/RectF;->height()F

    move-result v6

    div-float/2addr v6, v5

    invoke-virtual {p1, v0, v4, v6, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    new-instance v4, Landroid/graphics/RectF;

    invoke-direct {v4, v0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    const/high16 v5, 0x40a00000    # 5.0f

    mul-float/2addr v5, v1

    invoke-virtual {v4, v5, v5}, Landroid/graphics/RectF;->inset(FF)V

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const v6, 0x7f0300c9

    iget v7, p2, Lc/r4;->g:I

    invoke-static {v5, p1, v6, v7, v4}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    goto/16 :goto_0

    :cond_4
    return-void
.end method

.method public final c(FF)Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lc/C0;->c:Lc/G0;

    iget-boolean v1, v0, Lc/G0;->o:Z

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return-object v2

    :cond_0
    invoke-virtual {v0}, Lc/G0;->e()Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    invoke-virtual {v3, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    return-object p1

    :cond_2
    return-object v2
.end method
