.class public final Lc/n5;
.super Landroid/net/ConnectivityManager$NetworkCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/o5;


# direct methods
.method public constructor <init>(Lc/o5;)V
    .locals 0

    iput-object p1, p0, Lc/n5;->a:Lc/o5;

    invoke-direct {p0}, Landroid/net/ConnectivityManager$NetworkCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    sget-object v0, Lc/A8;->s:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    const-wide/16 v1, 0x0

    sput-wide v1, Lc/A8;->w:J

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, p0, Lc/n5;->a:Lc/o5;

    iget-object v1, v0, Lc/o5;->a:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->postInvalidate()V

    iget-object v1, v0, Lc/o5;->e:Lc/F3;

    if-eqz v1, :cond_0

    iget-object v0, v0, Lc/o5;->a:Landroid/view/View;

    new-instance v1, Lc/i;

    const/16 v2, 0xb

    invoke-direct {v1, p0, v2}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1
.end method

.method public final onAvailable(Landroid/net/Network;)V
    .locals 0

    invoke-virtual {p0}, Lc/n5;->a()V

    return-void
.end method

.method public final onCapabilitiesChanged(Landroid/net/Network;Landroid/net/NetworkCapabilities;)V
    .locals 0

    invoke-virtual {p0}, Lc/n5;->a()V

    return-void
.end method

.method public final onLinkPropertiesChanged(Landroid/net/Network;Landroid/net/LinkProperties;)V
    .locals 0

    invoke-virtual {p0}, Lc/n5;->a()V

    return-void
.end method

.method public final onLost(Landroid/net/Network;)V
    .locals 0

    invoke-virtual {p0}, Lc/n5;->a()V

    return-void
.end method
