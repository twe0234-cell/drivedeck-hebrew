.class public final synthetic Lc/h8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/v4;


# direct methods
.method public synthetic constructor <init>(Lc/v4;I)V
    .locals 0

    iput p2, p0, Lc/h8;->a:I

    iput-object p1, p0, Lc/h8;->b:Lc/v4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/h8;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, "su"

    const-string v1, "0"

    const-string v2, "id"

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/j8;->C([Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "-c"

    filled-new-array {v0, v1, v2}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/j8;->C([Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "rootAvailable="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "DriveDeckRoot"

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v1, Lc/j8;->b:Landroid/os/Handler;

    new-instance v2, Lc/K1;

    iget-object v3, p0, Lc/h8;->b:Lc/v4;

    const/4 v4, 0x4

    invoke-direct {v2, v3, v0, v4}, Lc/K1;-><init>(Ljava/lang/Object;ZI)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_0
    const/4 v0, 0x1

    iget-object v1, p0, Lc/h8;->b:Lc/v4;

    invoke-virtual {v1, v0}, Lc/v4;->a(Z)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
