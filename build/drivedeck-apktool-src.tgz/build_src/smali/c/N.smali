.class public final synthetic Lc/N;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILandroid/content/Context;Landroid/net/Uri;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p5, p0, Lc/N;->a:I

    iput p1, p0, Lc/N;->b:I

    iput-object p2, p0, Lc/N;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/N;->c:Ljava/lang/Object;

    iput-object p4, p0, Lc/N;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;ILjava/io/Serializable;Ljava/io/Serializable;I)V
    .locals 0

    .line 2
    iput p5, p0, Lc/N;->a:I

    iput-object p1, p0, Lc/N;->d:Ljava/lang/Object;

    iput p2, p0, Lc/N;->b:I

    iput-object p3, p0, Lc/N;->e:Ljava/lang/Object;

    iput-object p4, p0, Lc/N;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lc/K5;Landroid/bluetooth/BluetoothGatt;Landroid/os/Parcelable;II)V
    .locals 0

    .line 3
    iput p5, p0, Lc/N;->a:I

    iput-object p1, p0, Lc/N;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/N;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/N;->e:Ljava/lang/Object;

    iput p4, p0, Lc/N;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lc/Z7;Landroid/os/IBinder;ILjava/lang/String;)V
    .locals 1

    .line 4
    const/16 v0, 0xa

    iput v0, p0, Lc/N;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/N;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/N;->c:Ljava/lang/Object;

    iput p3, p0, Lc/N;->b:I

    iput-object p4, p0, Lc/N;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 5
    iput p5, p0, Lc/N;->a:I

    iput-object p1, p0, Lc/N;->d:Ljava/lang/Object;

    iput p2, p0, Lc/N;->b:I

    iput-object p3, p0, Lc/N;->c:Ljava/lang/Object;

    iput-object p4, p0, Lc/N;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .locals 13

    iget-object v0, p0, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, p0, Lc/N;->c:Ljava/lang/Object;

    check-cast v1, Landroid/net/Uri;

    iget v2, p0, Lc/N;->b:I

    iget-object v3, p0, Lc/N;->e:Ljava/lang/Object;

    check-cast v3, Lc/B0;

    const/16 v4, 0x1cf3

    const-string v5, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0444\u0430\u0439\u043b"

    if-ne v2, v4, :cond_2

    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v4, "wt"

    invoke-virtual {v2, v1, v4}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v1, :cond_0

    :try_start_1
    iget-object v2, v3, Lc/B0;->b:Ljava/lang/Object;

    check-cast v2, [B

    invoke-virtual {v1, v2}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V

    new-instance v1, Lc/H;

    const/16 v2, 0x1c

    invoke-direct {v1, v3, v0, v2}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto/16 :goto_6

    :catch_0
    move-exception v1

    goto/16 :goto_5

    :catchall_0
    move-exception v2

    goto :goto_0

    :cond_0
    :try_start_3
    new-instance v2, Ljava/io/IOException;

    invoke-direct {v2, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_0
    if-eqz v1, :cond_1

    :try_start_4
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    goto :goto_1

    :catchall_1
    move-exception v1

    :try_start_5
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    throw v2

    :cond_2
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v1
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    if-eqz v1, :cond_5

    :try_start_6
    new-instance v2, Ljava/lang/String;

    new-instance v4, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v4}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v5, 0x2000

    new-array v5, v5, [B

    const/4 v6, 0x0

    move v7, v6

    :goto_2
    invoke-virtual {v1, v5}, Ljava/io/InputStream;->read([B)I

    move-result v8

    const/4 v9, -0x1

    if-eq v8, v9, :cond_4

    add-int/2addr v7, v8

    int-to-long v9, v7

    const-wide/32 v11, 0x100000

    cmp-long v9, v9, v11

    if-gtz v9, :cond_3

    invoke-virtual {v4, v5, v6, v8}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_2

    :cond_3
    new-instance v2, Ljava/io/IOException;

    const-string v4, "\u0424\u0430\u0439\u043b PID \u0431\u043e\u043b\u044c\u0448\u0435 1 \u041c\u0438\u0411"

    invoke-direct {v2, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_4
    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v4

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, v4, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V

    new-instance v1, Lc/Z;

    const/16 v4, 0x15

    invoke-direct {v1, v3, v0, v2, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    goto :goto_6

    :catchall_2
    move-exception v2

    goto :goto_3

    :cond_5
    :try_start_8
    new-instance v2, Ljava/io/IOException;

    invoke-direct {v2, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    :goto_3
    if-eqz v1, :cond_6

    :try_start_9
    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception v1

    :try_start_a
    invoke-virtual {v2, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_6
    :goto_4
    throw v2
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    :goto_5
    new-instance v2, Lc/Z;

    const/16 v4, 0x16

    invoke-direct {v2, v3, v0, v1, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_6
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 21

    move-object/from16 v1, p0

    const/4 v2, 0x5

    const/4 v3, -0x1

    const/4 v4, 0x0

    const-string v5, ""

    const/16 v6, 0xd

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget v9, v1, Lc/N;->a:I

    packed-switch v9, :pswitch_data_0

    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/O;

    iget-object v0, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v0, Lc/g8;

    iget-boolean v2, v0, Lc/g8;->d:Z

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    iget v2, v1, Lc/N;->b:I

    iget-object v3, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    const/16 v4, 0xe

    if-ne v2, v8, :cond_2

    iget-object v8, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v8, [I

    if-eqz v8, :cond_2

    array-length v9, v8

    if-lez v9, :cond_2

    iget v9, v0, Lc/g8;->f:I

    aget v7, v8, v7

    if-eq v9, v7, :cond_1

    iput-object v5, v0, Lc/g8;->g:Ljava/lang/String;

    iput-object v5, v0, Lc/g8;->h:Ljava/lang/String;

    :cond_1
    iput v7, v0, Lc/g8;->f:I

    goto :goto_0

    :cond_2
    if-ne v2, v4, :cond_3

    iput-object v3, v0, Lc/g8;->g:Ljava/lang/String;

    goto :goto_0

    :cond_3
    if-ne v2, v6, :cond_4

    iput-object v3, v0, Lc/g8;->h:Ljava/lang/String;

    :cond_4
    :goto_0
    if-eq v2, v4, :cond_5

    if-ne v2, v6, :cond_6

    :cond_5
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    iget v2, v0, Lc/g8;->f:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    const-string v5, "update_id"

    const-string v7, "length"

    const-string v9, "frequency"

    filled-new-array/range {v5 .. v10}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "radio_rds"

    invoke-static {v3, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_6
    iget-object v0, v0, Lc/g8;->b:Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    :goto_1
    return-void

    :pswitch_0
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x1a

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Landroid/os/IBinder;

    invoke-static {v3, v2, v4}, Lc/Z7;->p(Landroid/os/IBinder;ILjava/lang/String;)Z

    move-result v2

    iget-object v3, v0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v4, Lc/Q7;

    iget v5, v1, Lc/N;->b:I

    iget-object v6, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v6, Ljava/lang/String;

    invoke-direct {v4, v0, v5, v6, v2}, Lc/Q7;-><init>(Lc/Z7;ILjava/lang/String;Z)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_1
    invoke-direct/range {p0 .. p0}, Lc/N;->a()V

    return-void

    :pswitch_2
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/K5;

    iget-object v0, v0, Lc/K5;->a:Lc/T5;

    iget-object v2, v0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Landroid/bluetooth/BluetoothGatt;

    if-ne v3, v2, :cond_a

    iget-object v2, v0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v3, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v3, Landroid/bluetooth/BluetoothGattCharacteristic;

    if-ne v3, v2, :cond_a

    iget-boolean v2, v0, Lc/T5;->U1:Z

    if-nez v2, :cond_7

    goto :goto_2

    :cond_7
    iput-boolean v7, v0, Lc/T5;->U1:Z

    iget v2, v1, Lc/N;->b:I

    if-eqz v2, :cond_9

    iget-boolean v2, v0, Lc/T5;->T1:Z

    if-eqz v2, :cond_8

    invoke-virtual {v0}, Lc/T5;->a0()V

    goto :goto_2

    :cond_8
    const-string v2, "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0435\u0440\u0435\u0434\u0430\u0447\u0438 OBD"

    invoke-virtual {v0, v2}, Lc/T5;->Q0(Ljava/lang/String;)V

    goto :goto_2

    :cond_9
    iget v2, v0, Lc/T5;->Q1:I

    add-int/2addr v2, v8

    iput v2, v0, Lc/T5;->Q1:I

    invoke-virtual {v0}, Lc/T5;->g1()V

    :cond_a
    :goto_2
    return-void

    :pswitch_3
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/K5;

    iget-object v0, v0, Lc/K5;->a:Lc/T5;

    iget-object v2, v0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Landroid/bluetooth/BluetoothGatt;

    if-ne v3, v2, :cond_d

    iget-object v2, v0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    iget-object v3, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v3, Landroid/bluetooth/BluetoothGattDescriptor;

    if-ne v3, v2, :cond_d

    iget-boolean v2, v0, Lc/T5;->T1:Z

    if-eqz v2, :cond_d

    iget-boolean v2, v0, Lc/T5;->V1:Z

    if-nez v2, :cond_b

    goto :goto_3

    :cond_b
    iput-boolean v7, v0, Lc/T5;->V1:Z

    iget v2, v1, Lc/N;->b:I

    if-eqz v2, :cond_c

    invoke-virtual {v0}, Lc/T5;->a0()V

    goto :goto_3

    :cond_c
    iget v2, v0, Lc/T5;->P1:I

    add-int/2addr v2, v8

    iput v2, v0, Lc/T5;->P1:I

    invoke-virtual {v0}, Lc/T5;->h1()V

    :cond_d
    :goto_3
    return-void

    :pswitch_4
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget v2, v1, Lc/N;->b:I

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Ljava/io/OutputStream;

    iget-object v4, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Exception;

    iget v5, v0, Lc/T5;->t:I

    if-ne v2, v5, :cond_e

    iget-object v2, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-ne v2, v3, :cond_e

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\u0421\u0432\u044f\u0437\u044c \u0441 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u043c \u043f\u043e\u0442\u0435\u0440\u044f\u043d\u0430: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lc/T5;->Q0(Ljava/lang/String;)V

    :cond_e
    return-void

    :pswitch_5
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    move-object v9, v0

    check-cast v9, Lc/T5;

    iget v10, v1, Lc/N;->b:I

    iget-object v0, v1, Lc/N;->c:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/io/OutputStream;

    iget-object v0, v1, Lc/N;->e:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Ljava/io/InputStream;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x400

    new-array v0, v0, [B

    new-instance v13, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v13}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    :catch_0
    :goto_4
    :try_start_0
    iget v2, v9, Lc/T5;->t:I

    if-ne v10, v2, :cond_12

    iget-object v2, v9, Lc/T5;->K:Ljava/io/OutputStream;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-ne v2, v11, :cond_12

    :try_start_1
    invoke-virtual {v12, v0}, Ljava/io/InputStream;->read([B)I

    move-result v2
    :try_end_1
    .catch Ljava/net/SocketTimeoutException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-ltz v2, :cond_11

    if-nez v2, :cond_f

    const-wide/16 v2, 0xa

    :try_start_2
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    goto :goto_4

    :catchall_0
    move-exception v0

    goto :goto_9

    :catch_1
    move-exception v0

    :goto_5
    move-object v6, v0

    goto :goto_7

    :catch_2
    move-exception v0

    goto :goto_5

    :cond_f
    invoke-virtual {v13, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const v4, 0x8000

    if-gt v3, v4, :cond_10

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v6

    iget-object v14, v9, Lc/T5;->c:Landroid/os/Handler;

    new-instance v15, Lc/F5;

    const/4 v8, 0x1

    move-object v2, v15

    move-object v3, v9

    move v4, v10

    move-object v5, v11

    move-object v7, v13

    invoke-direct/range {v2 .. v8}, Lc/F5;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v14, v15}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_4

    :cond_10
    new-instance v0, Ljava/io/IOException;

    const-string v2, "Receive queue overflow"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_11
    new-instance v0, Ljava/io/EOFException;

    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    throw v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_12
    :goto_6
    :try_start_3
    invoke-virtual {v12}, Ljava/io/InputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_8

    :goto_7
    :try_start_4
    iget-object v0, v9, Lc/T5;->c:Landroid/os/Handler;

    new-instance v8, Lc/N;

    const/4 v7, 0x6

    move-object v2, v8

    move-object v3, v9

    move v4, v10

    move-object v5, v11

    invoke-direct/range {v2 .. v7}, Lc/N;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_6

    :catch_3
    :goto_8
    return-void

    :goto_9
    :try_start_5
    invoke-virtual {v12}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4

    :catch_4
    throw v0

    :pswitch_6
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    iget v2, v1, Lc/N;->b:I

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Ljava/io/OutputStream;

    iget-object v4, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    iget v5, v0, Lc/T5;->t:I

    if-ne v2, v5, :cond_13

    iget-object v2, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-ne v2, v3, :cond_13

    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_13

    invoke-virtual {v0}, Lc/T5;->i1()V

    :cond_13
    return-void

    :pswitch_7
    iget-object v0, v1, Lc/N;->e:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    const/16 v0, 0x1d57

    iget v3, v1, Lc/N;->b:I

    iget-object v4, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v4, Landroid/content/Context;

    iget-object v5, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v5, Landroid/net/Uri;

    if-ne v3, v0, :cond_14

    :try_start_6
    invoke-static {v4, v5}, Lc/q4;->k(Landroid/content/Context;Landroid/net/Uri;)V

    new-instance v0, Lc/J1;

    const/16 v3, 0xc

    invoke-direct {v0, v2, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v2, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_b

    :catch_5
    move-exception v0

    goto :goto_a

    :cond_14
    invoke-static {v4, v5}, Lc/q4;->u(Landroid/content/Context;Landroid/net/Uri;)Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v4, v0}, Lc/q4;->z(Landroid/content/Context;Ljava/util/LinkedHashMap;)Lorg/json/JSONObject;

    move-result-object v3

    new-instance v4, Lc/n4;

    invoke-direct {v4, v2, v0, v3, v8}, Lc/n4;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/util/LinkedHashMap;Lorg/json/JSONObject;I)V

    invoke-virtual {v2, v4}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_5

    goto :goto_b

    :goto_a
    const-string v3, "DriveDeck"

    const-string v4, "Configuration file operation failed"

    invoke-static {v3, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v0, Lc/J1;

    invoke-direct {v0, v2, v6}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v2, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_b
    return-void

    :pswitch_8
    iget-object v6, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v6, Lc/P3;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v9, Ljava/lang/String;

    iget v10, v1, Lc/N;->b:I

    if-gtz v10, :cond_15

    goto/16 :goto_1e

    :cond_15
    :try_start_7
    const-string v11, "android.os.SystemProperties"

    invoke-static {v11}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v11

    const-string v12, "get"

    filled-new-array {v9, v9}, [Ljava/lang/Class;

    move-result-object v9

    invoke-virtual {v11, v12, v9}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v9

    const-string v11, "persist.syu.city"

    filled-new-array {v11, v5}, [Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v9, v4, v11}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9
    :try_end_7
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_7 .. :try_end_7} :catch_6
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_6

    goto :goto_c

    :catch_6
    move-object v9, v5

    :goto_c
    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v11

    if-gtz v10, :cond_16

    goto/16 :goto_1e

    :cond_16
    iget-object v12, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v12, Ljava/lang/String;

    if-nez v12, :cond_17

    move-object v12, v5

    goto :goto_d

    :cond_17
    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    :goto_d
    if-nez v9, :cond_18

    goto :goto_e

    :cond_18
    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    :goto_e
    new-instance v9, Ljava/io/File;

    const-string v13, "fmbd"

    invoke-direct {v9, v11, v13}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :try_start_8
    invoke-virtual {v11}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v14

    invoke-virtual {v9}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object v15

    invoke-virtual {v15}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/io/File;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_19

    :goto_f
    move-object v0, v4

    goto/16 :goto_17

    :cond_19
    new-instance v14, Ljava/io/File;

    const-string v15, "fmbd.txt"

    invoke-direct {v14, v9, v15}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/high16 v15, 0x200000

    invoke-static {v14, v9, v15}, Lc/k6;->o(Ljava/io/File;Ljava/io/File;I)[B

    move-result-object v14

    if-nez v14, :cond_1a

    goto :goto_f

    :cond_1a
    sget-object v15, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v15}, Ljava/nio/charset/Charset;->newDecoder()Ljava/nio/charset/CharsetDecoder;

    move-result-object v15

    invoke-static {v14}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v14

    invoke-virtual {v15, v14}, Ljava/nio/charset/CharsetDecoder;->decode(Ljava/nio/ByteBuffer;)Ljava/nio/CharBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/nio/CharBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v15, "\ufeff"

    invoke-virtual {v14, v15}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v15

    if-eqz v15, :cond_1b

    invoke-virtual {v14, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v14

    :cond_1b
    const-string v15, "\\|"

    invoke-virtual {v14, v15, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v14

    array-length v15, v14

    const/16 v4, 0x2710

    if-le v15, v4, :cond_1d

    :catch_7
    :cond_1c
    :goto_10
    const/4 v0, 0x0

    goto/16 :goto_17

    :cond_1d
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    new-instance v15, Ljava/util/HashSet;

    invoke-direct {v15}, Ljava/util/HashSet;-><init>()V

    array-length v0, v14

    move v13, v7

    move/from16 v19, v13

    :goto_11
    if-ge v13, v0, :cond_24

    aget-object v20, v14, v13

    invoke-virtual/range {v20 .. v20}, Ljava/lang/String;->length()I

    move-result v7

    const/16 v8, 0x1000

    if-le v7, v8, :cond_1e

    goto/16 :goto_13

    :cond_1e
    invoke-virtual/range {v20 .. v20}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    const-string v8, ","

    invoke-virtual {v7, v8, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v7

    array-length v8, v7

    if-eq v8, v2, :cond_1f

    goto :goto_13

    :cond_1f
    const/4 v8, 0x0

    :goto_12
    array-length v3, v7

    if-ge v8, v3, :cond_20

    aget-object v3, v7, v8

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v7, v8

    const/4 v3, 0x1

    add-int/2addr v8, v3

    goto :goto_12

    :cond_20
    const/4 v3, 0x0

    aget-object v8, v7, v3

    const-string v3, "[0-9]{1,12}"

    invoke-virtual {v8, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_23

    const/4 v3, 0x1

    aget-object v8, v7, v3

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_23

    const/4 v3, 0x3

    aget-object v8, v7, v3

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v3
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_7
    .catch Ljava/lang/SecurityException; {:try_start_8 .. :try_end_8} :catch_7

    if-eqz v3, :cond_21

    goto :goto_13

    :cond_21
    :try_start_9
    new-instance v3, Ljava/math/BigDecimal;

    const/4 v8, 0x4

    aget-object v8, v7, v8

    invoke-direct {v3, v8}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    invoke-virtual {v3, v8}, Ljava/math/BigDecimal;->movePointRight(I)Ljava/math/BigDecimal;

    move-result-object v3

    invoke-virtual {v3}, Ljava/math/BigDecimal;->intValueExact()I

    move-result v3
    :try_end_9
    .catch Ljava/lang/NumberFormatException; {:try_start_9 .. :try_end_9} :catch_8
    .catch Ljava/lang/ArithmeticException; {:try_start_9 .. :try_end_9} :catch_8
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_7
    .catch Ljava/lang/SecurityException; {:try_start_9 .. :try_end_9} :catch_7

    const/16 v8, 0x1964

    if-lt v3, v8, :cond_23

    const/16 v8, 0x2a30

    if-le v3, v8, :cond_22

    goto :goto_13

    :cond_22
    const/4 v8, 0x1

    :try_start_a
    aget-object v2, v7, v8

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v8}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v15, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    aget-object v8, v7, v2

    invoke-virtual {v8, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    or-int v19, v19, v2

    if-ne v3, v10, :cond_23

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :catch_8
    :cond_23
    :goto_13
    const/4 v2, 0x1

    add-int/2addr v13, v2

    move v8, v2

    const/4 v2, 0x5

    const/4 v3, -0x1

    const/4 v7, 0x0

    goto/16 :goto_11

    :cond_24
    if-nez v19, :cond_25

    invoke-virtual {v15}, Ljava/util/HashSet;->size()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_1c

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_25

    const-string v0, "[0-9]+"

    invoke-virtual {v5, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_25

    :goto_14
    goto/16 :goto_10

    :cond_25
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_26
    :goto_15
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_28

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    if-eqz v19, :cond_27

    const/4 v4, 0x1

    aget-object v7, v3, v4

    invoke-virtual {v7, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_26

    :cond_27
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_15

    :cond_28
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-le v2, v3, :cond_2b

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_29
    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2a

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    const/4 v4, 0x3

    aget-object v7, v3, v4

    invoke-virtual {v7, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_29

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_16

    :cond_2a
    move-object v0, v2

    :cond_2b
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x1

    if-eq v2, v3, :cond_2c

    goto :goto_14

    :cond_2c
    new-instance v2, Ljava/io/File;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    aget-object v0, v0, v4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ".bmp"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v9, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v2, v9}, Lc/k6;->A(Ljava/io/File;Ljava/io/File;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_7
    .catch Ljava/lang/SecurityException; {:try_start_a .. :try_end_a} :catch_7

    :goto_17
    if-eqz v0, :cond_2d

    move-object v4, v0

    goto/16 :goto_1e

    :cond_2d
    invoke-static {v10}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    int-to-float v3, v10

    const/high16 v4, 0x42c80000    # 100.0f

    div-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%.2f"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "0"

    invoke-virtual {v2, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2e

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    goto :goto_18

    :cond_2e
    move-object v3, v2

    :goto_18
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    const-string v8, "radio_logo"

    if-nez v7, :cond_2f

    const-string v7, "."

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_2f

    const-string v7, ".."

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_2f

    const/16 v7, 0x2f

    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-gez v7, :cond_2f

    const/16 v7, 0x5c

    invoke-virtual {v5, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v7

    if-gez v7, :cond_2f

    new-instance v7, Ljava/io/File;

    new-instance v9, Ljava/io/File;

    invoke-direct {v9, v11, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v7, v9, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2f
    const-string v5, "radiologo"

    const-string v7, "RadioPC"

    filled-new-array {v8, v5, v7}, [Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v8, 0x3

    :goto_19
    if-ge v7, v8, :cond_30

    aget-object v9, v5, v7

    new-instance v10, Ljava/io/File;

    invoke-direct {v10, v11, v9}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x1

    add-int/2addr v7, v9

    goto :goto_19

    :cond_30
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :catch_9
    :cond_31
    :goto_1a
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_37

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/io/File;

    :try_start_b
    invoke-virtual {v5}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v7
    :try_end_b
    .catch Ljava/lang/SecurityException; {:try_start_b .. :try_end_b} :catch_9

    if-nez v7, :cond_32

    goto :goto_1a

    :cond_32
    array-length v8, v7

    const/4 v9, 0x0

    :goto_1b
    if-ge v9, v8, :cond_31

    aget-object v10, v7, v9

    invoke-virtual {v10}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0x2e

    invoke-virtual {v11, v13}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v13

    const/4 v14, 0x1

    if-ge v13, v14, :cond_33

    move v10, v14

    goto :goto_1d

    :cond_33
    add-int/lit8 v15, v13, 0x1

    invoke-virtual {v11, v15}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v14

    sget-object v15, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v14, v15}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "png"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_35

    const-string v15, "jpg"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_35

    const-string v15, "jpeg"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_35

    const-string v15, "webp"

    invoke-virtual {v14, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_35

    :cond_34
    :goto_1c
    const/4 v10, 0x1

    goto :goto_1d

    :cond_35
    const/4 v14, 0x0

    invoke-virtual {v11, v14, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    const/16 v13, 0x5f

    invoke-virtual {v11, v13}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v13

    const/4 v14, 0x1

    add-int/2addr v13, v14

    invoke-virtual {v11, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v12}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_36

    invoke-virtual {v13, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_36

    invoke-virtual {v13, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_36

    invoke-virtual {v13, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_36

    goto :goto_1c

    :cond_36
    invoke-static {v10, v5}, Lc/k6;->A(Ljava/io/File;Ljava/io/File;)Landroid/graphics/Bitmap;

    move-result-object v10

    if-eqz v10, :cond_34

    move-object v4, v10

    goto :goto_1e

    :goto_1d
    add-int/2addr v9, v10

    goto :goto_1b

    :cond_37
    const/4 v4, 0x0

    :goto_1e
    iget-object v0, v6, Lc/P3;->W0:Landroid/os/Handler;

    new-instance v2, Lc/G3;

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x0

    invoke-direct {v2, v6, v3, v4, v5}, Lc/G3;-><init>(Lc/P3;Ljava/lang/String;Landroid/graphics/Bitmap;I)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_9
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    iget-object v2, v0, Lc/k3;->c:Lc/n1;

    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v3, 0xbb8

    iget v4, v1, Lc/N;->b:I

    if-eq v4, v3, :cond_39

    const/16 v3, 0x1388

    if-ne v4, v3, :cond_38

    goto :goto_1f

    :cond_38
    const/16 v3, 0x5dc

    goto :goto_20

    :cond_39
    :goto_1f
    move v3, v4

    :goto_20
    const-string v5, "dock_auto_hide_delay_ms"

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v2, 0x0

    :goto_21
    iget-object v3, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v3, [Landroid/widget/TextView;

    array-length v5, v3

    if-ge v2, v5, :cond_3c

    iget-object v5, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v5, [I

    aget v5, v5, v2

    if-ne v5, v4, :cond_3a

    const/4 v5, 0x1

    goto :goto_22

    :cond_3a
    const/4 v5, 0x0

    :goto_22
    aget-object v6, v3, v2

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setSelected(Z)V

    aget-object v3, v3, v2

    if-eqz v5, :cond_3b

    invoke-virtual {v0}, Lc/k3;->o0()I

    move-result v5

    goto :goto_23

    :cond_3b
    const/4 v5, 0x0

    :goto_23
    invoke-virtual {v0, v5}, Lc/k3;->h0(I)Landroid/graphics/drawable/RippleDrawable;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x1

    add-int/2addr v2, v3

    goto :goto_21

    :cond_3c
    return-void

    :pswitch_a
    iget-object v0, v1, Lc/N;->d:Ljava/lang/Object;

    check-cast v0, Lc/O;

    iget v2, v1, Lc/N;->b:I

    iget-object v3, v1, Lc/N;->c:Ljava/lang/Object;

    check-cast v3, [I

    iget-object v4, v1, Lc/N;->e:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    iget-object v7, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v7, Lc/P;

    iget-boolean v8, v7, Lc/P;->f:Z

    if-nez v8, :cond_3d

    goto/16 :goto_32

    :cond_3d
    iget-object v7, v7, Lc/P;->a:Lc/K;

    iget-boolean v8, v7, Lc/K;->f:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v9

    if-eqz v3, :cond_3f

    array-length v11, v3

    if-nez v11, :cond_3e

    goto :goto_24

    :cond_3e
    const/4 v11, 0x0

    aget v12, v3, v11

    goto :goto_25

    :cond_3f
    :goto_24
    const/4 v12, -0x1

    :goto_25
    const/16 v11, 0x2d

    const/16 v13, 0x2c

    const/16 v14, 0x9

    if-ne v2, v14, :cond_43

    const/4 v15, 0x2

    if-lt v12, v15, :cond_40

    const/4 v9, 0x5

    if-le v12, v9, :cond_41

    :cond_40
    const/4 v9, 0x7

    if-ne v12, v9, :cond_42

    :cond_41
    const/4 v9, 0x1

    goto :goto_26

    :cond_42
    const/4 v9, 0x0

    :goto_26
    iput-boolean v9, v7, Lc/K;->f:Z

    if-nez v9, :cond_50

    invoke-virtual {v7}, Lc/K;->b()V

    goto/16 :goto_2f

    :cond_43
    const-wide/16 v18, 0x3e8

    const/4 v15, 0x2

    if-ne v2, v15, :cond_45

    if-lez v12, :cond_44

    int-to-long v9, v12

    mul-long v15, v9, v18

    move-wide v9, v15

    goto :goto_27

    :cond_44
    const-wide/16 v9, -0x1

    :goto_27
    iput-wide v9, v7, Lc/K;->a:J

    goto/16 :goto_2f

    :cond_45
    const/16 v15, 0x1c

    if-ne v2, v15, :cond_47

    if-ltz v12, :cond_46

    int-to-long v14, v12

    mul-long v14, v14, v18

    goto :goto_28

    :cond_46
    const-wide/16 v14, -0x1

    :goto_28
    iput-wide v14, v7, Lc/K;->b:J

    iput-wide v9, v7, Lc/K;->c:J

    goto/16 :goto_2f

    :cond_47
    if-ne v2, v6, :cond_4a

    invoke-virtual {v7, v9, v10}, Lc/K;->a(J)J

    move-result-wide v14

    const-wide/16 v17, 0x0

    cmp-long v17, v14, v17

    if-ltz v17, :cond_48

    iput-wide v14, v7, Lc/K;->b:J

    iput-wide v9, v7, Lc/K;->c:J

    :cond_48
    const/4 v9, 0x1

    if-ne v12, v9, :cond_49

    const/4 v9, 0x1

    goto :goto_29

    :cond_49
    const/4 v9, 0x0

    :goto_29
    iput-boolean v9, v7, Lc/K;->g:Z

    goto :goto_2f

    :cond_4a
    if-ne v2, v13, :cond_4d

    :try_start_c
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9
    :try_end_c
    .catch Ljava/lang/NumberFormatException; {:try_start_c .. :try_end_c} :catch_a
    .catch Ljava/lang/NullPointerException; {:try_start_c .. :try_end_c} :catch_a

    if-ltz v9, :cond_4b

    const/4 v10, 0x5

    if-gt v9, v10, :cond_4b

    goto :goto_2a

    :catch_a
    :cond_4b
    const/4 v9, -0x1

    :goto_2a
    iput v9, v7, Lc/K;->d:I

    if-gez v9, :cond_50

    if-ltz v12, :cond_4c

    const/4 v9, 0x5

    if-gt v12, v9, :cond_4c

    goto :goto_2b

    :cond_4c
    const/4 v12, -0x1

    :goto_2b
    iput v12, v7, Lc/K;->d:I

    goto :goto_2f

    :cond_4d
    const/4 v9, 0x5

    if-ne v2, v11, :cond_50

    if-ltz v12, :cond_4e

    if-gt v12, v9, :cond_4e

    goto :goto_2c

    :cond_4e
    const/4 v12, -0x1

    :goto_2c
    iput v12, v7, Lc/K;->e:I

    if-gez v12, :cond_50

    :try_start_d
    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9
    :try_end_d
    .catch Ljava/lang/NumberFormatException; {:try_start_d .. :try_end_d} :catch_b
    .catch Ljava/lang/NullPointerException; {:try_start_d .. :try_end_d} :catch_b

    if-ltz v9, :cond_4f

    const/4 v10, 0x5

    if-gt v9, v10, :cond_4f

    move/from16 v20, v9

    goto :goto_2d

    :cond_4f
    const/16 v20, -0x1

    :goto_2d
    move/from16 v9, v20

    goto :goto_2e

    :catch_b
    const/4 v9, -0x1

    :goto_2e
    iput v9, v7, Lc/K;->e:I

    :cond_50
    :goto_2f
    if-nez v2, :cond_51

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    iput-object v4, v2, Lc/P;->l:Ljava/lang/String;

    goto :goto_31

    :cond_51
    const/4 v7, 0x1

    if-ne v2, v7, :cond_52

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    iput-object v4, v2, Lc/P;->m:Ljava/lang/String;

    goto :goto_31

    :cond_52
    if-ne v2, v6, :cond_54

    if-eqz v3, :cond_54

    array-length v4, v3

    if-lez v4, :cond_54

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    const/4 v4, 0x0

    aget v3, v3, v4

    const/4 v4, 0x1

    if-ne v3, v4, :cond_53

    const/4 v7, 0x1

    goto :goto_30

    :cond_53
    const/4 v7, 0x0

    :goto_30
    iput-boolean v7, v2, Lc/P;->n:Z

    goto :goto_31

    :cond_54
    const/16 v3, 0x9

    if-ne v2, v3, :cond_56

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    iget-object v3, v2, Lc/P;->a:Lc/K;

    iget-boolean v3, v3, Lc/K;->f:Z

    iput-boolean v3, v2, Lc/P;->o:Z

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    iget-boolean v2, v2, Lc/P;->o:Z

    if-nez v2, :cond_55

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    iput-object v5, v2, Lc/P;->m:Ljava/lang/String;

    iput-object v5, v2, Lc/P;->l:Ljava/lang/String;

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    const/4 v3, 0x0

    iput-boolean v3, v2, Lc/P;->n:Z

    goto :goto_31

    :cond_55
    if-nez v8, :cond_56

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    const/4 v3, 0x1

    invoke-virtual {v2, v13, v3}, Lc/P;->e(IZ)V

    iget-object v2, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/P;

    invoke-virtual {v2, v11, v3}, Lc/P;->e(IZ)V

    :cond_56
    :goto_31
    iget-object v0, v0, Lc/O;->b:Landroid/content/ServiceConnection;

    check-cast v0, Lc/P;

    iget-object v0, v0, Lc/P;->d:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :goto_32
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
