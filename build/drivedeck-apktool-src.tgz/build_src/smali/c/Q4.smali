.class public final synthetic Lc/Q4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/P4;JILandroid/content/BroadcastReceiver$PendingResult;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/Q4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q4;->d:Ljava/lang/Object;

    iput-wide p2, p0, Lc/Q4;->b:J

    iput p4, p0, Lc/Q4;->c:I

    iput-object p5, p0, Lc/Q4;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/v7;Lc/q2;JI)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/Q4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q4;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/Q4;->e:Ljava/lang/Object;

    iput-wide p3, p0, Lc/Q4;->b:J

    iput p5, p0, Lc/Q4;->c:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    iget v0, p0, Lc/Q4;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/Q4;->d:Ljava/lang/Object;

    check-cast v0, Lc/v7;

    iget-wide v0, v0, Lc/v7;->O:J

    iget-wide v2, p0, Lc/Q4;->b:J

    cmp-long v0, v2, v0

    if-nez v0, :cond_0

    iget v0, p0, Lc/Q4;->c:I

    goto :goto_0

    :cond_0
    const/4 v0, 0x5

    :goto_0
    iget-object v1, p0, Lc/Q4;->e:Ljava/lang/Object;

    check-cast v1, Lc/q2;

    invoke-virtual {v1, v0}, Lc/q2;->a(I)V

    return-void

    :pswitch_0
    iget-wide v3, p0, Lc/Q4;->b:J

    iget v8, p0, Lc/Q4;->c:I

    iget-object v0, p0, Lc/Q4;->e:Ljava/lang/Object;

    check-cast v0, Landroid/content/BroadcastReceiver$PendingResult;

    iget-object v1, p0, Lc/Q4;->d:Ljava/lang/Object;

    check-cast v1, Lc/P4;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v1, v1, Lc/P4;->b:Lru/drivedeck/launcher/MainActivity;

    new-instance v10, Landroid/view/KeyEvent;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    const/4 v7, 0x1

    const/4 v9, 0x0

    move-object v2, v10

    invoke-direct/range {v2 .. v9}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-virtual {v1, v10}, Lru/drivedeck/launcher/MainActivity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/BroadcastReceiver$PendingResult;->setResultCode(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    return-void

    :catchall_0
    move-exception v1

    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    throw v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
