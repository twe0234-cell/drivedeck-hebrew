.class public final synthetic Lc/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/c;->a:I

    iput-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget v0, p0, Lc/c;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/z3;

    invoke-virtual {p1}, Lc/z3;->run()V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/z3;

    invoke-virtual {p1}, Lc/z3;->run()V

    return-void

    :pswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-lez v3, :cond_0

    const-string v3, "\n\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    invoke-virtual {v2}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    goto :goto_0

    :cond_1
    invoke-static {p1, v0}, Lc/G8;->K0(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_2

    const/16 v0, 0x8

    goto :goto_1

    :cond_2
    const/4 v0, 0x0

    :goto_1
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    return-void

    :pswitch_3
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/i2;

    invoke-virtual {p1}, Lc/i2;->run()V

    return-void

    :pswitch_4
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Landroid/app/Activity;

    instance-of v0, p1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v0, :cond_6

    check-cast p1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lc/N1;->X:Lc/N1;

    if-eqz v0, :cond_3

    sget-object v0, Lc/N1;->X:Lc/N1;

    iget-boolean v0, v0, Lc/N1;->K:Z

    if-eqz v0, :cond_3

    goto :goto_2

    :cond_3
    invoke-static {}, Lc/N1;->s()I

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "\u0413\u043e\u0442\u043e\u0432\u044b\u0445 \u043e\u0442\u0447\u0451\u0442\u043e\u0432 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442"

    const/4 v1, 0x1

    invoke-static {p1, v0, p1, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_3

    :cond_4
    :goto_2
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.CREATE_DOCUMENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.intent.category.OPENABLE"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "application/zip"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "DriveDeck-diagnostics-"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ".zip"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "android.intent.extra.TITLE"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/16 v1, 0x1ceb

    :try_start_0
    invoke-virtual {p1, v0, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    sget-object v0, Lc/N1;->X:Lc/N1;

    if-nez v0, :cond_5

    goto :goto_3

    :cond_5
    iget-object v1, v0, Lc/N1;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v2, Lc/H;

    const/4 v3, 0x3

    invoke-direct {v2, v0, p1, v3}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_6
    :goto_3
    return-void

    :pswitch_5
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/g1;

    iget-object p1, p1, Lc/g1;->W:Landroid/app/AlertDialog;

    if-eqz p1, :cond_7

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    :cond_7
    return-void

    :pswitch_6
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/Q0;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void

    :pswitch_7
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/M0;

    invoke-virtual {p1}, Lc/M0;->run()V

    return-void

    :pswitch_8
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/e0;

    invoke-virtual {p1}, Lc/e0;->d()V

    return-void

    :pswitch_9
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/Z;

    invoke-virtual {p1}, Lc/Z;->run()V

    return-void

    :pswitch_a
    iget-object p1, p0, Lc/c;->b:Ljava/lang/Object;

    check-cast p1, Lc/j;

    invoke-virtual {p1}, Lc/j;->dismiss()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
