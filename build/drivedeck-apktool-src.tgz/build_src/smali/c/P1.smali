.class public final Lc/P1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroid/widget/TextView;

.field public final synthetic b:Landroid/app/Activity;

.field public final synthetic c:Landroid/widget/Button;

.field public final synthetic d:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/widget/TextView;Landroid/app/Activity;Landroid/widget/Button;Landroid/os/Handler;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/P1;->a:Landroid/widget/TextView;

    iput-object p2, p0, Lc/P1;->b:Landroid/app/Activity;

    iput-object p3, p0, Lc/P1;->c:Landroid/widget/Button;

    iput-object p4, p0, Lc/P1;->d:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget-object v0, p0, Lc/P1;->b:Landroid/app/Activity;

    invoke-static {}, Lc/N1;->B()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/P1;->a:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {}, Lc/N1;->s()I

    move-result v0

    if-lez v0, :cond_0

    invoke-static {}, Lc/N1;->p()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Lc/N1;->o()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lc/P1;->c:Landroid/widget/Button;

    invoke-virtual {v1, v0}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p0, Lc/P1;->d:Landroid/os/Handler;

    const-wide/16 v1, 0x7d0

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
