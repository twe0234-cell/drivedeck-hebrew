.class public final synthetic Lc/H4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/H4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/H4;->b:J

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 5

    iget-object v0, p0, Lc/H4;->a:Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->j0:J

    iget-wide v3, p0, Lc/H4;->b:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_0

    if-ltz p1, :cond_0

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->g0:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge p1, v1, :cond_0

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->g0:Ljava/util/List;

    invoke-interface {v1, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/Q;

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->r(Lc/Q;)V

    :cond_0
    return-void
.end method
