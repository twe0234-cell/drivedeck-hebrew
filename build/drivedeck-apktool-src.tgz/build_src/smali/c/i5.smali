.class public final Lc/i5;
.super Landroid/media/browse/MediaBrowser$ConnectionCallback;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:J

.field public final synthetic d:Lc/y4;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Landroid/os/Bundle;

.field public final synthetic h:Lc/u0;


# direct methods
.method public constructor <init>(Lc/u0;IIJLc/y4;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 0

    iput-object p1, p0, Lc/i5;->h:Lc/u0;

    iput p2, p0, Lc/i5;->a:I

    iput p3, p0, Lc/i5;->b:I

    iput-wide p4, p0, Lc/i5;->c:J

    iput-object p6, p0, Lc/i5;->d:Lc/y4;

    iput-object p7, p0, Lc/i5;->e:Ljava/lang/String;

    iput-object p8, p0, Lc/i5;->f:Ljava/lang/String;

    iput-object p9, p0, Lc/i5;->g:Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/media/browse/MediaBrowser$ConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .locals 5

    iget v0, p0, Lc/i5;->b:I

    iget-wide v1, p0, Lc/i5;->c:J

    iget-object v3, p0, Lc/i5;->h:Lc/u0;

    iget v4, p0, Lc/i5;->a:I

    invoke-virtual {v3, v4, v0, v1, v2}, Lc/u0;->n(IIJ)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {v3}, Lc/u0;->b()V

    if-nez p1, :cond_2

    iget-object p1, p0, Lc/i5;->e:Ljava/lang/String;

    iget-object v0, p0, Lc/i5;->f:Ljava/lang/String;

    invoke-virtual {v3, p1, v0}, Lc/u0;->h(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 p1, 0x1

    :goto_1
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iget-object v0, p0, Lc/i5;->d:Lc/y4;

    invoke-virtual {v0, p1}, Lc/y4;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public final onConnected()V
    .locals 5

    iget v0, p0, Lc/i5;->b:I

    iget-wide v1, p0, Lc/i5;->c:J

    iget-object v3, p0, Lc/i5;->h:Lc/u0;

    iget v4, p0, Lc/i5;->a:I

    invoke-virtual {v3, v4, v0, v1, v2}, Lc/u0;->n(IIJ)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, v3, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/media/browse/MediaBrowser;

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    new-instance v0, Landroid/media/session/MediaController;

    iget-object v1, v3, Lc/u0;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v3, Lc/u0;->d:Ljava/lang/Object;

    check-cast v2, Landroid/media/browse/MediaBrowser;

    invoke-virtual {v2}, Landroid/media/browse/MediaBrowser;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/media/session/MediaController;-><init>(Landroid/content/Context;Landroid/media/session/MediaSession$Token;)V

    iget-object v1, p0, Lc/i5;->f:Ljava/lang/String;

    iget-object v2, p0, Lc/i5;->g:Landroid/os/Bundle;

    invoke-virtual {v3, v0, v1, v2}, Lc/u0;->t(Landroid/media/session/MediaController;Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0}, Lc/i5;->a(Z)V

    :cond_1
    :goto_1
    return-void
.end method

.method public final onConnectionFailed()V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/i5;->a(Z)V

    return-void
.end method

.method public final onConnectionSuspended()V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/i5;->a(Z)V

    return-void
.end method
