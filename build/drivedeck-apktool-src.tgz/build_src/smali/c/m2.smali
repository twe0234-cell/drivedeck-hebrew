.class public final Lc/m2;
.super Lc/F;
.source "SourceFile"

# interfaces
.implements Lc/s2;


# instance fields
.field public final A:Landroid/graphics/RectF;

.field public B:Lc/W3;

.field public C:I

.field public D:Z

.field public E:Z

.field public F:Z

.field public G:Ljava/lang/String;

.field public H:F

.field public I:Z

.field public J:Z

.field public K:Ljava/lang/String;

.field public L:J

.field public final M:[Z

.field public N:Z

.field public O:I

.field public P:F

.field public Q:F

.field public R:F

.field public S:Z

.field public final t:[Lc/t2;

.field public final u:Lc/b2;

.field public final v:Lc/z;

.field public final w:Lc/l2;

.field public final x:Lc/M4;

.field public final y:Lc/n1;

.field public final z:Landroid/graphics/Paint;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/M4;)V
    .locals 5

    invoke-direct {p0, p1}, Lc/F;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    const/4 v0, 0x2

    new-array v1, v0, [Lc/t2;

    iput-object v1, p0, Lc/m2;->t:[Lc/t2;

    new-instance v2, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lc/m2;->z:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/m2;->A:Landroid/graphics/RectF;

    const/high16 v2, 0x3f000000    # 0.5f

    iput v2, p0, Lc/m2;->H:F

    iput-boolean v3, p0, Lc/m2;->J:Z

    const-string v2, ""

    iput-object v2, p0, Lc/m2;->K:Ljava/lang/String;

    new-array v0, v0, [Z

    iput-object v0, p0, Lc/m2;->M:[Z

    iput-object p2, p0, Lc/m2;->v:Lc/z;

    iput-object p4, p0, Lc/m2;->x:Lc/M4;

    iput-object p3, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {p3}, Lc/n1;->I()F

    move-result v0

    iput v0, p0, Lc/m2;->H:F

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v2, Lc/t2;

    invoke-virtual {p3, v0}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, p1, v0, v4, p0}, Lc/t2;-><init>(Lru/drivedeck/launcher/MainActivity;ILjava/lang/String;Lc/s2;)V

    aput-object v2, v1, v0

    new-instance v2, Lc/t2;

    invoke-virtual {p3, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, p1, v3, v4, p0}, Lc/t2;-><init>(Lru/drivedeck/launcher/MainActivity;ILjava/lang/String;Lc/s2;)V

    aput-object v2, v1, v3

    aget-object v0, v1, v0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    aget-object v0, v1, v3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Lc/l2;

    invoke-direct {v0, p1}, Lc/l2;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object v0, p0, Lc/m2;->w:Lc/l2;

    new-instance v1, Lc/A;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Lc/A;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0440\u0430\u0437\u043c\u0435\u0440 \u043e\u043a\u043e\u043d"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Lc/b2;

    invoke-virtual {p3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object p3

    new-instance v1, Lc/v8;

    const/4 v2, 0x3

    invoke-direct {v1, p4, v2}, Lc/v8;-><init>(Ljava/lang/Object;I)V

    invoke-direct {v0, p1, p2, p3, v1}, Lc/b2;-><init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;)V

    iput-object v0, p0, Lc/m2;->u:Lc/b2;

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iput-object v0, p0, Lc/F;->l:Landroid/view/View;

    new-instance p1, Lc/B;

    const/4 p2, 0x1

    invoke-direct {p1, p0, p2}, Lc/B;-><init>(Lc/F;I)V

    iput-object p1, v0, Lc/b2;->d:Ljava/util/function/Consumer;

    iget-boolean p2, v0, Lc/b2;->c:Z

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    invoke-virtual {p1, p2}, Lc/B;->accept(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lc/m2;->C()V

    return-void
.end method


# virtual methods
.method public final A(Ljava/lang/String;I)V
    .locals 15

    move-object v0, p0

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, v0, Lc/m2;->K:Ljava/lang/String;

    move-object/from16 v3, p1

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    iget-boolean v1, v0, Lc/m2;->N:Z

    if-eqz v1, :cond_0

    goto/16 :goto_4

    :cond_0
    iget-object v1, v0, Lc/m2;->M:[Z

    const/4 v2, 0x1

    aput-boolean v2, v1, p2

    const/4 v4, 0x0

    aget-boolean v5, v1, v4

    if-eqz v5, :cond_7

    aget-boolean v1, v1, v2

    if-nez v1, :cond_1

    goto/16 :goto_4

    :cond_1
    iput-boolean v2, v0, Lc/m2;->N:Z

    iget-object v1, v0, Lc/m2;->t:[Lc/t2;

    aget-object v5, v1, v4

    invoke-virtual {v5}, Lc/t2;->y()I

    move-result v5

    aget-object v6, v1, v2

    invoke-virtual {v6}, Lc/t2;->y()I

    move-result v6

    aget-object v7, v1, v4

    iget-object v7, v7, Lc/t2;->u:Ljava/lang/String;

    aget-object v8, v1, v2

    iget-object v8, v8, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v7}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_3

    aget-object v9, v1, v2

    iget-object v9, v9, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v9}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    invoke-static {v9, v7, v6}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v7

    goto :goto_1

    :cond_3
    :goto_0
    move v7, v4

    :goto_1
    aget-object v9, v1, v4

    iget-object v9, v9, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v9}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_5

    aget-object v1, v1, v2

    iget-object v1, v1, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, v8, v5}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v4

    :cond_5
    :goto_2
    if-nez v7, :cond_6

    if-nez v4, :cond_6

    const-string v1, "pair_switch_completed"

    goto :goto_3

    :cond_6
    const-string v1, "pair_switch_placement_unconfirmed"

    :goto_3
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-wide v12, v0, Lc/m2;->L:J

    sub-long/2addr v6, v12

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v13

    const-string v10, "right_on_left"

    const-string v12, "tap_to_both_confirmed_ms"

    const-string v2, "pair_switch_id"

    const-string v4, "left_display"

    const-string v6, "right_display"

    const-string v14, "left_on_right"

    move-object/from16 v3, p1

    move-object v7, v8

    move-object v8, v14

    filled-new-array/range {v2 .. v13}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_7
    :goto_4
    return-void
.end method

.method public final B(Ljava/lang/String;)Lc/t2;
    .locals 5

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    iget-object v4, v3, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-object v3

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final C()V
    .locals 4

    iget-object v0, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->a0()Z

    move-result v1

    iput-boolean v1, p0, Lc/m2;->E:Z

    invoke-virtual {v0}, Lc/n1;->j0()Z

    move-result v1

    iput-boolean v1, p0, Lc/m2;->F:Z

    invoke-virtual {v0}, Lc/n1;->T()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc/m2;->G:Ljava/lang/String;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/m2;->D:Z

    iget v1, p0, Lc/m2;->C:I

    add-int/2addr v1, v0

    iput v1, p0, Lc/m2;->C:I

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    new-instance v2, Lc/j2;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v1, v3}, Lc/j2;-><init>(Landroid/view/ViewGroup;II)V

    invoke-static {v0, v2}, Lc/X3;->f(Landroid/content/Context;Ljava/util/function/Consumer;)V

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final D()V
    .locals 6

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_1

    aget-object v3, v0, v2

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v4

    if-nez v4, :cond_0

    new-instance v4, Lc/i2;

    const/4 v5, 0x0

    invoke-direct {v4, v3, v5}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v3, v4}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final E()V
    .locals 4

    invoke-virtual {p0}, Lc/m2;->C()V

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    invoke-virtual {v3}, Lc/t2;->K()V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, p0, Lc/m2;->w:Lc/l2;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final F()V
    .locals 4

    iget v0, p0, Lc/m2;->O:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lc/m2;->O:I

    iget v0, p0, Lc/m2;->C:I

    add-int/2addr v0, v1

    iput v0, p0, Lc/m2;->C:I

    const/4 v0, 0x0

    iput-object v0, p0, Lc/m2;->B:Lc/W3;

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    const/4 v2, 0x0

    aget-object v3, v0, v2

    invoke-virtual {v3}, Lc/t2;->i()V

    aget-object v3, v0, v1

    invoke-virtual {v3}, Lc/t2;->i()V

    aget-object v2, v0, v2

    invoke-virtual {v2}, Lc/t2;->L()V

    aget-object v0, v0, v1

    invoke-virtual {v0}, Lc/t2;->L()V

    return-void
.end method

.method public final G(Z)V
    .locals 8

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-object v3, v0, v2

    iput-boolean p1, v3, Lc/t2;->C:Z

    iget-wide v4, v3, Lc/t2;->H:J

    const-wide/16 v6, 0x1

    add-long/2addr v4, v6

    iput-wide v4, v3, Lc/t2;->H:J

    const/4 v6, 0x0

    invoke-virtual {v3, p1, v4, v5, v6}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final H()V
    .locals 9

    iget-object v0, p0, Lc/m2;->y:Lc/n1;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v3

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lc/n1;->I()F

    move-result v5

    invoke-virtual {p0}, Lc/F;->f()Z

    const/4 v6, -0x1

    const-wide/16 v7, 0x0

    move-object v2, p0

    invoke-virtual/range {v2 .. v8}, Lc/m2;->J(Ljava/lang/String;Ljava/lang/String;FIJ)V

    return-void
.end method

.method public final I(J)V
    .locals 9

    const/4 v0, 0x0

    iget-object v1, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {v1, v0}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1}, Lc/n1;->I()F

    move-result v5

    const/4 v6, 0x2

    move-object v2, p0

    move-wide v7, p1

    invoke-virtual/range {v2 .. v8}, Lc/m2;->J(Ljava/lang/String;Ljava/lang/String;FIJ)V

    return-void
.end method

.method public final J(Ljava/lang/String;Ljava/lang/String;FIJ)V
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    move-object/from16 v10, p2

    move/from16 v11, p4

    move-wide/from16 v1, p5

    invoke-virtual/range {p0 .. p0}, Lc/F;->f()Z

    const/high16 v3, 0x3f400000    # 0.75f

    move/from16 v4, p3

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/high16 v4, 0x3e800000    # 0.25f

    invoke-static {v4, v3}, Ljava/lang/Math;->max(FF)F

    move-result v12

    iget-object v13, v0, Lc/m2;->y:Lc/n1;

    const/4 v14, 0x1

    if-gez v11, :cond_0

    move v3, v14

    goto :goto_0

    :cond_0
    invoke-virtual {v13, v9, v10, v12}, Lc/n1;->Q0(Ljava/lang/String;Ljava/lang/String;F)Z

    move-result v3

    :goto_0
    const/4 v15, 0x0

    if-nez v3, :cond_1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u0432 \u0434\u0440\u0443\u0433\u043e\u043c \u043e\u043a\u043d\u0435"

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v15}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    return-void

    :cond_1
    const-string v8, ""

    const/4 v7, 0x2

    if-ne v11, v7, :cond_2

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1

    :cond_2
    move-object v3, v8

    :goto_1
    iput-object v3, v0, Lc/m2;->K:Ljava/lang/String;

    iput-wide v1, v0, Lc/m2;->L:J

    iput-boolean v15, v0, Lc/m2;->N:Z

    iget-object v4, v0, Lc/m2;->M:[Z

    aput-boolean v15, v4, v14

    aput-boolean v15, v4, v15

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_3

    iget-object v3, v0, Lc/m2;->K:Ljava/lang/String;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long/2addr v4, v1

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    const-string v5, "right"

    const-string v17, "tap_to_start_ms"

    const-string v1, "pair_switch_id"

    const-string v4, "left"

    move-object v2, v3

    move-object v3, v4

    move-object/from16 v4, p1

    move-object/from16 v6, p2

    move v15, v7

    move-object/from16 v7, v17

    move-object/from16 v18, v8

    move-object/from16 v8, v16

    filled-new-array/range {v1 .. v8}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "pair_switch_started"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_2

    :cond_3
    move v15, v7

    move-object/from16 v18, v8

    :goto_2
    if-gez v11, :cond_4

    iget-object v1, v13, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "split_ratio"

    invoke-static {v12}, Lc/n1;->b(F)F

    move-result v3

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_4
    const-string v1, "split"

    invoke-virtual {v13, v1, v9, v10, v14}, Lc/n1;->y0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    iget v1, v0, Lc/m2;->O:I

    add-int/2addr v1, v14

    iput v1, v0, Lc/m2;->O:I

    iget-object v2, v0, Lc/m2;->t:[Lc/t2;

    if-ne v11, v15, :cond_5

    iget-boolean v3, v0, Lc/m2;->I:Z

    if-nez v3, :cond_5

    const/4 v3, 0x0

    aget-object v4, v2, v3

    invoke-virtual {v4, v9}, Lc/t2;->d(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_5

    move v3, v14

    goto :goto_3

    :cond_5
    const/4 v3, 0x0

    :goto_3
    if-ne v11, v15, :cond_6

    iget-boolean v4, v0, Lc/m2;->I:Z

    if-nez v4, :cond_6

    aget-object v4, v2, v14

    invoke-virtual {v4, v10}, Lc/t2;->d(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_6

    move v4, v14

    :goto_4
    const/4 v5, 0x0

    goto :goto_5

    :cond_6
    const/4 v4, 0x0

    goto :goto_4

    :goto_5
    aget-object v6, v2, v5

    invoke-virtual {v6}, Lc/t2;->i()V

    aget-object v6, v2, v14

    invoke-virtual {v6}, Lc/t2;->i()V

    iput-boolean v5, v0, Lc/m2;->I:Z

    iput v12, v0, Lc/m2;->H:F

    if-nez v3, :cond_7

    aget-object v6, v2, v5

    invoke-virtual {v6, v5}, Lc/t2;->c0(Z)V

    :cond_7
    if-nez v4, :cond_8

    aget-object v6, v2, v14

    invoke-virtual {v6, v5}, Lc/t2;->c0(Z)V

    :cond_8
    aget-object v6, v2, v5

    iput-boolean v5, v6, Lc/t2;->B:Z

    aget-object v7, v2, v14

    iput-boolean v5, v7, Lc/t2;->B:Z

    invoke-virtual {v6}, Lc/t2;->J()V

    aget-object v6, v2, v14

    invoke-virtual {v6}, Lc/t2;->J()V

    aget-object v6, v2, v5

    invoke-virtual {v6, v9}, Lc/t2;->d0(Ljava/lang/String;)V

    aget-object v6, v2, v14

    invoke-virtual {v6, v10}, Lc/t2;->d0(Ljava/lang/String;)V

    if-ne v11, v15, :cond_c

    iget-object v6, v0, Lc/m2;->K:Ljava/lang/String;

    aget-object v7, v2, v5

    new-instance v5, Lc/h2;

    const/4 v8, 0x0

    invoke-direct {v5, v0, v6, v8}, Lc/h2;-><init>(Lc/m2;Ljava/lang/String;I)V

    invoke-virtual {v7, v6}, Lc/t2;->g0(Ljava/lang/String;)V

    iput-object v5, v7, Lc/t2;->A:Ljava/lang/Runnable;

    iget-object v5, v7, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v5}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_9

    new-instance v5, Lc/i2;

    const/16 v8, 0x14

    invoke-direct {v5, v7, v8}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v7, v5}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_9
    aget-object v5, v2, v14

    new-instance v7, Lc/h2;

    const/4 v8, 0x1

    invoke-direct {v7, v0, v6, v8}, Lc/h2;-><init>(Lc/m2;Ljava/lang/String;I)V

    invoke-virtual {v5, v6}, Lc/t2;->g0(Ljava/lang/String;)V

    iput-object v7, v5, Lc/t2;->A:Ljava/lang/Runnable;

    iget-object v6, v5, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v6}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_a

    new-instance v6, Lc/i2;

    const/16 v7, 0x14

    invoke-direct {v6, v5, v7}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v5, v6}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_a
    const/4 v5, 0x0

    if-nez v3, :cond_b

    aget-object v6, v2, v5

    invoke-virtual {v6, v9}, Lc/t2;->e0(Ljava/lang/String;)V

    :cond_b
    if-nez v4, :cond_e

    aget-object v6, v2, v14

    invoke-virtual {v6, v10}, Lc/t2;->e0(Ljava/lang/String;)V

    goto :goto_6

    :cond_c
    aget-object v6, v2, v5

    move-object/from16 v7, v18

    invoke-virtual {v6, v7}, Lc/t2;->g0(Ljava/lang/String;)V

    aget-object v6, v2, v14

    invoke-virtual {v6, v7}, Lc/t2;->g0(Ljava/lang/String;)V

    if-nez v11, :cond_d

    aget-object v6, v2, v5

    invoke-virtual {v6, v9}, Lc/t2;->e0(Ljava/lang/String;)V

    goto :goto_6

    :cond_d
    if-ne v11, v14, :cond_e

    aget-object v6, v2, v14

    invoke-virtual {v6, v10}, Lc/t2;->e0(Ljava/lang/String;)V

    :cond_e
    :goto_6
    aget-object v6, v2, v5

    invoke-virtual {v6, v14}, Lc/t2;->c0(Z)V

    aget-object v2, v2, v14

    invoke-virtual {v2, v14}, Lc/t2;->c0(Z)V

    if-eqz v3, :cond_f

    iget-object v2, v0, Lc/m2;->K:Ljava/lang/String;

    invoke-virtual {v0, v2, v5}, Lc/m2;->A(Ljava/lang/String;I)V

    :cond_f
    if-eqz v4, :cond_10

    iget-object v2, v0, Lc/m2;->K:Ljava/lang/String;

    invoke-virtual {v0, v2, v14}, Lc/m2;->A(Ljava/lang/String;I)V

    :cond_10
    iget-object v2, v0, Lc/m2;->w:Lc/l2;

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->requestLayout()V

    new-instance v2, Lc/w;

    const/4 v3, 0x1

    invoke-direct {v2, v0, v1, v3}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final K(Ljava/lang/String;)V
    .locals 5

    invoke-virtual {p0}, Lc/F;->f()Z

    iget v0, p0, Lc/m2;->O:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lc/m2;->O:I

    const-string v0, ""

    iput-object v0, p0, Lc/m2;->K:Ljava/lang/String;

    iget-object v2, p0, Lc/m2;->t:[Lc/t2;

    const/4 v3, 0x0

    aget-object v4, v2, v3

    invoke-virtual {v4, v0}, Lc/t2;->g0(Ljava/lang/String;)V

    aget-object v4, v2, v1

    invoke-virtual {v4, v0}, Lc/t2;->g0(Ljava/lang/String;)V

    aget-object v0, v2, v3

    invoke-virtual {v0}, Lc/t2;->i()V

    aget-object v0, v2, v1

    invoke-virtual {v0}, Lc/t2;->i()V

    iput-boolean v1, p0, Lc/m2;->I:Z

    iget-object v0, p0, Lc/m2;->w:Lc/l2;

    const/16 v4, 0x8

    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    aget-object v0, v2, v3

    invoke-virtual {v0, v3}, Lc/t2;->c0(Z)V

    aget-object v0, v2, v1

    invoke-virtual {v0, v3}, Lc/t2;->c0(Z)V

    aget-object v0, v2, v3

    iput-boolean v1, v0, Lc/t2;->B:Z

    invoke-virtual {v0, p1}, Lc/t2;->e0(Ljava/lang/String;)V

    aget-object p1, v2, v3

    invoke-virtual {p1}, Lc/t2;->J()V

    aget-object p1, v2, v3

    invoke-virtual {p1, v1}, Lc/t2;->c0(Z)V

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public final L(I)I
    .locals 2

    invoke-virtual {p0}, Lc/m2;->v()I

    move-result v0

    invoke-virtual {p0, p1}, Lc/m2;->w(I)I

    move-result p1

    sub-int/2addr p1, v0

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v1

    sub-int/2addr p1, v1

    const/4 v1, 0x1

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    int-to-float p1, p1

    iget v1, p0, Lc/m2;->H:F

    mul-float/2addr p1, v1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    add-int/2addr p1, v0

    return p1
.end method

.method public final a(I)V
    .locals 1

    iget-object v0, p0, Lc/m2;->x:Lc/M4;

    iget-object v0, v0, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->M(I)V

    return-void
.end method

.method public final b(I)V
    .locals 4

    if-ltz p1, :cond_1

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    if-lt p1, v1, :cond_0

    goto :goto_0

    :cond_0
    iget v1, p0, Lc/m2;->O:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, Lc/m2;->O:I

    const/4 v3, 0x0

    aget-object v3, v0, v3

    invoke-virtual {v3}, Lc/t2;->i()V

    aget-object v2, v0, v2

    invoke-virtual {v2}, Lc/t2;->i()V

    aget-object v0, v0, p1

    iget-object v2, p0, Lc/m2;->v:Lc/z;

    invoke-virtual {v2}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v2

    new-instance v3, Lc/k2;

    invoke-direct {v3, p0, v1, p1}, Lc/k2;-><init>(Lc/m2;II)V

    invoke-virtual {v0, v2, v3}, Lc/t2;->k0(Ljava/util/ArrayList;Lc/f2;)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final c(I)V
    .locals 1

    iget-object v0, p0, Lc/m2;->x:Lc/M4;

    iget-object v0, v0, Lc/M4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->L(I)V

    return-void
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1

    iget-boolean v0, p0, Lc/m2;->J:Z

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-super {p0, p1}, Lc/F;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final g()Lc/Q1;
    .locals 1

    iget-object v0, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->i()Lc/u0;

    move-result-object v0

    iget-object v0, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q1;

    return-object v0
.end method

.method public final h()F
    .locals 1

    iget-object v0, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->f0()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    return v0

    :cond_0
    iget-boolean v0, p0, Lc/F;->a:Z

    if-eqz v0, :cond_1

    const/high16 v0, 0x41a00000    # 20.0f

    goto :goto_0

    :cond_1
    invoke-super {p0}, Lc/F;->h()F

    move-result v0

    :goto_0
    return v0
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 13

    iget-object v0, p0, Lc/m2;->y:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->a0()Z

    move-result v1

    invoke-virtual {v0}, Lc/n1;->j0()Z

    move-result v2

    invoke-virtual {v0}, Lc/n1;->T()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v3, :cond_0

    iget-object v3, p0, Lc/m2;->G:Ljava/lang/String;

    if-eqz v3, :cond_1

    :goto_0
    move v4, v5

    goto :goto_1

    :cond_0
    iget-object v6, p0, Lc/m2;->G:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    :goto_1
    iget-boolean v3, p0, Lc/m2;->D:Z

    if-eqz v3, :cond_2

    iget-boolean v3, p0, Lc/m2;->E:Z

    if-ne v1, v3, :cond_2

    iget-boolean v1, p0, Lc/m2;->F:Z

    if-ne v2, v1, :cond_2

    if-eqz v4, :cond_3

    :cond_2
    invoke-virtual {p0}, Lc/m2;->C()V

    :cond_3
    iget-object v6, p0, Lc/m2;->z:Landroid/graphics/Paint;

    iget-object v7, p0, Lc/m2;->A:Landroid/graphics/RectF;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    iget v8, v1, Lc/r4;->a:I

    iget-object v9, p0, Lc/m2;->B:Lc/W3;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v10, v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v11, v1

    invoke-virtual {v0}, Lc/n1;->S()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0, v0}, Lc/m2;->y(F)I

    move-result v0

    int-to-float v12, v0

    move-object v5, p1

    invoke-static/range {v5 .. v12}, Lc/s3;->a(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/RectF;ILc/W3;FFF)V

    return-void
.end method

.method public final onLayout(ZIIII)V
    .locals 16

    move-object/from16 v6, p0

    iget-object v7, v6, Lc/m2;->u:Lc/b2;

    invoke-virtual {v6, v7}, Lc/F;->m(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    sub-int v0, p4, p2

    sub-int v1, p5, p3

    const/high16 v2, 0x42b80000    # 92.0f

    invoke-virtual {v6, v2}, Lc/m2;->y(F)I

    move-result v3

    const/high16 v4, 0x41400000    # 12.0f

    invoke-virtual {v6, v4}, Lc/m2;->y(F)I

    move-result v5

    invoke-virtual {v6, v4}, Lc/m2;->y(F)I

    move-result v8

    invoke-virtual {v6, v4}, Lc/m2;->y(F)I

    move-result v9

    invoke-virtual {v6, v4}, Lc/m2;->y(F)I

    move-result v10

    invoke-virtual {v6, v4}, Lc/m2;->y(F)I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Lc/F;->q()Z

    move-result v11

    const/high16 v12, 0x42100000    # 36.0f

    const/4 v13, 0x0

    const/4 v14, 0x1

    iget-object v15, v6, Lc/m2;->w:Lc/l2;

    iget-object v2, v6, Lc/m2;->t:[Lc/t2;

    if-eqz v11, :cond_3

    sub-int v9, v1, v9

    invoke-virtual/range {p0 .. p0}, Lc/m2;->h()F

    move-result v1

    invoke-virtual {v6, v1}, Lc/m2;->y(F)I

    move-result v1

    sub-int v1, v9, v1

    sub-int v3, v1, v4

    sub-int/2addr v3, v10

    invoke-static {v14, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    int-to-float v3, v3

    iget v11, v6, Lc/m2;->H:F

    mul-float/2addr v3, v11

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    add-int/2addr v3, v4

    aget-object v11, v2, v13

    sub-int v8, v0, v8

    iget-boolean v0, v6, Lc/m2;->I:Z

    if-eqz v0, :cond_1

    move v0, v1

    goto :goto_0

    :cond_1
    move v0, v3

    :goto_0
    invoke-virtual {v11, v5, v4, v8, v0}, Landroid/view/View;->layout(IIII)V

    iget-boolean v0, v6, Lc/m2;->I:Z

    if-nez v0, :cond_2

    invoke-virtual {v6, v12}, Lc/m2;->y(F)I

    move-result v0

    add-int/2addr v0, v3

    invoke-virtual {v15, v5, v3, v8, v0}, Landroid/view/View;->layout(IIII)V

    aget-object v0, v2, v14

    add-int/2addr v3, v10

    invoke-virtual {v0, v5, v3, v8, v1}, Landroid/view/View;->layout(IIII)V

    invoke-virtual {v15}, Landroid/view/View;->bringToFront()V

    :cond_2
    const/high16 v0, 0x42b80000    # 92.0f

    invoke-virtual {v6, v0}, Lc/m2;->y(F)I

    move-result v0

    sub-int v3, v9, v0

    iget-object v1, v6, Lc/m2;->u:Lc/b2;

    move-object/from16 v0, p0

    move v2, v5

    move v4, v8

    move v5, v9

    invoke-virtual/range {v0 .. v5}, Lc/F;->l(Landroid/view/View;IIII)V

    invoke-virtual {v7}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    return-void

    :cond_3
    invoke-virtual/range {p0 .. p0}, Lc/m2;->v()I

    move-result v11

    invoke-virtual {v6, v0}, Lc/m2;->w(I)I

    move-result v14

    iget-boolean v12, v6, Lc/m2;->I:Z

    if-eqz v12, :cond_4

    aget-object v2, v2, v13

    sub-int v10, v1, v9

    invoke-virtual {v2, v11, v4, v14, v10}, Landroid/view/View;->layout(IIII)V

    move/from16 p3, v5

    goto :goto_1

    :cond_4
    invoke-virtual {v6, v0}, Lc/m2;->L(I)I

    move-result v12

    aget-object v13, v2, v13

    move/from16 p3, v5

    sub-int v5, v1, v9

    invoke-virtual {v13, v11, v4, v12, v5}, Landroid/view/View;->layout(IIII)V

    const/high16 v11, 0x42100000    # 36.0f

    invoke-virtual {v6, v11}, Lc/m2;->y(F)I

    move-result v11

    sub-int/2addr v11, v10

    div-int/lit8 v11, v11, 0x2

    sub-int v13, v12, v11

    add-int/2addr v12, v10

    add-int/2addr v11, v12

    invoke-virtual {v15, v13, v4, v11, v5}, Landroid/view/View;->layout(IIII)V

    const/4 v10, 0x1

    aget-object v2, v2, v10

    invoke-virtual {v2, v12, v4, v14, v5}, Landroid/view/View;->layout(IIII)V

    :goto_1
    invoke-virtual/range {p0 .. p0}, Lc/m2;->g()Lc/Q1;

    move-result-object v2

    sget-object v5, Lc/Q1;->a:Lc/Q1;

    if-ne v2, v5, :cond_5

    move/from16 v2, p3

    goto :goto_2

    :cond_5
    sub-int/2addr v0, v8

    sub-int/2addr v0, v3

    move v2, v0

    :goto_2
    add-int v5, v2, v3

    sub-int v8, v1, v9

    iget-object v1, v6, Lc/m2;->u:Lc/b2;

    move-object/from16 v0, p0

    move v3, v4

    move v4, v5

    move v5, v8

    invoke-virtual/range {v0 .. v5}, Lc/F;->l(Landroid/view/View;IIII)V

    invoke-virtual {v7}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v15}, Landroid/view/View;->bringToFront()V

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    return-void
.end method

.method public final onMeasure(II)V
    .locals 16

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/m2;->u:Lc/b2;

    move/from16 v2, p1

    move/from16 v3, p2

    invoke-virtual {v0, v2, v3, v1}, Lc/F;->n(IILandroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_0

    return-void

    :cond_0
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v3

    invoke-virtual {v0, v2, v3}, Landroid/view/View;->setMeasuredDimension(II)V

    const/high16 v4, 0x42b80000    # 92.0f

    invoke-virtual {v0, v4}, Lc/m2;->y(F)I

    move-result v5

    const/high16 v6, 0x41400000    # 12.0f

    invoke-virtual {v0, v6}, Lc/m2;->y(F)I

    move-result v7

    invoke-virtual {v0, v6}, Lc/m2;->y(F)I

    move-result v8

    invoke-virtual {v0, v6}, Lc/m2;->y(F)I

    move-result v9

    invoke-virtual {v0, v6}, Lc/m2;->y(F)I

    move-result v10

    invoke-virtual {v0, v6}, Lc/m2;->y(F)I

    move-result v6

    invoke-static {v2, v3}, Lc/G8;->M(II)Z

    move-result v11

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v12

    if-eq v12, v0, :cond_1

    iget-boolean v12, v0, Lc/m2;->J:Z

    if-eqz v12, :cond_2

    :cond_1
    iget-object v12, v0, Lc/F;->l:Landroid/view/View;

    check-cast v12, Lc/b2;

    invoke-virtual {v12, v11}, Lc/b2;->E(Z)V

    :cond_2
    iget-object v12, v0, Lc/m2;->w:Lc/l2;

    iget-boolean v13, v12, Lc/l2;->b:Z

    if-ne v13, v11, :cond_3

    goto :goto_0

    :cond_3
    iput-boolean v11, v12, Lc/l2;->b:Z

    invoke-virtual {v12}, Landroid/view/View;->invalidate()V

    :goto_0
    iget-object v15, v0, Lc/m2;->t:[Lc/t2;

    const/4 v13, 0x1

    const/high16 v14, 0x40000000    # 2.0f

    if-eqz v11, :cond_7

    invoke-virtual {v0, v4}, Lc/m2;->y(F)I

    move-result v4

    sub-int/2addr v3, v6

    invoke-virtual/range {p0 .. p0}, Lc/m2;->h()F

    move-result v5

    invoke-virtual {v0, v5}, Lc/m2;->y(F)I

    move-result v5

    sub-int/2addr v3, v5

    sub-int v5, v3, v10

    sub-int/2addr v5, v9

    invoke-static {v13, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    int-to-float v5, v5

    iget v6, v0, Lc/m2;->H:F

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    add-int/2addr v5, v10

    const/4 v6, 0x0

    aget-object v6, v15, v6

    sub-int/2addr v2, v7

    sub-int/2addr v2, v8

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-static {v7, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    iget-boolean v8, v0, Lc/m2;->I:Z

    if-eqz v8, :cond_4

    move v8, v3

    goto :goto_1

    :cond_4
    move v8, v5

    :goto_1
    sub-int/2addr v8, v10

    invoke-static {v13, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-static {v8, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Landroid/view/View;->measure(II)V

    iget-boolean v6, v0, Lc/m2;->I:Z

    if-nez v6, :cond_5

    aget-object v6, v15, v13

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-static {v7, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    sub-int/2addr v3, v5

    sub-int/2addr v3, v9

    invoke-static {v13, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v6, v7, v3}, Landroid/view/View;->measure(II)V

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    const/high16 v5, 0x42100000    # 36.0f

    invoke-virtual {v0, v5}, Lc/m2;->y(F)I

    move-result v5

    invoke-static {v5, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v12, v3, v5}, Landroid/view/View;->measure(II)V

    :cond_5
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    if-ne v3, v0, :cond_6

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-static {v2, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-static {v4, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/view/View;->measure(II)V

    :cond_6
    return-void

    :cond_7
    invoke-virtual/range {p0 .. p0}, Lc/m2;->v()I

    move-result v4

    invoke-virtual {v0, v2}, Lc/m2;->w(I)I

    move-result v7

    sub-int v8, v7, v4

    invoke-static {v13, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    iget-boolean v11, v0, Lc/m2;->I:Z

    if-eqz v11, :cond_8

    goto :goto_2

    :cond_8
    invoke-virtual {v0, v2}, Lc/m2;->L(I)I

    move-result v8

    sub-int/2addr v8, v4

    invoke-static {v13, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    :goto_2
    sub-int/2addr v7, v9

    invoke-virtual {v0, v2}, Lc/m2;->L(I)I

    move-result v2

    sub-int/2addr v7, v2

    invoke-static {v13, v7}, Ljava/lang/Math;->max(II)I

    move-result v2

    sub-int/2addr v3, v10

    sub-int/2addr v3, v6

    invoke-static {v13, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    const/4 v4, 0x0

    aget-object v4, v15, v4

    invoke-static {v8, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    invoke-virtual {v4, v6, v7}, Landroid/view/View;->measure(II)V

    iget-boolean v4, v0, Lc/m2;->I:Z

    if-nez v4, :cond_9

    aget-object v4, v15, v13

    invoke-static {v2, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-virtual {v4, v2, v6}, Landroid/view/View;->measure(II)V

    const/high16 v2, 0x42100000    # 36.0f

    invoke-virtual {v0, v2}, Lc/m2;->y(F)I

    move-result v2

    invoke-static {v2, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-virtual {v12, v2, v4}, Landroid/view/View;->measure(II)V

    :cond_9
    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    if-ne v2, v0, :cond_a

    invoke-static {v5, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-static {v3, v14}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/view/View;->measure(II)V

    :cond_a
    return-void
.end method

.method public final v()I
    .locals 3

    const/high16 v0, 0x41400000    # 12.0f

    invoke-virtual {p0, v0}, Lc/m2;->y(F)I

    move-result v0

    invoke-virtual {p0}, Lc/m2;->g()Lc/Q1;

    move-result-object v1

    sget-object v2, Lc/Q1;->a:Lc/Q1;

    if-ne v1, v2, :cond_0

    invoke-virtual {p0}, Lc/m2;->h()F

    move-result v1

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    add-int/2addr v0, v1

    return v0
.end method

.method public final w(I)I
    .locals 2

    const/high16 v0, 0x41400000    # 12.0f

    invoke-virtual {p0, v0}, Lc/m2;->y(F)I

    move-result v0

    sub-int/2addr p1, v0

    invoke-virtual {p0}, Lc/m2;->g()Lc/Q1;

    move-result-object v0

    sget-object v1, Lc/Q1;->b:Lc/Q1;

    if-ne v0, v1, :cond_0

    invoke-virtual {p0}, Lc/m2;->h()F

    move-result v0

    invoke-virtual {p0, v0}, Lc/m2;->y(F)I

    move-result v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sub-int/2addr p1, v0

    return p1
.end method

.method public final x(Z)F
    .locals 3

    const/4 v0, 0x1

    const/high16 v1, 0x41400000    # 12.0f

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v2

    sub-int/2addr p1, v2

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v2

    sub-int/2addr p1, v2

    invoke-virtual {p0}, Lc/m2;->h()F

    move-result v2

    invoke-virtual {p0, v2}, Lc/m2;->y(F)I

    move-result v2

    sub-int/2addr p1, v2

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v1

    sub-int/2addr p1, v1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    :goto_0
    int-to-float p1, p1

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-virtual {p0, p1}, Lc/m2;->w(I)I

    move-result p1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    invoke-virtual {p0}, Lc/m2;->v()I

    move-result v2

    sub-int/2addr p1, v2

    invoke-virtual {p0, v1}, Lc/m2;->y(F)I

    move-result v1

    sub-int/2addr p1, v1

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    goto :goto_0

    :goto_1
    return p1
.end method

.method public final y(F)I
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    return p1
.end method

.method public final z(I)Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lc/m2;->t:[Lc/t2;

    aget-object p1, v0, p1

    iget-object p1, p1, Lc/t2;->u:Ljava/lang/String;

    return-object p1
.end method
