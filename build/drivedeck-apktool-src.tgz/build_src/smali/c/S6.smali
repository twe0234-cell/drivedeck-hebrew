.class public final synthetic Lc/S6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnShowListener;


# instance fields
.field public final synthetic a:Landroid/app/AlertDialog;

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:Lc/r4;

.field public final synthetic d:Lc/T5;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lorg/json/JSONObject;

.field public final synthetic g:Ljava/util/LinkedHashMap;

.field public final synthetic h:Landroid/widget/Spinner;

.field public final synthetic i:Landroid/widget/Spinner;

.field public final synthetic j:Landroid/widget/CheckBox;

.field public final synthetic k:Landroid/widget/CheckBox;

.field public final synthetic l:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Landroid/app/AlertDialog;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Ljava/lang/String;Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/S6;->a:Landroid/app/AlertDialog;

    iput-object p2, p0, Lc/S6;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/S6;->c:Lc/r4;

    iput-object p4, p0, Lc/S6;->d:Lc/T5;

    iput-object p5, p0, Lc/S6;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/S6;->f:Lorg/json/JSONObject;

    iput-object p7, p0, Lc/S6;->g:Ljava/util/LinkedHashMap;

    iput-object p8, p0, Lc/S6;->h:Landroid/widget/Spinner;

    iput-object p9, p0, Lc/S6;->i:Landroid/widget/Spinner;

    iput-object p10, p0, Lc/S6;->j:Landroid/widget/CheckBox;

    iput-object p11, p0, Lc/S6;->k:Landroid/widget/CheckBox;

    iput-object p12, p0, Lc/S6;->l:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onShow(Landroid/content/DialogInterface;)V
    .locals 13

    iget-object v9, p0, Lc/S6;->a:Landroid/app/AlertDialog;

    invoke-virtual {v9}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    iget-object v10, p0, Lc/S6;->b:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_0

    iget-object v0, p0, Lc/S6;->c:Lc/r4;

    iget v0, v0, Lc/r4;->c:I

    invoke-static {v10, v0}, Lc/b7;->m(Landroid/app/Activity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0x10

    invoke-virtual {p1, v0}, Landroid/view/Window;->setSoftInputMode(I)V

    const/16 v0, 0x2f8

    invoke-static {v10, v0}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v3, 0x20

    invoke-static {v10, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    const/16 v3, 0x30

    invoke-static {v10, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    sub-int/2addr v2, v3

    invoke-static {v10, v0}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v0

    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-virtual {p1, v1, v0}, Landroid/view/Window;->setLayout(II)V

    :cond_0
    const/4 p1, -0x1

    invoke-virtual {v9, p1}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object p1

    new-instance v12, Lc/V6;

    iget-object v3, p0, Lc/S6;->f:Lorg/json/JSONObject;

    iget-object v4, p0, Lc/S6;->g:Ljava/util/LinkedHashMap;

    iget-object v5, p0, Lc/S6;->h:Landroid/widget/Spinner;

    iget-object v6, p0, Lc/S6;->i:Landroid/widget/Spinner;

    iget-object v7, p0, Lc/S6;->j:Landroid/widget/CheckBox;

    iget-object v8, p0, Lc/S6;->k:Landroid/widget/CheckBox;

    iget-object v11, p0, Lc/S6;->l:Landroid/widget/TextView;

    iget-object v1, p0, Lc/S6;->d:Lc/T5;

    iget-object v2, p0, Lc/S6;->e:Ljava/lang/String;

    move-object v0, v12

    invoke-direct/range {v0 .. v11}, Lc/V6;-><init>(Lc/T5;Ljava/lang/String;Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/app/AlertDialog;Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;)V

    invoke-virtual {p1, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method
