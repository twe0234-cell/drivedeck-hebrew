.class public final synthetic Lc/k2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/f2;


# instance fields
.field public final synthetic a:Lc/m2;

.field public final synthetic b:I

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/m2;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/k2;->a:Lc/m2;

    iput p2, p0, Lc/k2;->b:I

    iput p3, p0, Lc/k2;->c:I

    return-void
.end method


# virtual methods
.method public final a(Lc/a;)V
    .locals 7

    iget-object v0, p0, Lc/k2;->a:Lc/m2;

    iget v1, v0, Lc/m2;->O:I

    iget v2, p0, Lc/k2;->b:I

    if-eq v2, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    iget-object v1, v0, Lc/m2;->y:Lc/n1;

    iget v4, p0, Lc/k2;->c:I

    invoke-virtual {v1, p1, v4}, Lc/n1;->R0(Ljava/lang/String;I)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    invoke-virtual {v1, p1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1}, Lc/n1;->I()F

    move-result v3

    const-wide/16 v5, 0x0

    move-object v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/m2;->J(Ljava/lang/String;Ljava/lang/String;FIJ)V

    :goto_0
    return-void
.end method
