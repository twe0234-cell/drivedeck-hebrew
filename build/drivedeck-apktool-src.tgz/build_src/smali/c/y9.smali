.class public abstract Lc/y9;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/concurrent/ExecutorService;

.field public static final b:Ljava/util/concurrent/ExecutorService;

.field public static final c:Landroid/os/Handler;

.field public static final d:Ljava/lang/Object;

.field public static volatile e:Ljava/lang/String;

.field public static volatile f:Ljava/lang/String;

.field public static volatile g:Z

.field public static volatile h:Z

.field public static volatile i:Lc/R0;

.field public static volatile j:Ljava/lang/String;

.field public static k:J

.field public static l:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lc/y9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    sput-object v0, Lc/y9;->b:Ljava/util/concurrent/ExecutorService;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lc/y9;->c:Landroid/os/Handler;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lc/y9;->d:Ljava/lang/Object;

    const-string v0, "\u2212\u00b0"

    sput-object v0, Lc/y9;->e:Ljava/lang/String;

    const-string v0, ""

    sput-object v0, Lc/y9;->f:Ljava/lang/String;

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object v1

    sput-object v1, Lc/y9;->i:Lc/R0;

    sput-object v0, Lc/y9;->j:Ljava/lang/String;

    return-void
.end method

.method public static a(Landroid/content/Context;Lorg/json/JSONObject;Landroid/location/Location;)Lc/x9;
    .locals 26

    move-object/from16 v0, p0

    invoke-static/range {p0 .. p0}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result v1

    const/high16 v2, 0x10000

    const/16 v3, 0xc8

    const/16 v4, 0x1b58

    const/4 v5, 0x1

    const/4 v7, 0x0

    if-nez v1, :cond_5

    :try_start_0
    invoke-static {}, Lc/y9;->i()Ljava/net/URL;

    move-result-object v0

    if-nez v0, :cond_1

    :cond_0
    :goto_0
    const/4 v6, 0x0

    goto/16 :goto_5

    :cond_1
    invoke-virtual/range {p1 .. p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v1, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const-string v0, "POST"

    invoke-virtual {v8, v0}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {v8, v5}, Ljava/net/URLConnection;->setDoOutput(Z)V

    invoke-virtual {v8, v7}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    array-length v0, v1

    invoke-virtual {v8, v0}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    const-string v0, "Content-Type"

    const-string v5, "application/json; charset=utf-8"

    invoke-virtual {v8, v0, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "Accept"

    const-string v5, "application/json"

    invoke-virtual {v8, v0, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "User-Agent"

    const-string v5, "DriveDeck/0.6.7"

    invoke-virtual {v8, v0, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v8, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {v8}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v4
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v4, v1}, Ljava/io/OutputStream;->write([B)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-eq v0, v3, :cond_2

    :goto_1
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_0

    :cond_2
    :try_start_4
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {v8}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    invoke-static {v1, v2}, Lc/G8;->m0(Ljava/io/InputStream;I)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lc/y9;->g(Lorg/json/JSONObject;)Lc/x9;

    move-result-object v6
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_1
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_5

    :catchall_0
    move-exception v0

    move-object v6, v8

    goto :goto_3

    :catchall_1
    move-exception v0

    move-object v1, v0

    if-eqz v4, :cond_3

    :try_start_5
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception v0

    move-object v2, v0

    :try_start_6
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_2
    throw v1
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :catchall_3
    move-exception v0

    const/4 v6, 0x0

    goto :goto_3

    :catch_0
    const/4 v8, 0x0

    goto :goto_4

    :goto_3
    if-eqz v6, :cond_4

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_4
    throw v0

    :catch_1
    :goto_4
    if-eqz v8, :cond_0

    goto :goto_1

    :goto_5
    return-object v6

    :cond_5
    if-nez p2, :cond_6

    const-wide/high16 v10, 0x7ff8000000000000L    # Double.NaN

    goto :goto_6

    :cond_6
    invoke-virtual/range {p2 .. p2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v10

    :goto_6
    if-nez p2, :cond_7

    const-wide/high16 v12, 0x7ff8000000000000L    # Double.NaN

    goto :goto_7

    :cond_7
    invoke-virtual/range {p2 .. p2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v12

    :goto_7
    const-string v1, "city"

    const-string v14, ""

    move-object/from16 v15, p1

    invoke-virtual {v15, v1, v14}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v14, "yandex_weather"

    invoke-virtual {v0, v14, v7}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v14

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    const-wide v16, -0x3f99800000000000L    # -180.0

    const-wide v18, -0x3fa9800000000000L    # -90.0

    const-wide v20, 0x4066800000000000L    # 180.0

    const-wide v22, 0x4056800000000000L    # 90.0

    if-nez v15, :cond_a

    const-string v15, "coordinates_city"

    const-string v6, ""

    invoke-interface {v14, v15, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_a

    const-string v6, "city_lat"

    const/high16 v10, 0x7fc00000    # Float.NaN

    invoke-interface {v14, v6, v10}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v6

    float-to-double v11, v6

    const-string v6, "city_lon"

    invoke-interface {v14, v6, v10}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v6

    float-to-double v8, v6

    cmpl-double v6, v11, v18

    if-ltz v6, :cond_9

    cmpg-double v6, v11, v22

    if-gtz v6, :cond_9

    cmpl-double v6, v8, v16

    if-ltz v6, :cond_9

    cmpg-double v6, v8, v20

    if-lez v6, :cond_8

    goto :goto_8

    :cond_8
    move-wide/from16 v24, v8

    move-wide v8, v11

    goto :goto_9

    :cond_9
    :goto_8
    const-wide/high16 v8, 0x7ff8000000000000L    # Double.NaN

    const-wide/high16 v24, 0x7ff8000000000000L    # Double.NaN

    goto :goto_9

    :cond_a
    move-wide v8, v10

    move-wide/from16 v24, v12

    :goto_9
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_b

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v6

    if-nez v6, :cond_b

    invoke-static {}, Landroid/location/Geocoder;->isPresent()Z

    move-result v6

    if-eqz v6, :cond_b

    :try_start_7
    new-instance v6, Landroid/location/Geocoder;

    new-instance v10, Ljava/util/Locale;

    const-string v11, "ru"

    const-string v12, "RU"

    invoke-direct {v10, v11, v12}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v6, v0, v10}, Landroid/location/Geocoder;-><init>(Landroid/content/Context;Ljava/util/Locale;)V

    invoke-virtual {v6, v1, v5}, Landroid/location/Geocoder;->getFromLocationName(Ljava/lang/String;I)Ljava/util/List;

    move-result-object v6

    if-eqz v6, :cond_b

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_b

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/location/Address;

    invoke-virtual {v10}, Landroid/location/Address;->hasLatitude()Z

    move-result v10

    if-eqz v10, :cond_b

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/location/Address;

    invoke-virtual {v10}, Landroid/location/Address;->hasLongitude()Z

    move-result v10

    if-eqz v10, :cond_b

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/location/Address;

    invoke-virtual {v10}, Landroid/location/Address;->getLatitude()D

    move-result-wide v8

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/location/Address;

    invoke-virtual {v6}, Landroid/location/Address;->getLongitude()D

    move-result-wide v24
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_2

    :catch_2
    :cond_b
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_11

    cmpl-double v6, v8, v18

    if-ltz v6, :cond_c

    cmpg-double v6, v8, v22

    if-gtz v6, :cond_c

    cmpl-double v6, v24, v16

    if-ltz v6, :cond_c

    cmpg-double v6, v24, v20

    if-lez v6, :cond_11

    :cond_c
    sget-object v6, Lc/t9;->a:Ljava/util/regex/Pattern;

    const-string v6, "https://geocoding-api.open-meteo.com/v1/search?name="

    invoke-static {v1}, Lc/y9;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-nez v10, :cond_e

    :cond_d
    :goto_a
    const/4 v2, 0x0

    goto :goto_e

    :cond_e
    :try_start_8
    new-instance v10, Ljava/net/URL;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, "UTF-8"

    invoke-static {v1, v6}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "&count=1&language=ru&format=json"

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v10, v6}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v6

    check-cast v6, Ljava/net/HttpURLConnection;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_3
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    :try_start_9
    invoke-virtual {v6, v7}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    invoke-virtual {v6, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v6, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const-string v10, "User-Agent"

    const-string v11, "DriveDeck/0.6.7"

    invoke-virtual {v6, v10, v11}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v10
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_4
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    if-eq v10, v3, :cond_f

    :goto_b
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_a

    :cond_f
    :try_start_a
    new-instance v10, Lorg/json/JSONObject;

    invoke-virtual {v6}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v11

    invoke-static {v11, v2}, Lc/G8;->m0(Ljava/io/InputStream;I)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v10, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v10}, Lc/t9;->d(Lorg/json/JSONObject;)[D

    move-result-object v2
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_4
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_e

    :catchall_4
    move-exception v0

    goto :goto_c

    :catchall_5
    move-exception v0

    const/4 v6, 0x0

    goto :goto_c

    :catch_3
    const/4 v6, 0x0

    goto :goto_d

    :goto_c
    if-eqz v6, :cond_10

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_10
    throw v0

    :catch_4
    :goto_d
    if-eqz v6, :cond_d

    goto :goto_b

    :goto_e
    if-eqz v2, :cond_11

    aget-wide v8, v2, v7

    aget-wide v24, v2, v5

    :cond_11
    move-wide/from16 v5, v24

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_13

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v2

    if-eqz v2, :cond_13

    invoke-static {v5, v6}, Ljava/lang/Double;->isFinite(D)Z

    move-result v2

    if-eqz v2, :cond_13

    sget-object v2, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v2

    :try_start_b
    invoke-static/range {p0 .. p0}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_12

    invoke-interface {v14}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v10, "coordinates_city"

    invoke-interface {v0, v10, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v10, "city_lat"

    double-to-float v11, v8

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v10, "city_lon"

    double-to-float v11, v5

    invoke-interface {v0, v10, v11}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_f

    :catchall_6
    move-exception v0

    goto :goto_10

    :cond_12
    :goto_f
    monitor-exit v2

    goto :goto_11

    :goto_10
    monitor-exit v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_6

    throw v0

    :cond_13
    :goto_11
    sget-object v0, Lc/t9;->a:Ljava/util/regex/Pattern;

    const-string v0, "https://yandex.ru/pogoda/ru?lat="

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-static {v5, v6}, Ljava/lang/Double;->isFinite(D)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    cmpl-double v2, v10, v22

    if-gtz v2, :cond_15

    invoke-static {v5, v6}, Ljava/lang/Math;->abs(D)D

    move-result-wide v10

    cmpl-double v2, v10, v20

    if-lez v2, :cond_14

    goto :goto_13

    :cond_14
    :try_start_c
    new-instance v2, Ljava/net/URL;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v8, v9}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const-string v0, "&lon="

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v5, v6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/net/HttpURLConnection;
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_5
    .catchall {:try_start_c .. :try_end_c} :catchall_8

    :try_start_d
    invoke-virtual {v2, v7}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    invoke-virtual {v2, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v2, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const-string v0, "User-Agent"

    const-string v4, "DriveDeck/0.6.7"

    invoke-virtual {v2, v0, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "Accept-Language"

    const-string v4, "ru-RU"

    invoke-virtual {v2, v0, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_6
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    if-eq v0, v3, :cond_16

    :goto_12
    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_15
    :goto_13
    const/4 v0, 0x0

    goto :goto_16

    :cond_16
    :try_start_e
    invoke-virtual {v2}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const/high16 v3, 0x200000

    invoke-static {v0, v3}, Lc/G8;->m0(Ljava/io/InputStream;I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/t9;->c(Ljava/lang/String;)Lc/o9;

    move-result-object v0
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_6
    .catchall {:try_start_e .. :try_end_e} :catchall_7

    invoke-virtual {v2}, Ljava/net/HttpURLConnection;->disconnect()V

    goto :goto_16

    :catchall_7
    move-exception v0

    move-object v6, v2

    goto :goto_14

    :catchall_8
    move-exception v0

    const/4 v6, 0x0

    goto :goto_14

    :catch_5
    const/4 v2, 0x0

    goto :goto_15

    :goto_14
    if-eqz v6, :cond_17

    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_17
    throw v0

    :catch_6
    :goto_15
    if-eqz v2, :cond_15

    goto :goto_12

    :goto_16
    if-eqz v0, :cond_18

    new-instance v6, Lc/x9;

    iget-object v2, v0, Lc/o9;->a:Lc/R0;

    invoke-virtual {v2, v1}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v9

    new-instance v1, Lc/o9;

    iget-wide v11, v0, Lc/o9;->c:J

    iget-wide v13, v0, Lc/o9;->d:J

    iget-boolean v10, v0, Lc/o9;->b:Z

    iget-wide v2, v0, Lc/o9;->e:J

    iget-wide v4, v0, Lc/o9;->f:J

    move-object v8, v1

    move-wide v15, v2

    move-wide/from16 v17, v4

    invoke-direct/range {v8 .. v18}, Lc/o9;-><init>(Lc/R0;ZJJJJ)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-direct {v6, v1, v2, v3, v7}, Lc/x9;-><init>(Lc/o9;JZ)V

    goto :goto_17

    :cond_18
    const/4 v6, 0x0

    :goto_17
    return-object v6
.end method

.method public static b(Ljava/lang/String;JLjava/lang/Runnable;)V
    .locals 3

    sget-object v0, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lc/y9;->j:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    sget-wide v1, Lc/y9;->l:J

    cmp-long p0, p1, v1

    if-nez p0, :cond_0

    const-string p0, ""

    sput-object p0, Lc/y9;->j:Ljava/lang/String;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p3, :cond_1

    sget-object p0, Lc/y9;->c:Landroid/os/Handler;

    invoke-virtual {p0, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    return-void

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static c(Landroid/content/Context;)Ljava/lang/Boolean;
    .locals 11

    const-string v0, "yandex_weather"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-string v0, "solar_context_invalid"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x0

    if-nez v0, :cond_4

    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v0

    const-string v5, "request_timezone"

    const-string v6, ""

    invoke-interface {p0, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const-string v0, "solar_from"

    const-wide/16 v5, 0x0

    invoke-interface {p0, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    cmp-long v0, v2, v7

    const/4 v7, 0x1

    if-ltz v0, :cond_3

    const-string v0, "solar_until"

    invoke-interface {p0, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v8

    cmp-long v0, v2, v8

    if-ltz v0, :cond_1

    goto :goto_0

    :cond_1
    const-string v0, "sunrise"

    invoke-interface {p0, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v8

    cmp-long v0, v2, v8

    if-ltz v0, :cond_2

    const-string v0, "sunset"

    invoke-interface {p0, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v4

    cmp-long p0, v2, v4

    if-gez p0, :cond_2

    move v1, v7

    :cond_2
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0

    :cond_3
    :goto_0
    const-string v0, "updated_at"

    invoke-interface {p0, v0, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v8

    const-string v0, "details"

    const-string v10, "{}"

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/R0;->a(Ljava/lang/String;)Lc/R0;

    move-result-object v0

    const-string v10, "\u042f\u043d\u0434\u0435\u043a\u0441 \u041f\u043e\u0433\u043e\u0434\u0430"

    iget-object v0, v0, Lc/R0;->c:Ljava/lang/String;

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    cmp-long v0, v8, v5

    if-lez v0, :cond_4

    cmp-long v0, v2, v8

    if-ltz v0, :cond_4

    sub-long/2addr v2, v8

    const-wide/32 v5, 0x1b7740

    cmp-long v0, v2, v5

    if-gtz v0, :cond_4

    const-string v0, "night"

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    xor-int/2addr p0, v7

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    :cond_4
    :goto_1
    return-object v4
.end method

.method public static d(Landroid/content/Context;)Z
    .locals 2

    const-string v0, "yandex_weather"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "yandex_provider"

    const/4 v1, 0x1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    return p0
.end method

.method public static e(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const-string v0, "yandex_weather"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, "manual_city"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static f(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    sget-object v1, Ljava/text/Normalizer$Form;->NFC:Ljava/text/Normalizer$Form;

    invoke-static {p0, v1}, Ljava/text/Normalizer;->normalize(Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_9

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x50

    if-le v1, v2, :cond_1

    goto/16 :goto_3

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v6

    if-ge v4, v6, :cond_7

    invoke-virtual {p0, v4}, Ljava/lang/String;->codePointAt(I)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Character;->charCount(I)I

    move-result v7

    add-int/2addr v4, v7

    invoke-static {v6}, Ljava/lang/Character;->getType(I)I

    move-result v7

    const/16 v8, 0xf

    if-eq v7, v8, :cond_6

    const/16 v8, 0x10

    if-eq v7, v8, :cond_6

    const/16 v8, 0x12

    if-eq v7, v8, :cond_6

    const/16 v8, 0x13

    if-eq v7, v8, :cond_6

    if-nez v7, :cond_2

    goto :goto_2

    :cond_2
    invoke-static {v6}, Ljava/lang/Character;->isWhitespace(I)Z

    move-result v7

    if-nez v7, :cond_5

    invoke-static {v6}, Ljava/lang/Character;->isSpaceChar(I)Z

    move-result v7

    if-eqz v7, :cond_3

    goto :goto_1

    :cond_3
    if-eqz v5, :cond_4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    if-lez v5, :cond_4

    const/16 v5, 0x20

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_4
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->appendCodePoint(I)Ljava/lang/StringBuilder;

    move v5, v3

    goto :goto_0

    :cond_5
    :goto_1
    const/4 v5, 0x1

    goto :goto_0

    :cond_6
    :goto_2
    return-object v0

    :cond_7
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    if-eqz p0, :cond_9

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    if-le p0, v2, :cond_8

    goto :goto_3

    :cond_8
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_9
    :goto_3
    return-object v0
.end method

.method public static g(Lorg/json/JSONObject;)Lc/x9;
    .locals 23

    move-object/from16 v0, p0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/16 v3, 0xa

    const/4 v4, 0x1

    const-string v11, "solarUntil"

    const-string v12, "source"

    const-string v5, "schema"

    const-string v6, "details"

    const-string v7, "night"

    const-string v8, "sunrise"

    const-string v9, "sunset"

    const-string v10, "solarFrom"

    const-string v13, "cachedAt"

    const-string v14, "stale"

    filled-new-array/range {v5 .. v14}, [Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p0 .. p0}, Lorg/json/JSONObject;->length()I

    move-result v6

    const/4 v7, 0x0

    if-eq v6, v3, :cond_0

    goto :goto_1

    :cond_0
    move v6, v2

    :goto_0
    if-ge v6, v3, :cond_2

    aget-object v8, v5, v6

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_1

    :goto_1
    return-object v7

    :cond_1
    add-int/2addr v6, v4

    goto :goto_0

    :cond_2
    const-string v5, "schema"

    invoke-virtual {v0, v5}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    const-string v6, "night"

    invoke-virtual {v0, v6}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    const-string v8, "source"

    invoke-virtual {v0, v8}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    const-string v9, "stale"

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    const-string v10, "details"

    invoke-virtual {v0, v10}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    const-string v11, "cachedAt"

    invoke-static {v0, v11}, Lc/y9;->o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v11

    instance-of v12, v5, Ljava/lang/Number;

    if-eqz v12, :cond_27

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v12

    if-ne v12, v4, :cond_27

    invoke-virtual {v5}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v12

    const-wide/high16 v14, 0x3ff0000000000000L    # 1.0

    cmpl-double v5, v12, v14

    if-nez v5, :cond_27

    instance-of v5, v6, Ljava/lang/Boolean;

    if-eqz v5, :cond_27

    const-string v5, "open-meteo"

    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_27

    instance-of v5, v9, Ljava/lang/Boolean;

    if-eqz v5, :cond_27

    if-eqz v11, :cond_27

    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    const-wide v14, 0xdc6acfac00L

    cmp-long v5, v12, v14

    if-ltz v5, :cond_27

    if-nez v10, :cond_3

    goto/16 :goto_8

    :cond_3
    const-string v5, "locality"

    const-string v8, "attribution"

    const-string v12, "fact"

    filled-new-array {v5, v8, v12}, [Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v10}, Lorg/json/JSONObject;->length()I

    move-result v14

    if-eq v14, v1, :cond_4

    goto/16 :goto_8

    :cond_4
    move v14, v2

    :goto_2
    if-ge v14, v1, :cond_6

    aget-object v15, v13, v14

    invoke-virtual {v10, v15}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v15

    if-nez v15, :cond_5

    goto/16 :goto_8

    :cond_5
    add-int/2addr v14, v4

    goto :goto_2

    :cond_6
    invoke-virtual {v10, v5}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v13, v5, Ljava/lang/String;

    if-eqz v13, :cond_27

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v13, 0x100

    if-gt v5, v13, :cond_27

    const-string v5, "Open-Meteo.com"

    invoke-virtual {v10, v8}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_7

    goto/16 :goto_8

    :cond_7
    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_27

    const-string v20, "wind_speed"

    const-string v21, "wind_gust"

    const-string v12, "temp"

    const-string v13, "condition"

    const-string v14, "wind_dir"

    const-string v15, "feels_like"

    const-string v16, "humidity"

    const-string v17, "pressure_mm"

    const-string v18, "prec_prob"

    const-string v19, "uv_index"

    filled-new-array/range {v12 .. v21}, [Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5}, Lorg/json/JSONObject;->length()I

    move-result v12

    if-le v12, v3, :cond_8

    goto/16 :goto_8

    :cond_8
    invoke-virtual {v5}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v12

    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_a

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    move v14, v2

    :goto_4
    if-ge v14, v3, :cond_27

    aget-object v15, v8, v14

    invoke-virtual {v15, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_9

    goto :goto_3

    :cond_9
    add-int/2addr v14, v4

    goto :goto_4

    :cond_a
    const-string v8, "temp"

    const/16 v12, -0x64

    const/16 v13, 0x64

    invoke-static {v5, v8, v12, v13, v4}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "feels_like"

    const/16 v12, -0x78

    const/16 v14, 0x78

    invoke-static {v5, v8, v12, v14, v2}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "humidity"

    invoke-static {v5, v8, v2, v13, v2}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "pressure_mm"

    const/16 v12, 0x4b0

    invoke-static {v5, v8, v13, v12, v2}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "prec_prob"

    invoke-static {v5, v8, v2, v13, v2}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "uv_index"

    const/16 v12, 0x1e

    invoke-static {v5, v8, v2, v12, v2}, Lc/R0;->g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "wind_speed"

    invoke-static {v5, v8}, Lc/R0;->j(Lorg/json/JSONObject;Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_27

    const-string v8, "wind_gust"

    invoke-static {v5, v8}, Lc/R0;->j(Lorg/json/JSONObject;Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_b

    goto/16 :goto_8

    :cond_b
    const-string v8, "condition"

    invoke-virtual {v5, v8}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    const-string v12, "wind_dir"

    invoke-virtual {v5, v12}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    instance-of v12, v8, Ljava/lang/String;

    if-eqz v12, :cond_27

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, -0x1

    invoke-virtual {v8}, Ljava/lang/String;->hashCode()I

    move-result v13

    sparse-switch v13, :sswitch_data_0

    :goto_5
    move v1, v12

    goto/16 :goto_6

    :sswitch_0
    const-string v1, "showers"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto :goto_5

    :cond_c
    const/16 v1, 0x15

    goto/16 :goto_6

    :sswitch_1
    const-string v1, "moderate-rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    goto :goto_5

    :cond_d
    const/16 v1, 0x14

    goto/16 :goto_6

    :sswitch_2
    const-string v1, "thunderstorm-with-rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    goto :goto_5

    :cond_e
    const/16 v1, 0x13

    goto/16 :goto_6

    :sswitch_3
    const-string v1, "thunderstorm-with-hail"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    goto :goto_5

    :cond_f
    const/16 v1, 0x12

    goto/16 :goto_6

    :sswitch_4
    const-string v1, "drizzle"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    goto :goto_5

    :cond_10
    const/16 v1, 0x11

    goto/16 :goto_6

    :sswitch_5
    const-string v1, "heavy-rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_11

    goto :goto_5

    :cond_11
    const/16 v1, 0x10

    goto/16 :goto_6

    :sswitch_6
    const-string v1, "overcast"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_12

    goto :goto_5

    :cond_12
    const/16 v1, 0xf

    goto/16 :goto_6

    :sswitch_7
    const-string v1, "clear"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_13

    goto :goto_5

    :cond_13
    const/16 v1, 0xe

    goto/16 :goto_6

    :sswitch_8
    const-string v1, "snow-showers"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_14

    goto :goto_5

    :cond_14
    const/16 v1, 0xd

    goto/16 :goto_6

    :sswitch_9
    const-string v1, "snow"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_15

    goto/16 :goto_5

    :cond_15
    const/16 v1, 0xc

    goto/16 :goto_6

    :sswitch_a
    const-string v1, "rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_16

    goto/16 :goto_5

    :cond_16
    const/16 v1, 0xb

    goto/16 :goto_6

    :sswitch_b
    const-string v1, "mist"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    goto/16 :goto_5

    :cond_17
    move v1, v3

    goto/16 :goto_6

    :sswitch_c
    const-string v1, "hail"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_18

    goto/16 :goto_5

    :cond_18
    const/16 v1, 0x9

    goto/16 :goto_6

    :sswitch_d
    const-string v1, "fog"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_19

    goto/16 :goto_5

    :cond_19
    const/16 v1, 0x8

    goto/16 :goto_6

    :sswitch_e
    const-string v1, "wet-snow"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1a

    goto/16 :goto_5

    :cond_1a
    const/4 v1, 0x7

    goto :goto_6

    :sswitch_f
    const-string v1, "light-snow"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1b

    goto/16 :goto_5

    :cond_1b
    const/4 v1, 0x6

    goto :goto_6

    :sswitch_10
    const-string v1, "light-rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1c

    goto/16 :goto_5

    :cond_1c
    const/4 v1, 0x5

    goto :goto_6

    :sswitch_11
    const-string v1, "unknown"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1d

    goto/16 :goto_5

    :cond_1d
    const/4 v1, 0x4

    goto :goto_6

    :sswitch_12
    const-string v2, "partly-cloudy"

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_21

    goto/16 :goto_5

    :sswitch_13
    const-string v1, "continuous-heavy-rain"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1e

    goto/16 :goto_5

    :cond_1e
    const/4 v1, 0x2

    goto :goto_6

    :sswitch_14
    const-string v1, "cloudy"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f

    goto/16 :goto_5

    :cond_1f
    move v1, v4

    goto :goto_6

    :sswitch_15
    const-string v1, "thunderstorm"

    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_20

    goto/16 :goto_5

    :cond_20
    move v1, v2

    :cond_21
    :goto_6
    packed-switch v1, :pswitch_data_0

    goto/16 :goto_8

    :pswitch_0
    instance-of v1, v5, Ljava/lang/String;

    if-eqz v1, :cond_27

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "n"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "ne"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "e"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "se"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "s"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "sw"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "w"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    const-string v1, "nw"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_27

    :cond_22
    invoke-virtual {v10}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/R0;->a(Ljava/lang/String;)Lc/R0;

    move-result-object v13

    iget-object v1, v13, Lc/R0;->d:Ljava/lang/Integer;

    if-nez v1, :cond_23

    return-object v7

    :cond_23
    const-string v1, "sunrise"

    invoke-static {v0, v1}, Lc/y9;->o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "sunset"

    invoke-static {v0, v2}, Lc/y9;->o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    const-string v3, "solarFrom"

    invoke-static {v0, v3}, Lc/y9;->o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    const-string v4, "solarUntil"

    invoke-static {v0, v4}, Lc/y9;->o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    if-eqz v1, :cond_27

    if-eqz v2, :cond_27

    if-eqz v3, :cond_27

    if-nez v0, :cond_24

    goto/16 :goto_8

    :cond_24
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const-wide/16 v14, 0x0

    cmp-long v4, v4, v14

    if-nez v4, :cond_25

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    cmp-long v4, v4, v14

    if-nez v4, :cond_25

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    cmp-long v4, v4, v14

    if-nez v4, :cond_25

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    cmp-long v4, v4, v14

    if-nez v4, :cond_25

    goto :goto_7

    :cond_25
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v4, v4, v14

    if-gtz v4, :cond_27

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v4, v4, v14

    if-gez v4, :cond_27

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v4, v4, v14

    if-gtz v4, :cond_27

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    cmp-long v4, v4, v14

    if-ltz v4, :cond_26

    goto :goto_8

    :cond_26
    :goto_7
    new-instance v4, Lc/x9;

    new-instance v5, Lc/o9;

    check-cast v6, Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v14

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v15

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v17

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v19

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v21

    move-object v12, v5

    invoke-direct/range {v12 .. v22}, Lc/o9;-><init>(Lc/R0;ZJJJJ)V

    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    check-cast v9, Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    invoke-direct {v4, v5, v0, v1, v2}, Lc/x9;-><init>(Lc/o9;JZ)V

    return-object v4

    :cond_27
    :goto_8
    return-object v7

    nop

    :sswitch_data_0
    .sparse-switch
        -0x6fc1b57b -> :sswitch_15
        -0x50ea171c -> :sswitch_14
        -0x4e3db5a8 -> :sswitch_13
        -0x1b63456f -> :sswitch_12
        -0x10fa53b6 -> :sswitch_11
        -0xf300a15 -> :sswitch_10
        -0xf2f6426 -> :sswitch_f
        -0xedc8876 -> :sswitch_e
        0x18cbe -> :sswitch_d
        0x30bfdc -> :sswitch_c
        0x3324fd -> :sswitch_b
        0x354b94 -> :sswitch_a
        0x35f183 -> :sswitch_9
        0x48712ff -> :sswitch_8
        0x5a5b64d -> :sswitch_7
        0x1f902e13 -> :sswitch_6
        0x4c70e0da -> :sswitch_5
        0x72788cd4 -> :sswitch_4
        0x75c4473b -> :sswitch_3
        0x75c8d2f3 -> :sswitch_2
        0x78471a1e -> :sswitch_1
        0x7b387149 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z
    .locals 21

    move-object/from16 v0, p1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const-string v1, "yandex_weather"

    const/4 v11, 0x0

    invoke-virtual {v5, v1, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-static {v5}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    const/4 v12, 0x1

    if-eqz v1, :cond_6

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v5, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-virtual {v5, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    const-string v1, "location"

    invoke-virtual {v5, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/location/LocationManager;

    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    :try_start_0
    invoke-virtual {v1, v12}, Landroid/location/LocationManager;->getProviders(Z)Ljava/util/List;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v8, v2

    :cond_2
    :goto_0
    :try_start_1
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v1, v9}, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;

    move-result-object v9

    if-nez v9, :cond_3

    goto :goto_0

    :cond_3
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v13

    invoke-virtual {v9}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v15

    sub-long/2addr v13, v15

    invoke-virtual {v9}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v15

    cmp-long v10, v15, v3

    if-lez v10, :cond_2

    cmp-long v10, v13, v3

    if-ltz v10, :cond_2

    const-wide v15, 0x8bb2c97000L

    cmp-long v10, v13, v15

    if-lez v10, :cond_4

    goto :goto_0

    :cond_4
    if-eqz v8, :cond_5

    invoke-virtual {v9}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v13

    invoke-virtual {v8}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v15
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    cmp-long v10, v13, v15

    if-lez v10, :cond_2

    :cond_5
    move-object v8, v9

    goto :goto_0

    :catch_0
    :cond_6
    :goto_1
    move-object v8, v2

    :catch_1
    :cond_7
    sget-object v1, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v1

    :try_start_2
    invoke-static {v5}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lc/y9;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_8

    move-object v2, v8

    :cond_8
    invoke-static {v6, v9, v2}, Lc/y9;->p(Landroid/content/SharedPreferences;Ljava/lang/String;Landroid/location/Location;)Z

    move-result v2

    if-eqz v2, :cond_9

    sget-wide v9, Lc/y9;->k:J

    const-wide/16 v14, 0x1

    add-long/2addr v9, v14

    sput-wide v9, Lc/y9;->k:J

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string v10, "request_timezone"

    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v9, v10, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string v10, "solar_context_invalid"

    invoke-interface {v9, v10, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string v10, "relay_cached_at"

    invoke-interface {v9, v10, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_2

    :catchall_0
    move-exception v0

    move-object/from16 v18, v1

    goto/16 :goto_15

    :cond_9
    :goto_2
    sget-wide v14, Lc/y9;->k:J

    const-string v9, "temperature"

    const-string v10, "\u2212\u00b0"

    invoke-interface {v6, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lc/y9;->e:Ljava/lang/String;

    const-string v9, "condition"

    const-string v10, ""

    invoke-interface {v6, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    sput-object v9, Lc/y9;->f:Ljava/lang/String;

    const-string v9, "night"

    invoke-interface {v6, v9, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    sput-boolean v9, Lc/y9;->g:Z

    const-string v9, "stale"

    invoke-interface {v6, v9, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    sput-boolean v9, Lc/y9;->h:Z

    const-string v9, "details"

    const-string v10, "{}"

    invoke-interface {v6, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lc/R0;->a(Ljava/lang/String;)Lc/R0;

    move-result-object v9

    sput-object v9, Lc/y9;->i:Lc/R0;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    const-string v12, "request_at"

    invoke-interface {v6, v12, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v16

    const-string v12, "success_at"

    const-string v11, "updated_at"
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    move-object/from16 v18, v1

    :try_start_3
    invoke-interface {v6, v11, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    invoke-interface {v6, v12, v0, v1}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    cmp-long v11, v16, v3

    if-lez v11, :cond_a

    move-wide/from16 v11, v16

    goto :goto_3

    :cond_a
    move-wide v11, v0

    :goto_3
    cmp-long v11, v11, v9

    if-lez v11, :cond_b

    goto :goto_4

    :cond_b
    cmp-long v11, v0, v9

    if-lez v11, :cond_c

    :goto_4
    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "request_at"

    invoke-interface {v0, v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "success_at"

    invoke-interface {v0, v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    move-wide v0, v3

    move-wide/from16 v16, v0

    goto :goto_5

    :catchall_1
    move-exception v0

    goto/16 :goto_15

    :cond_c
    :goto_5
    cmp-long v11, v0, v3

    if-lez v11, :cond_f

    cmp-long v11, v9, v0

    if-ltz v11, :cond_d

    sub-long v11, v9, v0

    const-wide/32 v19, 0x1b7740

    cmp-long v11, v11, v19

    if-ltz v11, :cond_d

    goto :goto_6

    :cond_d
    cmp-long v0, v16, v0

    if-lez v0, :cond_e

    goto :goto_6

    :cond_e
    const/4 v0, 0x0

    goto :goto_7

    :cond_f
    :goto_6
    const/4 v0, 0x1

    :goto_7
    if-nez p3, :cond_11

    cmp-long v1, v16, v3

    if-lez v1, :cond_11

    sub-long v3, v9, v16

    const-wide/32 v11, 0x15f90

    cmp-long v1, v3, v11

    if-ltz v1, :cond_10

    goto :goto_8

    :cond_10
    const/4 v1, 0x0

    goto :goto_9

    :cond_11
    :goto_8
    const/4 v1, 0x1

    :goto_9
    if-nez p2, :cond_13

    if-nez v2, :cond_13

    const-string v2, "details_request_version"

    const/4 v3, 0x0

    invoke-interface {v6, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v3, 0x3

    if-ge v2, v3, :cond_12

    if-eqz v1, :cond_12

    goto :goto_a

    :cond_12
    const/4 v2, 0x0

    goto :goto_b

    :cond_13
    :goto_a
    const/4 v2, 0x1

    :goto_b
    if-eqz v0, :cond_14

    if-eqz v1, :cond_14

    const/4 v0, 0x1

    goto :goto_c

    :cond_14
    const/4 v0, 0x0

    :goto_c
    sget-object v1, Lc/y9;->j:Ljava/lang/String;

    invoke-virtual {v13, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_15

    sget-wide v3, Lc/y9;->l:J

    cmp-long v1, v14, v3

    if-nez v1, :cond_15

    goto :goto_d

    :cond_15
    if-nez v2, :cond_17

    if-eqz v0, :cond_16

    goto :goto_e

    :cond_16
    :goto_d
    const/4 v0, 0x0

    goto :goto_f

    :cond_17
    :goto_e
    const/4 v0, 0x1

    :goto_f
    if-eqz v0, :cond_19

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "request_at"

    invoke-interface {v1, v2, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    if-eqz v8, :cond_18

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_18

    const-string v2, "request_lat"

    invoke-virtual {v8}, Landroid/location/Location;->getLatitude()D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v3

    invoke-interface {v1, v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "request_lon"

    invoke-virtual {v8}, Landroid/location/Location;->getLongitude()D

    move-result-wide v9

    invoke-static {v9, v10}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v9

    invoke-interface {v2, v3, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    :cond_18
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    sput-object v13, Lc/y9;->j:Ljava/lang/String;

    sput-wide v14, Lc/y9;->l:J

    :cond_19
    monitor-exit v18
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    if-nez v0, :cond_1a

    invoke-interface/range {p1 .. p1}, Ljava/lang/Runnable;->run()V

    const/4 v0, 0x0

    return v0

    :cond_1a
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1c

    invoke-static {v7}, Lc/y9;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1b

    :try_start_4
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "city"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v9

    new-instance v0, Lc/u9;

    const/4 v7, 0x0

    move-object v1, v0

    move-object v2, v13

    move-wide v3, v14

    move-object/from16 v10, p1

    invoke-direct/range {v1 .. v10}, Lc/u9;-><init>(Ljava/lang/String;JLandroid/content/Context;Landroid/content/SharedPreferences;Landroid/location/Location;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Runnable;)V

    sget-object v1, Lc/y9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v0, 0x1

    return v0

    :catch_2
    move-exception v0

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Invalid city"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1c
    if-nez v8, :cond_1d

    invoke-static {}, Lc/j8;->u()Z

    move-result v0

    if-eqz v0, :cond_1d

    new-instance v0, Landroid/location/Location;

    const-string v1, "emulator"

    invoke-direct {v0, v1}, Landroid/location/Location;-><init>(Ljava/lang/String;)V

    const-wide v1, 0x404be0be0ded288dL    # 55.7558

    invoke-virtual {v0, v1, v2}, Landroid/location/Location;->setLatitude(D)V

    const-wide v1, 0x4042cf0d844d013bL    # 37.6176

    invoke-virtual {v0, v1, v2}, Landroid/location/Location;->setLongitude(D)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Landroid/location/Location;->setTime(J)V

    move-object v7, v0

    goto :goto_10

    :cond_1d
    move-object v7, v8

    :goto_10
    if-nez v7, :cond_22

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v5, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1e

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-virtual {v5, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1e

    move-object/from16 v0, p1

    invoke-static {v13, v14, v15, v0}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    :goto_11
    const/4 v11, 0x0

    goto/16 :goto_14

    :cond_1e
    move-object/from16 v0, p1

    const-string v1, "location"

    invoke-virtual {v5, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Landroid/location/LocationManager;

    if-nez v12, :cond_1f

    invoke-static {v13, v14, v15, v0}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    goto :goto_11

    :cond_1f
    new-instance v16, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct/range {v16 .. v16}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    new-instance v17, Lc/w9;

    move-object/from16 v1, v17

    move-object/from16 v2, v16

    move-object v3, v12

    move-object v4, v5

    move-object v5, v13

    move-wide v6, v14

    move-object/from16 v8, p1

    invoke-direct/range {v1 .. v8}, Lc/w9;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroid/location/LocationManager;Landroid/content/Context;Ljava/lang/String;JLjava/lang/Runnable;)V

    const/4 v1, 0x1

    :try_start_5
    invoke-virtual {v12, v1}, Landroid/location/LocationManager;->getProviders(Z)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1
    :try_end_5
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_4

    const/4 v3, 0x0

    :goto_12
    :try_start_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_20

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Ljava/lang/String;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2
    :try_end_6
    .catch Ljava/lang/SecurityException; {:try_start_6 .. :try_end_6} :catch_3

    const-wide/16 v8, 0x0

    const/4 v10, 0x0

    move-object v6, v12

    move-object/from16 v11, v17

    move-object v4, v12

    move-object v12, v2

    :try_start_7
    invoke-virtual/range {v6 .. v12}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;Landroid/os/Looper;)V
    :try_end_7
    .catch Ljava/lang/SecurityException; {:try_start_7 .. :try_end_7} :catch_5

    move-object v12, v4

    const/4 v3, 0x1

    goto :goto_12

    :catch_3
    :cond_20
    move-object v4, v12

    goto :goto_13

    :catch_4
    move-object v4, v12

    const/4 v3, 0x0

    :catch_5
    :goto_13
    if-nez v3, :cond_21

    invoke-static {v13, v14, v15, v0}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    goto :goto_11

    :cond_21
    sget-object v9, Lc/y9;->c:Landroid/os/Handler;

    new-instance v10, Lc/V8;

    move-object v1, v10

    move-object/from16 v2, v16

    move-object v3, v4

    move-object/from16 v4, v17

    move-object v5, v13

    move-wide v6, v14

    move-object/from16 v8, p1

    invoke-direct/range {v1 .. v8}, Lc/V8;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroid/location/LocationManager;Lc/w9;Ljava/lang/String;JLjava/lang/Runnable;)V

    const-wide/16 v0, 0x2ee0

    invoke-virtual {v9, v10, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v11, 0x1

    :goto_14
    return v11

    :cond_22
    move-object/from16 v0, p1

    :try_start_8
    invoke-static {v7}, Lc/y9;->j(Landroid/location/Location;)Lorg/json/JSONObject;

    move-result-object v8

    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v9

    new-instance v11, Lc/u9;

    move-object v1, v11

    move-object v2, v13

    move-wide v3, v14

    move-object/from16 v10, p1

    invoke-direct/range {v1 .. v10}, Lc/u9;-><init>(Ljava/lang/String;JLandroid/content/Context;Landroid/content/SharedPreferences;Landroid/location/Location;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Runnable;)V

    sget-object v1, Lc/y9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v11}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_6

    const/4 v0, 0x1

    return v0

    :catch_6
    invoke-static {v13, v14, v15, v0}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    const/4 v0, 0x0

    return v0

    :goto_15
    :try_start_9
    monitor-exit v18
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    throw v0
.end method

.method public static i()Ljava/net/URL;
    .locals 4

    const-string v0, "https://functions.yandexcloud.net/d4eies762ft4kmiqu40b"

    const/4 v1, 0x0

    :try_start_0
    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-string v0, "https"

    invoke-virtual {v2}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "functions.yandexcloud.net"

    invoke-virtual {v2}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, Ljava/net/URL;->getPort()I

    move-result v0

    const/4 v3, -0x1

    if-eq v0, v3, :cond_0

    invoke-virtual {v2}, Ljava/net/URL;->getPort()I

    move-result v0

    const/16 v3, 0x1bb

    if-ne v0, v3, :cond_1

    :cond_0
    const-string v0, "/d4eies762ft4kmiqu40b"

    invoke-virtual {v2}, Ljava/net/URL;->getPath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, Ljava/net/URL;->getQuery()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    invoke-virtual {v2}, Ljava/net/URL;->getRef()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_1

    invoke-virtual {v2}, Ljava/net/URL;->getUserInfo()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v0, :cond_1

    move-object v1, v2

    :catch_0
    :cond_1
    return-object v1
.end method

.method public static j(Landroid/location/Location;)Lorg/json/JSONObject;
    .locals 7

    invoke-virtual {p0}, Landroid/location/Location;->getLatitude()D

    move-result-wide v0

    invoke-virtual {p0}, Landroid/location/Location;->getLongitude()D

    move-result-wide v2

    invoke-static {v0, v1}, Ljava/lang/Double;->isFinite(D)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result p0

    if-eqz p0, :cond_0

    const-wide v4, -0x3fa9800000000000L    # -90.0

    cmpg-double p0, v0, v4

    if-ltz p0, :cond_0

    const-wide v4, 0x4056800000000000L    # 90.0

    cmpl-double p0, v0, v4

    if-gtz p0, :cond_0

    const-wide v4, -0x3f99800000000000L    # -180.0

    cmpg-double p0, v2, v4

    if-ltz p0, :cond_0

    const-wide v4, 0x4066800000000000L    # 180.0

    cmpl-double p0, v2, v4

    if-gtz p0, :cond_0

    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    invoke-static {v0, v1}, Ljava/math/BigDecimal;->valueOf(D)Ljava/math/BigDecimal;

    move-result-object v0

    sget-object v1, Ljava/math/RoundingMode;->HALF_UP:Ljava/math/RoundingMode;

    const/4 v4, 0x1

    invoke-virtual {v0, v4, v1}, Ljava/math/BigDecimal;->setScale(ILjava/math/RoundingMode;)Ljava/math/BigDecimal;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigDecimal;->doubleValue()D

    move-result-wide v5

    const-string v0, "lat"

    invoke-virtual {p0, v0, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object p0

    invoke-static {v2, v3}, Ljava/math/BigDecimal;->valueOf(D)Ljava/math/BigDecimal;

    move-result-object v0

    invoke-virtual {v0, v4, v1}, Ljava/math/BigDecimal;->setScale(ILjava/math/RoundingMode;)Ljava/math/BigDecimal;

    move-result-object v0

    invoke-virtual {v0}, Ljava/math/BigDecimal;->doubleValue()D

    move-result-wide v0

    const-string v2, "lon"

    invoke-virtual {p0, v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid location"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static k(Lru/drivedeck/launcher/MainActivity;ZLjava/lang/String;)Z
    .locals 9

    sget-object v0, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    const-string v1, "yandex_weather"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-static {p0}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    invoke-static {p0}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result p0

    if-ne p1, p0, :cond_0

    monitor-exit v0

    return v4

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    new-instance p0, Ljava/util/HashMap;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v3

    invoke-direct {p0, v3}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    const-string v3, "request_at"

    const-wide/16 v5, 0x0

    invoke-interface {v1, v3, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    cmp-long v3, v7, v5

    if-lez v3, :cond_1

    goto :goto_0

    :cond_1
    const-string v3, "updated_at"

    invoke-interface {v1, v3, v5, v6}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    :goto_0
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v5, "request_at"

    invoke-interface {v3, v5, v7, v8}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v5, "yandex_provider"

    invoke-interface {v3, v5, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2

    const-string v3, "manual_city"

    invoke-interface {p1, v3, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    :try_start_1
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result p1
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catch_0
    move p1, v2

    :goto_1
    if-nez p1, :cond_3

    :try_start_2
    invoke-static {v1, p0}, Lc/y9;->l(Landroid/content/SharedPreferences;Ljava/util/HashMap;)V

    monitor-exit v0

    return v2

    :cond_3
    sget-wide p0, Lc/y9;->k:J

    const-wide/16 v5, 0x1

    add-long/2addr p0, v5

    sput-wide p0, Lc/y9;->k:J

    const-string p0, "\u2212\u00b0"

    sput-object p0, Lc/y9;->e:Ljava/lang/String;

    const-string p0, ""

    sput-object p0, Lc/y9;->f:Ljava/lang/String;

    sput-boolean v2, Lc/y9;->g:Z

    sput-boolean v2, Lc/y9;->h:Z

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object p0

    invoke-virtual {p0, p2}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object p0

    sput-object p0, Lc/y9;->i:Lc/R0;

    const-string p0, ""

    sput-object p0, Lc/y9;->j:Ljava/lang/String;

    monitor-exit v0

    return v4

    :goto_2
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p0
.end method

.method public static l(Landroid/content/SharedPreferences;Ljava/util/HashMap;)V
    .locals 5

    :try_start_0
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-virtual {p1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    instance-of v2, v0, Ljava/lang/String;

    if-eqz v2, :cond_1

    check-cast v0, Ljava/lang/String;

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_1
    instance-of v2, v0, Ljava/lang/Boolean;

    if-eqz v2, :cond_2

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_2
    instance-of v2, v0, Ljava/lang/Integer;

    if-eqz v2, :cond_3

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_3
    instance-of v2, v0, Ljava/lang/Long;

    if-eqz v2, :cond_4

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-interface {p0, v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_4
    instance-of v2, v0, Ljava/lang/Float;

    if-eqz v2, :cond_5

    check-cast v0, Ljava/lang/Float;

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_5
    instance-of v2, v0, Ljava/util/Set;

    if-eqz v2, :cond_0

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    check-cast v0, Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Ljava/lang/String;

    if-eqz v4, :cond_0

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_6
    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_7
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public static m(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "gps"

    goto :goto_0

    :cond_0
    const-string v0, "city:"

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static n()Ljava/lang/String;
    .locals 4

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static o(Lorg/json/JSONObject;Ljava/lang/String;)Ljava/lang/Long;
    .locals 5

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/Number;

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v1

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    invoke-static {v1, v2}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    if-eqz v3, :cond_1

    long-to-double v3, p0

    cmpl-double v1, v1, v3

    if-nez v1, :cond_1

    const-wide/16 v1, 0x0

    cmp-long v1, p0, v1

    if-ltz v1, :cond_1

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public static p(Landroid/content/SharedPreferences;Ljava/lang/String;Landroid/location/Location;)Z
    .locals 13

    const-string v0, "request_timezone"

    const-string v1, ""

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x1

    if-nez p1, :cond_0

    return v0

    :cond_0
    const/4 p1, 0x0

    if-eqz p2, :cond_3

    const-string v1, "request_lat"

    invoke-interface {p0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_1

    :cond_1
    new-array v2, v0, [F

    const-wide/16 v3, 0x0

    invoke-interface {p0, v1, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v5

    const-string v1, "request_lon"

    invoke-interface {p0, v1, v3, v4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v7

    invoke-virtual {p2}, Landroid/location/Location;->getLatitude()D

    move-result-wide v9

    invoke-virtual {p2}, Landroid/location/Location;->getLongitude()D

    move-result-wide v11

    move-wide v3, v5

    move-wide v5, v7

    move-wide v7, v9

    move-wide v9, v11

    move-object v11, v2

    invoke-static/range {v3 .. v11}, Landroid/location/Location;->distanceBetween(DDDD[F)V

    aget p0, v2, p1

    const p2, 0x46c35000    # 25000.0f

    cmpl-float p0, p0, p2

    if-ltz p0, :cond_2

    goto :goto_0

    :cond_2
    move v0, p1

    :goto_0
    return v0

    :cond_3
    :goto_1
    return p1
.end method
