.class public final Lc/y7;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Z

.field public final d:J

.field public final e:J

.field public final f:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZJIJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/y7;->a:Ljava/lang/String;

    iput-object p2, p0, Lc/y7;->b:Ljava/lang/String;

    iput-boolean p3, p0, Lc/y7;->c:Z

    iput-wide p4, p0, Lc/y7;->d:J

    iput p6, p0, Lc/y7;->f:I

    iput-wide p7, p0, Lc/y7;->e:J

    return-void
.end method
