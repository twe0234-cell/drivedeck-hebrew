.class public final Lc/J8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/app/Activity;

.field public final b:Lc/n1;

.field public c:Landroid/widget/LinearLayout;

.field public d:Landroid/widget/TextView;

.field public e:Landroid/widget/Button;

.field public f:Landroid/widget/Button;

.field public g:Lc/U8;

.field public h:Z

.field public i:Z


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J8;->a:Landroid/app/Activity;

    new-instance v0, Lc/n1;

    invoke-direct {v0, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/J8;->b:Lc/n1;

    return-void
.end method


# virtual methods
.method public final a(I)I
    .locals 1

    iget-object v0, p0, Lc/J8;->a:Landroid/app/Activity;

    int-to-float p1, p1

    invoke-static {v0, p1}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    return p1
.end method
