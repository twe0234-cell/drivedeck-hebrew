.class public final Lc/h4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public a:I

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:I

.field public final synthetic d:J

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lc/v1;

.field public final synthetic g:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/content/Context;IJLjava/lang/String;Lc/v1;Landroid/os/Handler;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/h4;->b:Landroid/content/Context;

    iput p2, p0, Lc/h4;->c:I

    iput-wide p3, p0, Lc/h4;->d:J

    iput-object p5, p0, Lc/h4;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/h4;->f:Lc/v1;

    iput-object p7, p0, Lc/h4;->g:Landroid/os/Handler;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget-object v0, p0, Lc/h4;->f:Lc/v1;

    new-instance v1, Lc/n1;

    iget-object v2, p0, Lc/h4;->b:Landroid/content/Context;

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    sget v3, Lc/G8;->B:I

    iget v4, p0, Lc/h4;->c:I

    if-ne v4, v3, :cond_8

    iget-wide v3, p0, Lc/h4;->d:J

    invoke-virtual {v1}, Lc/n1;->t0()J

    move-result-wide v5

    cmp-long v3, v3, v5

    if-nez v3, :cond_8

    invoke-static {v2, v1}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lc/h4;->e:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_1

    :cond_0
    const/4 v1, 0x1

    :try_start_0
    const-string v4, "media_session"

    invoke-virtual {v2, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/media/session/MediaSessionManager;

    const/4 v5, 0x0

    if-eqz v4, :cond_6

    invoke-static {v2, v4}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/media/session/MediaController;

    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {v4}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v6

    if-nez v6, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v5

    if-eqz v5, :cond_4

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v7

    const/4 v8, 0x3

    if-eq v7, v8, :cond_3

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v5

    const/4 v7, 0x6

    if-ne v5, v7, :cond_4

    :cond_3
    return-void

    :cond_4
    iget-object v5, v0, Lc/v1;->a:Ljava/lang/String;

    const-string v7, "android.media.metadata.TITLE"

    invoke-virtual {v6, v7}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5

    iget-object v5, v0, Lc/v1;->b:Ljava/lang/String;

    const-string v7, "android.media.metadata.ARTIST"

    invoke-virtual {v6, v7}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-virtual {v4}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v2

    iget-wide v3, v0, Lc/v1;->c:J

    invoke-virtual {v2, v3, v4}, Landroid/media/session/MediaController$TransportControls;->seekTo(J)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :cond_5
    move v5, v1

    goto :goto_0

    :cond_6
    if-eqz v5, :cond_7

    return-void

    :catch_0
    :cond_7
    iget v0, p0, Lc/h4;->a:I

    add-int/2addr v0, v1

    iput v0, p0, Lc/h4;->a:I

    const/16 v1, 0x8

    if-ge v0, v1, :cond_8

    iget-object v0, p0, Lc/h4;->g:Landroid/os/Handler;

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_8
    :goto_1
    return-void
.end method
