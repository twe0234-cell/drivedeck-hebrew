.class public final Lc/Q0;
.super Landroid/app/Dialog;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/H;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lc/Q0;->a:I

    .line 6
    iput-object p2, p0, Lc/Q0;->b:Ljava/lang/Object;

    invoke-direct {p0, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;)V
    .locals 3

    const/4 v0, 0x1

    iput v0, p0, Lc/Q0;->a:I

    .line 1
    invoke-direct {p0, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 2
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 3
    new-instance v0, Lc/O7;

    new-instance v1, Lc/i;

    const/16 v2, 0xe

    invoke-direct {v1, p0, v2}, Lc/i;-><init>(Ljava/lang/Object;I)V

    const/4 v2, 0x0

    invoke-direct {v0, p1, p2, v2, v1}, Lc/O7;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;ZLjava/lang/Runnable;)V

    iput-object v0, p0, Lc/Q0;->b:Ljava/lang/Object;

    .line 4
    invoke-virtual {p0, v0}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 5
    new-instance p2, Lc/c1;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lc/c1;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p0, p2}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    return-void
.end method


# virtual methods
.method public onWindowFocusChanged(Z)V
    .locals 1

    iget v0, p0, Lc/Q0;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0, p1}, Landroid/app/Dialog;->onWindowFocusChanged(Z)V

    return-void

    :pswitch_0
    invoke-super {p0, p1}, Landroid/app/Dialog;->onWindowFocusChanged(Z)V

    if-eqz p1, :cond_0

    iget-object p1, p0, Lc/Q0;->b:Ljava/lang/Object;

    check-cast p1, Lc/H;

    invoke-virtual {p1}, Lc/H;->run()V

    :cond_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public show()V
    .locals 3

    iget v0, p0, Lc/Q0;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Landroid/app/Dialog;->show()V

    return-void

    :pswitch_0
    invoke-super {p0}, Landroid/app/Dialog;->show()V

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_0

    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    iget v2, v2, Lc/r4;->a:I

    invoke-direct {v1, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    const/4 v1, -0x1

    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setLayout(II)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/view/Window;->setSoftInputMode(I)V

    invoke-static {v0}, Lc/b4;->b(Landroid/view/Window;)V

    :cond_0
    iget-object v0, p0, Lc/Q0;->b:Ljava/lang/Object;

    check-cast v0, Lc/O7;

    invoke-virtual {v0}, Lc/O7;->n()V

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
