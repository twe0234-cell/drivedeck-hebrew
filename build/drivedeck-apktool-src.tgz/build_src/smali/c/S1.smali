.class public final Lc/S1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lru/drivedeck/launcher/LauncherAccessibilityService;

.field public final b:Landroid/view/WindowManager;

.field public final c:Lc/z;

.field public d:Lc/b2;

.field public e:Lc/p7;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    const-string v0, "window"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    iput-object v0, p0, Lc/S1;->b:Landroid/view/WindowManager;

    new-instance v0, Lc/z;

    invoke-direct {v0, p1}, Lc/z;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/S1;->c:Lc/z;

    return-void
.end method


# virtual methods
.method public final a()Lc/Q1;
    .locals 2

    new-instance v0, Lc/n1;

    iget-object v1, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->i()Lc/u0;

    move-result-object v0

    iget-object v0, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q1;

    return-object v0
.end method

.method public final b(Lc/Q1;)Landroid/view/WindowManager$LayoutParams;
    .locals 13

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    iget-object v1, p0, Lc/S1;->b:Landroid/view/WindowManager;

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v1, v0, Landroid/graphics/Point;->x:I

    iget v2, v0, Landroid/graphics/Point;->y:I

    invoke-static {v1, v2}, Lc/G8;->M(II)Z

    move-result v1

    const/high16 v2, 0x42b80000    # 92.0f

    const/high16 v3, 0x41c00000    # 24.0f

    const/4 v4, 0x1

    const/high16 v5, 0x41400000    # 12.0f

    iget-object v6, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v1, :cond_0

    new-instance p1, Landroid/view/WindowManager$LayoutParams;

    iget v0, v0, Landroid/graphics/Point;->x:I

    invoke-static {v6, v3}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-static {v6, v2}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v9

    const/16 v11, 0x308

    const/4 v12, -0x3

    const/16 v10, 0x7f6

    move-object v7, p1

    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const v0, 0x800053

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    invoke-static {v6, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v0

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v6, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v0

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->y:I

    return-object p1

    :cond_0
    new-instance v1, Landroid/view/WindowManager$LayoutParams;

    invoke-static {v6, v2}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v8

    iget v0, v0, Landroid/graphics/Point;->y:I

    invoke-static {v6, v3}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v2

    sub-int/2addr v0, v2

    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v9

    const/16 v11, 0x308

    const/4 v12, -0x3

    const/16 v10, 0x7f6

    move-object v7, v1

    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    sget-object v0, Lc/Q1;->b:Lc/Q1;

    if-ne p1, v0, :cond_1

    const p1, 0x800005

    goto :goto_0

    :cond_1
    const p1, 0x800003

    :goto_0
    or-int/lit8 p1, p1, 0x30

    iput p1, v1, Landroid/view/WindowManager$LayoutParams;->gravity:I

    invoke-static {v6, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    iput p1, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    invoke-static {v6, v5}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result p1

    iput p1, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    return-object v1
.end method

.method public final c()V
    .locals 3

    iget-object v0, p0, Lc/S1;->e:Lc/p7;

    const/4 v1, 0x0

    iget-object v2, p0, Lc/S1;->b:Landroid/view/WindowManager;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-interface {v2, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iput-object v1, p0, Lc/S1;->e:Lc/p7;

    :goto_0
    iget-object v0, p0, Lc/S1;->d:Lc/b2;

    if-nez v0, :cond_1

    return-void

    :cond_1
    :try_start_1
    invoke-interface {v2, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    iput-object v1, p0, Lc/S1;->d:Lc/b2;

    return-void
.end method

.method public final d(Ljava/util/ArrayList;)V
    .locals 7

    iget-object v0, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-static {v0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lc/S1;->c:Lc/z;

    invoke-virtual {v1}, Lc/z;->k()V

    invoke-virtual {p0}, Lc/S1;->a()Lc/Q1;

    move-result-object v2

    iget-object v3, p0, Lc/S1;->d:Lc/b2;

    iget-object v4, p0, Lc/S1;->b:Landroid/view/WindowManager;

    if-eqz v3, :cond_1

    invoke-virtual {v3, p1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object p1, p0, Lc/S1;->d:Lc/b2;

    invoke-virtual {p0}, Lc/S1;->g()Z

    move-result v0

    invoke-virtual {p1, v0}, Lc/b2;->E(Z)V

    :try_start_0
    iget-object p1, p0, Lc/S1;->d:Lc/b2;

    invoke-virtual {p0, v2}, Lc/S1;->b(Lc/Q1;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-interface {v4, p1, v0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    iget-object p1, p0, Lc/S1;->d:Lc/b2;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_1
    new-instance v3, Lc/b2;

    new-instance v5, Lc/v8;

    const/4 v6, 0x2

    invoke-direct {v5, p0, v6}, Lc/v8;-><init>(Ljava/lang/Object;I)V

    invoke-direct {v3, v0, v1, p1, v5}, Lc/b2;-><init>(Landroid/content/Context;Lc/z;Ljava/util/ArrayList;Lc/v8;)V

    iput-object v3, p0, Lc/S1;->d:Lc/b2;

    invoke-virtual {p0}, Lc/S1;->g()Z

    move-result p1

    invoke-virtual {v3, p1}, Lc/b2;->E(Z)V

    iget-object p1, p0, Lc/S1;->d:Lc/b2;

    invoke-virtual {p0, v2}, Lc/S1;->b(Lc/Q1;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    invoke-interface {v4, p1, v0}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final e(Ljava/util/ArrayList;)V
    .locals 12

    invoke-virtual {p0, p1}, Lc/S1;->d(Ljava/util/ArrayList;)V

    iget-object p1, p0, Lc/S1;->e:Lc/p7;

    iget-object v0, p0, Lc/S1;->b:Landroid/view/WindowManager;

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-interface {v0, p1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 p1, 0x0

    iput-object p1, p0, Lc/S1;->e:Lc/p7;

    :goto_0
    invoke-virtual {p0}, Lc/S1;->a()Lc/Q1;

    move-result-object p1

    new-instance v1, Lc/n1;

    iget-object v2, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Lc/p7;

    new-instance v6, Lc/R1;

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    iput-object p0, v6, Lc/R1;->c:Ljava/lang/Object;

    iput-object v3, v6, Lc/R1;->a:Ljava/lang/Object;

    iput-object v1, v6, Lc/R1;->b:Ljava/lang/Object;

    invoke-direct {v5, v2, v6}, Lc/p7;-><init>(Landroid/content/Context;Lc/R1;)V

    iput-object v5, p0, Lc/S1;->e:Lc/p7;

    new-instance v1, Landroid/graphics/Point;

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v3, v1, Landroid/graphics/Point;->x:I

    iget v5, v1, Landroid/graphics/Point;->y:I

    invoke-static {v3, v5}, Lc/G8;->M(II)Z

    move-result v3

    if-eqz v3, :cond_1

    iget v1, v1, Landroid/graphics/Point;->x:I

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-static {v2, v5}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    :goto_1
    sub-int/2addr v1, v5

    goto :goto_2

    :cond_1
    iget v1, v1, Landroid/graphics/Point;->x:I

    const/high16 v5, 0x43000000    # 128.0f

    invoke-static {v2, v5}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    goto :goto_1

    :goto_2
    new-instance v11, Landroid/view/WindowManager$LayoutParams;

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v6

    const/high16 v1, 0x42080000    # 34.0f

    invoke-static {v2, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v7

    const/4 v10, -0x3

    const/16 v8, 0x7f6

    const/16 v9, 0x308

    move-object v5, v11

    invoke-direct/range {v5 .. v10}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    if-eqz v3, :cond_2

    const p1, 0x800033

    goto :goto_4

    :cond_2
    sget-object v1, Lc/Q1;->b:Lc/Q1;

    if-ne p1, v1, :cond_3

    const p1, 0x800005

    goto :goto_3

    :cond_3
    const p1, 0x800003

    :goto_3
    or-int/lit8 p1, p1, 0x50

    :goto_4
    iput p1, v11, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/high16 p1, 0x41400000    # 12.0f

    if-eqz v3, :cond_4

    invoke-static {v2, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    :goto_5
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    goto :goto_6

    :cond_4
    const/high16 v1, 0x42e80000    # 116.0f

    invoke-static {v2, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    goto :goto_5

    :goto_6
    iput v1, v11, Landroid/view/WindowManager$LayoutParams;->x:I

    if-eqz v3, :cond_5

    invoke-static {v2, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    iput p1, v11, Landroid/view/WindowManager$LayoutParams;->y:I

    :cond_5
    iget-object p1, p0, Lc/S1;->e:Lc/p7;

    invoke-interface {v0, p1, v11}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final f(Ljava/util/List;)V
    .locals 9

    iget-object v0, p0, Lc/S1;->e:Lc/p7;

    if-eqz v0, :cond_d

    if-nez p1, :cond_0

    goto/16 :goto_4

    :cond_0
    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    iget-object v1, p0, Lc/S1;->b:Landroid/view/WindowManager;

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v1, v0, Landroid/graphics/Point;->x:I

    div-int/lit8 v1, v1, 0x2

    new-instance v2, Landroid/graphics/Rect;

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v3, -0x1

    move v4, v3

    :cond_1
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x1

    if-eqz v5, :cond_6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/view/accessibility/AccessibilityWindowInfo;

    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityWindowInfo;->getType()I

    move-result v7

    if-eq v7, v6, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v5, v2}, Landroid/view/accessibility/AccessibilityWindowInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v5

    iget v6, v0, Landroid/graphics/Point;->y:I

    div-int/lit8 v6, v6, 0x2

    if-lt v5, v6, :cond_1

    invoke-virtual {v2}, Landroid/graphics/Rect;->width()I

    move-result v5

    iget v6, v0, Landroid/graphics/Point;->x:I

    div-int/lit8 v7, v6, 0x5

    if-ge v5, v7, :cond_3

    goto :goto_0

    :cond_3
    iget v5, v2, Landroid/graphics/Rect;->right:I

    div-int/lit8 v6, v6, 0xa

    add-int/2addr v6, v1

    if-gt v5, v6, :cond_4

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    :cond_4
    iget v5, v2, Landroid/graphics/Rect;->left:I

    iget v6, v0, Landroid/graphics/Point;->x:I

    div-int/lit8 v6, v6, 0xa

    sub-int v6, v1, v6

    if-lt v5, v6, :cond_1

    if-ltz v4, :cond_5

    if-ge v5, v4, :cond_1

    :cond_5
    move v4, v5

    goto :goto_0

    :cond_6
    if-ltz v3, :cond_d

    if-ltz v4, :cond_d

    if-ge v4, v3, :cond_7

    goto :goto_4

    :cond_7
    invoke-virtual {p0}, Lc/S1;->a()Lc/Q1;

    move-result-object p1

    iget v1, v0, Landroid/graphics/Point;->y:I

    iget v2, v0, Landroid/graphics/Point;->x:I

    if-le v1, v2, :cond_8

    move v1, v6

    goto :goto_1

    :cond_8
    const/4 v1, 0x0

    :goto_1
    const/high16 v2, 0x42e80000    # 116.0f

    const/high16 v5, 0x41400000    # 12.0f

    if-eqz v1, :cond_a

    :cond_9
    move v7, v5

    goto :goto_2

    :cond_a
    sget-object v7, Lc/Q1;->a:Lc/Q1;

    if-ne p1, v7, :cond_9

    move v7, v2

    :goto_2
    iget-object v8, p0, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-static {v8, v7}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v7

    iget v0, v0, Landroid/graphics/Point;->x:I

    if-eqz v1, :cond_c

    :cond_b
    move v2, v5

    goto :goto_3

    :cond_c
    sget-object v1, Lc/Q1;->b:Lc/Q1;

    if-ne p1, v1, :cond_b

    :goto_3
    invoke-static {v8, v2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    sub-int/2addr v0, p1

    add-int/2addr v3, v4

    int-to-float p1, v3

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr p1, v1

    iget-object v1, p0, Lc/S1;->e:Lc/p7;

    int-to-float v2, v7

    sub-float/2addr p1, v2

    sub-int/2addr v0, v7

    invoke-static {v6, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p1, v0

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v0, 0x3f59999a    # 0.85f

    invoke-static {v0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const v0, 0x3e19999a    # 0.15f

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iput p1, v1, Lc/p7;->e:F

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    :cond_d
    :goto_4
    return-void
.end method

.method public final g()Z
    .locals 2

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    iget-object v1, p0, Lc/S1;->b:Landroid/view/WindowManager;

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget v1, v0, Landroid/graphics/Point;->x:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    invoke-static {v1, v0}, Lc/G8;->M(II)Z

    move-result v0

    return v0
.end method
