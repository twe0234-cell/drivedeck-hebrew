.class public final Lc/u0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V
    .locals 0

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    .line 8
    sget-object p1, Lc/Q1;->a:Lc/Q1;

    :cond_0
    iput-object p1, p0, Lc/u0;->b:Ljava/lang/Object;

    if-nez p2, :cond_1

    .line 9
    sget-object p2, Lc/q0;->a:Lc/q0;

    :cond_1
    iput-object p2, p0, Lc/u0;->c:Ljava/lang/Object;

    .line 10
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1, p3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lc/u0;->d:Ljava/lang/Object;

    const/16 p1, 0x48

    if-ne p4, p1, :cond_2

    goto :goto_0

    :cond_2
    const/16 p1, 0x24

    .line 11
    :goto_0
    iput p1, p0, Lc/u0;->a:I

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lc/u0;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/u0;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/u0;->d:Ljava/lang/Object;

    iput p4, p0, Lc/u0;->a:I

    return-void
.end method

.method public constructor <init>(Ljava/util/List;)V
    .locals 3

    sget-object v0, Lc/Q1;->a:Lc/Q1;

    sget-object v1, Lc/q0;->a:Lc/q0;

    const/16 v2, 0x24

    .line 6
    invoke-direct {p0, v0, v1, p1, v2}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 2

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/u0;->c:Ljava/lang/Object;

    .line 5
    iput-object p1, p0, Lc/u0;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;[Lc/k3;ILjava/lang/String;)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/u0;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/u0;->b:Ljava/lang/Object;

    iput p3, p0, Lc/u0;->a:I

    iput-object p4, p0, Lc/u0;->c:Ljava/lang/Object;

    return-void
.end method

.method public static c()Lc/u0;
    .locals 19

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v9, Lc/r0;

    sget-object v2, Lc/s0;->b:Lc/s0;

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x0

    move-object v1, v9

    invoke-direct/range {v1 .. v8}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v11, Lc/s0;->c:Lc/s0;

    const/4 v15, 0x7

    const/16 v16, 0x6

    const/4 v12, 0x0

    const/16 v13, 0xc

    const/4 v14, 0x0

    const/16 v17, 0x0

    move-object v10, v1

    invoke-direct/range {v10 .. v17}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v3, Lc/s0;->g:Lc/s0;

    const/16 v7, 0xf

    const/4 v8, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x0

    move-object v2, v1

    invoke-direct/range {v2 .. v9}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v11, Lc/s0;->f:Lc/s0;

    const/4 v15, 0x7

    const/16 v16, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x1

    const/16 v17, 0x0

    move-object v10, v1

    invoke-direct/range {v10 .. v17}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v3, Lc/s0;->d:Lc/s0;

    sget-object v10, Lc/t0;->d:Lc/t0;

    const/4 v7, 0x7

    const/16 v8, 0x12

    const/4 v4, 0x0

    const/16 v5, 0x12

    const/4 v6, 0x0

    const/4 v9, 0x0

    move-object v2, v1

    invoke-direct/range {v2 .. v9}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v12, Lc/s0;->e:Lc/s0;

    const/16 v16, 0x7

    const/16 v17, 0x12

    const/4 v13, 0x7

    const/16 v14, 0x12

    const/4 v15, 0x0

    const/16 v18, 0x0

    move-object v11, v1

    invoke-direct/range {v11 .. v18}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v3, Lc/s0;->h:Lc/s0;

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v9, 0x0

    move-object v2, v1

    invoke-direct/range {v2 .. v9}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v12, Lc/s0;->j:Lc/s0;

    const/16 v16, 0xf

    const/16 v17, 0x12

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x1

    const/16 v18, 0x0

    move-object v11, v1

    invoke-direct/range {v11 .. v18}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v3, Lc/s0;->i:Lc/s0;

    const/4 v6, 0x0

    const/16 v7, 0xf

    const/16 v4, 0xf

    const/4 v5, 0x0

    const/16 v8, 0x24

    const/4 v9, 0x1

    move-object v2, v1

    invoke-direct/range {v2 .. v9}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v12, Lc/s0;->k:Lc/s0;

    const/16 v16, 0x16

    const/16 v17, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x1

    const/16 v18, 0x0

    move-object v11, v1

    invoke-direct/range {v11 .. v18}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/r0;

    sget-object v2, Lc/s0;->l:Lc/s0;

    const/4 v3, 0x1

    invoke-direct {v1, v2, v10, v3}, Lc/r0;-><init>(Lc/s0;Lc/t0;Z)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lc/u0;

    invoke-direct {v1, v0}, Lc/u0;-><init>(Ljava/util/List;)V

    invoke-static {v1}, Lc/u0;->r(Lc/u0;)Lc/u0;

    move-result-object v0

    return-object v0
.end method

.method public static f([[ZLc/r0;)Z
    .locals 7

    iget v0, p1, Lc/r0;->e:I

    const/4 v1, 0x0

    iget v2, p1, Lc/r0;->c:I

    if-ltz v2, :cond_4

    iget v3, p1, Lc/r0;->d:I

    if-ltz v3, :cond_4

    add-int v4, v2, v0

    const/16 v5, 0x1e

    if-gt v4, v5, :cond_4

    iget p1, p1, Lc/r0;->f:I

    add-int v4, v3, p1

    array-length v5, p0

    if-le v4, v5, :cond_0

    goto :goto_2

    :cond_0
    move v4, v3

    :goto_0
    add-int v5, v3, p1

    if-ge v4, v5, :cond_3

    move v5, v2

    :goto_1
    add-int v6, v2, v0

    if-ge v5, v6, :cond_2

    aget-object v6, p0, v4

    aget-boolean v6, v6, v5

    if-eqz v6, :cond_1

    return v1

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_3
    const/4 p0, 0x1

    return p0

    :cond_4
    :goto_2
    return v1
.end method

.method public static i(Lc/r0;)Ljava/math/BigInteger;
    .locals 5

    sget-object v0, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    iget v1, p0, Lc/r0;->d:I

    :goto_0
    iget v2, p0, Lc/r0;->d:I

    iget v3, p0, Lc/r0;->f:I

    add-int/2addr v2, v3

    if-ge v1, v2, :cond_1

    iget v2, p0, Lc/r0;->c:I

    move v3, v2

    :goto_1
    iget v4, p0, Lc/r0;->e:I

    add-int/2addr v4, v2

    if-ge v3, v4, :cond_0

    mul-int/lit8 v4, v1, 0x1e

    add-int/2addr v4, v3

    invoke-virtual {v0, v4}, Ljava/math/BigInteger;->setBit(I)Ljava/math/BigInteger;

    move-result-object v0

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static j(Lc/s0;)Lc/r0;
    .locals 10

    sget-object v0, Lc/s0;->l:Lc/s0;

    sget-object v1, Lc/t0;->c:Lc/t0;

    if-ne p0, v0, :cond_0

    new-instance v0, Lc/r0;

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x0

    move-object v2, v0

    move-object v3, p0

    invoke-direct/range {v2 .. v9}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    goto :goto_0

    :cond_0
    new-instance v0, Lc/r0;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lc/r0;-><init>(Lc/s0;Lc/t0;Z)V

    :goto_0
    return-object v0
.end method

.method public static k([[ZLc/r0;)V
    .locals 6

    iget v0, p1, Lc/r0;->d:I

    move v1, v0

    :goto_0
    iget v2, p1, Lc/r0;->f:I

    add-int/2addr v2, v0

    if-ge v1, v2, :cond_1

    iget v2, p1, Lc/r0;->c:I

    move v3, v2

    :goto_1
    iget v4, p1, Lc/r0;->e:I

    add-int/2addr v4, v2

    if-ge v3, v4, :cond_0

    aget-object v4, p0, v1

    const/4 v5, 0x1

    aput-boolean v5, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static m(Ljava/lang/String;)Lc/u0;
    .locals 13

    const/4 v0, 0x0

    const v1, 0x9600

    if-eqz p0, :cond_11

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_11

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const-string v3, "auto"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto/16 :goto_8

    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const-string v2, "[;,]"

    invoke-virtual {p0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    array-length v2, p0

    const/4 v3, 0x1

    const-string v4, "baud"

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ne v2, v3, :cond_4

    aget-object v2, p0, v6

    const/16 v7, 0x3a

    invoke-virtual {v2, v7}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    if-ltz v2, :cond_4

    aget-object p0, p0, v6

    const-string v2, ":"

    invoke-virtual {p0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    array-length v2, p0

    if-lez v2, :cond_1

    aget-object v2, p0, v6

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_1

    aget-object v2, p0, v6

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    goto :goto_0

    :cond_1
    move-object v2, v0

    :goto_0
    array-length v6, p0

    if-le v6, v3, :cond_2

    aget-object v6, p0, v3

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_2

    aget-object v3, p0, v3

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_1

    :cond_2
    move-object v3, v0

    :goto_1
    array-length v6, p0

    if-le v6, v5, :cond_10

    aget-object v6, p0, v5

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_10

    aget-object p0, p0, v5

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_3

    goto/16 :goto_7

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    array-length v2, p0

    move-object v7, v0

    move v8, v1

    move v9, v6

    move-object v1, v7

    :goto_2
    if-ge v9, v2, :cond_f

    aget-object v10, p0, v9

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    const-string v12, "="

    invoke-virtual {v11, v12, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v11

    array-length v12, v11

    if-eq v12, v5, :cond_5

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_6

    :cond_5
    aget-object v10, v11, v6

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v10, v12}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v10

    aget-object v11, v11, v3

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    const-string v12, "vid"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_d

    const-string v12, "vendor"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_d

    const-string v12, "vendorid"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_6

    goto :goto_5

    :cond_6
    const-string v12, "pid"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_c

    const-string v12, "product"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_c

    const-string v12, "productid"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_7

    goto :goto_4

    :cond_7
    invoke-virtual {v10, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_a

    const-string v12, "baudrate"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_a

    const-string v12, "speed"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_8

    goto :goto_3

    :cond_8
    const-string v12, "device"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_9

    const-string v12, "deviceid"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_e

    :cond_9
    move-object v0, v11

    goto :goto_6

    :cond_a
    :goto_3
    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v8

    if-lez v8, :cond_b

    goto :goto_6

    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    :goto_4
    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    goto :goto_6

    :cond_d
    :goto_5
    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Integer;->decode(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v1

    :cond_e
    :goto_6
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_2

    :cond_f
    move-object v2, v1

    move-object v3, v7

    move v1, v8

    :cond_10
    :goto_7
    new-instance p0, Lc/u0;

    invoke-direct {p0, v0, v2, v3, v1}, Lc/u0;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;I)V

    return-object p0

    :cond_11
    :goto_8
    new-instance p0, Lc/u0;

    invoke-direct {p0, v0, v0, v0, v1}, Lc/u0;-><init>(Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;I)V

    return-object p0
.end method

.method public static o(Ljava/util/ArrayList;[Ljava/math/BigInteger;[Lc/r0;ILjava/math/BigInteger;ILjava/util/HashSet;[IIJ)Z
    .locals 26

    move-object/from16 v11, p0

    move/from16 v12, p3

    move-object/from16 v13, p4

    move-object/from16 v14, p6

    move/from16 v15, p8

    invoke-virtual/range {p0 .. p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v9, 0x1

    if-ne v12, v0, :cond_0

    return v9

    :cond_0
    const/16 v16, 0x0

    aget v0, p7, v16

    sub-int/2addr v0, v9

    aput v0, p7, v16

    if-ltz v0, :cond_14

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    cmp-long v0, v0, p9

    if-ltz v0, :cond_1

    goto/16 :goto_a

    :cond_1
    const/16 v10, 0x1e

    move v2, v10

    move v0, v12

    move/from16 v1, v16

    :goto_0
    invoke-virtual/range {p0 .. p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v0, v3, :cond_2

    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/r0;

    iget v4, v3, Lc/r0;->e:I

    iget v3, v3, Lc/r0;->f:I

    mul-int/2addr v3, v4

    add-int/2addr v1, v3

    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    move/from16 v0, v16

    move v3, v0

    :goto_1
    if-ge v0, v15, :cond_6

    move/from16 v4, v16

    move v5, v4

    :goto_2
    if-gt v4, v10, :cond_5

    if-ge v4, v10, :cond_3

    mul-int/lit8 v6, v0, 0x1e

    add-int/2addr v6, v4

    invoke-virtual {v13, v6}, Ljava/math/BigInteger;->testBit(I)Z

    move-result v6

    if-nez v6, :cond_3

    add-int/lit8 v5, v5, 0x1

    goto :goto_3

    :cond_3
    if-lt v5, v2, :cond_4

    add-int/2addr v3, v5

    :cond_4
    move/from16 v5, v16

    :goto_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_5
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_6
    if-ge v3, v1, :cond_7

    return v16

    :cond_7
    const/16 v0, 0x10

    invoke-virtual {v13, v0}, Ljava/math/BigInteger;->shiftLeft(I)Ljava/math/BigInteger;

    move-result-object v0

    shl-int/lit8 v1, v12, 0x8

    or-int v1, v1, p5

    int-to-long v1, v1

    invoke-static {v1, v2}, Ljava/math/BigInteger;->valueOf(J)Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/math/BigInteger;->or(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v8

    invoke-virtual {v14, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    return v16

    :cond_8
    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lc/r0;

    aget-object v6, p1, v12

    iget v0, v7, Lc/r0;->d:I

    mul-int/2addr v0, v10

    iget v5, v7, Lc/r0;->c:I

    add-int/2addr v0, v5

    invoke-virtual {v6, v0}, Ljava/math/BigInteger;->shiftLeft(I)Ljava/math/BigInteger;

    move-result-object v0

    invoke-virtual {v13, v0}, Ljava/math/BigInteger;->and(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v1}, Ljava/math/BigInteger;->signum()I

    move-result v1

    if-nez v1, :cond_9

    aput-object v7, p2, v12

    add-int/lit8 v3, v12, 0x1

    invoke-virtual {v13, v0}, Ljava/math/BigInteger;->or(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v4

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v17, v5

    move/from16 v5, p5

    move-object v11, v6

    move-object/from16 v6, p6

    move-object v14, v7

    move-object/from16 v7, p7

    move-object/from16 v18, v8

    move/from16 v8, p8

    move v12, v9

    move-wide/from16 v9, p9

    invoke-static/range {v0 .. v10}, Lc/u0;->o(Ljava/util/ArrayList;[Ljava/math/BigInteger;[Lc/r0;ILjava/math/BigInteger;ILjava/util/HashSet;[IIJ)Z

    move-result v0

    if-eqz v0, :cond_a

    return v12

    :cond_9
    move/from16 v17, v5

    move-object v11, v6

    move-object v14, v7

    move-object/from16 v18, v8

    move v12, v9

    :cond_a
    if-lez p5, :cond_13

    add-int/lit8 v9, v15, 0x1e

    move v10, v12

    :goto_4
    if-gt v10, v9, :cond_13

    aget v0, p7, v16

    if-lez v0, :cond_13

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    cmp-long v0, v0, p9

    if-gez v0, :cond_13

    neg-int v0, v10

    move v8, v0

    :goto_5
    if-gt v8, v10, :cond_12

    aget v0, p7, v16

    if-lez v0, :cond_12

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    cmp-long v0, v0, p9

    if-gez v0, :cond_12

    iget v0, v14, Lc/r0;->d:I

    add-int v7, v0, v8

    invoke-static {v8}, Ljava/lang/Math;->abs(I)I

    move-result v0

    sub-int v20, v10, v0

    if-ltz v7, :cond_b

    iget v0, v14, Lc/r0;->f:I

    add-int/2addr v0, v7

    if-le v0, v15, :cond_c

    :cond_b
    move/from16 v23, v8

    move/from16 v24, v9

    move/from16 v25, v10

    const/16 v21, 0x1e

    goto/16 :goto_9

    :cond_c
    const/4 v0, -0x1

    move v6, v0

    :goto_6
    if-gt v6, v12, :cond_b

    if-nez v20, :cond_e

    if-ne v6, v12, :cond_e

    :cond_d
    move/from16 v19, v6

    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v24, v9

    move/from16 v25, v10

    const/16 v21, 0x1e

    goto :goto_8

    :cond_e
    mul-int v0, v6, v20

    add-int v0, v0, v17

    if-ltz v0, :cond_d

    iget v1, v14, Lc/r0;->e:I

    add-int/2addr v1, v0

    const/16 v5, 0x1e

    if-le v1, v5, :cond_f

    :goto_7
    move/from16 v21, v5

    move/from16 v19, v6

    move/from16 v22, v7

    move/from16 v23, v8

    move/from16 v24, v9

    move/from16 v25, v10

    goto :goto_8

    :cond_f
    mul-int/lit8 v1, v7, 0x1e

    add-int/2addr v1, v0

    invoke-virtual {v11, v1}, Ljava/math/BigInteger;->shiftLeft(I)Ljava/math/BigInteger;

    move-result-object v1

    invoke-virtual {v13, v1}, Ljava/math/BigInteger;->and(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v2

    invoke-virtual {v2}, Ljava/math/BigInteger;->signum()I

    move-result v2

    if-eqz v2, :cond_10

    goto :goto_7

    :cond_10
    invoke-virtual {v14, v0, v7}, Lc/r0;->a(II)Lc/r0;

    move-result-object v0

    aput-object v0, p2, p3

    add-int/lit8 v3, p3, 0x1

    invoke-virtual {v13, v1}, Ljava/math/BigInteger;->or(Ljava/math/BigInteger;)Ljava/math/BigInteger;

    move-result-object v4

    add-int/lit8 v19, p5, -0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v21, v5

    move/from16 v5, v19

    move/from16 v19, v6

    move-object/from16 v6, p6

    move/from16 v22, v7

    move-object/from16 v7, p7

    move/from16 v23, v8

    move/from16 v8, p8

    move/from16 v24, v9

    move/from16 v25, v10

    move-wide/from16 v9, p9

    invoke-static/range {v0 .. v10}, Lc/u0;->o(Ljava/util/ArrayList;[Ljava/math/BigInteger;[Lc/r0;ILjava/math/BigInteger;ILjava/util/HashSet;[IIJ)Z

    move-result v0

    if-eqz v0, :cond_11

    return v12

    :cond_11
    :goto_8
    add-int/lit8 v6, v19, 0x2

    move/from16 v7, v22

    move/from16 v8, v23

    move/from16 v9, v24

    move/from16 v10, v25

    goto :goto_6

    :goto_9
    add-int/lit8 v8, v23, 0x1

    move/from16 v9, v24

    move/from16 v10, v25

    goto/16 :goto_5

    :cond_12
    move/from16 v24, v9

    move/from16 v25, v10

    const/16 v21, 0x1e

    add-int/lit8 v10, v25, 0x1

    move/from16 v9, v24

    goto/16 :goto_4

    :cond_13
    move-object/from16 v0, p6

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_14
    :goto_a
    return v16
.end method

.method public static r(Lc/u0;)Lc/u0;
    .locals 28

    move-object/from16 v0, p0

    if-nez v0, :cond_0

    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const-class v2, Lc/s0;

    invoke-static {v2}, Ljava/util/EnumSet;->noneOf(Ljava/lang/Class;)Ljava/util/EnumSet;

    move-result-object v2

    const/4 v3, 0x2

    new-array v3, v3, [I

    const/4 v12, 0x1

    const/16 v13, 0x1e

    aput v13, v3, v12

    const/4 v14, 0x0

    iget v15, v0, Lc/u0;->a:I

    aput v15, v3, v14

    sget-object v4, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v4, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [[Z

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iget-object v5, v0, Lc/u0;->d:Ljava/lang/Object;

    move-object/from16 v16, v5

    check-cast v16, Ljava/util/List;

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    sget-object v11, Lc/s0;->i:Lc/s0;

    if-eqz v6, :cond_2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    if-eqz v6, :cond_1

    iget-object v7, v6, Lc/r0;->a:Lc/s0;

    if-ne v7, v11, :cond_1

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    :goto_0
    if-eqz v6, :cond_3

    goto :goto_1

    :cond_3
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v5

    invoke-virtual {v5, v11}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v6

    :goto_1
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_4
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_6

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    if-eqz v6, :cond_5

    iget-object v7, v6, Lc/r0;->a:Lc/s0;

    if-eq v7, v11, :cond_4

    :cond_5
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_6
    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_3
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_e

    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/r0;

    if-eqz v4, :cond_d

    iget-object v5, v4, Lc/r0;->a:Lc/s0;

    if-eqz v5, :cond_d

    invoke-virtual {v2, v5}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_7

    goto :goto_3

    :cond_7
    iget v6, v4, Lc/r0;->e:I

    rsub-int/lit8 v7, v6, 0x1e

    iget v8, v4, Lc/r0;->c:I

    invoke-static {v7, v8}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-static {v14, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget v8, v4, Lc/r0;->f:I

    sub-int v9, v15, v8

    iget v10, v4, Lc/r0;->d:I

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v14, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    if-ne v5, v11, :cond_8

    new-instance v10, Lc/r0;

    iget v14, v4, Lc/r0;->e:I

    iget v12, v4, Lc/r0;->f:I

    iget-object v13, v4, Lc/r0;->a:Lc/s0;

    move-object/from16 v26, v2

    iget-boolean v2, v4, Lc/r0;->g:Z

    move/from16 v27, v15

    iget-boolean v15, v4, Lc/r0;->h:Z

    move-object/from16 v18, v10

    move-object/from16 v19, v13

    move/from16 v20, v7

    move/from16 v21, v9

    move/from16 v22, v2

    move/from16 v23, v14

    move/from16 v24, v12

    move/from16 v25, v15

    invoke-direct/range {v18 .. v25}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    goto :goto_4

    :cond_8
    move-object/from16 v26, v2

    move/from16 v27, v15

    invoke-virtual {v4, v7, v9}, Lc/r0;->a(II)Lc/r0;

    move-result-object v10

    :goto_4
    iget-boolean v2, v10, Lc/r0;->g:Z

    if-nez v2, :cond_b

    invoke-static {v3, v10}, Lc/u0;->f([[ZLc/r0;)Z

    move-result v2

    if-nez v2, :cond_b

    invoke-static {v3, v10}, Lc/u0;->u([[ZLc/r0;)Lc/r0;

    move-result-object v10

    if-nez v10, :cond_b

    if-ne v5, v11, :cond_a

    iget-object v5, v4, Lc/r0;->a:Lc/s0;

    if-ne v5, v11, :cond_9

    iget-boolean v2, v4, Lc/r0;->h:Z

    if-eqz v2, :cond_9

    const/4 v2, 0x1

    goto :goto_5

    :cond_9
    const/4 v2, 0x0

    :goto_5
    invoke-virtual {v5}, Lc/s0;->a()I

    move-result v4

    const/16 v12, 0x1e

    invoke-static {v12, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    move-result v10

    invoke-virtual {v5}, Lc/s0;->b()I

    move-result v4

    const/16 v6, 0x48

    invoke-static {v6, v8}, Ljava/lang/Math;->min(II)I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    move-result v13

    new-instance v14, Lc/r0;

    move-object v4, v14

    move v6, v7

    move v7, v9

    const/4 v15, 0x1

    move v8, v15

    move v9, v10

    move v10, v13

    move-object v13, v11

    move v11, v2

    invoke-direct/range {v4 .. v11}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    move-object v10, v14

    goto :goto_6

    :cond_a
    move-object v13, v11

    const/16 v12, 0x1e

    const/4 v15, 0x1

    invoke-virtual {v4, v7, v9}, Lc/r0;->a(II)Lc/r0;

    move-result-object v2

    invoke-virtual {v2, v15}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v2

    move-object v10, v2

    goto :goto_6

    :cond_b
    move-object v13, v11

    const/16 v12, 0x1e

    const/4 v15, 0x1

    :goto_6
    iget-boolean v2, v10, Lc/r0;->g:Z

    if-nez v2, :cond_c

    invoke-static {v3, v10}, Lc/u0;->k([[ZLc/r0;)V

    :cond_c
    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v11, v13

    move-object/from16 v2, v26

    const/4 v14, 0x0

    move v13, v12

    :goto_7
    move v12, v15

    move/from16 v15, v27

    goto/16 :goto_3

    :cond_d
    move/from16 v27, v15

    move v15, v12

    move v12, v13

    goto :goto_7

    :cond_e
    move/from16 v27, v15

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface/range {v16 .. v16}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_f
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_13

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/r0;

    if-eqz v4, :cond_f

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_10
    :goto_8
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_f

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    iget-object v7, v6, Lc/r0;->a:Lc/s0;

    iget-object v8, v4, Lc/r0;->a:Lc/s0;

    if-ne v7, v8, :cond_10

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_11
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_12

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/r0;

    if-eqz v9, :cond_11

    iget-object v9, v9, Lc/r0;->a:Lc/s0;

    if-ne v9, v7, :cond_11

    goto :goto_8

    :cond_12
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8

    :cond_13
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_16

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/r0;

    iget-object v4, v3, Lc/r0;->a:Lc/s0;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_14
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_15

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    if-eqz v6, :cond_14

    iget-object v6, v6, Lc/r0;->a:Lc/s0;

    if-ne v6, v4, :cond_14

    goto :goto_9

    :cond_15
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_16
    new-instance v1, Lc/u0;

    iget-object v3, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v3, Lc/Q1;

    iget-object v0, v0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v0, Lc/q0;

    move/from16 v4, v27

    invoke-direct {v1, v3, v0, v2, v4}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    return-object v1
.end method

.method public static u([[ZLc/r0;)Lc/r0;
    .locals 5

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    array-length v2, p0

    if-ge v1, v2, :cond_3

    move v2, v0

    :goto_1
    const/16 v3, 0x1e

    if-ge v2, v3, :cond_2

    iget v3, p1, Lc/r0;->c:I

    if-ne v2, v3, :cond_0

    iget v3, p1, Lc/r0;->d:I

    if-ne v1, v3, :cond_0

    move-object v3, p1

    goto :goto_2

    :cond_0
    invoke-virtual {p1, v2, v1}, Lc/r0;->a(II)Lc/r0;

    move-result-object v3

    :goto_2
    invoke-static {p0, v3}, Lc/u0;->f([[ZLc/r0;)Z

    move-result v4

    if-eqz v4, :cond_1

    return-object v3

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public a(Lc/r0;)Z
    .locals 7

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    :cond_0
    const/4 v1, 0x2

    new-array v1, v1, [I

    const/4 v2, 0x1

    const/16 v3, 0x1e

    aput v3, v1, v2

    iget v3, p0, Lc/u0;->a:I

    aput v3, v1, v0

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v3, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [[Z

    iget-object v3, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v3, Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/r0;

    iget-object v5, v4, Lc/r0;->a:Lc/s0;

    iget-object v6, p1, Lc/r0;->a:Lc/s0;

    if-eq v5, v6, :cond_1

    iget-boolean v5, v4, Lc/r0;->g:Z

    if-nez v5, :cond_1

    invoke-static {v1, v4}, Lc/u0;->k([[ZLc/r0;)V

    goto :goto_0

    :cond_2
    iget-boolean v3, p1, Lc/r0;->g:Z

    if-nez v3, :cond_3

    invoke-static {v1, p1}, Lc/u0;->f([[ZLc/r0;)Z

    move-result p1

    if-eqz p1, :cond_4

    :cond_3
    move v0, v2

    :cond_4
    return v0
.end method

.method public b()V
    .locals 2

    iget v0, p0, Lc/u0;->a:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/u0;->a:I

    iget-object v0, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/media/browse/MediaBrowser;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->disconnect()V

    iput-object v1, p0, Lc/u0;->d:Ljava/lang/Object;

    :cond_0
    iget-object v0, p0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v0, Landroid/os/Handler;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    return-void
.end method

.method public d(Lc/s0;)Lc/r0;
    .locals 3

    iget-object v0, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/r0;

    iget-object v2, v1, Lc/r0;->a:Lc/s0;

    if-ne v2, p1, :cond_0

    return-object v1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public e(Lc/r0;)Lc/r0;
    .locals 6

    const/4 v0, 0x2

    new-array v0, v0, [I

    const/4 v1, 0x1

    const/16 v2, 0x1e

    aput v2, v0, v1

    iget v1, p0, Lc/u0;->a:I

    const/4 v2, 0x0

    aput v1, v0, v2

    sget-object v1, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v1, v0}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [[Z

    iget-object v1, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/r0;

    iget-object v4, v3, Lc/r0;->a:Lc/s0;

    iget-object v5, p1, Lc/r0;->a:Lc/s0;

    if-eq v4, v5, :cond_0

    iget-boolean v4, v3, Lc/r0;->g:Z

    if-nez v4, :cond_0

    invoke-static {v0, v3}, Lc/u0;->k([[ZLc/r0;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v2}, Lc/r0;->b(Z)Lc/r0;

    move-result-object p1

    invoke-static {v0, p1}, Lc/u0;->u([[ZLc/r0;)Lc/r0;

    move-result-object p1

    return-object p1
.end method

.method public g()Z
    .locals 3

    iget-object v0, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    const-class v1, Landroid/media/AudioManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioManager;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/media/AudioManager;->getMode()I

    move-result v1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_0

    invoke-virtual {v0}, Landroid/media/AudioManager;->getMode()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1

    :cond_0
    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public h(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 5

    iget-object v0, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p0}, Lc/u0;->g()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    return v2

    :cond_0
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.media.action.MEDIA_PLAY_FROM_SEARCH"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v3, "android.intent.extra.focus"

    const-string v4, "vnd.android.cursor.item/*"

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v3, "query"

    invoke-virtual {v1, v3, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    const/high16 v1, 0x10000000

    invoke-virtual {p2, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p2

    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, p2, v2}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v1

    if-nez v1, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    :goto_0
    if-eqz v1, :cond_3

    iget-object v3, v1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    iget-boolean v3, v1, Landroid/content/pm/ActivityInfo;->exported:Z

    if-eqz v3, :cond_3

    iget-boolean v3, v1, Landroid/content/pm/ActivityInfo;->enabled:Z

    if-eqz v3, :cond_3

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->permission:Ljava/lang/String;

    if-eqz v1, :cond_2

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {v0, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    invoke-static {v0, p1}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x1

    return p1

    :catch_0
    :cond_3
    :goto_1
    return v2
.end method

.method public l(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1, p1}, Lc/n1;->S0(Ljava/lang/String;)V

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->j0()Z

    move-result p1

    iput-boolean p1, v0, Lru/drivedeck/launcher/MainActivity;->v0:Z

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->e()V

    return-void
.end method

.method public n(IIJ)Z
    .locals 2

    iget v0, p0, Lc/u0;->a:I

    const/4 v1, 0x0

    if-eq p1, v0, :cond_0

    return v1

    :cond_0
    sget p1, Lc/G8;->B:I

    if-ne p2, p1, :cond_1

    new-instance p1, Lc/n1;

    iget-object p2, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast p2, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p1, p2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lc/n1;->t0()J

    move-result-wide p1

    cmp-long p1, p3, p1

    if-nez p1, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    invoke-virtual {p0}, Lc/u0;->b()V

    return v1
.end method

.method public p(Lc/r0;)Lc/u0;
    .locals 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-boolean v2, v1, Lc/r0;->g:Z

    if-eqz v2, :cond_0

    invoke-virtual/range {p0 .. p1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    return-object v1

    :cond_0
    const/4 v2, 0x0

    iget v3, v1, Lc/r0;->c:I

    if-ltz v3, :cond_9

    iget v4, v1, Lc/r0;->d:I

    if-ltz v4, :cond_9

    iget v5, v1, Lc/r0;->e:I

    add-int/2addr v3, v5

    const/16 v6, 0x1e

    if-gt v3, v6, :cond_9

    iget v3, v1, Lc/r0;->f:I

    add-int/2addr v4, v3

    iget v7, v0, Lc/u0;->a:I

    if-le v4, v7, :cond_1

    goto/16 :goto_5

    :cond_1
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iget-object v8, v0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v8, Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_2
    :goto_0
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_3

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/r0;

    iget-object v10, v9, Lc/r0;->a:Lc/s0;

    iget-object v11, v1, Lc/r0;->a:Lc/s0;

    if-eq v10, v11, :cond_2

    iget-boolean v10, v9, Lc/r0;->g:Z

    if-nez v10, :cond_2

    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    new-instance v8, Lc/p0;

    const/4 v9, 0x0

    invoke-direct {v8, v9}, Lc/p0;-><init>(I)V

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    mul-int/2addr v5, v3

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_4

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/r0;

    iget v9, v8, Lc/r0;->e:I

    iget v8, v8, Lc/r0;->f:I

    mul-int/2addr v9, v8

    add-int/2addr v5, v9

    goto :goto_1

    :cond_4
    mul-int/2addr v7, v6

    if-le v5, v7, :cond_5

    return-object v2

    :cond_5
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v3

    new-array v5, v3, [Lc/r0;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v6

    new-array v6, v6, [Ljava/math/BigInteger;

    const/4 v7, 0x0

    move v8, v7

    :goto_2
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v8, v9, :cond_6

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/r0;

    invoke-virtual {v9, v7, v7}, Lc/r0;->a(II)Lc/r0;

    move-result-object v9

    invoke-static {v9}, Lc/u0;->i(Lc/r0;)Ljava/math/BigInteger;

    move-result-object v9

    aput-object v9, v6, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_2

    :cond_6
    const/16 v8, 0xbb8

    filled-new-array {v8}, [I

    move-result-object v19

    invoke-static/range {p1 .. p1}, Lc/u0;->i(Lc/r0;)Ljava/math/BigInteger;

    move-result-object v20

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    const-wide/32 v10, 0x5f5e100

    add-long v21, v8, v10

    move v15, v7

    :goto_3
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-gt v15, v8, :cond_9

    aget v8, v19, v7

    if-lez v8, :cond_9

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v8

    cmp-long v8, v8, v21

    if-gez v8, :cond_9

    new-instance v14, Ljava/util/HashSet;

    invoke-direct {v14}, Ljava/util/HashSet;-><init>()V

    iget v13, v0, Lc/u0;->a:I

    const/4 v11, 0x0

    move-object v8, v4

    move-object v9, v6

    move-object v10, v5

    move-object/from16 v12, v20

    move/from16 v16, v13

    move v13, v15

    move/from16 v23, v15

    move-object/from16 v15, v19

    move-wide/from16 v17, v21

    invoke-static/range {v8 .. v18}, Lc/u0;->o(Ljava/util/ArrayList;[Ljava/math/BigInteger;[Lc/r0;ILjava/math/BigInteger;ILjava/util/HashSet;[IIJ)Z

    move-result v8

    if-eqz v8, :cond_8

    invoke-virtual/range {p0 .. p1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    :goto_4
    if-ge v7, v3, :cond_7

    aget-object v2, v5, v7

    invoke-virtual {v1, v2}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_7
    return-object v1

    :cond_8
    add-int/lit8 v15, v23, 0x1

    goto :goto_3

    :cond_9
    :goto_5
    return-object v2
.end method

.method public q(Lc/s0;I)Lc/u0;
    .locals 6

    invoke-virtual {p0, p1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    if-eqz v0, :cond_4

    iget-boolean v1, v0, Lc/r0;->g:Z

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iget-object v3, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v3, Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/r0;

    iget-boolean v5, v4, Lc/r0;->g:Z

    if-eqz v5, :cond_2

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    iget-object v5, v4, Lc/r0;->a:Lc/s0;

    if-eq v5, p1, :cond_1

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    invoke-static {p2, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 p2, 0x0

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-virtual {v1, p1, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    new-instance p1, Lc/u0;

    iget-object p2, p0, Lc/u0;->c:Ljava/lang/Object;

    check-cast p2, Lc/q0;

    iget v0, p0, Lc/u0;->a:I

    iget-object v2, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v2, Lc/Q1;

    invoke-direct {p1, v2, p2, v1, v0}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    return-object p1

    :cond_4
    :goto_1
    return-object p0
.end method

.method public s(Lc/r0;)Lc/u0;
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/r0;

    iget-object v3, v2, Lc/r0;->a:Lc/s0;

    iget-object v4, p1, Lc/r0;->a:Lc/s0;

    if-eq v3, v4, :cond_0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    iget-object v1, p1, Lc/r0;->a:Lc/s0;

    invoke-virtual {p0, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    if-nez v1, :cond_2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    new-instance p1, Lc/u0;

    iget-object v1, p0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v1, Lc/q0;

    iget v2, p0, Lc/u0;->a:I

    iget-object v3, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v3, Lc/Q1;

    invoke-direct {p1, v3, v1, v0, v2}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    return-object p1
.end method

.method public t(Landroid/media/session/MediaController;Ljava/lang/String;Landroid/os/Bundle;)Z
    .locals 6

    invoke-virtual {p0}, Lc/u0;->g()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p1}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v0

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/media/session/PlaybackState;->getActions()J

    move-result-wide v2

    const-wide/16 v4, 0x800

    and-long/2addr v2, v4

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    invoke-virtual {v0, p2, p3}, Landroid/media/session/MediaController$TransportControls;->playFromSearch(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object p2, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast p2, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z

    const/4 p1, 0x1

    return p1

    :cond_2
    :goto_0
    return v1
.end method
