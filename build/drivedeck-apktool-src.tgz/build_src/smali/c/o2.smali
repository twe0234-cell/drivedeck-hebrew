.class public final synthetic Lc/o2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/t2;

.field public final synthetic c:J


# direct methods
.method public synthetic constructor <init>(Lc/t2;JI)V
    .locals 0

    iput p4, p0, Lc/o2;->a:I

    iput-object p1, p0, Lc/o2;->b:Lc/t2;

    iput-wide p2, p0, Lc/o2;->c:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/o2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/o2;->b:Lc/t2;

    iget-wide v1, p0, Lc/o2;->c:J

    invoke-virtual {v0, v1, v2}, Lc/t2;->t(J)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/o2;->b:Lc/t2;

    invoke-virtual {v0}, Lc/t2;->u()V

    iget-wide v1, p0, Lc/o2;->c:J

    invoke-virtual {v0, v1, v2}, Lc/t2;->t(J)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/o2;->b:Lc/t2;

    iget-wide v1, p0, Lc/o2;->c:J

    invoke-virtual {v0, v1, v2}, Lc/t2;->t(J)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/o2;->b:Lc/t2;

    iget-wide v1, p0, Lc/o2;->c:J

    invoke-virtual {v0, v1, v2}, Lc/t2;->t(J)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
