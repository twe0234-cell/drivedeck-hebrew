.class public final synthetic Lc/L3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/P3;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/P3;II)V
    .locals 0

    iput p3, p0, Lc/L3;->a:I

    iput-object p1, p0, Lc/L3;->b:Lc/P3;

    iput p2, p0, Lc/L3;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lc/L3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/L3;->b:Lc/P3;

    iget-object v1, v0, Lc/P3;->A:Lc/g1;

    iget-boolean v2, v1, Lc/g1;->J:Z

    iget v3, p0, Lc/L3;->c:I

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/16 v2, 0xfd2

    if-lt v3, v2, :cond_0

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    array-length v5, v5

    add-int/2addr v5, v2

    if-ge v3, v5, :cond_0

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    sub-int/2addr v3, v2

    aget-object v0, v0, v3

    invoke-virtual {v1, v0, v4}, Lc/g1;->s(Lc/s0;I)V

    goto :goto_0

    :cond_0
    const/16 v2, 0x66

    if-ne v3, v2, :cond_1

    iget-boolean v2, v1, Lc/g1;->J:Z

    if-nez v2, :cond_1

    iput-boolean v4, v0, Lc/P3;->z0:Z

    iget-object v1, v0, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v1}, Lc/U4;->c()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    goto :goto_0

    :cond_1
    iget-boolean v2, v1, Lc/g1;->J:Z

    if-eqz v2, :cond_2

    const/16 v2, 0xfa2

    if-lt v3, v2, :cond_2

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    array-length v5, v5

    mul-int/lit8 v5, v5, 0x3

    add-int/2addr v5, v2

    if-ge v3, v5, :cond_2

    add-int/lit16 v2, v3, -0xfa2

    rem-int/lit8 v5, v2, 0x3

    if-ne v5, v4, :cond_2

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v0

    div-int/lit8 v2, v2, 0x3

    aget-object v0, v0, v2

    const/4 v2, 0x2

    invoke-virtual {v1, v0, v2}, Lc/g1;->s(Lc/s0;I)V

    goto :goto_0

    :cond_2
    invoke-virtual {v0, v3}, Lc/P3;->h(I)Z

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/L3;->b:Lc/P3;

    iget v1, p0, Lc/L3;->c:I

    invoke-virtual {v0, v1}, Lc/P3;->i(I)Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
