.class public final Lc/o9;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/R0;

.field public final b:Z

.field public final c:J

.field public final d:J

.field public final e:J

.field public final f:J


# direct methods
.method public constructor <init>(Lc/R0;ZJJJJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object p1

    :cond_0
    iput-object p1, p0, Lc/o9;->a:Lc/R0;

    iput-boolean p2, p0, Lc/o9;->b:Z

    iput-wide p3, p0, Lc/o9;->c:J

    iput-wide p5, p0, Lc/o9;->d:J

    iput-wide p7, p0, Lc/o9;->e:J

    iput-wide p9, p0, Lc/o9;->f:J

    return-void
.end method
