.class public final Lc/J7;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# instance fields
.field public final a:Landroid/widget/LinearLayout;

.field public final b:Landroid/widget/FrameLayout;

.field public final c:Lc/y7;

.field public final d:Ljava/lang/String;

.field public e:F

.field public f:F

.field public g:F

.field public h:Z

.field public i:Z

.field public j:Z

.field public final k:I

.field public final synthetic l:Lc/O7;


# direct methods
.method public constructor <init>(Lc/O7;Landroid/widget/LinearLayout;Lc/y7;Ljava/lang/String;)V
    .locals 4

    iput-object p1, p0, Lc/J7;->l:Lc/O7;

    iget-object v0, p1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iget-object v0, p1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v1

    iput v1, p0, Lc/J7;->k:I

    iput-object p2, p0, Lc/J7;->a:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lc/J7;->c:Lc/y7;

    iput-object p4, p0, Lc/J7;->d:Ljava/lang/String;

    const/4 p3, 0x1

    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    new-instance p4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget-object v1, p1, Lc/O7;->c:Lc/r4;

    iget v2, v1, Lc/r4;->b:I

    invoke-virtual {p4, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v2, 0x12

    invoke-virtual {p1, v2}, Lc/O7;->g(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p4, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-virtual {p0, p4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, p3}, Landroid/view/View;->setClipToOutline(Z)V

    new-instance p3, Landroid/widget/FrameLayout;

    invoke-direct {p3, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p3, p0, Lc/J7;->b:Landroid/widget/FrameLayout;

    invoke-static {v1}, Lc/k6;->y(Lc/r4;)I

    move-result p4

    invoke-virtual {p3, p4}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 p4, 0x4

    invoke-virtual {p3, p4}, Landroid/view/View;->setVisibility(I)V

    new-instance p4, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v0, -0x1

    invoke-direct {p4, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, p3, p4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p4, Lc/H7;

    const/4 v2, 0x0

    invoke-direct {p4, p0, v2}, Lc/H7;-><init>(Lc/J7;I)V

    const-string v2, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    const v3, 0x7f0300c3

    invoke-virtual {p1, v3, p4, v2}, Lc/O7;->j(ILjava/lang/Runnable;Ljava/lang/String;)Landroid/widget/ImageButton;

    move-result-object p4

    invoke-virtual {p1, v3, v0}, Lc/O7;->i(II)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {p4, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x0

    invoke-virtual {p4, v2}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x40

    invoke-virtual {p1, v3}, Lc/O7;->g(I)I

    move-result p1

    const/4 v3, 0x5

    invoke-direct {v2, p1, v0, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    invoke-virtual {p3, p4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget p1, v1, Lc/r4;->b:I

    invoke-virtual {p2, p1}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 p3, -0x2

    invoke-direct {p1, v0, p3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, p2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Lc/I7;

    invoke-direct {p1, p0}, Lc/I7;-><init>(Lc/J7;)V

    invoke-virtual {p0, p1}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 8

    iget-boolean v0, p0, Lc/J7;->j:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lc/J7;->l:Lc/O7;

    sget v1, Lc/O7;->G:I

    invoke-virtual {v0}, Lc/O7;->l()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/J7;->d:Ljava/lang/String;

    iget-object v1, p0, Lc/J7;->l:Lc/O7;

    iget-object v1, v1, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/J7;->j:Z

    iget-object v0, p0, Lc/J7;->l:Lc/O7;

    iget-object v2, v0, Lc/O7;->b:Lc/Z7;

    iget-object v3, p0, Lc/J7;->d:Ljava/lang/String;

    iget-object v0, p0, Lc/J7;->c:Lc/y7;

    iget-wide v4, v0, Lc/y7;->e:J

    iget-boolean v0, v2, Lc/Z7;->r:Z

    if-nez v0, :cond_2

    iget-object v0, v2, Lc/Z7;->a:Lc/e8;

    iget-object v0, v0, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    iget-object v0, v2, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v7, Lc/k1;

    const/4 v6, 0x6

    move-object v1, v7

    invoke-direct/range {v1 .. v6}, Lc/k1;-><init>(Ljava/lang/Object;Ljava/lang/Object;JI)V

    invoke-interface {v0, v7}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 6

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    iget-object v1, p0, Lc/J7;->a:Landroid/widget/LinearLayout;

    const/4 v2, 0x0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lc/J7;->e:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    iput v0, p0, Lc/J7;->f:F

    invoke-virtual {v1}, Landroid/view/View;->getTranslationX()F

    move-result v0

    iput v0, p0, Lc/J7;->g:F

    iput-boolean v2, p0, Lc/J7;->i:Z

    iput-boolean v2, p0, Lc/J7;->h:Z

    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v3, 0x2

    if-ne v0, v3, :cond_3

    iget-boolean v0, p0, Lc/J7;->i:Z

    if-nez v0, :cond_3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v3, p0, Lc/J7;->e:F

    sub-float/2addr v0, v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v3, p0, Lc/J7;->f:F

    sub-float/2addr p1, v3

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v3

    iget v4, p0, Lc/J7;->k:I

    int-to-float v4, v4

    cmpl-float v3, v3, v4

    const/4 v5, 0x1

    if-lez v3, :cond_1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v3

    cmpl-float p1, p1, v3

    if-ltz p1, :cond_1

    iput-boolean v5, p0, Lc/J7;->i:Z

    goto :goto_0

    :cond_1
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result p1

    cmpl-float p1, p1, v4

    if-lez p1, :cond_3

    const/4 p1, 0x0

    cmpg-float v0, v0, p1

    if-ltz v0, :cond_2

    iget v0, p0, Lc/J7;->g:F

    cmpg-float p1, v0, p1

    if-gez p1, :cond_3

    :cond_2
    iput-boolean v5, p0, Lc/J7;->h:Z

    iget-object p1, p0, Lc/J7;->b:Landroid/widget/FrameLayout;

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    invoke-interface {p1, v5}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    return v5

    :cond_3
    :goto_0
    iget-boolean p1, p0, Lc/J7;->h:Z

    return p1
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 7

    iget-boolean v0, p0, Lc/J7;->h:Z

    if-nez v0, :cond_0

    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    neg-int v0, v0

    int-to-float v0, v0

    iget v1, p0, Lc/J7;->g:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    add-float/2addr v2, v1

    iget v1, p0, Lc/J7;->e:F

    sub-float/2addr v2, v1

    const/4 v1, 0x0

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    iget-object v3, p0, Lc/J7;->a:Landroid/widget/LinearLayout;

    const/4 v4, 0x2

    if-ne v2, v4, :cond_1

    invoke-virtual {v3, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/4 v4, 0x1

    if-eq v2, v4, :cond_2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/4 v5, 0x3

    if-ne v2, v5, :cond_5

    :cond_2
    const/4 v2, 0x0

    iput-boolean v2, p0, Lc/J7;->h:Z

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    invoke-interface {v5, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    if-ne v2, v4, :cond_3

    neg-float v2, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v5

    int-to-float v5, v5

    const v6, 0x3f59999a    # 0.85f

    mul-float/2addr v5, v6

    cmpl-float v2, v2, v5

    if-ltz v2, :cond_3

    invoke-virtual {p0}, Lc/J7;->a()V

    goto :goto_0

    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    if-ne p1, v4, :cond_4

    neg-float p1, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const v2, 0x3eb33333    # 0.35f

    mul-float/2addr v0, v2

    cmpl-float p1, p1, v0

    if-ltz p1, :cond_4

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    neg-int p1, p1

    int-to-float p1, p1

    const/high16 v0, 0x3f000000    # 0.5f

    mul-float v1, p1, v0

    :cond_4
    invoke-virtual {v3}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0xa0

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    new-instance v0, Lc/H7;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/H7;-><init>(Lc/J7;I)V

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_5
    :goto_0
    return v4
.end method
