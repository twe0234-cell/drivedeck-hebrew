.class public final Lc/n9;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static f:Lc/n9;

.field public static g:Landroid/widget/Toast;


# instance fields
.field public final a:Landroid/view/WindowManager;

.field public final b:Lc/m9;

.field public final c:Landroid/os/Handler;

.field public final d:Lc/i;

.field public e:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/n9;->c:Landroid/os/Handler;

    new-instance v0, Lc/i;

    const/16 v1, 0x13

    invoke-direct {v0, p0, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/n9;->d:Lc/i;

    const-class v0, Landroid/view/WindowManager;

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/WindowManager;

    iput-object v0, p0, Lc/n9;->a:Landroid/view/WindowManager;

    new-instance v0, Lc/m9;

    invoke-direct {v0, p1}, Lc/m9;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/n9;->b:Lc/m9;

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    iget-object v0, p0, Lc/n9;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/n9;->d:Lc/i;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/n9;->b:Lc/m9;

    iget-object v1, v0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v2, v0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    :cond_0
    iget-boolean v1, p0, Lc/n9;->e:Z

    if-eqz v1, :cond_1

    :try_start_0
    iget-object v1, p0, Lc/n9;->a:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/n9;->e:Z

    sget-object v0, Lc/n9;->f:Lc/n9;

    if-ne v0, p0, :cond_2

    sput-object v2, Lc/n9;->f:Lc/n9;

    :cond_2
    return-void
.end method

.method public final b(I)V
    .locals 12

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    iget-object v1, p0, Lc/n9;->a:Landroid/view/WindowManager;

    invoke-interface {v1}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    iget-object v2, p0, Lc/n9;->b:Lc/m9;

    invoke-virtual {v2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    iget v4, v0, Landroid/graphics/Point;->x:I

    const/high16 v5, 0x42000000    # 32.0f

    mul-float/2addr v5, v3

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    sub-int/2addr v4, v5

    const/high16 v5, 0x43480000    # 200.0f

    mul-float/2addr v5, v3

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget v6, v0, Landroid/graphics/Point;->x:I

    int-to-float v6, v6

    const v7, 0x3ecccccd    # 0.4f

    mul-float/2addr v6, v7

    const/high16 v7, 0x40000000    # 2.0f

    mul-float/2addr v6, v7

    const/high16 v7, 0x40400000    # 3.0f

    div-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v7

    new-instance v4, Landroid/view/WindowManager$LayoutParams;

    const/high16 v5, 0x42a00000    # 80.0f

    mul-float/2addr v3, v5

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v8

    const/4 v11, -0x3

    const/16 v9, 0x7f6

    const/16 v10, 0x118

    move-object v6, v4

    invoke-direct/range {v6 .. v11}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const/16 v3, 0x31

    iput v3, v4, Landroid/view/WindowManager$LayoutParams;->gravity:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    int-to-float v0, v0

    const v3, 0x3d75c28f    # 0.06f

    mul-float/2addr v0, v3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    iput v0, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1f

    if-lt v0, v3, :cond_0

    const v0, 0x3f4ccccd    # 0.8f

    iput v0, v4, Landroid/view/WindowManager$LayoutParams;->alpha:F

    :cond_0
    iput p1, v2, Lc/m9;->q:I

    iget v0, v2, Lc/m9;->s:F

    iput v0, v2, Lc/m9;->r:F

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    iput-wide v5, v2, Lc/m9;->t:J

    iget-wide v7, v2, Lc/m9;->u:J

    const-wide/16 v9, 0x0

    cmp-long v0, v7, v9

    if-nez v0, :cond_1

    iput-wide v5, v2, Lc/m9;->u:J

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v2, Lc/m9;->o:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "%"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-static {}, Landroid/animation/ValueAnimator;->areAnimatorsEnabled()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object p1, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    if-nez p1, :cond_4

    const/4 p1, 0x2

    new-array p1, p1, [F

    fill-array-data p1, :array_0

    invoke-static {p1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object p1

    iput-object p1, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    const-wide/16 v5, 0x708

    invoke-virtual {p1, v5, v6}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object p1, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    const/4 v0, -0x1

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    iget-object p1, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    new-instance v0, Lc/X1;

    const/4 v3, 0x4

    invoke-direct {v0, v2, v3}, Lc/X1;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object p1, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->start()V

    goto :goto_0

    :cond_2
    iget-object v0, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    const/4 v0, 0x0

    iput-object v0, v2, Lc/m9;->p:Landroid/animation/ValueAnimator;

    :cond_3
    int-to-float p1, p1

    const/high16 v0, 0x42c80000    # 100.0f

    div-float/2addr p1, v0

    iput p1, v2, Lc/m9;->s:F

    :cond_4
    :goto_0
    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    iget-boolean p1, p0, Lc/n9;->e:Z

    if-nez p1, :cond_5

    invoke-interface {v1, v2, v4}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/n9;->e:Z

    goto :goto_1

    :cond_5
    invoke-interface {v1, v2, v4}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_1
    iget-object p1, p0, Lc/n9;->c:Landroid/os/Handler;

    iget-object v0, p0, Lc/n9;->d:Lc/i;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v1, 0xbb8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method
