.class public final synthetic Lc/X6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/T5;

.field public final synthetic b:[Ljava/lang/String;

.field public final synthetic c:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic d:Lc/r4;

.field public final synthetic e:Landroid/widget/LinearLayout;

.field public final synthetic f:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lc/T5;[Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/X6;->a:Lc/T5;

    iput-object p2, p0, Lc/X6;->b:[Ljava/lang/String;

    iput-object p3, p0, Lc/X6;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p4, p0, Lc/X6;->d:Lc/r4;

    iput-object p5, p0, Lc/X6;->e:Landroid/widget/LinearLayout;

    iput-object p6, p0, Lc/X6;->f:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/X6;->a:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, v1, Lc/T5;->i:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v1, Lc/T5;->g:Lc/j6;

    if-nez v2, :cond_0

    const-string v2, ""

    goto :goto_0

    :cond_0
    iget-object v2, v2, Lc/j6;->d:Ljava/lang/String;

    :goto_0
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lc/X6;->b:[Ljava/lang/String;

    const/4 v3, 0x0

    aget-object v4, v2, v3

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    aput-object v0, v2, v3

    iget-object v0, p0, Lc/X6;->e:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lc/X6;->f:Landroid/widget/TextView;

    iget-object v3, p0, Lc/X6;->c:Lru/drivedeck/launcher/MainActivity;

    iget-object v4, p0, Lc/X6;->d:Lc/r4;

    invoke-static {v3, v4, v1, v0, v2}, Lc/b7;->l(Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    :cond_1
    return-void
.end method
