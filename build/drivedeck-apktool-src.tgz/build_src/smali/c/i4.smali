.class public final Lc/i4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public a:Z

.field public b:J

.field public final synthetic c:Landroid/content/Context;

.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Landroid/os/Handler;

.field public final synthetic g:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;ILjava/lang/String;Landroid/os/Handler;Landroid/content/Context;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/i4;->c:Landroid/content/Context;

    iput p2, p0, Lc/i4;->d:I

    iput-object p3, p0, Lc/i4;->e:Ljava/lang/String;

    iput-object p4, p0, Lc/i4;->f:Landroid/os/Handler;

    iput-object p5, p0, Lc/i4;->g:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v0, p0

    const-string v1, "com.syu.radio"

    const-string v2, "com.syu.bt"

    new-instance v3, Lc/n1;

    iget-object v4, v0, Lc/i4;->c:Landroid/content/Context;

    invoke-direct {v3, v4}, Lc/n1;-><init>(Landroid/content/Context;)V

    sget v5, Lc/G8;->A:I

    iget v6, v0, Lc/i4;->d:I

    if-ne v6, v5, :cond_e

    const-string v5, "resume_music_on_start"

    iget-object v6, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v7, 0x0

    invoke-interface {v6, v5, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_e

    invoke-static {v4, v3}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v5

    iget-object v8, v0, Lc/i4;->e:Ljava/lang/String;

    invoke-virtual {v8, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    goto/16 :goto_4

    :cond_0
    const/4 v5, 0x1

    :try_start_0
    const-string v9, "media_session"

    invoke-virtual {v4, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/media/session/MediaSessionManager;

    if-eqz v9, :cond_5

    invoke-static {v4, v9}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/media/session/MediaController;

    invoke-virtual {v10}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v11

    invoke-virtual {v10}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1

    if-eqz v11, :cond_1

    invoke-virtual {v11}, Landroid/media/session/PlaybackState;->getState()I

    move-result v10

    const/4 v12, 0x3

    if-eq v10, v12, :cond_2

    invoke-virtual {v11}, Landroid/media/session/PlaybackState;->getState()I

    move-result v10

    const/4 v11, 0x6

    if-ne v10, v11, :cond_1

    :cond_2
    iget-boolean v9, v0, Lc/i4;->a:Z

    if-nez v9, :cond_3

    invoke-virtual {v3}, Lc/n1;->l0()Z

    move-result v9

    if-eqz v9, :cond_3

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_3

    invoke-static {v4, v5}, Lc/J;->f(Landroid/content/Context;I)Z

    goto :goto_0

    :cond_3
    iget-boolean v9, v0, Lc/i4;->a:Z

    if-nez v9, :cond_4

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4

    invoke-static {v4, v8}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_4
    :goto_0
    return-void

    :catch_0
    :cond_5
    iget-boolean v9, v0, Lc/i4;->a:Z

    iget-object v10, v0, Lc/i4;->f:Landroid/os/Handler;

    const-wide/16 v11, 0x1388

    if-nez v9, :cond_8

    const-string v9, "wait_for_internet_before_music"

    invoke-interface {v6, v9, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_8

    const-string v6, "connectivity"

    invoke-virtual {v4, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/net/ConnectivityManager;

    if-nez v6, :cond_6

    goto :goto_1

    :cond_6
    :try_start_1
    invoke-virtual {v6}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v6

    if-eqz v6, :cond_7

    const/16 v7, 0xc

    invoke-virtual {v6, v7}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v7

    if-eqz v7, :cond_7

    const/16 v7, 0x11

    invoke-virtual {v6, v7}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v6
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    if-nez v6, :cond_7

    goto :goto_2

    :catch_1
    :cond_7
    :goto_1
    invoke-virtual {v10, v0, v11, v12}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_8
    :goto_2
    iget-boolean v6, v0, Lc/i4;->a:Z

    const-string v7, "com.syu.music"

    if-nez v6, :cond_a

    iput-boolean v5, v0, Lc/i4;->a:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v13

    const-wide/32 v15, 0x15f90

    add-long/2addr v13, v15

    iput-wide v13, v0, Lc/i4;->b:J

    invoke-virtual {v3}, Lc/n1;->l0()Z

    move-result v6

    if-eqz v6, :cond_9

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_9

    invoke-static {v4, v5}, Lc/J;->f(Landroid/content/Context;I)Z

    goto :goto_3

    :cond_9
    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    invoke-static {v4, v8}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z

    iget-object v1, v0, Lc/i4;->g:Landroid/content/Context;

    invoke-static {v1, v8}, Lc/G8;->Z(Landroid/content/Context;Ljava/lang/String;)V

    :cond_a
    :goto_3
    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-virtual {v3}, Lc/n1;->l0()Z

    move-result v1

    if-nez v1, :cond_b

    return-void

    :cond_b
    invoke-static {v4, v8}, Lc/G8;->p0(Landroid/content/Context;Ljava/lang/String;)Z

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c

    goto :goto_4

    :cond_c
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iget-wide v3, v0, Lc/i4;->b:J

    cmp-long v1, v1, v3

    if-gez v1, :cond_d

    invoke-virtual {v10, v0, v11, v12}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_4

    :cond_d
    const-string v1, "Auto resume timed out for "

    invoke-virtual {v1, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "DriveDeckMusic"

    invoke-static {v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    :goto_4
    return-void
.end method
