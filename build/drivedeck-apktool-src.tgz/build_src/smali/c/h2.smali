.class public final synthetic Lc/h2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/m2;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/m2;Ljava/lang/String;I)V
    .locals 0

    iput p3, p0, Lc/h2;->a:I

    iput-object p1, p0, Lc/h2;->b:Lc/m2;

    iput-object p2, p0, Lc/h2;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/h2;->a:I

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x1

    iget-object v1, p0, Lc/h2;->b:Lc/m2;

    iget-object v2, p0, Lc/h2;->c:Ljava/lang/String;

    invoke-virtual {v1, v2, v0}, Lc/m2;->A(Ljava/lang/String;I)V

    return-void

    :pswitch_0
    const/4 v0, 0x0

    iget-object v1, p0, Lc/h2;->b:Lc/m2;

    iget-object v2, p0, Lc/h2;->c:Ljava/lang/String;

    invoke-virtual {v1, v2, v0}, Lc/m2;->A(Ljava/lang/String;I)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
