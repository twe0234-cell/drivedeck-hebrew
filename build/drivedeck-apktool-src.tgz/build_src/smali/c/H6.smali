.class public final Lc/H6;
.super Landroid/widget/ScrollView;
.source "SourceFile"


# static fields
.field public static final s0:[Ljava/lang/String;


# instance fields
.field public A:Lc/j6;

.field public B:Ljava/lang/String;

.field public C:Ljava/lang/String;

.field public final D:Landroid/widget/TextView;

.field public final E:Landroid/widget/EditText;

.field public final F:Lc/B6;

.field public final G:Landroid/widget/Button;

.field public final H:Ljava/util/EnumMap;

.field public final I:Ljava/util/EnumMap;

.field public final J:Ljava/util/ArrayList;

.field public final K:Ljava/util/ArrayList;

.field public final L:Lc/C6;

.field public M:Lc/j6;

.field public N:Ljava/lang/String;

.field public O:Ljava/lang/String;

.field public P:Z

.field public Q:Z

.field public final R:Landroid/widget/Spinner;

.field public final S:Landroid/widget/Spinner;

.field public final T:Landroid/widget/Spinner;

.field public final U:Landroid/widget/Spinner;

.field public final V:Ljava/util/ArrayList;

.field public final W:[I

.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public a0:Lc/x5;

.field public final b:Lc/r4;

.field public b0:I

.field public final c:Lc/T5;

.field public c0:I

.field public final d:Landroid/widget/LinearLayout;

.field public d0:Ljava/lang/String;

.field public final e:Landroid/widget/LinearLayout;

.field public e0:Z

.field public final f:Lc/u8;

.field public final f0:Landroid/widget/Button;

.field public final g:Landroid/widget/LinearLayout;

.field public final g0:Landroid/widget/Button;

.field public final h:Landroid/widget/LinearLayout;

.field public final h0:Landroid/widget/Button;

.field public i:I

.field public final i0:Landroid/widget/Button;

.field public j:I

.field public final j0:Landroid/widget/TextView;

.field public final k:Lc/u8;

.field public final k0:Landroid/widget/EditText;

.field public final l:Landroid/widget/TextView;

.field public final l0:Landroid/widget/Spinner;

.field public final m:Landroid/widget/TextView;

.field public final m0:Landroid/os/Handler;

.field public final n:Landroid/widget/TextView;

.field public final n0:Lc/u5;

.field public final o:Landroid/widget/TextView;

.field public o0:Ljava/lang/String;

.field public final p:Landroid/widget/TextView;

.field public final p0:Lc/q6;

.field public final q:Landroid/widget/TextView;

.field public final q0:Lc/e1;

.field public final r:Landroid/widget/TextView;

.field public final r0:Lc/q6;

.field public final s:Lc/o6;

.field public final t:Lc/o6;

.field public final u:Lc/G0;

.field public final v:Lc/z5;

.field public final w:Lc/n1;

.field public final x:Landroid/widget/LinearLayout;

.field public y:Lc/o6;

.field public final z:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const-string v12, "Nissan Consult III"

    const-string v13, "KWP \u00b7 8110F1"

    const-string v0, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    const-string v1, "CAN 11 \u0431\u0438\u0442 \u00b7 500 \u043a\u0431\u0438\u0442/\u0441"

    const-string v2, "CAN 29 \u0431\u0438\u0442 \u00b7 500 \u043a\u0431\u0438\u0442/\u0441"

    const-string v3, "CAN 11 \u0431\u0438\u0442 \u00b7 250 \u043a\u0431\u0438\u0442/\u0441"

    const-string v4, "CAN 29 \u0431\u0438\u0442 \u00b7 250 \u043a\u0431\u0438\u0442/\u0441"

    const-string v5, "J1850 PWM"

    const-string v6, "J1850 VPW"

    const-string v7, "ISO 9141-2"

    const-string v8, "KWP \u00b7 \u043c\u0435\u0434\u043b\u0435\u043d\u043d\u0430\u044f \u0438\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f"

    const-string v9, "KWP \u00b7 \u0431\u044b\u0441\u0442\u0440\u0430\u044f \u0438\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0430\u0446\u0438\u044f"

    const-string v10, "J1939"

    const-string v11, "Nissan Consult II"

    filled-new-array/range {v0 .. v13}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/H6;->s0:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/r4;)V
    .locals 41

    move-object/from16 v11, p0

    move-object/from16 v12, p1

    move-object/from16 v13, p2

    invoke-direct/range {p0 .. p1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v10, -0x1

    iput v10, v11, Lc/H6;->i:I

    iput v10, v11, Lc/H6;->j:I

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v11, Lc/H6;->z:Ljava/util/ArrayList;

    const-string v8, ""

    iput-object v8, v11, Lc/H6;->B:Ljava/lang/String;

    iput-object v8, v11, Lc/H6;->C:Ljava/lang/String;

    new-instance v1, Ljava/util/EnumMap;

    const-class v2, Lc/F0;

    invoke-direct {v1, v2}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v1, v11, Lc/H6;->H:Ljava/util/EnumMap;

    new-instance v1, Ljava/util/EnumMap;

    invoke-direct {v1, v2}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    iput-object v1, v11, Lc/H6;->I:Ljava/util/EnumMap;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v11, Lc/H6;->J:Ljava/util/ArrayList;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v11, Lc/H6;->K:Ljava/util/ArrayList;

    iput-object v8, v11, Lc/H6;->N:Ljava/lang/String;

    iput-object v8, v11, Lc/H6;->O:Ljava/lang/String;

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, v11, Lc/H6;->V:Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x4

    const/16 v10, 0xe

    new-array v2, v10, [I

    fill-array-data v2, :array_0

    iput-object v2, v11, Lc/H6;->W:[I

    iput-object v8, v11, Lc/H6;->d0:Ljava/lang/String;

    new-instance v2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v7

    invoke-direct {v2, v7}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v2, v11, Lc/H6;->m0:Landroid/os/Handler;

    iput-object v8, v11, Lc/H6;->o0:Ljava/lang/String;

    new-instance v7, Lc/q6;

    invoke-direct {v7, v11, v9}, Lc/q6;-><init>(Lc/H6;I)V

    iput-object v7, v11, Lc/H6;->p0:Lc/q6;

    new-instance v7, Lc/e1;

    invoke-direct {v7, v11, v6}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v7, v11, Lc/H6;->q0:Lc/e1;

    new-instance v7, Lc/q6;

    invoke-direct {v7, v11, v5}, Lc/q6;-><init>(Lc/H6;I)V

    iput-object v7, v11, Lc/H6;->r0:Lc/q6;

    iput-object v12, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object v13, v11, Lc/H6;->b:Lc/r4;

    invoke-static/range {p1 .. p1}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v7

    iput-object v7, v11, Lc/H6;->c:Lc/T5;

    invoke-static/range {p1 .. p1}, Lc/z5;->b(Landroid/content/Context;)Lc/z5;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->v:Lc/z5;

    new-instance v4, Lc/n1;

    invoke-direct {v4, v12}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object v4, v11, Lc/H6;->w:Lc/n1;

    new-instance v6, Lc/G0;

    invoke-direct {v6, v12, v4}, Lc/G0;-><init>(Landroid/app/Activity;Lc/n1;)V

    iput-object v6, v11, Lc/H6;->u:Lc/G0;

    new-instance v4, Lc/u5;

    invoke-direct {v4, v12, v2}, Lc/u5;-><init>(Lru/drivedeck/launcher/MainActivity;Landroid/os/Handler;)V

    iput-object v4, v11, Lc/H6;->n0:Lc/u5;

    invoke-virtual {v7}, Lc/T5;->g0()I

    move-result v2

    iput v2, v11, Lc/H6;->b0:I

    invoke-virtual {v11, v5}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    iget v2, v13, Lc/r4;->b:I

    invoke-virtual {v11, v2}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->d:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v5}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    invoke-virtual {v2, v9, v9, v9, v9}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v11, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v4, Lc/u8;

    invoke-direct {v4, v12}, Lc/u8;-><init>(Landroid/content/Context;)V

    iput-object v4, v11, Lc/H6;->f:Lc/u8;

    invoke-virtual {v11, v2, v4, v9}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/4 v6, 0x0

    invoke-virtual {v11, v6}, Lc/H6;->d(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->g:Landroid/widget/LinearLayout;

    const-string v1, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440"

    invoke-virtual {v11, v1}, Lc/H6;->d(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v24

    move-object/from16 v15, v24

    check-cast v15, Landroid/widget/TextView;

    const/high16 v14, 0x41900000    # 18.0f

    invoke-virtual {v15, v14}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v4, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v14, 0x30

    invoke-virtual {v4, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v15, "\u0410\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044c"

    const/16 v14, 0x12

    invoke-virtual {v11, v14, v15, v9}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v15

    invoke-virtual {v15, v6, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-virtual {v6, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v15, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f."

    invoke-virtual {v11, v10, v15, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v15

    sget-object v14, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {v15, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v11, v6, v15, v3}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v15, v9, v3, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v6, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v6, Lc/w5;

    invoke-direct {v6, v0, v5}, Lc/w5;-><init>(Lc/z5;I)V

    const-string v0, "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c"

    invoke-virtual {v11, v0, v9, v6}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v15, 0x30

    invoke-virtual {v11, v15}, Lc/H6;->g(I)I

    move-result v10

    invoke-direct {v6, v3, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v11, v2, v4, v9}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v0, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0438 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u043c OBD."

    const/16 v4, 0xe

    invoke-virtual {v11, v4, v0, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v4, 0x4

    invoke-virtual {v11, v1, v0, v4}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/16 v0, 0xd

    invoke-virtual {v11, v0, v8, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    iput-object v4, v11, Lc/H6;->n:Landroid/widget/TextView;

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->R:Landroid/widget/Spinner;

    const-string v6, "\u041c\u0430\u0440\u043a\u0430"

    invoke-virtual {v11, v2, v6, v0}, Lc/H6;->h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->S:Landroid/widget/Spinner;

    const-string v6, "\u041c\u043e\u0434\u0435\u043b\u044c"

    invoke-virtual {v11, v2, v6, v0}, Lc/H6;->h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->T:Landroid/widget/Spinner;

    const-string v6, "\u041f\u0440\u043e\u0442\u043e\u043a\u043e\u043b"

    invoke-virtual {v11, v2, v6, v0}, Lc/H6;->h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V

    iget v6, v11, Lc/H6;->b0:I

    invoke-virtual {v11, v6}, Lc/H6;->w(I)V

    new-instance v6, Lc/q6;

    const/4 v10, 0x4

    invoke-direct {v6, v11, v10}, Lc/q6;-><init>(Lc/H6;I)V

    new-instance v10, Lc/E6;

    invoke-direct {v10, v6}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v10}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/16 v0, 0xc

    invoke-virtual {v11, v2, v4, v0}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/16 v4, 0xe

    invoke-virtual {v11, v4, v8, v9}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    iput-object v6, v11, Lc/H6;->o:Landroid/widget/TextView;

    invoke-virtual {v11, v2, v6, v0}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/q6;

    const/4 v4, 0x5

    invoke-direct {v0, v11, v4}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v4, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043f\u0440\u043e\u0444\u0438\u043b\u044c"

    invoke-virtual {v11, v4, v9, v0}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    const v4, 0x7f03003d

    invoke-virtual {v11, v0, v4}, Lc/H6;->c(Landroid/widget/Button;I)V

    const/16 v15, 0x10

    invoke-virtual {v11, v2, v0, v15}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/16 v2, 0x34

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v2

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->U:Landroid/widget/Spinner;

    const-string v2, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435"

    invoke-virtual {v11, v1, v2, v0}, Lc/H6;->h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V

    const-string v2, "Bluetooth BLE"

    const-string v4, "Bluetooth Classic \u00b7 ELM327"

    const-string v6, "Wi-Fi \u00b7 ELM327"

    const-string v10, "USB \u00b7 ELM327"

    filled-new-array {v2, v4, v6, v10}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v11, v0, v2}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    const-string v2, "ble"

    const-string v4, "spp"

    const-string v6, "wifi"

    const-string v10, "usb"

    filled-new-array {v2, v4, v6, v10}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-virtual {v7}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/AdapterView;->setSelection(I)V

    new-instance v2, Lc/q6;

    const/4 v4, 0x6

    invoke-direct {v2, v11, v4}, Lc/q6;-><init>(Lc/H6;I)V

    new-instance v4, Lc/E6;

    invoke-direct {v4, v2}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v4}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->k0:Landroid/widget/EditText;

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setSingleLine(Z)V

    const-string v2, "wifi_endpoint"

    const-string v4, "192.168.0.10:35000"

    iget-object v6, v7, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v6, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v2, "IP:\u043f\u043e\u0440\u0442"

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    const/16 v2, 0x8

    invoke-virtual {v11, v1, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->l0:Landroid/widget/Spinner;

    const-string v35, "USB \u00b7 115200 \u0431\u043e\u0434"

    const-string v36, "USB \u00b7 230400 \u0431\u043e\u0434"

    const-string v31, "USB \u00b7 9600 \u0431\u043e\u0434"

    const-string v32, "USB \u00b7 19200 \u0431\u043e\u0434"

    const-string v33, "USB \u00b7 38400 \u0431\u043e\u0434"

    const-string v34, "USB \u00b7 57600 \u0431\u043e\u0434"

    const-string v37, "USB \u00b7 500000 \u0431\u043e\u0434"

    const-string v38, "USB \u00b7 1000000 \u0431\u043e\u0434"

    filled-new-array/range {v31 .. v38}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v11, v0, v1}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    const/16 v0, 0x8

    new-array v1, v0, [I

    fill-array-data v1, :array_1

    const-string v2, "usb_baud"

    const v4, 0x9600

    invoke-interface {v6, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    move v4, v9

    const/4 v6, 0x2

    :goto_0
    if-ge v4, v0, :cond_1

    aget v0, v1, v4

    if-ne v0, v2, :cond_0

    move v6, v4

    :cond_0
    add-int/2addr v4, v5

    const/16 v0, 0x8

    goto :goto_0

    :cond_1
    iget-object v0, v11, Lc/H6;->l0:Landroid/widget/Spinner;

    invoke-virtual {v0, v6}, Landroid/widget/AdapterView;->setSelection(I)V

    iget-object v0, v11, Lc/H6;->l0:Landroid/widget/Spinner;

    new-instance v2, Lc/H;

    const/16 v4, 0x1a

    invoke-direct {v2, v11, v1, v4}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance v1, Lc/E6;

    invoke-direct {v1, v2}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v0, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    iget-object v1, v11, Lc/H6;->l0:Landroid/widget/Spinner;

    const/16 v2, 0x8

    invoke-virtual {v11, v0, v1, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v0, v11, Lc/H6;->R:Landroid/widget/Spinner;

    new-instance v1, Lc/q6;

    const/4 v6, 0x7

    invoke-direct {v1, v11, v6}, Lc/q6;-><init>(Lc/H6;I)V

    new-instance v4, Lc/E6;

    invoke-direct {v4, v1}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v4}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v0, v11, Lc/H6;->S:Landroid/widget/Spinner;

    new-instance v1, Lc/q6;

    invoke-direct {v1, v11, v2}, Lc/q6;-><init>(Lc/H6;I)V

    new-instance v2, Lc/E6;

    invoke-direct {v2, v1}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v2}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/16 v0, 0xd

    invoke-virtual {v11, v0, v8, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->r:Landroid/widget/TextView;

    iget-object v1, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const-string v2, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0441\u043e\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 Android."

    invoke-virtual {v11, v0, v2, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v4, 0x6

    invoke-virtual {v11, v1, v2, v4}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual {v11, v0, v8, v9}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->q:Landroid/widget/TextView;

    iget-object v2, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v2, v1, v4}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/16 v1, 0xe

    invoke-virtual {v11, v1, v8, v9}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->l:Landroid/widget/TextView;

    iget-object v1, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const/4 v4, 0x4

    invoke-virtual {v11, v1, v2, v4}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual {v11, v0, v8, v9}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->m:Landroid/widget/TextView;

    sget-object v2, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    iget-object v2, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v2, v1, v4}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual {v11, v0, v8, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->j0:Landroid/widget/TextView;

    iget-object v0, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const/4 v2, 0x6

    invoke-virtual {v11, v0, v1, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/q6;

    const/16 v1, 0x9

    invoke-direct {v0, v11, v1}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v1, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c Bluetooth \u0430\u043a\u0441\u0435\u0441\u0441\u0443\u0430\u0440\u043e\u0432"

    invoke-virtual {v11, v1, v9, v0}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->i0:Landroid/widget/Button;

    const v1, 0x7f030092

    invoke-virtual {v11, v0, v1}, Lc/H6;->c(Landroid/widget/Button;I)V

    iget-object v1, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const/16 v2, 0xc

    invoke-virtual {v11, v1, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/q6;

    const/4 v1, 0x3

    invoke-direct {v0, v11, v1}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v1, "\u041d\u0430\u0439\u0442\u0438 \u0430\u0434\u0430\u043f\u0442\u0435\u0440"

    invoke-virtual {v11, v1, v9, v0}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->f0:Landroid/widget/Button;

    const v1, 0x7f03003e

    invoke-virtual {v11, v0, v1}, Lc/H6;->c(Landroid/widget/Button;I)V

    new-instance v1, Lc/q6;

    const/16 v2, 0xb

    invoke-direct {v1, v11, v2}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v2, "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    invoke-virtual {v11, v2, v9, v1}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    const v2, 0x7f03003c

    invoke-virtual {v11, v1, v2}, Lc/H6;->c(Landroid/widget/Button;I)V

    iget-object v2, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    new-instance v4, Landroid/widget/LinearLayout;

    iget-object v7, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v4, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v7, v9, v3, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v9, v3, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v7, 0x8

    invoke-virtual {v11, v7}, Lc/H6;->g(I)I

    move-result v10

    iput v10, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v4, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0xc

    invoke-virtual {v11, v2, v4, v0}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v1, Lc/q6;

    invoke-direct {v1, v11, v0}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v0, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    invoke-virtual {v11, v0, v5, v1}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    new-instance v1, Lc/q6;

    const/16 v2, 0xd

    invoke-direct {v1, v11, v2}, Lc/q6;-><init>(Lc/H6;I)V

    invoke-virtual {v11, v8, v9, v1}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    iput-object v1, v11, Lc/H6;->g0:Landroid/widget/Button;

    iget-object v2, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const v4, 0x7f0300c3

    invoke-virtual {v2, v4}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    iget-object v4, v11, Lc/H6;->b:Lc/r4;

    iget v4, v4, Lc/r4;->k:I

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    new-instance v4, Landroid/graphics/drawable/LayerDrawable;

    new-instance v7, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v7, v9}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/4 v10, 0x2

    new-array v3, v10, [Landroid/graphics/drawable/Drawable;

    aput-object v7, v3, v9

    aput-object v2, v3, v5

    invoke-direct {v4, v3}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/16 v2, 0x18

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {v4, v5, v3, v2}, Landroid/graphics/drawable/LayerDrawable;->setLayerSize(III)V

    const/16 v2, 0x11

    invoke-virtual {v4, v5, v2}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setForeground(Landroid/graphics/drawable/Drawable;)V

    iget-object v3, v11, Lc/H6;->b:Lc/r4;

    invoke-static {v3}, Lc/G8;->V0(Lc/r4;)I

    move-result v3

    invoke-static {v3}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    iget-object v2, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0430\u0434\u0430\u043f\u0442\u0435\u0440"

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v2, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x38

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setMinWidth(I)V

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v1, v9, v9, v9, v9}, Landroid/view/View;->setPadding(IIII)V

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v15}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v2

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v7, v9, v2, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0x8

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v3

    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v4, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const/16 v1, 0xc

    invoke-virtual {v11, v0, v4, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/q6;

    const/16 v6, 0xe

    invoke-direct {v0, v11, v6}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v2, "Bluetooth Android"

    invoke-virtual {v11, v2, v9, v0}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->h0:Landroid/widget/Button;

    iget-object v2, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v2, v0, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->e:Landroid/widget/LinearLayout;

    iget-object v1, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const/16 v2, 0x8

    invoke-virtual {v11, v1, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v0, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {v7, v2}, Landroid/view/View;->setVisibility(I)V

    new-instance v1, Lc/j1;

    const/4 v2, 0x3

    invoke-direct {v1, v7, v2}, Lc/j1;-><init>(Landroid/widget/LinearLayout;I)V

    const-string v2, "\u0417\u0430\u0449\u0438\u0442\u0430 \u0430\u043a\u043a\u0443\u043c\u0443\u043b\u044f\u0442\u043e\u0440\u0430"

    invoke-virtual {v11, v2, v9, v1}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    const/16 v2, 0xc

    invoke-virtual {v11, v0, v1, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/4 v1, 0x4

    invoke-virtual {v11, v0, v7, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v4, Landroid/widget/Spinner;

    iget-object v0, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v4, v0}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0420\u0435\u0436\u0438\u043c"

    invoke-virtual {v11, v7, v1, v4}, Lc/H6;->h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V

    const-string v1, "\u041f\u043e \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u044e ELM \u00b7 Android-\u0431\u043e\u043a\u0441"

    const-string v2, "\u041f\u043e \u043e\u0431\u043e\u0440\u043e\u0442\u0430\u043c \u00b7 \u043e\u0431\u044b\u0447\u043d\u044b\u0439 \u0414\u0412\u0421"

    const-string v3, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u0430"

    const-string v6, "\u041f\u043e \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u044e / \u043f\u0438\u0442\u0430\u043d\u0438\u044e"

    filled-new-array {v3, v6, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v11, v4, v1}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    iget-object v1, v11, Lc/H6;->c:Lc/T5;

    invoke-virtual {v1}, Lc/T5;->j()I

    move-result v2

    const/4 v3, 0x3

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v9, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v4, v2}, Landroid/widget/AdapterView;->setSelection(I)V

    const/16 v2, 0xd

    invoke-virtual {v11, v2, v8, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v6

    const/16 v2, 0x8

    invoke-virtual {v11, v7, v6, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v3, Lc/a1;

    const/4 v10, 0x6

    invoke-direct {v3, v10}, Lc/a1;-><init>(I)V

    const-string v10, "\u0414\u0430\u0442\u0447\u0438\u043a \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u044f"

    invoke-virtual {v11, v10, v9, v3}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v10

    invoke-virtual {v11, v7, v10, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v2, Lc/w2;

    const/4 v3, 0x3

    invoke-direct {v2, v11, v10, v3}, Lc/w2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v2, v1, Lc/T5;->g:Lc/j6;

    iget-object v3, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    if-eqz v2, :cond_3

    const-string v2, "battery_ignition_sensor"

    invoke-interface {v3, v2, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v15, v1, Lc/T5;->g:Lc/j6;

    iget-object v15, v15, Lc/j6;->y:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_1
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v21

    if-eqz v21, :cond_3

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v21

    move-object/from16 v9, v21

    check-cast v9, Lc/i6;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v30, v4

    iget-object v4, v1, Lc/T5;->g:Lc/j6;

    iget-object v4, v4, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v9, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u0417\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u0435: "

    invoke-static {v0, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v9, Lc/i6;->b:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_2
    move-object/from16 v4, v30

    const/4 v5, 0x1

    const/4 v9, 0x0

    goto :goto_1

    :cond_3
    move-object/from16 v30, v4

    const-string v1, "\u0412\u044b\u0431\u0438\u0440\u0430\u0439\u0442\u0435 \u0442\u043e\u043b\u044c\u043a\u043e \u0441\u043e\u0441\u0442\u043e\u044f\u043d\u0438\u0435 \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u044f/READY: 0 \u2014 \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e. \u0421\u0432\u0435\u0436\u0435\u0435 \u043d\u0435\u043d\u0443\u043b\u0435\u0432\u043e\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u0437\u0430\u043f\u0440\u0435\u0449\u0430\u0435\u0442 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043f\u043e \u043e\u0431\u043e\u0440\u043e\u0442\u0430\u043c \u0438 \u043d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u044e."

    const/16 v2, 0xd

    const/4 v4, 0x1

    invoke-virtual {v11, v2, v1, v4}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x4

    invoke-virtual {v11, v7, v1, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v15, Landroid/widget/Switch;

    invoke-direct {v15, v0}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    const-string v1, "\u042d\u043a\u0440\u0430\u043d \u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f \u0432\u043c\u0435\u0441\u0442\u0435 \u0441 \u0437\u0430\u0436\u0438\u0433\u0430\u043d\u0438\u0435\u043c"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "battery_screen"

    const/4 v9, 0x0

    invoke-interface {v3, v0, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-virtual {v15, v0}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v0, v11, Lc/H6;->b:Lc/r4;

    invoke-static {v15, v0}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const/16 v5, 0x8

    invoke-virtual {v11, v7, v15, v5}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/w6;

    invoke-direct {v0, v11, v9}, Lc/w6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v15, v0}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v3

    const/4 v2, 0x4

    invoke-virtual {v11, v7, v3, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-wide v21, 0x409c200000000000L    # 1800.0

    const/16 v23, 0x1

    const-string v28, "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f, \u0441"

    const-string v31, "battery_delay"

    const-wide/high16 v32, 0x405e000000000000L    # 120.0

    const-wide/high16 v34, 0x403e000000000000L    # 30.0

    move-object/from16 v0, p0

    move-object v1, v3

    move/from16 v36, v2

    move-object/from16 v2, v28

    move-object/from16 v18, v3

    const/16 v17, 0x3

    move-object/from16 v3, v31

    move-wide/from16 v4, v32

    move-object/from16 v19, v6

    move-object/from16 v39, v7

    const/16 v20, 0xe

    move-wide/from16 v6, v34

    move-object/from16 v40, v8

    move-wide/from16 v8, v21

    move/from16 v13, v17

    move-object/from16 v17, v10

    move/from16 v10, v23

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v10

    move-object/from16 v0, v39

    const/4 v8, 0x4

    invoke-virtual {v11, v0, v10, v8}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-wide/high16 v20, 0x402c000000000000L    # 14.0

    const/16 v22, 0x0

    const-string v2, "\u041e\u0436\u0438\u0434\u0430\u043d\u0438\u0435 \u043d\u0438\u0436\u0435, \u0412"

    const-string v3, "battery_stop_volts"

    const-wide v4, 0x402999999999999aL    # 12.8

    const-wide/high16 v6, 0x4024000000000000L    # 10.0

    move-object/from16 v0, p0

    move-object v1, v10

    move-wide/from16 v8, v20

    move-object/from16 v20, v10

    move/from16 v10, v22

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-wide/high16 v8, 0x4030000000000000L    # 16.0

    const/4 v10, 0x0

    const-string v2, "\u041f\u0440\u043e\u0431\u0443\u0436\u0434\u0435\u043d\u0438\u0435 \u0432\u044b\u0448\u0435, \u0412"

    const-string v3, "battery_wake_volts"

    const-wide v4, 0x402a99999999999aL    # 13.3

    const-wide/high16 v6, 0x4028000000000000L    # 12.0

    move-object/from16 v1, v20

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    new-instance v8, Lc/x6;

    move-object v0, v8

    move-object/from16 v1, p0

    move-object/from16 v2, v30

    move-object/from16 v3, v17

    move-object v4, v15

    move-object/from16 v5, v18

    move-object/from16 v6, v20

    move-object/from16 v7, v19

    invoke-direct/range {v0 .. v7}, Lc/x6;-><init>(Lc/H6;Landroid/widget/Spinner;Landroid/widget/Button;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    new-instance v0, Lc/Z;

    const/16 v1, 0x12

    invoke-direct {v0, v11, v2, v8, v1}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance v1, Lc/E6;

    invoke-direct {v1, v0}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2, v1}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    invoke-virtual {v8}, Lc/x6;->run()V

    new-instance v0, Lc/u8;

    invoke-direct {v0, v12}, Lc/u8;-><init>(Landroid/content/Context;)V

    iput-object v0, v11, Lc/H6;->k:Lc/u8;

    iget-object v1, v11, Lc/H6;->d:Landroid/widget/LinearLayout;

    const/16 v2, 0xc

    invoke-virtual {v11, v1, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v0, "\u0414\u0430\u043d\u043d\u044b\u0435 \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f"

    invoke-virtual {v11, v0}, Lc/H6;->j(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v6

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    new-instance v7, Lc/o6;

    invoke-static {v0}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lc/v;

    const/4 v3, 0x7

    invoke-direct {v2, v3}, Lc/v;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lc/A6;

    const/4 v15, 0x0

    invoke-direct {v2, v15}, Lc/A6;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->toArray(Ljava/util/function/IntFunction;)[Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, [Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lc/v;

    const/16 v10, 0x8

    invoke-direct {v2, v10}, Lc/v;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->map(Ljava/util/function/Function;)Ljava/util/stream/Stream;

    move-result-object v1

    new-instance v2, Lc/A6;

    const/4 v8, 0x1

    invoke-direct {v2, v8}, Lc/A6;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/Stream;->toArray(Ljava/util/function/IntFunction;)[Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, [Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->stream([Ljava/lang/Object;)Ljava/util/stream/Stream;

    move-result-object v0

    new-instance v1, Lc/l0;

    invoke-direct {v1, v13}, Lc/l0;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/stream/Stream;->mapToInt(Ljava/util/function/ToIntFunction;)Ljava/util/stream/IntStream;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/stream/IntStream;->toArray()[I

    move-result-object v5

    move-object v0, v7

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct/range {v0 .. v5}, Lc/o6;-><init>(Landroid/app/Activity;Lc/r4;[Ljava/lang/String;[Ljava/lang/String;[I)V

    iput-object v7, v11, Lc/H6;->s:Lc/o6;

    const-string v0, "\u041f\u043e\u043a\u0430\u0437\u0430\u043d\u0438\u044f \u043e\u0431\u043d\u043e\u0432\u043b\u044f\u044e\u0442\u0441\u044f \u043f\u043e \u043e\u0447\u0435\u0440\u0435\u0434\u0438. \u041f\u0440\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0438 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430 \u0434\u0430\u043d\u043d\u044b\u0435 \u0441\u043a\u0440\u044b\u0432\u0430\u044e\u0442\u0441\u044f."

    const/16 v9, 0xe

    invoke-virtual {v11, v9, v0, v8}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v11, v6, v0, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v0, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438, \u043a\u043e\u0442\u043e\u0440\u044b\u0435 \u043d\u0443\u0436\u043d\u044b \u043d\u0430 \u0433\u043b\u0430\u0432\u043d\u043e\u043c \u044d\u043a\u0440\u0430\u043d\u0435. \u041c\u043e\u0436\u043d\u043e \u0432\u044b\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0432\u0441\u0435."

    const/16 v1, 0xd

    invoke-virtual {v11, v1, v0, v8}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v11, v6, v0, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v0

    array-length v1, v0

    move v2, v15

    :goto_2
    if-ge v2, v1, :cond_5

    aget-object v3, v0, v2

    new-instance v4, Landroid/widget/Switch;

    invoke-direct {v4, v12}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v5, v3, Lc/F0;->a:Ljava/lang/String;

    invoke-static {v12, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v5, v11, Lc/H6;->b:Lc/r4;

    invoke-static {v4, v5}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    iget-object v5, v11, Lc/H6;->w:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->z()I

    move-result v5

    invoke-virtual {v3}, Lc/F0;->a()I

    move-result v7

    and-int/2addr v5, v7

    if-eqz v5, :cond_4

    move v5, v8

    goto :goto_3

    :cond_4
    move v5, v15

    :goto_3
    invoke-virtual {v4, v5}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v5, v11, Lc/H6;->H:Ljava/util/EnumMap;

    invoke-virtual {v5, v3, v4}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Lc/i0;

    invoke-direct {v5, v11, v3, v13}, Lc/i0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v5}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v11, v3}, Lc/H6;->z(Lc/F0;)Ljava/lang/String;

    move-result-object v5

    new-instance v7, Lc/H;

    const/16 v9, 0x19

    invoke-direct {v7, v11, v3, v9}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v11, v5, v15, v7}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v5

    const/high16 v7, 0x41400000    # 12.0f

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v7, v11, Lc/H6;->b:Lc/r4;

    invoke-static {v7}, Lc/G8;->V0(Lc/r4;)I

    move-result v7

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    iget-object v7, v11, Lc/H6;->I:Ljava/util/EnumMap;

    invoke-virtual {v7, v3, v5}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v9, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v5, v9}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    iget-object v9, v11, Lc/H6;->s:Lc/o6;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    invoke-virtual {v9, v3, v4, v5}, Lc/o6;->a(ILandroid/widget/Switch;Landroid/widget/Button;)V

    add-int/2addr v2, v8

    const/16 v9, 0xe

    goto :goto_2

    :cond_5
    const/4 v7, 0x2

    iget-object v0, v11, Lc/H6;->s:Lc/o6;

    invoke-virtual {v11, v6, v0, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v0

    iput-object v0, v11, Lc/H6;->x:Landroid/widget/LinearLayout;

    invoke-virtual {v11, v6, v0, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v1, 0xc

    invoke-virtual {v11, v6, v0, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    move-object/from16 v13, v40

    const/16 v1, 0xd

    invoke-virtual {v11, v1, v13, v8}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->D:Landroid/widget/TextView;

    invoke-virtual {v11, v0, v2, v15}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v1, Landroid/widget/EditText;

    invoke-direct {v1, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iput-object v1, v11, Lc/H6;->E:Landroid/widget/EditText;

    invoke-virtual {v1, v8}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v2, 0x41700000    # 15.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v2, v11, Lc/H6;->b:Lc/r4;

    iget v2, v2, Lc/r4;->d:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v11, Lc/H6;->b:Lc/r4;

    iget v2, v2, Lc/r4;->e:I

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setHintTextColor(I)V

    const-string v2, "\u041d\u0430\u0439\u0442\u0438 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044c"

    invoke-static {v12, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    invoke-static {v12, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget-object v2, v11, Lc/H6;->b:Lc/r4;

    iget v2, v2, Lc/r4;->b:I

    invoke-virtual {v11, v2}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v2, 0xc

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {v11, v10}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v5

    invoke-virtual {v11, v10}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {v1, v3, v4, v5, v2}, Landroid/view/View;->setPadding(IIII)V

    const/16 v2, 0x30

    invoke-virtual {v11, v2}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v11, v0, v1, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v2, Lc/B6;

    invoke-direct {v2, v11, v12}, Lc/B6;-><init>(Lc/H6;Landroid/app/Activity;)V

    iput-object v2, v11, Lc/H6;->F:Lc/B6;

    const/4 v9, 0x0

    invoke-virtual {v2, v9}, Landroid/widget/ListView;->setDivider(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v2, v15}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v2, v8}, Landroid/view/View;->setNestedScrollingEnabled(Z)V

    new-instance v3, Lc/C6;

    invoke-direct {v3, v11}, Lc/C6;-><init>(Lc/H6;)V

    iput-object v3, v11, Lc/H6;->L:Lc/C6;

    invoke-virtual {v2, v3}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v3, Lc/A;

    invoke-direct {v3, v11, v7}, Lc/A;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x168

    invoke-virtual {v11, v4}, Lc/H6;->g(I)I

    move-result v4

    const/4 v5, -0x1

    invoke-direct {v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v10}, Lc/H6;->g(I)I

    move-result v4

    iput v4, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Lc/q6;

    invoke-direct {v2, v11, v7}, Lc/q6;-><init>(Lc/H6;I)V

    const-string v3, "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0432\u0441\u0435 \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0435"

    invoke-virtual {v11, v3, v15, v2}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->G:Landroid/widget/Button;

    invoke-virtual {v11, v0, v2, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Lc/D6;

    invoke-direct {v0, v11, v15}, Lc/D6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const-string v0, "\u0420\u0430\u0441\u0445\u043e\u0434 \u0442\u043e\u043f\u043b\u0438\u0432\u0430"

    invoke-virtual {v11, v0}, Lc/H6;->j(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v6

    new-instance v7, Lc/o6;

    const-string v0, "\u0412 \u0447\u0430\u0441"

    const-string v1, "\u041d\u0430 100 \u043a\u043c"

    const-string v2, "\u0421\u0440\u0435\u0434\u043d\u0438\u0439 \u0437\u0430 \u043f\u043e\u0435\u0437\u0434\u043a\u0443"

    const-string v3, "\u0418\u0437\u0440\u0430\u0441\u0445\u043e\u0434\u043e\u0432\u0430\u043d\u043e"

    filled-new-array {v0, v1, v2, v3}, [Ljava/lang/String;

    move-result-object v3

    const-string v0, "\u043b"

    const-string v1, "\u043b/\u0447"

    const-string v2, "\u043b/100 \u043a\u043c"

    filled-new-array {v1, v2, v2, v0}, [Ljava/lang/String;

    move-result-object v4

    const-string v0, "Fuel flow"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v0

    const-string v1, "Fuel consumption"

    invoke-static {v1}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v2

    invoke-static {v1}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v1

    const-string v5, "Fuel volume"

    invoke-static {v5}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v5

    filled-new-array {v0, v2, v1, v5}, [I

    move-result-object v5

    move-object v0, v7

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct/range {v0 .. v5}, Lc/o6;-><init>(Landroid/app/Activity;Lc/r4;[Ljava/lang/String;[Ljava/lang/String;[I)V

    iput-object v7, v11, Lc/H6;->t:Lc/o6;

    const/16 v0, 0xc

    invoke-virtual {v11, v6, v7, v0}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/16 v1, 0xd

    invoke-virtual {v11, v1, v13, v8}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    iput-object v2, v11, Lc/H6;->p:Landroid/widget/TextView;

    invoke-virtual {v11, v6, v2, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v1, v11, Lc/H6;->c:Lc/T5;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lc/A5;

    invoke-direct {v2, v1, v0}, Lc/A5;-><init>(Lc/T5;I)V

    const-string v0, "\u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c \u043f\u043e\u0435\u0437\u0434\u043a\u0443"

    invoke-virtual {v11, v0, v15, v2}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v11, v6, v0, v10}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0422\u043e\u043f\u043b\u0438\u0432\u043e"

    const-string v2, "fuel_type"

    invoke-virtual {v11, v6, v1, v0, v2}, Lc/H6;->l(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;Ljava/lang/String;)V

    const-string v30, "\u041c\u0435\u0442\u0430\u043d"

    const-string v31, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u043e \u042d\u0411\u0423"

    const-string v25, "\u0411\u0435\u043d\u0437\u0438\u043d"

    const-string v26, "\u0414\u0438\u0437\u0435\u043b\u044c"

    const-string v27, "\u042d\u0442\u0430\u043d\u043e\u043b"

    const-string v28, "\u041c\u0435\u0442\u0430\u043d\u043e\u043b"

    const-string v29, "\u041f\u0440\u043e\u043f\u0430\u043d"

    const-string v32, "\u0421\u0432\u043e\u0438 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b"

    const-string v33, "\u042d\u043b\u0435\u043a\u0442\u0440\u0438\u0447\u0435\u0441\u043a\u0438\u0439"

    filled-new-array/range {v25 .. v33}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v11, v0, v1}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    iget-object v1, v11, Lc/H6;->c:Lc/T5;

    iget-object v1, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v1, v2, v15, v10, v15}, Lc/t;->b(Landroid/content/SharedPreferences;Ljava/lang/String;III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    new-instance v1, Lc/r6;

    invoke-direct {v1, v11, v0, v15}, Lc/r6;-><init>(Lc/H6;Landroid/widget/Spinner;I)V

    new-instance v2, Lc/E6;

    invoke-direct {v2, v1}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v2}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    new-instance v0, Landroid/widget/Spinner;

    invoke-direct {v0, v12}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0420\u0430\u0441\u0447\u0451\u0442"

    const-string v2, "fuel_scheme"

    invoke-virtual {v11, v6, v1, v0, v2}, Lc/H6;->l(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;Ljava/lang/String;)V

    const-string v28, "\u041f\u043e \u0434\u0430\u0432\u043b\u0435\u043d\u0438\u044e (MAP)"

    const-string v29, "\u0420\u0430\u0441\u0445\u043e\u0434 \u042d\u0411\u0423"

    const-string v25, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    const-string v26, "\u041f\u043e \u0432\u043e\u0437\u0434\u0443\u0445\u0443 (MAF)"

    const-string v27, "\u041f\u043e \u0430\u0431\u0441\u043e\u043b\u044e\u0442\u043d\u043e\u0439 \u043d\u0430\u0433\u0440\u0443\u0437\u043a\u0435"

    const-string v30, "\u041f\u043e \u0434\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u0438 \u0432\u043f\u0440\u044b\u0441\u043a\u0430"

    const-string v31, "\u0420\u0430\u0441\u0445\u043e\u0434 \u0437\u0430 \u0446\u0438\u043a\u043b"

    filled-new-array/range {v25 .. v31}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v11, v0, v1}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    iget-object v1, v11, Lc/H6;->c:Lc/T5;

    iget-object v1, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x6

    invoke-static {v1, v2, v15, v3, v15}, Lc/t;->b(Landroid/content/SharedPreferences;Ljava/lang/String;III)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    new-instance v1, Lc/r6;

    invoke-direct {v1, v11, v0, v8}, Lc/r6;-><init>(Lc/H6;Landroid/widget/Spinner;I)V

    new-instance v2, Lc/E6;

    invoke-direct {v2, v1}, Lc/E6;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v2}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v0, v11, Lc/H6;->c:Lc/T5;

    const v1, 0x3fcccccd    # 1.6f

    iget-object v0, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "engine_litres"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    float-to-double v4, v0

    const-string v3, "engine_litres"

    const-wide/high16 v16, 0x3fe0000000000000L    # 0.5

    const-string v2, "\u041e\u0431\u044a\u0451\u043c \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b\u044f, \u043b"

    const-wide/high16 v18, 0x4024000000000000L    # 10.0

    const/4 v12, 0x0

    move-object/from16 v0, p0

    move-object v1, v6

    move-object/from16 p1, v6

    move-wide/from16 v6, v16

    move v15, v8

    move-wide/from16 v8, v18

    move v15, v10

    move v10, v12

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    const-wide v6, 0x3fb999999999999aL    # 0.1

    const-string v2, "\u041a\u043e\u044d\u0444\u0444\u0438\u0446\u0438\u0435\u043d\u0442 \u0440\u0430\u0441\u0445\u043e\u0434\u0430"

    const-string v3, "fuel_correction"

    const-wide/high16 v8, 0x4024000000000000L    # 10.0

    const/4 v10, 0x0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-wide/high16 v4, 0x4010000000000000L    # 4.0

    const-wide/high16 v6, 0x3ff0000000000000L    # 1.0

    const-string v2, "\u0427\u0438\u0441\u043b\u043e \u0446\u0438\u043b\u0438\u043d\u0434\u0440\u043e\u0432"

    const-string v3, "engine_cylinders"

    const-wide/high16 v8, 0x4030000000000000L    # 16.0

    const/4 v10, 0x1

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-wide v4, 0x406f400000000000L    # 250.0

    const-string v2, "\u0424\u043e\u0440\u0441\u0443\u043d\u043a\u0430, \u0441\u043c\u00b3/\u043c\u0438\u043d"

    const-string v3, "injector_flow"

    const-wide v8, 0x40b3880000000000L    # 5000.0

    const/4 v10, 0x0

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v12

    move-object/from16 v10, p1

    invoke-virtual {v11, v10, v12, v15}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-wide v4, 0x402d666666666666L    # 14.7

    const-string v2, "\u0421\u0432\u043e\u0438 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u00b7 \u0432\u043e\u0437\u0434\u0443\u0445 / \u0442\u043e\u043f\u043b\u0438\u0432\u043e"

    const-string v3, "fuel_custom_af"

    const-wide/high16 v8, 0x4059000000000000L    # 100.0

    const/16 v16, 0x0

    move-object v1, v12

    move-object v15, v10

    move/from16 v10, v16

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-wide v4, 0x3fe75c28f5c28f5cL    # 0.73

    const-wide v6, 0x3f847ae147ae147bL    # 0.01

    const-string v2, "\u0421\u0432\u043e\u0438 \u043f\u0430\u0440\u0430\u043c\u0435\u0442\u0440\u044b \u00b7 \u043f\u043b\u043e\u0442\u043d\u043e\u0441\u0442\u044c, \u043a\u0433/\u043b"

    const-string v3, "fuel_custom_density"

    const-wide/high16 v8, 0x4014000000000000L    # 5.0

    const/4 v10, 0x0

    invoke-virtual/range {v0 .. v10}, Lc/H6;->n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V

    const-string v0, "\u0421\u043f\u043e\u0441\u043e\u0431 \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0432\u044b\u0431\u0438\u0440\u0430\u0435\u0442\u0441\u044f \u043f\u043e \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u043c \u0434\u0430\u0442\u0447\u0438\u043a\u0430\u043c. \u0414\u043b\u044f \u0440\u0430\u0441\u0447\u0451\u0442\u043d\u043e\u0433\u043e \u0440\u0430\u0441\u0445\u043e\u0434\u0430 \u0437\u0430\u0434\u0430\u0439\u0442\u0435 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b\u044c, \u0442\u043e\u043f\u043b\u0438\u0432\u043e \u0438 \u043a\u043e\u044d\u0444\u0444\u0438\u0446\u0438\u0435\u043d\u0442 \u043a\u0430\u043b\u0438\u0431\u0440\u043e\u0432\u043a\u0438. \u041d\u0430 \u043c\u0435\u0441\u0442\u0435 \u2014 \u043b/\u0447; \u043b/100 \u043a\u043c \u2014 \u043f\u0440\u0438 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438 \u043e\u0442 5 \u043a\u043c/\u0447."

    const/4 v1, 0x1

    const/16 v2, 0xe

    invoke-virtual {v11, v2, v0, v1}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v2, 0xc

    invoke-virtual {v11, v15, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v0, v11, Lc/H6;->h:Landroid/widget/LinearLayout;

    const-string v2, "\u0410\u0432\u0442\u043e\u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043a \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u043c\u0443 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0443. \u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0434\u0440\u0443\u0433\u0438\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f OBD."

    const/16 v3, 0xd

    invoke-virtual {v11, v3, v2, v1}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v2, v14}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v1, 0x8

    invoke-virtual {v11, v0, v2, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v0, v11, Lc/H6;->d:Landroid/widget/LinearLayout;

    iget-object v4, v11, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v5, v11, Lc/H6;->b:Lc/r4;

    iget-object v8, v11, Lc/H6;->c:Lc/T5;

    sget-object v1, Lc/b7;->a:Lc/B0;

    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0xd

    invoke-static {v4, v5, v13, v2, v1}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v7

    const/16 v2, 0x8

    invoke-virtual {v7, v2}, Landroid/view/View;->setVisibility(I)V

    new-instance v2, Lc/Z2;

    invoke-direct {v2, v7, v1}, Lc/Z2;-><init>(Landroid/widget/TextView;I)V

    invoke-virtual {v7, v2}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v1, 0xc

    invoke-static {v4, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v4, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v4, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v10

    invoke-static {v4, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v9, v2, v3, v10, v12}, Landroid/view/View;->setPadding(IIII)V

    iget v1, v5, Lc/r4;->c:I

    invoke-static {v4, v1}, Lc/b7;->m(Landroid/app/Activity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v3, "\u041f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0435 PID"

    const/4 v10, 0x0

    invoke-static {v4, v5, v3, v2, v10}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v2

    const/4 v3, 0x1

    const/4 v10, 0x0

    invoke-virtual {v2, v10, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setSingleLine(Z)V

    const-string v3, "\u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0441\u0432\u043e\u0439 \u0434\u0430\u0442\u0447\u0438\u043a \u0438\u043b\u0438 \u0438\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 CSP Car Scanner / CSV Torque. \u041f\u043e\u0441\u043b\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0435\u0433\u043e \u0432 \u0434\u0430\u043d\u043d\u044b\u0445 \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f."

    invoke-static {v4, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setTooltipText(Ljava/lang/CharSequence;)V

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v3, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v3, 0xc

    invoke-static {v4, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v12

    iput v12, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    new-instance v3, Lc/Z;

    const/16 v12, 0x17

    invoke-direct {v3, v4, v5, v8, v12}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v12, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c PID"

    const/4 v14, 0x1

    invoke-static {v4, v5, v12, v14, v3}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v3

    invoke-virtual {v1, v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v3, 0x8

    invoke-static {v4, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v12

    iput v12, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    new-instance v12, Lc/W6;

    const/4 v14, 0x0

    invoke-direct {v12, v4, v8, v7, v14}, Lc/W6;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/T5;Landroid/widget/TextView;I)V

    const-string v15, "\u0418\u043c\u043f\u043e\u0440\u0442"

    invoke-static {v4, v5, v15, v14, v12}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v12

    invoke-virtual {v1, v12, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {v4, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v10

    iput v10, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    new-instance v3, Lc/W6;

    const/4 v10, 0x1

    invoke-direct {v3, v4, v8, v7, v10}, Lc/W6;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/T5;Landroid/widget/TextView;I)V

    const-string v10, "\u042d\u043a\u0441\u043f\u043e\u0440\u0442"

    invoke-static {v4, v5, v10, v14, v3}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v3

    invoke-virtual {v1, v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/HorizontalScrollView;

    invoke-direct {v2, v4}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2, v14}, Landroid/view/View;->setHorizontalScrollBarEnabled(Z)V

    invoke-virtual {v2, v1}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    invoke-static {v9, v2, v14}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/16 v1, 0x8

    invoke-static {v9, v6, v1}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/4 v1, 0x4

    invoke-static {v9, v7, v1}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    filled-new-array {v13}, [Ljava/lang/String;

    move-result-object v3

    new-instance v10, Lc/X6;

    move-object v1, v10

    move-object v2, v8

    invoke-direct/range {v1 .. v7}, Lc/X6;-><init>(Lc/T5;[Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    new-instance v1, Lc/Z6;

    invoke-direct {v1, v8, v10}, Lc/Z6;-><init>(Lc/T5;Lc/X6;)V

    invoke-virtual {v9, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    invoke-virtual {v10}, Lc/X6;->run()V

    const/16 v1, 0xc

    invoke-virtual {v11, v0, v9, v1}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    iget-object v0, v11, Lc/H6;->d:Landroid/widget/LinearLayout;

    iget-object v1, v11, Lc/H6;->b:Lc/r4;

    iget v1, v1, Lc/r4;->d:I

    invoke-static {v0, v1}, Lc/G8;->p(Landroid/widget/LinearLayout;I)V

    iget-object v0, v11, Lc/H6;->d:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    invoke-virtual/range {p0 .. p0}, Lc/H6;->t()V

    return-void

    :array_0
    .array-data 4
        0x0
        0x6
        0x7
        0x8
        0x9
        0x1
        0x2
        0x3
        0x4
        0x5
        0xa
        0xb
        0x2b
        0x2c
    .end array-data

    :array_1
    .array-data 4
        0x2580
        0x4b00
        0x9600
        0xe100
        0x1c200
        0x38400
        0x7a120
        0xf4240
    .end array-data
.end method

.method public static k(DI)Ljava/lang/String;
    .locals 3

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "%."

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "f"

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v0, p2, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static o(DZ)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/text/DecimalFormat;

    if-eqz p2, :cond_0

    const-string p2, "0"

    goto :goto_0

    :cond_0
    const-string p2, "0.######"

    :goto_0
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-static {v1}, Ljava/text/DecimalFormatSymbols;->getInstance(Ljava/util/Locale;)Ljava/text/DecimalFormatSymbols;

    move-result-object v1

    invoke-direct {v0, p2, v1}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;Ljava/text/DecimalFormatSymbols;)V

    const/4 p2, 0x0

    invoke-virtual {v0, p2}, Ljava/text/DecimalFormat;->setGroupingUsed(Z)V

    invoke-virtual {v0, p0, p1}, Ljava/text/NumberFormat;->format(D)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static x(Landroid/widget/TextView;Ljava/lang/String;)V
    .locals 1

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    return-void
.end method


# virtual methods
.method public final A()V
    .locals 7

    invoke-virtual {p0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->z()I

    move-result v1

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v3, :cond_2

    aget-object v5, v2, v4

    invoke-virtual {v5}, Lc/F0;->a()I

    move-result v6

    and-int/2addr v6, v1

    if-eqz v6, :cond_1

    iget v5, v5, Lc/F0;->d:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v0, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    iget-object v1, p0, Lc/H6;->c:Lc/T5;

    invoke-virtual {v1, p0, v0}, Lc/T5;->r0(Ljava/lang/Object;Ljava/util/LinkedHashSet;)V

    return-void
.end method

.method public final B(ILjava/lang/String;Z)Landroid/widget/TextView;
    .locals 2

    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object p1, p0, Lc/H6;->b:Lc/r4;

    if-eqz p3, :cond_1

    iget-boolean p2, p1, Lc/r4;->m:Z

    if-eqz p2, :cond_0

    const p1, -0xb0a399

    goto :goto_0

    :cond_0
    iget p1, p1, Lc/r4;->e:I

    goto :goto_0

    :cond_1
    iget p1, p1, Lc/r4;->d:I

    :goto_0
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-object v0
.end method

.method public final C(Ljava/lang/Runnable;)V
    .locals 6

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v1

    const-string v2, "ble"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "spp"

    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :cond_0
    invoke-virtual {v0}, Lc/T5;->e0()Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_2

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1f

    const/4 v3, 0x1

    if-lt p1, v1, :cond_1

    const/4 p1, 0x2

    new-array p1, p1, [Ljava/lang/String;

    const-string v1, "android.permission.BLUETOOTH_SCAN"

    aput-object v1, p1, v2

    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    aput-object v1, p1, v3

    goto :goto_0

    :cond_1
    new-array p1, v3, [Ljava/lang/String;

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    aput-object v1, p1, v2

    :goto_0
    const/16 v1, 0x2db

    iget-object v2, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2, p1, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    const-string p1, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f, \u0437\u0430\u0442\u0435\u043c \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u043f\u043e\u0438\u0441\u043a"

    iput-object p1, v0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v0}, Lc/T5;->q()V

    return-void

    :cond_2
    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v1

    const-string v3, "\u0412\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 Bluetooth \u0430\u043a\u0441\u0435\u0441\u0441\u0443\u0430\u0440\u043e\u0432\u2026"

    iput-object v3, v0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v0}, Lc/T5;->q()V

    new-instance v0, Lc/Z;

    const/16 v3, 0x13

    invoke-direct {v0, p0, v1, p1, v3}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance p1, Lc/E3;

    const/4 v1, 0x2

    invoke-direct {p1, p0, v1}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    iget-object v1, p0, Lc/H6;->n0:Lc/u5;

    invoke-virtual {v1}, Lc/u5;->a()V

    iget-object v3, v1, Lc/u5;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object v0, v1, Lc/u5;->c:Lc/Z;

    iput-object p1, v1, Lc/u5;->d:Lc/E3;

    :try_start_0
    const-class p1, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {v3, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/bluetooth/BluetoothManager;

    if-nez p1, :cond_3

    const/4 p1, 0x0

    goto :goto_1

    :cond_3
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object p1

    :goto_1
    if-nez p1, :cond_4

    const-string p1, "Bluetooth Android \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    iget-object v0, v1, Lc/u5;->d:Lc/E3;

    invoke-virtual {v1}, Lc/u5;->a()V

    invoke-virtual {v0, p1}, Lc/E3;->accept(Ljava/lang/Object;)V

    goto :goto_2

    :cond_4
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothAdapter;->getState()I

    move-result v0

    const/16 v4, 0xc

    if-ne v0, v4, :cond_5

    iget-object p1, v1, Lc/u5;->c:Lc/Z;

    invoke-virtual {v1}, Lc/u5;->a()V

    invoke-virtual {p1}, Lc/Z;->run()V

    goto :goto_2

    :cond_5
    const/16 v4, 0xd

    if-ne v0, v4, :cond_6

    const-string p1, "Bluetooth \u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f. \u041f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u043f\u043e\u0441\u043b\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043d\u0438\u044f"

    iget-object v0, v1, Lc/u5;->d:Lc/E3;

    invoke-virtual {v1}, Lc/u5;->a()V

    invoke-virtual {v0, p1}, Lc/E3;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_1

    goto :goto_2

    :cond_6
    const/16 v4, 0xb

    if-eq v0, v4, :cond_7

    :try_start_1
    invoke-virtual {p1}, Landroid/bluetooth/BluetoothAdapter;->enable()Z

    move-result v2
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_0
    if-nez v2, :cond_7

    :try_start_2
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.bluetooth.adapter.action.REQUEST_ENABLE"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    :cond_7
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    const-wide/16 v4, 0x4e20

    add-long/2addr v2, v4

    iput-wide v2, v1, Lc/u5;->e:J

    iget-object p1, v1, Lc/u5;->b:Landroid/os/Handler;

    iget-object v0, v1, Lc/u5;->f:Lc/i;

    const-wide/16 v2, 0xfa

    invoke-virtual {p1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_2
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Landroid/content/ActivityNotFoundException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_2

    :catch_1
    iget-object p1, v1, Lc/u5;->d:Lc/E3;

    invoke-virtual {v1}, Lc/u5;->a()V

    const-string v0, "\u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 Bluetooth Android \u0438 \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0435\u0433\u043e"

    invoke-virtual {p1, v0}, Lc/E3;->accept(Ljava/lang/Object;)V

    goto :goto_2

    :catch_2
    iget-object p1, v1, Lc/u5;->d:Lc/E3;

    invoke-virtual {v1}, Lc/u5;->a()V

    const-string v0, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a Bluetooth, \u0437\u0430\u0442\u0435\u043c \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435"

    invoke-virtual {p1, v0}, Lc/E3;->accept(Ljava/lang/Object;)V

    :goto_2
    invoke-virtual {p0}, Lc/H6;->t()V

    return-void
.end method

.method public final a(Landroid/widget/LinearLayout;Landroid/view/View;I)V
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, p3}, Lc/H6;->g(I)I

    move-result p3

    iput p3, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {p1, p2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public final b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;
    .locals 2

    new-instance v0, Landroid/widget/Button;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p0, Lc/H6;->b:Lc/r4;

    invoke-static {v0, p1, p2}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance p1, Lc/h1;

    const/4 p2, 0x5

    invoke-direct {p1, p3, p2}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method public final c(Landroid/widget/Button;I)V
    .locals 3

    iget-object v0, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    iget-object v0, p0, Lc/H6;->b:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    invoke-virtual {p2, v0}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/16 v0, 0x18

    invoke-virtual {p0, v0}, Lc/H6;->g(I)I

    move-result v1

    invoke-virtual {p0, v0}, Lc/H6;->g(I)I

    move-result v0

    const/4 v2, 0x0

    invoke-virtual {p2, v2, v2, v1, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v0, 0x0

    invoke-virtual {p1, p2, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/16 p2, 0xc

    invoke-virtual {p0, p2}, Lc/H6;->g(I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    return-void
.end method

.method public final d(Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 6

    invoke-virtual {p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v0

    const/16 v1, 0x10

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v5

    invoke-virtual {v0, v2, v3, v4, v5}, Landroid/view/View;->setPadding(IIII)V

    iget-object v2, p0, Lc/H6;->b:Lc/r4;

    iget v2, v2, Lc/r4;->c:I

    invoke-virtual {p0, v2}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    invoke-virtual {p0, v1, p1, v2}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    return-object v0
.end method

.method public final e(Landroid/widget/Spinner;Ljava/util/List;)V
    .locals 3

    const/16 v0, 0x30

    invoke-virtual {p0, v0}, Lc/H6;->g(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    const/4 v0, 0x0

    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/view/View;->setPadding(IIII)V

    iget-object v0, p0, Lc/H6;->b:Lc/r4;

    iget v1, v0, Lc/r4;->b:I

    invoke-virtual {p0, v1}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/Spinner;->setPopupBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget v1, v0, Lc/r4;->b:I

    invoke-virtual {p0, v1}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    const/16 v2, 0x3e8

    invoke-virtual {p0, v2}, Lc/H6;->g(I)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v2, 0x1

    invoke-virtual {p0, v2}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {v0}, Lc/r4;->a()I

    move-result v0

    invoke-virtual {v1, v2, v0}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/F6;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, p0, v1, p2, p2}, Lc/F6;-><init>(Lc/H6;Lru/drivedeck/launcher/MainActivity;Ljava/util/List;Ljava/util/List;)V

    invoke-virtual {p1, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method public final f()Landroid/widget/LinearLayout;
    .locals 2

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    return-object v0
.end method

.method public final g(I)I
    .locals 1

    int-to-float p1, p1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final h(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;)V
    .locals 8

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v3, 0xe

    const/4 v4, 0x0

    invoke-virtual {p0, v3, p2, v4}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const-string v6, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435"

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/16 v6, 0x70

    goto :goto_0

    :cond_0
    const/16 v6, 0x60

    :goto_0
    invoke-virtual {p0, v6}, Lc/H6;->g(I)I

    move-result v6

    const/4 v7, -0x2

    invoke-direct {v5, v6, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v3, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x34

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v1

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {p2, v4, v1, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p3, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {p0, p1, v0, v2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    return-void
.end method

.method public final i()V
    .locals 7

    iget-object v0, p0, Lc/H6;->E:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/H6;->K:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v2, p0, Lc/H6;->J:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i6;

    iget-object v4, p0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, v3, Lc/i6;->c:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v3, Lc/i6;->e:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v4, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_0

    :cond_1
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    iget-boolean v0, p0, Lc/H6;->Q:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lc/H6;->L:Lc/C6;

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_3
    return-void
.end method

.method public final j(Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 11

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/H6;->d(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v7

    invoke-virtual {p0}, Lc/H6;->f()Landroid/widget/LinearLayout;

    move-result-object v8

    const/16 v1, 0x8

    invoke-virtual {v8, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/16 v1, 0xc

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v2

    const/4 v3, 0x4

    invoke-virtual {p0, v3}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v1

    invoke-virtual {p0, v3}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {v7, v2, v4, v1, v3}, Landroid/view/View;->setPadding(IIII)V

    new-instance v1, Lc/a1;

    const/4 v2, 0x6

    invoke-direct {v1, v2}, Lc/a1;-><init>(I)V

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v2, v1}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    const/4 v1, 0x1

    invoke-virtual {v9, v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const v0, 0x800013

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setGravity(I)V

    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    invoke-virtual {p0, v2}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    const/16 v3, 0x3e8

    invoke-virtual {p0, v3}, Lc/H6;->g(I)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v10, -0x1

    invoke-virtual {p0, v10}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {p0, v3}, Lc/H6;->g(I)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-direct {v0, v1, v2, v4}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v9, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/C2;

    invoke-direct {v0, p0, v8, v9, p1}, Lc/C2;-><init>(Lc/H6;Landroid/widget/LinearLayout;Landroid/widget/Button;Ljava/lang/String;)V

    new-instance p1, Lc/j0;

    const/4 v6, 0x5

    move-object v1, p1

    move-object v2, p0

    move-object v3, v8

    move-object v4, v7

    move-object v5, v0

    invoke-direct/range {v1 .. v6}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v9, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    invoke-direct {p1, v10, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v9, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v10, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v8, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v10, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    iget-object v1, p0, Lc/H6;->k:Lc/u8;

    invoke-virtual {v1, v7, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0}, Lc/C2;->run()V

    return-object v8
.end method

.method public final l(Landroid/widget/LinearLayout;Ljava/lang/String;Landroid/widget/Spinner;Ljava/lang/String;)V
    .locals 6

    new-instance v0, Landroid/widget/LinearLayout;

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0xe

    const/4 v3, 0x1

    invoke-virtual {p0, v2, p2, v3}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x54

    invoke-virtual {p0, v4}, Lc/H6;->g(I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v3, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {v1, v2, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x30

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v1

    invoke-direct {p3, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v1, 0x8

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v1

    iput v1, p3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {p0, p2, p4}, Lc/H6;->m(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object p2

    invoke-virtual {v0, p2, p3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p2, 0x4

    invoke-virtual {p0, p1, v0, p2}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    return-void
.end method

.method public final m(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;
    .locals 4

    new-instance v0, Lc/a1;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lc/a1;-><init>(I)V

    const-string v1, "\u24d8"

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2, v0}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v0

    new-instance v1, Lc/w2;

    const/4 v3, 0x2

    invoke-direct {v1, p0, p2, v3}, Lc/w2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    const/16 p2, 0x30

    invoke-virtual {p0, p2}, Lc/H6;->g(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMinWidth(I)V

    invoke-virtual {p0, p2}, Lc/H6;->g(I)I

    move-result p2

    invoke-virtual {v0, p2}, Landroid/view/View;->setMinimumWidth(I)V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-object v0
.end method

.method public final n(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;DDDZ)V
    .locals 16

    move-object/from16 v10, p0

    move-object/from16 v0, p2

    move-object/from16 v9, p3

    move/from16 v3, p10

    new-instance v1, Landroid/widget/LinearLayout;

    iget-object v2, v10, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v4, 0x10

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v4, 0xe

    const/4 v5, 0x1

    invoke-virtual {v10, v4, v0, v5}, Lc/H6;->B(ILjava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x0

    const/4 v8, -0x2

    const/high16 v11, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v8, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v11, 0x8

    invoke-virtual {v10, v11}, Lc/H6;->g(I)I

    move-result v12

    iput v12, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    invoke-virtual {v1, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v12, Landroid/widget/EditText;

    invoke-direct {v12, v2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    iget-object v4, v10, Lc/H6;->b:Lc/r4;

    iget v6, v4, Lc/r4;->d:I

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41800000    # 16.0f

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v12, v5}, Landroid/widget/TextView;->setSingleLine(Z)V

    if-eqz v3, :cond_0

    move v6, v7

    goto :goto_0

    :cond_0
    const/16 v6, 0x2000

    :goto_0
    or-int/lit8 v6, v6, 0x2

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setInputType(I)V

    if-eqz v3, :cond_1

    const-string v6, "0123456789"

    goto :goto_1

    :cond_1
    const-string v6, "0123456789.,"

    :goto_1
    invoke-static {v6}, Landroid/text/method/DigitsKeyListener;->getInstance(Ljava/lang/String;)Landroid/text/method/DigitsKeyListener;

    move-result-object v6

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setKeyListener(Landroid/text/method/KeyListener;)V

    const/4 v6, 0x6

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setImeOptions(I)V

    iget-object v6, v10, Lc/H6;->c:Lc/T5;

    iget-object v6, v6, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v6}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    instance-of v13, v6, Ljava/lang/Number;

    if-eqz v13, :cond_2

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v13

    goto :goto_2

    :cond_2
    move-wide/from16 v13, p4

    :goto_2
    invoke-static {v13, v14, v3}, Lc/H6;->o(DZ)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    iget v2, v4, Lc/r4;->b:I

    invoke-virtual {v10, v2}, Lc/H6;->y(I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v12, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v2, 0xa

    invoke-virtual {v10, v2}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {v10, v11}, Lc/H6;->g(I)I

    move-result v6

    invoke-virtual {v10, v2}, Lc/H6;->g(I)I

    move-result v2

    invoke-virtual {v10, v11}, Lc/H6;->g(I)I

    move-result v15

    invoke-virtual {v12, v4, v6, v2, v15}, Landroid/view/View;->setPadding(IIII)V

    const/16 v2, 0x30

    invoke-virtual {v10, v2}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {v12, v4}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x60

    invoke-virtual {v10, v6}, Lc/H6;->g(I)I

    move-result v6

    invoke-direct {v4, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v12, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v10, v2}, Lc/H6;->g(I)I

    move-result v6

    invoke-virtual {v10, v2}, Lc/H6;->g(I)I

    move-result v2

    invoke-direct {v4, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11}, Lc/H6;->g(I)I

    move-result v2

    iput v2, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v10, v0, v9}, Lc/H6;->m(Ljava/lang/String;Ljava/lang/String;)Landroid/widget/Button;

    move-result-object v0

    invoke-virtual {v1, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x4

    move-object/from16 v2, p1

    invoke-virtual {v10, v2, v1, v0}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    if-eqz v3, :cond_3

    invoke-static {v13, v14}, Ljava/lang/Math;->rint(D)D

    move-result-wide v0

    goto :goto_3

    :cond_3
    const-wide v0, 0x412e848000000000L    # 1000000.0

    mul-double/2addr v13, v0

    invoke-static {v13, v14}, Ljava/lang/Math;->rint(D)D

    move-result-wide v13

    div-double v0, v13, v0

    :goto_3
    new-array v8, v5, [D

    aput-wide v0, v8, v7

    new-instance v11, Lc/s6;

    move-object v0, v11

    move-object/from16 v1, p0

    move-object v2, v12

    move/from16 v3, p10

    move-wide/from16 v4, p6

    move-wide/from16 v6, p8

    move-object/from16 v9, p3

    invoke-direct/range {v0 .. v9}, Lc/s6;-><init>(Lc/H6;Landroid/widget/EditText;ZDD[DLjava/lang/String;)V

    new-instance v0, Lc/G6;

    invoke-direct {v0, v12, v11, v10}, Lc/G6;-><init>(Landroid/widget/EditText;Lc/s6;Lc/H6;)V

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    new-instance v0, Lc/t6;

    invoke-direct {v0, v10, v11}, Lc/t6;-><init>(Lc/H6;Lc/s6;)V

    invoke-virtual {v12, v0}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    new-instance v0, Lc/u6;

    invoke-direct {v0, v12, v11, v10}, Lc/u6;-><init>(Landroid/widget/EditText;Lc/s6;Lc/H6;)V

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 3

    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    iget-object v0, v0, Lc/T5;->B1:Ljava/util/HashSet;

    iget-object v1, p0, Lc/H6;->p0:Lc/q6;

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lc/H6;->v:Lc/z5;

    iget-object v2, v0, Lc/z5;->i:Ljava/util/HashSet;

    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v1, p0, Lc/H6;->m0:Landroid/os/Handler;

    iget-object v2, p0, Lc/H6;->q0:Lc/e1;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v1, p0, Lc/H6;->r0:Lc/q6;

    invoke-virtual {p0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    iget-object v1, v0, Lc/z5;->a:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    iget-boolean v1, v0, Lc/z5;->d:Z

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/z5;->d:Z

    const-string v1, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043a\u0430\u0442\u0430\u043b\u043e\u0433\u0430\u2026"

    iput-object v1, v0, Lc/z5;->b:Ljava/lang/String;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, v0, Lc/z5;->i:Ljava/util/HashSet;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Runnable;

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_1
    new-instance v1, Lc/w5;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lc/w5;-><init>(Lc/z5;I)V

    iget-object v0, v0, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_2
    :goto_1
    new-instance v0, Lc/q6;

    const/16 v1, 0xa

    invoke-direct {v0, p0, v1}, Lc/q6;-><init>(Lc/H6;I)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 3

    iget-object v0, p0, Lc/H6;->n0:Lc/u5;

    invoke-virtual {v0}, Lc/u5;->a()V

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    iget-object v1, v0, Lc/T5;->B1:Ljava/util/HashSet;

    iget-object v2, p0, Lc/H6;->p0:Lc/q6;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget-object v1, p0, Lc/H6;->v:Lc/z5;

    iget-object v1, v1, Lc/z5;->i:Ljava/util/HashSet;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget v1, p0, Lc/H6;->c0:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lc/H6;->c0:I

    iget-object v1, p0, Lc/H6;->m0:Landroid/os/Handler;

    iget-object v2, p0, Lc/H6;->q0:Lc/e1;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/H6;->r0:Lc/q6;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v0, p0}, Lc/T5;->n0(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lc/T5;->L0()V

    invoke-super {p0}, Landroid/widget/ScrollView;->onDetachedFromWindow()V

    return-void
.end method

.method public final onMeasure(II)V
    .locals 10

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    const/16 v1, 0x2f8

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    move v0, v3

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    iget v1, p0, Lc/H6;->i:I

    if-eq v1, v0, :cond_7

    iput v0, p0, Lc/H6;->i:I

    const/4 v1, 0x0

    if-ne v0, v3, :cond_1

    move v2, v1

    :cond_1
    iget-object v4, p0, Lc/H6;->f:Lc/u8;

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x30

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    if-ne v0, v3, :cond_2

    move v5, v1

    goto :goto_1

    :cond_2
    move v5, v4

    :goto_1
    const/4 v6, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    if-ne v0, v3, :cond_3

    move v8, v7

    goto :goto_2

    :cond_3
    move v8, v6

    :goto_2
    const/4 v9, -0x2

    invoke-direct {v2, v5, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    if-ne v0, v3, :cond_4

    goto :goto_3

    :cond_4
    move v1, v4

    :goto_3
    if-ne v0, v3, :cond_5

    move v6, v7

    :cond_5
    invoke-direct {v5, v1, v9, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v1, 0x10

    if-ne v0, v3, :cond_6

    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v0

    iput v0, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    goto :goto_4

    :cond_6
    invoke-virtual {p0, v1}, Lc/H6;->g(I)I

    move-result v0

    iput v0, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :goto_4
    iget-object v0, p0, Lc/H6;->g:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, p0, Lc/H6;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_7
    invoke-virtual {p0}, Lc/H6;->p()V

    invoke-super {p0, p1, p2}, Landroid/widget/ScrollView;->onMeasure(II)V

    return-void
.end method

.method public final onScrollChanged(IIII)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onScrollChanged(IIII)V

    iget-object p1, p0, Lc/H6;->m0:Landroid/os/Handler;

    iget-object p2, p0, Lc/H6;->r0:Lc/q6;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 p3, 0x12c

    invoke-virtual {p1, p2, p3, p4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final onSizeChanged(IIII)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ScrollView;->onSizeChanged(IIII)V

    iget-object p1, p0, Lc/H6;->m0:Landroid/os/Handler;

    iget-object p2, p0, Lc/H6;->r0:Lc/q6;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 p3, 0x12c

    invoke-virtual {p1, p2, p3, p4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final p()V
    .locals 9

    iget-object v0, p0, Lc/H6;->k:Lc/u8;

    if-nez v0, :cond_0

    return-void

    :cond_0
    const/4 v1, 0x0

    move v2, v1

    move v3, v2

    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v4

    const/4 v5, 0x1

    if-ge v2, v4, :cond_2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v4

    if-nez v4, :cond_1

    goto :goto_1

    :cond_1
    move v5, v1

    :goto_1
    or-int/2addr v3, v5

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    iget v2, p0, Lc/H6;->i:I

    const/4 v4, 0x2

    if-ne v2, v4, :cond_3

    if-nez v3, :cond_3

    move v2, v4

    goto :goto_2

    :cond_3
    move v2, v5

    :goto_2
    iget v3, p0, Lc/H6;->j:I

    if-ne v2, v3, :cond_4

    return-void

    :cond_4
    iput v2, p0, Lc/H6;->j:I

    if-ne v2, v4, :cond_5

    move v5, v1

    :cond_5
    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    move v3, v1

    :goto_3
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    if-ge v3, v5, :cond_a

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    if-ne v2, v4, :cond_6

    move v6, v1

    goto :goto_4

    :cond_6
    const/4 v6, -0x1

    :goto_4
    if-ne v2, v4, :cond_7

    const/high16 v7, 0x3f800000    # 1.0f

    goto :goto_5

    :cond_7
    const/4 v7, 0x0

    :goto_5
    const/4 v8, -0x2

    invoke-direct {v5, v6, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-lez v3, :cond_9

    const/16 v6, 0x10

    invoke-virtual {p0, v6}, Lc/H6;->g(I)I

    move-result v6

    if-ne v2, v4, :cond_8

    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    goto :goto_6

    :cond_8
    iput v6, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_9
    :goto_6
    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v6, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_a
    return-void
.end method

.method public final q()V
    .locals 10

    iget-object v0, p0, Lc/H6;->a0:Lc/x5;

    const-string v1, ""

    const-string v2, "profile_id"

    iget-object v3, p0, Lc/H6;->c:Lc/T5;

    if-nez v0, :cond_0

    iget-object v0, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/x5;->a:Ljava/lang/String;

    :goto_0
    iget-object v4, p0, Lc/H6;->R:Landroid/widget/Spinner;

    invoke-virtual {v4}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p0, Lc/H6;->V:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    iget-object v6, p0, Lc/H6;->v:Lc/z5;

    iget-object v6, v6, Lc/z5;->a:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_1
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/x5;

    iget-object v8, v7, Lc/x5;->f:Ljava/util/ArrayList;

    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_2
    new-instance v6, Lc/v;

    const/4 v7, 0x6

    invoke-direct {v6, v7}, Lc/v;-><init>(I)V

    invoke-static {v6}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/x5;

    iget-object v8, v8, Lc/x5;->b:Ljava/lang/String;

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_3
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_5

    invoke-virtual {p0}, Lc/H6;->v()Z

    move-result v7

    if-eqz v7, :cond_4

    iget-object v7, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v8, "profile_name"

    const-string v9, "\u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c"

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_3

    :cond_4
    const-string v7, "\u0423\u043d\u0438\u0432\u0435\u0440\u0441\u0430\u043b\u044c\u043d\u044b\u0435 \u043e\u0441\u043d\u043e\u0432\u043d\u044b\u0435 \u0434\u0430\u0442\u0447\u0438\u043a\u0438"

    :goto_3
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    iget-object v7, p0, Lc/H6;->S:Landroid/widget/Spinner;

    invoke-virtual {p0, v7, v6}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    const/4 v6, 0x0

    move v8, v6

    :goto_4
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v8, v9, :cond_7

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/x5;

    iget-object v9, v9, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v9, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_6

    goto :goto_5

    :cond_6
    add-int/lit8 v8, v8, 0x1

    goto :goto_4

    :cond_7
    move v8, v6

    :goto_5
    invoke-virtual {v7, v8}, Landroid/widget/AdapterView;->setSelection(I)V

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_8

    const/4 v0, 0x0

    goto :goto_6

    :cond_8
    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/x5;

    :goto_6
    iget-object v5, p0, Lc/H6;->a0:Lc/x5;

    if-eq v5, v0, :cond_c

    if-eqz v5, :cond_9

    if-eqz v0, :cond_9

    iget-object v5, v5, Lc/x5;->a:Ljava/lang/String;

    iget-object v7, v0, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_9

    goto :goto_9

    :cond_9
    iget v5, p0, Lc/H6;->c0:I

    add-int/lit8 v5, v5, 0x1

    iput v5, p0, Lc/H6;->c0:I

    iput-boolean v6, p0, Lc/H6;->e0:Z

    if-eqz v0, :cond_b

    iget-object v5, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v5, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_7

    :cond_a
    iget v1, v0, Lc/x5;->g:I

    goto :goto_8

    :cond_b
    :goto_7
    invoke-virtual {v3}, Lc/T5;->g0()I

    move-result v1

    :goto_8
    iput v1, p0, Lc/H6;->b0:I

    :cond_c
    :goto_9
    iput-object v0, p0, Lc/H6;->a0:Lc/x5;

    iget v1, p0, Lc/H6;->b0:I

    invoke-virtual {p0, v1}, Lc/H6;->w(I)V

    invoke-virtual {p0}, Lc/H6;->s()V

    invoke-virtual {p0}, Lc/H6;->v()Z

    move-result v1

    if-eqz v1, :cond_d

    return-void

    :cond_d
    const-string v1, "profile_brand"

    if-eqz v0, :cond_f

    const-string v0, "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 OBD-II"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    goto :goto_a

    :cond_e
    iget-object v0, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v1, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_b

    :cond_f
    :goto_a
    iget-object v0, v3, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_b
    return-void
.end method

.method public final r(Lc/v6;)V
    .locals 5

    iget-boolean v0, p0, Lc/H6;->e0:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget v0, p0, Lc/H6;->b0:I

    invoke-static {v0}, Lc/j6;->c(I)Z

    move-result v0

    iget-object v1, p0, Lc/H6;->c:Lc/T5;

    if-nez v0, :cond_1

    const-string p1, "\u042d\u0442\u043e\u0442 \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u043f\u043e\u043a\u0430 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f"

    iput-object p1, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    return-void

    :cond_1
    iget v0, p0, Lc/H6;->c0:I

    const/4 v2, 0x1

    add-int/2addr v0, v2

    iput v0, p0, Lc/H6;->c0:I

    iget v3, p0, Lc/H6;->b0:I

    iget-object v4, p0, Lc/H6;->a0:Lc/x5;

    if-nez v4, :cond_5

    invoke-virtual {p0}, Lc/H6;->v()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {v1}, Lc/T5;->E()V

    const/4 v0, 0x0

    iput-object v0, v1, Lc/T5;->h:Lc/j6;

    iget-object v2, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v2, v0}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object v0

    iput-object v0, v1, Lc/T5;->g:Lc/j6;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "profile_id"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "profile_sha"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "profile_name"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "checked_widget_profile_sha"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "disabled_sensor_ids"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "protocol"

    const/4 v4, 0x0

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v1}, Lc/T5;->H()V

    const-string v0, "\u0411\u0430\u0437\u043e\u0432\u044b\u0439 OBD-II"

    iput-object v0, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    :cond_2
    invoke-virtual {v1, v3}, Lc/T5;->h0(I)V

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Lc/v6;->run()V

    goto :goto_1

    :cond_3
    invoke-virtual {p0}, Lc/H6;->v()Z

    move-result p1

    if-eqz p1, :cond_4

    const-string p1, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b"

    goto :goto_0

    :cond_4
    const-string p1, "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    :goto_0
    iput-object p1, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    :goto_1
    invoke-virtual {p0}, Lc/H6;->s()V

    return-void

    :cond_5
    iput-boolean v2, p0, Lc/H6;->e0:Z

    invoke-virtual {p0}, Lc/H6;->t()V

    new-instance v1, Lc/y6;

    invoke-direct {v1, p0, v0, v3, p1}, Lc/y6;-><init>(Lc/H6;IILc/v6;)V

    iget-object p1, p0, Lc/H6;->v:Lc/z5;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lc/Z;

    const/16 v2, 0x10

    invoke-direct {v0, p1, v4, v1, v2}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object p1, p1, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public final s()V
    .locals 7

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    iget-object v0, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "profile_name"

    const-string v2, "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 OBD-II"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d: "

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lc/H6;->a0:Lc/x5;

    const-string v4, ""

    const-string v5, "\n"

    if-nez v0, :cond_0

    move-object v0, v4

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v6, p0, Lc/H6;->a0:Lc/x5;

    iget-object v6, v6, Lc/x5;->c:Ljava/lang/String;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "\u041e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0439 \u0432 \u043f\u0430\u043a\u0435\u0442\u0435: "

    invoke-static {v2, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v6, p0, Lc/H6;->a0:Lc/x5;

    iget v6, v6, Lc/x5;->i:I

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, p0, Lc/H6;->b0:I

    invoke-static {v0}, Lc/j6;->c(I)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_1

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v4, "\u041f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u044d\u0442\u043e\u0433\u043e \u043f\u0440\u043e\u0444\u0438\u043b\u044f \u043f\u043e\u043a\u0430 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f"

    invoke-static {v2, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_1
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/H6;->o:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Landroid/text/SpannableString;

    invoke-virtual {v1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-direct {v0, v4}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    new-instance v4, Landroid/text/style/ForegroundColorSpan;

    const v5, -0x994496

    invoke-direct {v4, v5}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x21

    const/4 v5, 0x0

    invoke-virtual {v0, v4, v5, v2, v3}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final t()V
    .locals 19

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->z()I

    move-result v2

    const/4 v3, 0x1

    iput-boolean v3, v0, Lc/H6;->P:Z

    iget-object v4, v0, Lc/H6;->H:Ljava/util/EnumMap;

    invoke-virtual {v4}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x0

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Map$Entry;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/F0;

    invoke-virtual {v7}, Lc/F0;->a()I

    move-result v7

    and-int/2addr v7, v2

    if-eqz v7, :cond_1

    move v6, v3

    :cond_1
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/Switch;

    invoke-virtual {v7}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v7

    if-eq v7, v6, :cond_0

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/widget/Switch;

    invoke-virtual {v5, v6}, Landroid/widget/Switch;->setChecked(Z)V

    goto :goto_0

    :cond_2
    iget-object v2, v0, Lc/H6;->c:Lc/T5;

    iget-object v4, v2, Lc/T5;->g:Lc/j6;

    if-eqz v4, :cond_3

    move v5, v3

    goto :goto_1

    :cond_3
    move v5, v6

    :goto_1
    if-eqz v5, :cond_6

    iget-object v4, v4, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/i6;

    iget-boolean v5, v5, Lc/i6;->v:Z

    if-eqz v5, :cond_4

    move v5, v3

    goto :goto_2

    :cond_5
    move v5, v6

    :cond_6
    :goto_2
    iget-object v4, v0, Lc/H6;->I:Ljava/util/EnumMap;

    invoke-virtual {v4}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/F0;

    invoke-virtual {v0, v9}, Lc/H6;->z(Lc/F0;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v8, v9}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/Button;

    invoke-virtual {v7, v5}, Landroid/view/View;->setEnabled(Z)V

    goto :goto_3

    :cond_7
    iput-boolean v6, v0, Lc/H6;->P:Z

    invoke-virtual {v1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2}, Lc/T5;->f1()Ljava/lang/String;

    move-result-object v4

    iget-object v5, v0, Lc/H6;->M:Lc/j6;

    iget-object v7, v2, Lc/T5;->g:Lc/j6;

    if-eq v5, v7, :cond_8

    move v5, v3

    goto :goto_4

    :cond_8
    move v5, v6

    :goto_4
    iget-object v7, v0, Lc/H6;->J:Ljava/util/ArrayList;

    if-nez v5, :cond_9

    iget-object v8, v0, Lc/H6;->O:Ljava/lang/String;

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_b

    :cond_9
    iget-object v8, v2, Lc/T5;->g:Lc/j6;

    iput-object v8, v0, Lc/H6;->M:Lc/j6;

    iput-object v1, v0, Lc/H6;->O:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    iget-object v1, v2, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_a

    iget-object v1, v1, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_a
    invoke-virtual/range {p0 .. p0}, Lc/H6;->i()V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->A()V

    :cond_b
    const-string v1, " \u00b7 "

    iget-object v8, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    if-nez v5, :cond_c

    iget-object v5, v0, Lc/H6;->N:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_e

    :cond_c
    iput-object v4, v0, Lc/H6;->N:Ljava/lang/String;

    iget-object v4, v2, Lc/T5;->g:Lc/j6;

    if-nez v4, :cond_d

    const-string v4, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u0435 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f."

    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_5

    :cond_d
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u0414\u0430\u0442\u0447\u0438\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f"

    invoke-static {v8, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ": "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "\u0412\u044b\u0431\u0440\u0430\u043d\u043e"

    invoke-static {v8, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Set;->size()I

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_5
    iget-object v5, v0, Lc/H6;->D:Landroid/widget/TextView;

    invoke-static {v5, v4}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    :cond_e
    iget-boolean v4, v0, Lc/H6;->Q:Z

    if-nez v4, :cond_f

    iget-object v4, v0, Lc/H6;->L:Lc/C6;

    invoke-virtual {v4}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_f
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_10

    move v7, v6

    goto :goto_6

    :cond_10
    const/16 v7, 0x8

    :goto_6
    iget-object v9, v0, Lc/H6;->E:Landroid/widget/EditText;

    invoke-virtual {v9, v7}, Landroid/view/View;->setVisibility(I)V

    if-nez v4, :cond_11

    move v7, v6

    goto :goto_7

    :cond_11
    const/16 v7, 0x8

    :goto_7
    iget-object v9, v0, Lc/H6;->F:Lc/B6;

    invoke-virtual {v9, v7}, Landroid/view/View;->setVisibility(I)V

    if-nez v4, :cond_12

    move v4, v6

    goto :goto_8

    :cond_12
    const/16 v4, 0x8

    :goto_8
    iget-object v7, v0, Lc/H6;->G:Landroid/widget/Button;

    invoke-virtual {v7, v4}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v2}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->isEmpty()Z

    move-result v4

    xor-int/2addr v4, v3

    invoke-virtual {v7, v4}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v2}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v4

    const-string v7, "wifi"

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_13

    move v4, v6

    goto :goto_9

    :cond_13
    const/16 v4, 0x8

    :goto_9
    iget-object v7, v0, Lc/H6;->k0:Landroid/widget/EditText;

    invoke-virtual {v7, v4}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v2}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v4

    const-string v7, "usb"

    invoke-virtual {v4, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    move v4, v6

    goto :goto_a

    :cond_14
    const/16 v4, 0x8

    :goto_a
    iget-object v7, v0, Lc/H6;->l0:Landroid/widget/Spinner;

    invoke-virtual {v7, v4}, Landroid/view/View;->setVisibility(I)V

    iget-boolean v4, v0, Lc/H6;->e0:Z

    const/4 v7, 0x3

    if-eqz v4, :cond_15

    const-string v4, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0438 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u043f\u0440\u043e\u0444\u0438\u043b\u044f\u2026"

    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    :cond_15
    iget-object v4, v2, Lc/T5;->C1:Ljava/lang/String;

    const-string v9, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u042d\u0411\u0423 \u00b7 \u043f\u043e\u043f\u044b\u0442\u043a\u0430 "

    invoke-virtual {v4, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_16

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x17

    invoke-virtual {v4, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const-string v9, " \u00b7 \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b "

    invoke-static {v8, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v9, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto/16 :goto_d

    :cond_16
    const-string v14, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043e\u0442\u043a\u043b\u043e\u043d\u0438\u043b \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0443 "

    const-string v15, "\u0421\u0432\u044f\u0437\u044c \u0441 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u043c \u043f\u043e\u0442\u0435\u0440\u044f\u043d\u0430 ("

    const-string v9, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0432\u044b\u0431\u0440\u0430\u043d \u00b7 "

    const-string v10, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u00b7 "

    const-string v11, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u043a \u042d\u0411\u0423 \u00b7 "

    const-string v12, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043a "

    const-string v13, "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u043e\u0438\u0441\u043a\u0430: "

    filled-new-array/range {v9 .. v15}, [Ljava/lang/String;

    move-result-object v9

    move v10, v6

    :goto_b
    const/4 v11, 0x7

    if-ge v10, v11, :cond_18

    aget-object v11, v9, v10

    invoke-virtual {v4, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_17

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v10

    invoke-virtual {v4, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_d

    :cond_17
    add-int/lit8 v10, v10, 0x1

    goto :goto_b

    :cond_18
    const-string v9, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c USB: "

    const-string v10, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f: "

    const-string v11, "\u042d\u0411\u0423 \u043e\u0442\u043a\u043b\u043e\u043d\u0438\u043b \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0443 \u043f\u0440\u043e\u0444\u0438\u043b\u044f "

    filled-new-array {v9, v10, v11}, [Ljava/lang/String;

    move-result-object v9

    move v10, v6

    :goto_c
    if-ge v10, v7, :cond_1a

    aget-object v11, v9, v10

    invoke-virtual {v4, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_19

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v8, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v10

    invoke-virtual {v4, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_d

    :cond_19
    add-int/lit8 v10, v10, 0x1

    goto :goto_c

    :cond_1a
    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_d
    iget-object v9, v0, Lc/H6;->l:Landroid/widget/TextView;

    invoke-static {v9, v4}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    iget-boolean v4, v2, Lc/T5;->G1:Z

    iget-object v9, v0, Lc/H6;->n0:Lc/u5;

    if-nez v4, :cond_1c

    iget-boolean v4, v0, Lc/H6;->e0:Z

    if-nez v4, :cond_1c

    iget-object v4, v9, Lc/u5;->c:Lc/Z;

    if-eqz v4, :cond_1b

    goto :goto_e

    :cond_1b
    move v4, v3

    goto :goto_f

    :cond_1c
    :goto_e
    move v4, v6

    :goto_f
    iget-object v10, v0, Lc/H6;->f0:Landroid/widget/Button;

    invoke-virtual {v10, v4}, Landroid/view/View;->setEnabled(Z)V

    iget-object v4, v2, Lc/T5;->E1:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1d

    const/16 v4, 0x8

    goto :goto_10

    :cond_1d
    move v4, v6

    :goto_10
    iget-object v10, v0, Lc/H6;->m:Landroid/widget/TextView;

    invoke-virtual {v10, v4}, Landroid/view/View;->setVisibility(I)V

    iget-object v4, v2, Lc/T5;->E1:Ljava/lang/String;

    const-string v11, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-static {v8, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v11, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    const-string v11, "\n\u041e\u0442\u0432\u0435\u0442:\n"

    invoke-static {v8, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v11, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    const-string v11, "\n[\u0431\u0435\u0437 > \u00b7 \u0442\u0430\u0439\u043c\u0430\u0443\u0442]"

    invoke-static {v8, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v4, v11, v12}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v4

    iget-object v11, v2, Lc/T5;->E1:Ljava/lang/String;

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    const-string v12, ""

    if-eqz v11, :cond_1e

    move-object v4, v12

    goto :goto_11

    :cond_1e
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v13, "\u041f\u043e\u0441\u043b\u0435\u0434\u043d\u044f\u044f \u043e\u0448\u0438\u0431\u043a\u0430 OBD\n"

    invoke-static {v8, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_11
    invoke-static {v10, v4}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    iget-object v4, v0, Lc/H6;->v:Lc/z5;

    iget-object v10, v4, Lc/z5;->b:Ljava/lang/String;

    invoke-static {v8, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    iget-object v11, v0, Lc/H6;->n:Landroid/widget/TextView;

    invoke-static {v11, v10}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    const-string v10, "address"

    iget-object v11, v2, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v11, v10, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    xor-int/2addr v13, v3

    iget-object v14, v0, Lc/H6;->g0:Landroid/widget/Button;

    invoke-virtual {v14, v13}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v14}, Landroid/view/View;->isEnabled()Z

    move-result v13

    if-eqz v13, :cond_1f

    const/high16 v13, 0x3f800000    # 1.0f

    goto :goto_12

    :cond_1f
    const v13, 0x3ecccccd    # 0.4f

    :goto_12
    invoke-virtual {v14, v13}, Landroid/view/View;->setAlpha(F)V

    const-string v13, "ble"

    invoke-virtual {v2}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    const-string v14, "spp"

    if-nez v13, :cond_21

    invoke-virtual {v2}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v14, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_20

    goto :goto_13

    :cond_20
    move v13, v6

    goto :goto_14

    :cond_21
    :goto_13
    move v13, v3

    :goto_14
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/high16 v16, -0x80000000

    :try_start_0
    iget-object v7, v9, Lc/u5;->a:Lru/drivedeck/launcher/MainActivity;

    const-class v15, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {v7, v15}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/bluetooth/BluetoothManager;

    if-nez v7, :cond_22

    const/4 v7, 0x0

    goto :goto_15

    :cond_22
    invoke-virtual {v7}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v7

    :goto_15
    if-nez v7, :cond_23

    goto :goto_16

    :cond_23
    invoke-virtual {v7}, Landroid/bluetooth/BluetoothAdapter;->getState()I

    move-result v16
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_16
    move/from16 v7, v16

    if-eqz v13, :cond_24

    move v15, v6

    goto :goto_17

    :cond_24
    const/16 v15, 0x8

    :goto_17
    iget-object v5, v0, Lc/H6;->j0:Landroid/widget/TextView;

    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Bluetooth \u0430\u043a\u0441\u0435\u0441\u0441\u0443\u0430\u0440\u043e\u0432 / OBD \u00b7 "

    invoke-static {v8, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xd

    const/16 v6, 0xc

    if-ne v7, v6, :cond_25

    const-string v18, "\u0432\u043a\u043b\u044e\u0447\u0451\u043d"

    move-object/from16 v6, v18

    goto :goto_18

    :cond_25
    const/16 v6, 0xa

    if-ne v7, v6, :cond_26

    const-string v6, "\u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d"

    goto :goto_18

    :cond_26
    const/16 v6, 0xb

    if-ne v7, v6, :cond_27

    const-string v6, "\u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f"

    goto :goto_18

    :cond_27
    if-ne v7, v3, :cond_28

    const-string v6, "\u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f"

    goto :goto_18

    :cond_28
    const-string v6, "\u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0438\u043b\u0438 \u043d\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f"

    :goto_18
    invoke-static {v8, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    if-eqz v13, :cond_29

    const/16 v5, 0xc

    if-eq v7, v5, :cond_29

    const/4 v5, 0x0

    goto :goto_19

    :cond_29
    const/16 v5, 0x8

    :goto_19
    iget-object v6, v0, Lc/H6;->i0:Landroid/widget/Button;

    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    iget-object v5, v9, Lc/u5;->c:Lc/Z;

    if-eqz v5, :cond_2a

    goto :goto_1a

    :cond_2a
    iget-boolean v5, v0, Lc/H6;->e0:Z

    if-nez v5, :cond_2b

    const/4 v5, 0x1

    goto :goto_1b

    :cond_2b
    :goto_1a
    const/4 v5, 0x0

    :goto_1b
    invoke-virtual {v6, v5}, Landroid/view/View;->setEnabled(Z)V

    if-nez v13, :cond_2d

    iget-boolean v5, v2, Lc/T5;->I1:Z

    if-eqz v5, :cond_2c

    goto :goto_1c

    :cond_2c
    const/16 v5, 0x8

    goto :goto_1d

    :cond_2d
    :goto_1c
    const/4 v5, 0x0

    :goto_1d
    iget-object v6, v0, Lc/H6;->h0:Landroid/widget/Button;

    invoke-virtual {v6, v5}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    const-string v6, "\n"

    if-eqz v5, :cond_2e

    const-string v5, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d"

    invoke-static {v8, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_1e

    :cond_2e
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u0412\u044b\u0431\u0440\u0430\u043d: "

    invoke-static {v8, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "name"

    invoke-interface {v11, v7, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :goto_1e
    iget-object v7, v0, Lc/H6;->q:Landroid/widget/TextView;

    invoke-static {v7, v5}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    invoke-virtual {v2}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2f

    const/4 v5, 0x0

    goto :goto_1f

    :cond_2f
    const/16 v5, 0x8

    :goto_1f
    iget-object v7, v0, Lc/H6;->r:Landroid/widget/TextView;

    invoke-virtual {v7, v5}, Landroid/view/View;->setVisibility(I)V

    const-string v5, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u0441\u043e\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 Android."

    invoke-static {v8, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v4, Lc/z5;->c:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ":"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v4, Lc/z5;->a:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v7, v0, Lc/H6;->d0:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_36

    iput-object v5, v0, Lc/H6;->d0:Ljava/lang/String;

    new-instance v5, Ljava/util/TreeSet;

    invoke-direct {v5}, Ljava/util/TreeSet;-><init>()V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_20
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_30

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/x5;

    iget-object v9, v9, Lc/x5;->f:Ljava/util/ArrayList;

    invoke-virtual {v5, v9}, Ljava/util/TreeSet;->addAll(Ljava/util/Collection;)Z

    goto :goto_20

    :cond_30
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const-string v9, "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0439 OBD-II"

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const-string v5, "profile_id"

    invoke-interface {v11, v5, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v9, "profile_brand"

    invoke-interface {v11, v9, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_31
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_33

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/x5;

    iget-object v11, v10, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v11, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_31

    iget-object v10, v10, Lc/x5;->f:Ljava/util/ArrayList;

    invoke-virtual {v10}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_31

    if-eqz v9, :cond_32

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_32

    goto :goto_21

    :cond_32
    const/4 v4, 0x0

    invoke-virtual {v10, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    goto :goto_21

    :cond_33
    move-object v9, v12

    :goto_21
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_34

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_34

    const-string v9, "\u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c"

    const/4 v4, 0x1

    invoke-virtual {v7, v4, v9}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    :cond_34
    iget-object v4, v0, Lc/H6;->R:Landroid/widget/Spinner;

    invoke-virtual {v0, v4, v7}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    invoke-virtual {v7, v9}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v5

    if-gez v5, :cond_35

    const/4 v5, 0x0

    :cond_35
    invoke-virtual {v4, v5}, Landroid/widget/AdapterView;->setSelection(I)V

    invoke-virtual/range {p0 .. p0}, Lc/H6;->q()V

    :cond_36
    iget-object v4, v2, Lc/T5;->A1:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    iget-object v7, v0, Lc/H6;->o0:Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_37

    iput-object v5, v0, Lc/H6;->o0:Ljava/lang/String;

    iget-object v5, v0, Lc/H6;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_22
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_37

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    new-instance v10, Lc/H;

    const/16 v11, 0x1b

    invoke-direct {v10, v0, v7, v11}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v7, 0x0

    invoke-virtual {v0, v9, v7, v10}, Lc/H6;->b(Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v9

    const/16 v7, 0x8

    invoke-virtual {v0, v5, v9, v7}, Lc/H6;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    goto :goto_22

    :cond_37
    iget-object v1, v0, Lc/H6;->u:Lc/G0;

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lc/G0;->j(Z)Z

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v4

    array-length v5, v4

    const/4 v7, 0x0

    :goto_23
    if-ge v7, v5, :cond_3e

    aget-object v9, v4, v7

    iget v10, v9, Lc/F0;->d:I

    if-ltz v10, :cond_3c

    invoke-virtual {v2, v10}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v10

    if-nez v10, :cond_3c

    iget-boolean v10, v2, Lc/T5;->H1:Z

    if-eqz v10, :cond_3c

    const/16 v10, 0x42

    iget v11, v9, Lc/F0;->d:I

    if-ne v11, v10, :cond_38

    goto :goto_25

    :cond_38
    iget-object v10, v2, Lc/T5;->d:Ljava/util/HashSet;

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v10, v13}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_39

    goto :goto_25

    :cond_39
    iget-object v10, v2, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v10

    :cond_3a
    :goto_24
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_3b

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lc/i6;

    iget v14, v13, Lc/i6;->j:I

    invoke-static {v11}, Lc/T5;->w0(I)I

    move-result v15

    if-ne v14, v15, :cond_3a

    iget-object v14, v2, Lc/T5;->h1:Ljava/util/HashSet;

    iget-object v13, v13, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v14, v13}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_3c

    goto :goto_24

    :cond_3b
    const/4 v10, 0x1

    goto :goto_26

    :cond_3c
    :goto_25
    const/4 v10, 0x0

    :goto_26
    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v11

    iget-object v13, v1, Lc/G0;->g:[Ljava/lang/String;

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v14

    aget-object v13, v13, v14

    if-eqz v10, :cond_3d

    const-string v10, "\u042d\u0411\u0423 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442"

    invoke-static {v8, v10}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_27

    :cond_3d
    const/4 v10, 0x0

    :goto_27
    iget-object v14, v1, Lc/G0;->h:[Ljava/lang/String;

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    aget-object v9, v14, v9

    iget-object v14, v0, Lc/H6;->s:Lc/o6;

    invoke-virtual {v14, v11, v13, v10, v9}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v7, v7, 0x1

    goto :goto_23

    :cond_3e
    invoke-virtual/range {p0 .. p0}, Lc/H6;->u()V

    invoke-virtual {v2}, Lc/T5;->S()Ljava/lang/Double;

    move-result-object v1

    invoke-virtual {v2, v3}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v3

    invoke-virtual {v2}, Lc/T5;->R0()Ljava/lang/Double;

    move-result-object v4

    iget-boolean v5, v2, Lc/T5;->m2:Z

    if-eqz v5, :cond_3f

    iget-wide v9, v2, Lc/T5;->j2:D

    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    goto :goto_28

    :cond_3f
    const/4 v5, 0x0

    :goto_28
    iget-boolean v7, v2, Lc/T5;->o2:Z

    if-nez v7, :cond_41

    iget-boolean v7, v2, Lc/T5;->p2:Z

    if-eqz v7, :cond_40

    goto :goto_29

    :cond_40
    move-object v7, v12

    goto :goto_2a

    :cond_41
    :goto_29
    const-string v7, "\u2248"

    :goto_2a
    const/4 v9, 0x2

    const-string v10, "\u2014"

    if-nez v1, :cond_42

    move-object v11, v10

    goto :goto_2b

    :cond_42
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v13

    invoke-static {v13, v14, v9}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v11

    :goto_2b
    iget-object v13, v0, Lc/H6;->t:Lc/o6;

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-virtual {v13, v14, v11, v15, v15}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    if-eqz v1, :cond_44

    if-eqz v3, :cond_44

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v14

    const-wide/high16 v17, 0x4014000000000000L    # 5.0

    cmpg-double v11, v14, v17

    if-gez v11, :cond_43

    goto :goto_2d

    :cond_43
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v14

    const-wide/high16 v17, 0x4059000000000000L    # 100.0

    mul-double v14, v14, v17

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v17

    div-double v14, v14, v17

    invoke-static {v14, v15, v9}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v3

    :goto_2c
    const/4 v11, 0x1

    const/4 v14, 0x0

    goto :goto_2e

    :cond_44
    :goto_2d
    move-object v3, v10

    goto :goto_2c

    :goto_2e
    invoke-virtual {v13, v11, v3, v14, v14}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    if-nez v4, :cond_45

    move-object v3, v10

    goto :goto_2f

    :cond_45
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    invoke-static {v3, v4, v11}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_2f
    invoke-virtual {v13, v9, v3, v14, v14}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    if-nez v5, :cond_46

    :goto_30
    const/4 v3, 0x3

    goto :goto_31

    :cond_46
    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    invoke-static {v3, v4, v9}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    goto :goto_30

    :goto_31
    invoke-virtual {v13, v3, v10, v14, v14}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v1, :cond_47

    goto :goto_32

    :cond_47
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lc/T5;->T()Ljava/lang/String;

    move-result-object v2

    invoke-static {v8, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    :goto_32
    invoke-virtual {v3, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\u0423\u0447\u0442\u0435\u043d\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u0443\u0447\u0430\u0441\u0442\u043a\u0438 \u0441 \u0434\u0430\u043d\u043d\u044b\u043c\u0438."

    invoke-static {v8, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget-object v2, v0, Lc/H6;->p:Landroid/widget/TextView;

    invoke-static {v2, v1}, Lc/H6;->x(Landroid/widget/TextView;Ljava/lang/String;)V

    return-void
.end method

.method public final u()V
    .locals 14

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    invoke-virtual {v0}, Lc/T5;->f1()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lc/H6;->A:Lc/j6;

    iget-object v4, v0, Lc/T5;->g:Lc/j6;

    iget-object v5, p0, Lc/H6;->z:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-ne v3, v4, :cond_0

    iget-object v3, p0, Lc/H6;->B:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    iget-object v3, p0, Lc/H6;->C:Ljava/lang/String;

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5

    :cond_0
    iget-object v3, v0, Lc/T5;->g:Lc/j6;

    iput-object v3, p0, Lc/H6;->A:Lc/j6;

    iput-object v1, p0, Lc/H6;->B:Ljava/lang/String;

    iput-object v2, p0, Lc/H6;->C:Ljava/lang/String;

    iget-object v1, p0, Lc/H6;->x:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iput-object v7, p0, Lc/H6;->y:Lc/o6;

    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_3

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v3

    new-array v4, v3, [Ljava/lang/String;

    new-array v12, v3, [Ljava/lang/String;

    new-array v13, v3, [I

    move v8, v6

    :goto_0
    if-ge v8, v3, :cond_1

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/i6;

    invoke-virtual {v9, v2}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    aput-object v10, v4, v8

    iget-object v10, v9, Lc/i6;->e:Ljava/lang/String;

    aput-object v10, v12, v8

    iget-object v9, v9, Lc/i6;->c:Ljava/lang/String;

    invoke-static {v9}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v9

    aput v9, v13, v8

    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_1
    new-instance v2, Lc/o6;

    iget-object v9, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v10, p0, Lc/H6;->b:Lc/r4;

    move-object v8, v2

    move-object v11, v4

    invoke-direct/range {v8 .. v13}, Lc/o6;-><init>(Landroid/app/Activity;Lc/r4;[Ljava/lang/String;[Ljava/lang/String;[I)V

    iput-object v2, p0, Lc/H6;->y:Lc/o6;

    iget-object v2, v0, Lc/T5;->g:Lc/j6;

    move v8, v6

    :goto_1
    if-ge v8, v3, :cond_2

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/i6;

    iget-object v9, v9, Lc/i6;->a:Ljava/lang/String;

    new-instance v10, Landroid/widget/Switch;

    iget-object v11, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v10, v11}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    iget-object v11, p0, Lc/H6;->b:Lc/r4;

    invoke-static {v10, v11}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    aget-object v11, v4, v8

    invoke-virtual {v10, v11}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/Switch;->setChecked(Z)V

    new-instance v11, Lc/w0;

    const/4 v12, 0x3

    invoke-direct {v11, p0, v2, v9, v12}, Lc/w0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v11}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object v9, p0, Lc/H6;->y:Lc/o6;

    invoke-virtual {v9, v8, v10, v7}, Lc/o6;->a(ILandroid/widget/Switch;Landroid/widget/Button;)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    :cond_2
    iget-object v2, p0, Lc/H6;->y:Lc/o6;

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    const/4 v8, -0x2

    invoke-direct {v3, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_4

    const/16 v2, 0x8

    goto :goto_2

    :cond_4
    move v2, v6

    :goto_2
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    :cond_5
    iget-object v1, p0, Lc/H6;->y:Lc/o6;

    if-nez v1, :cond_6

    return-void

    :cond_6
    :goto_3
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v6, v1, :cond_b

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    iget-object v2, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v2

    if-nez v2, :cond_7

    move-object v3, v7

    goto :goto_4

    :cond_7
    iget-wide v3, v2, Lc/S5;->a:D

    invoke-virtual {v1, v3, v4}, Lc/i6;->f(D)Ljava/lang/String;

    move-result-object v3

    :goto_4
    if-nez v2, :cond_8

    const-string v3, "\u2014"

    goto :goto_5

    :cond_8
    if-nez v3, :cond_9

    iget-wide v3, v2, Lc/S5;->a:D

    const/4 v8, 0x2

    invoke-static {v3, v4, v8}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v3

    :cond_9
    :goto_5
    if-nez v2, :cond_a

    iget v1, v1, Lc/i6;->o:I

    goto :goto_6

    :cond_a
    invoke-virtual {v2, v1}, Lc/S5;->a(Lc/i6;)I

    move-result v1

    :goto_6
    invoke-static {v1}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lc/H6;->y:Lc/o6;

    invoke-virtual {v2, v6, v3, v7, v1}, Lc/o6;->d(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_b
    return-void
.end method

.method public final v()Z
    .locals 3

    iget-object v0, p0, Lc/H6;->R:Landroid/widget/Spinner;

    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    iget-object v0, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "profile_id"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final w(I)V
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    sget-object v1, Lc/H6;->s0:[Ljava/lang/String;

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v1, p0, Lc/H6;->W:[I

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    array-length v4, v1

    if-ge v3, v4, :cond_1

    aget v4, v1, v3

    if-ne v4, p1, :cond_0

    move v2, v3

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    array-length v1, v1

    if-ne v2, v1, :cond_3

    invoke-static {p1}, Lc/j6;->c(I)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string v1, "\u041f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u043f\u0440\u043e\u0444\u0438\u043b\u044f \u00b7 "

    invoke-static {v1, p1}, Lcom/hoho/android/usbserial/driver/a;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :cond_2
    const-string p1, "\u041f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u043f\u0440\u043e\u0444\u0438\u043b\u044f \u00b7 \u043f\u043e\u043a\u0430 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    :goto_1
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    iget-object p1, p0, Lc/H6;->T:Landroid/widget/Spinner;

    invoke-virtual {p0, p1, v0}, Lc/H6;->e(Landroid/widget/Spinner;Ljava/util/List;)V

    invoke-virtual {p1, v2}, Landroid/widget/AdapterView;->setSelection(I)V

    return-void
.end method

.method public final y(I)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 p1, 0x10

    invoke-virtual {p0, p1}, Lc/H6;->g(I)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public final z(Lc/F0;)Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lc/H6;->c:Lc/T5;

    iget p1, p1, Lc/F0;->d:I

    invoke-virtual {v0, p1}, Lc/T5;->a1(I)Lc/i6;

    move-result-object p1

    iget-object v0, p0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    if-nez p1, :cond_0

    const-string p1, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a: \u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    invoke-static {v0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_0
    iget-object v1, p0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, Lc/i6;->e:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p1, ""

    goto :goto_0

    :cond_1
    const-string v0, " \u00b7 "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method
