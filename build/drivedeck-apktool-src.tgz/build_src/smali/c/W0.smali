.class public final synthetic Lc/W0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/n1;

.field public final synthetic c:Lc/s0;

.field public final synthetic d:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Lc/n1;Lc/s0;Ljava/lang/Runnable;I)V
    .locals 0

    iput p4, p0, Lc/W0;->a:I

    iput-object p1, p0, Lc/W0;->b:Lc/n1;

    iput-object p2, p0, Lc/W0;->c:Lc/s0;

    iput-object p3, p0, Lc/W0;->d:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 2

    iget v0, p0, Lc/W0;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/W0;->b:Lc/n1;

    iget-object v1, p0, Lc/W0;->c:Lc/s0;

    invoke-virtual {v0, v1, p1}, Lc/n1;->X0(Lc/s0;I)V

    iget-object p1, p0, Lc/W0;->d:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/W0;->b:Lc/n1;

    iget-object v1, p0, Lc/W0;->c:Lc/s0;

    invoke-virtual {v0, v1, p1}, Lc/n1;->Y0(Lc/s0;I)V

    iget-object p1, p0, Lc/W0;->d:Ljava/lang/Runnable;

    check-cast p1, Lc/i2;

    invoke-virtual {p1}, Lc/i2;->run()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
