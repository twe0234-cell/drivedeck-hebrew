.class public final Lc/N5;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/P6;

.field public final synthetic c:Landroid/hardware/usb/UsbDevice;

.field public final synthetic d:Lc/u0;

.field public final synthetic e:Lc/T5;


# direct methods
.method public constructor <init>(Lc/T5;ILc/P6;Landroid/hardware/usb/UsbDevice;Lc/u0;)V
    .locals 0

    iput-object p1, p0, Lc/N5;->e:Lc/T5;

    iput p2, p0, Lc/N5;->a:I

    iput-object p3, p0, Lc/N5;->b:Lc/P6;

    iput-object p4, p0, Lc/N5;->c:Landroid/hardware/usb/UsbDevice;

    iput-object p5, p0, Lc/N5;->d:Lc/u0;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    const-string p1, "ru.drivedeck.launcher.USB_PERMISSION"

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    iget p1, p0, Lc/N5;->a:I

    iget-object p2, p0, Lc/N5;->e:Lc/T5;

    iget p2, p2, Lc/T5;->t:I

    if-ne p1, p2, :cond_2

    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    iget-object p1, p1, Lc/T5;->M:Lc/P6;

    iget-object p2, p0, Lc/N5;->b:Lc/P6;

    if-eq p1, p2, :cond_0

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    iget-object p1, p1, Lc/T5;->a:Landroid/content/Context;

    invoke-virtual {p1, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    const/4 p2, 0x0

    iput-object p2, p1, Lc/T5;->N:Lc/N5;

    iget-object p1, p0, Lc/N5;->b:Lc/P6;

    iget-object p2, p0, Lc/N5;->c:Landroid/hardware/usb/UsbDevice;

    iget-object p1, p1, Lc/P6;->a:Landroid/hardware/usb/UsbManager;

    invoke-virtual {p1, p2}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object v1, p0, Lc/N5;->e:Lc/T5;

    iget-object v2, p0, Lc/N5;->b:Lc/P6;

    iget-object v3, p0, Lc/N5;->c:Landroid/hardware/usb/UsbDevice;

    iget-object v4, p0, Lc/N5;->d:Lc/u0;

    iget v5, p0, Lc/N5;->a:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lc/F5;

    const/4 v6, 0x0

    move-object v0, p2

    invoke-direct/range {v0 .. v6}, Lc/F5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    const-string v0, "DriveDeck-OBD-USB"

    invoke-direct {p1, p2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    iget-object p1, p1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string p2, "enabled"

    const/4 v0, 0x0

    invoke-static {p1, p2, v0}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    invoke-virtual {p1}, Lc/T5;->s()V

    iget-object p1, p0, Lc/N5;->e:Lc/T5;

    const-string p2, "\u0414\u043e\u0441\u0442\u0443\u043f \u043a USB-\u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0443 \u043d\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043d"

    iput-object p2, p1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p1}, Lc/T5;->q()V

    :cond_2
    :goto_0
    return-void
.end method
