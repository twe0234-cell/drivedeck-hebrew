.class public final synthetic Lc/H7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/J7;


# direct methods
.method public synthetic constructor <init>(Lc/J7;I)V
    .locals 0

    iput p2, p0, Lc/H7;->a:I

    iput-object p1, p0, Lc/H7;->b:Lc/J7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/H7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/H7;->b:Lc/J7;

    iget-object v1, v0, Lc/J7;->a:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getTranslationX()F

    move-result v1

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    if-nez v1, :cond_0

    iget-object v0, v0, Lc/J7;->b:Landroid/widget/FrameLayout;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/H7;->b:Lc/J7;

    invoke-virtual {v0}, Lc/J7;->a()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
