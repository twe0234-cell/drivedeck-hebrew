.class public final synthetic Lc/r7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnGenericMotionListener;


# instance fields
.field public final synthetic a:Lc/v7;


# direct methods
.method public synthetic constructor <init>(Lc/v7;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/r7;->a:Lc/v7;

    return-void
.end method


# virtual methods
.method public final onGenericMotion(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 0

    iget-object p1, p0, Lc/r7;->a:Lc/v7;

    invoke-virtual {p1, p2}, Lc/v7;->j(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method
