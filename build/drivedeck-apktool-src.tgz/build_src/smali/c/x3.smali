.class public final synthetic Lc/x3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;I)V
    .locals 0

    iput p2, p0, Lc/x3;->a:I

    iput-object p1, p0, Lc/x3;->b:Landroid/view/KeyEvent$Callback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 3

    iget-object v0, p0, Lc/x3;->b:Landroid/view/KeyEvent$Callback;

    iget v1, p0, Lc/x3;->a:I

    packed-switch v1, :pswitch_data_0

    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/w;

    const/4 v2, 0x5

    invoke-direct {v1, v0, p1, v2}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->a0(Ljava/lang/Runnable;)V

    return-void

    :pswitch_0
    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-lez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    invoke-virtual {v0, p1}, Lc/P3;->r(Z)Z

    return-void

    :pswitch_1
    check-cast v0, Lc/Q3;

    iget-object v1, v0, Lc/Q3;->y:Lc/t2;

    iput p1, v1, Lc/t2;->C0:I

    invoke-virtual {v1}, Lc/t2;->n0()V

    iget-object v0, v0, Lc/Q3;->z:Lc/t2;

    iput p1, v0, Lc/t2;->C0:I

    invoke-virtual {v0}, Lc/t2;->n0()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
