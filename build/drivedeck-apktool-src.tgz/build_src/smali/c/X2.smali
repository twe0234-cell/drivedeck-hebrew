.class public final Lc/X2;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Landroid/graphics/Paint;

.field public final synthetic c:Lc/k3;


# direct methods
.method public constructor <init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p3, p0, Lc/X2;->a:I

    packed-switch p3, :pswitch_data_0

    iput-object p1, p0, Lc/X2;->c:Lc/k3;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lc/X2;->b:Landroid/graphics/Paint;

    return-void

    :pswitch_0
    iput-object p1, p0, Lc/X2;->c:Lc/k3;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lc/X2;->b:Landroid/graphics/Paint;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 11

    iget v0, p0, Lc/X2;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget-object v0, p0, Lc/X2;->b:Landroid/graphics/Paint;

    iget-object v1, p0, Lc/X2;->c:Lc/k3;

    iget-object v2, v1, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->k:I

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v7, 0x40000000    # 2.0f

    invoke-virtual {v1, v7}, Lc/k3;->x(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    sget-object v2, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v7

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v7

    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v1, v2}, Lc/k3;->x(F)I

    move-result v1

    int-to-float v9, v1

    const/high16 v1, -0x3ef00000    # -9.0f

    mul-float v2, v9, v1

    const/high16 v1, -0x3f200000    # -7.0f

    mul-float v8, v9, v1

    const/high16 v1, 0x41100000    # 9.0f

    mul-float v4, v9, v1

    move-object v1, p1

    move v3, v8

    move v5, v8

    move-object v6, v0

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/high16 v1, -0x3fc00000    # -3.0f

    mul-float v2, v9, v1

    const/high16 v1, -0x3ed00000    # -11.0f

    mul-float v3, v9, v1

    const/high16 v1, 0x40400000    # 3.0f

    mul-float v4, v9, v1

    move-object v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const/high16 v1, 0x40e00000    # 7.0f

    mul-float v4, v9, v1

    const/high16 v1, 0x41200000    # 10.0f

    mul-float v5, v9, v1

    mul-float v10, v9, v7

    move-object v1, p1

    move v2, v8

    move v3, v8

    move v6, v10

    move v7, v10

    move-object v8, v0

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    const/high16 v1, -0x40000000    # -2.0f

    mul-float v7, v9, v1

    const/high16 v1, 0x40c00000    # 6.0f

    mul-float v8, v9, v1

    move-object v1, p1

    move v2, v7

    move v3, v7

    move v4, v7

    move v5, v8

    move-object v6, v0

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v2, v10

    move v4, v10

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/X2;->b:Landroid/graphics/Paint;

    iget-object v1, p0, Lc/X2;->c:Lc/k3;

    iget-object v2, v1, Lc/k3;->g:Lc/r4;

    iget v2, v2, Lc/r4;->d:I

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v2, 0x40000000    # 2.0f

    invoke-virtual {v1, v2}, Lc/k3;->x(F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v3, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    sget-object v3, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v4, v2

    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v1, v2}, Lc/k3;->x(F)I

    move-result v1

    int-to-float v7, v1

    const/high16 v1, -0x3ee00000    # -10.0f

    mul-float v8, v7, v1

    const/high16 v1, -0x3f600000    # -5.0f

    mul-float v9, v7, v1

    const/high16 v1, 0x41200000    # 10.0f

    mul-float v10, v7, v1

    move-object v1, p1

    move v2, v8

    move v3, v9

    move v4, v10

    move v5, v9

    move-object v6, v0

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/high16 v1, 0x40a00000    # 5.0f

    mul-float/2addr v7, v1

    move-object v1, p1

    move v2, v7

    move v3, v8

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v5, 0x0

    move v2, v10

    move v3, v9

    move v4, v7

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v3, v7

    move v4, v8

    move v5, v7

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v3, 0x0

    move v2, v9

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v2, v8

    move v3, v7

    move v4, v9

    move v5, v10

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
