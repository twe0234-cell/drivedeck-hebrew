.class public final Lc/U5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:[B

.field public final c:[B

.field public final d:Z

.field public final e:Ljava/util/function/ToDoubleFunction;

.field public f:I

.field public g:I

.field public h:I

.field public i:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;[BZLjava/util/function/ToDoubleFunction;[B)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x1000

    if-gt v0, v1, :cond_1

    if-eqz p2, :cond_1

    array-length v0, p2

    const/16 v1, 0xfff

    if-gt v0, v1, :cond_1

    if-eqz p5, :cond_0

    array-length v0, p5

    if-le v0, v1, :cond_0

    goto :goto_0

    :cond_0
    iput-object p1, p0, Lc/U5;->a:Ljava/lang/String;

    iput-object p2, p0, Lc/U5;->b:[B

    iput-boolean p3, p0, Lc/U5;->d:Z

    iput-object p4, p0, Lc/U5;->e:Ljava/util/function/ToDoubleFunction;

    iput-object p5, p0, Lc/U5;->c:[B

    return-void

    :cond_1
    :goto_0
    new-instance p2, Ljava/lang/IllegalArgumentException;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_1

    :cond_2
    const-string p1, "Formula input exceeds limits"

    goto :goto_2

    :cond_3
    :goto_1
    const-string p1, "Empty formula"

    :goto_2
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p2
.end method


# virtual methods
.method public final a(II)V
    .locals 2

    if-ne p1, p2, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Expected "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " arguments, received "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1
.end method

.method public final b()D
    .locals 21

    move-object/from16 v0, p0

    const/4 v4, 0x3

    const/16 v5, 0x8

    const/4 v6, 0x0

    const/4 v8, 0x1

    const-string v9, "("

    invoke-virtual {v0, v9}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v10

    const-string v11, ")"

    if-eqz v10, :cond_1

    invoke-virtual/range {p0 .. p0}, Lc/U5;->d()D

    move-result-wide v1

    invoke-virtual {v0, v11}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    return-wide v1

    :cond_0
    const-string v1, "Expected \')\'"

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_1
    invoke-virtual/range {p0 .. p0}, Lc/U5;->j()V

    const-string v10, "{"

    invoke-virtual {v0, v10}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v10

    iget-object v12, v0, Lc/U5;->e:Ljava/util/function/ToDoubleFunction;

    iget-boolean v15, v0, Lc/U5;->d:Z

    const-string v2, "Unexpected token"

    const/16 v1, 0x100

    iget-object v3, v0, Lc/U5;->a:Ljava/lang/String;

    if-eqz v10, :cond_5

    iget v4, v0, Lc/U5;->f:I

    const/16 v5, 0x7d

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->indexOf(II)I

    move-result v5

    if-lt v5, v4, :cond_4

    sub-int v6, v5, v4

    if-gt v6, v1, :cond_4

    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    add-int/2addr v5, v8

    iput v5, v0, Lc/U5;->f:I

    if-eqz v12, :cond_2

    invoke-interface {v12, v1}, Ljava/util/function/ToDoubleFunction;->applyAsDouble(Ljava/lang/Object;)D

    move-result-wide v13

    goto :goto_0

    :cond_2
    if-eqz v15, :cond_3

    const-wide/high16 v13, 0x3ff0000000000000L    # 1.0

    :goto_0
    return-wide v13

    :cond_3
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_4
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_5
    const-string v10, "[NaN]"

    invoke-virtual {v0, v10}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_6

    const-wide/high16 v1, 0x7ff8000000000000L    # Double.NaN

    return-wide v1

    :cond_6
    iget v10, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v7, 0x800

    if-ge v10, v1, :cond_10

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isDigit(C)Z

    move-result v1

    const/16 v13, 0x2e

    if-nez v1, :cond_7

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    if-ne v1, v13, :cond_10

    :cond_7
    :goto_1
    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-ge v1, v4, :cond_9

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isDigit(C)Z

    move-result v1

    if-nez v1, :cond_8

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    if-ne v1, v13, :cond_9

    :cond_8
    iget v1, v0, Lc/U5;->f:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->f:I

    goto :goto_1

    :cond_9
    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-ge v1, v4, :cond_d

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v4, 0x65

    if-eq v1, v4, :cond_a

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v4, 0x45

    if-ne v1, v4, :cond_d

    :cond_a
    iget v1, v0, Lc/U5;->f:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-ge v1, v4, :cond_c

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v4, 0x2b

    if-eq v1, v4, :cond_b

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v4, 0x2d

    if-ne v1, v4, :cond_c

    :cond_b
    iget v1, v0, Lc/U5;->f:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->f:I

    :cond_c
    :goto_2
    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-ge v1, v4, :cond_d

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isDigit(C)Z

    move-result v1

    if-eqz v1, :cond_d

    iget v1, v0, Lc/U5;->f:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->f:I

    goto :goto_2

    :cond_d
    iget v1, v0, Lc/U5;->g:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->g:I

    if-gt v1, v7, :cond_f

    :try_start_0
    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v10, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_e

    return-wide v3

    :cond_e
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_f
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_10
    :goto_3
    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v13

    if-ge v1, v13, :cond_12

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    invoke-static {v1}, Ljava/lang/Character;->isLetterOrDigit(C)Z

    move-result v1

    if-nez v1, :cond_11

    iget v1, v0, Lc/U5;->f:I

    invoke-virtual {v3, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v13, 0x5f

    if-ne v1, v13, :cond_12

    :cond_11
    iget v1, v0, Lc/U5;->f:I

    add-int/2addr v1, v8

    iput v1, v0, Lc/U5;->f:I

    goto :goto_3

    :cond_12
    iget v1, v0, Lc/U5;->f:I

    if-eq v10, v1, :cond_4d

    iget v13, v0, Lc/U5;->g:I

    add-int/2addr v13, v8

    iput v13, v0, Lc/U5;->g:I

    if-gt v13, v7, :cond_4d

    invoke-virtual {v3, v10, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v9}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v3

    const-string v7, "\'"

    if-eqz v3, :cond_40

    new-array v3, v5, [D

    invoke-virtual {v0, v11}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_16

    move v9, v6

    :goto_4
    if-eq v9, v5, :cond_15

    add-int/lit8 v10, v9, 0x1

    invoke-virtual/range {p0 .. p0}, Lc/U5;->d()D

    move-result-wide v13

    aput-wide v13, v3, v9

    const-string v9, ","

    invoke-virtual {v0, v9}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_14

    const-string v9, ";"

    invoke-virtual {v0, v9}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_14

    invoke-virtual {v0, v11}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_13

    goto :goto_5

    :cond_13
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_14
    move v9, v10

    goto :goto_4

    :cond_15
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_16
    move v10, v6

    :goto_5
    const-string v9, "IF"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1a

    invoke-virtual {v0, v10, v4}, Lc/U5;->a(II)V

    if-nez v15, :cond_18

    aget-wide v4, v3, v6

    invoke-static {v4, v5}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_17

    goto :goto_6

    :cond_17
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_18
    :goto_6
    aget-wide v1, v3, v6

    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    cmpl-double v1, v1, v4

    if-nez v1, :cond_19

    aget-wide v1, v3, v8

    goto/16 :goto_13

    :cond_19
    const/4 v1, 0x2

    aget-wide v1, v3, v1

    goto/16 :goto_13

    :cond_1a
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v9, "min"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_3c

    const-string v11, "max"

    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_1b

    goto/16 :goto_10

    :cond_1b
    const-wide/high16 v13, 0x40f0000000000000L    # 65536.0

    const-wide/16 v17, 0x0

    const-wide/high16 v19, 0x4070000000000000L    # 256.0

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v9

    sparse-switch v9, :sswitch_data_0

    :goto_7
    const/16 v16, -0x1

    goto/16 :goto_9

    :sswitch_0
    const-string v9, "shortsigned"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1c

    goto :goto_7

    :cond_1c
    const/16 v9, 0x17

    goto/16 :goto_8

    :sswitch_1
    const-string v9, "int32"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1d

    goto :goto_7

    :cond_1d
    const/16 v9, 0x16

    goto/16 :goto_8

    :sswitch_2
    const-string v9, "int24"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1e

    goto :goto_7

    :cond_1e
    const/16 v9, 0x15

    goto/16 :goto_8

    :sswitch_3
    const-string v9, "int16"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_1f

    goto :goto_7

    :cond_1f
    const/16 v9, 0x14

    goto/16 :goto_8

    :sswitch_4
    const-string v9, "floor"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_20

    goto :goto_7

    :cond_20
    const/16 v9, 0x13

    goto/16 :goto_8

    :sswitch_5
    const-string v9, "bitor"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_21

    goto :goto_7

    :cond_21
    const/16 v9, 0x12

    goto/16 :goto_8

    :sswitch_6
    const-string v9, "sqrt"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_22

    goto :goto_7

    :cond_22
    const/16 v9, 0x11

    goto/16 :goto_8

    :sswitch_7
    const-string v9, "ceil"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_23

    goto :goto_7

    :cond_23
    const/16 v16, 0x10

    goto/16 :goto_9

    :sswitch_8
    const-string v9, "xor"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_24

    goto :goto_7

    :cond_24
    const/16 v9, 0xf

    goto/16 :goto_8

    :sswitch_9
    const-string v9, "shr"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_25

    goto/16 :goto_7

    :cond_25
    const/16 v9, 0xe

    goto/16 :goto_8

    :sswitch_a
    const-string v9, "shl"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_26

    goto/16 :goto_7

    :cond_26
    const/16 v9, 0xd

    goto/16 :goto_8

    :sswitch_b
    const-string v9, "pow"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_27

    goto/16 :goto_7

    :cond_27
    const/16 v9, 0xc

    goto :goto_8

    :sswitch_c
    const-string v9, "pid"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_28

    goto/16 :goto_7

    :cond_28
    const/16 v9, 0xb

    goto :goto_8

    :sswitch_d
    const-string v9, "bit"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_29

    goto/16 :goto_7

    :cond_29
    const/16 v9, 0xa

    goto :goto_8

    :sswitch_e
    const-string v9, "and"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2a

    goto/16 :goto_7

    :cond_2a
    const/16 v9, 0x9

    goto :goto_8

    :sswitch_f
    const-string v9, "abs"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2b

    goto/16 :goto_7

    :cond_2b
    move/from16 v16, v5

    goto/16 :goto_9

    :sswitch_10
    const-string v9, "or"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2c

    goto/16 :goto_7

    :cond_2c
    const/4 v9, 0x7

    goto :goto_8

    :sswitch_11
    const-string v9, "if"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2d

    goto/16 :goto_7

    :cond_2d
    const/4 v9, 0x6

    goto :goto_8

    :sswitch_12
    const-string v9, "float64"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2e

    goto/16 :goto_7

    :cond_2e
    const/4 v9, 0x5

    :goto_8
    move/from16 v16, v9

    goto :goto_9

    :sswitch_13
    const-string v9, "float32"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_2f

    goto/16 :goto_7

    :cond_2f
    const/16 v16, 0x4

    goto :goto_9

    :sswitch_14
    const-string v9, "signed"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_30

    goto/16 :goto_7

    :cond_30
    move/from16 v16, v4

    goto :goto_9

    :sswitch_15
    const-string v9, "getbit"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_31

    goto/16 :goto_7

    :cond_31
    const/16 v16, 0x2

    goto :goto_9

    :sswitch_16
    const-string v9, "bitxor"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_32

    goto/16 :goto_7

    :cond_32
    move/from16 v16, v8

    goto :goto_9

    :sswitch_17
    const-string v9, "bitand"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_33

    goto/16 :goto_7

    :cond_33
    move/from16 v16, v6

    :goto_9
    packed-switch v16, :pswitch_data_0

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unknown function \'"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :pswitch_0
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    const/16 v2, 0x100

    mul-int/2addr v1, v2

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    add-int/2addr v2, v1

    int-to-short v1, v2

    :goto_a
    int-to-double v1, v1

    goto/16 :goto_13

    :pswitch_1
    const/4 v1, 0x4

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    const-wide/high16 v5, 0x4170000000000000L    # 1.6777216E7

    mul-double/2addr v1, v5

    aget-wide v5, v3, v8

    mul-double/2addr v5, v13

    add-double/2addr v5, v1

    const/4 v1, 0x2

    aget-wide v1, v3, v1

    mul-double v1, v1, v19

    add-double/2addr v1, v5

    aget-wide v4, v3, v4

    :goto_b
    add-double/2addr v1, v4

    goto/16 :goto_13

    :pswitch_2
    invoke-virtual {v0, v10, v4}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    mul-double/2addr v1, v13

    aget-wide v4, v3, v8

    mul-double v4, v4, v19

    add-double/2addr v4, v1

    const/4 v1, 0x2

    aget-wide v1, v3, v1

    add-double/2addr v1, v4

    goto/16 :goto_13

    :pswitch_3
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    mul-double v1, v1, v19

    aget-wide v4, v3, v8

    goto :goto_b

    :pswitch_4
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->floor(D)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_5
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_6
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_7
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit8 v2, v2, 0x1f

    shr-int/2addr v1, v2

    goto :goto_a

    :pswitch_8
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit8 v2, v2, 0x1f

    shl-int/2addr v1, v2

    goto :goto_a

    :pswitch_9
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    aget-wide v4, v3, v8

    invoke-static {v1, v2, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_a
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v4, v3, v6

    invoke-static {v4, v5}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_36

    aget-wide v4, v3, v6

    double-to-int v1, v4

    int-to-double v6, v1

    cmpl-double v3, v4, v6

    if-nez v3, :cond_36

    cmpg-double v3, v4, v17

    if-ltz v3, :cond_36

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    if-eqz v12, :cond_34

    invoke-interface {v12, v1}, Ljava/util/function/ToDoubleFunction;->applyAsDouble(Ljava/lang/Object;)D

    move-result-wide v13

    goto :goto_d

    :cond_34
    if-eqz v15, :cond_35

    :goto_c
    const-wide/high16 v13, 0x3ff0000000000000L    # 1.0

    :goto_d
    move-wide v1, v13

    goto/16 :goto_13

    :cond_35
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_36
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :pswitch_b
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->abs(D)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_c
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    or-int/2addr v1, v2

    goto/16 :goto_a

    :pswitch_d
    invoke-virtual {v0, v10, v4}, Lc/U5;->a(II)V

    if-nez v15, :cond_38

    aget-wide v4, v3, v6

    invoke-static {v4, v5}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_37

    goto :goto_e

    :cond_37
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_38
    :goto_e
    aget-wide v1, v3, v6

    cmpl-double v1, v1, v17

    if-eqz v1, :cond_39

    aget-wide v1, v3, v8

    goto/16 :goto_13

    :cond_39
    const/4 v1, 0x2

    aget-wide v1, v3, v1

    goto/16 :goto_13

    :pswitch_e
    invoke-virtual {v0, v10, v5}, Lc/U5;->a(II)V

    const-wide/16 v1, 0x0

    :goto_f
    if-ge v6, v5, :cond_3a

    shl-long/2addr v1, v5

    aget-wide v9, v3, v6

    invoke-virtual {v0, v9, v10}, Lc/U5;->g(D)I

    move-result v4

    and-int/lit16 v4, v4, 0xff

    int-to-long v9, v4

    or-long/2addr v1, v9

    add-int/2addr v6, v8

    goto :goto_f

    :cond_3a
    invoke-static {v1, v2}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v1

    goto/16 :goto_13

    :pswitch_f
    const/4 v1, 0x4

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    and-int/lit16 v1, v1, 0xff

    shl-int/lit8 v1, v1, 0x18

    aget-wide v6, v3, v8

    invoke-virtual {v0, v6, v7}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit16 v2, v2, 0xff

    const/16 v6, 0x10

    shl-int/2addr v2, v6

    or-int/2addr v1, v2

    const/4 v2, 0x2

    aget-wide v6, v3, v2

    invoke-virtual {v0, v6, v7}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit16 v2, v2, 0xff

    shl-int/2addr v2, v5

    or-int/2addr v1, v2

    aget-wide v2, v3, v4

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit16 v2, v2, 0xff

    or-int/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v1

    float-to-double v1, v1

    goto/16 :goto_13

    :pswitch_10
    invoke-virtual {v0, v10, v8}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    int-to-byte v1, v1

    goto/16 :goto_a

    :pswitch_11
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    and-int/lit16 v1, v1, 0xff

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    and-int/lit8 v2, v2, 0x1f

    shl-int v2, v8, v2

    and-int/2addr v1, v2

    if-eqz v1, :cond_3b

    goto/16 :goto_c

    :cond_3b
    move-wide/from16 v13, v17

    goto/16 :goto_d

    :pswitch_12
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    xor-int/2addr v1, v2

    goto/16 :goto_a

    :pswitch_13
    const/4 v1, 0x2

    invoke-virtual {v0, v10, v1}, Lc/U5;->a(II)V

    aget-wide v1, v3, v6

    invoke-virtual {v0, v1, v2}, Lc/U5;->g(D)I

    move-result v1

    aget-wide v2, v3, v8

    invoke-virtual {v0, v2, v3}, Lc/U5;->g(D)I

    move-result v2

    and-int/2addr v1, v2

    goto/16 :goto_a

    :cond_3c
    :goto_10
    if-lt v10, v8, :cond_3f

    aget-wide v4, v3, v6

    move v2, v8

    :goto_11
    if-ge v2, v10, :cond_3e

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3d

    aget-wide v6, v3, v2

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->min(DD)D

    move-result-wide v4

    goto :goto_12

    :cond_3d
    aget-wide v6, v3, v2

    invoke-static {v4, v5, v6, v7}, Ljava/lang/Math;->max(DD)D

    move-result-wide v4

    :goto_12
    add-int/2addr v2, v8

    goto :goto_11

    :cond_3e
    move-wide v1, v4

    :goto_13
    return-wide v1

    :cond_3f
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_40
    const-string v2, "pi"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_41

    const-wide v1, 0x400921fb54442d18L    # Math.PI

    return-wide v1

    :cond_41
    const-string v2, "e"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_42

    const-wide v1, 0x4005bf0a8b145769L    # Math.E

    return-wide v1

    :cond_42
    const-string v2, "[rR][0-9]+"

    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_46

    :try_start_1
    invoke-virtual {v1, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    const/16 v3, 0xffe

    if-gt v2, v3, :cond_45

    iput-boolean v8, v0, Lc/U5;->i:Z

    if-eqz v15, :cond_43

    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    return-wide v3

    :cond_43
    iget-object v3, v0, Lc/U5;->c:[B

    if-eqz v3, :cond_44

    array-length v4, v3

    if-ge v2, v4, :cond_44

    aget-byte v1, v3, v2

    and-int/lit16 v1, v1, 0xff

    int-to-double v1, v1

    return-wide v1

    :cond_44
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Missing raw response byte \'"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_45
    const-string v1, "Raw byte index exceeds limits"

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :catch_1
    const-string v1, "Invalid raw byte index"

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_46
    const-wide/high16 v3, 0x3ff0000000000000L    # 1.0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v5, 0x5a

    const/16 v9, 0x41

    if-ne v2, v8, :cond_47

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-lt v2, v9, :cond_47

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-gt v2, v5, :cond_47

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    sub-int/2addr v2, v9

    goto :goto_14

    :cond_47
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v10, 0x2

    if-ne v2, v10, :cond_48

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-lt v2, v9, :cond_48

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v10, 0x46

    if-gt v2, v10, :cond_48

    invoke-virtual {v1, v8}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-lt v2, v9, :cond_48

    invoke-virtual {v1, v8}, Ljava/lang/String;->charAt(I)C

    move-result v2

    if-gt v2, v5, :cond_48

    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v2

    sub-int/2addr v2, v9

    mul-int/lit8 v2, v2, 0x1a

    add-int/lit8 v2, v2, 0x1a

    invoke-virtual {v1, v8}, Ljava/lang/String;->charAt(I)C

    move-result v5

    add-int/2addr v5, v2

    add-int/lit8 v2, v5, -0x41

    goto :goto_14

    :cond_48
    const/4 v2, -0x1

    :goto_14
    if-ltz v2, :cond_4c

    iget-object v5, v0, Lc/U5;->b:[B

    if-nez v15, :cond_4a

    array-length v6, v5

    if-ge v2, v6, :cond_49

    goto :goto_15

    :cond_49
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Missing payload byte \'"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_4a
    :goto_15
    iput-boolean v8, v0, Lc/U5;->i:Z

    if-eqz v15, :cond_4b

    move-wide v13, v3

    goto :goto_16

    :cond_4b
    aget-byte v1, v5, v2

    and-int/lit16 v1, v1, 0xff

    int-to-double v13, v1

    :goto_16
    return-wide v13

    :cond_4c
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unknown argument \'"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    :cond_4d
    invoke-virtual {v0, v2}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v1

    throw v1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x52c73a56 -> :sswitch_17
        -0x52c6e3d2 -> :sswitch_16
        -0x4a775a09 -> :sswitch_15
        -0x35ca90e4 -> :sswitch_14
        -0x2daefe45 -> :sswitch_13
        -0x2daefde6 -> :sswitch_12
        0xd1d -> :sswitch_11
        0xde3 -> :sswitch_10
        0x17872 -> :sswitch_f
        0x179d7 -> :sswitch_e
        0x17d0d -> :sswitch_d
        0x1b18b -> :sswitch_c
        0x1b258 -> :sswitch_b
        0x1bcb7 -> :sswitch_a
        0x1bcbd -> :sswitch_9
        0x1d05b -> :sswitch_8
        0x2e8905 -> :sswitch_7
        0x35fd20 -> :sswitch_6
        0x5967bb0 -> :sswitch_5
        0x5d0240c -> :sswitch_4
        0x5fb5e54 -> :sswitch_3
        0x5fb5e71 -> :sswitch_2
        0x5fb5e8e -> :sswitch_1
        0x6f0ca698 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_13
        :pswitch_11
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_12
        :pswitch_6
        :pswitch_5
        :pswitch_c
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;
    .locals 2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " at "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p1, p0, Lc/U5;->f:I

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method public final d()D
    .locals 7

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v0

    :goto_0
    const-string v2, "@&"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lc/U5;->n(D)J

    move-result-wide v2

    and-long/2addr v0, v2

    :goto_1
    long-to-double v0, v0

    goto :goto_0

    :cond_0
    const-string v2, "@|"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lc/U5;->n(D)J

    move-result-wide v2

    or-long/2addr v0, v2

    goto :goto_1

    :cond_1
    const-string v2, "@^"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v2

    invoke-virtual {p0, v2, v3}, Lc/U5;->n(D)J

    move-result-wide v2

    xor-long/2addr v0, v2

    goto :goto_1

    :cond_2
    const-string v2, "@<<"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    const-wide/16 v3, 0x3f

    if-eqz v2, :cond_3

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v5

    invoke-virtual {p0, v5, v6}, Lc/U5;->n(D)J

    move-result-wide v5

    and-long v2, v5, v3

    long-to-int v2, v2

    shl-long/2addr v0, v2

    goto :goto_1

    :cond_3
    const-string v2, "@>>"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->e()D

    move-result-wide v5

    invoke-virtual {p0, v5, v6}, Lc/U5;->n(D)J

    move-result-wide v5

    and-long v2, v5, v3

    long-to-int v2, v2

    shr-long/2addr v0, v2

    goto :goto_1

    :cond_4
    return-wide v0
.end method

.method public final e()D
    .locals 11

    invoke-virtual {p0}, Lc/U5;->f()D

    move-result-wide v0

    :goto_0
    const-string v2, "&"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual {p0}, Lc/U5;->f()D

    move-result-wide v2

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-wide v7, 0x3d06849b86a12b9bL    # 1.0E-14

    if-nez v4, :cond_0

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(D)D

    move-result-wide v9

    cmpg-double v4, v9, v7

    if-gtz v4, :cond_0

    move v4, v6

    goto :goto_1

    :cond_0
    move v4, v5

    :goto_1
    invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z

    move-result v9

    if-nez v9, :cond_1

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v9

    cmpg-double v7, v9, v7

    if-gtz v7, :cond_1

    move v5, v6

    :cond_1
    if-nez v4, :cond_5

    if-eqz v5, :cond_2

    goto :goto_3

    :cond_2
    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    move-result v0

    if-nez v0, :cond_4

    invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_2

    :cond_3
    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    goto :goto_0

    :cond_4
    :goto_2
    const-wide/high16 v0, 0x7ff8000000000000L    # Double.NaN

    goto :goto_0

    :cond_5
    :goto_3
    const-wide/16 v0, 0x0

    goto :goto_0

    :cond_6
    return-wide v0
.end method

.method public final f()D
    .locals 9

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v0

    :goto_0
    const-string v2, "<="

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    const-wide/16 v3, 0x0

    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpg-double v0, v0, v7

    if-gtz v0, :cond_0

    :goto_1
    move-wide v0, v5

    goto :goto_0

    :cond_0
    move-wide v0, v3

    goto :goto_0

    :cond_1
    const-string v2, ">="

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpl-double v0, v0, v7

    if-ltz v0, :cond_0

    goto :goto_1

    :cond_2
    const-string v2, "!="

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpl-double v0, v0, v7

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_3
    const-string v2, "=="

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_7

    const-string v2, "="

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    goto :goto_2

    :cond_4
    const-string v2, "<"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpg-double v0, v0, v7

    if-gez v0, :cond_0

    goto :goto_1

    :cond_5
    const-string v2, ">"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_6

    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpl-double v0, v0, v7

    if-lez v0, :cond_0

    goto :goto_1

    :cond_6
    return-wide v0

    :cond_7
    :goto_2
    invoke-virtual {p0}, Lc/U5;->k()D

    move-result-wide v7

    cmpl-double v0, v0, v7

    if-nez v0, :cond_0

    goto :goto_1
.end method

.method public final g(D)I
    .locals 2

    iget-boolean v0, p0, Lc/U5;->d:Z

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-static {p1, p2}, Ljava/lang/Double;->isFinite(D)Z

    move-result v0

    if-eqz v0, :cond_1

    const-wide/high16 v0, -0x3e20000000000000L    # -2.147483648E9

    cmpg-double v0, p1, v0

    if-ltz v0, :cond_1

    const-wide v0, 0x41dfffffffc00000L    # 2.147483647E9

    cmpl-double v0, p1, v0

    if-gtz v0, :cond_1

    double-to-int p1, p1

    return p1

    :cond_1
    const-string p1, "Unexpected token"

    invoke-virtual {p0, p1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1
.end method

.method public final h()D
    .locals 4

    invoke-virtual {p0}, Lc/U5;->d()D

    move-result-wide v0

    invoke-virtual {p0}, Lc/U5;->j()V

    iget v2, p0, Lc/U5;->f:I

    iget-object v3, p0, Lc/U5;->a:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-ne v2, v3, :cond_0

    return-wide v0

    :cond_0
    const-string v0, "Unexpected token"

    invoke-virtual {p0, v0}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v0

    throw v0
.end method

.method public final i()D
    .locals 4

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v0

    :goto_0
    const-string v2, "*"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v2

    mul-double/2addr v0, v2

    goto :goto_0

    :cond_0
    const-string v2, "/"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v2

    div-double/2addr v0, v2

    goto :goto_0

    :cond_1
    const-string v2, "%"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v2

    rem-double/2addr v0, v2

    goto :goto_0

    :cond_2
    return-wide v0
.end method

.method public final j()V
    .locals 3

    :goto_0
    iget v0, p0, Lc/U5;->f:I

    iget-object v1, p0, Lc/U5;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v0, v2, :cond_0

    iget v0, p0, Lc/U5;->f:I

    invoke-virtual {v1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, Lc/U5;->f:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/U5;->f:I

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final k()D
    .locals 4

    invoke-virtual {p0}, Lc/U5;->i()D

    move-result-wide v0

    :goto_0
    const-string v2, "+"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lc/U5;->i()D

    move-result-wide v2

    add-double/2addr v0, v2

    goto :goto_0

    :cond_0
    const-string v2, "-"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lc/U5;->i()D

    move-result-wide v2

    sub-double/2addr v0, v2

    goto :goto_0

    :cond_1
    return-wide v0
.end method

.method public final l(Ljava/lang/String;)Z
    .locals 3

    invoke-virtual {p0}, Lc/U5;->j()V

    iget-object v0, p0, Lc/U5;->a:Ljava/lang/String;

    iget v1, p0, Lc/U5;->f:I

    invoke-virtual {v0, p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;I)Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    iget v0, p0, Lc/U5;->g:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lc/U5;->g:I

    const/16 v2, 0x800

    if-gt v0, v2, :cond_1

    iget v0, p0, Lc/U5;->f:I

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    add-int/2addr p1, v0

    iput p1, p0, Lc/U5;->f:I

    return v1

    :cond_1
    const-string p1, "Unexpected token"

    invoke-virtual {p0, p1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1
.end method

.method public final m()D
    .locals 4

    iget v0, p0, Lc/U5;->h:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/U5;->h:I

    const/16 v1, 0x30

    if-gt v0, v1, :cond_4

    :try_start_0
    const-string v0, "+"

    invoke-virtual {p0, v0}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    :goto_0
    iget v2, p0, Lc/U5;->h:I

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, Lc/U5;->h:I

    return-wide v0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_1
    :try_start_1
    const-string v0, "-"

    invoke-virtual {p0, v0}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v0

    neg-double v0, v0

    goto :goto_0

    :cond_2
    const-string v0, "@~"

    invoke-virtual {p0, v0}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v0

    invoke-virtual {p0, v0, v1}, Lc/U5;->n(D)J

    move-result-wide v0

    not-long v0, v0

    long-to-double v0, v0

    goto :goto_0

    :cond_3
    invoke-virtual {p0}, Lc/U5;->b()D

    move-result-wide v0

    const-string v2, "^"

    invoke-virtual {p0, v2}, Lc/U5;->l(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Lc/U5;->m()D

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :goto_1
    iget v1, p0, Lc/U5;->h:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lc/U5;->h:I

    throw v0

    :cond_4
    const-string v0, "Unexpected token"

    invoke-virtual {p0, v0}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object v0

    throw v0
.end method

.method public final n(D)J
    .locals 2

    invoke-static {p1, p2}, Ljava/lang/Double;->isFinite(D)Z

    move-result v0

    if-eqz v0, :cond_0

    const-wide/high16 v0, -0x3c20000000000000L    # -9.223372036854776E18

    cmpg-double v0, p1, v0

    if-ltz v0, :cond_0

    const-wide/high16 v0, 0x43e0000000000000L    # 9.223372036854776E18

    cmpl-double v0, p1, v0

    if-gez v0, :cond_0

    double-to-long p1, p1

    return-wide p1

    :cond_0
    const-string p1, "Unexpected token"

    invoke-virtual {p0, p1}, Lc/U5;->c(Ljava/lang/String;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1
.end method
