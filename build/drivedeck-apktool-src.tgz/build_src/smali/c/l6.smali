.class public final Lc/l6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I

.field public final g:Z

.field public final h:Z

.field public final i:Z


# direct methods
.method public constructor <init>(IIIZZI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/l6;->a:I

    iput p2, p0, Lc/l6;->b:I

    iput p3, p0, Lc/l6;->c:I

    iput-boolean p4, p0, Lc/l6;->g:Z

    iput-boolean p5, p0, Lc/l6;->h:Z

    iput p6, p0, Lc/l6;->d:I

    iput-boolean p5, p0, Lc/l6;->i:Z

    if-eqz p5, :cond_0

    const/4 p1, 0x2

    goto :goto_0

    :cond_0
    const/4 p1, 0x3

    :goto_0
    iput p1, p0, Lc/l6;->e:I

    const/4 p1, 0x6

    if-lt p2, p1, :cond_1

    const/16 p1, 0x9

    if-le p2, p1, :cond_2

    :cond_1
    const/16 p1, 0x2b

    if-ne p2, p1, :cond_3

    :cond_2
    const/16 p1, 0x2710

    goto :goto_1

    :cond_3
    const/16 p1, 0x3a98

    :goto_1
    iput p1, p0, Lc/l6;->f:I

    return-void
.end method
