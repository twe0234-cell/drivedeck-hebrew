.class public final synthetic Lc/A2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/n;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;


# direct methods
.method public synthetic constructor <init>(Lc/k3;I)V
    .locals 0

    iput p2, p0, Lc/A2;->a:I

    iput-object p1, p0, Lc/A2;->b:Lc/k3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lc/a;)V
    .locals 6

    iget v0, p0, Lc/A2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/A2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/n1;->A0(Z)V

    iget-object v2, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/n1;->J0(Ljava/lang/String;)V

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, p1}, Lc/n1;->I0(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Lc/n1;->v0(Ljava/lang/String;)V

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Lru/drivedeck/launcher/MainActivity;->b(Ljava/lang/String;)V

    :cond_0
    const-string p1, "\u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e"

    iput-object p1, v0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/A2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/util/HashSet;

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v3

    iget-object v4, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    const-string v5, "music_widget_added_sources"

    invoke-interface {v4, v5, v3}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Lc/n1;->u0()Ljava/util/HashSet;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1, v5, v2}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v2, "music_widget_hidden_sources"

    invoke-interface {p1, v2, v1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
