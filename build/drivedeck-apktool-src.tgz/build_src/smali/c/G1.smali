.class public final synthetic Lc/G1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/N1;

.field public final synthetic c:J

.field public final synthetic d:J


# direct methods
.method public synthetic constructor <init>(Lc/N1;JJI)V
    .locals 0

    iput p6, p0, Lc/G1;->a:I

    iput-object p1, p0, Lc/G1;->b:Lc/N1;

    iput-wide p2, p0, Lc/G1;->c:J

    iput-wide p4, p0, Lc/G1;->d:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/G1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/G1;->b:Lc/N1;

    iget-wide v1, p0, Lc/G1;->c:J

    iget-wide v3, p0, Lc/G1;->d:J

    invoke-virtual {v0, v1, v2, v3, v4}, Lc/N1;->i(JJ)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/G1;->b:Lc/N1;

    iget-wide v1, p0, Lc/G1;->c:J

    iget-wide v3, p0, Lc/G1;->d:J

    invoke-virtual {v0, v1, v2, v3, v4}, Lc/N1;->i(JJ)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
