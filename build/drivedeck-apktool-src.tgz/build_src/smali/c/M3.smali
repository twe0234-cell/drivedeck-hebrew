.class public final Lc/M3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/P3;


# direct methods
.method public synthetic constructor <init>(Lc/P3;)V
    .locals 0

    iput-object p1, p0, Lc/M3;->a:Lc/P3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc/a;Z)V
    .locals 3

    iget-object v0, p0, Lc/M3;->a:Lc/P3;

    invoke-virtual {v0}, Lc/P3;->p()V

    invoke-static {}, Lc/G8;->l()V

    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    :try_start_0
    iget-object v1, v0, Lc/P3;->c1:Landroid/media/session/MediaController;

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v1

    invoke-virtual {v1}, Landroid/media/session/MediaController$TransportControls;->pause()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v1, 0x0

    iget-object v2, v0, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->A0(Z)V

    invoke-virtual {v2, p1}, Lc/n1;->J0(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Lc/n1;->I0(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Lc/n1;->v0(Ljava/lang/String;)V

    if-eqz p2, :cond_1

    iget-object p2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast p2, Landroid/content/SharedPreferences;

    invoke-interface {p2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v1, "radio_app_package"

    invoke-interface {p2, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_1
    iget-object p1, v0, Lc/P3;->b0:Lc/y;

    invoke-virtual {p1}, Lc/y;->a()V

    invoke-virtual {v0}, Lc/P3;->Y()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method
