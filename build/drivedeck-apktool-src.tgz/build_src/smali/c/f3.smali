.class public final Lc/f3;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/RectF;

.field public final synthetic b:Lc/a;

.field public final synthetic c:Lc/a;

.field public final synthetic d:Lc/k3;


# direct methods
.method public constructor <init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;Lc/a;Lc/a;)V
    .locals 0

    iput-object p1, p0, Lc/f3;->d:Lc/k3;

    iput-object p3, p0, Lc/f3;->b:Lc/a;

    iput-object p4, p0, Lc/f3;->c:Lc/a;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lc/f3;->a:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 8

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget-object v0, p0, Lc/f3;->b:Lc/a;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    sub-float/2addr v2, v1

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v1

    div-float/2addr v4, v3

    iget-object v3, p0, Lc/f3;->a:Landroid/graphics/RectF;

    iget-object v0, v0, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    iget-object v5, p0, Lc/f3;->d:Lc/k3;

    iget-object v6, p0, Lc/f3;->c:Lc/a;

    if-nez v6, :cond_1

    add-float v6, v2, v1

    add-float/2addr v1, v4

    invoke-virtual {v3, v2, v4, v6, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v5, Lc/k3;->g:Lc/r4;

    invoke-static {p1, v0, v3, v1}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_0

    :cond_1
    add-float v7, v2, v1

    add-float/2addr v1, v4

    invoke-virtual {v3, v2, v4, v7, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v1, v5, Lc/k3;->g:Lc/r4;

    iget-object v1, v6, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {p1, v0, v1, v3}, Lc/s;->c(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;)V

    :goto_0
    return-void
.end method
