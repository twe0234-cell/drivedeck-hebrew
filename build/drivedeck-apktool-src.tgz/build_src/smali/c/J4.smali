.class public final synthetic Lc/J4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/J4;->b:J

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 5

    check-cast p1, Ljava/lang/Boolean;

    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/J4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_0

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->j0:J

    iget-wide v3, p0, Lc/J4;->b:J

    cmp-long p1, v3, v1

    if-nez p1, :cond_0

    const-string p1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    :cond_0
    return-void
.end method
