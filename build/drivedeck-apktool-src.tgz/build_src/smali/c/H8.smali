.class public final synthetic Lc/H8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/J8;


# direct methods
.method public synthetic constructor <init>(Lc/J8;I)V
    .locals 0

    iput p2, p0, Lc/H8;->a:I

    iput-object p1, p0, Lc/H8;->b:Lc/J8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 5

    iget p1, p0, Lc/H8;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/H8;->b:Lc/J8;

    iget-boolean v0, p1, Lc/J8;->h:Z

    if-nez v0, :cond_1

    iget-object v0, p1, Lc/J8;->g:Lc/U8;

    if-eqz v0, :cond_1

    iget-boolean v0, p1, Lc/J8;->i:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p1, Lc/J8;->h:Z

    iget-object v0, p1, Lc/J8;->e:Landroid/widget/Button;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p1, Lc/J8;->f:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p1, Lc/J8;->d:Landroid/widget/TextView;

    const-string v1, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f\u2026 0%"

    iget-object v2, p1, Lc/J8;->a:Landroid/app/Activity;

    invoke-static {v2, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p1, Lc/J8;->g:Lc/U8;

    iget-object v2, p1, Lc/J8;->c:Landroid/widget/LinearLayout;

    new-instance v3, Lc/I8;

    invoke-direct {v3, p1}, Lc/I8;-><init>(Lc/J8;)V

    invoke-static {v0, v1, v2, v3}, Lc/c9;->c(Landroid/content/Context;Lc/U8;Landroid/view/View;Lc/b9;)V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/H8;->b:Lc/J8;

    iget-boolean v0, p1, Lc/J8;->h:Z

    if-nez v0, :cond_4

    iget-object v0, p1, Lc/J8;->g:Lc/U8;

    if-eqz v0, :cond_4

    iget-boolean v1, p1, Lc/J8;->i:Z

    if-eqz v1, :cond_2

    goto :goto_1

    :cond_2
    iget-object v1, p1, Lc/J8;->b:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "update_postponed_version"

    iget v0, v0, Lc/U8;->a:I

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/32 v3, 0x5265c00

    add-long/2addr v1, v3

    const-string v3, "update_postponed_until"

    invoke-interface {v0, v3, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v0, 0x0

    iput-object v0, p1, Lc/J8;->g:Lc/U8;

    iget-object v1, p1, Lc/J8;->c:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_3

    iget-object v1, p1, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    iget-object v2, p1, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_3
    iput-object v0, p1, Lc/J8;->c:Landroid/widget/LinearLayout;

    :cond_4
    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
