.class public final Lc/s1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/ArrayDeque;

.field public final b:Ljava/util/ArrayDeque;

.field public final c:I

.field public final d:I

.field public e:J

.field public f:J


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lc/s1;->a:Ljava/util/ArrayDeque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lc/s1;->b:Ljava/util/ArrayDeque;

    const/16 v0, 0x80

    iput v0, p0, Lc/s1;->c:I

    const/16 v0, 0x40

    iput v0, p0, Lc/s1;->d:I

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Lc/r1;)V
    .locals 4

    monitor-enter p0

    :try_start_0
    iget-object v0, p1, Lc/r1;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    iget-object v2, p0, Lc/s1;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v2, v1}, Ljava/util/ArrayDeque;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_0
    iget-object v0, p1, Lc/r1;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    iget-object v2, p0, Lc/s1;->b:Ljava/util/ArrayDeque;

    invoke-virtual {v2, v1}, Ljava/util/ArrayDeque;->remove(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    iget-wide v0, p0, Lc/s1;->e:J

    iget-wide v2, p1, Lc/r1;->c:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lc/s1;->e:J

    iget-wide v0, p0, Lc/s1;->f:J

    iget-wide v2, p1, Lc/r1;->d:J

    sub-long/2addr v0, v2

    iput-wide v0, p0, Lc/s1;->f:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized b(Lorg/json/JSONObject;Z)V
    .locals 5

    monitor-enter p0

    if-eqz p2, :cond_0

    :try_start_0
    iget-object v0, p0, Lc/s1;->b:Ljava/util/ArrayDeque;

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_0
    iget-object v0, p0, Lc/s1;->a:Ljava/util/ArrayDeque;

    :goto_0
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    move-result v1

    if-eqz p2, :cond_1

    iget v2, p0, Lc/s1;->d:I

    goto :goto_1

    :cond_1
    iget v2, p0, Lc/s1;->c:I

    :goto_1
    if-lt v1, v2, :cond_3

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    const-wide/16 v1, 0x1

    if-eqz p2, :cond_2

    iget-wide v3, p0, Lc/s1;->f:J

    add-long/2addr v3, v1

    iput-wide v3, p0, Lc/s1;->f:J

    goto :goto_2

    :cond_2
    iget-wide v3, p0, Lc/s1;->e:J

    add-long/2addr v3, v1

    iput-wide v3, p0, Lc/s1;->e:J

    :cond_3
    :goto_2
    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addLast(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :goto_3
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final declared-synchronized c()Lc/r1;
    .locals 8

    monitor-enter p0

    :try_start_0
    new-instance v7, Lc/r1;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v0, p0, Lc/s1;->a:Ljava/util/ArrayDeque;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v2, Ljava/util/ArrayList;

    iget-object v0, p0, Lc/s1;->b:Ljava/util/ArrayDeque;

    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-wide v3, p0, Lc/s1;->e:J

    iget-wide v5, p0, Lc/s1;->f:J

    move-object v0, v7

    invoke-direct/range {v0 .. v6}, Lc/r1;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;JJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v7

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
