.class public final synthetic Lc/V;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/e0;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/e0;II)V
    .locals 0

    iput p3, p0, Lc/V;->a:I

    iput-object p1, p0, Lc/V;->b:Lc/e0;

    iput p2, p0, Lc/V;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget p1, p0, Lc/V;->a:I

    packed-switch p1, :pswitch_data_0

    iget v2, p0, Lc/V;->c:I

    iget-object p1, p0, Lc/V;->b:Lc/e0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v0, p1, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    invoke-virtual {v0, v2}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    iget-object v1, v0, Landroid/appwidget/AppWidgetProviderInfo;->configure:Landroid/content/ComponentName;

    if-eqz v1, :cond_1

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1c

    if-lt v1, v3, :cond_0

    invoke-static {v0}, Lc/T;->a(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v0

    and-int/lit8 v0, v0, 0x1

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    :try_start_1
    iget-object v0, p1, Lc/e0;->d:Lc/b0;

    iget-object v1, p1, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/16 v4, 0x1ced

    invoke-virtual/range {v0 .. v5}, Landroid/appwidget/AppWidgetHost;->startAppWidgetConfigureActivityForResult(Landroid/app/Activity;IIILandroid/os/Bundle;)V
    :try_end_1
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    invoke-virtual {p1, v0}, Lc/e0;->t(Ljava/lang/String;)V

    goto :goto_2

    :cond_1
    :goto_1
    const-string v0, "\u0423 \u0432\u0438\u0434\u0436\u0435\u0442\u0430 \u043d\u0435\u0442 \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a"

    invoke-virtual {p1, v0}, Lc/e0;->t(Ljava/lang/String;)V

    :goto_2
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/V;->b:Lc/e0;

    iget-object v0, p1, Lc/e0;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v1

    iget v2, p0, Lc/V;->c:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0, v1}, Lc/n1;->F0(Ljava/util/ArrayList;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1}, Lc/e0;->i()V

    goto :goto_3

    :cond_2
    :try_start_2
    iget-object v0, p1, Lc/e0;->d:Lc/b0;

    invoke-virtual {v0, v2}, Landroid/appwidget/AppWidgetHost;->deleteAppWidgetId(I)V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    invoke-virtual {p1}, Lc/e0;->n()V

    iget-object p1, p1, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_3
    :goto_3
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
