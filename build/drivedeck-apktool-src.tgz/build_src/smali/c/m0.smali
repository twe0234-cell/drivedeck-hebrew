.class public final Lc/m0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:F

.field public final b:F

.field public final c:F

.field public final d:F


# direct methods
.method public constructor <init>(FFFF)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/m0;->a:F

    iput p2, p0, Lc/m0;->b:F

    invoke-static {p1, p3}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iput p1, p0, Lc/m0;->c:F

    invoke-static {p2, p4}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iput p1, p0, Lc/m0;->d:F

    return-void
.end method


# virtual methods
.method public final a(FF)Z
    .locals 1

    iget v0, p0, Lc/m0;->a:F

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_0

    iget v0, p0, Lc/m0;->c:F

    cmpg-float p1, p1, v0

    if-gez p1, :cond_0

    iget p1, p0, Lc/m0;->b:F

    cmpl-float p1, p2, p1

    if-ltz p1, :cond_0

    iget p1, p0, Lc/m0;->d:F

    cmpg-float p1, p2, p1

    if-gez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final b()F
    .locals 2

    iget v0, p0, Lc/m0;->d:F

    iget v1, p0, Lc/m0;->b:F

    sub-float/2addr v0, v1

    return v0
.end method

.method public final c(F)Lc/m0;
    .locals 4

    new-instance v0, Lc/m0;

    iget v1, p0, Lc/m0;->c:F

    sub-float v1, p1, v1

    iget v2, p0, Lc/m0;->a:F

    sub-float/2addr p1, v2

    iget v2, p0, Lc/m0;->d:F

    iget v3, p0, Lc/m0;->b:F

    invoke-direct {v0, v1, v3, p1, v2}, Lc/m0;-><init>(FFFF)V

    return-object v0
.end method

.method public final d()F
    .locals 2

    iget v0, p0, Lc/m0;->c:F

    iget v1, p0, Lc/m0;->a:F

    sub-float/2addr v0, v1

    return v0
.end method
