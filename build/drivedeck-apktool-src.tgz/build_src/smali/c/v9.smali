.class public final synthetic Lc/v9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic b:Landroid/location/Location;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:J

.field public final synthetic e:Lc/R0;

.field public final synthetic f:Landroid/content/SharedPreferences;

.field public final synthetic g:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Landroid/location/Location;Ljava/lang/String;JLc/R0;Landroid/content/SharedPreferences;Ljava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/v9;->a:Landroid/content/Context;

    iput-object p2, p0, Lc/v9;->b:Landroid/location/Location;

    iput-object p3, p0, Lc/v9;->c:Ljava/lang/String;

    iput-wide p4, p0, Lc/v9;->d:J

    iput-object p6, p0, Lc/v9;->e:Lc/R0;

    iput-object p7, p0, Lc/v9;->f:Landroid/content/SharedPreferences;

    iput-object p8, p0, Lc/v9;->g:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 14

    iget-object v0, p0, Lc/v9;->a:Landroid/content/Context;

    iget-object v1, p0, Lc/v9;->b:Landroid/location/Location;

    iget-object v2, p0, Lc/v9;->c:Ljava/lang/String;

    iget-wide v3, p0, Lc/v9;->d:J

    iget-object v5, p0, Lc/v9;->e:Lc/R0;

    iget-object v6, p0, Lc/v9;->f:Landroid/content/SharedPreferences;

    iget-object v7, p0, Lc/v9;->g:Ljava/lang/Runnable;

    :try_start_0
    new-instance v8, Landroid/location/Geocoder;

    new-instance v9, Ljava/util/Locale;

    const-string v10, "ru"

    const-string v11, "RU"

    invoke-direct {v9, v10, v11}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v8, v0, v9}, Landroid/location/Geocoder;-><init>(Landroid/content/Context;Ljava/util/Locale;)V

    invoke-virtual {v1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v9

    invoke-virtual {v1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v11

    const/4 v13, 0x1

    invoke-virtual/range {v8 .. v13}, Landroid/location/Geocoder;->getFromLocation(DDI)Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_5

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    goto :goto_2

    :cond_0
    const/4 v8, 0x0

    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/location/Address;

    invoke-virtual {v1}, Landroid/location/Address;->getLocality()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/y9;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    goto :goto_2

    :cond_1
    sget-object v9, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v9
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    invoke-static {v0}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/y9;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-wide v10, Lc/y9;->k:J

    cmp-long v3, v3, v10

    if-nez v3, :cond_2

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const/4 v8, 0x1

    :cond_2
    if-eqz v8, :cond_4

    sget-object v0, Lc/y9;->i:Lc/R0;

    if-eq v0, v5, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {v5, v1}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v0

    sput-object v0, Lc/y9;->i:Lc/R0;

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "details"

    sget-object v2, Lc/y9;->i:Lc/R0;

    invoke-virtual {v2}, Lc/R0;->d()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    monitor-exit v9
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    sget-object v0, Lc/y9;->c:Landroid/os/Handler;

    invoke-virtual {v0, v7}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_2

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_4
    :goto_0
    :try_start_3
    monitor-exit v9

    goto :goto_2

    :goto_1
    monitor-exit v9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    :cond_5
    :goto_2
    return-void
.end method
