.class public final Lc/S5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:D

.field public final b:I

.field public final c:J


# direct methods
.method public constructor <init>(D)V
    .locals 1

    const/4 v0, -0x1

    .line 1
    invoke-direct {p0, p1, p2, v0}, Lc/S5;-><init>(DI)V

    return-void
.end method

.method public constructor <init>(DI)V
    .locals 6

    .line 2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    move-object v0, p0

    move-wide v1, p1

    move v3, p3

    invoke-direct/range {v0 .. v5}, Lc/S5;-><init>(DIJ)V

    return-void
.end method

.method public constructor <init>(DIJ)V
    .locals 0

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-wide p1, p0, Lc/S5;->a:D

    .line 5
    iput p3, p0, Lc/S5;->b:I

    .line 6
    iput-wide p4, p0, Lc/S5;->c:J

    return-void
.end method


# virtual methods
.method public final a(Lc/i6;)I
    .locals 1

    iget v0, p0, Lc/S5;->b:I

    if-gez v0, :cond_0

    iget v0, p1, Lc/i6;->o:I

    :cond_0
    return v0
.end method
