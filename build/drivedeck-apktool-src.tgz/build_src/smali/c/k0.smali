.class public final Lc/k0;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Lc/h0;

.field public final b:Landroid/graphics/RectF;

.field public final synthetic c:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic d:Lc/q0;

.field public final synthetic e:Lc/r4;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lru/drivedeck/launcher/MainActivity;Lc/q0;Lc/r4;)V
    .locals 0

    iput-object p2, p0, Lc/k0;->c:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/k0;->d:Lc/q0;

    iput-object p4, p0, Lc/k0;->e:Lc/r4;

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Lc/h0;

    invoke-direct {p1, p2}, Lc/h0;-><init>(Landroid/app/Activity;)V

    iput-object p1, p0, Lc/k0;->a:Lc/h0;

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lc/k0;->b:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 8

    iget-object v2, p0, Lc/k0;->b:Landroid/graphics/RectF;

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v1, v1

    const/4 v3, 0x0

    invoke-virtual {v2, v3, v3, v0, v1}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iget-object v0, p0, Lc/k0;->e:Lc/r4;

    iget-object v1, p0, Lc/k0;->c:Lru/drivedeck/launcher/MainActivity;

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v1, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    iget-object v1, p0, Lc/k0;->a:Lc/h0;

    iget-object v3, p0, Lc/k0;->d:Lc/q0;

    iget v6, v0, Lc/r4;->d:I

    const/4 v7, 0x1

    move-object v0, v1

    move-object v1, p1

    invoke-virtual/range {v0 .. v7}, Lc/h0;->d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;JIZ)V

    return-void
.end method
