.class public final synthetic Lc/F4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(JLc/n1;Ljava/util/List;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/F4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lc/F4;->b:J

    iput-object p3, p0, Lc/F4;->c:Ljava/lang/Object;

    iput-object p4, p0, Lc/F4;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;J)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/F4;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/F4;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/F4;->d:Ljava/lang/Object;

    iput-wide p3, p0, Lc/F4;->b:J

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 16

    move-object/from16 v0, p0

    const/4 v1, 0x0

    iget-object v2, v0, Lc/F4;->d:Ljava/lang/Object;

    iget-wide v3, v0, Lc/F4;->b:J

    iget-object v5, v0, Lc/F4;->c:Ljava/lang/Object;

    const/4 v6, 0x1

    iget v7, v0, Lc/F4;->a:I

    packed-switch v7, :pswitch_data_0

    move-object/from16 v7, p1

    check-cast v7, Lc/P8;

    check-cast v5, Lc/n1;

    invoke-virtual {v5}, Lc/n1;->Q()J

    move-result-wide v8

    cmp-long v3, v3, v8

    if-nez v3, :cond_1

    iget-object v3, v7, Lc/P8;->a:Landroid/widget/Button;

    invoke-virtual {v3, v6}, Landroid/view/View;->setEnabled(Z)V

    check-cast v2, Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v3, "\u041f\u043e\u0434\u0445\u043e\u0434\u044f\u0449\u0438\u0445 \u043f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0445 \u0432\u0435\u0440\u0441\u0438\u0439 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442."

    goto :goto_0

    :cond_0
    const-string v3, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0432\u0435\u0440\u0441\u0438\u044e \u0434\u043b\u044f \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0438:"

    :goto_0
    iget-object v4, v7, Lc/P8;->c:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v4, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v5, v7, Lc/P8;->b:Landroid/widget/TextView;

    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    move-object v13, v3

    check-cast v13, Lc/U8;

    invoke-static {v4}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v3

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setAllCaps(Z)V

    iget-object v6, v13, Lc/U8;->b:Ljava/lang/String;

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v3}, Lc/G8;->r(Landroid/widget/TextView;)V

    const/16 v6, 0xe

    invoke-static {v3, v6}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/16 v6, 0x30

    int-to-float v6, v6

    invoke-static {v4, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-static {v4}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v6

    iget v8, v6, Lc/r4;->g:I

    invoke-virtual {v3, v8}, Landroid/widget/TextView;->setTextColor(I)V

    iget v6, v6, Lc/r4;->f:I

    invoke-static {v6}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    invoke-static {}, Lc/k6;->S()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v6

    iget-object v10, v7, Lc/P8;->d:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v6, Lc/O8;

    iget-object v9, v7, Lc/P8;->a:Landroid/widget/Button;

    iget-object v14, v7, Lc/P8;->c:Lru/drivedeck/launcher/MainActivity;

    move-object v8, v6

    move-object v11, v5

    move-object v12, v7

    invoke-direct/range {v8 .. v14}, Lc/O8;-><init>(Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/TextView;Lc/P8;Lc/U8;Lru/drivedeck/launcher/MainActivity;)V

    invoke-virtual {v3, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_1

    :cond_1
    return-void

    :pswitch_0
    move-object/from16 v7, p1

    check-cast v7, Ljava/util/List;

    sget v8, Lru/drivedeck/launcher/MainActivity;->F0:I

    check-cast v5, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v8, Ljava/util/LinkedHashMap;

    invoke-direct {v8}, Ljava/util/LinkedHashMap;-><init>()V

    check-cast v2, Ljava/lang/String;

    if-eqz v7, :cond_5

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_2
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/Q;

    iget-object v11, v10, Lc/Q;->a:Ljava/lang/String;

    invoke-static {v2}, Lc/k6;->U(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    new-instance v13, Ljava/lang/StringBuilder;

    const-string v14, " "

    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v11}, Lc/k6;->U(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v13

    if-eqz v13, :cond_2

    goto :goto_4

    :cond_2
    const-string v13, " +"

    invoke-virtual {v12, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    array-length v13, v12

    move v15, v1

    :goto_3
    if-ge v15, v13, :cond_4

    aget-object v1, v12, v15

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v11, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    goto :goto_4

    :cond_3
    const/4 v1, 0x1

    add-int/2addr v15, v1

    move v6, v1

    const/4 v1, 0x0

    goto :goto_3

    :cond_4
    iget-object v1, v10, Lc/Q;->b:Ljava/lang/String;

    invoke-interface {v8, v1, v10}, Ljava/util/Map;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_4
    const/4 v1, 0x0

    const/4 v6, 0x1

    goto :goto_2

    :cond_5
    new-instance v1, Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v6

    invoke-direct {v1, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-wide v8, v5, Lru/drivedeck/launcher/MainActivity;->j0:J

    cmp-long v3, v3, v8

    if-nez v3, :cond_e

    iget-object v3, v5, Lru/drivedeck/launcher/MainActivity;->h0:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-virtual {v5}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_e

    invoke-virtual {v5}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-nez v2, :cond_e

    invoke-virtual {v5}, Lru/drivedeck/launcher/MainActivity;->o0()Z

    move-result v2

    if-eqz v2, :cond_e

    iget-object v2, v5, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->q0()Z

    move-result v2

    if-eqz v2, :cond_e

    iget-object v2, v5, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-object v3, v5, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v3, v3, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v8, v5, Lru/drivedeck/launcher/MainActivity;->i0:J

    cmp-long v2, v2, v8

    if-lez v2, :cond_6

    goto/16 :goto_9

    :cond_6
    if-eqz v7, :cond_c

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_7

    goto/16 :goto_7

    :cond_7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_8

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/Q;

    invoke-virtual {v5, v1}, Lru/drivedeck/launcher/MainActivity;->r(Lc/Q;)V

    goto/16 :goto_9

    :cond_8
    const/4 v2, 0x0

    new-instance v3, Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_9

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_9
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v3

    iput-object v3, v5, Lru/drivedeck/launcher/MainActivity;->g0:Ljava/util/List;

    iget-wide v3, v5, Lru/drivedeck/launcher/MainActivity;->j0:J

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    new-array v9, v6, [Ljava/lang/String;

    :goto_6
    if-ge v2, v6, :cond_a

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    add-int/lit8 v10, v2, 0x1

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v11, ". "

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/Q;

    iget-object v11, v11, Lc/Q;->b:Ljava/lang/String;

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v9, v2

    move v2, v10

    goto :goto_6

    :cond_a
    iget-object v1, v5, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-nez v1, :cond_b

    new-instance v1, Lc/l9;

    invoke-direct {v1, v5}, Lc/l9;-><init>(Landroid/app/Activity;)V

    iput-object v1, v5, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_b
    iget-object v7, v5, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    const-string v1, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0430\u0431\u043e\u043d\u0435\u043d\u0442\u0430"

    invoke-static {v5, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v10, Lc/H4;

    invoke-direct {v10, v5, v3, v4}, Lc/H4;-><init>(Lru/drivedeck/launcher/MainActivity;J)V

    new-instance v11, Lc/J1;

    const/16 v1, 0x1d

    invoke-direct {v11, v5, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iget-wide v1, v5, Lru/drivedeck/launcher/MainActivity;->i0:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    sub-long/2addr v1, v3

    const-wide/16 v3, 0x1

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v12

    invoke-virtual/range {v7 .. v13}, Lc/l9;->g(Ljava/lang/String;[Ljava/lang/String;Ljava/util/function/IntConsumer;Ljava/lang/Runnable;J)V

    goto :goto_9

    :cond_c
    :goto_7
    invoke-virtual {v5}, Lru/drivedeck/launcher/MainActivity;->j()V

    invoke-virtual {v5}, Lru/drivedeck/launcher/MainActivity;->l()V

    if-nez v7, :cond_d

    const-string v1, "\u0414\u043e\u0441\u0442\u0443\u043f \u043a \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u043d\u043e\u0439 \u043a\u043d\u0438\u0433\u0435 Bluetooth \u043f\u043e\u043a\u0430 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    goto :goto_8

    :cond_d
    const-string v1, "\u0410\u0431\u043e\u043d\u0435\u043d\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u0432 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e\u0439 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u043d\u043e\u0439 \u043a\u043d\u0438\u0433\u0435"

    :goto_8
    invoke-virtual {v5, v1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    :cond_e
    :goto_9
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
