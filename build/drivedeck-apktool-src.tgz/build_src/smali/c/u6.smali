.class public final synthetic Lc/u6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# instance fields
.field public final synthetic a:Lc/H6;

.field public final synthetic b:Lc/s6;

.field public final synthetic c:Landroid/widget/EditText;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/EditText;Lc/s6;Lc/H6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc/u6;->a:Lc/H6;

    iput-object p2, p0, Lc/u6;->b:Lc/s6;

    iput-object p1, p0, Lc/u6;->c:Landroid/widget/EditText;

    return-void
.end method


# virtual methods
.method public final onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p1, 0x6

    iget-object p3, p0, Lc/u6;->a:Lc/H6;

    if-eq p2, p1, :cond_0

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_0

    :cond_0
    iget-object p1, p3, Lc/H6;->m0:Landroid/os/Handler;

    iget-object p2, p0, Lc/u6;->b:Lc/s6;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/u6;->c:Landroid/widget/EditText;

    invoke-virtual {p1}, Landroid/view/View;->clearFocus()V

    invoke-virtual {p2}, Lc/s6;->run()V

    :goto_0
    const/4 p1, 0x0

    return p1
.end method
