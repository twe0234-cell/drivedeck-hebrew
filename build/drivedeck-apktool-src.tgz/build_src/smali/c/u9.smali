.class public final synthetic Lc/u9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Ljava/lang/String;

.field public final synthetic b:J

.field public final synthetic c:Landroid/content/Context;

.field public final synthetic d:Landroid/content/SharedPreferences;

.field public final synthetic e:Landroid/location/Location;

.field public final synthetic f:Lorg/json/JSONObject;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;JLandroid/content/Context;Landroid/content/SharedPreferences;Landroid/location/Location;Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/u9;->a:Ljava/lang/String;

    iput-wide p2, p0, Lc/u9;->b:J

    iput-object p4, p0, Lc/u9;->c:Landroid/content/Context;

    iput-object p5, p0, Lc/u9;->d:Landroid/content/SharedPreferences;

    iput-object p6, p0, Lc/u9;->e:Landroid/location/Location;

    iput-object p7, p0, Lc/u9;->f:Lorg/json/JSONObject;

    iput-object p8, p0, Lc/u9;->g:Ljava/lang/String;

    iput-object p9, p0, Lc/u9;->h:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 33

    move-object/from16 v1, p0

    iget-object v11, v1, Lc/u9;->a:Ljava/lang/String;

    iget-wide v12, v1, Lc/u9;->b:J

    iget-object v3, v1, Lc/u9;->c:Landroid/content/Context;

    iget-object v9, v1, Lc/u9;->d:Landroid/content/SharedPreferences;

    iget-object v4, v1, Lc/u9;->e:Landroid/location/Location;

    iget-object v0, v1, Lc/u9;->f:Lorg/json/JSONObject;

    iget-object v2, v1, Lc/u9;->g:Ljava/lang/String;

    iget-object v14, v1, Lc/u9;->h:Ljava/lang/Runnable;

    :try_start_0
    sget-object v5, Lc/y9;->d:Ljava/lang/Object;

    monitor-enter v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_c

    :try_start_1
    invoke-static {v3}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lc/y9;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    sget-wide v7, Lc/y9;->k:J

    cmp-long v7, v12, v7

    if-nez v7, :cond_0

    invoke-virtual {v11, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    const/4 v6, 0x1

    goto :goto_1

    :goto_0
    move-wide/from16 v31, v12

    move-object v13, v11

    move-wide/from16 v11, v31

    goto/16 :goto_15

    :cond_0
    const/4 v6, 0x0

    :goto_1
    if-nez v6, :cond_1

    monitor-exit v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-static {v11, v12, v13, v14}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    goto/16 :goto_14

    :catchall_0
    move-exception v0

    goto :goto_0

    :cond_1
    :try_start_2
    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "request_at"

    move-object v15, v9

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-interface {v6, v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "details_request_version"

    const/4 v8, 0x3

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v4, :cond_2

    :try_start_3
    const-string v7, "request_lat"

    invoke-virtual {v4}, Landroid/location/Location;->getLatitude()D

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v8

    invoke-interface {v6, v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "request_lon"

    invoke-virtual {v4}, Landroid/location/Location;->getLongitude()D

    move-result-wide v16
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    move-object/from16 v18, v11

    :try_start_4
    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v10

    invoke-interface {v7, v8, v10, v11}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    goto :goto_3

    :catchall_1
    move-exception v0

    :goto_2
    move-wide v11, v12

    move-object/from16 v13, v18

    goto/16 :goto_15

    :catchall_2
    move-exception v0

    move-object/from16 v18, v11

    goto :goto_2

    :cond_2
    move-object/from16 v18, v11

    :goto_3
    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v6

    monitor-exit v5
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v7, 0x0

    if-eqz v6, :cond_3

    :try_start_5
    invoke-static {v3, v0, v4}, Lc/y9;->a(Landroid/content/Context;Lorg/json/JSONObject;Landroid/location/Location;)Lc/x9;

    move-result-object v6

    goto :goto_4

    :catchall_3
    move-exception v0

    move-wide v11, v12

    move-object/from16 v13, v18

    goto/16 :goto_16

    :cond_3
    move-object v6, v7

    :goto_4
    if-eqz v6, :cond_16

    iget-object v8, v6, Lc/x9;->a:Lc/o9;

    iget-object v8, v8, Lc/o9;->a:Lc/R0;

    iget-object v8, v8, Lc/R0;->d:Ljava/lang/Integer;

    if-eqz v8, :cond_16

    monitor-enter v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    :try_start_6
    invoke-static {}, Lc/y9;->n()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_8

    if-eqz v2, :cond_14

    :try_start_7
    invoke-static {v3}, Lc/y9;->e(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/y9;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-wide v7, Lc/y9;->k:J
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_7

    cmp-long v7, v12, v7

    if-nez v7, :cond_4

    move-object/from16 v11, v18

    :try_start_8
    invoke-virtual {v11, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    if-eqz v2, :cond_5

    const/4 v8, 0x1

    goto :goto_5

    :catchall_4
    move-exception v0

    move-wide/from16 v31, v12

    move-object v13, v11

    move-wide/from16 v11, v31

    goto/16 :goto_12

    :cond_4
    move-object/from16 v11, v18

    :cond_5
    const/4 v8, 0x0

    :goto_5
    if-eqz v8, :cond_6

    :try_start_9
    iget-wide v7, v6, Lc/x9;->b:J

    const-string v2, "relay_cached_at"

    const-wide/16 v9, 0x0

    invoke-interface {v15, v2, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v16

    cmp-long v2, v16, v9

    if-lez v2, :cond_7

    cmp-long v2, v7, v16

    if-lez v2, :cond_6

    goto :goto_6

    :cond_6
    move-wide/from16 v29, v12

    move-object v13, v11

    goto/16 :goto_10

    :cond_7
    :goto_6
    iget-object v2, v6, Lc/x9;->a:Lc/o9;

    const-string v7, "city"

    const-string v8, ""

    invoke-virtual {v0, v7, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v7, v2, Lc/o9;->a:Lc/R0;

    iget-object v7, v7, Lc/R0;->a:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_8

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_8

    iget-object v7, v2, Lc/o9;->a:Lc/R0;

    invoke-virtual {v7, v0}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v17

    new-instance v0, Lc/o9;

    iget-wide v7, v2, Lc/o9;->c:J

    iget-wide v9, v2, Lc/o9;->d:J

    iget-boolean v1, v2, Lc/o9;->b:Z

    move-object/from16 v27, v3

    move-object/from16 v28, v4

    iget-wide v3, v2, Lc/o9;->e:J
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_5

    move-wide/from16 v29, v12

    move-object v13, v11

    :try_start_a
    iget-wide v11, v2, Lc/o9;->f:J

    move-object/from16 v16, v0

    move/from16 v18, v1

    move-wide/from16 v19, v7

    move-wide/from16 v21, v9

    move-wide/from16 v23, v3

    move-wide/from16 v25, v11

    invoke-direct/range {v16 .. v26}, Lc/o9;-><init>(Lc/R0;ZJJJJ)V

    move-object v2, v0

    goto :goto_8

    :goto_7
    move-wide/from16 v11, v29

    goto/16 :goto_12

    :catchall_5
    move-exception v0

    move-wide/from16 v29, v12

    move-object v13, v11

    goto :goto_7

    :cond_8
    move-object/from16 v27, v3

    move-object/from16 v28, v4

    move-wide/from16 v29, v12

    move-object v13, v11

    :goto_8
    iget-object v0, v2, Lc/o9;->a:Lc/R0;

    sput-object v0, Lc/y9;->i:Lc/R0;

    sget-object v0, Lc/y9;->i:Lc/R0;

    iget-object v1, v2, Lc/o9;->a:Lc/R0;

    iget-object v1, v1, Lc/R0;->d:Ljava/lang/Integer;

    if-nez v1, :cond_9

    const-string v1, "\u2014"

    goto :goto_a

    :cond_9
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v4

    if-lez v4, :cond_a

    const-string v4, "+"

    goto :goto_9

    :cond_a
    const-string v4, ""

    :goto_9
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, "\u00b0"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_a
    sput-object v1, Lc/y9;->e:Ljava/lang/String;

    iget-object v1, v2, Lc/o9;->a:Lc/R0;

    iget-object v1, v1, Lc/R0;->b:Ljava/lang/String;

    sput-object v1, Lc/y9;->f:Ljava/lang/String;

    iget-boolean v1, v2, Lc/o9;->b:Z

    sput-boolean v1, Lc/y9;->g:Z

    iget-boolean v1, v6, Lc/x9;->c:Z

    sput-boolean v1, Lc/y9;->h:Z

    const-string v1, "solar_context_invalid"

    const/4 v3, 0x0

    invoke-interface {v15, v1, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    invoke-interface {v15}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v7, "solar_context_invalid"

    invoke-interface {v4, v7, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "temperature"

    sget-object v7, Lc/y9;->e:Ljava/lang/String;

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "condition"

    sget-object v7, Lc/y9;->f:Ljava/lang/String;

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "night"

    sget-boolean v7, Lc/y9;->g:Z

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "stale"

    sget-boolean v7, Lc/y9;->h:Z

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "details"

    sget-object v7, Lc/y9;->i:Lc/R0;

    invoke-virtual {v7}, Lc/R0;->d()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v3, v4, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "sunrise"

    iget-wide v7, v2, Lc/o9;->c:J

    const-wide/16 v9, 0x0

    cmp-long v11, v7, v9

    if-lez v11, :cond_b

    goto :goto_b

    :cond_b
    if-nez v1, :cond_c

    const-string v7, "sunrise"

    invoke-interface {v15, v7, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    goto :goto_b

    :catchall_6
    move-exception v0

    goto/16 :goto_7

    :cond_c
    const-wide/16 v7, 0x0

    :goto_b
    invoke-interface {v3, v4, v7, v8}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "sunset"

    iget-wide v7, v2, Lc/o9;->d:J

    const-wide/16 v9, 0x0

    cmp-long v11, v7, v9

    if-lez v11, :cond_d

    goto :goto_c

    :cond_d
    if-nez v1, :cond_e

    const-string v7, "sunset"

    invoke-interface {v15, v7, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    goto :goto_c

    :cond_e
    const-wide/16 v7, 0x0

    :goto_c
    invoke-interface {v3, v4, v7, v8}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "solar_from"

    iget-wide v7, v2, Lc/o9;->e:J

    const-wide/16 v9, 0x0

    cmp-long v11, v7, v9

    if-lez v11, :cond_f

    goto :goto_d

    :cond_f
    if-nez v1, :cond_10

    const-string v7, "solar_from"

    invoke-interface {v15, v7, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v7

    goto :goto_d

    :cond_10
    const-wide/16 v7, 0x0

    :goto_d
    invoke-interface {v3, v4, v7, v8}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "solar_until"

    iget-wide v7, v2, Lc/o9;->f:J

    const-wide/16 v9, 0x0

    cmp-long v2, v7, v9

    if-lez v2, :cond_11

    move-wide v9, v7

    goto :goto_e

    :cond_11
    if-nez v1, :cond_12

    const-string v1, "solar_until"

    invoke-interface {v15, v1, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v1

    move-wide v9, v1

    goto :goto_e

    :cond_12
    const-wide/16 v9, 0x0

    :goto_e
    invoke-interface {v3, v4, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "relay_cached_at"

    iget-wide v3, v6, Lc/x9;->b:J

    invoke-interface {v1, v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "updated_at"

    iget-wide v3, v6, Lc/x9;->b:J

    invoke-interface {v1, v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "success_at"

    iget-boolean v3, v6, Lc/x9;->c:Z

    if-eqz v3, :cond_13

    const-string v3, "success_at"

    const-wide/16 v6, 0x0

    invoke-interface {v15, v3, v6, v7}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    goto :goto_f

    :cond_13
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    :goto_f
    invoke-interface {v1, v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    monitor-exit v5

    move-object v8, v0

    move-wide/from16 v11, v29

    goto :goto_13

    :catchall_7
    move-exception v0

    move-wide/from16 v29, v12

    move-object/from16 v13, v18

    goto/16 :goto_7

    :cond_14
    move-wide/from16 v29, v12

    move-object/from16 v13, v18

    :goto_10
    monitor-exit v5
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_6

    move-wide/from16 v11, v29

    :cond_15
    :goto_11
    invoke-static {v13, v11, v12, v14}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    goto :goto_14

    :catchall_8
    move-exception v0

    move-wide v11, v12

    move-object/from16 v13, v18

    :goto_12
    :try_start_b
    monitor-exit v5
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_a

    :try_start_c
    throw v0

    :catchall_9
    move-exception v0

    goto :goto_16

    :catchall_a
    move-exception v0

    goto :goto_12

    :cond_16
    move-object/from16 v27, v3

    move-object/from16 v28, v4

    move-wide v11, v12

    move-object/from16 v13, v18

    move-object v8, v7

    :goto_13
    if-eqz v28, :cond_15

    if-eqz v8, :cond_15

    iget-object v0, v8, Lc/R0;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-static {}, Landroid/location/Geocoder;->isPresent()Z

    move-result v0

    if-nez v0, :cond_17

    goto :goto_11

    :cond_17
    new-instance v0, Lc/v9;

    move-object v2, v0

    move-object/from16 v3, v27

    move-object/from16 v4, v28

    move-object v5, v13

    move-wide v6, v11

    move-object v9, v15

    move-object v10, v14

    invoke-direct/range {v2 .. v10}, Lc/v9;-><init>(Landroid/content/Context;Landroid/location/Location;Ljava/lang/String;JLc/R0;Landroid/content/SharedPreferences;Ljava/lang/Runnable;)V

    sget-object v1, Lc/y9;->b:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_9

    goto :goto_11

    :goto_14
    return-void

    :goto_15
    :try_start_d
    monitor-exit v5
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_b

    :try_start_e
    throw v0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_9

    :catchall_b
    move-exception v0

    goto :goto_15

    :catchall_c
    move-exception v0

    move-wide/from16 v31, v12

    move-object v13, v11

    move-wide/from16 v11, v31

    :goto_16
    invoke-static {v13, v11, v12, v14}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    throw v0
.end method
