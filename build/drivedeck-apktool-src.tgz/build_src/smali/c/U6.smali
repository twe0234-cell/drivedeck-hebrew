.class public final synthetic Lc/U6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/widget/LinearLayout;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/TextView;Lc/P8;Lc/U8;Lru/drivedeck/launcher/MainActivity;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/U6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p4, p0, Lc/U6;->e:Ljava/lang/Object;

    iput-object p1, p0, Lc/U6;->f:Ljava/lang/Object;

    iput-object p2, p0, Lc/U6;->b:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lc/U6;->c:Landroid/widget/TextView;

    iput-object p6, p0, Lc/U6;->d:Lru/drivedeck/launcher/MainActivity;

    iput-object p5, p0, Lc/U6;->g:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/T5;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/U6;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/U6;->e:Ljava/lang/Object;

    iput-object p2, p0, Lc/U6;->f:Ljava/lang/Object;

    iput-object p3, p0, Lc/U6;->d:Lru/drivedeck/launcher/MainActivity;

    iput-object p4, p0, Lc/U6;->g:Ljava/lang/Object;

    iput-object p5, p0, Lc/U6;->b:Landroid/widget/LinearLayout;

    iput-object p6, p0, Lc/U6;->c:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 4

    iget p1, p0, Lc/U6;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/U6;->e:Ljava/lang/Object;

    check-cast p1, Lc/P8;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lc/U6;->f:Ljava/lang/Object;

    check-cast p1, Landroid/widget/Button;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/view/View;->setEnabled(Z)V

    iget-object p2, p0, Lc/U6;->b:Landroid/widget/LinearLayout;

    invoke-virtual {p2}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object p2, p0, Lc/U6;->d:Lru/drivedeck/launcher/MainActivity;

    const-string v0, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430\u2026 0%"

    invoke-static {p2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/U6;->c:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Lc/a3;

    invoke-direct {v0, v1, p2, p1}, Lc/a3;-><init>(Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Landroid/widget/Button;)V

    iget-object p1, p0, Lc/U6;->g:Ljava/lang/Object;

    check-cast p1, Lc/U8;

    invoke-static {p2, p1, v1, v0}, Lc/c9;->c(Landroid/content/Context;Lc/U8;Landroid/view/View;Lc/b9;)V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/U6;->e:Ljava/lang/Object;

    check-cast p1, Lc/T5;

    iget-object p2, p0, Lc/U6;->f:Ljava/lang/Object;

    check-cast p2, Ljava/lang/String;

    iget-object v0, p0, Lc/U6;->d:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, p0, Lc/U6;->g:Ljava/lang/Object;

    check-cast v1, Lc/r4;

    iget-object v2, p0, Lc/U6;->b:Landroid/widget/LinearLayout;

    iget-object v3, p0, Lc/U6;->c:Landroid/widget/TextView;

    :try_start_0
    invoke-virtual {p1, p2}, Lc/T5;->D(Ljava/lang/String;)V

    invoke-static {v0, v1, p1, v2, v3}, Lc/b7;->l(Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
