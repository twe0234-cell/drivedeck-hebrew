.class public final Lc/h0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final k:Landroid/graphics/Typeface;

.field public static final l:[F


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Lc/n1;

.field public final c:Ljava/util/Date;

.field public final d:Landroid/graphics/Rect;

.field public final e:Ljava/util/Calendar;

.field public final f:Ljava/util/Locale;

.field public final g:Ljava/text/SimpleDateFormat;

.field public final h:Ljava/text/SimpleDateFormat;

.field public final i:Ljava/text/SimpleDateFormat;

.field public final j:Ljava/text/SimpleDateFormat;


# direct methods
.method static constructor <clinit>()V
    .locals 16

    const-string v0, "sans"

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    const/4 v2, 0x1

    invoke-static {v0, v2}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    sput-object v0, Lc/h0;->k:Landroid/graphics/Typeface;

    const/16 v0, 0xf0

    new-array v0, v0, [F

    sput-object v0, Lc/h0;->l:[F

    :goto_0
    const/16 v0, 0x3c

    if-ge v1, v0, :cond_2

    int-to-double v2, v1

    const-wide v4, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v2, v4

    const-wide/high16 v4, 0x403e000000000000L    # 30.0

    div-double/2addr v2, v4

    const-wide v4, 0x3ff921fb54442d18L    # 1.5707963267948966

    sub-double/2addr v2, v4

    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    move-result-wide v4

    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v2

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(D)D

    move-result-wide v6

    invoke-static {v2, v3}, Ljava/lang/Math;->abs(D)D

    move-result-wide v8

    const-wide/high16 v10, 0x3ff0000000000000L    # 1.0

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->max(DD)D

    move-result-wide v12

    div-double/2addr v10, v12

    mul-double v12, v6, v10

    const-wide/high16 v14, 0x3fe8000000000000L    # 0.75

    cmpl-double v0, v12, v14

    if-lez v0, :cond_0

    mul-double v12, v8, v10

    cmpl-double v0, v12, v14

    if-lez v0, :cond_0

    add-double/2addr v6, v8

    mul-double/2addr v6, v14

    mul-double v8, v6, v6

    const-wide/high16 v10, 0x3ff2000000000000L    # 1.125

    sub-double/2addr v8, v10

    const-wide/high16 v10, 0x3fb0000000000000L    # 0.0625

    add-double/2addr v8, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v8

    add-double v10, v8, v6

    :cond_0
    double-to-float v0, v10

    rem-int/lit8 v6, v1, 0x5

    if-nez v6, :cond_1

    const v6, 0x3e4ccccd    # 0.2f

    goto :goto_1

    :cond_1
    const v6, 0x3db851ec    # 0.09f

    :goto_1
    sub-float/2addr v0, v6

    sget-object v6, Lc/h0;->l:[F

    mul-int/lit8 v7, v1, 0x4

    double-to-float v8, v4

    mul-float/2addr v8, v0

    aput v8, v6, v7

    add-int/lit8 v8, v7, 0x1

    double-to-float v9, v2

    mul-float/2addr v9, v0

    aput v9, v6, v8

    add-int/lit8 v0, v7, 0x2

    mul-double/2addr v4, v10

    double-to-float v4, v4

    aput v4, v6, v0

    add-int/lit8 v7, v7, 0x3

    mul-double/2addr v2, v10

    double-to-float v0, v2

    aput v0, v6, v7

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/h0;->a:Landroid/graphics/Paint;

    new-instance v0, Ljava/util/Date;

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    iput-object v0, p0, Lc/h0;->c:Ljava/util/Date;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lc/h0;->d:Landroid/graphics/Rect;

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lc/h0;->e:Ljava/util/Calendar;

    new-instance v0, Lc/n1;

    invoke-direct {v0, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/h0;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->g()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object p1

    iput-object p1, p0, Lc/h0;->f:Ljava/util/Locale;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "HH"

    invoke-direct {v0, v1, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lc/h0;->g:Ljava/text/SimpleDateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "mm"

    invoke-direct {v0, v1, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lc/h0;->h:Ljava/text/SimpleDateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "EEE"

    invoke-direct {v0, v1, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lc/h0;->i:Ljava/text/SimpleDateFormat;

    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "d MMM"

    invoke-direct {v0, v1, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lc/h0;->j:Ljava/text/SimpleDateFormat;

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;JI)V
    .locals 22

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move/from16 v9, p4

    iget-object v0, v7, Lc/h0;->e:Ljava/util/Calendar;

    move-wide/from16 v1, p2

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    const/16 v1, 0xd

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    int-to-double v1, v1

    const/16 v3, 0xe

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v3

    int-to-double v3, v3

    const-wide v5, 0x408f400000000000L    # 1000.0

    div-double/2addr v3, v5

    add-double v10, v3, v1

    const/16 v1, 0xc

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v1

    int-to-double v1, v1

    const-wide/high16 v3, 0x404e000000000000L    # 60.0

    div-double v5, v10, v3

    add-double v12, v5, v1

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    int-to-double v0, v0

    div-double v2, v12, v3

    add-double/2addr v2, v0

    iget-object v14, v7, Lc/h0;->a:Landroid/graphics/Paint;

    invoke-virtual {v14, v9}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const-wide v15, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v2, v15

    const-wide/high16 v0, 0x4018000000000000L    # 6.0

    div-double/2addr v2, v0

    const-wide v17, 0x3ff921fb54442d18L    # 1.5707963267948966

    sub-double v5, v2, v17

    const v4, 0x40866666    # 4.2f

    const v2, 0x4208e147    # 34.219997f

    const v19, 0x4101eb85    # 8.12f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v3, v19

    invoke-virtual/range {v0 .. v6}, Lc/h0;->e(Landroid/graphics/Canvas;FFFD)V

    mul-double/2addr v12, v15

    const-wide/high16 v20, 0x403e000000000000L    # 30.0

    div-double v12, v12, v20

    sub-double v5, v12, v17

    const v4, 0x40733333    # 3.8f

    const v2, 0x42635c29    # 56.84f

    invoke-virtual/range {v0 .. v6}, Lc/h0;->e(Landroid/graphics/Canvas;FFFD)V

    const/high16 v0, 0x3f400000    # 0.75f

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    mul-double/2addr v10, v15

    div-double v10, v10, v20

    sub-double v10, v10, v17

    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    double-to-float v0, v0

    const v1, 0x425a147b    # 54.52f

    mul-float/2addr v0, v1

    const/high16 v2, 0x42900000    # 72.0f

    add-float v3, v0, v2

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    double-to-float v0, v4

    mul-float/2addr v0, v1

    const/high16 v4, 0x42a00000    # 80.0f

    add-float v5, v0, v4

    move-object/from16 v0, p1

    move v1, v2

    move v2, v4

    move v4, v5

    move-object v5, v14

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const v0, 0x40533333    # 3.3f

    const/high16 v1, 0x42900000    # 72.0f

    const/high16 v2, 0x42a00000    # 80.0f

    invoke-virtual {v8, v1, v2, v0, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/16 v0, -0x4cda

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x40066666    # 2.1f

    invoke-virtual {v8, v1, v2, v0, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-static/range {p4 .. p4}, Landroid/graphics/Color;->luminance(I)F

    move-result v0

    float-to-double v3, v0

    const-wide/high16 v5, 0x3fe0000000000000L    # 0.5

    cmpl-double v0, v3, v5

    if-lez v0, :cond_0

    const v0, -0xeaded6

    goto :goto_0

    :cond_0
    const v0, -0xa0a0b

    :goto_0
    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setColor(I)V

    const v0, 0x3f666666    # 0.9f

    invoke-virtual {v8, v1, v2, v0, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    invoke-virtual {v14, v9}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    return-void
.end method

.method public final b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;)I
    .locals 8

    sget-object v0, Lc/q0;->c:Lc/q0;

    sget-object v1, Lc/q0;->b:Lc/q0;

    const/high16 v2, 0x41200000    # 10.0f

    if-ne p3, v0, :cond_0

    const/high16 v3, 0x41900000    # 18.0f

    goto :goto_0

    :cond_0
    if-ne p3, v1, :cond_1

    const/high16 v3, 0x41a00000    # 20.0f

    goto :goto_0

    :cond_1
    move v3, v2

    :goto_0
    if-ne p3, v1, :cond_2

    const/high16 v4, 0x43520000    # 210.0f

    goto :goto_1

    :cond_2
    sget-object v4, Lc/q0;->a:Lc/q0;

    if-ne p3, v4, :cond_3

    const/high16 v4, 0x435c0000    # 220.0f

    goto :goto_1

    :cond_3
    const/high16 v4, 0x43700000    # 240.0f

    :goto_1
    const/high16 v5, 0x41000000    # 8.0f

    sub-float/2addr v4, v5

    iget-object v5, p0, Lc/h0;->b:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->f0()Z

    move-result v6

    if-eqz v6, :cond_4

    const-string v6, "clock_status_visible"

    iget-object v5, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    const/4 v7, 0x1

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_4

    goto :goto_2

    :cond_4
    const/4 v7, 0x0

    :goto_2
    if-ne p3, v0, :cond_5

    const/high16 p3, 0x430e0000    # 142.0f

    goto :goto_3

    :cond_5
    if-eqz v7, :cond_6

    const/high16 p3, 0x431f0000    # 159.0f

    goto :goto_3

    :cond_6
    if-ne p3, v1, :cond_7

    const/high16 p3, 0x42e00000    # 112.0f

    goto :goto_3

    :cond_7
    const/high16 p3, 0x43160000    # 150.0f

    :goto_3
    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    sub-float v1, v4, v2

    div-float/2addr v0, v1

    invoke-virtual {p2}, Landroid/graphics/RectF;->height()F

    move-result v1

    sub-float v5, p3, v3

    div-float/2addr v1, v5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    add-float/2addr v2, v4

    mul-float/2addr v2, v0

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v2, v4

    sub-float/2addr v5, v2

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerY()F

    move-result p2

    add-float/2addr v3, p3

    mul-float/2addr v3, v0

    div-float/2addr v3, v4

    sub-float/2addr p2, v3

    invoke-virtual {p1, v5, p2}, Landroid/graphics/Canvas;->translate(FF)V

    invoke-virtual {p1, v0, v0}, Landroid/graphics/Canvas;->scale(FF)V

    return v1
.end method

.method public final c(Landroid/graphics/Canvas;Ljava/lang/String;FF)V
    .locals 4

    iget-object v0, p0, Lc/h0;->a:Landroid/graphics/Paint;

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    iget-object v3, p0, Lc/h0;->d:Landroid/graphics/Rect;

    invoke-virtual {v0, p2, v2, v1, v3}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    iget v1, v3, Landroid/graphics/Rect;->left:I

    iget v2, v3, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v2

    int-to-float v1, v1

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    sub-float/2addr p3, v1

    iget v1, v3, Landroid/graphics/Rect;->top:I

    iget v3, v3, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v1, v3

    int-to-float v1, v1

    div-float/2addr v1, v2

    sub-float/2addr p4, v1

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final d(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;JIZ)V
    .locals 20

    move-object/from16 v8, p0

    move-object/from16 v9, p1

    move-wide/from16 v6, p4

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-lez v0, :cond_9

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v0

    cmpg-float v0, v0, v1

    if-gtz v0, :cond_0

    goto/16 :goto_5

    :cond_0
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    iget-object v1, v8, Lc/h0;->g:Ljava/text/SimpleDateFormat;

    invoke-virtual {v1}, Ljava/text/DateFormat;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    iget-object v3, v8, Lc/h0;->j:Ljava/text/SimpleDateFormat;

    iget-object v4, v8, Lc/h0;->i:Ljava/text/SimpleDateFormat;

    iget-object v5, v8, Lc/h0;->h:Ljava/text/SimpleDateFormat;

    if-nez v2, :cond_1

    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    invoke-virtual {v5, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    invoke-virtual {v4, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    invoke-virtual {v3, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    iget-object v2, v8, Lc/h0;->e:Ljava/util/Calendar;

    invoke-virtual {v2, v0}, Ljava/util/Calendar;->setTimeZone(Ljava/util/TimeZone;)V

    :cond_1
    iget-object v0, v8, Lc/h0;->c:Ljava/util/Date;

    invoke-virtual {v0, v6, v7}, Ljava/util/Date;->setTime(J)V

    invoke-virtual {v1, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v5, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    iget-object v2, v8, Lc/h0;->f:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v3, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual/range {p0 .. p3}, Lc/h0;->b(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/q0;)I

    move-result v14

    iget-object v15, v8, Lc/h0;->a:Landroid/graphics/Paint;

    invoke-static/range {p6 .. p6}, Lc/q9;->a(I)I

    move-result v0

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v5, Lc/s0;->b:Lc/s0;

    iget-object v4, v8, Lc/h0;->b:Lc/n1;

    invoke-virtual {v4, v5}, Lc/n1;->X(Lc/s0;)I

    move-result v0

    invoke-static {v0}, Lc/r9;->b(I)Landroid/graphics/Typeface;

    move-result-object v16

    invoke-virtual/range {p3 .. p3}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    if-eqz v0, :cond_8

    const/4 v1, 0x1

    if-eq v0, v1, :cond_7

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2

    move v0, v14

    goto/16 :goto_4

    :cond_2
    invoke-static/range {p6 .. p6}, Lc/q9;->a(I)I

    move-result v10

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const/4 v0, 0x0

    move v11, v0

    :goto_0
    const/16 v0, 0x3c

    const/high16 v1, 0x42900000    # 72.0f

    const/high16 v2, 0x42a00000    # 80.0f

    if-ge v11, v0, :cond_5

    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    rem-int/lit8 v0, v11, 0x5

    if-nez v0, :cond_3

    const/16 v3, 0xff

    goto :goto_1

    :cond_3
    const/16 v3, 0x69

    :goto_1
    invoke-virtual {v15, v3}, Landroid/graphics/Paint;->setAlpha(I)V

    if-nez v0, :cond_4

    const v0, 0x3f666666    # 0.9f

    goto :goto_2

    :cond_4
    const v0, 0x3f266666    # 0.65f

    :goto_2
    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    mul-int/lit8 v0, v11, 0x4

    sget-object v3, Lc/h0;->l:[F

    aget v16, v3, v0

    const/high16 v17, 0x42680000    # 58.0f

    mul-float v16, v16, v17

    add-float v16, v16, v1

    add-int/lit8 v18, v0, 0x1

    aget v18, v3, v18

    mul-float v18, v18, v17

    add-float v18, v18, v2

    add-int/lit8 v19, v0, 0x2

    aget v19, v3, v19

    mul-float v19, v19, v17

    add-float v19, v19, v1

    add-int/lit8 v0, v0, 0x3

    aget v0, v3, v0

    mul-float v0, v0, v17

    add-float v17, v0, v2

    move-object/from16 v0, p1

    move/from16 v1, v16

    move/from16 v2, v18

    move/from16 v3, v19

    move/from16 p2, v14

    move-object v14, v4

    move/from16 v4, v17

    move-object/from16 v17, v13

    move-object v13, v5

    move-object v5, v15

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v11, v11, 0x1

    move-object v5, v13

    move-object v4, v14

    move-object/from16 v13, v17

    move/from16 v14, p2

    goto :goto_0

    :cond_5
    move-object/from16 v17, v13

    move/from16 p2, v14

    move-object v14, v4

    move-object v13, v5

    invoke-virtual {v15, v10}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v14, v13}, Lc/n1;->X(Lc/s0;)I

    move-result v0

    invoke-static {v0}, Lc/r9;->b(I)Landroid/graphics/Typeface;

    move-result-object v0

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v0, 0x41880000    # 17.0f

    invoke-virtual {v15, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const v0, 0x423bc28f    # 46.94f

    const-string v3, "12"

    invoke-virtual {v8, v9, v3, v1, v0}, Lc/h0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    const v0, 0x42d5999a    # 106.8f

    const-string v3, "3"

    invoke-virtual {v8, v9, v3, v0, v2}, Lc/h0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    const-string v0, "6"

    const v3, 0x42e5999a    # 114.8f

    invoke-virtual {v8, v9, v0, v1, v3}, Lc/h0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    const-string v0, "9"

    const v1, 0x4214cccc    # 37.199997f

    invoke-virtual {v8, v9, v0, v1, v2}, Lc/h0;->c(Landroid/graphics/Canvas;Ljava/lang/String;FF)V

    if-eqz p7, :cond_6

    invoke-static/range {p6 .. p6}, Lc/q9;->a(I)I

    move-result v0

    invoke-virtual {v8, v9, v6, v7, v0}, Lc/h0;->a(Landroid/graphics/Canvas;JI)V

    :cond_6
    const/high16 v4, 0x42280000    # 42.0f

    const/high16 v5, 0x41e00000    # 28.0f

    const/high16 v3, 0x430e0000    # 142.0f

    const/high16 v6, 0x42a60000    # 83.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v12

    invoke-virtual/range {v0 .. v6}, Lc/h0;->f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V

    const/high16 v4, 0x42780000    # 62.0f

    const/high16 v5, 0x41980000    # 19.0f

    move-object/from16 v2, v17

    invoke-virtual/range {v0 .. v6}, Lc/h0;->f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V

    :goto_3
    move/from16 v0, p2

    goto/16 :goto_4

    :cond_7
    move-object/from16 v17, v13

    move/from16 p2, v14

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v4, 0x42280000    # 42.0f

    const/high16 v5, 0x41b80000    # 23.0f

    const/high16 v3, 0x41700000    # 15.0f

    const/high16 v6, 0x43340000    # 180.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {v0 .. v6}, Lc/h0;->f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v4, 0x42d80000    # 108.0f

    const/high16 v5, 0x42880000    # 68.0f

    const/high16 v6, 0x43350000    # 181.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v7, v16

    invoke-virtual/range {v0 .. v7}, Lc/h0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFLandroid/graphics/Typeface;)V

    goto :goto_3

    :cond_8
    move/from16 p2, v14

    const/high16 v3, 0x41700000    # 15.0f

    const/high16 v4, 0x42980000    # 76.0f

    const/high16 v5, 0x42ac0000    # 86.0f

    const/high16 v6, 0x42e20000    # 113.0f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v10

    move-object/from16 v7, v16

    invoke-virtual/range {v0 .. v7}, Lc/h0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFLandroid/graphics/Typeface;)V

    const/high16 v4, 0x43110000    # 145.0f

    move-object v2, v11

    invoke-virtual/range {v0 .. v7}, Lc/h0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFLandroid/graphics/Typeface;)V

    const/high16 v4, 0x426c0000    # 59.0f

    const/high16 v5, 0x41c00000    # 24.0f

    const/high16 v3, 0x43080000    # 136.0f

    const/high16 v6, 0x42900000    # 72.0f

    move-object v2, v12

    invoke-virtual/range {v0 .. v6}, Lc/h0;->f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V

    const/high16 v4, 0x42a00000    # 80.0f

    const/high16 v5, 0x41980000    # 19.0f

    move-object v2, v13

    invoke-virtual/range {v0 .. v6}, Lc/h0;->f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V

    goto :goto_3

    :goto_4
    invoke-virtual {v9, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_9
    :goto_5
    return-void
.end method

.method public final e(Landroid/graphics/Canvas;FFFD)V
    .locals 7

    iget-object v6, p0, Lc/h0;->a:Landroid/graphics/Paint;

    const v0, 0x3f99999a    # 1.2f

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-static {p5, p6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    double-to-float v0, v0

    mul-float/2addr v0, p2

    const/high16 v1, 0x42900000    # 72.0f

    add-float v3, v0, v1

    invoke-static {p5, p6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    double-to-float v0, v4

    mul-float/2addr v0, p2

    const/high16 v2, 0x42a00000    # 80.0f

    add-float v4, v0, v2

    move-object v0, p1

    move-object v5, v6

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v6, p4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-static {p5, p6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v0

    double-to-float p4, v0

    mul-float/2addr p4, p3

    const/high16 v0, 0x42900000    # 72.0f

    add-float/2addr p4, v0

    invoke-static {p5, p6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    mul-float/2addr v1, p3

    const/high16 p3, 0x42a00000    # 80.0f

    add-float/2addr v1, p3

    invoke-static {p5, p6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v2

    double-to-float v2, v2

    mul-float/2addr v2, p2

    add-float/2addr v0, v2

    invoke-static {p5, p6}, Ljava/lang/Math;->sin(D)D

    move-result-wide p5

    double-to-float p5, p5

    mul-float/2addr p5, p2

    add-float/2addr p5, p3

    move p2, p4

    move p3, v1

    move p4, v0

    move-object p6, v6

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final f(Landroid/graphics/Canvas;Ljava/lang/String;FFFF)V
    .locals 8

    sget-object v7, Lc/h0;->k:Landroid/graphics/Typeface;

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    invoke-virtual/range {v0 .. v7}, Lc/h0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFLandroid/graphics/Typeface;)V

    return-void
.end method

.method public final g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFLandroid/graphics/Typeface;)V
    .locals 2

    iget-object v0, p0, Lc/h0;->a:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v0, p7}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result p7

    cmpl-float v1, p7, p6

    if-lez v1, :cond_0

    mul-float/2addr p5, p6

    div-float/2addr p5, p7

    invoke-virtual {v0, p5}, Landroid/graphics/Paint;->setTextSize(F)V

    :cond_0
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p5

    const/4 p6, 0x0

    iget-object p7, p0, Lc/h0;->d:Landroid/graphics/Rect;

    invoke-virtual {v0, p2, p6, p5, p7}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    iget p5, p7, Landroid/graphics/Rect;->left:I

    int-to-float p5, p5

    sub-float/2addr p3, p5

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method
