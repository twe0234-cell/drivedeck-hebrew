.class public final Lc/R4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/a9;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/R4;->a:Lru/drivedeck/launcher/MainActivity;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public final b()V
    .locals 0

    return-void
.end method

.method public final c(Lc/U8;)V
    .locals 12

    iget-object v0, p0, Lc/R4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_4

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    if-nez v1, :cond_1

    new-instance v1, Lc/J8;

    invoke-direct {v1, v0}, Lc/J8;-><init>(Landroid/app/Activity;)V

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    :cond_1
    iget-object v0, v0, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    iget-boolean v1, v0, Lc/J8;->i:Z

    if-nez v1, :cond_4

    iget-boolean v1, v0, Lc/J8;->h:Z

    if-nez v1, :cond_4

    iget-object v1, v0, Lc/J8;->a:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-nez v2, :cond_4

    iget v2, p1, Lc/U8;->a:I

    iget-object v3, v0, Lc/J8;->b:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    const-string v4, "update_postponed_version"

    const/4 v5, -0x1

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    if-ne v4, v2, :cond_2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const-string v2, "update_postponed_until"

    const-wide/16 v8, 0x0

    invoke-interface {v3, v2, v8, v9}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v2

    cmp-long v2, v6, v2

    if-gez v2, :cond_2

    goto/16 :goto_0

    :cond_2
    iput-object p1, v0, Lc/J8;->g:Lc/U8;

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v2, :cond_3

    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    const/16 v6, 0x10

    invoke-virtual {v2, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    const/16 v7, 0x14

    invoke-virtual {v0, v7}, Lc/J8;->a(I)I

    move-result v7

    const/16 v8, 0x8

    invoke-virtual {v0, v8}, Lc/J8;->a(I)I

    move-result v9

    const/16 v10, 0xc

    invoke-virtual {v0, v10}, Lc/J8;->a(I)I

    move-result v10

    invoke-virtual {v0, v8}, Lc/J8;->a(I)I

    move-result v11

    invoke-virtual {v2, v7, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v6}, Lc/J8;->a(I)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v2, v7}, Landroid/view/View;->setElevation(F)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v3}, Landroid/view/View;->setClickable(Z)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v4}, Landroid/view/View;->setFocusable(Z)V

    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v2, v0, Lc/J8;->d:Landroid/widget/TextView;

    const/high16 v7, 0x41800000    # 16.0f

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    iget-object v7, v0, Lc/J8;->d:Landroid/widget/TextView;

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    const/4 v11, -0x2

    invoke-direct {v9, v4, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v1}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v2

    iput-object v2, v0, Lc/J8;->f:Landroid/widget/Button;

    const-string v7, "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043f\u043e\u0437\u0436\u0435"

    invoke-static {v1, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Lc/J8;->f:Landroid/widget/Button;

    invoke-static {v2}, Lc/G8;->r(Landroid/widget/TextView;)V

    iget-object v2, v0, Lc/J8;->f:Landroid/widget/Button;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setAllCaps(Z)V

    iget-object v2, v0, Lc/J8;->f:Landroid/widget/Button;

    const/high16 v7, 0x41600000    # 14.0f

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setTextSize(F)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42400000    # 48.0f

    invoke-static {v1, v7}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v9

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-direct {v2, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v8}, Lc/J8;->a(I)I

    move-result v8

    iput v8, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget-object v8, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    iget-object v9, v0, Lc/J8;->f:Landroid/widget/Button;

    invoke-virtual {v8, v9, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v2, v0, Lc/J8;->f:Landroid/widget/Button;

    new-instance v8, Lc/H8;

    const/4 v9, 0x0

    invoke-direct {v8, v0, v9}, Lc/H8;-><init>(Lc/J8;I)V

    invoke-virtual {v2, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {v1}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v2

    iput-object v2, v0, Lc/J8;->e:Landroid/widget/Button;

    const-string v8, "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c"

    invoke-static {v1, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Lc/J8;->e:Landroid/widget/Button;

    invoke-static {v2}, Lc/G8;->r(Landroid/widget/TextView;)V

    iget-object v2, v0, Lc/J8;->e:Landroid/widget/Button;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setAllCaps(Z)V

    iget-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    iget-object v8, v0, Lc/J8;->e:Landroid/widget/Button;

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v1, v7}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v7

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    invoke-direct {v9, v11, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v2, v0, Lc/J8;->e:Landroid/widget/Button;

    new-instance v7, Lc/H8;

    const/4 v8, 0x1

    invoke-direct {v7, v0, v8}, Lc/H8;-><init>(Lc/J8;I)V

    invoke-virtual {v2, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v7, 0x50

    invoke-direct {v2, v5, v11, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v5, 0x18

    invoke-virtual {v0, v5}, Lc/J8;->a(I)I

    move-result v7

    invoke-virtual {v0, v5}, Lc/J8;->a(I)I

    move-result v5

    invoke-virtual {v0, v6}, Lc/J8;->a(I)I

    move-result v6

    invoke-virtual {v2, v7, v4, v5, v6}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup;

    iget-object v6, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v6, v2, Lc/r4;->c:I

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v6, 0x3e8

    invoke-virtual {v0, v6}, Lc/J8;->a(I)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    iget-object v6, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v5, v0, Lc/J8;->d:Landroid/widget/TextView;

    iget v6, v2, Lc/r4;->d:I

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v5, v0, Lc/J8;->f:Landroid/widget/Button;

    invoke-static {v5, v2, v4}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    iget-object v4, v0, Lc/J8;->e:Landroid/widget/Button;

    invoke-static {v4, v2, v3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    iget-object v2, v0, Lc/J8;->d:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u0430 \u043d\u043e\u0432\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f DriveDeck "

    invoke-static {v1, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p1, p1, Lc/U8;->b:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    :cond_4
    :goto_0
    return-void
.end method
