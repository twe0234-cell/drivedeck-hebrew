.class public final synthetic Lc/x4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:J


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;JI)V
    .locals 0

    iput p4, p0, Lc/x4;->a:I

    iput-object p1, p0, Lc/x4;->b:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/x4;->c:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget-wide v0, p0, Lc/x4;->c:J

    iget-object v2, p0, Lc/x4;->b:Lru/drivedeck/launcher/MainActivity;

    iget v3, p0, Lc/x4;->a:I

    packed-switch v3, :pswitch_data_0

    sget v3, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {v2}, Landroid/app/Activity;->isDestroyed()Z

    move-result v3

    if-nez v3, :cond_0

    iget-wide v3, v2, Lru/drivedeck/launcher/MainActivity;->R:J

    cmp-long v0, v0, v3

    if-nez v0, :cond_0

    invoke-virtual {v2}, Lru/drivedeck/launcher/MainActivity;->g0()V

    :cond_0
    return-void

    :pswitch_0
    iget-wide v3, v2, Lru/drivedeck/launcher/MainActivity;->R:J

    cmp-long v0, v0, v3

    if-nez v0, :cond_1

    invoke-virtual {v2}, Lru/drivedeck/launcher/MainActivity;->h()V

    :cond_1
    return-void

    :pswitch_1
    iget-wide v3, v2, Lru/drivedeck/launcher/MainActivity;->R:J

    cmp-long v0, v0, v3

    if-nez v0, :cond_2

    invoke-virtual {v2}, Lru/drivedeck/launcher/MainActivity;->g0()V

    :cond_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
