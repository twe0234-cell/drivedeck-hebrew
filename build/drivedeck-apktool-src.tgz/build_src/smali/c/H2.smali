.class public final synthetic Lc/H2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;

.field public final synthetic c:Lc/n1;


# direct methods
.method public synthetic constructor <init>(ILc/n1;Lc/k3;)V
    .locals 0

    iput p1, p0, Lc/H2;->a:I

    iput-object p3, p0, Lc/H2;->b:Lc/k3;

    iput-object p2, p0, Lc/H2;->c:Lc/n1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    iget p1, p0, Lc/H2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/H2;->b:Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/H2;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "home_edge_fade_all_apps"

    invoke-virtual {v0, v2}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/H2;->b:Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/H2;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "home_window_bar_visible"

    invoke-virtual {v0, v2}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {v1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
