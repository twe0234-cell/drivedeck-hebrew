.class public final Lc/g9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Lc/n1;

.field public final c:Lc/x3;

.field public final d:Lc/J1;

.field public final e:Lc/u4;

.field public f:Ljava/lang/String;

.field public g:I

.field public h:J

.field public final i:Landroid/os/Messenger;

.field public j:Landroid/os/Messenger;

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Ljava/lang/String;

.field public r:I

.field public s:J

.field public t:J

.field public final u:Landroid/os/Handler;

.field public final v:Lc/e9;

.field public w:I

.field public final x:Lc/e9;

.field public final y:Lc/e9;


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/n1;Lc/x3;Lc/u4;Lc/J1;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lc/g9;->f:Ljava/lang/String;

    new-instance v0, Landroid/os/Messenger;

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    new-instance v3, Lc/d9;

    invoke-direct {v3, p0}, Lc/d9;-><init>(Lc/g9;)V

    invoke-direct {v1, v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    invoke-direct {v0, v1}, Landroid/os/Messenger;-><init>(Landroid/os/Handler;)V

    iput-object v0, p0, Lc/g9;->i:Landroid/os/Messenger;

    const-string v0, "disabled"

    iput-object v0, p0, Lc/g9;->q:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p0, Lc/g9;->r:I

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/g9;->u:Landroid/os/Handler;

    new-instance v0, Lc/e9;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/e9;-><init>(Lc/g9;I)V

    iput-object v0, p0, Lc/g9;->v:Lc/e9;

    const/16 v0, 0x3e8

    iput v0, p0, Lc/g9;->w:I

    new-instance v0, Lc/e9;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/e9;-><init>(Lc/g9;I)V

    iput-object v0, p0, Lc/g9;->x:Lc/e9;

    new-instance v0, Lc/e9;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lc/e9;-><init>(Lc/g9;I)V

    iput-object v0, p0, Lc/g9;->y:Lc/e9;

    iput-object p1, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/g9;->b:Lc/n1;

    iput-object p3, p0, Lc/g9;->c:Lc/x3;

    iput-object p4, p0, Lc/g9;->e:Lc/u4;

    iput-object p5, p0, Lc/g9;->d:Lc/J1;

    return-void
.end method

.method public static b(Landroid/app/Activity;)Z
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "ru.drivedeck.voice"

    invoke-virtual {p0, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    if-lt p0, v1, :cond_0

    const/4 v0, 0x1

    :catch_0
    :cond_0
    return v0
.end method

.method public static f(Landroid/content/Context;)Z
    .locals 6

    const-string v0, "ru.drivedeck.voice"

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v3

    iget v4, v3, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v5, 0x3

    if-lt v4, v5, :cond_0

    iget-object v3, v3, Landroid/content/pm/PackageInfo;->sharedUserId:Ljava/lang/String;

    if-nez v3, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0, v0}, Landroid/content/pm/PackageManager;->checkSignatures(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez p0, :cond_0

    const/4 v1, 0x1

    :catch_0
    :cond_0
    return v1
.end method

.method public static g(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 5

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p1}, Ld/a;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v2

    iget v3, v2, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v4, 0x1

    if-lt v3, v4, :cond_0

    iget-object v2, v2, Landroid/content/pm/PackageInfo;->sharedUserId:Ljava/lang/String;

    if-nez v2, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0, p1}, Landroid/content/pm/PackageManager;->checkSignatures(Ljava/lang/String;Ljava/lang/String;)I

    move-result p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez p0, :cond_0

    move v0, v4

    :catch_0
    :cond_0
    return v0
.end method

.method public static h(Landroid/content/Context;)Z
    .locals 3

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "ru.drivedeck.voice"

    invoke-virtual {p0, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/16 v1, 0x9

    const/4 v2, 0x1

    if-lt p0, v1, :cond_0

    move p0, v2

    goto :goto_0

    :cond_0
    move p0, v0

    :goto_0
    if-eqz p0, :cond_1

    move v0, v2

    :catch_0
    :cond_1
    return v0
.end method

.method public static k(Landroid/app/Activity;)Z
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-static {p0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "ru.drivedeck.voice"

    invoke-virtual {p0, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    if-lt p0, v1, :cond_0

    const/4 v0, 0x1

    :catch_0
    :cond_0
    return v0
.end method


# virtual methods
.method public final a()Z
    .locals 2

    iget-boolean v0, p0, Lc/g9;->p:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->r0()Z

    move-result v1

    if-nez v1, :cond_0

    iget-boolean v1, p0, Lc/g9;->n:Z

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lc/n1;->p0()Z

    move-result v0

    if-eqz v0, :cond_1

    :cond_0
    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final c()V
    .locals 10

    iget-object v0, p0, Lc/g9;->j:Landroid/os/Messenger;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v1}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v0, "language_missing"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void

    :cond_1
    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1, v3, v4, v5}, Landroid/os/Message;->obtain(Landroid/os/Handler;III)Landroid/os/Message;

    move-result-object v1

    iget-object v4, p0, Lc/g9;->u:Landroid/os/Handler;

    iget-object v6, p0, Lc/g9;->y:Lc/e9;

    invoke-virtual {v4, v6}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-wide v6, p0, Lc/g9;->s:J

    const-wide/16 v8, 0x1

    add-long/2addr v6, v8

    iput-wide v6, p0, Lc/g9;->s:J

    iget-wide v6, p0, Lc/g9;->t:J

    add-long/2addr v6, v8

    iput-wide v6, p0, Lc/g9;->t:J

    const-string v4, ""

    iput-object v4, p0, Lc/g9;->f:Ljava/lang/String;

    iput v5, p0, Lc/g9;->g:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    iget-object v7, p0, Lc/g9;->e:Lc/u4;

    invoke-virtual {v7, v6, v4}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v4, p0, Lc/g9;->i:Landroid/os/Messenger;

    iput-object v4, v1, Landroid/os/Message;->replyTo:Landroid/os/Messenger;

    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const-string v6, "session"

    iget-wide v7, p0, Lc/g9;->s:J

    invoke-virtual {v4, v6, v7, v8}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const-string v6, "language"

    invoke-virtual {v0}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "single"

    iget-boolean v7, p0, Lc/g9;->n:Z

    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string v6, "requests"

    invoke-static {v2}, Lc/g9;->k(Landroid/app/Activity;)Z

    move-result v7

    invoke-virtual {v4, v6, v7}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-static {v2}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v0}, Lc/n1;->q0()Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-static {v2}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_0

    :cond_2
    move v3, v5

    :goto_0
    const-string v2, "calls"

    invoke-virtual {v4, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v2, 0x55

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v3, "voice_confidence"

    const/16 v5, 0x5f

    const/16 v6, 0x46

    invoke-static {v0, v3, v2, v5, v6}, Lc/t;->b(Landroid/content/SharedPreferences;Ljava/lang/String;III)I

    move-result v0

    const-string v2, "confidence"

    invoke-virtual {v4, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v1, v4}, Landroid/os/Message;->setData(Landroid/os/Bundle;)V

    const-string v0, "starting"

    invoke-virtual {p0, v0}, Lc/g9;->o(Ljava/lang/String;)V

    :try_start_0
    iget-object v0, p0, Lc/g9;->j:Landroid/os/Messenger;

    invoke-virtual {v0, v1}, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-virtual {p0}, Lc/g9;->d()V

    :goto_1
    return-void
.end method

.method public final d()V
    .locals 1

    iget-boolean v0, p0, Lc/g9;->m:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lc/g9;->k:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lc/g9;->j:Landroid/os/Messenger;

    invoke-virtual {p0}, Lc/g9;->e()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final e()V
    .locals 1

    const-string v0, "error"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void
.end method

.method public final i()V
    .locals 6

    iget-boolean v0, p0, Lc/g9;->m:Z

    if-nez v0, :cond_4

    iget-boolean v0, p0, Lc/g9;->l:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Lc/g9;->p:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lc/g9;->j()V

    return-void

    :cond_1
    iget-object v0, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2

    const-string v0, "missing"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void

    :cond_2
    iget-object v1, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_3

    const-string v0, "language_missing"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void

    :cond_3
    iget-boolean v1, p0, Lc/g9;->n:Z

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Lc/g9;->q(Z)V

    iput-boolean v1, p0, Lc/g9;->n:Z

    const/4 v1, 0x1

    iput-boolean v1, p0, Lc/g9;->l:Z

    const-string v1, "starting"

    invoke-virtual {p0, v1}, Lc/g9;->o(Ljava/lang/String;)V

    :try_start_0
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    new-instance v3, Landroid/content/ComponentName;

    const-string v4, "ru.drivedeck.voice"

    const-string v5, "ru.drivedeck.voice.VoiceModuleActivity"

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    const/16 v3, 0x1f90

    invoke-virtual {v0, v1, v3}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    iput-boolean v2, p0, Lc/g9;->l:Z

    invoke-virtual {p0}, Lc/g9;->e()V

    :cond_4
    :goto_0
    return-void
.end method

.method public final j()V
    .locals 3

    iget-boolean v0, p0, Lc/g9;->m:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lc/g9;->a()Z

    move-result v0

    iget-object v1, p0, Lc/g9;->b:Lc/n1;

    if-nez v0, :cond_2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/g9;->q(Z)V

    iget-boolean v0, p0, Lc/g9;->p:Z

    if-eqz v0, :cond_1

    invoke-virtual {v1}, Lc/n1;->r0()Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "paused"

    invoke-virtual {p0, v0}, Lc/g9;->o(Ljava/lang/String;)V

    :cond_1
    return-void

    :cond_2
    iget-object v0, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string v0, "missing"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void

    :cond_3
    invoke-virtual {v1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "language_missing"

    invoke-virtual {p0, v0}, Lc/g9;->r(Ljava/lang/String;)V

    return-void

    :cond_4
    iget-boolean v0, p0, Lc/g9;->k:Z

    if-nez v0, :cond_6

    iget-boolean v0, p0, Lc/g9;->l:Z

    if-eqz v0, :cond_5

    goto :goto_0

    :cond_5
    invoke-virtual {p0}, Lc/g9;->i()V

    :cond_6
    :goto_0
    return-void
.end method

.method public final l()V
    .locals 5

    iget-object v0, p0, Lc/g9;->u:Landroid/os/Handler;

    iget-object v1, p0, Lc/g9;->x:Lc/e9;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v2, p0, Lc/g9;->m:Z

    if-nez v2, :cond_1

    iget-boolean v2, p0, Lc/g9;->p:Z

    if-nez v2, :cond_1

    iget-object v2, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2}, Landroid/app/Activity;->isFinishing()Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v2}, Landroid/app/Activity;->isDestroyed()Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v3, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->r0()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-static {v2}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const-string v3, "android.permission.RECORD_AUDIO"

    const-string v4, "ru.drivedeck.voice"

    invoke-virtual {v2, v3, v4}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-nez v2, :cond_1

    :cond_0
    iget v2, p0, Lc/g9;->w:I

    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget v0, p0, Lc/g9;->w:I

    mul-int/lit8 v0, v0, 0x2

    const/16 v1, 0x7530

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    iput v0, p0, Lc/g9;->w:I

    :cond_1
    return-void
.end method

.method public final m(Z)V
    .locals 1

    iget-boolean v0, p0, Lc/g9;->p:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Lc/g9;->p:Z

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lc/g9;->q(Z)V

    iget-object p1, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->r0()Z

    move-result p1

    if-eqz p1, :cond_2

    const-string p1, "paused"

    invoke-virtual {p0, p1}, Lc/g9;->o(Ljava/lang/String;)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lc/g9;->j()V

    :cond_2
    :goto_0
    return-void
.end method

.method public final n(Z)V
    .locals 5

    const/16 v0, 0x3e8

    iput v0, p0, Lc/g9;->w:I

    const/4 v0, 0x0

    iget-object v1, p0, Lc/g9;->b:Lc/n1;

    if-eqz p1, :cond_2

    iget-object v2, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    const-string v3, "voice_button_enabled"

    invoke-static {v2, v3, v0}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    sget-object v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, Landroid/accessibilityservice/AccessibilityService;->getServiceInfo()Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-result-object v3

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    iget v4, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    or-int/lit8 v4, v4, 0x20

    iput v4, v3, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    invoke-virtual {v2, v3}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    :cond_2
    :goto_0
    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "voice_enabled"

    invoke-static {v1, v2, p1}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Lc/g9;->i()V

    goto :goto_1

    :cond_3
    invoke-virtual {p0, v0}, Lc/g9;->q(Z)V

    :goto_1
    return-void
.end method

.method public final o(Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    iput-object p1, p0, Lc/g9;->q:Ljava/lang/String;

    const-string v0, "listening"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    iput-boolean p1, p0, Lc/g9;->o:Z

    :cond_0
    iget-object p1, p0, Lc/g9;->d:Lc/J1;

    invoke-virtual {p1}, Lc/J1;->run()V

    :cond_1
    return-void
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 0

    invoke-virtual {p0}, Lc/g9;->d()V

    return-void
.end method

.method public final onNullBinding(Landroid/content/ComponentName;)V
    .locals 0

    invoke-virtual {p0}, Lc/g9;->d()V

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 0

    iget-boolean p1, p0, Lc/g9;->k:Z

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget-boolean p1, p0, Lc/g9;->m:Z

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lc/g9;->a()Z

    move-result p1

    if-eqz p1, :cond_2

    iget-object p1, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p1}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    new-instance p1, Landroid/os/Messenger;

    invoke-direct {p1, p2}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    iput-object p1, p0, Lc/g9;->j:Landroid/os/Messenger;

    invoke-virtual {p0}, Lc/g9;->c()V

    return-void

    :cond_2
    :goto_0
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lc/g9;->q(Z)V

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    invoke-virtual {p0}, Lc/g9;->d()V

    return-void
.end method

.method public final p()Ljava/lang/String;
    .locals 5

    iget-object v0, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v1

    const-string v2, "\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u0438\u043b\u0438 \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u0435 \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0439 \u043c\u043e\u0434\u0443\u043b\u044c"

    if-nez v1, :cond_0

    return-object v2

    :cond_0
    iget-object v1, p0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "\u0421\u043a\u0430\u0447\u0430\u0439\u0442\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u044f\u0437\u044b\u043a \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044f"

    return-object v0

    :cond_1
    iget-object v0, p0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, -0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const-string v4, "call_query"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_0

    :cond_2
    const/16 v3, 0x9

    goto/16 :goto_0

    :sswitch_1
    const-string v4, "music_query"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto/16 :goto_0

    :cond_3
    const/16 v3, 0x8

    goto/16 :goto_0

    :sswitch_2
    const-string v4, "starting"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto :goto_0

    :cond_4
    const/4 v3, 0x7

    goto :goto_0

    :sswitch_3
    const-string v4, "missing"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto :goto_0

    :cond_5
    const/4 v3, 0x6

    goto :goto_0

    :sswitch_4
    const-string v4, "confirm"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto :goto_0

    :cond_6
    const/4 v3, 0x5

    goto :goto_0

    :sswitch_5
    const-string v4, "recognizing"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto :goto_0

    :cond_7
    const/4 v3, 0x4

    goto :goto_0

    :sswitch_6
    const-string v4, "error"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto :goto_0

    :cond_8
    const/4 v3, 0x3

    goto :goto_0

    :sswitch_7
    const-string v4, "call_lookup"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto :goto_0

    :cond_9
    const/4 v3, 0x2

    goto :goto_0

    :sswitch_8
    const-string v4, "paused"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    goto :goto_0

    :cond_a
    const/4 v3, 0x1

    goto :goto_0

    :sswitch_9
    const-string v4, "listening"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b

    goto :goto_0

    :cond_b
    const/4 v3, 0x0

    :goto_0
    packed-switch v3, :pswitch_data_0

    const-string v0, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    return-object v0

    :pswitch_0
    const-string v0, "\u041d\u0430\u0437\u043e\u0432\u0438\u0442\u0435 \u0430\u0431\u043e\u043d\u0435\u043d\u0442\u0430"

    return-object v0

    :pswitch_1
    const-string v0, "\u041d\u0430\u0437\u043e\u0432\u0438\u0442\u0435 \u0438\u0441\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044f \u0438, \u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e, \u0442\u0440\u0435\u043a"

    return-object v0

    :pswitch_2
    const-string v0, "\u041f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044f\u2026"

    return-object v0

    :pswitch_3
    return-object v2

    :pswitch_4
    const-string v0, "\u041f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u0435 \u0437\u0430\u043f\u0440\u043e\u0441 \u0438\u043b\u0438 \u043e\u0442\u043c\u0435\u043d\u0438\u0442\u0435"

    return-object v0

    :pswitch_5
    const-string v0, "\u0421\u043b\u0443\u0448\u0430\u044e\u2026"

    return-object v0

    :pswitch_6
    invoke-virtual {v1}, Lc/n1;->r0()Z

    move-result v0

    if-eqz v0, :cond_c

    const-string v0, "\u041c\u043e\u0434\u0443\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d. \u041f\u043e\u0432\u0442\u043e\u0440\u043d\u043e\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435\u2026"

    goto :goto_1

    :cond_c
    const-string v0, "\u041c\u043e\u0434\u0443\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d. \u0412\u044b\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0438 \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0433\u043e\u043b\u043e\u0441\u043e\u0432\u043e\u0435 \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435."

    :goto_1
    return-object v0

    :pswitch_7
    const-string v0, "\u041f\u043e\u0438\u0441\u043a \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0430\u2026"

    return-object v0

    :pswitch_8
    const-string v0, "\u041c\u0438\u043a\u0440\u043e\u0444\u043e\u043d \u043e\u0441\u0432\u043e\u0431\u043e\u0436\u0434\u0451\u043d \u043d\u0430 \u0432\u0440\u0435\u043c\u044f \u0437\u0432\u043e\u043d\u043a\u0430"

    return-object v0

    :pswitch_9
    const-string v0, "\u041e\u0436\u0438\u0434\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u044b"

    return-object v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x48a41f45 -> :sswitch_9
        -0x3b5366d2 -> :sswitch_8
        -0x1bd19985 -> :sswitch_7
        0x5c4d208 -> :sswitch_6
        0x1a4239cb -> :sswitch_5
        0x38b0e6c0 -> :sswitch_4
        0x3fbe8166 -> :sswitch_3
        0x4e7ce040 -> :sswitch_2
        0x5e9e7a2e -> :sswitch_1
        0x730037a7 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final q(Z)V
    .locals 6

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/g9;->l:Z

    iget-object v1, p0, Lc/g9;->u:Landroid/os/Handler;

    iget-object v2, p0, Lc/g9;->x:Lc/e9;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v2, 0x1

    if-nez p1, :cond_0

    iget-wide v4, p0, Lc/g9;->t:J

    add-long/2addr v4, v2

    iput-wide v4, p0, Lc/g9;->t:J

    :cond_0
    iget-object p1, p0, Lc/g9;->v:Lc/e9;

    invoke-virtual {v1, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/g9;->y:Lc/e9;

    invoke-virtual {v1, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v0, p0, Lc/g9;->n:Z

    iget-wide v4, p0, Lc/g9;->s:J

    add-long/2addr v4, v2

    iput-wide v4, p0, Lc/g9;->s:J

    const-string p1, ""

    iput-object p1, p0, Lc/g9;->f:Ljava/lang/String;

    iput v0, p0, Lc/g9;->g:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget-object v2, p0, Lc/g9;->e:Lc/u4;

    invoke-virtual {v2, v1, p1}, Lc/u4;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object p1, p0, Lc/g9;->j:Landroid/os/Messenger;

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    :try_start_0
    invoke-static {v1, v2}, Landroid/os/Message;->obtain(Landroid/os/Handler;I)Landroid/os/Message;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/os/Messenger;->send(Landroid/os/Message;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    iput-object v1, p0, Lc/g9;->j:Landroid/os/Messenger;

    iget-boolean p1, p0, Lc/g9;->k:Z

    if-eqz p1, :cond_2

    iput-boolean v0, p0, Lc/g9;->k:Z

    :try_start_1
    iget-object p1, p0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_2
    const/4 p1, -0x1

    iput p1, p0, Lc/g9;->r:I

    const-string p1, "disabled"

    invoke-virtual {p0, p1}, Lc/g9;->o(Ljava/lang/String;)V

    return-void
.end method

.method public final r(Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lc/g9;->q(Z)V

    invoke-virtual {p0, p1}, Lc/g9;->o(Ljava/lang/String;)V

    invoke-virtual {p0}, Lc/g9;->l()V

    return-void
.end method
