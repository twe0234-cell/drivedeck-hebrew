.class public final synthetic Lc/p3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;JII)V
    .locals 0

    iput p5, p0, Lc/p3;->a:I

    iput-object p1, p0, Lc/p3;->d:Ljava/lang/Object;

    iput-wide p2, p0, Lc/p3;->b:J

    iput p4, p0, Lc/p3;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/p3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/p3;->d:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-wide v3, p0, Lc/p3;->b:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_0

    iget v1, p0, Lc/p3;->c:I

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->g(I)V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/p3;->d:Ljava/lang/Object;

    check-cast v0, Lc/r3;

    iget-boolean v1, v0, Lc/r3;->g:Z

    if-eqz v1, :cond_1

    iget-wide v1, v0, Lc/r3;->f:J

    iget-wide v3, p0, Lc/p3;->b:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_1

    iget v1, v0, Lc/r3;->k:I

    iget v2, p0, Lc/p3;->c:I

    if-eq v1, v2, :cond_1

    iput v2, v0, Lc/r3;->k:I

    invoke-virtual {v0}, Lc/r3;->b()V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
