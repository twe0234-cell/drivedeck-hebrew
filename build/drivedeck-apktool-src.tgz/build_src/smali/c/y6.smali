.class public final synthetic Lc/y6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/y5;


# instance fields
.field public final synthetic a:Lc/H6;

.field public final synthetic b:I

.field public final synthetic c:I

.field public final synthetic d:Lc/v6;


# direct methods
.method public synthetic constructor <init>(Lc/H6;IILc/v6;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/y6;->a:Lc/H6;

    iput p2, p0, Lc/y6;->b:I

    iput p3, p0, Lc/y6;->c:I

    iput-object p4, p0, Lc/y6;->d:Lc/v6;

    return-void
.end method


# virtual methods
.method public final b(Lc/j6;Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, Lc/y6;->a:Lc/H6;

    iget v1, v0, Lc/H6;->c0:I

    iget v2, p0, Lc/y6;->b:I

    if-eq v2, v1, :cond_0

    goto/16 :goto_3

    :cond_0
    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/H6;->e0:Z

    iget-object v1, v0, Lc/H6;->c:Lc/T5;

    if-nez p2, :cond_5

    if-nez p1, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p2, "[a-f0-9]{64}"

    iget-object v2, p1, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v2, p2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_4

    invoke-virtual {v1}, Lc/T5;->E()V

    iput-object p1, v1, Lc/T5;->h:Lc/j6;

    iget-object p2, v1, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {p2, p1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object v3

    iput-object v3, v1, Lc/T5;->g:Lc/j6;

    invoke-interface {p2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v3, "profile_id"

    iget-object v4, p1, Lc/j6;->a:Ljava/lang/String;

    invoke-interface {p2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v3, "profile_sha"

    invoke-interface {p2, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "profile_name"

    iget-object v3, p1, Lc/j6;->b:Ljava/lang/String;

    invoke-interface {p2, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "protocol"

    iget p1, p1, Lc/j6;->f:I

    invoke-interface {p2, v2, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "checked_widget_profile_sha"

    invoke-interface {p2, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "disabled_sensor_ids"

    invoke-interface {p2, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "recovered_atst"

    invoke-interface {p2, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const-string v2, "source_atst_idx"

    invoke-interface {p2, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v1}, Lc/T5;->H()V

    invoke-static {p1}, Lc/j6;->c(I)Z

    move-result p1

    if-eqz p1, :cond_2

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0432\u044b\u0431\u0440\u0430\u043d \u00b7 "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_2
    const-string p1, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b"

    :goto_0
    iput-object p1, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    iget p1, p0, Lc/y6;->c:I

    invoke-virtual {v1, p1}, Lc/T5;->h0(I)V

    iget-object p1, p0, Lc/y6;->d:Lc/v6;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Lc/v6;->run()V

    goto :goto_1

    :cond_3
    const-string p1, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043a\u0430\u0447\u0430\u043d \u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    iput-object p1, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    :goto_1
    invoke-virtual {v0}, Lc/H6;->s()V

    invoke-virtual {v0}, Lc/H6;->t()V

    goto :goto_3

    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Missing verified profile"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    :goto_2
    if-nez p2, :cond_6

    const-string p2, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    :cond_6
    iput-object p2, v1, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v1}, Lc/T5;->q()V

    :goto_3
    return-void
.end method
