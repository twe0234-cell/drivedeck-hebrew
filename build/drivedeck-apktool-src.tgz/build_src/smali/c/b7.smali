.class public abstract Lc/b7;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static a:Lc/B0;

.field public static final b:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const-string v0, "01=01 02=02 03=03 04=13 05=31 06=35 07=3F 08=2C 09=20 0D=24 0E=58 0F=4F 10=1D 11=15 13=0B 14=0C 15=05 16=2A 17=07 18=2F 19=1F 1B=1E 1C=40 1D=2B 1E=50 1F=5F 20=16 22=0A 23=0D 25=14 26=30 27=3E 28=45 29=38 2D=59 2E=54 2F=4C 32=18 34=04 36=26 37=5B 38=27 39=39 3C=1C 3D=3A 3E=62 42=22 44=09 46=21 47=53 48=37 4C=08 4E=4C 4F=28 52=23 53=19 55=06 56=52 57=57 59=41 5C=1A 5D=4B 5E=5E 5F=4D 61=33 62=24 63=46 65=29 66=36 67=5C 68=32 69=43 6C=49 6D=34 6E=3D 6F=3C 71=0E 72=25 73=47 74=1B 75=55 76=2D 77=5A 78=25 7D=2E 7E=48 7F=4E"

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/b7;->b:[Ljava/lang/String;

    return-void
.end method

.method public static a(Landroid/widget/LinearLayout;Landroid/view/View;I)V
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    iput p2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {p0, p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;
    .locals 1

    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v0, p1, p3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance p0, Lc/h1;

    const/4 p1, 0x6

    invoke-direct {p0, p4, p1}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method public static c(Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/Spinner;Ljava/util/List;)V
    .locals 1

    const/16 v0, 0x30

    invoke-static {p0, v0}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/view/View;->setMinimumHeight(I)V

    iget v0, p1, Lc/r4;->b:I

    invoke-static {p0, v0}, Lc/b7;->m(Landroid/app/Activity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v0, Lc/F6;

    invoke-direct {v0, p0, p3, p1, p0}, Lc/F6;-><init>(Landroid/app/Activity;Ljava/util/List;Lc/r4;Lru/drivedeck/launcher/MainActivity;)V

    const p0, 0x1090009

    invoke-virtual {v0, p0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    invoke-virtual {p2, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    return-void
.end method

.method public static d(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;)Lorg/json/JSONObject;
    .locals 13

    const-string v0, ""

    invoke-static {p0}, Lc/b7;->e(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v1

    :try_start_0
    invoke-virtual {p1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/widget/EditText;

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    goto :goto_0

    :catch_0
    move-exception v0

    goto/16 :goto_2

    :catch_1
    move-exception v0

    goto/16 :goto_2

    :cond_0
    const-string v5, "RL"

    const-string v6, "SBI"

    const-string v7, "DL"

    const-string v8, "BIT"

    const-string v9, "SkipCycles"

    const-string v10, "ABRPRole"

    const-string v11, "VAGGroup"

    const-string v12, "VAGItem"

    filled-new-array/range {v5 .. v12}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    goto :goto_0

    :cond_1
    const-string v5, "MIN"

    const-string v6, "MAX"

    const-string v7, "MUL"

    const-string v8, "DIV"

    const-string v9, "OFS"

    filled-new-array {v5, v6, v7, v8, v9}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    invoke-interface {v5, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/16 v5, 0x2c

    const/16 v6, 0x2e

    invoke-virtual {v4, v5, v6}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v4

    invoke-virtual {v1, v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    goto/16 :goto_0

    :cond_2
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto/16 :goto_0

    :cond_3
    const-string v2, "UN"

    invoke-virtual/range {p3 .. p3}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v3

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    filled-new-array {v4, v5, v2, v3}, [I

    move-result-object v2

    invoke-virtual {p2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v6

    aget v2, v2, v6

    const-string v6, "TP"

    invoke-virtual {v1, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v6, "RBS"

    invoke-virtual/range {p4 .. p4}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v7

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    const-string v6, "SIG"

    invoke-virtual/range {p5 .. p5}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v7

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    if-ne v2, v3, :cond_6

    const-string v2, "VAGGroup"

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const-string v3, "VAGItem"

    invoke-virtual {v1, v3, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    if-lt v2, v5, :cond_5

    const/16 v4, 0xff

    if-gt v2, v4, :cond_5

    if-lt v3, v5, :cond_5

    const/4 v4, 0x4

    if-gt v3, v4, :cond_5

    const-string v4, "VAGUnit"

    invoke-virtual {v1, v4, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v6, " "

    invoke-virtual {v4, v6, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/b7;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v6, "[0-9A-F]{2}"

    invoke-virtual {v0, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_4

    const-string v6, "CMD"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "VWTP:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ":21"

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "%02X"

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v4, v0, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v6, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "SBI"

    sub-int/2addr v3, v5

    invoke-virtual {v1, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v0, "BCM"

    const-string v2, "ATCAF0;ATV1;ATSP6;ATCM000"

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "ACM"

    const-string v2, "ATSPDEF;ATCAF1;ATV0"

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "HDR"

    const-string v2, "000"

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_1

    :cond_4
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "VWTP \u0431\u043b\u043e\u043a: HEX \u043a\u043e\u0434"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "VWTP: \u0433\u0440\u0443\u043f\u043f\u0430 1\u2013255, \u044d\u043b\u0435\u043c\u0435\u043d\u0442 1\u20134"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_6
    :goto_1
    return-object v1

    :goto_2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0447\u0438\u0441\u043b\u043e\u0432\u044b\u0435 \u043f\u043e\u043b\u044f"

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method public static e(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 1

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    new-instance p0, Lorg/json/JSONObject;

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    return-object p0
.end method

.method public static f(Landroid/content/Context;I)I
    .locals 0

    int-to-float p1, p1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static g(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V
    .locals 60

    move-object/from16 v0, p1

    move-object/from16 v12, p2

    move-object/from16 v14, p3

    const-string v15, "SkipCycles"

    const-string v8, "ABRPRole"

    const-string v7, "RL"

    const-string v6, "BIT"

    const-string v5, "OFS"

    const-string v3, "SBI"

    const-string v11, "DIV"

    const-string v1, "MUL"

    const-string v9, "DL"

    const-string v13, ""

    const-string v10, "UN"

    const-string v4, "TP"

    if-nez p0, :cond_0

    new-instance v25, Lorg/json/JSONObject;

    invoke-direct/range {v25 .. v25}, Lorg/json/JSONObject;-><init>()V

    goto :goto_0

    :cond_0
    invoke-static/range {p0 .. p0}, Lc/b7;->e(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v25

    :goto_0
    invoke-static/range {v25 .. v25}, Lc/b7;->e(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object v14

    const/16 v24, 0x0

    :try_start_0
    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v4, v2}, [Ljava/lang/Object;

    move-result-object v26

    const-string v2, "FR"

    move-object/from16 v40, v4

    const-string v4, "A"

    filled-new-array {v2, v4}, [Ljava/lang/Object;

    move-result-object v27

    invoke-static/range {v24 .. v24}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v3, v2}, [Ljava/lang/Object;

    move-result-object v28

    const/4 v2, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v9, v4}, [Ljava/lang/Object;

    move-result-object v29

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v1, v4}, [Ljava/lang/Object;

    move-result-object v30

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v11, v4}, [Ljava/lang/Object;

    move-result-object v31

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v5, v4}, [Ljava/lang/Object;

    move-result-object v32

    const-string v4, "MIN"

    move-object/from16 v41, v1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v4, v1}, [Ljava/lang/Object;

    move-result-object v33

    const-string v1, "MAX"

    const/16 v4, 0x64

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v1, v4}, [Ljava/lang/Object;

    move-result-object v34

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v10, v1}, [Ljava/lang/Object;

    move-result-object v35

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v6, v1}, [Ljava/lang/Object;

    move-result-object v36

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v7, v1}, [Ljava/lang/Object;

    move-result-object v37

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v8, v1}, [Ljava/lang/Object;

    move-result-object v38

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    filled-new-array {v15, v1}, [Ljava/lang/Object;

    move-result-object v39

    filled-new-array/range {v26 .. v39}, [[Ljava/lang/Object;

    move-result-object v1

    const/4 v2, 0x0

    :goto_1
    const/16 v4, 0xe

    if-ge v2, v4, :cond_2

    aget-object v4, v1, v2

    const/16 v24, 0x0

    aget-object v26, v4, v24

    move-object/from16 v27, v1

    move-object/from16 v1, v26

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v14, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    aget-object v1, v4, v24

    check-cast v1, Ljava/lang/String;

    const/16 v23, 0x1

    aget-object v4, v4, v23

    invoke-virtual {v14, v1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v1, 0x1

    goto :goto_2

    :catch_0
    move-exception v0

    goto/16 :goto_1c

    :goto_2
    add-int/2addr v2, v1

    move-object/from16 v1, v27

    goto :goto_1

    :cond_2
    const-string v1, "CMD"

    invoke-virtual {v14, v1, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "(?i)VWTP:[0-9A-F]{2}:21[0-9A-F]{2}"

    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_5

    move-object/from16 v27, v5

    const/4 v2, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v4, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v5, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    sget-object v4, Lc/b7;->b:[Ljava/lang/String;

    array-length v5, v4

    move-object/from16 v28, v6

    const/4 v6, 0x0

    :goto_3
    if-ge v6, v5, :cond_4

    move/from16 v29, v5

    aget-object v5, v4, v6

    move-object/from16 v30, v4

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v31, v7

    const-string v7, "="

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    const-string v2, "VAGUnit"

    const/4 v4, 0x2

    const/4 v6, 0x0

    invoke-virtual {v5, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    goto :goto_4

    :cond_3
    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v6, v5

    move/from16 v5, v29

    move-object/from16 v4, v30

    move-object/from16 v7, v31

    goto :goto_3

    :cond_4
    move-object/from16 v31, v7

    const/4 v4, 0x2

    :goto_4
    const-string v2, "VAGGroup"

    const/16 v7, 0xa

    invoke-virtual {v1, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const/16 v5, 0x10

    invoke-static {v1, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v1

    invoke-virtual {v14, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v1, "VAGItem"

    const/4 v2, 0x0

    invoke-virtual {v14, v3, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v5

    const/4 v2, 0x1

    add-int/2addr v5, v2

    invoke-virtual {v14, v1, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_5

    :cond_5
    move-object/from16 v27, v5

    move-object/from16 v28, v6

    move-object/from16 v31, v7

    const/4 v4, 0x2

    const/16 v7, 0xa

    :goto_5
    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual/range {p3 .. p3}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v19

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v5, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x14

    invoke-static {v0, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    const/16 v4, 0x8

    invoke-static {v0, v4}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v7

    move-object/from16 v29, v3

    invoke-static {v0, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v0, v4}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v5, v2, v7, v3, v1}, Landroid/view/View;->setPadding(IIII)V

    const-string v1, "\u041e\u0441\u043d\u043e\u0432\u043d\u044b\u0435 \u043f\u043e\u043b\u044f"

    const/4 v3, 0x0

    const/16 v7, 0x10

    invoke-static {v0, v12, v1, v7, v3}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x4

    invoke-static {v5, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v24, "\u0414\u0430\u0442\u0447\u0438\u043a \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f"

    const-string v26, "NM"

    const-string v30, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435"

    move-object/from16 v20, v13

    const/4 v2, 0x2

    move v13, v4

    move-object/from16 v4, v41

    move-object v1, v5

    move v13, v2

    move-object/from16 v2, p1

    move/from16 v25, v3

    move-object/from16 v42, v29

    move-object/from16 v3, p2

    move-object/from16 v43, v4

    move-object/from16 v29, v9

    move-object/from16 v13, v40

    move v9, v7

    move/from16 v7, v25

    move-object v4, v6

    move-object/from16 v33, v5

    move-object/from16 v44, v27

    move-object/from16 v5, v26

    move-object/from16 v26, v6

    move-object/from16 v45, v28

    move-object/from16 v6, v30

    move v9, v7

    move-object/from16 v46, v31

    const/16 v17, 0xa

    move-object v7, v14

    move-object/from16 v47, v8

    move-object/from16 v8, v24

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, ""

    const-string v5, "SNM"

    const-string v6, "\u041a\u043e\u0440\u043e\u0442\u043a\u043e\u0435 \u0438\u043c\u044f"

    move-object/from16 v1, v33

    move-object/from16 v4, v26

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-instance v8, Landroid/widget/Spinner;

    invoke-direct {v8, v0}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    invoke-virtual {v8, v13}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const-string v1, "\u0424\u043e\u0440\u043c\u0443\u043b\u0430"

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u0427\u0438\u0441\u043b\u043e \u0438\u0437 \u0431\u0430\u0439\u0442\u043e\u0432"

    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u0417\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u0431\u0438\u0442\u0430"

    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "VWTP"

    filled-new-array {v1, v2, v3, v4}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-static {v0, v12, v8, v1}, Lc/b7;->c(Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/Spinner;Ljava/util/List;)V

    invoke-virtual {v14, v13, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_6

    const/4 v4, 0x1

    :goto_6
    const/4 v7, 0x3

    const/4 v13, 0x5

    goto :goto_8

    :cond_6
    const/4 v2, 0x2

    if-ne v1, v2, :cond_7

    const/4 v4, 0x2

    goto :goto_6

    :cond_7
    const/4 v13, 0x5

    if-ne v1, v13, :cond_8

    const/4 v4, 0x3

    :goto_7
    const/4 v7, 0x3

    goto :goto_8

    :cond_8
    move v4, v9

    goto :goto_7

    :goto_8
    invoke-static {v7, v4}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v8, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    const-string v1, "\u0414\u0435\u043a\u043e\u0434\u0435\u0440"

    invoke-static {v0, v12, v1, v8}, Lc/b7;->k(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    move-object/from16 v6, v33

    const/4 v2, 0x4

    invoke-static {v6, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v22, ""

    const-string v5, "CMD"

    const-string v24, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u0447\u0442\u0435\u043d\u0438\u044f"

    move-object v1, v6

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, v26

    move-object/from16 v6, v24

    move-object v7, v14

    move-object/from16 v24, v8

    move-object/from16 v8, v22

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, ""

    const-string v5, "HDR"

    const-string v6, "\u0410\u0434\u0440\u0435\u0441 \u042d\u0411\u0423"

    move-object/from16 v1, v33

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, ""

    const-string v5, "FR"

    const-string v6, "\u0424\u043e\u0440\u043c\u0443\u043b\u0430"

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-instance v1, Lc/Z;

    move-object v8, v14

    move-object/from16 v7, v26

    const/16 v2, 0x14

    move-object/from16 v14, p3

    invoke-direct {v1, v0, v14, v7, v2}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v2, "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c PID"

    invoke-static {v0, v12, v2, v9, v1}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    move-object/from16 v6, v33

    const/4 v2, 0x4

    invoke-static {v6, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v1, "A, B, C\u2026 \u2014 \u0431\u0430\u0439\u0442\u044b \u0434\u0430\u043d\u043d\u044b\u0445. \u00ab\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c PID\u00bb \u0434\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u044c. \u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: A\u221240. \u0410\u0434\u0440\u0435\u0441 \u042d\u0411\u0423 \u043c\u043e\u0436\u043d\u043e \u043e\u0441\u0442\u0430\u0432\u0438\u0442\u044c \u043f\u0443\u0441\u0442\u044b\u043c \u0434\u043b\u044f \u0430\u0434\u0440\u0435\u0441\u0430 \u043f\u0440\u043e\u0444\u0438\u043b\u044f."

    const/16 v5, 0xc

    const/4 v2, 0x1

    invoke-static {v0, v12, v1, v5, v2}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v1

    const/4 v2, 0x2

    invoke-static {v6, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v1, "\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043e\u0432\u043a\u0430"

    const/16 v2, 0x10

    invoke-static {v0, v12, v1, v2, v9}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-static {v6, v1, v5}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v4, Landroid/widget/Spinner;

    invoke-direct {v4, v0}, Landroid/widget/Spinner;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v10}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    move v2, v9

    :goto_9
    if-ltz v2, :cond_a

    const/16 v3, 0x70

    if-ge v2, v3, :cond_a

    invoke-static {v2}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v3

    if-nez v2, :cond_9

    const-string v3, "\u0411\u0435\u0437 \u0435\u0434\u0438\u043d\u0438\u0446\u044b"

    :cond_9
    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    add-int/2addr v2, v3

    goto :goto_9

    :cond_a
    const/4 v3, 0x1

    invoke-static {v0, v12, v4, v1}, Lc/b7;->c(Lru/drivedeck/launcher/MainActivity;Lc/r4;Landroid/widget/Spinner;Ljava/util/List;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    sub-int/2addr v1, v3

    invoke-virtual {v8, v10, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v4, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    const-string v1, "\u0415\u0434\u0438\u043d\u0438\u0446\u0430"

    invoke-static {v0, v12, v1, v4}, Lc/b7;->k(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    const/4 v2, 0x4

    invoke-static {v6, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v10, "0"

    const-string v18, "MIN"

    const-string v22, "\u041c\u0438\u043d\u0438\u043c\u0443\u043c"

    move-object v1, v6

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v26, v4

    move-object v4, v7

    move v13, v5

    move-object/from16 v5, v18

    move-object/from16 v33, v6

    move-object/from16 v6, v22

    move-object/from16 v18, v7

    move-object v7, v8

    move-object/from16 v22, v8

    move-object v8, v10

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, "100"

    const-string v5, "MAX"

    const-string v6, "\u041c\u0430\u043a\u0441\u0438\u043c\u0443\u043c"

    move-object/from16 v1, v33

    move-object/from16 v4, v18

    move-object/from16 v7, v22

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    new-instance v1, Lc/a1;

    const/4 v10, 0x7

    invoke-direct {v1, v10}, Lc/a1;-><init>(I)V

    const-string v2, "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043d\u043d\u044b\u0435 \u043f\u043e\u043b\u044f"

    invoke-static {v0, v12, v2, v9, v1}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    invoke-virtual {v8, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x8

    invoke-virtual {v8, v2}, Landroid/view/View;->setVisibility(I)V

    new-instance v3, Lc/c;

    invoke-direct {v3, v8, v2}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    move-object/from16 v7, v33

    invoke-static {v7, v1, v13}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const/4 v1, 0x4

    invoke-static {v7, v8, v1}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v56, "ABRPRole"

    const-string v57, "BCM"

    const-string v48, "SBI"

    const-string v49, "DL"

    const-string v50, "BIT"

    const-string v51, "MUL"

    const-string v52, "DIV"

    const-string v53, "OFS"

    const-string v54, "SkipCycles"

    const-string v55, "RL"

    const-string v58, "ACM"

    const-string v59, "TVV"

    filled-new-array/range {v48 .. v59}, [Ljava/lang/String;

    move-result-object v21

    move v6, v9

    :goto_a
    if-ge v6, v13, :cond_1a

    aget-object v5, v21, v6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_0

    :goto_b
    move-object/from16 v9, v29

    move-object/from16 v3, v42

    :goto_c
    move-object/from16 v1, v43

    move-object/from16 v2, v44

    :goto_d
    move-object/from16 v10, v45

    :goto_e
    move-object/from16 v4, v46

    move-object/from16 v13, v47

    :goto_f
    const/16 v31, -0x1

    goto/16 :goto_16

    :sswitch_0
    invoke-virtual {v5, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto :goto_b

    :cond_b
    const/16 v4, 0xb

    move/from16 v31, v4

    goto :goto_10

    :sswitch_1
    const-string v1, "TVV"

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto :goto_b

    :cond_c
    move/from16 v31, v17

    :goto_10
    move-object/from16 v9, v29

    move-object/from16 v3, v42

    goto :goto_11

    :sswitch_2
    move-object/from16 v3, v42

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    move-object/from16 v9, v29

    goto :goto_c

    :cond_d
    const/16 v4, 0x9

    move/from16 v31, v4

    move-object/from16 v9, v29

    :goto_11
    move-object/from16 v1, v43

    move-object/from16 v2, v44

    goto :goto_14

    :sswitch_3
    move-object/from16 v3, v42

    move-object/from16 v2, v44

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    move-object/from16 v9, v29

    if-nez v1, :cond_e

    move-object/from16 v1, v43

    goto :goto_d

    :cond_e
    move-object/from16 v1, v43

    move-object/from16 v10, v45

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    const/16 v31, 0x8

    goto/16 :goto_16

    :sswitch_4
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v30

    if-nez v30, :cond_f

    goto :goto_12

    :cond_f
    move/from16 v31, v10

    goto :goto_13

    :sswitch_5
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    invoke-virtual {v5, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v30

    if-nez v30, :cond_10

    :goto_12
    move-object/from16 v9, v29

    goto :goto_d

    :cond_10
    const/4 v4, 0x6

    move/from16 v31, v4

    :goto_13
    move-object/from16 v9, v29

    :goto_14
    move-object/from16 v10, v45

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    goto/16 :goto_16

    :sswitch_6
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    invoke-virtual {v5, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v31

    if-nez v31, :cond_11

    goto :goto_15

    :cond_11
    move-object/from16 v9, v29

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    const/16 v31, 0x5

    goto/16 :goto_16

    :sswitch_7
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    const-string v4, "BCM"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_12

    goto :goto_15

    :cond_12
    move-object/from16 v9, v29

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    const/16 v31, 0x4

    goto/16 :goto_16

    :sswitch_8
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    const-string v4, "ACM"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_13

    :goto_15
    move-object/from16 v9, v29

    goto/16 :goto_e

    :cond_13
    move-object/from16 v9, v29

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    const/16 v31, 0x3

    goto :goto_16

    :sswitch_9
    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    move-object/from16 v4, v46

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v33

    move-object/from16 v9, v29

    move-object/from16 v13, v47

    if-nez v33, :cond_14

    goto/16 :goto_f

    :cond_14
    const/16 v31, 0x2

    goto :goto_16

    :sswitch_a
    move-object/from16 v9, v29

    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    move-object/from16 v4, v46

    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v29

    move-object/from16 v13, v47

    if-nez v29, :cond_15

    goto/16 :goto_f

    :cond_15
    const/16 v31, 0x1

    goto :goto_16

    :sswitch_b
    move-object/from16 v9, v29

    move-object/from16 v3, v42

    move-object/from16 v1, v43

    move-object/from16 v2, v44

    move-object/from16 v10, v45

    move-object/from16 v4, v46

    move-object/from16 v13, v47

    invoke-virtual {v5, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v34

    if-nez v34, :cond_16

    goto/16 :goto_f

    :cond_16
    const/16 v31, 0x0

    :goto_16
    packed-switch v31, :pswitch_data_0

    move-object/from16 v31, v5

    goto :goto_17

    :pswitch_0
    const-string v31, "\u041f\u0440\u043e\u043f\u0443\u0441\u043a \u0446\u0438\u043a\u043b\u043e\u0432"

    goto :goto_17

    :pswitch_1
    const-string v31, "\u0422\u0435\u043a\u0441\u0442: \u0447\u0438\u0441\u043b\u043e=\u043f\u043e\u0434\u043f\u0438\u0441\u044c"

    goto :goto_17

    :pswitch_2
    const-string v31, "\u041f\u0435\u0440\u0432\u044b\u0439 \u0431\u0430\u0439\u0442 (\u0441 0)"

    goto :goto_17

    :pswitch_3
    const-string v31, "\u0421\u043c\u0435\u0449\u0435\u043d\u0438\u0435"

    goto :goto_17

    :pswitch_4
    const-string v31, "\u041c\u043d\u043e\u0436\u0438\u0442\u0435\u043b\u044c"

    goto :goto_17

    :pswitch_5
    const-string v31, "\u0414\u0435\u043b\u0438\u0442\u0435\u043b\u044c"

    goto :goto_17

    :pswitch_6
    const-string v31, "\u041d\u043e\u043c\u0435\u0440 \u0431\u0438\u0442\u0430 (0\u20137)"

    goto :goto_17

    :pswitch_7
    const-string v31, "\u041a\u043e\u043c\u0430\u043d\u0434\u044b \u0434\u043e \u0447\u0442\u0435\u043d\u0438\u044f"

    goto :goto_17

    :pswitch_8
    const-string v31, "\u041a\u043e\u043c\u0430\u043d\u0434\u044b \u043f\u043e\u0441\u043b\u0435 \u0447\u0442\u0435\u043d\u0438\u044f"

    goto :goto_17

    :pswitch_9
    const-string v31, "\u0420\u043e\u043b\u044c \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044f (\u043a\u043e\u0434)"

    goto :goto_17

    :pswitch_a
    const-string v31, "\u0427\u0438\u0441\u043b\u043e \u0431\u0430\u0439\u0442\u043e\u0432 (0\u20134)"

    goto :goto_17

    :pswitch_b
    const-string v31, "\u0420\u043e\u043b\u044c ABRP (\u043a\u043e\u0434)"

    :goto_17
    invoke-virtual {v5, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v34

    const-string v35, "1"

    if-eqz v34, :cond_17

    :goto_18
    move-object/from16 v34, v1

    goto :goto_19

    :cond_17
    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v34

    if-eqz v34, :cond_18

    goto :goto_18

    :cond_18
    invoke-virtual {v5, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v34

    if-eqz v34, :cond_19

    goto :goto_18

    :cond_19
    move-object/from16 v34, v1

    move-object/from16 v35, v20

    :goto_19
    move-object v1, v8

    move-object/from16 v36, v2

    move-object/from16 v2, p1

    move-object/from16 v37, v3

    move-object/from16 v3, p2

    move-object/from16 v38, v4

    move-object/from16 v4, v18

    move/from16 v39, v6

    move-object/from16 v6, v31

    move-object/from16 v47, v13

    move-object v13, v7

    move-object/from16 v7, v22

    move-object/from16 v31, v9

    move-object v9, v8

    move-object/from16 v8, v35

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const/4 v1, 0x1

    add-int/lit8 v6, v39, 0x1

    move-object v8, v9

    move-object/from16 v45, v10

    move-object v7, v13

    move-object/from16 v29, v31

    move-object/from16 v43, v34

    move-object/from16 v44, v36

    move-object/from16 v42, v37

    move-object/from16 v46, v38

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v13, 0xc

    goto/16 :goto_a

    :cond_1a
    move-object v13, v7

    move-object v9, v8

    const/4 v1, 0x1

    const-string v2, "VWTP: \u0431\u043b\u043e\u043a \u2014 \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 HEX-\u043a\u043e\u0434; \u0433\u0440\u0443\u043f\u043f\u0430 1\u2013255, \u044d\u043b\u0435\u043c\u0435\u043d\u0442 1\u20134. \u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u0438 \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u0444\u043e\u0440\u043c\u0438\u0440\u0443\u044e\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438."

    const/16 v3, 0xc

    invoke-static {v0, v12, v2, v3, v1}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v2

    const/4 v1, 0x4

    invoke-static {v9, v2, v1}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v8, ""

    const-string v5, "VAGUnit"

    const-string v6, "VWTP \u0431\u043b\u043e\u043a"

    move-object v1, v9

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, v18

    move-object/from16 v7, v22

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, ""

    const-string v5, "VAGGroup"

    const-string v6, "VWTP \u0433\u0440\u0443\u043f\u043f\u0430"

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v8, ""

    const-string v5, "VAGItem"

    const-string v6, "VWTP \u044d\u043b\u0435\u043c\u0435\u043d\u0442"

    invoke-static/range {v1 .. v8}, Lc/b7;->i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string v1, "RBS"

    move-object/from16 v15, v22

    const/4 v2, 0x0

    invoke-virtual {v15, v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    new-instance v11, Landroid/widget/CheckBox;

    invoke-direct {v11, v0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    const-string v2, "\u041e\u0431\u0440\u0430\u0442\u043d\u044b\u0439 \u043f\u043e\u0440\u044f\u0434\u043e\u043a \u0431\u0430\u0439\u0442\u043e\u0432"

    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget v2, v12, Lc/r4;->d:I

    invoke-virtual {v11, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v3, 0x30

    invoke-static {v0, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v11, v4}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v11, v1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    invoke-virtual {v9, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v1, "SIG"

    const/4 v4, 0x0

    invoke-virtual {v15, v1, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    new-instance v10, Landroid/widget/CheckBox;

    invoke-direct {v10, v0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    const-string v4, "\u0417\u043d\u0430\u043a\u043e\u0432\u043e\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435"

    invoke-static {v0, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-static {v0, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v10, v2}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v10, v1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v1, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430"

    const/16 v2, 0x10

    const/4 v9, 0x0

    invoke-static {v0, v12, v1, v2, v9}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v1

    const/16 v2, 0xc

    invoke-static {v13, v1, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    const-string v1, "HEX: \u0434\u043b\u044f rN \u2014 \u043e\u0442\u0432\u0435\u0442 \u0441 \u043d\u043e\u043c\u0435\u0440\u043e\u043c PID; \u0434\u043b\u044f A, B\u2026 \u2014 \u0442\u043e\u043b\u044c\u043a\u043e \u0434\u0430\u043d\u043d\u044b\u0435"

    invoke-static {v0, v12, v1}, Lc/b7;->o(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v8

    const-string v1, "sampleHex"

    invoke-virtual {v8, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v7, 0x1

    invoke-virtual {v8, v7}, Landroid/widget/TextView;->setInputType(I)V

    invoke-virtual {v13, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/16 v1, 0xd

    move-object/from16 v2, v20

    invoke-static {v0, v12, v2, v1, v7}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v6

    const-string v1, "testResult"

    invoke-virtual {v6, v1}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v1, 0x4

    invoke-static {v13, v6, v1}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-direct {v5, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    new-instance v4, Lc/Q6;

    move-object v1, v4

    move-object v2, v15

    move-object/from16 v3, v18

    move-object v14, v4

    move-object/from16 v4, v24

    move-object/from16 v33, v13

    move-object v13, v5

    move-object/from16 v5, v26

    move-object/from16 v16, v6

    move-object v6, v11

    move/from16 v17, v7

    move-object v7, v10

    move-object/from16 v20, v8

    move-object/from16 v8, p3

    move-object/from16 v21, v13

    move v13, v9

    move-object/from16 v9, v20

    move-object/from16 v17, v10

    move-object/from16 v10, v16

    move-object/from16 v20, v11

    move-object/from16 v11, p1

    invoke-direct/range {v1 .. v11}, Lc/Q6;-><init>(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Lc/T5;Landroid/widget/EditText;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;)V

    const-string v1, "\u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043e\u0431\u0440\u0430\u0437\u0435\u0446"

    invoke-static {v0, v12, v1, v13, v14}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v11

    new-instance v14, Lc/R6;

    move-object v1, v14

    move-object/from16 v6, v20

    move-object/from16 v7, v17

    move-object/from16 v8, v16

    move-object/from16 v9, p1

    move-object/from16 v10, p3

    invoke-direct/range {v1 .. v10}, Lc/R6;-><init>(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/T5;)V

    const-string v1, "\u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043d\u0430 \u042d\u0411\u0423"

    invoke-static {v0, v12, v1, v13, v14}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-direct {v2, v13, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    move-object/from16 v5, v21

    invoke-virtual {v5, v11, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v13, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v3, 0x8

    invoke-static {v0, v3}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v5, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v1, v33

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Landroid/app/AlertDialog$Builder;

    new-instance v3, Landroid/view/ContextThemeWrapper;

    iget-boolean v4, v12, Lc/r4;->m:Z

    if-eqz v4, :cond_1b

    const v4, 0x103023a

    goto :goto_1a

    :cond_1b
    const v4, 0x1030226

    :goto_1a
    invoke-direct {v3, v0, v4}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    invoke-direct {v2, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    if-nez p0, :cond_1c

    const-string v3, "\u041d\u043e\u0432\u044b\u0439 \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 PID"

    goto :goto_1b

    :cond_1c
    const-string v3, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 PID"

    :goto_1b
    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lc/a7;

    invoke-direct {v3, v0}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    invoke-virtual {v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lc/B2;

    move-object/from16 v14, p3

    const/4 v4, 0x2

    invoke-direct {v3, v14, v4}, Lc/B2;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    invoke-static {v0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v13

    new-instance v11, Lc/S6;

    move-object v1, v11

    move-object v2, v13

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v6, v19

    move-object v7, v15

    move-object/from16 v8, v18

    move-object/from16 v9, v24

    move-object/from16 v10, v26

    move-object v0, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v17

    move-object v15, v13

    move-object/from16 v13, v16

    invoke-direct/range {v1 .. v13}, Lc/S6;-><init>(Landroid/app/AlertDialog;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Ljava/lang/String;Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/widget/TextView;)V

    invoke-virtual {v15, v0}, Landroid/app/Dialog;->setOnShowListener(Landroid/content/DialogInterface$OnShowListener;)V

    new-instance v0, Lc/g;

    const/4 v1, 0x3

    invoke-direct {v0, v14, v1}, Lc/g;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v15, v0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-virtual {v15}, Landroid/app/Dialog;->show()V

    return-void

    :goto_1c
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u041d\u0435\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u043e\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0435 PID"

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x6bfca4cb -> :sswitch_b
        0x888 -> :sswitch_a
        0xa3a -> :sswitch_9
        0xfc6b -> :sswitch_8
        0x1002c -> :sswitch_7
        0x100ed -> :sswitch_6
        0x10871 -> :sswitch_5
        0x12ba4 -> :sswitch_4
        0x1315c -> :sswitch_3
        0x13fda -> :sswitch_2
        0x14614 -> :sswitch_1
        0x65abd6cc -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    if-nez p1, :cond_0

    const-string p1, "\u041d\u0435\u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u043e\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0435 PID"

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-string v5, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e: "

    const-string v6, "\u041d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u0430\u044f \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430: "

    const-string v0, "CSV: \u043d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e \u0441\u0442\u043e\u043b\u0431\u0446\u043e\u0432 \u0432 \u0441\u0442\u0440\u043e\u043a\u0435 "

    const-string v1, "PID \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u0432 \u0444\u043e\u0440\u043c\u0443\u043b\u0435: "

    const-string v2, "\u041d\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u0438: "

    const-string v3, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u043e\u0435 \u043f\u043e\u043b\u0435: "

    const-string v4, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u043f\u043e\u043b\u0435: "

    filled-new-array/range {v0 .. v6}, [Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x7

    if-ge v1, v2, :cond_2

    aget-object v2, v0, v1

    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result p0

    invoke-virtual {p1, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static i(Landroid/widget/LinearLayout;Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/util/LinkedHashMap;Ljava/lang/String;Ljava/lang/String;Lorg/json/JSONObject;Ljava/lang/String;)V
    .locals 3

    invoke-static {p1, p2, p7}, Lc/b7;->o(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {p6, p4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    const-string v2, ""

    if-eqz v1, :cond_0

    invoke-virtual {p6, p4, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p7

    goto :goto_0

    :cond_0
    const-string p6, "0"

    invoke-virtual {p6, p7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p6

    if-nez p6, :cond_2

    const-string p6, "1"

    invoke-virtual {p6, p7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p6

    if-nez p6, :cond_2

    const-string p6, "100"

    invoke-virtual {p6, p7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p6

    if-eqz p6, :cond_1

    goto :goto_0

    :cond_1
    move-object p7, v2

    :cond_2
    :goto_0
    invoke-virtual {v0, p7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-static {p1, p5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p6

    invoke-virtual {v0, p6}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-interface {p3, p4, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p1, p2, p5, v0}, Lc/b7;->k(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object p1

    const/16 p2, 0x8

    invoke-static {p0, p1, p2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    return-void
.end method

.method public static j(Lru/drivedeck/launcher/MainActivity;Lc/Q5;)Ljava/lang/String;
    .locals 6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p1, Lc/Q5;->a:Ljava/lang/String;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "\u041e\u0442\u0432\u0435\u0442: "

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p1, Lc/Q5;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/16 v1, 0xa

    iget-object v2, p1, Lc/Q5;->b:Ljava/lang/String;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-lez v3, :cond_1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_1
    const-string v3, "\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043e\u0432\u043a\u0430: "

    invoke-static {p0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    iget-object v2, p1, Lc/Q5;->e:Ljava/lang/Double;

    if-eqz v2, :cond_6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    if-lez v3, :cond_3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_3
    const-string v3, "\u0417\u043d\u0430\u0447\u0435\u043d\u0438\u0435: "

    invoke-static {p0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p1, Lc/Q5;->d:Ljava/lang/String;

    if-nez v3, :cond_5

    new-instance v3, Ljava/math/BigDecimal;

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Ljava/math/BigDecimal;->signum()I

    move-result v2

    if-nez v2, :cond_4

    new-instance v2, Ljava/math/BigDecimal;

    sget-object v3, Ljava/math/BigInteger;->ZERO:Ljava/math/BigInteger;

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;I)V

    goto :goto_0

    :cond_4
    invoke-virtual {v3}, Ljava/math/BigDecimal;->stripTrailingZeros()Ljava/math/BigDecimal;

    move-result-object v2

    :goto_0
    invoke-virtual {v2}, Ljava/math/BigDecimal;->toPlainString()Ljava/lang/String;

    move-result-object v3

    :cond_5
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p1, Lc/Q5;->f:I

    invoke-static {v2}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_6
    iget-object p1, p1, Lc/Q5;->c:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_8

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v2

    if-lez v2, :cond_7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_7
    const-string v1, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0, p1}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p1

    if-nez p1, :cond_9

    const-string p1, "\u041d\u0435\u0442 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u0430"

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_9
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0
.end method

.method public static k(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;Landroid/view/View;)Landroid/widget/LinearLayout;
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v1, 0xd

    const/4 v2, 0x1

    invoke-static {p0, p1, p2, v1, v2}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object p1

    invoke-virtual {p3}, Landroid/view/View;->getId()I

    move-result v1

    const/4 v2, -0x1

    if-ne v1, v2, :cond_0

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v1

    invoke-virtual {p3, v1}, Landroid/view/View;->setId(I)V

    :cond_0
    invoke-virtual {p3}, Landroid/view/View;->getId()I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/view/View;->setLabelFor(I)V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0xa4

    invoke-static {p0, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p0

    const/4 v1, -0x2

    invoke-direct {p2, p0, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p1, 0x0

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-direct {p0, p1, v1, p2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p3, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public static l(Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V
    .locals 24

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    move-object/from16 v12, p3

    const-string v13, "HDR"

    const-string v14, " \u00b7 "

    invoke-virtual/range {p3 .. p3}, Landroid/view/ViewGroup;->removeAllViews()V

    :try_start_0
    iget-object v0, v11, Lc/T5;->h:Lc/j6;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_b

    const-string v15, ""

    iget-object v1, v11, Lc/T5;->b:Landroid/content/SharedPreferences;

    if-nez v0, :cond_0

    :try_start_1
    const-string v0, "profile_id"

    invoke-interface {v1, v0, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    :goto_0
    move-object v8, v0

    goto :goto_1

    :cond_0
    iget-object v0, v11, Lc/T5;->h:Lc/j6;

    invoke-static {v1, v0}, Lc/k6;->f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_b

    goto :goto_0

    :goto_1
    iget-object v0, v11, Lc/T5;->h:Lc/j6;

    :try_start_2
    invoke-static {v1, v0}, Lc/k6;->f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-static {v0, v1}, Lc/k6;->s0(Lc/j6;Lorg/json/JSONArray;)Ljava/util/LinkedHashMap;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_4

    :catch_0
    move-exception v0

    :try_start_3
    instance-of v1, v0, Ljava/lang/IllegalArgumentException;

    if-nez v1, :cond_2

    instance-of v1, v0, Ljava/lang/IllegalStateException;

    if-eqz v1, :cond_1

    goto :goto_2

    :cond_1
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 PID"

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_2
    :goto_2
    throw v0

    :catch_1
    move-exception v0

    goto :goto_3

    :catch_2
    move-exception v0

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 JSON PID"

    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_1

    :goto_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "storage"

    invoke-static {v1, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v0

    :goto_4
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/16 v7, 0x8

    if-nez v1, :cond_3

    invoke-virtual {v12, v7}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_3
    const/4 v6, 0x0

    invoke-virtual {v12, v6}, Landroid/view/View;->setVisibility(I)V

    move v5, v6

    :goto_5
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v5, v1, :cond_7

    :try_start_4
    invoke-virtual {v8, v5}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "Id"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v2, "NM"

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_9

    :try_start_5
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_8

    const/4 v7, 0x1

    :try_start_6
    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V
    :try_end_6
    .catch Lorg/json/JSONException; {:try_start_6 .. :try_end_6} :catch_6

    const/4 v7, 0x4

    move-object/from16 v18, v0

    :try_start_7
    invoke-static {v9, v7}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v0

    move-object/from16 v19, v4

    invoke-static {v9, v7}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v4
    :try_end_7
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_7} :catch_7

    const/4 v7, 0x0

    :try_start_8
    invoke-virtual {v6, v7, v0, v7, v4}, Landroid/view/View;->setPadding(IIII)V

    const/16 v0, 0xf

    invoke-static {v9, v10, v3, v0, v7}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v0
    :try_end_8
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_8} :catch_5

    const/4 v4, 0x2

    :try_start_9
    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setMaxLines(I)V

    sget-object v4, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {v6, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "TP "

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "TP"
    :try_end_9
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_9} :catch_7

    const/4 v7, 0x0

    :try_start_a
    invoke-virtual {v1, v4, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4
    :try_end_a
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_a} :catch_5

    :try_start_b
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "CMD"

    invoke-virtual {v1, v4, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4

    move-object v4, v15

    goto :goto_6

    :cond_4
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :goto_6
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    if-eqz v2, :cond_5

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_5
    if-eqz v2, :cond_6

    const/4 v7, 0x1

    goto :goto_7

    :cond_6
    const/4 v7, 0x0

    :goto_7
    const/16 v2, 0xc

    invoke-static {v9, v10, v0, v2, v7}, Lc/b7;->n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;

    move-result-object v0

    const/4 v2, 0x4

    invoke-static {v6, v0, v2}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const-string v2, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c"

    new-instance v4, Lc/Y6;

    invoke-direct {v4, v9, v10, v11, v1}, Lc/Y6;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;Lorg/json/JSONObject;)V
    :try_end_b
    .catch Lorg/json/JSONException; {:try_start_b .. :try_end_b} :catch_7

    const/4 v7, 0x0

    :try_start_c
    invoke-static {v9, v10, v2, v7, v4}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v4

    const-string v2, "\u0414\u0443\u0431\u043b\u0438\u0440\u043e\u0432\u0430\u0442\u044c"
    :try_end_c
    .catch Lorg/json/JSONException; {:try_start_c .. :try_end_c} :catch_5

    :try_start_d
    new-instance v7, Lc/Y6;

    invoke-direct {v7, v1, v9, v10, v11}, Lc/Y6;-><init>(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V
    :try_end_d
    .catch Lorg/json/JSONException; {:try_start_d .. :try_end_d} :catch_7

    const/4 v1, 0x0

    :try_start_e
    invoke-static {v9, v10, v2, v1, v7}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v7

    const-string v2, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    new-instance v11, Lc/x6;
    :try_end_e
    .catch Lorg/json/JSONException; {:try_start_e .. :try_end_e} :catch_4

    move/from16 v16, v1

    move-object v1, v11

    move-object/from16 v17, v13

    move-object v13, v2

    move-object/from16 v2, p0

    move-object/from16 v20, v14

    move-object v14, v4

    move-object/from16 v4, p2

    move/from16 v21, v5

    move-object/from16 v5, v19

    move-object/from16 v22, v6

    move-object/from16 v19, v15

    move/from16 v15, v16

    move-object/from16 v6, p1

    move-object/from16 v23, v7

    move-object/from16 v7, p3

    move-object/from16 v16, v8

    move-object/from16 v8, p4

    :try_start_f
    invoke-direct/range {v1 .. v8}, Lc/x6;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lc/T5;Ljava/lang/String;Lc/r4;Landroid/widget/LinearLayout;Landroid/widget/TextView;)V

    invoke-static {v9, v10, v13, v15, v11}, Lc/b7;->b(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;ZLjava/lang/Runnable;)Landroid/widget/Button;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v4, -0x2

    invoke-direct {v2, v15, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v14, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v15, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V
    :try_end_f
    .catch Lorg/json/JSONException; {:try_start_f .. :try_end_f} :catch_3

    const/16 v5, 0x8

    :try_start_10
    invoke-static {v9, v5}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v6

    iput v6, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    move-object/from16 v6, v23

    invoke-virtual {v0, v6, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v15, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-static {v9, v5}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v1, v22

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v12, v1, v5}, Lc/b7;->a(Landroid/widget/LinearLayout;Landroid/view/View;I)V
    :try_end_10
    .catch Lorg/json/JSONException; {:try_start_10 .. :try_end_10} :catch_a

    goto :goto_9

    :catch_3
    const/16 v5, 0x8

    goto :goto_9

    :catch_4
    move/from16 v21, v5

    move-object/from16 v16, v8

    move-object/from16 v17, v13

    move-object/from16 v20, v14

    move-object/from16 v19, v15

    const/16 v5, 0x8

    move v15, v1

    goto :goto_9

    :catch_5
    move/from16 v21, v5

    move-object/from16 v16, v8

    move-object/from16 v17, v13

    move-object/from16 v20, v14

    move-object/from16 v19, v15

    const/16 v5, 0x8

    move v15, v7

    goto :goto_9

    :catch_6
    move-object/from16 v18, v0

    :catch_7
    move/from16 v21, v5

    move-object/from16 v16, v8

    move-object/from16 v17, v13

    move-object/from16 v20, v14

    move-object/from16 v19, v15

    const/16 v5, 0x8

    :goto_8
    const/4 v15, 0x0

    goto :goto_9

    :catch_8
    move-object/from16 v18, v0

    move/from16 v21, v5

    move v5, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v13

    move-object/from16 v20, v14

    move-object/from16 v19, v15

    goto :goto_8

    :catch_9
    move-object/from16 v18, v0

    move/from16 v21, v5

    move v5, v7

    move-object/from16 v16, v8

    move-object/from16 v17, v13

    move-object/from16 v20, v14

    move-object/from16 v19, v15

    move v15, v6

    :catch_a
    :goto_9
    add-int/lit8 v0, v21, 0x1

    move-object/from16 v11, p2

    move v7, v5

    move v6, v15

    move-object/from16 v8, v16

    move-object/from16 v13, v17

    move-object/from16 v15, v19

    move-object/from16 v14, v20

    move v5, v0

    move-object/from16 v0, v18

    goto/16 :goto_5

    :cond_7
    return-void

    :catch_b
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v1, p4

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public static m(Landroid/app/Activity;I)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 p1, 0x10

    invoke-static {p0, p1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public static n(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;IZ)Landroid/widget/TextView;
    .locals 1

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p0, p3

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTextSize(F)V

    if-eqz p4, :cond_1

    iget-boolean p0, p1, Lc/r4;->m:Z

    if-eqz p0, :cond_0

    const p0, -0xb0a399

    goto :goto_0

    :cond_0
    iget p0, p1, Lc/r4;->e:I

    goto :goto_0

    :cond_1
    iget p0, p1, Lc/r4;->d:I

    :goto_0
    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTextColor(I)V

    return-object v0
.end method

.method public static o(Lru/drivedeck/launcher/MainActivity;Lc/r4;Ljava/lang/String;)Landroid/widget/EditText;
    .locals 4

    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v1, 0x30

    invoke-static {p0, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    iget v1, p1, Lc/r4;->d:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget v1, p1, Lc/r4;->e:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHintTextColor(I)V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    const/16 p2, 0xa

    invoke-static {p0, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v1

    const/16 v2, 0x8

    invoke-static {p0, v2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v3

    invoke-static {p0, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    invoke-static {p0, v2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v0, v1, v3, p2, v2}, Landroid/view/View;->setPadding(IIII)V

    iget p1, p1, Lc/r4;->b:I

    invoke-static {p0, p1}, Lc/b7;->m(Landroid/app/Activity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method public static p(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const-string v0, "0"

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_0
    sget-object v0, Lc/b7;->b:[Ljava/lang/String;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "="

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    const/4 p0, 0x3

    invoke-virtual {v3, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043d\u044b\u0439 \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0431\u043b\u043e\u043a VWTP"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
