.class public final Lc/O5;
.super Ljava/io/InputStream;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/P6;


# direct methods
.method public constructor <init>(Lc/P6;)V
    .locals 0

    iput-object p1, p0, Lc/O5;->a:Lc/P6;

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    return-void
.end method


# virtual methods
.method public final close()V
    .locals 1

    iget-object v0, p0, Lc/O5;->a:Lc/P6;

    invoke-virtual {v0}, Lc/P6;->close()V

    return-void
.end method

.method public final read()I
    .locals 2

    const/4 v0, 0x1

    .line 1
    new-array v0, v0, [B

    .line 2
    :goto_0
    invoke-virtual {p0, v0}, Lc/O5;->read([B)I

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    if-gez v1, :cond_1

    const/4 v0, -0x1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    .line 3
    aget-byte v0, v0, v1

    and-int/lit16 v0, v0, 0xff

    :goto_1
    return v0
.end method

.method public final read([B)I
    .locals 3

    .line 4
    iget-object v0, p0, Lc/O5;->a:Lc/P6;

    .line 5
    iget-object v1, v0, Lc/P6;->b:Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    if-eqz v1, :cond_0

    .line 6
    iget-object v2, v0, Lc/P6;->f:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/16 v2, 0x1f4

    :try_start_0
    invoke-interface {v1, p1, v2}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->read([BI)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v0, v0, Lc/P6;->f:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return p1

    :catchall_0
    move-exception p1

    iget-object v0, v0, Lc/P6;->f:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    throw p1

    .line 7
    :cond_0
    new-instance p1, Ljava/io/IOException;

    const-string v0, "USB disconnected"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
