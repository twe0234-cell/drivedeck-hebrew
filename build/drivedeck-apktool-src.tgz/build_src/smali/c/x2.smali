.class public final synthetic Lc/x2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/k3;Ljava/lang/String;I)V
    .locals 0

    iput p3, p0, Lc/x2;->a:I

    iput-object p1, p0, Lc/x2;->b:Lc/k3;

    iput-object p2, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/x2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    iget-object v2, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "black"

    iget-object v4, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    const-string v3, "dark"

    :goto_0
    const-string v4, "auto_night_theme"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v2, v0, Lc/k3;->d:Lc/u0;

    invoke-virtual {v1}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    iget-object v1, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/k3;->W(Ljava/lang/String;)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.VIEW"

    iget-object v3, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "tutorial"

    iget-object v2, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    iget-object v0, v0, Lc/k3;->d:Lc/u0;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lc/i;

    const/4 v3, 0x6

    invoke-direct {v2, v0, v3}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_1

    :cond_1
    invoke-virtual {v0, v2}, Lc/k3;->n0(Ljava/lang/String;)V

    :goto_1
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/x2;->c:Ljava/lang/String;

    const-string v2, "tutorial"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    iget-object v0, v0, Lc/k3;->d:Lc/u0;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lc/i;

    const/4 v3, 0x6

    invoke-direct {v2, v0, v3}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto :goto_2

    :cond_2
    invoke-virtual {v0, v1}, Lc/k3;->n0(Ljava/lang/String;)V

    :goto_2
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->d:Lc/u0;

    iget-object v2, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_5
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/u2;

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Lc/u2;-><init>(Lc/k3;I)V

    sget-object v2, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v2, :cond_3

    const-string v1, "\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442\u0441\u044f"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_3

    :cond_3
    invoke-static {v0}, Lc/q4;->s(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v2

    iget-object v3, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4

    const-string v1, "\u041d\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0445 \u043f\u0440\u0435\u0441\u0435\u0442\u043e\u0432"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_3

    :cond_4
    new-instance v2, Lc/Z;

    const/16 v4, 0x9

    invoke-direct {v2, v0, v3, v1, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v1, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442?"

    const-string v4, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-static {v0, v1, v3, v4, v2}, Lc/q4;->i(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    :goto_3
    return-void

    :pswitch_6
    iget-object v0, p0, Lc/x2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, p0, Lc/x2;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lc/q4;->c(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
