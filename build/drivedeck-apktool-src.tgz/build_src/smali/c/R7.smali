.class public final synthetic Lc/R7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/Z7;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lc/Z7;Ljava/lang/String;II)V
    .locals 0

    iput p4, p0, Lc/R7;->a:I

    iput-object p1, p0, Lc/R7;->b:Lc/Z7;

    iput-object p2, p0, Lc/R7;->c:Ljava/lang/String;

    iput p3, p0, Lc/R7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    iget v0, p0, Lc/R7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/R7;->b:Lc/Z7;

    iget-object v1, p0, Lc/R7;->c:Ljava/lang/String;

    iget v2, p0, Lc/R7;->d:I

    invoke-virtual {v0, v1, v2}, Lc/Z7;->i(Ljava/lang/String;I)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/R7;->b:Lc/Z7;

    iget-object v1, p0, Lc/R7;->c:Ljava/lang/String;

    iget v2, p0, Lc/R7;->d:I

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    invoke-virtual {v0, v1}, Lc/Z7;->a(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;

    move-result-object v3

    iget-object v4, v0, Lc/Z7;->j:Landroid/bluetooth/BluetoothProfile;

    if-eqz v3, :cond_0

    if-eqz v4, :cond_0

    invoke-interface {v4}, Landroid/bluetooth/BluetoothProfile;->getConnectedDevices()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    const-string v6, "connect"

    const-class v7, Landroid/bluetooth/BluetoothDevice;

    filled-new-array {v7}, [Ljava/lang/Class;

    move-result-object v7

    invoke-virtual {v5, v6, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v5, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    iget-object v3, v0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v4, Lc/R7;

    const/4 v5, 0x0

    invoke-direct {v4, v0, v1, v2, v5}, Lc/R7;-><init>(Lc/Z7;Ljava/lang/String;II)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_1
    const/4 v0, 0x1

    iget-object v1, p0, Lc/R7;->b:Lc/Z7;

    iget-object v2, p0, Lc/R7;->c:Ljava/lang/String;

    iget v3, p0, Lc/R7;->d:I

    invoke-virtual {v1, v0, v3, v2}, Lc/Z7;->c(IILjava/lang/String;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/R7;->b:Lc/Z7;

    iget-object v1, p0, Lc/R7;->c:Ljava/lang/String;

    iget v2, p0, Lc/R7;->d:I

    invoke-virtual {v0, v1, v2}, Lc/Z7;->i(Ljava/lang/String;I)V

    return-void

    :pswitch_3
    const/4 v0, 0x0

    iget-object v1, p0, Lc/R7;->b:Lc/Z7;

    iget-object v2, p0, Lc/R7;->c:Ljava/lang/String;

    iget v3, p0, Lc/R7;->d:I

    invoke-virtual {v1, v0, v3, v2}, Lc/Z7;->c(IILjava/lang/String;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
