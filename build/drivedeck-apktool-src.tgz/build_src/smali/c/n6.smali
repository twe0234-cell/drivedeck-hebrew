.class public final Lc/n6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final k:[I

.field public static final l:[I

.field public static final m:[Ljava/lang/String;


# instance fields
.field public final a:Lc/m6;

.field public final b:[I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:Z

.field public h:Z

.field public i:Z

.field public j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 35

    const/16 v0, 0x11

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lc/n6;->k:[I

    const/16 v0, 0x27

    new-array v0, v0, [I

    fill-array-data v0, :array_1

    sput-object v0, Lc/n6;->l:[I

    const-string v33, "ATSP5;ATSH8110F1;ATIB10;ATST20"

    const-string v34, "ATSP6;ATFCSH7E0;ATFCSD30000000;ATFCSM1"

    const-string v1, "ATSP5;ATIB96"

    const-string v2, "ATSP5;ATIB48"

    const-string v3, "ATSP5;ATIB48;ATIIA7A"

    const-string v4, "ATSP5;ATIB48;ATIIA13"

    const-string v5, "ATSP5;ATIB48;ATIIA33"

    const-string v6, "ATSP4;ATIB96"

    const-string v7, "ATSP4;ATIB48"

    const-string v8, "ATSP4;ATIB48;ATIIA7A"

    const-string v9, "ATSP4;ATIB48;ATIIA13"

    const-string v10, "ATSP4;ATIB48;ATIIA33"

    const-string v11, "ATSP3;ATIB96"

    const-string v12, "ATSP3;ATIB48"

    const-string v13, "ATSP3;ATIB48;ATIIA7A"

    const-string v14, "ATSP3;ATIB48;ATIIA13"

    const-string v15, "ATSP3;ATIB48;ATIIA33"

    const-string v16, "ATSP5;ATSH8013F1;ATIB10;ATIIA13"

    const-string v17, "ATSP5;ATSH8013F0;ATIB96;ATIIA13"

    const-string v18, "ATSP5;ATSH8213F0;ATIB96;ATIIA13"

    const-string v19, "ATSP5;ATSH8013FC;ATIB10;ATIIA10"

    const-string v20, "ATSP5;ATSH8013FC;ATIB96;ATIIA10"

    const-string v21, "ATSP4;ATSH8013F1;ATIB10;ATIIA13"

    const-string v22, "ATSP4;ATSH8013F0;ATIB96;ATIIA13"

    const-string v23, "ATSP4;ATSH8213F0;ATIB96;ATIIA13"

    const-string v24, "ATSP4;ATSH8013FC;ATIB10;ATIIA13"

    const-string v25, "ATSP4;ATSH8013F1;ATIB96;ATIIA13"

    const-string v26, "ATSP4;ATSH8113F1;ATIB96;ATIIA13"

    const-string v27, "ATSP5;ATSH8110FC;ATIB10;ATIIA10"

    const-string v28, "ATSP4;ATSH8013F1;ATIB10;ATIIA13"

    const-string v29, "ATSP5;ATSH8113F1;ATIB96;ATIIA13"

    const-string v30, "ATSP5;ATSH8213F1;ATIB96;ATIIA13"

    const-string v31, "ATSP3;ATSH686AF1;ATIB10;ATIIA33"

    const-string v32, "ATSP6;ATSH7E0;10C0"

    filled-new-array/range {v1 .. v34}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/n6;->m:[Ljava/lang/String;

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x6
        0x7
        0x4
        0x5
        0x3
        0x1
        0x2
        0x8
        0x9
        0xa
        0xb
        0x25
        0x21
        0x2b
        0x2c
        0x2d
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x6
        0x7
        0x4
        0x5
        0x3
        0x25
        0x21
        0x2c
        0xc
        0xd
        0xe
        0xf
        0x10
        0x11
        0x12
        0x13
        0x14
        0x15
        0x16
        0x17
        0x18
        0x19
        0x1a
        0x1b
        0x1c
        0x1d
        0x1e
        0x1f
        0x20
        0x22
        0x23
        0x24
        0x26
        0x27
        0x28
        0x29
        0x2a
        0x2d
    .end array-data
.end method

.method public constructor <init>(Lc/m6;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lc/n6;->c:I

    iput v0, p0, Lc/n6;->d:I

    iput v0, p0, Lc/n6;->e:I

    const/4 v0, -0x1

    iput v0, p0, Lc/n6;->f:I

    iput-object p1, p0, Lc/n6;->a:Lc/m6;

    iget-object p1, p1, Lc/m6;->f:Ljava/lang/String;

    const-string v0, "Toyota"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "Lexus"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    sget-object p1, Lc/n6;->k:[I

    goto :goto_1

    :cond_1
    :goto_0
    sget-object p1, Lc/n6;->l:[I

    :goto_1
    invoke-virtual {p1}, [I->clone()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [I

    iput-object p1, p0, Lc/n6;->b:[I

    return-void
.end method

.method public static c(I)Ljava/util/List;
    .locals 8

    if-ltz p0, :cond_4

    const/16 v0, 0x2d

    if-gt p0, v0, :cond_4

    const/16 v1, 0xb

    if-ne p0, v1, :cond_0

    invoke-static {}, Lc/G8;->P0()Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    const-string v2, "ATD"

    const-string v3, "ATD0"

    const-string v4, "ATE0"

    const-string v5, "ATH1"

    filled-new-array {v2, v3, v4, v5}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/16 v2, 0xa

    if-gt p0, v2, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "ATSP"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p0

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_1
    const/16 v2, 0xc

    if-lt p0, v2, :cond_3

    if-le p0, v0, :cond_2

    goto :goto_0

    :cond_2
    sget-object v0, Lc/n6;->m:[Ljava/lang/String;

    sub-int/2addr p0, v2

    aget-object p0, v0, p0

    const-string v0, ";"

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    goto :goto_1

    :cond_3
    :goto_0
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    :goto_1
    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :goto_2
    const-string p0, "ATAT"

    const-string v0, "1"

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v4, "ATM0"

    const-string v5, "ATS0"

    const-string v2, "ATE0"

    const-string v3, "ATH1"

    const-string v7, "ATAL"

    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid protocol"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static f(Ljava/lang/String;)Z
    .locals 1

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const-string v0, "obdlink"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_2

    const-string v0, "vlinker"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_1

    :cond_1
    const/4 p0, 0x0

    goto :goto_2

    :cond_2
    :goto_1
    const/4 p0, 0x1

    :goto_2
    return p0
.end method

.method public static g(Ljava/lang/String;)Z
    .locals 1

    if-eqz p0, :cond_1

    const-string v0, "STN"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p0}, Lc/n6;->i(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static h(Ljava/lang/String;)Z
    .locals 1

    if-eqz p0, :cond_0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "vlinker"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static i(Ljava/lang/String;)Z
    .locals 1

    if-eqz p0, :cond_0

    const/16 v0, 0x2e

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-ltz v0, :cond_0

    const/16 v0, 0x3f

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_0

    const-string v0, "ELM"

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public final a()V
    .locals 4

    iget v0, p0, Lc/n6;->c:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lc/n6;->c:I

    iget-object v2, p0, Lc/n6;->a:Lc/m6;

    iget v3, v2, Lc/m6;->b:I

    if-gt v0, v3, :cond_0

    return-void

    :cond_0
    iget-boolean v0, v2, Lc/m6;->d:Z

    if-nez v0, :cond_1

    iget v0, v2, Lc/m6;->a:I

    if-nez v0, :cond_1

    iget v0, v2, Lc/m6;->c:I

    if-nez v0, :cond_1

    iput-boolean v1, p0, Lc/n6;->g:Z

    return-void

    :cond_1
    iput-boolean v1, p0, Lc/n6;->h:Z

    return-void
.end method

.method public final b()V
    .locals 3

    iget v0, p0, Lc/n6;->e:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Lc/n6;->e:I

    const/4 v2, 0x3

    if-gt v0, v2, :cond_0

    return-void

    :cond_0
    iget-boolean v0, p0, Lc/n6;->j:Z

    iget-object v2, p0, Lc/n6;->b:[I

    if-eqz v0, :cond_1

    iget v0, p0, Lc/n6;->d:I

    aget v0, v2, v0

    iput v0, p0, Lc/n6;->f:I

    iput-boolean v1, p0, Lc/n6;->h:Z

    return-void

    :cond_1
    iput v1, p0, Lc/n6;->e:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/n6;->j:Z

    iget v0, p0, Lc/n6;->d:I

    add-int/2addr v0, v1

    iput v0, p0, Lc/n6;->d:I

    array-length v2, v2

    if-lt v0, v2, :cond_2

    iput-boolean v1, p0, Lc/n6;->h:Z

    :cond_2
    return-void
.end method

.method public final d()Lc/l6;
    .locals 10

    iget-boolean v0, p0, Lc/n6;->h:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    return-object v0

    :cond_0
    new-instance v0, Lc/l6;

    iget-boolean v1, p0, Lc/n6;->i:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    const/4 v1, 0x2

    move v3, v1

    goto :goto_0

    :cond_1
    move v3, v2

    :goto_0
    iget-boolean v6, p0, Lc/n6;->g:Z

    const/4 v1, 0x0

    iget-object v4, p0, Lc/n6;->a:Lc/m6;

    if-eqz v6, :cond_2

    iget-object v5, p0, Lc/n6;->b:[I

    iget v7, p0, Lc/n6;->d:I

    aget v5, v5, v7

    goto :goto_1

    :cond_2
    iget-boolean v5, v4, Lc/m6;->d:Z

    if-nez v5, :cond_3

    iget-boolean v5, v4, Lc/m6;->e:Z

    if-nez v5, :cond_3

    iget v5, p0, Lc/n6;->c:I

    iget v7, v4, Lc/m6;->b:I

    if-ne v5, v7, :cond_3

    move v5, v1

    goto :goto_1

    :cond_3
    iget v5, v4, Lc/m6;->a:I

    :goto_1
    if-eqz v6, :cond_4

    iget v7, p0, Lc/n6;->e:I

    goto :goto_2

    :cond_4
    iget v7, p0, Lc/n6;->c:I

    :goto_2
    if-nez v6, :cond_5

    iget-boolean v8, v4, Lc/m6;->d:Z

    if-eqz v8, :cond_5

    move v8, v2

    goto :goto_3

    :cond_5
    move v8, v1

    :goto_3
    if-eqz v6, :cond_6

    :goto_4
    move v9, v1

    goto :goto_5

    :cond_6
    iget v1, v4, Lc/m6;->c:I

    goto :goto_4

    :goto_5
    move-object v1, v0

    move v2, v3

    move v3, v5

    move v4, v7

    move v5, v8

    move v7, v9

    invoke-direct/range {v1 .. v7}, Lc/l6;-><init>(IIIZZI)V

    return-object v0
.end method

.method public final e(Z)V
    .locals 1

    iget-boolean v0, p0, Lc/n6;->h:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/n6;->i:Z

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/n6;->i:Z

    iget-boolean v0, p0, Lc/n6;->g:Z

    if-eqz v0, :cond_1

    if-nez p1, :cond_0

    iget p1, p0, Lc/n6;->e:I

    const/4 v0, 0x2

    if-ne p1, v0, :cond_0

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/n6;->h:Z

    return-void

    :cond_0
    invoke-virtual {p0}, Lc/n6;->b()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lc/n6;->a()V

    :goto_0
    return-void

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "No reconnect awaiting result"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
