.class public final synthetic Lc/N2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/k3;II)V
    .locals 0

    iput p3, p0, Lc/N2;->a:I

    iput-object p1, p0, Lc/N2;->b:Lc/k3;

    iput p2, p0, Lc/N2;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lc/N2;->a:I

    packed-switch v0, :pswitch_data_0

    iget v0, p0, Lc/N2;->c:I

    iget-object v1, p0, Lc/N2;->b:Lc/k3;

    iput v0, v1, Lc/k3;->s:I

    invoke-virtual {v1}, Lc/k3;->S()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/N2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v2, 0x2

    iget v3, p0, Lc/N2;->c:I

    const/4 v4, 0x0

    const-string v5, "window_gesture_bars"

    invoke-static {v2, v3, v4, v1, v5}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_0
    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/N2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    iget v2, p0, Lc/N2;->c:I

    const/4 v3, 0x1

    if-eq v2, v3, :cond_4

    const/4 v3, 0x2

    if-eq v2, v3, :cond_3

    const/4 v3, 0x3

    if-eq v2, v3, :cond_2

    const/4 v3, 0x4

    if-ne v2, v3, :cond_1

    const-string v2, "HIDE_BOTH"

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    throw v0

    :cond_2
    const-string v2, "HIDE_NAVIGATION"

    goto :goto_0

    :cond_3
    const-string v2, "HIDE_STATUS"

    goto :goto_0

    :cond_4
    const-string v2, "SHOW_BOTH"

    :goto_0
    const-string v3, "system_bars_mode"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v1, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_5

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->v()V

    goto :goto_1

    :cond_5
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-static {v1}, Lc/b4;->b(Landroid/view/Window;)V

    :goto_1
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-static {v1}, Lc/b4;->b(Landroid/view/Window;)V

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
