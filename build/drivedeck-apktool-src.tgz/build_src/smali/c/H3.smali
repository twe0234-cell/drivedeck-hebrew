.class public final synthetic Lc/H3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:[I

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>([II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/H3;->a:[I

    iput p2, p0, Lc/H3;->b:I

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 2

    iget-object p1, p0, Lc/H3;->a:[I

    iget v0, p0, Lc/H3;->b:I

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    aget p2, p1, v1

    or-int/2addr p2, v0

    aput p2, p1, v1

    goto :goto_0

    :cond_0
    aget p2, p1, v1

    not-int v0, v0

    and-int/2addr p2, v0

    aput p2, p1, v1

    :goto_0
    return-void
.end method
