.class public final synthetic Lc/V1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:Lc/b2;

.field public final synthetic b:F

.field public final synthetic c:F

.field public final synthetic d:F

.field public final synthetic e:F


# direct methods
.method public synthetic constructor <init>(Lc/b2;FFFF)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V1;->a:Lc/b2;

    iput p2, p0, Lc/V1;->b:F

    iput p3, p0, Lc/V1;->c:F

    iput p4, p0, Lc/V1;->d:F

    iput p5, p0, Lc/V1;->e:F

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 3

    iget-object v0, p0, Lc/V1;->a:Lc/b2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    iget v1, p0, Lc/V1;->c:F

    iget v2, p0, Lc/V1;->b:F

    sub-float/2addr v1, v2

    mul-float/2addr v1, p1

    add-float/2addr v1, v2

    iput v1, v0, Lc/b2;->a0:F

    iget v1, p0, Lc/V1;->e:F

    iget v2, p0, Lc/V1;->d:F

    sub-float/2addr v1, v2

    mul-float/2addr v1, p1

    add-float/2addr v1, v2

    iput v1, v0, Lc/b2;->b0:F

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void
.end method
