.class public final synthetic Lc/K8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lc/n1;

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:[Lc/U8;

.field public final synthetic d:Landroid/widget/LinearLayout;

.field public final synthetic e:Landroid/widget/Button;

.field public final synthetic f:Landroid/widget/TextView;

.field public final synthetic g:Landroid/widget/TextView;

.field public final synthetic h:Lc/N8;


# direct methods
.method public synthetic constructor <init>(Lc/n1;Lru/drivedeck/launcher/MainActivity;[Lc/U8;Landroid/widget/LinearLayout;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;Lc/N8;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K8;->a:Lc/n1;

    iput-object p2, p0, Lc/K8;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p3, p0, Lc/K8;->c:[Lc/U8;

    iput-object p4, p0, Lc/K8;->d:Landroid/widget/LinearLayout;

    iput-object p5, p0, Lc/K8;->e:Landroid/widget/Button;

    iput-object p6, p0, Lc/K8;->f:Landroid/widget/TextView;

    iput-object p7, p0, Lc/K8;->g:Landroid/widget/TextView;

    iput-object p8, p0, Lc/K8;->h:Lc/N8;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 6

    check-cast p1, Ljava/lang/String;

    iget-object v0, p0, Lc/K8;->a:Lc/n1;

    invoke-virtual {v0, p1}, Lc/n1;->T0(Ljava/lang/String;)V

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object v2, p0, Lc/K8;->b:Lru/drivedeck/launcher/MainActivity;

    if-eqz v2, :cond_1

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    if-eqz v3, :cond_1

    iput-boolean v0, v3, Lc/J8;->i:Z

    iget-object v4, v3, Lc/J8;->c:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_0

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    instance-of v4, v4, Landroid/view/ViewGroup;

    if-eqz v4, :cond_0

    iget-object v4, v3, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v4}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup;

    iget-object v5, v3, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    iput-object v1, v3, Lc/J8;->c:Landroid/widget/LinearLayout;

    iput-object v1, v2, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    :cond_1
    iget-object v3, p0, Lc/K8;->c:[Lc/U8;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    iget-object v1, p0, Lc/K8;->d:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v1, p0, Lc/K8;->e:Landroid/widget/Button;

    invoke-virtual {v1, v0}, Landroid/view/View;->setEnabled(Z)V

    iget-object v1, p0, Lc/K8;->f:Landroid/widget/TextView;

    const-string v3, ""

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string v1, "alpha"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    const-string p1, "\u0420\u0430\u043d\u043d\u0438\u0435 \u0442\u0435\u0441\u0442\u043e\u0432\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u0431\u0443\u0434\u0443\u0442 \u043f\u0440\u0438\u0445\u043e\u0434\u0438\u0442\u044c \u0438\u0437 \u0430\u043b\u044c\u0444\u0430-\u043a\u0430\u043d\u0430\u043b\u0430."

    goto :goto_0

    :cond_2
    const-string v1, "beta"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_3

    const-string p1, "\u0422\u0435\u0441\u0442\u043e\u0432\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u041f\u043e\u0441\u043b\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u0431\u0435\u0442\u0430-\u043a\u0430\u043d\u0430\u043b\u0430 \u0432\u044b \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u0435 \u0441\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0441\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u044b\u0439 \u0432\u044b\u043f\u0443\u0441\u043a. \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043d\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f \u043e\u0441\u0442\u0430\u043d\u0435\u0442\u0441\u044f."

    goto :goto_0

    :cond_3
    const-string p1, "\u0421\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u044b\u0435 \u0432\u0435\u0440\u0441\u0438\u0438. \u041f\u043e\u0441\u043b\u0435 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f \u0442\u0435\u0441\u0442\u043e\u0432\u044b\u0445 \u043a\u0430\u043d\u0430\u043b\u043e\u0432 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u0434\u0451\u0442 \u0441 \u0432\u044b\u0445\u043e\u0434\u043e\u043c \u0431\u043e\u043b\u0435\u0435 \u043d\u043e\u0432\u043e\u0433\u043e \u0441\u0442\u0430\u0431\u0438\u043b\u044c\u043d\u043e\u0433\u043e \u0432\u044b\u043f\u0443\u0441\u043a\u0430."

    :goto_0
    invoke-static {v2, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lc/K8;->g:Landroid/widget/TextView;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "\u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-static {v2, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lc/K8;->h:Lc/N8;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v1}, Lc/G8;->r(Landroid/widget/TextView;)V

    invoke-virtual {v1, v0}, Lc/N8;->setEnabled(Z)V

    invoke-virtual {v1}, Landroid/view/View;->performClick()Z

    return-void
.end method
