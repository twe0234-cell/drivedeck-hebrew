.class public final synthetic Lc/n4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:Ljava/util/LinkedHashMap;

.field public final synthetic d:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Ljava/util/LinkedHashMap;Lorg/json/JSONObject;I)V
    .locals 0

    iput p4, p0, Lc/n4;->a:I

    iput-object p1, p0, Lc/n4;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/n4;->c:Ljava/util/LinkedHashMap;

    iput-object p3, p0, Lc/n4;->d:Lorg/json/JSONObject;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/n4;->a:I

    packed-switch v0, :pswitch_data_0

    sget-object v0, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, p0, Lc/n4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v1, Lc/n4;

    iget-object v2, p0, Lc/n4;->c:Ljava/util/LinkedHashMap;

    iget-object v3, p0, Lc/n4;->d:Lorg/json/JSONObject;

    const/4 v4, 0x0

    invoke-direct {v1, v0, v2, v3, v4}, Lc/n4;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/util/LinkedHashMap;Lorg/json/JSONObject;I)V

    const-string v2, "\u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438?"

    const-string v3, "\u0422\u0435\u043a\u0443\u0449\u0438\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438, \u0434\u043e\u043a, \u043e\u0431\u043e\u0438 \u0438 \u043f\u0440\u0435\u0441\u0435\u0442\u044b \u0431\u0443\u0434\u0443\u0442 \u0437\u0430\u043c\u0435\u043d\u0435\u043d\u044b. Android-\u0432\u0438\u0434\u0436\u0435\u0442\u044b \u043c\u043e\u0433\u0443\u0442 \u043f\u043e\u0442\u0440\u0435\u0431\u043e\u0432\u0430\u0442\u044c \u043f\u043e\u0432\u0442\u043e\u0440\u043d\u043e\u0439 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438."

    const-string v4, "\u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c"

    invoke-static {v0, v2, v3, v4, v1}, Lc/q4;->i(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    sget-object v0, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_1

    :cond_2
    iget-object v7, p0, Lc/n4;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v7}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v0

    iput-boolean v2, v0, Lc/T5;->u:Z

    const/4 v2, 0x0

    iput-object v2, v0, Lc/T5;->r0:Lc/n6;

    iput-boolean v1, v0, Lc/T5;->o1:Z

    invoke-virtual {v0}, Lc/T5;->L0()V

    invoke-virtual {v0}, Lc/T5;->s()V

    invoke-virtual {v7}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lc/C2;

    iget-object v5, p0, Lc/n4;->c:Ljava/util/LinkedHashMap;

    iget-object v6, p0, Lc/n4;->d:Lorg/json/JSONObject;

    const/4 v8, 0x4

    move-object v3, v1

    invoke-direct/range {v3 .. v8}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v2, "DriveDeckSettingsRestore"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :goto_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
