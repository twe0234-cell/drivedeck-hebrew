.class public final Lc/X7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/bluetooth/BluetoothProfile$ServiceListener;


# instance fields
.field public final synthetic a:Lc/Z7;


# direct methods
.method public constructor <init>(Lc/Z7;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/X7;->a:Lc/Z7;

    return-void
.end method


# virtual methods
.method public final onServiceConnected(ILandroid/bluetooth/BluetoothProfile;)V
    .locals 1

    iget-object v0, p0, Lc/X7;->a:Lc/Z7;

    iget-boolean v0, v0, Lc/Z7;->r:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/X7;->a:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-virtual {v0, p1, p2}, Landroid/bluetooth/BluetoothAdapter;->closeProfileProxy(ILandroid/bluetooth/BluetoothProfile;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void

    :cond_1
    const/16 v0, 0x10

    if-ne p1, v0, :cond_2

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-object p2, p1, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    goto :goto_0

    :cond_2
    const/16 v0, 0x11

    if-ne p1, v0, :cond_3

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-object p2, p1, Lc/Z7;->j:Landroid/bluetooth/BluetoothProfile;

    :cond_3
    :goto_0
    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    invoke-virtual {p1}, Lc/Z7;->n()V

    return-void
.end method

.method public final onServiceDisconnected(I)V
    .locals 4

    const/16 v0, 0x10

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-object v2, p1, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-boolean v1, p1, Lc/Z7;->o:Z

    goto :goto_0

    :cond_0
    const/16 v0, 0x11

    if-ne p1, v0, :cond_1

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-object v2, p1, Lc/Z7;->j:Landroid/bluetooth/BluetoothProfile;

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iput-boolean v1, p1, Lc/Z7;->p:Z

    :cond_1
    :goto_0
    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iget-boolean p1, p1, Lc/Z7;->r:Z

    if-nez p1, :cond_2

    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    iget-object v0, p1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v1, Lc/P7;

    const/4 v2, 0x5

    invoke-direct {v1, p1, v2}, Lc/P7;-><init>(Lc/Z7;I)V

    const-wide/16 v2, 0x7d0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    iget-object p1, p0, Lc/X7;->a:Lc/Z7;

    invoke-virtual {p1}, Lc/Z7;->n()V

    return-void
.end method
