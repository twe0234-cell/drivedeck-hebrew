.class public final enum Lc/F0;
.super Ljava/lang/Enum;
.source "SourceFile"


# static fields
.field public static final enum g:Lc/F0;

.field public static final enum h:Lc/F0;

.field public static final enum i:Lc/F0;

.field public static final synthetic j:[Lc/F0;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:I

.field public final e:I

.field public final f:I


# direct methods
.method static constructor <clinit>()V
    .locals 38

    new-instance v9, Lc/F0;

    const-string v0, "Battery voltage"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v8

    const/16 v6, 0x42

    const/4 v7, 0x1

    const-string v1, "VOLTAGE"

    const/4 v2, 0x0

    const-string v3, "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435"

    const-string v4, "\u041d\u0430\u043f\u0440\u044f\u0436\u0435\u043d\u0438\u0435"

    const-string v5, "\u0412"

    move-object v0, v9

    invoke-direct/range {v0 .. v8}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v1, Lc/F0;

    const-string v0, "Vehicle speed"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v18

    const/16 v16, 0xd

    const/16 v17, 0x0

    const-string v11, "SPEED"

    const/4 v12, 0x1

    const-string v13, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c"

    const-string v14, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c"

    const-string v15, "\u043a\u043c/\u0447"

    move-object v10, v1

    invoke-direct/range {v10 .. v18}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v2, Lc/F0;

    const-string v0, "Coolant temperature"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v27

    const/16 v25, 0x5

    const/16 v26, 0x0

    const-string v20, "COOLANT"

    const/16 v21, 0x2

    const-string v22, "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 \u041e\u0416"

    const-string v23, "\u041e\u0445\u043b\u0430\u0436\u0434. \u0436\u0438\u0434\u043a\u043e\u0441\u0442\u044c"

    const-string v24, "\u00b0C"

    move-object/from16 v19, v2

    invoke-direct/range {v19 .. v27}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v3, Lc/F0;

    const-string v0, "Engine RPM"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v18

    const/16 v16, 0xc

    const-string v11, "RPM"

    const/4 v12, 0x3

    const-string v13, "\u041e\u0431\u043e\u0440\u043e\u0442\u044b \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b\u044f"

    const-string v14, "\u041e\u0431\u043e\u0440\u043e\u0442\u044b"

    const-string v15, "\u043e/\u043c"

    move-object v10, v3

    invoke-direct/range {v10 .. v18}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v4, Lc/F0;

    const-string v0, "Fuel flow"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v27

    const/16 v25, -0x1

    const/16 v26, 0x1

    const-string v20, "INSTANT"

    const/16 v21, 0x4

    const-string v22, "\u041c\u0433\u043d\u043e\u0432\u0435\u043d\u043d\u044b\u0439 \u0440\u0430\u0441\u0445\u043e\u0434"

    const-string v23, "\u041c\u0433\u043d. \u0440\u0430\u0441\u0445\u043e\u0434"

    const-string v24, ""

    move-object/from16 v19, v4

    invoke-direct/range {v19 .. v27}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    sput-object v4, Lc/F0;->g:Lc/F0;

    new-instance v5, Lc/F0;

    const-string v0, "Fuel consumption"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v18

    const/16 v16, -0x2

    const/16 v17, 0x1

    const-string v11, "AVERAGE"

    const/4 v12, 0x5

    const-string v13, "\u0421\u0440\u0435\u0434\u043d\u0438\u0439 \u0440\u0430\u0441\u0445\u043e\u0434 \u0437\u0430 \u043f\u043e\u0435\u0437\u0434\u043a\u0443"

    const-string v14, "\u0421\u0440\u0435\u0434\u043d\u0438\u0439 \u0440\u0430\u0441\u0445\u043e\u0434"

    const-string v15, "\u043b/100 \u043a\u043c"

    move-object v10, v5

    invoke-direct/range {v10 .. v18}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    sput-object v5, Lc/F0;->h:Lc/F0;

    new-instance v6, Lc/F0;

    const-string v0, "Fuel volume"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v27

    const/16 v25, -0x3

    const/16 v26, 0x2

    const-string v20, "USED"

    const/16 v21, 0x6

    const-string v22, "\u0418\u0437\u0440\u0430\u0441\u0445\u043e\u0434\u043e\u0432\u0430\u043d\u043e \u0437\u0430 \u043f\u043e\u0435\u0437\u0434\u043a\u0443"

    const-string v23, "\u0418\u0437\u0440\u0430\u0441\u0445\u043e\u0434\u043e\u0432\u0430\u043d\u043e"

    const-string v24, "\u043b"

    move-object/from16 v19, v6

    invoke-direct/range {v19 .. v27}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    sput-object v6, Lc/F0;->i:Lc/F0;

    new-instance v7, Lc/F0;

    const-string v0, "Fuel level"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v18

    const/16 v16, 0x2f

    const/16 v17, 0x0

    const-string v11, "FUEL"

    const/4 v12, 0x7

    const-string v13, "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0442\u043e\u043f\u043b\u0438\u0432\u0430"

    const-string v14, "\u0422\u043e\u043f\u043b\u0438\u0432\u043e \u0432 \u0431\u0430\u043a\u0435"

    const-string v15, "%"

    move-object v10, v7

    invoke-direct/range {v10 .. v18}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v8, Lc/F0;

    const-string v0, "Engine load"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v27

    const/16 v25, 0x4

    const/16 v26, 0x0

    const-string v20, "LOAD"

    const/16 v21, 0x8

    const-string v22, "\u041d\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b\u044f"

    const-string v23, "\u041d\u0430\u0433\u0440\u0443\u0437\u043a\u0430"

    const-string v24, "%"

    move-object/from16 v19, v8

    invoke-direct/range {v19 .. v27}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v19, Lc/F0;

    const-string v0, "Intake temperature"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v18

    const/16 v16, 0xf

    const-string v11, "INTAKE"

    const/16 v12, 0x9

    const-string v13, "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 \u0432\u043f\u0443\u0441\u043a\u0430"

    const-string v14, "\u0422\u0435\u043c\u043f. \u0432\u043f\u0443\u0441\u043a\u0430"

    const-string v15, "\u00b0C"

    move-object/from16 v10, v19

    invoke-direct/range {v10 .. v18}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v10, Lc/F0;

    const-string v0, "Transmission oil temperature"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v28

    const/16 v26, -0x4

    const/16 v27, 0x0

    const-string v21, "TRANSMISSION"

    const/16 v22, 0xa

    const-string v23, "\u0422\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 \u043c\u0430\u0441\u043b\u0430 \u041a\u041f\u041f"

    const-string v24, "\u0422\u0435\u043c\u043f. \u043c\u0430\u0441\u043b\u0430 \u041a\u041f\u041f"

    const-string v25, "\u00b0C"

    move-object/from16 v20, v10

    invoke-direct/range {v20 .. v28}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    new-instance v11, Lc/F0;

    const-string v0, "Current gear"

    invoke-static {v0}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v37

    const/16 v35, -0x5

    const/16 v36, 0x0

    const-string v30, "GEAR"

    const/16 v31, 0xb

    const-string v32, "\u0422\u0435\u043a\u0443\u0449\u0430\u044f \u043f\u0435\u0440\u0435\u0434\u0430\u0447\u0430"

    const-string v33, "\u041f\u0435\u0440\u0435\u0434\u0430\u0447\u0430"

    const-string v34, ""

    move-object/from16 v29, v11

    invoke-direct/range {v29 .. v37}, Lc/F0;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V

    move-object v0, v9

    move-object/from16 v9, v19

    filled-new-array/range {v0 .. v11}, [Lc/F0;

    move-result-object v0

    sput-object v0, Lc/F0;->j:[Lc/F0;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;III)V
    .locals 0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lc/F0;->a:Ljava/lang/String;

    iput-object p4, p0, Lc/F0;->b:Ljava/lang/String;

    iput-object p5, p0, Lc/F0;->c:Ljava/lang/String;

    iput p6, p0, Lc/F0;->d:I

    iput p7, p0, Lc/F0;->e:I

    iput p8, p0, Lc/F0;->f:I

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lc/F0;
    .locals 1

    const-class v0, Lc/F0;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lc/F0;

    return-object p0
.end method

.method public static values()[Lc/F0;
    .locals 1

    sget-object v0, Lc/F0;->j:[Lc/F0;

    invoke-virtual {v0}, [Lc/F0;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lc/F0;

    return-object v0
.end method


# virtual methods
.method public final a()I
    .locals 2

    const/4 v0, 0x1

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    shl-int/2addr v0, v1

    return v0
.end method
