.class public final Lc/r0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/s0;

.field public final b:Lc/t0;

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I

.field public final g:Z

.field public final h:Z


# direct methods
.method public constructor <init>(Lc/s0;IIZIIZ)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    iput-object p1, p0, Lc/r0;->a:Lc/s0;

    iput p2, p0, Lc/r0;->c:I

    iput p3, p0, Lc/r0;->d:I

    iput-boolean p4, p0, Lc/r0;->g:Z

    .line 4
    sget-object p2, Lc/s0;->i:Lc/s0;

    if-ne p1, p2, :cond_0

    if-eqz p7, :cond_0

    const/4 p2, 0x1

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    iput-boolean p2, p0, Lc/r0;->h:Z

    .line 5
    invoke-virtual {p1}, Lc/s0;->a()I

    move-result p2

    const/16 p3, 0x1e

    invoke-static {p3, p5}, Ljava/lang/Math;->min(II)I

    move-result p3

    invoke-static {p2, p3}, Ljava/lang/Math;->max(II)I

    move-result p2

    iput p2, p0, Lc/r0;->e:I

    .line 6
    invoke-virtual {p1}, Lc/s0;->b()I

    move-result p1

    const/16 p3, 0x48

    invoke-static {p3, p6}, Ljava/lang/Math;->min(II)I

    move-result p3

    invoke-static {p1, p3}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Lc/r0;->f:I

    const/16 p3, 0xf

    if-ge p2, p3, :cond_1

    .line 7
    sget-object p1, Lc/t0;->c:Lc/t0;

    goto :goto_1

    :cond_1
    const/16 p2, 0x12

    if-ge p1, p2, :cond_2

    sget-object p1, Lc/t0;->d:Lc/t0;

    goto :goto_1

    :cond_2
    sget-object p1, Lc/t0;->e:Lc/t0;

    :goto_1
    iput-object p1, p0, Lc/r0;->b:Lc/t0;

    return-void
.end method

.method public constructor <init>(Lc/s0;Lc/t0;Z)V
    .locals 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, 0x0

    iget v6, p2, Lc/t0;->b:I

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v5, p2, Lc/t0;->a:I

    move-object v0, p0

    move-object v1, p1

    move v4, p3

    invoke-direct/range {v0 .. v7}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    return-void
.end method


# virtual methods
.method public final a(II)Lc/r0;
    .locals 9

    new-instance v8, Lc/r0;

    iget-boolean v4, p0, Lc/r0;->g:Z

    iget v5, p0, Lc/r0;->e:I

    iget-object v1, p0, Lc/r0;->a:Lc/s0;

    iget v6, p0, Lc/r0;->f:I

    const/4 v7, 0x0

    move-object v0, v8

    move v2, p1

    move v3, p2

    invoke-direct/range {v0 .. v7}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    return-object v8
.end method

.method public final b(Z)Lc/r0;
    .locals 9

    new-instance v8, Lc/r0;

    iget v3, p0, Lc/r0;->d:I

    iget v5, p0, Lc/r0;->e:I

    iget-object v1, p0, Lc/r0;->a:Lc/s0;

    iget v2, p0, Lc/r0;->c:I

    iget v6, p0, Lc/r0;->f:I

    iget-boolean v7, p0, Lc/r0;->h:Z

    move-object v0, v8

    move v4, p1

    invoke-direct/range {v0 .. v7}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    return-object v8
.end method

.method public final c(II)Lc/r0;
    .locals 9

    new-instance v8, Lc/r0;

    iget v2, p0, Lc/r0;->c:I

    iget v3, p0, Lc/r0;->d:I

    iget-object v1, p0, Lc/r0;->a:Lc/s0;

    iget-boolean v4, p0, Lc/r0;->g:Z

    const/4 v7, 0x0

    move-object v0, v8

    move v5, p1

    move v6, p2

    invoke-direct/range {v0 .. v7}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    return-object v8
.end method
