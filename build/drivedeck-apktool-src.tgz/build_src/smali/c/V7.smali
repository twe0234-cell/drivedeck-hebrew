.class public final synthetic Lc/V7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/Z7;

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Z

.field public final synthetic e:Z

.field public final synthetic f:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/Z7;ILjava/lang/String;ZZLjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V7;->a:Lc/Z7;

    iput p2, p0, Lc/V7;->b:I

    iput-object p3, p0, Lc/V7;->c:Ljava/lang/String;

    iput-boolean p4, p0, Lc/V7;->d:Z

    iput-boolean p5, p0, Lc/V7;->e:Z

    iput-object p6, p0, Lc/V7;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    iget-object v0, p0, Lc/V7;->a:Lc/Z7;

    iget v1, p0, Lc/V7;->b:I

    iget-object v2, p0, Lc/V7;->c:Ljava/lang/String;

    iget-boolean v3, p0, Lc/V7;->d:Z

    iget-boolean v4, p0, Lc/V7;->e:Z

    iget-object v5, p0, Lc/V7;->f:Ljava/lang/String;

    iget-boolean v6, v0, Lc/Z7;->r:Z

    if-nez v6, :cond_3

    iget-boolean v6, v0, Lc/Z7;->q:Z

    if-eqz v6, :cond_3

    iget v6, v0, Lc/Z7;->B:I

    if-ne v1, v6, :cond_3

    iget-object v6, v0, Lc/Z7;->a:Lc/e8;

    iget-object v6, v6, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    if-nez v3, :cond_1

    if-nez v4, :cond_1

    iget-object v2, v0, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v3, Lc/w;

    const/16 v4, 0x9

    invoke-direct {v3, v0, v1, v4}, Lc/w;-><init>(Ljava/lang/Object;II)V

    const-wide/16 v0, 0x7d0

    invoke-virtual {v2, v3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/Z7;->q:Z

    iput-object v5, v0, Lc/Z7;->K:Ljava/lang/String;

    if-eqz v3, :cond_2

    iget v1, v0, Lc/Z7;->D:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lc/Z7;->D:I

    :cond_2
    iget-object v0, v0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    :cond_3
    :goto_0
    return-void
.end method
