.class public final synthetic Lc/V6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/T5;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lorg/json/JSONObject;

.field public final synthetic d:Ljava/util/LinkedHashMap;

.field public final synthetic e:Landroid/widget/Spinner;

.field public final synthetic f:Landroid/widget/Spinner;

.field public final synthetic g:Landroid/widget/CheckBox;

.field public final synthetic h:Landroid/widget/CheckBox;

.field public final synthetic i:Landroid/app/AlertDialog;

.field public final synthetic j:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic k:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lc/T5;Ljava/lang/String;Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Landroid/app/AlertDialog;Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V6;->a:Lc/T5;

    iput-object p2, p0, Lc/V6;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/V6;->c:Lorg/json/JSONObject;

    iput-object p4, p0, Lc/V6;->d:Ljava/util/LinkedHashMap;

    iput-object p5, p0, Lc/V6;->e:Landroid/widget/Spinner;

    iput-object p6, p0, Lc/V6;->f:Landroid/widget/Spinner;

    iput-object p7, p0, Lc/V6;->g:Landroid/widget/CheckBox;

    iput-object p8, p0, Lc/V6;->h:Landroid/widget/CheckBox;

    iput-object p9, p0, Lc/V6;->i:Landroid/app/AlertDialog;

    iput-object p10, p0, Lc/V6;->j:Lru/drivedeck/launcher/MainActivity;

    iput-object p11, p0, Lc/V6;->k:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 9

    iget-object p1, p0, Lc/V6;->a:Lc/T5;

    iget-object v0, p0, Lc/V6;->b:Ljava/lang/String;

    iget-object v1, p0, Lc/V6;->c:Lorg/json/JSONObject;

    iget-object v2, p0, Lc/V6;->d:Ljava/util/LinkedHashMap;

    iget-object v3, p0, Lc/V6;->e:Landroid/widget/Spinner;

    iget-object v4, p0, Lc/V6;->f:Landroid/widget/Spinner;

    iget-object v5, p0, Lc/V6;->g:Landroid/widget/CheckBox;

    iget-object v6, p0, Lc/V6;->h:Landroid/widget/CheckBox;

    iget-object v7, p0, Lc/V6;->i:Landroid/app/AlertDialog;

    :try_start_0
    invoke-virtual {p1}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static/range {v1 .. v6}, Lc/b7;->d(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {p1, v0}, Lc/T5;->f0(Lorg/json/JSONObject;)Lc/i6;

    invoke-virtual {p1}, Lc/T5;->s0()V

    invoke-virtual {p1}, Lc/T5;->p()V

    iget-object v1, p1, Lc/T5;->h:Lc/j6;

    new-instance v2, Lc/f7;

    iget-object v3, p1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v4, 0x1

    invoke-direct {v2, v3, v1, v0, v4}, Lc/f7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONObject;I)V

    invoke-static {v2}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {p1}, Lc/T5;->o0()V

    invoke-virtual {v7}, Landroid/app/Dialog;->dismiss()V

    goto :goto_1

    :catch_0
    move-exception p1

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u0441\u044f. \u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u0440\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0441\u043d\u043e\u0432\u0430"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lc/V6;->k:Landroid/widget/TextView;

    iget-object v1, p0, Lc/V6;->j:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, p1}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance p1, Lc/i;

    const/16 v1, 0xd

    invoke-direct {p1, v0, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_1
    return-void
.end method
