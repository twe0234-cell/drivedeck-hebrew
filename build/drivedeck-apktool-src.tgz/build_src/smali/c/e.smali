.class public final synthetic Lc/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:[I

.field public final synthetic b:Lc/m;

.field public final synthetic c:Ljava/util/List;

.field public final synthetic d:Lc/n;

.field public final synthetic e:Lc/j;


# direct methods
.method public synthetic constructor <init>([ILc/m;Ljava/util/List;Lc/n;Lc/j;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/e;->a:[I

    iput-object p2, p0, Lc/e;->b:Lc/m;

    iput-object p3, p0, Lc/e;->c:Ljava/util/List;

    iput-object p4, p0, Lc/e;->d:Lc/n;

    iput-object p5, p0, Lc/e;->e:Lc/j;

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 0

    iget-object p1, p0, Lc/e;->a:[I

    const/4 p2, 0x0

    aget p4, p1, p2

    if-ltz p4, :cond_0

    const/4 p3, -0x1

    aput p3, p1, p2

    iget-object p1, p0, Lc/e;->b:Lc/m;

    invoke-virtual {p1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    goto :goto_0

    :cond_0
    iget-object p1, p0, Lc/e;->c:Ljava/util/List;

    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lc/a;

    iget-object p2, p2, Lc/a;->a:Ljava/lang/String;

    const-string p4, "package"

    filled-new-array {p4, p2}, [Ljava/lang/Object;

    move-result-object p2

    const-string p4, "app_grid_selection"

    invoke-static {p4, p2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-interface {p1, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/a;

    iget-object p2, p0, Lc/e;->d:Lc/n;

    invoke-interface {p2, p1}, Lc/n;->a(Lc/a;)V

    iget-object p1, p0, Lc/e;->e:Lc/j;

    invoke-virtual {p1}, Lc/j;->dismiss()V

    :goto_0
    return-void
.end method
