.class public final synthetic Lc/J1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    iput p2, p0, Lc/J1;->a:I

    iput-object p1, p0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 24

    move-object/from16 v0, p0

    const-string v1, "com.syu.radio"

    const/16 v5, 0x10

    const-string v6, "media_source_changed_elapsed"

    const/4 v8, 0x2

    const-wide/16 v9, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget v13, v0, Lc/J1;->a:I

    packed-switch v13, :pswitch_data_0

    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->j()V

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->l()V

    return-void

    :pswitch_0
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v12}, Lru/drivedeck/launcher/MainActivity;->C(Z)V

    return-void

    :pswitch_1
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    invoke-virtual {v2}, Landroid/view/View;->invalidate()V

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    :cond_1
    :goto_0
    return-void

    :pswitch_2
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-nez v2, :cond_2

    goto :goto_1

    :cond_2
    iget-boolean v2, v2, Lc/P;->o:Z

    if-eqz v2, :cond_3

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    iget-boolean v2, v2, Lc/P;->n:Z

    if-eqz v2, :cond_3

    move v11, v12

    :cond_3
    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->N:Lc/J1;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    if-eqz v11, :cond_4

    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->L:Z

    if-nez v2, :cond_4

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->e0()Z

    move-result v2

    if-nez v2, :cond_4

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2, v6, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v2

    iput-wide v2, v1, Lru/drivedeck/launcher/MainActivity;->M:J

    invoke-static {v1}, Lc/J;->b(Landroid/content/Context;)Z

    move-result v2

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->L:Z

    goto :goto_1

    :cond_4
    if-nez v11, :cond_5

    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->L:Z

    if-eqz v2, :cond_5

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->N:Lc/J1;

    const-wide/16 v3, 0x7d0

    invoke-virtual {v2, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_5
    :goto_1
    return-void

    :pswitch_3
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v12}, Lru/drivedeck/launcher/MainActivity;->C(Z)V

    return-void

    :pswitch_4
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v11}, Lru/drivedeck/launcher/MainActivity;->C(Z)V

    return-void

    :pswitch_5
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, v11}, Lru/drivedeck/launcher/MainActivity;->C(Z)V

    return-void

    :pswitch_6
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->O()V

    return-void

    :pswitch_7
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->P()V

    return-void

    :pswitch_8
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v2, :cond_6

    invoke-virtual {v2}, Lc/k3;->U()V

    :cond_6
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->V()V

    return-void

    :pswitch_9
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    if-eqz v6, :cond_1b

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v6

    if-nez v6, :cond_1b

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v6

    if-eqz v6, :cond_7

    goto/16 :goto_b

    :cond_7
    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v6, v6, Lc/Z7;->a:Lc/e8;

    iget-object v9, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    const/4 v10, 0x4

    if-eqz v9, :cond_a

    iget v13, v6, Lc/e8;->e:I

    if-eq v13, v10, :cond_9

    if-ne v13, v8, :cond_8

    goto :goto_2

    :cond_8
    move v8, v11

    goto :goto_3

    :cond_9
    :goto_2
    move v8, v12

    :goto_3
    invoke-virtual {v9, v8}, Lc/g9;->m(Z)V

    :cond_a
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->n()V

    iget-object v8, v1, Lru/drivedeck/launcher/MainActivity;->Z:Lc/d8;

    const-string v13, "\u0412\u0445\u043e\u0434\u044f\u0449\u0438\u0439 \u0437\u0432\u043e\u043d\u043e\u043a"

    const-string v14, ""

    if-eqz v8, :cond_11

    iget-object v15, v8, Lc/d8;->b:Lc/Z7;

    iget-object v2, v15, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v8}, Lc/d8;->k()Z

    move-result v16

    if-nez v16, :cond_b

    invoke-virtual {v8}, Lc/d8;->f()V

    goto/16 :goto_6

    :cond_b
    iget-object v9, v8, Lc/d8;->c:Landroid/view/WindowManager;

    if-eqz v9, :cond_10

    iget-object v3, v8, Lc/d8;->a:Landroid/content/Context;

    invoke-static {v3}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v17

    if-nez v17, :cond_c

    goto/16 :goto_5

    :cond_c
    iget-object v11, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-nez v11, :cond_d

    invoke-static {v3}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v11

    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    iget-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    const/16 v5, 0x12

    invoke-virtual {v8, v5}, Lc/d8;->e(I)I

    move-result v7

    const/16 v12, 0xe

    invoke-virtual {v8, v12}, Lc/d8;->e(I)I

    move-result v10

    invoke-virtual {v8, v5}, Lc/d8;->e(I)I

    move-result v5

    invoke-virtual {v8, v12}, Lc/d8;->e(I)I

    move-result v12

    invoke-virtual {v4, v7, v10, v5, v12}, Landroid/view/View;->setPadding(IIII)V

    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v5, v11, Lc/r4;->c:I

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v5, 0x3e8

    invoke-virtual {v8, v5}, Lc/d8;->e(I)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    iget-object v5, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    const/4 v5, 0x4

    invoke-virtual {v8, v5}, Lc/d8;->e(I)I

    move-result v7

    int-to-float v5, v7

    invoke-virtual {v4, v5}, Landroid/view/View;->setElevation(F)V

    iget-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    invoke-static {v3, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    iput-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    iget v5, v11, Lc/r4;->d:I

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    const/4 v5, 0x1

    const/4 v7, 0x0

    invoke-virtual {v4, v7, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v4}, Landroid/widget/TextView;->setSingleLine()V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    sget-object v7, Landroid/text/TextUtils$TruncateAt;->MARQUEE:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    const/4 v7, -0x1

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setMarqueeRepeatLimit(I)V

    iget-object v4, v8, Lc/d8;->h:Landroid/widget/TextView;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setSelected(Z)V

    iget-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    iget-object v5, v8, Lc/d8;->h:Landroid/widget/TextView;

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    const/4 v0, -0x2

    const/4 v12, 0x0

    invoke-direct {v7, v12, v0, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v3}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, v8, Lc/d8;->j:Landroid/widget/Button;

    const-string v4, "\u041e\u0442\u0432\u0435\u0442\u0438\u0442\u044c"

    invoke-static {v3, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, v8, Lc/d8;->j:Landroid/widget/Button;

    const/4 v4, 0x1

    invoke-static {v0, v11, v4}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    invoke-static {v0, v11, v12}, Lc/k6;->p(Landroid/widget/Button;Lc/r4;Z)V

    invoke-static {v3}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v0

    iput-object v0, v8, Lc/d8;->k:Landroid/widget/Button;

    const-string v5, "\u041e\u0442\u0431\u043e\u0439"

    invoke-static {v3, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v0, v8, Lc/d8;->k:Landroid/widget/Button;

    invoke-static {v0, v11, v4}, Lc/k6;->p(Landroid/widget/Button;Lc/r4;Z)V

    iget-object v0, v8, Lc/d8;->j:Landroid/widget/Button;

    const v4, 0x7f030053

    invoke-virtual {v8, v0, v4}, Lc/d8;->b(Landroid/widget/Button;I)V

    iget-object v0, v8, Lc/d8;->k:Landroid/widget/Button;

    const v4, 0x7f030057

    invoke-virtual {v8, v0, v4}, Lc/d8;->b(Landroid/widget/Button;I)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, v8, Lc/d8;->f:Landroid/widget/LinearLayout;

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Landroid/view/View;->setLayoutDirection(I)V

    iget-object v0, v8, Lc/d8;->f:Landroid/widget/LinearLayout;

    iget-object v4, v8, Lc/d8;->j:Landroid/widget/Button;

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8}, Lc/d8;->c()I

    move-result v7

    const/16 v10, 0x3c

    invoke-virtual {v8, v10}, Lc/d8;->e(I)I

    move-result v11

    invoke-direct {v5, v7, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v8}, Lc/d8;->c()I

    move-result v4

    invoke-virtual {v8, v10}, Lc/d8;->e(I)I

    move-result v5

    invoke-direct {v0, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v4, 0x8

    invoke-virtual {v8, v4}, Lc/d8;->e(I)I

    move-result v5

    iput v5, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget-object v5, v8, Lc/d8;->f:Landroid/widget/LinearLayout;

    iget-object v7, v8, Lc/d8;->k:Landroid/widget/Button;

    invoke-virtual {v5, v7, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    const/4 v5, 0x0

    invoke-virtual {v0, v5}, Landroid/view/View;->setLayoutDirection(I)V

    iget-object v0, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    iget-object v7, v8, Lc/d8;->f:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v0, v8, Lc/d8;->j:Landroid/widget/Button;

    new-instance v7, Lc/a8;

    invoke-direct {v7, v8, v5}, Lc/a8;-><init>(Lc/d8;I)V

    invoke-virtual {v0, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v0, v8, Lc/d8;->k:Landroid/widget/Button;

    new-instance v5, Lc/a8;

    const/4 v7, 0x1

    invoke-direct {v5, v8, v7}, Lc/a8;-><init>(Lc/d8;I)V

    invoke-virtual {v0, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v8}, Lc/d8;->i()I

    move-result v0

    new-instance v5, Landroid/widget/FrameLayout;

    invoke-direct {v5, v3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v5, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v8, v4}, Lc/d8;->e(I)I

    move-result v7

    invoke-virtual {v8, v4}, Lc/d8;->e(I)I

    move-result v10

    invoke-virtual {v8, v4}, Lc/d8;->e(I)I

    move-result v11

    invoke-virtual {v8, v4}, Lc/d8;->e(I)I

    move-result v4

    invoke-virtual {v5, v7, v10, v11, v4}, Landroid/view/View;->setPadding(IIII)V

    iget-object v4, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    iget-object v4, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    iget-object v4, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    iget-object v5, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    new-instance v7, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v7, v10, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v5, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v4, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    new-instance v5, Lc/A;

    const/4 v7, 0x5

    invoke-direct {v5, v8, v7}, Lc/A;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    iget-object v4, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    new-instance v5, Lc/b8;

    invoke-direct {v5, v8}, Lc/b8;-><init>(Lc/d8;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    new-instance v4, Landroid/view/WindowManager$LayoutParams;

    const/16 v5, 0x10

    invoke-virtual {v8, v5}, Lc/d8;->e(I)I

    move-result v5

    add-int v19, v5, v0

    const/16 v20, -0x2

    const/16 v21, 0x7f6

    const/16 v22, 0x128

    const/16 v23, -0x3

    move-object/from16 v18, v4

    invoke-direct/range {v18 .. v23}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    new-instance v0, Lc/n1;

    invoke-direct {v0, v3}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->i()Lc/u0;

    move-result-object v0

    iget-object v0, v0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q1;

    iput-object v0, v8, Lc/d8;->g:Lc/Q1;

    invoke-virtual {v8}, Lc/d8;->h()V

    const/16 v0, 0x51

    iput v0, v4, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v0, 0x0

    iput v0, v4, Landroid/view/WindowManager$LayoutParams;->x:I

    const/16 v0, 0xc

    invoke-virtual {v8, v0}, Lc/d8;->e(I)I

    move-result v0

    iput v0, v4, Landroid/view/WindowManager$LayoutParams;->y:I

    const-string v0, "DriveDeck incoming call"

    invoke-virtual {v4, v0}, Landroid/view/WindowManager$LayoutParams;->setTitle(Ljava/lang/CharSequence;)V

    :try_start_0
    iget-object v0, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    invoke-interface {v9, v0, v4}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_d
    const/4 v0, 0x0

    goto :goto_4

    :catch_0
    const/4 v0, 0x0

    iput-object v0, v8, Lc/d8;->e:Landroid/widget/LinearLayout;

    iput-object v0, v8, Lc/d8;->i:Landroid/widget/FrameLayout;

    goto :goto_6

    :goto_4
    iget v3, v8, Lc/d8;->t:I

    iget v4, v2, Lc/e8;->e:I

    iget-object v5, v8, Lc/d8;->d:Landroid/os/Handler;

    if-eq v3, v4, :cond_e

    iput v4, v8, Lc/d8;->t:I

    const/4 v3, 0x0

    iput-boolean v3, v8, Lc/d8;->n:Z

    invoke-virtual {v5, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v2, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "\n"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v2, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v3, v8, Lc/d8;->l:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_f

    iput-object v0, v8, Lc/d8;->l:Ljava/lang/String;

    iput-object v14, v8, Lc/d8;->m:Ljava/lang/String;

    const/4 v3, 0x0

    iput-boolean v3, v8, Lc/d8;->n:Z

    const/4 v3, 0x0

    invoke-virtual {v5, v3}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v3, v2, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_f

    iget-object v2, v2, Lc/e8;->c:Ljava/lang/String;

    new-instance v3, Lc/b;

    const/4 v4, 0x5

    invoke-direct {v3, v8, v0, v4}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v15, v2, v3}, Lc/Z7;->h(Ljava/lang/String;Ljava/util/function/Consumer;)V

    :cond_f
    invoke-virtual {v8}, Lc/d8;->j()V

    const/4 v11, 0x1

    goto :goto_7

    :cond_10
    :goto_5
    invoke-virtual {v8}, Lc/d8;->f()V

    :cond_11
    :goto_6
    const/4 v11, 0x0

    :goto_7
    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_12

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-object v2, v6, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->j()V

    :cond_12
    new-instance v0, Ljava/util/ArrayList;

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->b0:Ljava/util/HashSet;

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_13

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/O7;

    invoke-virtual {v2}, Lc/O7;->n()V

    goto :goto_8

    :cond_13
    const-class v0, Landroid/app/NotificationManager;

    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    iget v2, v6, Lc/e8;->e:I

    const/4 v3, 0x3

    if-ne v2, v3, :cond_14

    invoke-virtual {v6}, Lc/e8;->c()Z

    move-result v2

    if-eqz v2, :cond_14

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v6, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v6, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_9

    :cond_14
    move-object v2, v14

    :goto_9
    const/16 v3, 0x1f92

    if-eqz v11, :cond_15

    iput-object v14, v1, Lru/drivedeck/launcher/MainActivity;->e0:Ljava/lang/String;

    if-eqz v0, :cond_1b

    invoke-virtual {v0, v3}, Landroid/app/NotificationManager;->cancel(I)V

    goto/16 :goto_b

    :cond_15
    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->e0:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_16

    goto/16 :goto_b

    :cond_16
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_17

    iput-object v14, v1, Lru/drivedeck/launcher/MainActivity;->e0:Ljava/lang/String;

    if-eqz v0, :cond_1b

    invoke-virtual {v0, v3}, Landroid/app/NotificationManager;->cancel(I)V

    goto/16 :goto_b

    :cond_17
    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v4, :cond_18

    invoke-virtual {v4}, Landroid/app/Dialog;->isShowing()Z

    move-result v4

    if-eqz v4, :cond_18

    goto/16 :goto_b

    :cond_18
    if-eqz v0, :cond_1b

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x21

    if-lt v4, v5, :cond_19

    const-string v4, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {v1, v4}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v4

    if-eqz v4, :cond_19

    goto :goto_b

    :cond_19
    new-instance v4, Landroid/app/NotificationChannel;

    const-string v5, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d"

    invoke-static {v1, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v7, "bluetooth_calls"

    const/4 v8, 0x4

    invoke-direct {v4, v7, v5, v8}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    invoke-virtual {v0, v4}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    new-instance v4, Landroid/content/Intent;

    const-class v5, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v4, v1, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v5, "ru.drivedeck.launcher.PHONE"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    const/high16 v5, 0x14000000

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v4

    const/high16 v5, 0xc000000

    invoke-static {v1, v3, v4, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v4

    new-instance v5, Landroid/app/Notification$Builder;

    invoke-direct {v5, v1, v7}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const v7, 0x7f030053

    invoke-virtual {v5, v7}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v5

    invoke-static {v1, v13}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v5

    iget-object v7, v6, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_1a

    iget-object v6, v6, Lc/e8;->b:Ljava/lang/String;

    goto :goto_a

    :cond_1a
    iget-object v6, v6, Lc/e8;->c:Ljava/lang/String;

    :goto_a
    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v5

    const-string v6, "call"

    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    iput-object v2, v1, Lru/drivedeck/launcher/MainActivity;->e0:Ljava/lang/String;

    :cond_1b
    :goto_b
    return-void

    :pswitch_a
    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    move-object/from16 v0, p0

    iget-object v2, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iget-wide v5, v2, Lru/drivedeck/launcher/MainActivity;->H:J

    cmp-long v3, v3, v5

    if-gez v3, :cond_1d

    invoke-virtual {v2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->hasWindowFocus()Z

    move-result v3

    if-nez v3, :cond_1d

    const/4 v3, 0x0

    invoke-static {v2, v1, v3}, Lc/j8;->p(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v3

    const/4 v4, 0x1

    if-eq v3, v4, :cond_1c

    goto :goto_c

    :cond_1c
    iput-wide v9, v2, Lru/drivedeck/launcher/MainActivity;->H:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    iput-wide v3, v2, Lru/drivedeck/launcher/MainActivity;->I:J

    const-string v2, "package"

    filled-new-array {v2, v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "radio_home_recovery"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    sget-object v1, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v1, :cond_1d

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    invoke-virtual {v1, v8}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    iget-object v1, v1, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v1, :cond_1d

    invoke-virtual {v1}, Lc/S1;->c()V

    :cond_1d
    :goto_c
    return-void

    :pswitch_b
    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->R()V

    return-void

    :pswitch_c
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->A0:Z

    if-eqz v2, :cond_2a

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_2a

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_1e

    goto/16 :goto_13

    :cond_1e
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    iget-boolean v4, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v4, :cond_22

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v4, :cond_21

    iget-object v5, v4, Lc/Q3;->J:Lc/u0;

    sget-object v6, Lc/s0;->i:Lc/s0;

    invoke-virtual {v5, v6}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v5

    iget-object v6, v4, Lc/Q3;->J:Lc/u0;

    sget-object v7, Lc/s0;->m:Lc/s0;

    invoke-virtual {v6, v7}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v6

    if-eqz v5, :cond_1f

    iget-boolean v5, v5, Lc/r0;->g:Z

    if-nez v5, :cond_1f

    iget-object v5, v4, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v5}, Lc/t2;->l0()Z

    move-result v5

    if-eqz v5, :cond_21

    :cond_1f
    if-eqz v6, :cond_20

    iget-boolean v5, v6, Lc/r0;->g:Z

    if-nez v5, :cond_20

    iget-object v4, v4, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v4}, Lc/t2;->l0()Z

    move-result v4

    if-eqz v4, :cond_21

    :cond_20
    const/4 v4, 0x1

    goto :goto_f

    :cond_21
    :goto_d
    const/4 v4, 0x0

    goto :goto_f

    :cond_22
    iget-boolean v4, v1, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v4, :cond_20

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v4, :cond_21

    iget-object v4, v4, Lc/m2;->t:[Lc/t2;

    array-length v5, v4

    const/4 v6, 0x0

    :goto_e
    if-ge v6, v5, :cond_20

    aget-object v7, v4, v6

    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    move-result v8

    if-nez v8, :cond_23

    invoke-virtual {v7}, Lc/t2;->l0()Z

    move-result v7

    if-nez v7, :cond_23

    goto :goto_d

    :cond_23
    const/4 v7, 0x1

    add-int/2addr v6, v7

    goto :goto_e

    :goto_f
    if-eqz v4, :cond_24

    iget-wide v5, v1, Lru/drivedeck/launcher/MainActivity;->z0:J

    cmp-long v5, v5, v9

    if-nez v5, :cond_24

    iput-wide v2, v1, Lru/drivedeck/launcher/MainActivity;->z0:J

    :cond_24
    if-nez v4, :cond_25

    iput-wide v9, v1, Lru/drivedeck/launcher/MainActivity;->z0:J

    :cond_25
    iget-wide v5, v1, Lru/drivedeck/launcher/MainActivity;->y0:J

    cmp-long v5, v2, v5

    if-gez v5, :cond_26

    if-eqz v4, :cond_27

    iget-wide v4, v1, Lru/drivedeck/launcher/MainActivity;->z0:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x2ee

    cmp-long v2, v2, v4

    if-gez v2, :cond_26

    goto :goto_10

    :cond_26
    const/4 v2, 0x0

    goto :goto_11

    :cond_27
    :goto_10
    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->C0:Lc/J1;

    const-wide/16 v3, 0xfa

    invoke-virtual {v2, v1, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_13

    :goto_11
    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->A0:Z

    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-eqz v2, :cond_29

    iget-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->z:Z

    if-nez v2, :cond_29

    iget v2, v1, Lru/drivedeck/launcher/MainActivity;->B0:I

    sget v3, Lc/G8;->B:I

    if-ne v2, v3, :cond_29

    sget-boolean v2, Lc/G8;->z:Z

    if-eqz v2, :cond_28

    goto :goto_12

    :cond_28
    const/4 v2, 0x1

    sput-boolean v2, Lc/G8;->z:Z

    invoke-static {v1}, Lc/G8;->t0(Landroid/content/Context;)V

    :cond_29
    :goto_12
    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    new-instance v3, Lc/J1;

    const/16 v4, 0x1b

    invoke-direct {v3, v1, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v2, v3}, Lc/z;->j(Ljava/lang/Runnable;)V

    :cond_2a
    :goto_13
    return-void

    :pswitch_d
    iget-object v2, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    iget-boolean v3, v2, Lru/drivedeck/launcher/MainActivity;->L:Z

    if-eqz v3, :cond_2e

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-eqz v3, :cond_2b

    iget-boolean v3, v3, Lc/P;->o:Z

    if-eqz v3, :cond_2b

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    iget-boolean v3, v3, Lc/P;->n:Z

    if-eqz v3, :cond_2b

    goto :goto_15

    :cond_2b
    const/4 v3, 0x0

    iput-boolean v3, v2, Lru/drivedeck/launcher/MainActivity;->L:Z

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3, v6, v9, v10}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    iget-wide v5, v2, Lru/drivedeck/launcher/MainActivity;->M:J

    cmp-long v3, v3, v5

    if-nez v3, :cond_2e

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->e0()Z

    move-result v3

    if-eqz v3, :cond_2c

    goto :goto_15

    :cond_2c
    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l0()Z

    move-result v3

    if-eqz v3, :cond_2d

    iget-object v3, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    new-instance v1, Lc/G;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v2, v3, v4, v1}, Lc/J;->g(Landroid/content/Context;ILc/H;Ljava/util/function/BooleanSupplier;)Z

    move-result v1

    goto :goto_14

    :cond_2d
    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v1

    :goto_14
    if-nez v1, :cond_2e

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lc/G8;->p0(Landroid/content/Context;Ljava/lang/String;)Z

    :cond_2e
    :goto_15
    return-void

    :pswitch_e
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->K()V

    return-void

    :pswitch_f
    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0444\u0430\u0439\u043b"

    invoke-static {v1, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_10
    move v2, v11

    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b"

    invoke-static {v1, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_11
    move v2, v11

    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0432 \u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0438"

    iget-object v2, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_12
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lc/q4;->e(Lru/drivedeck/launcher/MainActivity;Z)V

    return-void

    :pswitch_13
    move v2, v11

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v2}, Lc/q4;->e(Lru/drivedeck/launcher/MainActivity;Z)V

    return-void

    :pswitch_14
    new-instance v1, Landroid/app/Dialog;

    iget-object v2, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v1, v2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v3

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v4

    const-string v5, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043f\u0440\u0435\u0441\u0435\u0442\u0430"

    invoke-static {v2, v5}, Lc/q4;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v6, Landroid/widget/EditText;

    invoke-direct {v6, v2}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/high16 v7, 0x41800000    # 16.0f

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    iget v7, v4, Lc/r4;->d:I

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    iget v7, v4, Lc/r4;->e:I

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setHintTextColor(I)V

    invoke-static {v2, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    invoke-static {v2, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v6, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/high16 v5, 0x41400000    # 12.0f

    invoke-static {v2, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v6, v5, v5, v5, v5}, Landroid/view/View;->setPadding(IIII)V

    const/high16 v5, 0x42400000    # 48.0f

    invoke-static {v2, v5}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v5

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setMinHeight(I)V

    iget v4, v4, Lc/r4;->b:I

    const/16 v5, 0x10

    invoke-static {v2, v4, v5}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v6, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    new-instance v4, Landroid/text/InputFilter$LengthFilter;

    const/16 v5, 0x40

    invoke-direct {v4, v5}, Landroid/text/InputFilter$LengthFilter;-><init>(I)V

    const/4 v5, 0x1

    new-array v7, v5, [Landroid/text/InputFilter;

    const/4 v9, 0x0

    aput-object v4, v7, v9

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setFilters([Landroid/text/InputFilter;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v9, -0x2

    invoke-direct {v4, v7, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v6, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    invoke-static {v2, v4, v5}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    new-instance v7, Lc/l;

    const/4 v9, 0x7

    invoke-direct {v7, v2, v6, v1, v9}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v6, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v2, v1, v6}, Lc/q4;->g(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v6

    new-array v7, v8, [Landroid/view/View;

    const/4 v8, 0x0

    aput-object v6, v7, v8

    aput-object v4, v7, v5

    const-string v4, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043f\u0440\u0435\u0441\u0435\u0442 \u0433\u043b\u0430\u0432\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430"

    invoke-static {v1, v2, v4, v3, v7}, Lc/q4;->q(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;[Landroid/view/View;)V

    return-void

    :pswitch_15
    move v8, v11

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v8}, Lc/q4;->r(Lru/drivedeck/launcher/MainActivity;Z)V

    return-void

    :pswitch_16
    move v5, v12

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v5}, Lc/q4;->r(Lru/drivedeck/launcher/MainActivity;Z)V

    return-void

    :pswitch_17
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443"

    invoke-static {v1, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_18
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0430"

    invoke-static {v1, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_19
    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0444\u0430\u0439\u043b \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0438"

    invoke-static {v1, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    return-void

    :pswitch_1a
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->U()V

    return-void

    :pswitch_1b
    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043e\u0442\u0447\u0451\u0442\u044b"

    const/4 v3, 0x1

    invoke-static {v1, v2, v1, v3}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :pswitch_1c
    move v3, v12

    iget-object v1, v0, Lc/J1;->b:Lru/drivedeck/launcher/MainActivity;

    const-string v2, "\u0417\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u0447\u0451\u0442\u044b \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b"

    invoke-static {v1, v2, v1, v3}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
