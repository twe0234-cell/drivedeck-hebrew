.class public final Lc/s4;
.super Landroid/view/View;
.source "SourceFile"

# interfaces
.implements Lc/q8;


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/Paint;

.field public final c:Lc/z;

.field public final d:Lc/n1;

.field public final e:Lru/drivedeck/launcher/MainActivity;

.field public final f:Lc/r4;

.field public final g:[Landroid/graphics/RectF;

.field public final h:Landroid/graphics/RectF;

.field public final i:Ljava/util/ArrayList;

.field public final j:Ljava/util/ArrayList;

.field public k:F

.field public l:F

.field public m:J


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lru/drivedeck/launcher/MainActivity;)V
    .locals 4

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/s4;->a:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/s4;->b:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    filled-new-array {v2, v3}, [Landroid/graphics/RectF;

    move-result-object v2

    iput-object v2, p0, Lc/s4;->g:[Landroid/graphics/RectF;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2}, Landroid/graphics/RectF;-><init>()V

    iput-object v2, p0, Lc/s4;->h:Landroid/graphics/RectF;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/s4;->i:Ljava/util/ArrayList;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Lc/s4;->j:Ljava/util/ArrayList;

    iput-object p2, p0, Lc/s4;->c:Lc/z;

    iput-object p3, p0, Lc/s4;->d:Lc/n1;

    iput-object p4, p0, Lc/s4;->e:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p2

    iput-object p2, p0, Lc/s4;->f:Lc/r4;

    const-string p2, "sans"

    const/4 p3, 0x0

    invoke-static {p2, p3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p2

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {p0, v1}, Landroid/view/View;->setFocusable(Z)V

    const-string p2, "\u0414\u043e\u043c\u0430\u0448\u043d\u0438\u0439 \u044d\u043a\u0440\u0430\u043d DriveDeck"

    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public static g(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;F)V
    .locals 3

    if-nez p1, :cond_0

    return-void

    :cond_0
    iget v0, p2, Landroid/graphics/RectF;->left:F

    add-float/2addr v0, p3

    float-to-int v0, v0

    iget v1, p2, Landroid/graphics/RectF;->top:F

    add-float/2addr v1, p3

    float-to-int v1, v1

    iget v2, p2, Landroid/graphics/RectF;->right:F

    sub-float/2addr v2, p3

    float-to-int v2, v2

    iget p2, p2, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr p2, p3

    float-to-int p2, p2

    invoke-virtual {p1, v0, v1, v2, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method


# virtual methods
.method public final d(Ljava/util/ArrayList;)V
    .locals 4

    const/4 v0, 0x0

    move v1, v0

    :goto_0
    iget-object v2, p0, Lc/s4;->g:[Landroid/graphics/RectF;

    array-length v3, v2

    if-ge v1, v3, :cond_0

    aget-object v2, v2, v1

    invoke-virtual {p0, p1, v1, v2}, Lc/s4;->i(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lc/s4;->h:Landroid/graphics/RectF;

    const/4 v2, -0x1

    invoke-virtual {p0, p1, v2, v1}, Lc/s4;->i(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    :goto_1
    iget-object v1, p0, Lc/s4;->i:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    add-int/lit8 v2, v0, 0x2

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    invoke-virtual {p0, p1, v2, v1}, Lc/s4;->i(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1
    return-void
.end method

.method public final f(F)F
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final h(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    iget-object v4, v0, Lc/s4;->f:Lc/r4;

    if-eqz p4, :cond_0

    iget v5, v4, Lc/r4;->b:I

    goto :goto_0

    :cond_0
    iget v5, v4, Lc/r4;->c:I

    :goto_0
    const/high16 v6, 0x42000000    # 32.0f

    invoke-virtual {v0, v6}, Lc/s4;->f(F)F

    move-result v7

    iget-object v8, v0, Lc/s4;->a:Landroid/graphics/Paint;

    invoke-virtual {v8, v5}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v1, v2, v7, v7, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    sget-object v7, Lc/r4;->p:Lc/r4;

    if-eq v4, v7, :cond_1

    sget-object v7, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v0, v7}, Lc/s4;->f(F)F

    move-result v7

    invoke-virtual {v8, v7}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    iget v7, v4, Lc/r4;->h:I

    invoke-virtual {v8, v7}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v0, v6}, Lc/s4;->f(F)F

    move-result v7

    invoke-virtual {v0, v6}, Lc/s4;->f(F)F

    move-result v6

    invoke-virtual {v1, v2, v7, v6, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v8, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    :cond_1
    iget-object v6, v0, Lc/s4;->d:Lc/n1;

    invoke-virtual {v6, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v6

    iget-object v7, v0, Lc/s4;->c:Lc/z;

    invoke-virtual {v7, v6}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v6

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v7

    const v9, 0x3e6147ae    # 0.22f

    mul-float/2addr v7, v9

    const/high16 v9, 0x42e80000    # 116.0f

    invoke-virtual {v0, v9}, Lc/s4;->f(F)F

    move-result v9

    invoke-static {v7, v9}, Ljava/lang/Math;->min(FF)F

    move-result v7

    iget v9, v2, Landroid/graphics/RectF;->left:F

    const/high16 v10, 0x42080000    # 34.0f

    invoke-virtual {v0, v10}, Lc/s4;->f(F)F

    move-result v11

    add-float/2addr v11, v9

    iget v9, v2, Landroid/graphics/RectF;->top:F

    const/high16 v12, 0x41f00000    # 30.0f

    invoke-virtual {v0, v12}, Lc/s4;->f(F)F

    move-result v12

    add-float/2addr v12, v9

    new-instance v9, Landroid/graphics/RectF;

    add-float v13, v11, v7

    add-float/2addr v7, v12

    invoke-direct {v9, v11, v12, v13, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v7, 0x41c80000    # 25.0f

    invoke-virtual {v0, v7}, Lc/s4;->f(F)F

    move-result v7

    iget v11, v4, Lc/r4;->c:I

    invoke-virtual {v8, v11}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v8, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v1, v9, v7, v7, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    iget-object v5, v0, Lc/s4;->b:Landroid/graphics/Paint;

    const/4 v7, 0x0

    const-string v11, "sans"

    if-eqz v6, :cond_2

    const/high16 v12, 0x41880000    # 17.0f

    invoke-virtual {v0, v12}, Lc/s4;->f(F)F

    move-result v12

    iget-object v13, v6, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v1, v13, v9, v12}, Lc/s4;->g(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;F)V

    goto :goto_1

    :cond_2
    invoke-virtual {v9}, Landroid/graphics/RectF;->centerX()F

    move-result v12

    invoke-virtual {v9}, Landroid/graphics/RectF;->centerY()F

    move-result v13

    const/high16 v14, 0x41600000    # 14.0f

    invoke-virtual {v0, v14}, Lc/s4;->f(F)F

    move-result v14

    add-float/2addr v14, v13

    const/high16 v13, 0x42400000    # 48.0f

    invoke-virtual {v0, v13}, Lc/s4;->f(F)F

    move-result v13

    iget v15, v4, Lc/r4;->f:I

    invoke-virtual {v5, v15}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-static {v11, v7}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v13

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const-string v13, "+"

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v15

    const/high16 v16, 0x40000000    # 2.0f

    div-float v15, v15, v16

    sub-float/2addr v12, v15

    invoke-virtual {v1, v13, v12, v14, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    :goto_1
    if-nez v3, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v12, "\u041e\u0421\u041d\u041e\u0412\u041d\u041e\u0415"

    :goto_2
    invoke-static {v3, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_3

    :cond_3
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v12, "\u0420\u042f\u0414\u041e\u041c"

    goto :goto_2

    :goto_3
    const/4 v12, 0x1

    invoke-static {v11, v12}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v13

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    iget v13, v4, Lc/r4;->e:I

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual {v0, v13}, Lc/s4;->f(F)F

    move-result v13

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    iget v13, v2, Landroid/graphics/RectF;->left:F

    invoke-virtual {v0, v10}, Lc/s4;->f(F)F

    move-result v14

    add-float/2addr v14, v13

    iget v13, v9, Landroid/graphics/RectF;->bottom:F

    const/high16 v15, 0x42180000    # 38.0f

    invoke-virtual {v0, v15}, Lc/s4;->f(F)F

    move-result v15

    add-float/2addr v15, v13

    invoke-virtual {v1, v3, v14, v15, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    if-nez v6, :cond_4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const-string v6, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v3, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_4

    :cond_4
    iget-object v3, v6, Lc/a;->b:Ljava/lang/String;

    :goto_4
    iget v6, v4, Lc/r4;->d:I

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    if-eqz p4, :cond_5

    const/high16 v13, 0x41f80000    # 31.0f

    :goto_5
    invoke-virtual {v0, v13}, Lc/s4;->f(F)F

    move-result v13

    goto :goto_6

    :cond_5
    const/high16 v13, 0x41d00000    # 26.0f

    goto :goto_5

    :goto_6
    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-static {v11, v12}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v11

    invoke-virtual {v5, v11}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v11

    const/high16 v13, 0x42880000    # 68.0f

    invoke-virtual {v0, v13}, Lc/s4;->f(F)F

    move-result v13

    sub-float/2addr v11, v13

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v13

    cmpg-float v13, v13, v11

    if-gtz v13, :cond_6

    goto :goto_8

    :cond_6
    :goto_7
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v13

    const-string v14, "\u2026"

    if-le v13, v12, :cond_7

    invoke-virtual {v3, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v5, v13}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v13

    cmpl-float v13, v13, v11

    if-lez v13, :cond_7

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v13

    sub-int/2addr v13, v12

    invoke-virtual {v3, v7, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    goto :goto_7

    :cond_7
    invoke-virtual {v3, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_8
    iget v7, v2, Landroid/graphics/RectF;->left:F

    invoke-virtual {v0, v10}, Lc/s4;->f(F)F

    move-result v10

    add-float/2addr v10, v7

    iget v7, v9, Landroid/graphics/RectF;->bottom:F

    const/high16 v9, 0x429c0000    # 78.0f

    invoke-virtual {v0, v9}, Lc/s4;->f(F)F

    move-result v9

    add-float/2addr v9, v7

    invoke-virtual {v1, v3, v10, v9, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    new-instance v3, Landroid/graphics/RectF;

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    const/high16 v7, 0x42280000    # 42.0f

    invoke-virtual {v0, v7}, Lc/s4;->f(F)F

    move-result v9

    sub-float/2addr v5, v9

    iget v9, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 v10, 0x41500000    # 13.0f

    invoke-virtual {v0, v10}, Lc/s4;->f(F)F

    move-result v10

    sub-float/2addr v9, v10

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->centerX()F

    move-result v10

    invoke-virtual {v0, v7}, Lc/s4;->f(F)F

    move-result v7

    add-float/2addr v7, v10

    iget v2, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 v10, 0x41100000    # 9.0f

    invoke-virtual {v0, v10}, Lc/s4;->f(F)F

    move-result v10

    sub-float/2addr v2, v10

    invoke-direct {v3, v5, v9, v7, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v2, 0x40400000    # 3.0f

    invoke-virtual {v0, v2}, Lc/s4;->f(F)F

    move-result v2

    iget-boolean v4, v4, Lc/r4;->m:Z

    if-eqz v4, :cond_8

    const/16 v4, 0x52

    const/16 v5, 0x60

    const/16 v6, 0x6a

    invoke-static {v4, v5, v6}, Landroid/graphics/Color;->rgb(III)I

    move-result v6

    :cond_8
    invoke-virtual {v8, v6}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {v1, v3, v2, v2, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final i(Ljava/util/ArrayList;ILandroid/graphics/RectF;)V
    .locals 6

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3, p3}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    new-instance v4, Lc/H;

    const/16 p3, 0x13

    invoke-direct {v4, p0, v3, p3}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    if-eqz p2, :cond_1

    const/4 p3, 0x1

    if-ne p2, p3, :cond_0

    goto :goto_0

    :cond_0
    iget-object p3, p0, Lc/s4;->e:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lc/J1;

    const/16 v1, 0xe

    invoke-direct {v0, p3, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    move-object v5, v0

    goto :goto_1

    :cond_1
    :goto_0
    new-instance p3, Lc/w;

    const/4 v0, 0x4

    invoke-direct {p3, p0, p2, v0}, Lc/w;-><init>(Ljava/lang/Object;II)V

    move-object v5, p3

    :goto_1
    move-object v0, p1

    move-object v1, p0

    move v2, p2

    invoke-static/range {v0 .. v5}, Lc/t8;->b(Ljava/util/ArrayList;Landroid/view/View;ILandroid/graphics/RectF;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 26

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v6, v1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v5, v1

    sget-object v1, Lc/r4;->p:Lc/r4;

    iget-object v4, v0, Lc/s4;->a:Landroid/graphics/Paint;

    const/4 v3, 0x0

    iget-object v2, v0, Lc/s4;->f:Lc/r4;

    if-ne v2, v1, :cond_0

    iget v1, v2, Lc/r4;->a:I

    invoke-virtual {v7, v1}, Landroid/graphics/Canvas;->drawColor(I)V

    move-object v10, v2

    move-object v9, v3

    move-object v8, v4

    move v11, v5

    move v12, v6

    goto :goto_2

    :cond_0
    new-instance v1, Landroid/graphics/LinearGradient;

    iget v13, v2, Lc/r4;->a:I

    iget-boolean v8, v2, Lc/r4;->m:Z

    if-eqz v8, :cond_1

    const/16 v8, 0xe8

    const/16 v9, 0xd9

    const/16 v10, 0xe2

    :goto_0
    invoke-static {v9, v10, v8}, Landroid/graphics/Color;->rgb(III)I

    move-result v8

    move v14, v8

    goto :goto_1

    :cond_1
    const/16 v8, 0x1f

    const/16 v9, 0x11

    const/16 v10, 0x1c

    goto :goto_0

    :goto_1
    sget-object v15, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v8, v1

    move v11, v6

    move v12, v5

    invoke-direct/range {v8 .. v15}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v4, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v8, 0x0

    move-object/from16 v1, p1

    move-object v10, v2

    move v2, v9

    move-object v9, v3

    move v3, v8

    move-object v8, v4

    move v4, v6

    move v11, v5

    move v12, v6

    move-object v6, v8

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :goto_2
    const/high16 v1, 0x42d00000    # 104.0f

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v1

    iget v2, v10, Lc/r4;->i:I

    invoke-virtual {v8, v2}, Landroid/graphics/Paint;->setColor(I)V

    new-instance v2, Landroid/graphics/RectF;

    const/high16 v3, 0x41400000    # 12.0f

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v4

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v5

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v6

    sub-float v6, v11, v6

    invoke-direct {v2, v4, v5, v1, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v4, 0x42000000    # 32.0f

    invoke-virtual {v0, v4}, Lc/s4;->f(F)F

    move-result v5

    invoke-virtual {v0, v4}, Lc/s4;->f(F)F

    move-result v4

    invoke-virtual {v7, v2, v5, v4, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const/high16 v5, 0x42800000    # 64.0f

    invoke-static {v4, v5}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v4

    const/high16 v5, 0x42100000    # 36.0f

    invoke-virtual {v0, v5}, Lc/s4;->f(F)F

    move-result v5

    invoke-virtual {v2}, Landroid/graphics/RectF;->centerX()F

    move-result v6

    const/high16 v8, 0x40000000    # 2.0f

    div-float v13, v4, v8

    sub-float/2addr v6, v13

    iget v13, v2, Landroid/graphics/RectF;->top:F

    const/high16 v14, 0x42940000    # 74.0f

    invoke-virtual {v0, v14}, Lc/s4;->f(F)F

    move-result v14

    add-float/2addr v14, v13

    iget-object v13, v0, Lc/s4;->i:Ljava/util/ArrayList;

    invoke-virtual {v13}, Ljava/util/ArrayList;->clear()V

    iget-object v15, v0, Lc/s4;->j:Ljava/util/ArrayList;

    invoke-virtual {v15}, Ljava/util/ArrayList;->clear()V

    iget v9, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 v8, 0x41200000    # 10.0f

    invoke-virtual {v0, v8}, Lc/s4;->f(F)F

    move-result v16

    sub-float v9, v9, v16

    sub-float/2addr v9, v4

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v16

    sub-float v16, v9, v16

    sub-float v16, v16, v14

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v17

    add-float v17, v17, v16

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v16

    add-float v16, v16, v4

    div-float v8, v17, v16

    move/from16 v16, v4

    float-to-double v3, v8

    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    move-result-wide v3

    double-to-int v3, v3

    const/4 v4, 0x1

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget-object v8, v0, Lc/s4;->d:Lc/n1;

    invoke-virtual {v8}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v8

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_2

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v4, v18

    check-cast v4, Ljava/lang/String;

    move-object/from16 v18, v8

    invoke-virtual {v15}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lt v8, v3, :cond_3

    :cond_2
    move/from16 v22, v1

    move/from16 v20, v11

    move/from16 v21, v12

    goto/16 :goto_8

    :cond_3
    invoke-static {v4}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move/from16 v19, v3

    iget-object v3, v0, Lc/s4;->c:Lc/z;

    invoke-virtual {v3, v8}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v8

    invoke-static {v4}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v20

    if-eqz v20, :cond_4

    move/from16 v20, v11

    invoke-static {v4}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v3

    goto :goto_4

    :cond_4
    move/from16 v20, v11

    const/4 v3, 0x0

    :goto_4
    if-eqz v8, :cond_5

    invoke-static {v4}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_6

    if-nez v3, :cond_6

    :cond_5
    move/from16 v22, v1

    move/from16 v25, v5

    move/from16 v21, v12

    const/high16 v1, 0x40c00000    # 6.0f

    goto :goto_7

    :cond_6
    new-instance v11, Landroid/graphics/RectF;

    move/from16 v21, v12

    add-float v12, v6, v16

    move/from16 v22, v1

    add-float v1, v14, v16

    invoke-direct {v11, v6, v14, v12, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v13, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v15, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/graphics/RectF;

    invoke-virtual {v11}, Landroid/graphics/RectF;->centerX()F

    move-result v4

    const/high16 v12, 0x40000000    # 2.0f

    div-float v23, v5, v12

    sub-float v4, v4, v23

    invoke-virtual {v11}, Landroid/graphics/RectF;->centerY()F

    move-result v12

    sub-float v12, v12, v23

    invoke-virtual {v11}, Landroid/graphics/RectF;->centerX()F

    move-result v24

    move/from16 v25, v5

    add-float v5, v24, v23

    invoke-virtual {v11}, Landroid/graphics/RectF;->centerY()F

    move-result v11

    add-float v11, v11, v23

    invoke-direct {v1, v4, v12, v5, v11}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v4, v8, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    if-nez v3, :cond_7

    const/4 v3, 0x0

    invoke-static {v7, v4, v1, v3}, Lc/s4;->g(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;F)V

    :goto_5
    const/high16 v1, 0x40c00000    # 6.0f

    goto :goto_6

    :cond_7
    iget-object v3, v3, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {v7, v4, v3, v1}, Lc/s;->c(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;)V

    goto :goto_5

    :goto_6
    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v3

    add-float v3, v3, v16

    add-float/2addr v14, v3

    :goto_7
    move-object/from16 v8, v18

    move/from16 v3, v19

    move/from16 v11, v20

    move/from16 v12, v21

    move/from16 v1, v22

    move/from16 v5, v25

    const/4 v4, 0x1

    goto/16 :goto_3

    :goto_8
    iget-object v1, v0, Lc/s4;->h:Landroid/graphics/RectF;

    add-float v4, v6, v16

    iget v2, v2, Landroid/graphics/RectF;->bottom:F

    const/high16 v3, 0x41200000    # 10.0f

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v3

    sub-float/2addr v2, v3

    invoke-virtual {v1, v6, v9, v4, v2}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerX()F

    move-result v2

    invoke-virtual {v1}, Landroid/graphics/RectF;->centerY()F

    move-result v1

    const/high16 v3, 0x42400000    # 48.0f

    invoke-virtual {v0, v3}, Lc/s4;->f(F)F

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    new-instance v5, Landroid/graphics/RectF;

    const/high16 v6, 0x40000000    # 2.0f

    div-float/2addr v3, v6

    sub-float v6, v2, v3

    sub-float v8, v1, v3

    add-float/2addr v2, v3

    add-float/2addr v1, v3

    invoke-direct {v5, v6, v8, v2, v1}, Landroid/graphics/RectF;-><init>(FFFF)V

    const v1, 0x7f030017

    iget v2, v10, Lc/r4;->j:I

    invoke-static {v4, v7, v1, v2, v5}, Lc/S4;->a(Landroid/content/Context;Landroid/graphics/Canvas;IILandroid/graphics/RectF;)V

    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v2

    add-float v2, v2, v22

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v3

    sub-float v6, v21, v3

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v3

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v4

    sub-float v5, v20, v4

    invoke-virtual {v0, v1}, Lc/s4;->f(F)F

    move-result v1

    sub-float v4, v6, v2

    sub-float/2addr v4, v1

    const/high16 v8, 0x3f000000    # 0.5f

    mul-float/2addr v4, v8

    iget-object v8, v0, Lc/s4;->g:[Landroid/graphics/RectF;

    const/4 v9, 0x0

    aget-object v10, v8, v9

    add-float/2addr v4, v2

    invoke-virtual {v10, v2, v3, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v2, 0x1

    aget-object v10, v8, v2

    add-float/2addr v4, v1

    invoke-virtual {v10, v4, v3, v6, v5}, Landroid/graphics/RectF;->set(FFFF)V

    aget-object v1, v8, v9

    invoke-virtual {v0, v7, v1, v9, v2}, Lc/s4;->h(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V

    aget-object v1, v8, v2

    invoke-virtual {v0, v7, v1, v2, v9}, Lc/s4;->h(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZ)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 11

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lc/s4;->k:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iput p1, p0, Lc/s4;->l:F

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iput-wide v2, p0, Lc/s4;->m:J

    return v1

    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-eq v0, v1, :cond_1

    return v1

    :cond_1
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v2, p0, Lc/s4;->k:F

    sub-float v2, v0, v2

    iget v3, p0, Lc/s4;->l:F

    sub-float v3, p1, v3

    const/4 v4, 0x0

    move v5, v4

    :goto_0
    iget-object v6, p0, Lc/s4;->g:[Landroid/graphics/RectF;

    array-length v7, v6

    iget-object v8, p0, Lc/s4;->e:Lru/drivedeck/launcher/MainActivity;

    if-ge v5, v7, :cond_5

    aget-object v6, v6, v5

    iget v7, p0, Lc/s4;->k:F

    iget v9, p0, Lc/s4;->l:F

    invoke-virtual {v6, v7, v9}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v6

    if-nez v6, :cond_2

    goto :goto_1

    :cond_2
    const/high16 v6, 0x428c0000    # 70.0f

    invoke-virtual {p0, v6}, Lc/s4;->f(F)F

    move-result v6

    neg-float v6, v6

    cmpg-float v6, v3, v6

    if-gez v6, :cond_3

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v6

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v7

    cmpl-float v6, v6, v7

    if-lez v6, :cond_3

    invoke-virtual {v8, v5}, Lru/drivedeck/launcher/MainActivity;->g(I)V

    return v1

    :cond_3
    const/high16 v6, 0x42b40000    # 90.0f

    invoke-virtual {p0, v6}, Lc/s4;->f(F)F

    move-result v6

    neg-float v6, v6

    cmpg-float v6, v2, v6

    if-gez v6, :cond_4

    invoke-static {v2}, Ljava/lang/Math;->abs(F)F

    move-result v6

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v7

    cmpl-float v6, v6, v7

    if-lez v6, :cond_4

    invoke-virtual {v8, v5}, Lru/drivedeck/launcher/MainActivity;->M(I)V

    return v1

    :cond_4
    :goto_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_5
    float-to-double v9, v2

    float-to-double v2, v3

    invoke-static {v9, v10, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v2

    const/high16 v5, 0x41b00000    # 22.0f

    invoke-virtual {p0, v5}, Lc/s4;->f(F)F

    move-result v5

    float-to-double v9, v5

    cmpl-double v2, v2, v9

    if-lez v2, :cond_6

    return v1

    :cond_6
    move v2, v4

    :goto_2
    array-length v3, v6

    if-ge v2, v3, :cond_c

    aget-object v3, v6, v2

    invoke-virtual {v3, v0, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_b

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-wide v5, p0, Lc/s4;->m:J

    sub-long/2addr v3, v5

    const-wide/16 v5, 0x226

    cmp-long p1, v3, v5

    if-lez p1, :cond_7

    invoke-virtual {v8, v2}, Lru/drivedeck/launcher/MainActivity;->L(I)V

    goto :goto_3

    :cond_7
    iget-boolean p1, v8, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz p1, :cond_8

    iget-object p1, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_8

    if-ltz v2, :cond_a

    iget-object p1, p1, Lc/m2;->t:[Lc/t2;

    array-length v0, p1

    if-ge v2, v0, :cond_a

    aget-object p1, p1, v2

    invoke-virtual {p1}, Lc/t2;->S()V

    invoke-virtual {p1}, Lc/t2;->j()V

    iput-boolean v1, p1, Lc/t2;->R0:Z

    invoke-virtual {p1}, Lc/t2;->D()V

    goto :goto_3

    :cond_8
    iget-object p1, v8, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_9

    invoke-virtual {v8, v2}, Lru/drivedeck/launcher/MainActivity;->g(I)V

    goto :goto_3

    :cond_9
    invoke-virtual {v8}, Lru/drivedeck/launcher/MainActivity;->D()V

    :cond_a
    :goto_3
    return v1

    :cond_b
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_c
    iget v2, p0, Lc/s4;->k:F

    const/high16 v3, 0x42d00000    # 104.0f

    invoke-virtual {p0, v3}, Lc/s4;->f(F)F

    move-result v3

    cmpg-float v2, v2, v3

    if-gtz v2, :cond_d

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    iget-wide v5, p0, Lc/s4;->m:J

    sub-long/2addr v2, v5

    const-wide/16 v5, 0x28a

    cmp-long v2, v2, v5

    if-ltz v2, :cond_d

    invoke-virtual {v8}, Lru/drivedeck/launcher/MainActivity;->K()V

    goto :goto_5

    :cond_d
    iget-object v2, p0, Lc/s4;->h:Landroid/graphics/RectF;

    invoke-virtual {v2, v0, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v2

    if-eqz v2, :cond_e

    invoke-virtual {v8}, Lru/drivedeck/launcher/MainActivity;->H()V

    goto :goto_5

    :cond_e
    iget-object v2, p0, Lc/s4;->i:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_11

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/graphics/RectF;

    invoke-virtual {v3, v0, p1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v3

    if-eqz v3, :cond_10

    iget-object p1, p0, Lc/s4;->j:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge v4, v0, :cond_11

    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-static {p1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static {p1}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {p1}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result p1

    invoke-virtual {v8, v0, v2, p1}, Lru/drivedeck/launcher/MainActivity;->J(Ljava/lang/String;Ljava/lang/String;F)V

    goto :goto_5

    :cond_f
    invoke-virtual {v8, p1}, Lru/drivedeck/launcher/MainActivity;->I(Ljava/lang/String;)V

    goto :goto_5

    :cond_10
    add-int/lit8 v4, v4, 0x1

    goto :goto_4

    :cond_11
    :goto_5
    return v1
.end method

.method public final performClick()Z
    .locals 1

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 v0, 0x1

    return v0
.end method
