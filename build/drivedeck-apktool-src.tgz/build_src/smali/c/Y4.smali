.class public final Lc/Y4;
.super Landroid/widget/HorizontalScrollView;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/a5;


# direct methods
.method public constructor <init>(Lc/a5;Landroid/content/Context;)V
    .locals 0

    iput-object p1, p0, Lc/Y4;->a:Lc/a5;

    invoke-direct {p0, p2}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final onScrollChanged(IIII)V
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onScrollChanged(IIII)V

    iget-object p1, p0, Lc/Y4;->a:Lc/a5;

    invoke-virtual {p1}, Lc/a5;->h()V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x1

    iget-object v2, p0, Lc/Y4;->a:Lc/a5;

    if-nez v0, :cond_0

    iput-boolean v1, v2, Lc/a5;->k:Z

    iget-object v0, v2, Lc/a5;->l:Lc/e1;

    invoke-virtual {v2, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_0
    invoke-super {p0, p1}, Landroid/widget/HorizontalScrollView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v3

    if-eq v3, v1, :cond_1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, v2, Lc/a5;->k:Z

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result p1

    iput p1, v2, Lc/a5;->j:I

    const-wide/16 v3, 0x50

    iget-object p1, v2, Lc/a5;->l:Lc/e1;

    invoke-virtual {v2, p1, v3, v4}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    return v0
.end method
