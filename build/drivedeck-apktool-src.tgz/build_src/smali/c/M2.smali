.class public final synthetic Lc/M2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/k3;

.field public final synthetic b:Landroid/widget/LinearLayout;

.field public final synthetic c:Landroid/widget/GridLayout;

.field public final synthetic d:Ljava/util/List;

.field public final synthetic e:Z

.field public final synthetic f:Z

.field public final synthetic g:Z


# direct methods
.method public synthetic constructor <init>(Lc/k3;Landroid/widget/LinearLayout;Landroid/widget/GridLayout;Ljava/util/List;ZZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/M2;->a:Lc/k3;

    iput-object p2, p0, Lc/M2;->b:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lc/M2;->c:Landroid/widget/GridLayout;

    iput-object p4, p0, Lc/M2;->d:Ljava/util/List;

    iput-boolean p5, p0, Lc/M2;->e:Z

    iput-boolean p6, p0, Lc/M2;->f:Z

    iput-boolean p7, p0, Lc/M2;->g:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 20

    move-object/from16 v0, p0

    iget-object v7, v0, Lc/M2;->a:Lc/k3;

    const/high16 v1, 0x42d80000    # 108.0f

    invoke-virtual {v7, v1}, Lc/k3;->x(F)I

    move-result v1

    iget-object v2, v0, Lc/M2;->b:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {v2}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {v2}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    sub-int/2addr v3, v2

    if-gtz v3, :cond_0

    goto/16 :goto_6

    :cond_0
    iget-object v8, v0, Lc/M2;->c:Landroid/widget/GridLayout;

    invoke-virtual {v8}, Landroid/view/ViewGroup;->removeAllViews()V

    div-int v1, v3, v1

    const/4 v9, 0x1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/widget/GridLayout;->setColumnCount(I)V

    const/high16 v1, 0x40800000    # 4.0f

    invoke-virtual {v7, v1}, Lc/k3;->x(F)I

    move-result v11

    const/high16 v1, 0x40c00000    # 6.0f

    invoke-virtual {v7, v1}, Lc/k3;->x(F)I

    move-result v12

    mul-int v1, v10, v11

    const/4 v13, 0x2

    mul-int/2addr v1, v13

    sub-int/2addr v3, v1

    div-int/2addr v3, v10

    invoke-static {v9, v3}, Ljava/lang/Math;->max(II)I

    move-result v14

    iget-object v1, v0, Lc/M2;->d:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v15

    const/4 v6, 0x0

    move/from16 v16, v6

    :goto_0
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    check-cast v4, Lc/a;

    iget-boolean v5, v0, Lc/M2;->e:Z

    iget-boolean v3, v0, Lc/M2;->g:Z

    iget-object v1, v7, Lc/k3;->c:Lc/n1;

    if-eqz v5, :cond_2

    invoke-virtual {v1}, Lc/n1;->b0()Ljava/util/HashSet;

    move-result-object v1

    iget-object v2, v4, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    :goto_1
    move v1, v9

    goto :goto_3

    :cond_1
    move v1, v6

    goto :goto_3

    :cond_2
    iget-boolean v2, v0, Lc/M2;->f:Z

    if-eqz v2, :cond_3

    invoke-virtual {v1}, Lc/n1;->e0()Z

    move-result v2

    if-nez v2, :cond_1

    :cond_3
    iget-object v2, v4, Lc/a;->a:Ljava/lang/String;

    if-eqz v3, :cond_4

    invoke-virtual {v1}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :cond_4
    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    :goto_2
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :goto_3
    new-instance v2, Lc/u;

    iget-object v9, v7, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const/16 v13, 0x32

    invoke-direct {v2, v9, v6, v13, v5}, Lc/u;-><init>(Landroid/content/Context;ZIZ)V

    if-eqz v5, :cond_7

    if-eqz v1, :cond_6

    :cond_5
    const/4 v1, 0x1

    goto :goto_4

    :cond_6
    const/4 v1, 0x3

    goto :goto_4

    :cond_7
    if-eqz v1, :cond_5

    const/4 v1, 0x2

    :goto_4
    invoke-virtual {v2, v4, v1}, Lc/u;->a(Lc/a;I)V

    if-eqz v5, :cond_8

    new-instance v1, Lc/w0;

    const/4 v9, 0x2

    invoke-direct {v1, v7, v4, v2, v9}, Lc/w0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object v9, v2, Lc/u;->e:Landroid/widget/Switch;

    if-eqz v9, :cond_8

    invoke-virtual {v9, v1}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    :cond_8
    new-instance v9, Lc/T2;

    move-object v1, v9

    move-object v13, v2

    move-object v2, v7

    move/from16 v17, v3

    move v3, v5

    move/from16 v18, v5

    move-object v5, v13

    move/from16 v19, v6

    move/from16 v6, v17

    invoke-direct/range {v1 .. v6}, Lc/T2;-><init>(Lc/k3;ZLc/a;Lc/u;Z)V

    invoke-virtual {v13, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v1, Landroid/widget/GridLayout$LayoutParams;

    div-int v2, v16, v10

    invoke-static {v2}, Landroid/widget/GridLayout;->spec(I)Landroid/widget/GridLayout$Spec;

    move-result-object v2

    rem-int v3, v16, v10

    invoke-static {v3}, Landroid/widget/GridLayout;->spec(I)Landroid/widget/GridLayout$Spec;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    iput v14, v1, Landroid/widget/GridLayout$LayoutParams;->width:I

    if-eqz v18, :cond_9

    const/high16 v2, 0x43140000    # 148.0f

    goto :goto_5

    :cond_9
    const/high16 v2, 0x42e00000    # 112.0f

    :goto_5
    invoke-virtual {v7, v2}, Lc/k3;->x(F)I

    move-result v2

    iput v2, v1, Landroid/widget/GridLayout$LayoutParams;->height:I

    invoke-virtual {v1, v11, v12, v11, v12}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v8, v13, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v16, v16, 0x1

    move/from16 v6, v19

    const/4 v9, 0x1

    const/4 v13, 0x2

    goto/16 :goto_0

    :cond_a
    if-nez v16, :cond_b

    const-string v1, "\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e"

    invoke-virtual {v7, v1}, Lc/k3;->A(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v8, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_b
    :goto_6
    return-void
.end method
