.class public final synthetic Lc/q2;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/t2;

.field public final synthetic b:J

.field public final synthetic c:Lc/H;

.field public final synthetic d:Lc/v7;

.field public final synthetic e:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/t2;JLc/H;ZLc/v7;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/q2;->a:Lc/t2;

    iput-wide p2, p0, Lc/q2;->b:J

    iput-object p4, p0, Lc/q2;->c:Lc/H;

    iput-object p6, p0, Lc/q2;->d:Lc/v7;

    iput-object p7, p0, Lc/q2;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 6

    iget-object v0, p0, Lc/q2;->a:Lc/t2;

    iget-wide v1, v0, Lc/t2;->H:J

    iget-wide v3, p0, Lc/q2;->b:J

    cmp-long v1, v3, v1

    iget-object v2, p0, Lc/q2;->c:Lc/H;

    if-eqz v1, :cond_0

    invoke-virtual {v2}, Lc/H;->run()V

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    if-eq p1, v1, :cond_1

    const/4 v1, 0x3

    if-ne p1, v1, :cond_2

    :cond_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v5, p0, Lc/q2;->e:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ":"

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lc/t;->f(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object v1, p0, Lc/q2;->d:Lc/v7;

    invoke-virtual {v0, v1, v3, v4, p1}, Lc/t2;->M(Lc/v7;JLjava/lang/String;)V

    :cond_2
    invoke-virtual {v2}, Lc/H;->run()V

    :goto_0
    return-void
.end method
