.class public final Lc/e6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Z

.field public final d:Ljava/util/List;

.field public final e:Ljava/util/List;

.field public final f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:Z

.field public l:J

.field public m:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/util/List;ZZZZLjava/util/List;)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc/e6;->l:J

    const-string v0, ""

    iput-object v0, p0, Lc/e6;->m:Ljava/lang/String;

    const/4 v0, 0x6

    if-eq p2, v0, :cond_1

    const/4 v0, 0x7

    if-eq p2, v0, :cond_1

    const/16 v0, 0x8

    if-eq p2, v0, :cond_1

    const/16 v0, 0x9

    if-ne p2, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "CAN required"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    const-string v0, "(?:[0-9A-F]{2}){1,4095}"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    iput-object p1, p0, Lc/e6;->a:Ljava/lang/String;

    iput p2, p0, Lc/e6;->b:I

    iput-boolean p4, p0, Lc/e6;->c:Z

    const/4 p2, 0x1

    const/4 p4, 0x0

    if-eqz p3, :cond_3

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    move v0, p4

    :cond_2
    :goto_1
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "ATCEA"

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    move v0, p2

    goto :goto_1

    :cond_3
    move v0, p4

    :cond_4
    const/16 p3, 0xe

    const/16 v1, 0xc

    if-eqz v0, :cond_5

    move v2, v1

    goto :goto_2

    :cond_5
    move v2, p3

    :goto_2
    if-eqz v0, :cond_6

    const/16 v3, 0xa

    goto :goto_3

    :cond_6
    move v3, v1

    :goto_3
    if-eqz v0, :cond_7

    move p3, v1

    :cond_7
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-gt v0, v2, :cond_8

    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    goto :goto_5

    :cond_8
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v5, "1%03X"

    invoke-static {v2, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v1, p2

    :goto_4
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v3, v2, :cond_9

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "2"

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v4, v5}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    add-int v5, v3, p3

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-virtual {p1, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/2addr v1, p2

    and-int/lit8 v1, v1, 0xf

    move v3, v5

    goto :goto_4

    :cond_9
    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p2

    :goto_5
    iput-object p2, p0, Lc/e6;->d:Ljava/util/List;

    if-nez p8, :cond_a

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p2

    goto :goto_6

    :cond_a
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2, p8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    :goto_6
    iput-object p2, p0, Lc/e6;->e:Ljava/util/List;

    const/16 p2, 0x2ee

    iput p2, p0, Lc/e6;->f:I

    if-eqz p5, :cond_c

    if-eqz p6, :cond_c

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    const/16 p2, 0x3e8

    if-ge p1, p2, :cond_c

    if-eqz p7, :cond_b

    const/16 p4, 0x15

    goto :goto_7

    :cond_b
    const/16 p4, 0x14

    :cond_c
    :goto_7
    iput p4, p0, Lc/e6;->g:I

    return-void

    :cond_d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Invalid query"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method


# virtual methods
.method public final a(JLjava/lang/String;)V
    .locals 10

    iget v0, p0, Lc/e6;->g:I

    const/16 v1, 0x14

    const/16 v2, 0x15

    if-ne v0, v1, :cond_0

    iput v2, p0, Lc/e6;->g:I

    return-void

    :cond_0
    const/16 v1, 0xb

    const-string v3, ""

    if-ne v0, v2, :cond_2

    if-nez p3, :cond_1

    move-object p3, v3

    :cond_1
    iput-object p3, p0, Lc/e6;->m:Ljava/lang/String;

    iput v1, p0, Lc/e6;->g:I

    return-void

    :cond_2
    const/4 v2, 0x1

    const/4 v4, 0x3

    if-gt v0, v4, :cond_3

    add-int/2addr v0, v2

    iput v0, p0, Lc/e6;->g:I

    return-void

    :cond_3
    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v0, v5, :cond_4

    iput-boolean v2, p0, Lc/e6;->k:Z

    iput v6, p0, Lc/e6;->g:I

    return-void

    :cond_4
    const/4 v5, 0x7

    if-ne v0, v6, :cond_5

    iput v5, p0, Lc/e6;->g:I

    return-void

    :cond_5
    iget-object v6, p0, Lc/e6;->d:Ljava/util/List;

    const/16 v7, 0x9

    const/4 v8, 0x0

    const/16 v9, 0x8

    if-ne v0, v5, :cond_11

    if-nez p3, :cond_6

    move-object p3, v3

    :cond_6
    iput-object p3, p0, Lc/e6;->m:Ljava/lang/String;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p2

    if-ge v8, p2, :cond_a

    invoke-virtual {p3, v8}, Ljava/lang/String;->charAt(I)C

    move-result p2

    invoke-static {p2}, Ljava/lang/Character;->toUpperCase(C)C

    move-result p2

    const/16 v0, 0x30

    if-lt p2, v0, :cond_7

    const/16 v0, 0x39

    if-le p2, v0, :cond_8

    :cond_7
    const/16 v0, 0x41

    if-lt p2, v0, :cond_9

    const/16 v0, 0x46

    if-gt p2, v0, :cond_9

    :cond_8
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_9
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_a
    iget p2, p0, Lc/e6;->b:I

    if-eq p2, v5, :cond_c

    if-ne p2, v7, :cond_b

    goto :goto_1

    :cond_b
    move p2, v4

    goto :goto_2

    :cond_c
    :goto_1
    move p2, v9

    :goto_2
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->length()I

    move-result p3

    add-int/lit8 v0, p2, 0x6

    const/4 v1, 0x0

    if-ge p3, v0, :cond_d

    goto :goto_3

    :cond_d
    add-int/lit8 p3, p2, 0x2

    invoke-virtual {p1, p2, p3}, Ljava/lang/StringBuilder;->substring(II)Ljava/lang/String;

    move-result-object p3

    const-string v3, "30"

    invoke-virtual {p3, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_e

    goto :goto_3

    :cond_e
    add-int/lit8 p3, p2, 0x4

    invoke-virtual {p1, p3, v0}, Ljava/lang/StringBuilder;->substring(II)Ljava/lang/String;

    move-result-object p1

    const/16 p3, 0x10

    invoke-static {p1, p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result p1

    if-ne p2, v4, :cond_f

    const/16 p2, 0xf1

    if-lt p1, p2, :cond_f

    mul-int/lit8 p1, p1, 0x64

    :cond_f
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    :goto_3
    iget p1, p0, Lc/e6;->h:I

    add-int/2addr p1, v2

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result p2

    if-ge p1, p2, :cond_10

    if-eqz v1, :cond_10

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    iput p1, p0, Lc/e6;->i:I

    :cond_10
    iput v9, p0, Lc/e6;->g:I

    return-void

    :cond_11
    if-ne v0, v9, :cond_14

    iget p3, p0, Lc/e6;->j:I

    add-int/2addr p3, v2

    iput p3, p0, Lc/e6;->j:I

    iget-object v0, p0, Lc/e6;->e:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-ne p3, v0, :cond_13

    iput v8, p0, Lc/e6;->j:I

    iput-wide p1, p0, Lc/e6;->l:J

    iget p1, p0, Lc/e6;->h:I

    add-int/2addr p1, v2

    iput p1, p0, Lc/e6;->h:I

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result p2

    if-ne p1, p2, :cond_12

    goto :goto_4

    :cond_12
    const/4 v7, 0x4

    :goto_4
    iput v7, p0, Lc/e6;->g:I

    :cond_13
    return-void

    :cond_14
    const/16 p1, 0xa

    if-ne v0, v7, :cond_15

    iput p1, p0, Lc/e6;->g:I

    return-void

    :cond_15
    if-ne v0, p1, :cond_16

    iput v1, p0, Lc/e6;->g:I

    return-void

    :cond_16
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "No pending step"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b(J)Lc/d6;
    .locals 15

    move-object v0, p0

    move-wide/from16 v1, p1

    iget-wide v3, v0, Lc/e6;->l:J

    const-wide/16 v5, 0x0

    cmp-long v3, v3, v5

    if-gez v3, :cond_0

    iput-wide v1, v0, Lc/e6;->l:J

    :cond_0
    iget v3, v0, Lc/e6;->g:I

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-boolean v6, v0, Lc/e6;->c:Z

    if-ne v3, v5, :cond_1

    if-nez v6, :cond_1

    iput v4, v0, Lc/e6;->g:I

    :cond_1
    iget v3, v0, Lc/e6;->g:I

    iget-object v7, v0, Lc/e6;->d:Ljava/util/List;

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-ne v3, v4, :cond_3

    iget v3, v0, Lc/e6;->h:I

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v11

    sub-int/2addr v11, v8

    if-ne v3, v11, :cond_2

    iget-boolean v3, v0, Lc/e6;->k:Z

    if-nez v3, :cond_2

    iput v9, v0, Lc/e6;->g:I

    goto :goto_0

    :cond_2
    iput v10, v0, Lc/e6;->g:I

    :cond_3
    :goto_0
    iget v3, v0, Lc/e6;->g:I

    const/4 v11, 0x6

    if-ne v3, v11, :cond_4

    if-nez v6, :cond_4

    iput v10, v0, Lc/e6;->g:I

    :cond_4
    iget v3, v0, Lc/e6;->g:I

    const/16 v13, 0x8

    const/4 v14, 0x0

    if-ne v3, v13, :cond_7

    iget v3, v0, Lc/e6;->f:I

    if-lez v3, :cond_5

    iget-object v5, v0, Lc/e6;->e:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_5

    iget-wide v9, v0, Lc/e6;->l:J

    sub-long v9, v1, v9

    int-to-long v12, v3

    cmp-long v3, v9, v12

    if-lez v3, :cond_5

    new-instance v1, Lc/d6;

    iget v2, v0, Lc/e6;->j:I

    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_5
    iget v3, v0, Lc/e6;->h:I

    add-int/2addr v3, v8

    iput v3, v0, Lc/e6;->h:I

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v5

    if-ne v3, v5, :cond_6

    const/16 v4, 0x9

    :cond_6
    iput v4, v0, Lc/e6;->g:I

    invoke-virtual/range {p0 .. p2}, Lc/e6;->b(J)Lc/d6;

    move-result-object v1

    return-object v1

    :cond_7
    const/16 v1, 0xa

    if-ne v3, v1, :cond_8

    iget-boolean v2, v0, Lc/e6;->k:Z

    if-eqz v2, :cond_8

    const/16 v2, 0xb

    iput v2, v0, Lc/e6;->g:I

    :cond_8
    iget v2, v0, Lc/e6;->g:I

    if-eqz v2, :cond_14

    if-eq v2, v8, :cond_13

    const/4 v3, 0x2

    if-eq v2, v3, :cond_12

    if-eq v2, v5, :cond_11

    const-string v3, "ATCFC1"

    if-eq v2, v9, :cond_10

    if-eq v2, v11, :cond_f

    if-eq v2, v10, :cond_d

    const/16 v4, 0x9

    if-eq v2, v4, :cond_c

    if-eq v2, v1, :cond_b

    const/16 v1, 0x14

    if-eq v2, v1, :cond_a

    const/16 v1, 0x15

    if-eq v2, v1, :cond_9

    const/4 v1, 0x0

    return-object v1

    :cond_9
    new-instance v1, Lc/d6;

    iget-object v2, v0, Lc/e6;->a:Ljava/lang/String;

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_a
    new-instance v1, Lc/d6;

    const-string v2, "STCSEGT1"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_b
    new-instance v1, Lc/d6;

    invoke-direct {v1, v3, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_c
    new-instance v1, Lc/d6;

    const-string v2, "ATCAF1"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_d
    new-instance v1, Lc/d6;

    iget v2, v0, Lc/e6;->h:I

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    if-eqz v6, :cond_e

    iget v14, v0, Lc/e6;->i:I

    :cond_e
    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_f
    new-instance v1, Lc/d6;

    const-string v2, "ATR1"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_10
    new-instance v1, Lc/d6;

    invoke-direct {v1, v3, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_11
    new-instance v1, Lc/d6;

    const-string v2, "ATR0"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_12
    new-instance v1, Lc/d6;

    const-string v2, "ATAL"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_13
    new-instance v1, Lc/d6;

    const-string v2, "ATCFC0"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1

    :cond_14
    new-instance v1, Lc/d6;

    const-string v2, "ATCAF0"

    invoke-direct {v1, v2, v14}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    return-object v1
.end method

.method public final c()Ljava/lang/String;
    .locals 2

    iget v0, p0, Lc/e6;->g:I

    const/16 v1, 0xb

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Lc/e6;->m:Ljava/lang/String;

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Upload pending"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
