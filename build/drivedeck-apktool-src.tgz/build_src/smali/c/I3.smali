.class public final synthetic Lc/I3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/View;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/Button;Landroid/widget/LinearLayout;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/n1;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    iput v0, p0, Lc/I3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/I3;->b:Landroid/view/View;

    iput-object p2, p0, Lc/I3;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/I3;->f:Ljava/lang/Object;

    iput-object p4, p0, Lc/I3;->d:Lru/drivedeck/launcher/MainActivity;

    iput-object p5, p0, Lc/I3;->e:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/P3;[ILru/drivedeck/launcher/MainActivity;Ljava/lang/Object;Landroid/app/Dialog;I)V
    .locals 0

    .line 2
    iput p6, p0, Lc/I3;->a:I

    iput-object p1, p0, Lc/I3;->b:Landroid/view/View;

    iput-object p2, p0, Lc/I3;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/I3;->d:Lru/drivedeck/launcher/MainActivity;

    iput-object p4, p0, Lc/I3;->f:Ljava/lang/Object;

    iput-object p5, p0, Lc/I3;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 17

    move-object/from16 v0, p0

    const/16 v1, 0x30

    const/16 v2, 0x60

    const/4 v3, 0x1

    iget-object v4, v0, Lc/I3;->e:Ljava/lang/Object;

    iget-object v5, v0, Lc/I3;->f:Ljava/lang/Object;

    iget-object v6, v0, Lc/I3;->d:Lru/drivedeck/launcher/MainActivity;

    iget-object v7, v0, Lc/I3;->c:Ljava/lang/Object;

    const/4 v8, 0x0

    iget-object v9, v0, Lc/I3;->b:Landroid/view/View;

    iget v10, v0, Lc/I3;->a:I

    packed-switch v10, :pswitch_data_0

    check-cast v9, Landroid/widget/Button;

    invoke-virtual {v9, v8}, Landroid/view/View;->setEnabled(Z)V

    check-cast v7, Landroid/widget/LinearLayout;

    invoke-virtual {v7}, Landroid/view/ViewGroup;->removeAllViews()V

    const-string v1, "\u041f\u0440\u043e\u0432\u0435\u0440\u044f\u0435\u043c \u0432\u0435\u0440\u0441\u0438\u0438\u2026"

    invoke-static {v6, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    check-cast v5, Landroid/widget/TextView;

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v1, Lc/P8;

    invoke-direct {v1, v9, v5, v6, v7}, Lc/P8;-><init>(Landroid/widget/Button;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;)V

    sget-object v2, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-virtual {v6}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v8

    new-instance v9, Lc/Z6;

    invoke-direct {v9, v5, v1}, Lc/Z6;-><init>(Landroid/view/View;Ljava/lang/Object;)V

    move-object v12, v4

    check-cast v12, Lc/n1;

    invoke-virtual {v12}, Lc/n1;->Q()J

    move-result-wide v10

    new-instance v1, Lc/m1;

    const/4 v13, 0x1

    move-object v7, v1

    invoke-direct/range {v7 .. v13}, Lc/m1;-><init>(Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;I)V

    sget-object v2, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_0
    check-cast v9, Lc/P3;

    iget-object v9, v9, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v9}, Lc/n1;->i()Lc/u0;

    move-result-object v10

    check-cast v7, [I

    aget v11, v7, v8

    invoke-virtual {v9, v10, v8, v11}, Lc/n1;->c(Lc/u0;ZI)Lc/u0;

    move-result-object v10

    invoke-virtual {v9, v3}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v11

    aget v12, v7, v8

    invoke-virtual {v9, v11, v3, v12}, Lc/n1;->c(Lc/u0;ZI)Lc/u0;

    move-result-object v11

    if-eqz v10, :cond_1

    if-nez v11, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v9, v10, v8, v8}, Lc/n1;->B0(Lc/u0;ZZ)Z

    invoke-virtual {v9, v11, v3, v8}, Lc/n1;->B0(Lc/u0;ZZ)Z

    aget v7, v7, v8

    iget-object v9, v9, Lc/n1;->b:Ljava/lang/Object;

    check-cast v9, Landroid/content/SharedPreferences;

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string v10, "widget_apps_icon_size"

    invoke-static {v2, v7, v1, v9, v10}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    check-cast v5, [Z

    aput-boolean v3, v5, v8

    invoke-virtual {v6}, Lru/drivedeck/launcher/MainActivity;->U()V

    check-cast v4, Landroid/app/Dialog;

    invoke-virtual {v4}, Landroid/app/Dialog;->dismiss()V

    goto :goto_1

    :cond_1
    :goto_0
    const-string v1, "\u041e\u0441\u0432\u043e\u0431\u043e\u0434\u0438\u0442\u0435 \u043c\u0435\u0441\u0442\u043e \u0434\u043b\u044f \u0438\u043a\u043e\u043d\u043e\u043a"

    invoke-static {v6, v1, v6, v8}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :goto_1
    return-void

    :pswitch_1
    check-cast v9, Lc/P3;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, [I

    aget v10, v7, v8

    and-int/lit8 v10, v10, 0x3f

    if-nez v10, :cond_2

    const-string v1, "\u041e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u0445\u043e\u0442\u044f \u0431\u044b \u043e\u0434\u043d\u0443 \u043a\u043d\u043e\u043f\u043a\u0443"

    invoke-static {v6, v1, v6, v8}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_3

    :cond_2
    iget-object v15, v9, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v15}, Lc/n1;->i()Lc/u0;

    move-result-object v10

    aget v13, v7, v8

    check-cast v5, [I

    aget v14, v5, v8

    const/4 v12, 0x1

    const/4 v11, 0x0

    move-object v9, v15

    invoke-virtual/range {v9 .. v14}, Lc/n1;->d(Lc/u0;ZZII)Lc/u0;

    move-result-object v14

    invoke-virtual {v15, v3}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v10

    aget v13, v7, v8

    aget v16, v5, v8

    const/4 v12, 0x1

    const/4 v11, 0x1

    move-object v9, v15

    move-object v1, v14

    move/from16 v14, v16

    invoke-virtual/range {v9 .. v14}, Lc/n1;->d(Lc/u0;ZZII)Lc/u0;

    move-result-object v9

    invoke-virtual {v15, v1, v8, v8}, Lc/n1;->B0(Lc/u0;ZZ)Z

    invoke-virtual {v15, v9, v3, v8}, Lc/n1;->B0(Lc/u0;ZZ)Z

    aget v1, v7, v8

    iget-object v7, v15, Lc/n1;->b:Ljava/lang/Object;

    check-cast v7, Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    and-int/lit8 v10, v1, 0x5f

    const-string v11, "quick_settings_mask"

    invoke-interface {v9, v11, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    and-int/lit8 v1, v1, 0x20

    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    move v3, v8

    :goto_2
    const-string v1, "quick_settings_mute"

    invoke-interface {v9, v1, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    aget v1, v5, v8

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v5, "quick_settings_icon_size"

    const/16 v7, 0x30

    invoke-static {v2, v1, v7, v3, v5}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    invoke-virtual {v6}, Lru/drivedeck/launcher/MainActivity;->U()V

    check-cast v4, Landroid/app/Dialog;

    invoke-virtual {v4}, Landroid/app/Dialog;->dismiss()V

    :goto_3
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
