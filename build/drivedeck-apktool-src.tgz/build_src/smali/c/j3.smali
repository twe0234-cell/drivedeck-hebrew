.class public final Lc/j3;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Z

.field public final b:F

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I

.field public final g:I

.field public final h:I


# direct methods
.method public constructor <init>(F)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/high16 v0, 0x43c80000    # 400.0f

    cmpg-float v1, p1, v0

    if-gez v1, :cond_0

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    iput-boolean v1, p0, Lc/j3;->a:Z

    sub-float v0, p1, v0

    const/high16 v1, 0x43f00000    # 480.0f

    div-float/2addr v0, v1

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iput v0, p0, Lc/j3;->b:F

    const/16 v2, 0x38

    const/16 v3, 0x4c

    invoke-virtual {p0, v2, v3}, Lc/j3;->a(II)I

    move-result v2

    iput v2, p0, Lc/j3;->c:I

    const/16 v3, 0x14

    const/16 v4, 0x8

    invoke-virtual {p0, v4, v3}, Lc/j3;->a(II)I

    move-result v3

    iput v3, p0, Lc/j3;->d:I

    const/16 v5, 0x10

    invoke-virtual {p0, v4, v5}, Lc/j3;->a(II)I

    move-result v4

    iput v4, p0, Lc/j3;->e:I

    iput v5, p0, Lc/j3;->f:I

    const/16 v4, 0x30

    iput v4, p0, Lc/j3;->g:I

    const v5, 0x3d23d70a    # 0.04f

    mul-float/2addr v0, v5

    const v5, 0x3eb851ec    # 0.36f

    add-float/2addr v0, v5

    mul-float/2addr v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/16 v5, 0xb0

    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    const/16 v0, 0x60

    const/16 v5, 0x84

    invoke-virtual {p0, v0, v5}, Lc/j3;->a(II)I

    const/16 v0, 0x78

    const/16 v5, 0x9c

    invoke-virtual {p0, v0, v5}, Lc/j3;->a(II)I

    int-to-float v0, v2

    sub-float/2addr p1, v0

    int-to-float v0, v3

    sub-float/2addr p1, v0

    invoke-static {v1, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    const/high16 v0, 0x43300000    # 176.0f

    sub-float/2addr p1, v0

    const/high16 v0, 0x40400000    # 3.0f

    div-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/16 v0, 0x5c

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {v4, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    iput p1, p0, Lc/j3;->h:I

    return-void
.end method


# virtual methods
.method public final a(II)I
    .locals 1

    int-to-float v0, p1

    sub-int/2addr p2, p1

    int-to-float p1, p2

    iget p2, p0, Lc/j3;->b:F

    mul-float/2addr p1, p2

    add-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method
