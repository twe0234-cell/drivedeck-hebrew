.class public final Lc/P;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# static fields
.field public static final q:[I


# instance fields
.field public final a:Lc/K;

.field public final b:Landroid/content/Context;

.field public final c:Landroid/os/Handler;

.field public final d:Ljava/lang/Runnable;

.field public e:Landroid/os/IBinder;

.field public f:Z

.field public g:Landroid/media/session/MediaSessionManager;

.field public h:Landroid/media/session/MediaController;

.field public i:Z

.field public final j:Lc/L;

.field public final k:Lc/M;

.field public volatile l:Ljava/lang/String;

.field public volatile m:Ljava/lang/String;

.field public volatile n:Z

.field public volatile o:Z

.field public final p:Lc/O;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lc/P;->q:[I

    return-void

    :array_0
    .array-data 4
        0x9
        0x0
        0x1
        0x2
        0xd
        0x1c
        0x2c
        0x2d
    .end array-data
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/Runnable;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lc/K;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v1, -0x1

    iput-wide v1, v0, Lc/K;->a:J

    iput-wide v1, v0, Lc/K;->b:J

    const/4 v1, -0x1

    iput v1, v0, Lc/K;->d:I

    iput v1, v0, Lc/K;->e:I

    iput-object v0, p0, Lc/P;->a:Lc/K;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/P;->c:Landroid/os/Handler;

    new-instance v0, Lc/L;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/L;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/P;->j:Lc/L;

    new-instance v0, Lc/M;

    invoke-direct {v0, p0, v1}, Lc/M;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/P;->k:Lc/M;

    const-string v0, ""

    iput-object v0, p0, Lc/P;->l:Ljava/lang/String;

    iput-object v0, p0, Lc/P;->m:Ljava/lang/String;

    new-instance v0, Lc/O;

    invoke-direct {v0, p0, v1}, Lc/O;-><init>(Landroid/content/ServiceConnection;I)V

    iput-object v0, p0, Lc/P;->p:Lc/O;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/P;->b:Landroid/content/Context;

    iput-object p2, p0, Lc/P;->d:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 3

    iget-object v0, p0, Lc/P;->e:Landroid/os/IBinder;

    const/4 v1, 0x1

    if-nez v0, :cond_4

    iget-object v0, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-nez v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    if-nez p1, :cond_1

    invoke-virtual {v0}, Landroid/media/session/MediaController$TransportControls;->skipToPrevious()V

    goto :goto_0

    :cond_1
    if-ne p1, v1, :cond_2

    invoke-virtual {v0}, Landroid/media/session/MediaController$TransportControls;->skipToNext()V

    goto :goto_0

    :cond_2
    iget-boolean p1, p0, Lc/P;->n:Z

    if-eqz p1, :cond_3

    invoke-virtual {v0}, Landroid/media/session/MediaController$TransportControls;->pause()V

    goto :goto_0

    :cond_3
    invoke-virtual {v0}, Landroid/media/session/MediaController$TransportControls;->play()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    return-void

    :cond_4
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_1
    const-string v2, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 p1, 0x0

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeIntArray([I)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeFloatArray([F)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    iget-object v2, p0, Lc/P;->e:Landroid/os/IBinder;

    invoke-interface {v2, v1, v0, p1, v1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_3

    :catchall_0
    move-exception p1

    goto :goto_4

    :catch_1
    move-exception p1

    goto :goto_2

    :catch_2
    move-exception p1

    :goto_2
    :try_start_2
    const-string v1, "DriveDeckBT"

    const-string v2, "Transport failed"

    invoke-static {v1, v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    goto :goto_1

    :goto_3
    return-void

    :goto_4
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1
.end method

.method public final b()V
    .locals 3

    iget-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/P;->b:Landroid/content/Context;

    invoke-static {v0}, Lc/J;->e(Landroid/content/Context;)Landroid/media/session/MediaController;

    move-result-object v0

    :goto_0
    iget-object v1, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-eq v1, v0, :cond_4

    if-eqz v1, :cond_1

    if-eqz v0, :cond_1

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v1

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/media/session/MediaSession$Token;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    iget-object v1, p0, Lc/P;->h:Landroid/media/session/MediaController;

    iget-object v2, p0, Lc/P;->k:Lc/M;

    if-eqz v1, :cond_2

    invoke-virtual {v1, v2}, Landroid/media/session/MediaController;->unregisterCallback(Landroid/media/session/MediaController$Callback;)V

    :cond_2
    iput-object v0, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-eqz v0, :cond_3

    iget-object v1, p0, Lc/P;->c:Landroid/os/Handler;

    invoke-virtual {v0, v2, v1}, Landroid/media/session/MediaController;->registerCallback(Landroid/media/session/MediaController$Callback;Landroid/os/Handler;)V

    :cond_3
    invoke-virtual {p0}, Lc/P;->f()V

    :cond_4
    :goto_1
    return-void
.end method

.method public final c()V
    .locals 6

    iget-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    iget-object v1, p0, Lc/P;->b:Landroid/content/Context;

    if-nez v0, :cond_0

    const-string v0, "media_session"

    invoke-virtual {v1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/session/MediaSessionManager;

    iput-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    :cond_0
    iget-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    iget-boolean v3, p0, Lc/P;->i:Z

    if-nez v3, :cond_1

    :try_start_0
    iget-object v3, p0, Lc/P;->j:Lc/L;

    iget-object v4, p0, Lc/P;->c:Landroid/os/Handler;

    invoke-static {v1, v0, v3, v4}, Lc/G8;->W(Landroid/content/Context;Landroid/media/session/MediaSessionManager;Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/os/Handler;)V

    iput-boolean v2, p0, Lc/P;->i:Z
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    invoke-virtual {p0}, Lc/P;->b()V

    iget-boolean v0, p0, Lc/P;->f:Z

    if-eqz v0, :cond_2

    return-void

    :cond_2
    :try_start_1
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.syu.ms.bt"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance v3, Landroid/content/ComponentName;

    const-string v4, "com.syu.ms"

    const-string v5, "app.ModuleService"

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v1, v0, p0, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, p0, Lc/P;->f:Z
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    move-exception v0

    const-string v1, "DriveDeckBT"

    const-string v2, "Cannot bind Bluetooth module"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    return-void
.end method

.method public final d()V
    .locals 4

    iget-boolean v0, p0, Lc/P;->f:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    sget-object v0, Lc/P;->q:[I

    move v2, v1

    :goto_0
    const/16 v3, 0x8

    if-ge v2, v3, :cond_0

    aget v3, v0, v2

    invoke-virtual {p0, v3, v1}, Lc/P;->e(IZ)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    iput-boolean v1, p0, Lc/P;->f:Z

    :try_start_0
    iget-object v0, p0, Lc/P;->b:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    iget-boolean v0, p0, Lc/P;->i:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    iget-object v2, p0, Lc/P;->j:Lc/L;

    invoke-virtual {v0, v2}, Landroid/media/session/MediaSessionManager;->removeOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;)V

    :cond_2
    iput-boolean v1, p0, Lc/P;->i:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/P;->g:Landroid/media/session/MediaSessionManager;

    iget-object v2, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-eqz v2, :cond_3

    iget-object v3, p0, Lc/P;->k:Lc/M;

    invoke-virtual {v2, v3}, Landroid/media/session/MediaController;->unregisterCallback(Landroid/media/session/MediaController$Callback;)V

    :cond_3
    iput-object v0, p0, Lc/P;->h:Landroid/media/session/MediaController;

    iput-object v0, p0, Lc/P;->e:Landroid/os/IBinder;

    iget-object v2, p0, Lc/P;->c:Landroid/os/Handler;

    invoke-virtual {v2, v0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v0, p0, Lc/P;->a:Lc/K;

    invoke-virtual {v0}, Lc/K;->b()V

    const-string v0, ""

    iput-object v0, p0, Lc/P;->m:Ljava/lang/String;

    iput-object v0, p0, Lc/P;->l:Ljava/lang/String;

    iput-boolean v1, p0, Lc/P;->o:Z

    iput-boolean v1, p0, Lc/P;->n:Z

    return-void
.end method

.method public final e(IZ)V
    .locals 3

    iget-object v0, p0, Lc/P;->e:Landroid/os/IBinder;

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const-string v1, "com.syu.ipc.IRemoteModule"

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    iget-object v1, p0, Lc/P;->p:Lc/O;

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 p1, 0x1

    if-eqz p2, :cond_1

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_5

    :catch_0
    move-exception p1

    goto :goto_3

    :catch_1
    move-exception p1

    goto :goto_3

    :cond_1
    :goto_0
    iget-object v1, p0, Lc/P;->e:Landroid/os/IBinder;

    if-eqz p2, :cond_2

    const/4 p2, 0x3

    goto :goto_1

    :cond_2
    const/4 p2, 0x4

    :goto_1
    const/4 v2, 0x0

    invoke-interface {v1, p2, v0, v2, p1}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_2
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    goto :goto_4

    :goto_3
    :try_start_1
    const-string p2, "DriveDeckBT"

    const-string v1, "Subscription failed"

    invoke-static {p2, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_2

    :goto_4
    return-void

    :goto_5
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    throw p1
.end method

.method public final f()V
    .locals 4

    iget-object v0, p0, Lc/P;->e:Landroid/os/IBinder;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/P;->h:Landroid/media/session/MediaController;

    const/4 v1, 0x0

    if-nez v0, :cond_1

    move-object v0, v1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v0

    :goto_0
    iget-object v2, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-nez v2, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    :goto_1
    const-string v2, ""

    if-nez v0, :cond_3

    :goto_2
    move-object v3, v2

    goto :goto_3

    :cond_3
    const-string v3, "android.media.metadata.TITLE"

    invoke-virtual {v0, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_4

    goto :goto_2

    :cond_4
    :goto_3
    iput-object v3, p0, Lc/P;->l:Ljava/lang/String;

    if-nez v0, :cond_5

    goto :goto_4

    :cond_5
    const-string v3, "android.media.metadata.ARTIST"

    invoke-virtual {v0, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_6

    goto :goto_4

    :cond_6
    move-object v2, v0

    :goto_4
    iput-object v2, p0, Lc/P;->m:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v2, 0x1

    if-eqz v1, :cond_7

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v1

    const/4 v3, 0x3

    if-ne v1, v3, :cond_7

    move v1, v2

    goto :goto_5

    :cond_7
    move v1, v0

    :goto_5
    iput-boolean v1, p0, Lc/P;->n:Z

    iget-object v1, p0, Lc/P;->h:Landroid/media/session/MediaController;

    if-eqz v1, :cond_8

    move v0, v2

    :cond_8
    iput-boolean v0, p0, Lc/P;->o:Z

    iget-object v0, p0, Lc/P;->d:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2

    iget-boolean p1, p0, Lc/P;->f:Z

    if-nez p1, :cond_0

    return-void

    :cond_0
    iput-object p2, p0, Lc/P;->e:Landroid/os/IBinder;

    sget-object p1, Lc/P;->q:[I

    const/4 p2, 0x0

    :goto_0
    const/16 v0, 0x8

    if-ge p2, v0, :cond_1

    aget v0, p1, p2

    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lc/P;->e(IZ)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lc/P;->e:Landroid/os/IBinder;

    iget-object p1, p0, Lc/P;->a:Lc/K;

    invoke-virtual {p1}, Lc/K;->b()V

    invoke-virtual {p0}, Lc/P;->f()V

    return-void
.end method
