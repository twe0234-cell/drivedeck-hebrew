.class public final Lc/O3;
.super Landroid/view/accessibility/AccessibilityNodeProvider;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/RectF;

.field public final synthetic b:Lc/P3;


# direct methods
.method public constructor <init>(Lc/P3;)V
    .locals 0

    iput-object p1, p0, Lc/O3;->b:Lc/P3;

    invoke-direct {p0}, Landroid/view/accessibility/AccessibilityNodeProvider;-><init>()V

    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lc/O3;->a:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public final createAccessibilityNodeInfo(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 27

    move-object/from16 v0, p0

    move/from16 v1, p1

    iget-object v2, v0, Lc/O3;->a:Landroid/graphics/RectF;

    const/16 v3, 0x64

    const/16 v4, 0x7d0

    const/16 v5, 0x1770

    const/16 v6, 0xfa0

    const/16 v7, 0x3e8

    const/16 v8, 0xbb8

    const/4 v9, 0x1

    const/16 v10, 0x1779

    const/16 v11, 0x7d5

    const/4 v12, -0x1

    const/16 v13, 0x1389

    const/16 v14, 0x1388

    iget-object v15, v0, Lc/O3;->b:Lc/P3;

    if-ne v1, v12, :cond_0

    :goto_0
    move v12, v9

    goto/16 :goto_3

    :cond_0
    if-lt v1, v3, :cond_1

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v12

    array-length v12, v12

    add-int/2addr v12, v3

    if-ge v1, v12, :cond_1

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    :goto_1
    xor-int/2addr v12, v9

    goto :goto_3

    :cond_1
    if-lt v1, v7, :cond_2

    iget-object v12, v15, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v12

    add-int/2addr v12, v7

    if-ge v1, v12, :cond_2

    goto :goto_0

    :cond_2
    if-lt v1, v4, :cond_3

    if-ge v1, v11, :cond_3

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    goto :goto_1

    :cond_3
    if-lt v1, v8, :cond_4

    iget-object v12, v15, Lc/P3;->t1:Lc/g0;

    iget-object v12, v12, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    move-result v12

    add-int/2addr v12, v8

    if-ge v1, v12, :cond_4

    goto :goto_0

    :cond_4
    if-eq v1, v14, :cond_8

    if-ne v1, v13, :cond_5

    goto :goto_2

    :cond_5
    if-lt v1, v5, :cond_6

    if-ge v1, v10, :cond_6

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    goto :goto_1

    :cond_6
    if-lt v1, v6, :cond_7

    const/16 v12, 0x1004

    if-ge v1, v12, :cond_7

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    goto :goto_1

    :cond_7
    const/4 v12, 0x0

    goto :goto_3

    :cond_8
    :goto_2
    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v12

    goto :goto_1

    :goto_3
    if-nez v12, :cond_9

    const/4 v1, 0x0

    return-object v1

    :cond_9
    invoke-static {}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v12

    invoke-virtual {v15, v12}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setPackageName(Ljava/lang/CharSequence;)V

    const/4 v8, -0x1

    if-ne v1, v8, :cond_a

    const-class v8, Landroid/view/View;

    :goto_4
    invoke-virtual {v8}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v8

    goto :goto_5

    :cond_a
    const-class v8, Landroid/widget/Button;

    goto :goto_4

    :goto_5
    invoke-virtual {v12, v8}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    invoke-virtual {v12, v15, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setSource(Landroid/view/View;I)V

    iget-object v8, v15, Lc/P3;->t1:Lc/g0;

    const/4 v9, 0x2

    const/4 v6, -0x1

    if-ne v1, v6, :cond_18

    const/4 v6, 0x0

    invoke-virtual {v12, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setFocusable(Z)V

    new-instance v1, Landroid/graphics/Rect;

    invoke-virtual {v15}, Landroid/view/View;->getWidth()I

    move-result v4

    invoke-virtual {v15}, Landroid/view/View;->getHeight()I

    move-result v5

    invoke-direct {v1, v6, v6, v4, v5}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v12, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInParent(Landroid/graphics/Rect;)V

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v1

    array-length v4, v1

    const/4 v5, 0x0

    :goto_6
    if-ge v5, v4, :cond_c

    aget-object v6, v1, v5

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    add-int/2addr v6, v3

    invoke-virtual {v15, v6, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_b

    invoke-virtual {v12, v15, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_b
    add-int/lit8 v5, v5, 0x1

    goto :goto_6

    :cond_c
    const/4 v1, 0x0

    :goto_7
    iget-object v3, v15, Lc/P3;->d0:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_d

    add-int/lit16 v3, v1, 0x3e8

    invoke-virtual {v12, v15, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_d
    iget-object v1, v15, Lc/P3;->I0:Landroid/graphics/RectF;

    invoke-virtual {v1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_f

    const/4 v1, 0x0

    :goto_8
    const/4 v3, 0x5

    if-ge v1, v3, :cond_f

    add-int/lit16 v3, v1, 0x7d0

    invoke-virtual {v15, v3, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_e

    invoke-virtual {v12, v15, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_e
    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_f
    const/4 v1, 0x0

    :goto_9
    iget-object v3, v8, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_10

    add-int/lit16 v3, v1, 0xbb8

    invoke-virtual {v12, v15, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_10
    invoke-virtual {v15, v13, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_11

    invoke-virtual {v12, v15, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_11
    invoke-virtual {v15, v14, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_12

    invoke-virtual {v12, v15, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_12
    const/4 v1, 0x0

    :goto_a
    const/16 v3, 0x9

    if-ge v1, v3, :cond_14

    add-int/lit16 v3, v1, 0x1770

    invoke-virtual {v15, v3, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_13

    invoke-virtual {v12, v15, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_13
    add-int/lit8 v1, v1, 0x1

    goto :goto_a

    :cond_14
    iget-object v1, v15, Lc/P3;->A:Lc/g1;

    iget-boolean v1, v1, Lc/g1;->J:Z

    if-eqz v1, :cond_17

    const/16 v1, 0xffa

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_15

    invoke-virtual {v12, v15, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_15
    const/4 v1, 0x0

    :goto_b
    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v3

    array-length v3, v3

    mul-int/lit8 v3, v3, 0x3

    add-int/2addr v3, v9

    if-ge v1, v3, :cond_17

    add-int/lit16 v3, v1, 0xfa0

    invoke-virtual {v15, v3, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_16

    invoke-virtual {v12, v15, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addChild(Landroid/view/View;I)V

    :cond_16
    add-int/lit8 v1, v1, 0x1

    goto :goto_b

    :cond_17
    return-object v12

    :cond_18
    invoke-virtual {v12, v15}, Landroid/view/accessibility/AccessibilityNodeInfo;->setParent(Landroid/view/View;)V

    invoke-virtual {v15, v1, v2}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    new-instance v6, Landroid/graphics/Rect;

    iget v9, v2, Landroid/graphics/RectF;->left:F

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    iget v3, v2, Landroid/graphics/RectF;->top:F

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    iget v14, v2, Landroid/graphics/RectF;->right:F

    invoke-static {v14}, Ljava/lang/Math;->round(F)I

    move-result v14

    iget v13, v2, Landroid/graphics/RectF;->bottom:F

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-direct {v6, v9, v3, v14, v13}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v12, v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInParent(Landroid/graphics/Rect;)V

    const-string v3, ": "

    iget-object v6, v15, Lc/P3;->n:Lc/G0;

    iget-object v9, v15, Lc/P3;->f0:Ljava/util/ArrayList;

    const-string v13, ""

    if-lt v1, v7, :cond_1a

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v14

    add-int/2addr v14, v7

    if-ge v1, v14, :cond_1a

    add-int/lit16 v5, v1, -0x3e8

    invoke-virtual {v9, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/q5;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v14, v5, Lc/q5;->b:Ljava/lang/String;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v5, Lc/q5;->c:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_19

    move-object v5, v13

    goto :goto_c

    :cond_19
    invoke-virtual {v3, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_c
    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_12

    :cond_1a
    if-lt v1, v4, :cond_1b

    if-ge v1, v11, :cond_1b

    const-string v5, "\u041f\u0430\u0443\u0437\u0430 \u0438\u043b\u0438 \u043f\u0440\u043e\u0434\u043e\u043b\u0436\u0438\u0442\u044c"

    const-string v10, "\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0438\u0439 \u0442\u0440\u0435\u043a"

    const-string v14, "\u041f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0439 \u0442\u0440\u0435\u043a"

    const-string v7, "\u0412 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435"

    const-string v11, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u043c\u0443\u0437\u044b\u043a\u0438"

    filled-new-array {v14, v5, v10, v7, v11}, [Ljava/lang/String;

    move-result-object v5

    add-int/lit16 v7, v1, -0x7d0

    aget-object v5, v5, v7

    goto/16 :goto_12

    :cond_1b
    if-lt v1, v5, :cond_1d

    if-ge v1, v10, :cond_1d

    iget-boolean v5, v15, Lc/P3;->R0:Z

    if-eqz v5, :cond_1c

    const-string v5, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0437\u0432\u0443\u043a"

    :goto_d
    move-object/from16 v25, v5

    goto :goto_e

    :cond_1c
    const-string v5, "\u0412\u044b\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0437\u0432\u0443\u043a"

    goto :goto_d

    :goto_e
    const-string v23, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0437\u0432\u0443\u043a\u0430"

    const-string v24, "\u0423\u0432\u0435\u043b\u0438\u0447\u0438\u0442\u044c \u0433\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c"

    const-string v18, "Wi-Fi"

    const-string v19, "Bluetooth"

    const-string v20, "\u041c\u043e\u0431\u0438\u043b\u044c\u043d\u0430\u044f \u0441\u0435\u0442\u044c"

    const-string v21, "\u0410\u0432\u0438\u0430\u0440\u0435\u0436\u0438\u043c"

    const-string v22, "\u0423\u043c\u0435\u043d\u044c\u0448\u0438\u0442\u044c \u0433\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c"

    const-string v26, "\u0412\u044b\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0434\u0438\u0441\u043f\u043b\u0435\u0439"

    filled-new-array/range {v18 .. v26}, [Ljava/lang/String;

    move-result-object v5

    add-int/lit16 v7, v1, -0x1770

    aget-object v5, v5, v7

    goto/16 :goto_12

    :cond_1d
    const/16 v5, 0x1389

    if-ne v1, v5, :cond_1f

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    iget-object v7, v6, Lc/G0;->c:Lc/T5;

    iget-object v7, v7, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v10, "enabled"

    const/4 v11, 0x0

    invoke-interface {v7, v10, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    if-eqz v7, :cond_1e

    const-string v7, "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c OBD"

    goto :goto_f

    :cond_1e
    const-string v7, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c OBD"

    :goto_f
    iget-object v10, v6, Lc/G0;->a:Landroid/app/Activity;

    invoke-static {v10, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_12

    :cond_1f
    const/16 v5, 0x1388

    if-ne v1, v5, :cond_20

    const-string v5, "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c \u043f\u043e\u0433\u043e\u0434\u0443"

    goto/16 :goto_12

    :cond_20
    const/16 v5, 0xfa0

    if-lt v1, v5, :cond_26

    add-int/lit16 v5, v1, -0xfa0

    const/16 v7, 0x5a

    if-ne v5, v7, :cond_21

    const-string v5, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c Android-\u0432\u0438\u0434\u0436\u0435\u0442"

    goto/16 :goto_12

    :cond_21
    if-nez v5, :cond_22

    const-string v5, "\u0413\u043e\u0442\u043e\u0432\u043e"

    goto/16 :goto_12

    :cond_22
    const/4 v7, 0x1

    if-ne v5, v7, :cond_23

    const-string v5, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u0438\u0434\u0436\u0435\u0442"

    goto/16 :goto_12

    :cond_23
    add-int/lit16 v5, v1, -0xfa2

    div-int/lit8 v7, v5, 0x3

    rem-int/lit8 v5, v5, 0x3

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v10

    aget-object v7, v10, v7

    if-nez v5, :cond_24

    const-string v5, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c "

    goto :goto_10

    :cond_24
    const/4 v10, 0x1

    if-ne v5, v10, :cond_25

    const-string v5, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0440\u0430\u0437\u043c\u0435\u0440 "

    goto :goto_10

    :cond_25
    const-string v5, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 "

    :goto_10
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v11

    invoke-static {v11, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v15, v7}, Lc/P3;->f(Lc/P3;Lc/s0;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_12

    :cond_26
    const/16 v5, 0xbb8

    if-lt v1, v5, :cond_2b

    add-int/lit16 v5, v1, -0xbb8

    if-ltz v5, :cond_2a

    iget-object v7, v8, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-lt v5, v7, :cond_27

    goto :goto_11

    :cond_27
    iget-object v7, v8, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    iget-object v10, v8, Lc/g0;->a:Lc/P3;

    if-lt v5, v7, :cond_28

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const-string v7, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v5, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_12

    :cond_28
    iget-object v7, v8, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    iget-object v7, v8, Lc/g0;->c:Lc/z;

    invoke-virtual {v7, v5}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v5

    if-nez v5, :cond_29

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const-string v7, "\u041d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static {v5, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_12

    :cond_29
    iget-object v5, v5, Lc/a;->b:Ljava/lang/String;

    goto :goto_12

    :cond_2a
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_11
    move-object v5, v13

    goto :goto_12

    :cond_2b
    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v7

    add-int/lit8 v10, v1, -0x64

    aget-object v7, v7, v10

    invoke-static {v15, v7}, Lc/P3;->f(Lc/P3;Lc/s0;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v5, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_12
    if-lt v1, v4, :cond_2d

    const/16 v4, 0x7d5

    if-ge v1, v4, :cond_2d

    invoke-virtual {v2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_2c

    goto :goto_13

    :cond_2c
    const/4 v4, 0x0

    goto :goto_14

    :cond_2d
    :goto_13
    const/4 v4, 0x1

    :goto_14
    invoke-virtual {v15}, Landroid/view/View;->isShown()Z

    move-result v7

    if-eqz v7, :cond_2e

    if-eqz v4, :cond_2e

    const/4 v7, 0x1

    goto :goto_15

    :cond_2e
    const/4 v7, 0x0

    :goto_15
    invoke-virtual {v12, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->setVisibleToUser(Z)V

    invoke-virtual {v15}, Landroid/view/View;->isShown()Z

    move-result v7

    if-eqz v7, :cond_30

    if-eqz v4, :cond_30

    const/16 v4, 0xbb8

    if-lt v1, v4, :cond_2f

    iget-object v7, v8, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    add-int/2addr v7, v4

    if-ge v1, v7, :cond_2f

    add-int/lit16 v4, v1, -0xbb8

    invoke-virtual {v8, v4}, Lc/g0;->b(I)Z

    move-result v4

    if-eqz v4, :cond_30

    :cond_2f
    const/4 v4, 0x1

    goto :goto_16

    :cond_30
    const/4 v4, 0x0

    :goto_16
    invoke-virtual {v12, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->setEnabled(Z)V

    invoke-virtual {v12, v4}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    iget v7, v15, Lc/P3;->R1:I

    if-ne v1, v7, :cond_31

    const/4 v7, 0x1

    invoke-virtual {v12, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->setAccessibilityFocused(Z)V

    :cond_31
    const/16 v7, 0x3e8

    if-lt v1, v7, :cond_32

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v10

    add-int/2addr v10, v7

    if-lt v1, v10, :cond_34

    :cond_32
    const/16 v7, 0xbb8

    if-lt v1, v7, :cond_33

    iget-object v8, v8, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    add-int/2addr v8, v7

    if-lt v1, v8, :cond_34

    :cond_33
    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-static {v7, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :cond_34
    const/16 v7, 0x6e

    const-string v10, ". "

    if-ne v1, v7, :cond_38

    new-instance v5, Ljava/lang/StringBuilder;

    iget-object v7, v6, Lc/G0;->a:Landroid/app/Activity;

    const-string v11, "\u0414\u0430\u043d\u043d\u044b\u0435 OBD. "

    invoke-static {v7, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v5, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v11, v6, Lc/G0;->i:Ljava/lang/String;

    invoke-static {v7, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v6, Lc/G0;->j:Ljava/lang/String;

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_35

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v11, v6, Lc/G0;->j:Ljava/lang/String;

    invoke-static {v7, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_35
    iget-object v11, v6, Lc/G0;->f:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_17
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_36

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lc/F0;

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v8, v14, Lc/F0;->a:Ljava/lang/String;

    invoke-static {v7, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v8, v6, Lc/G0;->g:[Ljava/lang/String;

    invoke-virtual {v14}, Ljava/lang/Enum;->ordinal()I

    move-result v17

    aget-object v8, v8, v17

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v8, 0x20

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v8, v6, Lc/G0;->h:[Ljava/lang/String;

    invoke-virtual {v14}, Ljava/lang/Enum;->ordinal()I

    move-result v14

    aget-object v8, v8, v14

    invoke-static {v7, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_17

    :cond_36
    iget-object v8, v6, Lc/G0;->H:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_18
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_37

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/i6;

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v14, v6, Lc/G0;->b:Lc/n1;

    invoke-virtual {v14}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v11, v14}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v7, v14}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v14, v6, Lc/G0;->I:Ljava/util/LinkedHashMap;

    iget-object v11, v11, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v14, v11}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v14, 0x20

    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v14, v6, Lc/G0;->J:Ljava/util/LinkedHashMap;

    invoke-virtual {v14, v11}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-static {v7, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_18

    :cond_37
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_38
    const/16 v3, 0x69

    if-ne v1, v3, :cond_3a

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v5, v15, Lc/P3;->r:Z

    if-eqz v5, :cond_39

    const-string v5, "OBD"

    goto :goto_19

    :cond_39
    const-string v5, "GPS"

    :goto_19
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_3a
    const/16 v3, 0x64

    if-ne v1, v3, :cond_40

    iget-object v3, v15, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->f0()Z

    move-result v6

    if-eqz v6, :cond_40

    const-string v6, "clock_status_visible"

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    const/4 v7, 0x1

    invoke-interface {v3, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_40

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v15, Lc/P3;->C:Lc/A8;

    if-nez v5, :cond_3b

    goto :goto_1a

    :cond_3b
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget-boolean v7, v5, Lc/A8;->e:Z

    if-eqz v7, :cond_3c

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const-string v8, "\u0421\u043e\u0442\u043e\u0432\u0430\u044f \u0441\u0435\u0442\u044c"

    invoke-static {v7, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x20

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v7, v5, Lc/A8;->h:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3c
    iget-boolean v7, v5, Lc/A8;->b:Z

    if-eqz v7, :cond_3d

    const-string v7, ". Wi-Fi "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    iget-object v8, v5, Lc/A8;->i:Ljava/lang/String;

    invoke-static {v7, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3d
    iget-boolean v5, v5, Lc/A8;->c:Z

    if-eqz v5, :cond_3e

    const-string v5, ". VPN"

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3e
    invoke-virtual {v15}, Lc/P3;->m()Ljava/lang/String;

    move-result-object v5

    const-string v7, ". Bluetooth "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "%"

    invoke-virtual {v5, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3f

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const-string v8, "\u0417\u0430\u0440\u044f\u0434 \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430"

    invoke-static {v7, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x20

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_3f
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    :goto_1a
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_40
    const/16 v3, 0x66

    if-ne v1, v3, :cond_41

    iget-boolean v3, v15, Lc/P3;->w0:Z

    if-eqz v3, :cond_41

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-object v3, v15, Lc/P3;->v0:Lc/U4;

    invoke-virtual {v3, v6, v7}, Lc/U4;->b(J)Z

    move-result v3

    if-nez v3, :cond_41

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    const-string v6, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435"

    invoke-static {v5, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_41
    invoke-virtual {v12, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v12, v5}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    if-eqz v4, :cond_42

    const/16 v3, 0x10

    invoke-virtual {v12, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    :cond_42
    if-eqz v4, :cond_43

    const/16 v3, 0x3e8

    if-lt v1, v3, :cond_43

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/2addr v5, v3

    if-ge v1, v5, :cond_43

    add-int/lit16 v3, v1, -0x3e8

    invoke-virtual {v9, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/q5;

    iget-boolean v3, v3, Lc/q5;->g:Z

    if-eqz v3, :cond_43

    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_DISMISS:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {v12, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    :cond_43
    iget-boolean v3, v15, Lc/P3;->L1:Z

    if-nez v3, :cond_44

    if-eqz v4, :cond_44

    const/16 v3, 0x64

    if-lt v1, v3, :cond_44

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    array-length v5, v5

    add-int/2addr v5, v3

    if-ge v1, v5, :cond_44

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v5

    sub-int/2addr v1, v3

    aget-object v3, v5, v1

    sget-object v5, Lc/s0;->i:Lc/s0;

    if-eq v3, v5, :cond_44

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v3

    aget-object v1, v3, v1

    sget-object v3, Lc/s0;->m:Lc/s0;

    if-eq v1, v3, :cond_44

    const/16 v1, 0x20

    invoke-virtual {v12, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    :cond_44
    if-eqz v4, :cond_45

    const/16 v1, 0x40

    invoke-virtual {v12, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    const/16 v1, 0x80

    invoke-virtual {v12, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    :cond_45
    const/4 v1, 0x2

    new-array v1, v1, [I

    invoke-virtual {v15, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    iget v4, v2, Landroid/graphics/RectF;->left:F

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    const/4 v5, 0x0

    aget v6, v1, v5

    add-int/2addr v4, v6

    iget v6, v2, Landroid/graphics/RectF;->top:F

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    const/4 v7, 0x1

    aget v8, v1, v7

    add-int/2addr v6, v8

    iget v8, v2, Landroid/graphics/RectF;->right:F

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    aget v5, v1, v5

    add-int/2addr v8, v5

    iget v2, v2, Landroid/graphics/RectF;->bottom:F

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    aget v1, v1, v7

    add-int/2addr v2, v1

    invoke-virtual {v3, v4, v6, v8, v2}, Landroid/graphics/Rect;->set(IIII)V

    invoke-virtual {v12, v3}, Landroid/view/accessibility/AccessibilityNodeInfo;->setBoundsInScreen(Landroid/graphics/Rect;)V

    return-object v12
.end method

.method public final performAction(IILandroid/os/Bundle;)Z
    .locals 5

    const/4 p3, 0x0

    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    return p3

    :cond_0
    iget-object v1, p0, Lc/O3;->b:Lc/P3;

    const/16 v2, 0xbb8

    if-lt p1, v2, :cond_1

    iget-object v3, v1, Lc/P3;->t1:Lc/g0;

    iget-object v3, v3, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/2addr v3, v2

    if-ge p1, v3, :cond_1

    iget-object v2, v1, Lc/P3;->t1:Lc/g0;

    add-int/lit16 v3, p1, -0xbb8

    invoke-virtual {v2, v3}, Lc/g0;->b(I)Z

    move-result v2

    if-nez v2, :cond_1

    return p3

    :cond_1
    const/16 v2, 0x10

    if-ne p2, v2, :cond_2

    invoke-virtual {v1, p1}, Lc/P3;->h(I)Z

    move-result p1

    return p1

    :cond_2
    const/16 v2, 0x20

    if-ne p2, v2, :cond_3

    invoke-virtual {v1, p1}, Lc/P3;->i(I)Z

    move-result p1

    return p1

    :cond_3
    invoke-virtual {v1}, Landroid/view/View;->isShown()Z

    move-result v2

    if-nez v2, :cond_4

    return p3

    :cond_4
    sget-object v2, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_DISMISS:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I

    move-result v2

    const/4 v3, 0x1

    if-ne p2, v2, :cond_7

    const/16 v2, 0x3e8

    if-lt p1, v2, :cond_7

    iget-object v4, v1, Lc/P3;->f0:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    add-int/2addr v4, v2

    if-ge p1, v4, :cond_7

    iget-object p2, v1, Lc/P3;->f0:Ljava/util/ArrayList;

    sub-int/2addr p1, v2

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/q5;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    iget-boolean v0, p1, Lc/q5;->g:Z

    if-eqz v0, :cond_6

    iget-object p1, p1, Lc/q5;->f:Ljava/lang/String;

    if-eqz p1, :cond_6

    if-nez p2, :cond_5

    goto :goto_0

    :cond_5
    :try_start_0
    invoke-virtual {p2, p1}, Landroid/service/notification/NotificationListenerService;->cancelNotification(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    move p3, v3

    :catch_0
    :cond_6
    :goto_0
    return p3

    :cond_7
    const/16 v2, 0x40

    if-ne p2, v2, :cond_8

    iput p1, v1, Lc/P3;->R1:I

    const p2, 0x8000

    invoke-virtual {v1, p1, p2}, Lc/P3;->e0(II)V

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    return v3

    :cond_8
    const/16 v2, 0x80

    if-ne p2, v2, :cond_9

    iget p2, v1, Lc/P3;->R1:I

    if-ne p2, p1, :cond_9

    iput v0, v1, Lc/P3;->R1:I

    const/high16 p2, 0x10000

    invoke-virtual {v1, p1, p2}, Lc/P3;->e0(II)V

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    return v3

    :cond_9
    return p3
.end method
