.class public final synthetic Lc/b1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    iput p1, p0, Lc/b1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    iget v0, p0, Lc/b1;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lc/b9;

    invoke-interface {p1}, Lc/b9;->c()V

    return-void

    :pswitch_0
    check-cast p1, Lc/b9;

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Lc/b9;->b(I)V

    return-void

    :pswitch_1
    check-cast p1, Lc/b9;

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Lc/b9;->b(I)V

    return-void

    :pswitch_2
    check-cast p1, Lc/b9;

    const/4 v0, 0x0

    invoke-interface {p1, v0}, Lc/b9;->b(I)V

    return-void

    :pswitch_3
    check-cast p1, Lc/s0;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
