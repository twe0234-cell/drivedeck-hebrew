.class public final synthetic Lc/U2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/k3;

.field public final synthetic b:Landroid/widget/TimePicker;

.field public final synthetic c:Z

.field public final synthetic d:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>(Lc/k3;Landroid/widget/TimePicker;ZLandroid/app/Dialog;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/U2;->a:Lc/k3;

    iput-object p2, p0, Lc/U2;->b:Landroid/widget/TimePicker;

    iput-boolean p3, p0, Lc/U2;->c:Z

    iput-object p4, p0, Lc/U2;->d:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget-object p1, p0, Lc/U2;->a:Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/U2;->b:Landroid/widget/TimePicker;

    invoke-virtual {v0}, Landroid/widget/TimePicker;->getHour()I

    move-result v1

    mul-int/lit8 v1, v1, 0x3c

    invoke-virtual {v0}, Landroid/widget/TimePicker;->getMinute()I

    move-result v0

    add-int/2addr v0, v1

    iget-boolean v1, p0, Lc/U2;->c:Z

    iget-object v2, p1, Lc/k3;->c:Lc/n1;

    if-eqz v1, :cond_0

    invoke-virtual {v2}, Lc/n1;->M()I

    move-result v3

    goto :goto_0

    :cond_0
    invoke-virtual {v2}, Lc/n1;->N()I

    move-result v3

    :goto_0
    if-ne v0, v3, :cond_1

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v0, "\u0412\u0440\u0435\u043c\u044f \u0441\u0432\u0435\u0442\u043b\u043e\u0439 \u0438 \u0442\u0451\u043c\u043d\u043e\u0439 \u0442\u0435\u043c\u044b \u0434\u043e\u043b\u0436\u043d\u043e \u043e\u0442\u043b\u0438\u0447\u0430\u0442\u044c\u0441\u044f"

    const/4 v1, 0x0

    invoke-static {p1, v0, p1, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_4

    :cond_1
    if-eqz v1, :cond_2

    move v3, v0

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Lc/n1;->N()I

    move-result v3

    :goto_1
    if-eqz v1, :cond_3

    invoke-virtual {v2}, Lc/n1;->M()I

    move-result v4

    goto :goto_2

    :cond_3
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move v4, v0

    :goto_2
    if-ltz v3, :cond_5

    const/16 v5, 0x5a0

    if-ge v3, v5, :cond_5

    if-ltz v4, :cond_5

    if-ge v4, v5, :cond_5

    if-eq v3, v4, :cond_5

    iget-object v3, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    if-eqz v1, :cond_4

    const-string v1, "theme_light_minute"

    goto :goto_3

    :cond_4
    const-string v1, "theme_dark_minute"

    :goto_3
    invoke-interface {v3, v1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v0, p1, Lc/k3;->d:Lc/u0;

    invoke-virtual {v2}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/u0;->l(Ljava/lang/String;)V

    iget-object v0, p0, Lc/U2;->d:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    invoke-virtual {p1}, Lc/k3;->X()V

    :goto_4
    return-void

    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Theme times must be distinct minutes of the day"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
