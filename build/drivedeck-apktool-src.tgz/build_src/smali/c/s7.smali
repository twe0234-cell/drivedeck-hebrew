.class public final synthetic Lc/s7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/PixelCopy$OnPixelCopyFinishedListener;


# instance fields
.field public final synthetic a:Lc/v7;

.field public final synthetic b:Landroid/graphics/Bitmap;

.field public final synthetic c:Z


# direct methods
.method public synthetic constructor <init>(Lc/v7;Landroid/graphics/Bitmap;Z)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/s7;->a:Lc/v7;

    iput-object p2, p0, Lc/s7;->b:Landroid/graphics/Bitmap;

    iput-boolean p3, p0, Lc/s7;->c:Z

    return-void
.end method


# virtual methods
.method public final onPixelCopyFinished(I)V
    .locals 31

    move-object/from16 v1, p0

    iget-object v10, v1, Lc/s7;->b:Landroid/graphics/Bitmap;

    iget-boolean v0, v1, Lc/s7;->c:Z

    iget-object v11, v1, Lc/s7;->a:Lc/v7;

    iget v12, v11, Lc/v7;->b:I

    const-string v13, "pane_pixel_probe"

    const/4 v14, 0x0

    :try_start_0
    iget-boolean v2, v11, Lc/v7;->o:Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_0

    iput-boolean v14, v11, Lc/v7;->J:Z

    :goto_0
    invoke-virtual {v10}, Landroid/graphics/Bitmap;->recycle()V

    goto/16 :goto_6

    :cond_0
    if-nez p1, :cond_6

    const/16 v9, 0x400

    :try_start_1
    new-array v8, v9, [I

    const/16 v16, 0x20

    const/16 v17, 0x20

    const/4 v4, 0x0

    const/16 v5, 0x20

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v2, v10

    move-object v3, v8

    move-object v15, v8

    move/from16 v8, v16

    move v14, v9

    move/from16 v9, v17

    invoke-virtual/range {v2 .. v9}, Landroid/graphics/Bitmap;->getPixels([IIIIIII)V

    iget-object v2, v11, Lc/v7;->K:[I

    if-nez v2, :cond_1

    const/16 v18, -0x1

    goto :goto_1

    :cond_1
    const/16 v18, 0x0

    :goto_1
    move/from16 v5, v18

    const/4 v3, 0x0

    const/4 v4, 0x0

    :goto_2
    if-ge v3, v14, :cond_5

    aget v6, v15, v3

    const v7, 0xffffff

    and-int v8, v6, v7

    shr-int/lit8 v9, v8, 0x10

    and-int/lit16 v9, v9, 0xff

    const/16 v14, 0x20

    if-gt v9, v14, :cond_2

    shr-int/lit8 v9, v8, 0x8

    and-int/lit16 v9, v9, 0xff

    if-gt v9, v14, :cond_2

    and-int/lit16 v6, v6, 0xff

    if-le v6, v14, :cond_3

    :cond_2
    add-int/lit8 v4, v4, 0x1

    :cond_3
    if-eqz v2, :cond_4

    aget v6, v2, v3

    and-int/2addr v6, v7

    if-eq v8, v6, :cond_4

    add-int/lit8 v5, v5, 0x1

    :cond_4
    add-int/lit8 v3, v3, 0x1

    const/16 v14, 0x400

    goto :goto_2

    :cond_5
    filled-new-array {v4, v5}, [I

    move-result-object v2

    const/4 v3, 0x0

    aget v4, v2, v3

    const/4 v3, 0x1

    aget v2, v2, v3

    iput-object v15, v11, Lc/v7;->K:[I

    move v15, v4

    goto :goto_3

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    goto :goto_7

    :catch_0
    move-exception v0

    goto :goto_5

    :cond_6
    const/4 v2, -0x1

    const/4 v15, -0x1

    :goto_3
    const-string v17, "renderer_id"

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    const-string v19, "display_id"

    invoke-virtual {v11}, Lc/v7;->f()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v20

    const-string v21, "result"

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v22

    const-string v23, "non_dark_pixels"

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string v25, "changed_pixels"

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v26

    const-string v27, "shown"

    invoke-virtual {v11}, Landroid/view/View;->isShown()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v28

    const-string v29, "surface_valid"

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v30

    filled-new-array/range {v17 .. v30}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v13, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x0

    :goto_4
    iput-boolean v2, v11, Lc/v7;->J:Z

    goto/16 :goto_0

    :goto_5
    :try_start_2
    const-string v2, "renderer_id"

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "display_id"

    invoke-virtual {v11}, Lc/v7;->f()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const-string v6, "result"

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v7

    filled-new-array/range {v2 .. v7}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v13, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v2, 0x0

    goto :goto_4

    :goto_6
    return-void

    :goto_7
    iput-boolean v2, v11, Lc/v7;->J:Z

    invoke-virtual {v10}, Landroid/graphics/Bitmap;->recycle()V

    throw v0
.end method
