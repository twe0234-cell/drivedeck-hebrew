.class public final Lc/p7;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/RectF;

.field public final c:Landroid/graphics/RectF;

.field public final d:Landroid/graphics/RectF;

.field public e:F

.field public final f:Lc/R1;

.field public g:F

.field public h:F

.field public i:J

.field public j:Z

.field public final k:Lc/o7;

.field public l:I

.field public m:F

.field public final n:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lc/R1;)V
    .locals 2

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/p7;->a:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/p7;->b:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/p7;->c:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/p7;->d:Landroid/graphics/RectF;

    const/high16 v0, 0x3f000000    # 0.5f

    iput v0, p0, Lc/p7;->e:F

    new-instance v0, Lc/o7;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/o7;-><init>(Lc/p7;I)V

    iput-object v0, p0, Lc/p7;->k:Lc/o7;

    const/4 v0, -0x1

    iput v0, p0, Lc/p7;->l:I

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/p7;->n:Landroid/os/Handler;

    iput-object p2, p0, Lc/p7;->f:Lc/R1;

    const-string p2, "\u0416\u0435\u0441\u0442\u044b \u043e\u043a\u043e\u043d DriveDeck"

    invoke-static {p1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .locals 5

    const/4 v0, 0x3

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    if-eq v1, v2, :cond_0

    new-instance v0, Lc/w;

    const/16 v1, 0x8

    invoke-direct {v0, p0, p1, v1}, Lc/w;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_0
    iget v1, p0, Lc/p7;->l:I

    if-ltz v1, :cond_1

    return-void

    :cond_1
    iput p1, p0, Lc/p7;->l:I

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/view/View;->performHapticFeedback(I)Z

    new-array v1, v0, [F

    fill-array-data v1, :array_0

    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v1

    const-wide/16 v2, 0xb4

    invoke-virtual {v1, v2, v3}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    new-instance v4, Lc/X1;

    invoke-direct {v4, p0, v0}, Lc/X1;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v4}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    invoke-virtual {v1}, Landroid/animation/ValueAnimator;->start()V

    iget-object v0, p0, Lc/p7;->f:Lc/R1;

    iget-object v1, v0, Lc/R1;->c:Ljava/lang/Object;

    check-cast v1, Lc/S1;

    iget-object v1, v1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez p1, :cond_2

    iget-object p1, v0, Lc/R1;->a:Ljava/lang/Object;

    :goto_0
    check-cast p1, Ljava/lang/String;

    goto :goto_1

    :cond_2
    iget-object p1, v0, Lc/R1;->b:Ljava/lang/Object;

    goto :goto_0

    :goto_1
    invoke-virtual {v1, p1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->g(Ljava/lang/String;)V

    iget-object p1, p0, Lc/p7;->n:Landroid/os/Handler;

    new-instance v0, Lc/o7;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/o7;-><init>(Lc/p7;I)V

    invoke-virtual {p1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method

.method public final b(F)F
    .locals 1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final c(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V
    .locals 7

    iget v0, p0, Lc/p7;->l:I

    const/4 v1, 0x0

    if-ne p3, v0, :cond_0

    iget p3, p0, Lc/p7;->m:F

    goto :goto_0

    :cond_0
    move p3, v1

    :goto_0
    iget-object v0, p0, Lc/p7;->a:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    cmpl-float v1, p3, v1

    if-lez v1, :cond_1

    iget v1, v2, Lc/r4;->f:I

    goto :goto_1

    :cond_1
    iget-boolean v1, v2, Lc/r4;->m:Z

    if-eqz v1, :cond_2

    const/16 v1, 0x6a

    const/16 v2, 0x52

    const/16 v3, 0x60

    invoke-static {v2, v3, v1}, Landroid/graphics/Color;->rgb(III)I

    move-result v1

    goto :goto_1

    :cond_2
    const/16 v1, 0xe1

    const/16 v2, 0xe2

    const/16 v3, 0xea

    const/16 v4, 0xe9

    invoke-static {v1, v2, v3, v4}, Landroid/graphics/Color;->argb(IIII)I

    move-result v1

    :goto_1
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    const v2, 0x3da3d70a    # 0.08f

    mul-float/2addr v2, p3

    const v3, 0x3eaaaaab

    add-float/2addr v2, v3

    mul-float/2addr v2, v1

    iget-object v1, p0, Lc/p7;->d:Landroid/graphics/RectF;

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    sub-float/2addr v3, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, 0x40c00000    # 6.0f

    mul-float/2addr p3, v5

    const/high16 v6, 0x41200000    # 10.0f

    add-float/2addr p3, v6

    invoke-virtual {p0, p3}, Lc/p7;->b(F)F

    move-result p3

    sub-float/2addr v4, p3

    invoke-virtual {p2}, Landroid/graphics/RectF;->centerX()F

    move-result p2

    add-float/2addr p2, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p3

    int-to-float p3, p3

    invoke-virtual {p0, v5}, Lc/p7;->b(F)F

    move-result v2

    sub-float/2addr p3, v2

    invoke-virtual {v1, v3, v4, p2, p3}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 p2, 0x40400000    # 3.0f

    invoke-virtual {p0, p2}, Lc/p7;->b(F)F

    move-result p3

    invoke-virtual {p0, p2}, Lc/p7;->b(F)F

    move-result p2

    invoke-virtual {p1, v1, p3, p2, v0}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 2

    iget-object v0, p0, Lc/p7;->n:Landroid/os/Handler;

    iget-object v1, p0, Lc/p7;->k:Lc/o7;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/p7;->i:J

    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 6

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    const/high16 v0, 0x41200000    # 10.0f

    invoke-virtual {p0, v0}, Lc/p7;->b(F)F

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lc/p7;->e:F

    mul-float/2addr v1, v2

    iget-object v2, p0, Lc/p7;->b:Landroid/graphics/RectF;

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v0, v3

    sub-float v3, v1, v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    const/4 v5, 0x0

    invoke-virtual {v2, v5, v5, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget-object v3, p0, Lc/p7;->c:Landroid/graphics/RectF;

    add-float/2addr v1, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v3, v1, v5, v0, v4}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v2, v0}, Lc/p7;->c(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    const/4 v0, 0x1

    invoke-virtual {p0, p1, v3, v0}, Lc/p7;->c(Landroid/graphics/Canvas;Landroid/graphics/RectF;I)V

    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 12

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    iget-object v1, p0, Lc/p7;->n:Landroid/os/Handler;

    const/4 v2, 0x0

    iget-object v3, p0, Lc/p7;->k:Lc/o7;

    const/4 v4, 0x1

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lc/p7;->g:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iput p1, p0, Lc/p7;->h:F

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    iput-wide v5, p0, Lc/p7;->i:J

    iput-boolean v2, p0, Lc/p7;->j:Z

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v5, 0x1f4

    invoke-virtual {v1, v3, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return v4

    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v5, 0x2

    const-wide/16 v6, 0x0

    if-ne v0, v5, :cond_2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v2, p0, Lc/p7;->g:F

    sub-float/2addr v0, v2

    float-to-double v8, v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v0, p0, Lc/p7;->h:F

    sub-float/2addr p1, v0

    float-to-double v10, p1

    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v8

    const/high16 p1, 0x41900000    # 18.0f

    invoke-virtual {p0, p1}, Lc/p7;->b(F)F

    move-result p1

    float-to-double v10, p1

    cmpl-double p1, v8, v10

    if-lez p1, :cond_1

    iput-wide v6, p0, Lc/p7;->i:J

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_1
    return v4

    :cond_2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v8, 0x3

    if-eq v0, v8, :cond_a

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v8, 0x5

    if-ne v0, v8, :cond_3

    goto/16 :goto_2

    :cond_3
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-eq v0, v4, :cond_4

    return v4

    :cond_4
    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v0, p0, Lc/p7;->j:Z

    if-eqz v0, :cond_5

    iput-boolean v2, p0, Lc/p7;->j:Z

    return v4

    :cond_5
    invoke-super {p0}, Landroid/view/View;->performClick()Z

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iget v1, p0, Lc/p7;->g:F

    sub-float/2addr v0, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    iget v1, p0, Lc/p7;->h:F

    sub-float/2addr p1, v1

    iget v1, p0, Lc/p7;->g:F

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    iget v8, p0, Lc/p7;->e:F

    mul-float/2addr v3, v8

    cmpg-float v1, v1, v3

    if-gez v1, :cond_6

    goto :goto_0

    :cond_6
    move v2, v4

    :goto_0
    const/high16 v1, 0x42080000    # 34.0f

    invoke-virtual {p0, v1}, Lc/p7;->b(F)F

    move-result v1

    neg-float v1, v1

    cmpg-float v1, p1, v1

    iget-object v3, p0, Lc/p7;->f:Lc/R1;

    if-gez v1, :cond_8

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v8

    cmpl-float v1, v1, v8

    if-lez v1, :cond_8

    iget-object p1, v3, Lc/R1;->c:Ljava/lang/Object;

    check-cast p1, Lc/S1;

    iget-object p1, p1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    iget-object v0, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Lc/S1;->c()V

    :cond_7
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x34000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    const-string v1, "ru.drivedeck.launcher.PICK_SLOT"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_1

    :cond_8
    const/high16 v1, 0x425c0000    # 55.0f

    invoke-virtual {p0, v1}, Lc/p7;->b(F)F

    move-result v1

    neg-float v1, v1

    cmpg-float v1, v0, v1

    if-gez v1, :cond_9

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    cmpl-float p1, v0, p1

    if-lez p1, :cond_9

    iget-object p1, v3, Lc/R1;->c:Ljava/lang/Object;

    check-cast p1, Lc/S1;

    iget-object p1, p1, Lc/S1;->a:Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    new-instance v0, Lc/n1;

    invoke-direct {v0, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    const-string v1, ""

    invoke-virtual {v0, v1, v2}, Lc/n1;->P0(Ljava/lang/String;I)V

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    invoke-virtual {p1, v5}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    iget-object p1, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz p1, :cond_9

    invoke-virtual {p1}, Lc/S1;->c()V

    :cond_9
    :goto_1
    iput-wide v6, p0, Lc/p7;->i:J

    return v4

    :cond_a
    :goto_2
    iput-wide v6, p0, Lc/p7;->i:J

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return v4
.end method

.method public final performClick()Z
    .locals 1

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    const/4 v0, 0x1

    return v0
.end method
