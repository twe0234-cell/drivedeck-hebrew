.class public final synthetic Lc/E4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J

.field public final synthetic c:Z

.field public final synthetic d:Landroid/view/View;

.field public final synthetic e:Landroid/view/View;

.field public final synthetic f:J


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;JZLandroid/view/View;Landroid/view/View;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/E4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/E4;->b:J

    iput-boolean p4, p0, Lc/E4;->c:Z

    iput-object p5, p0, Lc/E4;->d:Landroid/view/View;

    iput-object p6, p0, Lc/E4;->e:Landroid/view/View;

    iput-wide p7, p0, Lc/E4;->f:J

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    iget-object v8, p0, Lc/E4;->a:Lru/drivedeck/launcher/MainActivity;

    iget-wide v0, v8, Lru/drivedeck/launcher/MainActivity;->k:J

    iget-wide v9, p0, Lc/E4;->b:J

    cmp-long v0, v9, v0

    if-eqz v0, :cond_0

    goto/16 :goto_4

    :cond_0
    iget-boolean v0, p0, Lc/E4;->c:Z

    iget-object v11, p0, Lc/E4;->d:Landroid/view/View;

    if-eqz v0, :cond_1

    if-eqz v11, :cond_1

    const/4 v0, 0x4

    invoke-virtual {v11, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v0, 0x0

    invoke-virtual {v11, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_1
    iget-object v12, p0, Lc/E4;->e:Landroid/view/View;

    const/4 v13, 0x1

    invoke-virtual {v8, v12, v13}, Lru/drivedeck/launcher/MainActivity;->x(Landroid/view/View;Z)V

    iput-object v12, v8, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    const/4 v14, 0x0

    iput-object v14, v8, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    const-string v3, "incoming_active"

    iget-wide v6, p0, Lc/E4;->f:J

    move-object v0, v8

    move-wide v1, v9

    move-object v4, v11

    move-object v5, v12

    invoke-virtual/range {v0 .. v7}, Lru/drivedeck/launcher/MainActivity;->q(JLjava/lang/String;Landroid/view/View;Landroid/view/View;J)V

    if-eqz v11, :cond_7

    if-ne v11, v12, :cond_2

    goto :goto_1

    :cond_2
    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v12, v0, :cond_3

    if-eqz v0, :cond_3

    iget-object v0, v0, Lc/Q3;->y:Lc/t2;

    goto :goto_0

    :cond_3
    move-object v0, v14

    :goto_0
    if-eqz v0, :cond_7

    iget-object v5, v0, Lc/t2;->u:Ljava/lang/String;

    if-nez v5, :cond_4

    goto :goto_1

    :cond_4
    iget-object v1, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v11, v1, :cond_5

    if-eqz v1, :cond_5

    invoke-virtual {v1, v5}, Lc/m2;->B(Ljava/lang/String;)Lc/t2;

    move-result-object v14

    :cond_5
    if-nez v14, :cond_6

    goto :goto_1

    :cond_6
    invoke-virtual {v0}, Lc/t2;->y()I

    move-result v6

    invoke-virtual {v14}, Lc/t2;->y()I

    move-result v7

    invoke-virtual {v8}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v11

    new-instance v14, Lc/K4;

    move-object v0, v14

    move-object v1, v8

    move-wide v2, v9

    move-object v4, v12

    invoke-direct/range {v0 .. v7}, Lc/K4;-><init>(Lru/drivedeck/launcher/MainActivity;JLandroid/view/View;Ljava/lang/String;II)V

    const-wide/16 v0, 0xdac

    invoke-virtual {v11, v14, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_7
    :goto_1
    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v12, v0, :cond_8

    invoke-virtual {v0, v13}, Lc/Q3;->P(Z)V

    goto :goto_2

    :cond_8
    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v12, v0, :cond_9

    invoke-virtual {v0, v13}, Lc/m2;->G(Z)V

    :cond_9
    :goto_2
    invoke-virtual {v8, v12}, Lru/drivedeck/launcher/MainActivity;->F(Landroid/view/View;)Lc/t2;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Lc/t2;->m0()V

    invoke-virtual {v0}, Lc/t2;->T()V

    :cond_a
    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v12, v0, :cond_b

    invoke-virtual {v0}, Lc/Q3;->N()V

    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    iget-object v1, v8, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0, v1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0}, Lc/Q3;->M()V

    goto :goto_3

    :cond_b
    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v12, v0, :cond_c

    invoke-virtual {v0}, Lc/m2;->E()V

    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-object v1, v8, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0, v1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object v0, v8, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v0}, Lc/m2;->D()V

    :cond_c
    :goto_3
    invoke-virtual {v8, v12}, Lru/drivedeck/launcher/MainActivity;->j0(Landroid/view/View;)V

    :goto_4
    return-void
.end method
