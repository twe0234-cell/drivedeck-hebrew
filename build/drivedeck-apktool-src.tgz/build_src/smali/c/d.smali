.class public final synthetic Lc/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic a:[F

.field public final synthetic b:I

.field public final synthetic c:Lc/k;

.field public final synthetic d:Lc/j;


# direct methods
.method public synthetic constructor <init>([FILc/k;Lc/j;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/d;->a:[F

    iput p2, p0, Lc/d;->b:I

    iput-object p3, p0, Lc/d;->c:Lc/k;

    iput-object p4, p0, Lc/d;->d:Lc/j;

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    iget-object v0, p0, Lc/d;->a:[F

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p1, :cond_1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    aput p1, v0, v2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    aput p1, v0, v1

    :cond_0
    :goto_0
    move v1, v2

    goto :goto_1

    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    if-eq p1, v1, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    aget v3, v0, v2

    sub-float/2addr p1, v3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    aget v0, v0, v1

    sub-float/2addr v3, v0

    mul-float/2addr p1, p1

    mul-float/2addr v3, v3

    add-float/2addr v3, p1

    iget p1, p0, Lc/d;->b:I

    mul-int/2addr p1, p1

    int-to-float p1, p1

    cmpg-float p1, v3, p1

    if-gtz p1, :cond_0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    float-to-int p1, p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    float-to-int p2, p2

    iget-object v0, p0, Lc/d;->c:Lc/k;

    invoke-virtual {v0, p1, p2}, Landroid/widget/AbsListView;->pointToPosition(II)I

    move-result p1

    const/4 p2, -0x1

    if-ne p1, p2, :cond_0

    iget-object p1, p0, Lc/d;->d:Lc/j;

    invoke-virtual {p1}, Lc/j;->dismiss()V

    :goto_1
    return v1
.end method
