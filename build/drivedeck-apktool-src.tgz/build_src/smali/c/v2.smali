.class public final synthetic Lc/v2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/k3;

.field public final synthetic b:F


# direct methods
.method public synthetic constructor <init>(Lc/k3;F)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/v2;->a:Lc/k3;

    iput p2, p0, Lc/v2;->b:F

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Lc/v2;->a:Lc/k3;

    iget v1, p0, Lc/v2;->b:F

    iput v1, v0, Lc/k3;->x:F

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void
.end method
