.class public final Lc/u1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final g:[J


# instance fields
.field public final a:[J

.field public b:J

.field public c:J

.field public d:J

.field public e:J

.field public f:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/16 v0, 0x11

    new-array v0, v0, [J

    fill-array-data v0, :array_0

    sput-object v0, Lc/u1;->g:[J

    return-void

    :array_0
    .array-data 8
        0x1
        0x2
        0x4
        0x8
        0xc
        0x10
        0x14
        0x19
        0x21
        0x32
        0x4b
        0x64
        0x96
        0xfa
        0x1f4
        0x3e8
        0x1388
    .end array-data
.end method

.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x12

    new-array v0, v0, [J

    iput-object v0, p0, Lc/u1;->a:[J

    return-void
.end method


# virtual methods
.method public final declared-synchronized a(J)V
    .locals 8

    monitor-enter p0

    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-gez v0, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_0
    iget-wide v0, p0, Lc/u1;->b:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/u1;->b:J

    iget-wide v0, p0, Lc/u1;->c:J

    add-long/2addr v0, p1

    iput-wide v0, p0, Lc/u1;->c:J

    iget-wide v0, p0, Lc/u1;->d:J

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    iput-wide v0, p0, Lc/u1;->d:J

    const-wide/32 v0, 0xfe502b

    cmp-long v0, p1, v0

    if-lez v0, :cond_1

    iget-wide v0, p0, Lc/u1;->e:J

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/u1;->e:J

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_1
    :goto_0
    const-wide/32 v0, 0x1fca056

    cmp-long v0, p1, v0

    if-lez v0, :cond_2

    iget-wide v0, p0, Lc/u1;->f:J

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/u1;->f:J

    :cond_2
    const/4 v0, 0x0

    :goto_1
    sget-object v1, Lc/u1;->g:[J

    const/16 v4, 0x11

    if-ge v0, v4, :cond_3

    aget-wide v4, v1, v0

    const-wide/32 v6, 0xf4240

    mul-long/2addr v4, v6

    cmp-long v1, p1, v4

    if-lez v1, :cond_3

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    iget-object p1, p0, Lc/u1;->a:[J

    aget-wide v4, p1, v0

    add-long/2addr v4, v2

    aput-wide v4, p1, v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-void

    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1
.end method

.method public final b(I)J
    .locals 7

    iget-wide v0, p0, Lc/u1;->b:J

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-nez v4, :cond_0

    return-wide v2

    :cond_0
    int-to-long v4, p1

    mul-long/2addr v0, v4

    const-wide/16 v4, 0x63

    add-long/2addr v0, v4

    const-wide/16 v4, 0x64

    div-long/2addr v0, v4

    const/4 p1, 0x0

    :goto_0
    iget-object v4, p0, Lc/u1;->a:[J

    array-length v5, v4

    if-ge p1, v5, :cond_3

    aget-wide v5, v4, p1

    add-long/2addr v2, v5

    cmp-long v4, v2, v0

    if-ltz v4, :cond_2

    const/16 v0, 0x11

    if-ge p1, v0, :cond_1

    sget-object v0, Lc/u1;->g:[J

    aget-wide v1, v0, p1

    const-wide/32 v3, 0xf4240

    mul-long/2addr v1, v3

    goto :goto_1

    :cond_1
    iget-wide v1, p0, Lc/u1;->d:J

    :goto_1
    return-wide v1

    :cond_2
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_3
    iget-wide v0, p0, Lc/u1;->d:J

    return-wide v0
.end method

.method public final declared-synchronized c()[J
    .locals 19

    move-object/from16 v1, p0

    monitor-enter p0

    :try_start_0
    iget-wide v2, v1, Lc/u1;->b:J

    iget-wide v4, v1, Lc/u1;->c:J

    iget-wide v6, v1, Lc/u1;->d:J

    const/16 v0, 0x32

    invoke-virtual {v1, v0}, Lc/u1;->b(I)J

    move-result-wide v8

    const/16 v0, 0x5f

    invoke-virtual {v1, v0}, Lc/u1;->b(I)J

    move-result-wide v10

    const/16 v0, 0x63

    invoke-virtual {v1, v0}, Lc/u1;->b(I)J

    move-result-wide v12

    iget-wide v14, v1, Lc/u1;->e:J

    move-wide/from16 v16, v14

    iget-wide v14, v1, Lc/u1;->f:J

    const/16 v0, 0x8

    new-array v0, v0, [J

    const/16 v18, 0x0

    aput-wide v2, v0, v18

    const/4 v2, 0x1

    aput-wide v4, v0, v2

    const/4 v2, 0x2

    aput-wide v6, v0, v2

    const/4 v2, 0x3

    aput-wide v8, v0, v2

    const/4 v2, 0x4

    aput-wide v10, v0, v2

    const/4 v2, 0x5

    aput-wide v12, v0, v2

    const/4 v2, 0x6

    aput-wide v16, v0, v2

    const/4 v2, 0x7

    aput-wide v14, v0, v2

    iget-object v2, v1, Lc/u1;->a:[J

    const-wide/16 v3, 0x0

    invoke-static {v2, v3, v4}, Ljava/util/Arrays;->fill([JJ)V

    iput-wide v3, v1, Lc/u1;->f:J

    iput-wide v3, v1, Lc/u1;->e:J

    iput-wide v3, v1, Lc/u1;->d:J

    iput-wide v3, v1, Lc/u1;->c:J

    iput-wide v3, v1, Lc/u1;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p0

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method
