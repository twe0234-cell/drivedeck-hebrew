.class public final synthetic Lc/O2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/k3;

.field public final synthetic b:F


# direct methods
.method public synthetic constructor <init>(Lc/k3;F)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/O2;->a:Lc/k3;

    iput p2, p0, Lc/O2;->b:F

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 3

    iget-object v0, p0, Lc/O2;->a:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/v2;

    iget v2, p0, Lc/O2;->b:F

    invoke-direct {v1, v0, v2}, Lc/v2;-><init>(Lc/k3;F)V

    invoke-static {p1, v1}, Lc/k3;->p0(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void
.end method
