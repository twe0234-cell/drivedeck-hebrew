.class public final synthetic Lc/E7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/O7;


# direct methods
.method public synthetic constructor <init>(Lc/O7;I)V
    .locals 0

    iput p2, p0, Lc/E7;->a:I

    iput-object p1, p0, Lc/E7;->b:Lc/O7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .locals 1

    iget p1, p0, Lc/E7;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/E7;->b:Lc/O7;

    iget-object v0, p1, Lc/O7;->d:Landroid/widget/EditText;

    invoke-virtual {v0}, Landroid/widget/TextView;->length()I

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "+"

    invoke-virtual {p1, v0}, Lc/O7;->k(Ljava/lang/String;)V

    :cond_0
    const/4 p1, 0x1

    return p1

    :pswitch_0
    iget-object p1, p0, Lc/E7;->b:Lc/O7;

    iget-object p1, p1, Lc/O7;->d:Landroid/widget/EditText;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x1

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
