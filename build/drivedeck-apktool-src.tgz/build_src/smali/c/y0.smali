.class public final synthetic Lc/y0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/IntConsumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/y0;->a:I

    iput-object p1, p0, Lc/y0;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/y0;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(I)V
    .locals 5

    iget-object v0, p0, Lc/y0;->c:Ljava/lang/Object;

    iget-object v1, p0, Lc/y0;->b:Ljava/lang/Object;

    iget v2, p0, Lc/y0;->a:I

    packed-switch v2, :pswitch_data_0

    sget p1, Lru/drivedeck/launcher/MainActivity;->F0:I

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    check-cast v0, Lc/Q;

    invoke-virtual {v1, v0}, Lru/drivedeck/launcher/MainActivity;->r(Lc/Q;)V

    return-void

    :pswitch_0
    check-cast v1, Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/16 v2, 0x64

    const/4 v3, 0x0

    const-string v4, "music_edge_softness"

    invoke-static {v2, p1, v3, v1, v4}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    check-cast v0, Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    return-void

    :pswitch_1
    sget-object v2, Lc/s0;->d:Lc/s0;

    check-cast v1, Lc/n1;

    invoke-virtual {v1, v2, p1}, Lc/n1;->Y0(Lc/s0;I)V

    check-cast v0, Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
