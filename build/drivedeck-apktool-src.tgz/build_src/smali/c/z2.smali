.class public final synthetic Lc/z2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;


# direct methods
.method public synthetic constructor <init>(Lc/k3;I)V
    .locals 0

    iput p2, p0, Lc/z2;->a:I

    iput-object p1, p0, Lc/z2;->b:Lc/k3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget v0, p0, Lc/z2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object p1, p0, Lc/z2;->b:Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v0, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.DELETE"

    const-string v3, "package:ru.drivedeck.voice"

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u0435 \u043c\u043e\u0434\u0443\u043b\u044f"

    invoke-virtual {p1, v0}, Lc/k3;->J(Ljava/lang/String;)V

    :goto_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/z2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->v:Ljava/lang/String;

    iget-object v1, p1, Lc/k3;->w:Ljava/lang/String;

    iput-object v1, p1, Lc/k3;->v:Ljava/lang/String;

    iput-object v0, p1, Lc/k3;->w:Ljava/lang/String;

    invoke-virtual {p1}, Lc/k3;->S()V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/z2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v1, "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440 \u0437\u0430\u043f\u0443\u0441\u043a\u0430\u0435\u0442\u0441\u044f \u0432 \u0444\u043e\u043d\u0435 \u0438 \u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442\u0441\u044f \u043f\u0440\u0438 \u0432\u043e\u0437\u0432\u0440\u0430\u0442\u0435 \u0441 Bluetooth."

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lc/G8;->K0(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/z2;->b:Lc/k3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_3
    iget-object p1, p0, Lc/z2;->b:Lc/k3;

    invoke-virtual {p1}, Lc/k3;->dismiss()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
