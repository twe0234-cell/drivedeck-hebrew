.class public final synthetic Lc/x0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/n1;

.field public final synthetic b:I

.field public final synthetic c:Landroid/widget/LinearLayout;

.field public final synthetic d:[Landroid/widget/LinearLayout;

.field public final synthetic e:Lc/r4;

.field public final synthetic f:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic g:[I

.field public final synthetic h:[Ljava/lang/String;

.field public final synthetic i:Lc/F3;


# direct methods
.method public synthetic constructor <init>(Lc/n1;ILandroid/widget/LinearLayout;[Landroid/widget/LinearLayout;Lc/r4;Lru/drivedeck/launcher/MainActivity;[I[Ljava/lang/String;Lc/F3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/x0;->a:Lc/n1;

    iput p2, p0, Lc/x0;->b:I

    iput-object p3, p0, Lc/x0;->c:Landroid/widget/LinearLayout;

    iput-object p4, p0, Lc/x0;->d:[Landroid/widget/LinearLayout;

    iput-object p5, p0, Lc/x0;->e:Lc/r4;

    iput-object p6, p0, Lc/x0;->f:Lru/drivedeck/launcher/MainActivity;

    iput-object p7, p0, Lc/x0;->g:[I

    iput-object p8, p0, Lc/x0;->h:[Ljava/lang/String;

    iput-object p9, p0, Lc/x0;->i:Lc/F3;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 9

    iget-object p1, p0, Lc/x0;->a:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v0, 0x1

    iget v1, p0, Lc/x0;->b:I

    const/4 v2, 0x0

    if-ne v1, v0, :cond_0

    move v3, v0

    goto :goto_0

    :cond_0
    move v3, v2

    :goto_0
    const-string v4, "music_widget_style"

    invoke-interface {p1, v4, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-nez v1, :cond_1

    move p1, v2

    goto :goto_1

    :cond_1
    const/16 p1, 0x8

    :goto_1
    iget-object v3, p0, Lc/x0;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v3, p1}, Landroid/view/View;->setVisibility(I)V

    move p1, v2

    :goto_2
    iget-object v3, p0, Lc/x0;->d:[Landroid/widget/LinearLayout;

    const/4 v4, 0x2

    if-ge p1, v4, :cond_4

    aget-object v4, v3, p1

    iget-object v5, p0, Lc/x0;->g:[I

    aget v6, v5, p1

    if-ne v6, v1, :cond_2

    move v6, v0

    goto :goto_3

    :cond_2
    move v6, v2

    :goto_3
    iget-object v7, p0, Lc/x0;->e:Lc/r4;

    iget-object v8, p0, Lc/x0;->f:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v7, v8, v6}, Lc/G8;->U0(Lc/r4;Lru/drivedeck/launcher/MainActivity;Z)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    aget-object v3, v3, p1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v6, p0, Lc/x0;->h:[Ljava/lang/String;

    aget-object v6, v6, p1

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v5, v5, p1

    if-ne v5, v1, :cond_3

    const-string v5, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    goto :goto_4

    :cond_3
    const-string v5, ""

    :goto_4
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v8, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    add-int/lit8 p1, p1, 0x1

    goto :goto_2

    :cond_4
    iget-object p1, p0, Lc/x0;->i:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void
.end method
