.class public final synthetic Lc/L7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/N7;


# direct methods
.method public synthetic constructor <init>(Lc/N7;I)V
    .locals 0

    iput p2, p0, Lc/L7;->a:I

    iput-object p1, p0, Lc/L7;->b:Lc/N7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget v0, p0, Lc/L7;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v0, ""

    iget-object v1, p0, Lc/L7;->b:Lc/N7;

    iput-object v0, v1, Lc/N7;->c:Ljava/lang/String;

    invoke-virtual {v1}, Lc/N7;->a()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/L7;->b:Lc/N7;

    iget-object v0, v0, Lc/N7;->j:Lc/O7;

    iget-object v0, v0, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->c0:Z

    const-string v1, "android.permission.READ_CONTACTS"

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_1

    invoke-static {v0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->n()V

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->Y()V

    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
