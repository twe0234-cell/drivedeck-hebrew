.class public final Lc/c3;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/g3;


# direct methods
.method public constructor <init>(Lc/g3;)V
    .locals 0

    iput-object p1, p0, Lc/c3;->a:Lc/g3;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 2

    iget-object p1, p0, Lc/c3;->a:Lc/g3;

    iget-object v0, p1, Lc/g3;->a:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    iget-object v0, p1, Lc/g3;->c:Landroid/widget/LinearLayout;

    iget-object v1, p1, Lc/g3;->b:Lc/c0;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object p1, p1, Lc/g3;->f:Lc/k3;

    const/4 v0, 0x0

    iput-object v0, p1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    const/4 v1, 0x0

    iput-boolean v1, p1, Lc/k3;->o:Z

    iget-object v1, p1, Lc/k3;->p:Ljava/lang/String;

    iput-object v0, p1, Lc/k3;->p:Ljava/lang/String;

    if-eqz v1, :cond_0

    invoke-virtual {p1, v1}, Lc/k3;->n0(Ljava/lang/String;)V

    :cond_0
    return-void
.end method
