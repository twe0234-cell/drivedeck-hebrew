.class public final synthetic Lc/d7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/h7;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/SharedPreferences;

.field public final synthetic c:Lc/j6;

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Landroid/content/SharedPreferences;Lc/j6;Ljava/lang/String;I)V
    .locals 0

    iput p4, p0, Lc/d7;->a:I

    iput-object p1, p0, Lc/d7;->b:Landroid/content/SharedPreferences;

    iput-object p2, p0, Lc/d7;->c:Lc/j6;

    iput-object p3, p0, Lc/d7;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()Ljava/lang/Object;
    .locals 33

    move-object/from16 v0, p0

    const/16 v8, 0x22

    const-string v9, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u043d\u043e\u0433\u043e \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0445 PID"

    const-string v10, "{"

    const-string v11, "FR"

    const-string v12, "-"

    const-string v13, "000000000000000000000000"

    const-string v14, "user_"

    const-string v15, ""

    const-string v5, "Id"

    iget-object v4, v0, Lc/d7;->c:Lc/j6;

    iget-object v1, v0, Lc/d7;->b:Landroid/content/SharedPreferences;

    iget-object v2, v0, Lc/d7;->d:Ljava/lang/String;

    const/4 v7, 0x1

    iget v6, v0, Lc/d7;->a:I

    packed-switch v6, :pswitch_data_0

    invoke-static {v2}, Lc/k6;->n(Ljava/lang/String;)V

    new-instance v6, Lorg/json/JSONTokener;

    invoke-direct {v6, v2}, Lorg/json/JSONTokener;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Lorg/json/JSONTokener;->nextValue()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v6}, Lorg/json/JSONTokener;->nextClean()C

    move-result v6

    if-nez v6, :cond_1e

    instance-of v6, v2, Lorg/json/JSONArray;

    if-eqz v6, :cond_0

    check-cast v2, Lorg/json/JSONArray;

    goto :goto_1

    :cond_0
    instance-of v6, v2, Lorg/json/JSONObject;

    if-eqz v6, :cond_1d

    check-cast v2, Lorg/json/JSONObject;

    const-string v6, "PIDs"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    if-nez v6, :cond_1

    const-string v6, "sensors"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    goto :goto_0

    :cond_1
    move-object v2, v6

    :goto_0
    if-eqz v2, :cond_1c

    :goto_1
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v6

    const/16 v8, 0x100

    if-gt v6, v8, :cond_1b

    new-instance v6, Ljava/util/LinkedHashMap;

    invoke-direct {v6}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {v1, v4}, Lc/k6;->f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;

    move-result-object v8

    const/4 v9, 0x0

    :goto_2
    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v9, v3, :cond_2

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/2addr v9, v7

    move-object/from16 v0, p0

    goto :goto_2

    :cond_2
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    new-instance v8, Ljava/util/HashSet;

    invoke-direct {v8}, Ljava/util/HashSet;-><init>()V

    new-instance v9, Lorg/json/JSONArray;

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    new-instance v7, Ljava/util/HashSet;

    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {v6}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v16

    invoke-interface/range {v16 .. v16}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_3
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    move-object/from16 v22, v13

    const-string v13, "sourceImportId"

    if-eqz v17, :cond_6

    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    move-object/from16 v23, v1

    move-object/from16 v1, v17

    check-cast v1, Lorg/json/JSONObject;

    invoke-virtual {v1, v13, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v17

    if-eqz v17, :cond_3

    :goto_4
    move-object/from16 v13, v22

    move-object/from16 v1, v23

    goto :goto_3

    :cond_3
    invoke-interface {v0, v13}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v17

    if-nez v17, :cond_5

    invoke-virtual {v7, v13}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_4

    goto :goto_5

    :cond_4
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v13, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_5
    :goto_5
    invoke-interface {v0, v13}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v7, v13}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_4

    :cond_6
    move-object/from16 v23, v1

    move-object/from16 v16, v6

    const/4 v1, 0x0

    :goto_6
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v6

    move-object/from16 v24, v10

    const-string v10, "\u041f\u043e\u0432\u0442\u043e\u0440\u043d\u044b\u0439 ID PID"

    if-ge v1, v6, :cond_13

    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    move-object/from16 v17, v2

    new-instance v2, Lorg/json/JSONObject;

    invoke-virtual {v6}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v2, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v5, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v18

    if-nez v18, :cond_7

    invoke-virtual {v3, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_8

    :cond_7
    move-object/from16 v18, v3

    goto :goto_7

    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_7
    const-string v3, "DDID"

    invoke-virtual {v2, v3, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v25, v11

    const-string v11, "user_[a-f0-9]{32}"

    invoke-virtual {v6, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_9

    move-object v3, v6

    goto :goto_8

    :cond_9
    invoke-virtual {v3, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_a

    goto :goto_8

    :cond_a
    move-object v3, v15

    :goto_8
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_c

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_c

    invoke-virtual {v7, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_b

    invoke-virtual {v0, v6, v15}, Ljava/util/LinkedHashMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    goto :goto_9

    :cond_b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_c
    :goto_9
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_f

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_d

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v11

    move-object/from16 v26, v14

    goto :goto_b

    :cond_d
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v26, v14

    if-nez v4, :cond_e

    move-object/from16 v14, v22

    goto :goto_a

    :cond_e
    iget-object v14, v4, Lc/j6;->a:Ljava/lang/String;

    :goto_a
    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, ":carscanner:"

    invoke-virtual {v11, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    sget-object v14, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v11, v14}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v11

    invoke-static {v11}, Ljava/util/UUID;->nameUUIDFromBytes([B)Ljava/util/UUID;

    move-result-object v11

    :goto_b
    invoke-virtual {v11}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v12, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_c

    :cond_f
    move-object/from16 v26, v14

    :goto_c
    invoke-virtual {v8, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_12

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_10

    invoke-interface {v0, v6, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v7, v6}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    :cond_10
    invoke-virtual {v2, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_11

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_11

    invoke-virtual {v2, v13, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_11
    invoke-virtual {v9, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v2, 0x1

    add-int/2addr v1, v2

    move-object/from16 v2, v17

    move-object/from16 v3, v18

    move-object/from16 v10, v24

    move-object/from16 v11, v25

    move-object/from16 v14, v26

    goto/16 :goto_6

    :cond_12
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_13
    move-object/from16 v17, v2

    move-object/from16 v25, v11

    const/4 v1, 0x0

    :goto_d
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v1, v2, :cond_18

    invoke-virtual {v9, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    move-object/from16 v3, v25

    invoke-virtual {v2, v3, v15}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v8, "\\{([^{}]+)\\}|(?i:PID)\\(\\s*([0-9]+)\\s*\\)"

    invoke-static {v8}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v8

    invoke-virtual {v8, v6}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v6

    new-instance v8, Ljava/lang/StringBuffer;

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    :goto_e
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->find()Z

    move-result v11

    if-eqz v11, :cond_17

    const/4 v11, 0x1

    invoke-virtual {v6, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_14

    :goto_f
    invoke-virtual {v6, v11}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v12

    goto :goto_10

    :cond_14
    const/4 v11, 0x2

    goto :goto_f

    :goto_10
    invoke-virtual {v7, v12}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_16

    invoke-virtual {v0, v12}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    if-nez v11, :cond_15

    invoke-virtual {v6}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v11

    move-object/from16 v13, v24

    goto :goto_11

    :cond_15
    new-instance v12, Ljava/lang/StringBuilder;

    move-object/from16 v13, v24

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v11, "}"

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    :goto_11
    invoke-static {v11}, Ljava/util/regex/Matcher;->quoteReplacement(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v8, v11}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    move-object/from16 v24, v13

    goto :goto_e

    :cond_16
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v10}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_17
    move-object/from16 v13, v24

    invoke-virtual {v6, v8}, Ljava/util/regex/Matcher;->appendTail(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    move-object/from16 v8, v16

    invoke-virtual {v8, v6, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    add-int/2addr v1, v2

    move-object/from16 v25, v3

    goto/16 :goto_d

    :cond_18
    move-object/from16 v8, v16

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    const/4 v7, 0x0

    :goto_12
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v2

    if-ge v7, v2, :cond_19

    invoke-virtual {v9, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    add-int/2addr v7, v2

    goto :goto_12

    :cond_19
    invoke-virtual {v8}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_13
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/json/JSONObject;

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_13

    :cond_1a
    move-object/from16 v6, v23

    invoke-static {v6, v4, v0, v1}, Lc/k6;->v0(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONArray;Ljava/util/Set;)V

    invoke-virtual/range {v17 .. v17}, Lorg/json/JSONArray;->length()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :cond_1b
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u041d\u0435\u0442 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0439 PID"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1d
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 JSON PID"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u041b\u0438\u0448\u043d\u0438\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u043f\u043e\u0441\u043b\u0435 JSON"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_0
    move-object v6, v1

    move-object v3, v11

    move-object/from16 v22, v13

    move-object/from16 v26, v14

    move-object v13, v10

    invoke-static {v2}, Lc/k6;->n(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const-string v1, "\ufeff"

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1f

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    :cond_1f
    const-string v1, "["

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_20

    invoke-virtual {v0, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_21

    :cond_20
    move-object v3, v6

    goto/16 :goto_2d

    :cond_21
    const/4 v1, 0x0

    const/4 v2, 0x0

    :goto_14
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v7

    if-ge v1, v7, :cond_23

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v10, 0x1

    if-ne v7, v8, :cond_22

    xor-int/2addr v2, v10

    :cond_22
    if-nez v2, :cond_24

    const/16 v11, 0xa

    if-eq v7, v11, :cond_23

    const/16 v11, 0xd

    if-ne v7, v11, :cond_24

    :cond_23
    const/4 v2, 0x0

    goto :goto_15

    :cond_24
    add-int/2addr v1, v10

    goto :goto_14

    :goto_15
    invoke-virtual {v0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->chars()Ljava/util/stream/IntStream;

    move-result-object v7

    new-instance v10, Lc/e7;

    invoke-direct {v10, v2}, Lc/e7;-><init>(I)V

    invoke-interface {v7, v10}, Ljava/util/stream/IntStream;->filter(Ljava/util/function/IntPredicate;)Ljava/util/stream/IntStream;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/stream/IntStream;->count()J

    move-result-wide v10

    invoke-virtual {v1}, Ljava/lang/String;->chars()Ljava/util/stream/IntStream;

    move-result-object v1

    new-instance v2, Lc/e7;

    const/4 v7, 0x1

    invoke-direct {v2, v7}, Lc/e7;-><init>(I)V

    invoke-interface {v1, v2}, Ljava/util/stream/IntStream;->filter(Ljava/util/function/IntPredicate;)Ljava/util/stream/IntStream;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/stream/IntStream;->count()J

    move-result-wide v1

    cmp-long v1, v10, v1

    if-lez v1, :cond_25

    const/16 v1, 0x2c

    goto :goto_16

    :cond_25
    const/16 v1, 0x3b

    :goto_16
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    :goto_17
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v8

    if-gt v11, v8, :cond_36

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v8

    if-ne v11, v8, :cond_26

    const/16 v8, 0xa

    goto :goto_18

    :cond_26
    invoke-virtual {v0, v11}, Ljava/lang/String;->charAt(I)C

    move-result v8

    :goto_18
    if-eqz v13, :cond_2a

    move/from16 v24, v13

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v13

    if-eq v11, v13, :cond_29

    const/16 v13, 0x22

    if-ne v8, v13, :cond_28

    const/16 v21, 0x1

    add-int/lit8 v8, v11, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v13

    if-ge v8, v13, :cond_27

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v13

    move/from16 v25, v8

    const/16 v8, 0x22

    if-ne v13, v8, :cond_27

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move/from16 v11, v25

    const/16 v13, 0xd

    move/from16 v25, v1

    const/4 v1, 0x1

    goto/16 :goto_1d

    :cond_27
    move/from16 v25, v1

    const/4 v1, 0x1

    const/16 v13, 0xd

    const/4 v14, 0x1

    const/16 v24, 0x0

    goto/16 :goto_1d

    :cond_28
    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_19

    :cond_29
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CSV: \u043d\u0435\u0437\u0430\u043a\u0440\u044b\u0442\u044b\u0435 \u043a\u0430\u0432\u044b\u0447\u043a\u0438"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2a
    move/from16 v24, v13

    if-eq v8, v1, :cond_31

    const/16 v13, 0xd

    if-eq v8, v13, :cond_31

    const/16 v13, 0xa

    if-ne v8, v13, :cond_2b

    goto :goto_1a

    :cond_2b
    const/16 v13, 0x22

    if-ne v8, v13, :cond_2d

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->length()I

    move-result v8

    if-nez v8, :cond_2c

    if-nez v14, :cond_2c

    move/from16 v25, v1

    const/4 v1, 0x1

    const/16 v13, 0xd

    const/16 v24, 0x1

    goto/16 :goto_1d

    :cond_2c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CSV: \u043d\u0435\u0432\u0435\u0440\u043d\u044b\u0435 \u043a\u0430\u0432\u044b\u0447\u043a\u0438"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2d
    if-eqz v14, :cond_2f

    invoke-static {v8}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v8

    if-eqz v8, :cond_2e

    goto :goto_19

    :cond_2e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CSV: \u0434\u0430\u043d\u043d\u044b\u0435 \u043f\u043e\u0441\u043b\u0435 \u043a\u0430\u0432\u044b\u0447\u0435\u043a"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2f
    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->length()I

    move-result v8

    const/16 v13, 0x2000

    if-gt v8, v13, :cond_30

    :goto_19
    move/from16 v25, v1

    const/4 v1, 0x1

    const/16 v13, 0xd

    goto :goto_1d

    :cond_30
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CSV: \u0441\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u043e\u0435 \u043f\u043e\u043b\u0435"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_31
    :goto_1a
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-interface {v7, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v13, 0x0

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->setLength(I)V

    if-eq v8, v1, :cond_35

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v14

    move/from16 v25, v1

    const/4 v1, 0x1

    if-ne v14, v1, :cond_32

    invoke-interface {v7, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_32

    goto :goto_1b

    :cond_32
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v7, 0x101

    if-gt v1, v7, :cond_34

    :goto_1b
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/16 v13, 0xd

    if-ne v8, v13, :cond_33

    const/4 v7, 0x1

    add-int/lit8 v8, v11, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v7

    if-ge v8, v7, :cond_33

    invoke-virtual {v0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/16 v14, 0xa

    if-ne v7, v14, :cond_33

    move v11, v8

    :cond_33
    move-object v7, v1

    :goto_1c
    const/4 v1, 0x1

    const/4 v14, 0x0

    goto :goto_1d

    :cond_34
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, v9}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_35
    move/from16 v25, v1

    const/16 v13, 0xd

    goto :goto_1c

    :goto_1d
    add-int/2addr v11, v1

    move/from16 v13, v24

    move/from16 v1, v25

    goto/16 :goto_17

    :cond_36
    const/16 v13, 0xd

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x2

    if-lt v0, v1, :cond_8a

    const/4 v0, 0x0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x7

    if-lt v1, v7, :cond_8a

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    const/16 v1, 0xa

    if-gt v0, v1, :cond_8a

    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v7, 0x1

    :goto_1e
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_89

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v9

    const/4 v10, 0x7

    if-lt v9, v10, :cond_88

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v9

    if-gt v9, v1, :cond_88

    const/4 v9, 0x2

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    const/16 v31, 0x0

    const/16 v32, 0x2

    const/16 v28, 0x1

    const/16 v29, 0x0

    const-string v30, "0x"

    move-object/from16 v27, v9

    invoke-virtual/range {v27 .. v32}, Ljava/lang/String;->regionMatches(ZILjava/lang/String;II)Z

    move-result v10

    if-eqz v10, :cond_37

    const/4 v10, 0x2

    invoke-virtual {v9, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v9

    :cond_37
    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v10}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x3

    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    const-string v14, " "

    invoke-virtual {v11, v14, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v11

    const-string v14, "IF"

    const-string v1, "if"

    invoke-virtual {v11, v14, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v11, "GetBit"

    invoke-virtual {v1, v11}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_38

    move-object/from16 v24, v2

    move-object/from16 v27, v6

    move/from16 v28, v7

    const/16 v2, 0x2c

    goto/16 :goto_23

    :cond_38
    const/4 v11, 0x0

    :goto_1f
    const/16 v14, 0x3a

    const/16 v10, 0x40

    if-ge v11, v10, :cond_3b

    const/16 v10, 0x7b

    invoke-virtual {v1, v10}, Ljava/lang/String;->indexOf(I)I

    move-result v10

    const/16 v20, -0x1

    if-gez v10, :cond_39

    move/from16 v13, v20

    goto :goto_20

    :cond_39
    invoke-virtual {v1, v14, v10}, Ljava/lang/String;->indexOf(II)I

    move-result v24

    move/from16 v13, v24

    :goto_20
    if-gez v13, :cond_3a

    move/from16 v14, v20

    goto :goto_21

    :cond_3a
    const/16 v14, 0x7d

    invoke-virtual {v1, v14, v13}, Ljava/lang/String;->indexOf(II)I

    move-result v14

    :goto_21
    if-ltz v10, :cond_3b

    if-ltz v13, :cond_3b

    if-gez v14, :cond_3c

    :cond_3b
    move-object/from16 v24, v2

    move-object/from16 v27, v6

    move/from16 v28, v7

    goto :goto_22

    :cond_3c
    move-object/from16 v24, v2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v27, v6

    move/from16 v28, v7

    const/4 v6, 0x0

    invoke-virtual {v1, v6, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "GetBit("

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    add-int/2addr v10, v6

    invoke-virtual {v1, v10, v13}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ","

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/2addr v13, v6

    invoke-virtual {v1, v13, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ")"

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/2addr v14, v6

    invoke-virtual {v1, v14}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    add-int/2addr v11, v6

    move-object/from16 v2, v24

    move-object/from16 v6, v27

    move/from16 v7, v28

    const/4 v10, 0x3

    const/16 v13, 0xd

    goto :goto_1f

    :goto_22
    const-string v2, "signed"

    const-string v6, "SIGNED"

    invoke-virtual {v1, v2, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "&"

    const-string v6, "@&"

    invoke-virtual {v1, v2, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "<"

    const-string v6, "@<<"

    invoke-virtual {v1, v2, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, ">"

    const-string v6, "@>>"

    invoke-virtual {v1, v2, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "^"

    const-string v6, "@^"

    invoke-virtual {v1, v2, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x2c

    const/16 v6, 0x3a

    invoke-virtual {v1, v6, v2}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v1

    :goto_23
    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v6

    const/4 v7, 0x7

    if-le v6, v7, :cond_3d

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v6, v10}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    :goto_24
    const/4 v10, 0x0

    goto :goto_25

    :cond_3d
    move-object v6, v15

    goto :goto_24

    :goto_25
    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/4 v10, 0x1

    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v4, :cond_3e

    move-object/from16 v14, v22

    goto :goto_26

    :cond_3e
    iget-object v14, v4, Lc/j6;->a:Ljava/lang/String;

    :goto_26
    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, ":torque:"

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, "\u0000"

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    new-instance v14, Lorg/json/JSONObject;

    invoke-direct {v14}, Lorg/json/JSONObject;-><init>()V

    new-instance v2, Ljava/lang/StringBuilder;

    move-object/from16 v7, v26

    invoke-direct {v2, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v7, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v10, v7}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v7

    invoke-static {v7}, Ljava/util/UUID;->nameUUIDFromBytes([B)Ljava/util/UUID;

    move-result-object v7

    invoke-virtual {v7}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v12, v15}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v14, v5, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v7, "NM"

    invoke-virtual {v2, v7, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v7, "SNM"

    invoke-virtual {v2, v7, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v7, "CMD"

    invoke-virtual {v2, v7, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v2, 0x4

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-wide/16 v9, 0x0

    invoke-static {v2, v9, v10}, Lc/k6;->x(Ljava/lang/String;D)D

    move-result-wide v9

    const-string v2, "MIN"

    invoke-virtual {v1, v2, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v2, 0x5

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-wide/high16 v9, 0x4059000000000000L    # 100.0

    invoke-static {v2, v9, v10}, Lc/k6;->x(Ljava/lang/String;D)D

    move-result-wide v9

    const-string v2, "MAX"

    invoke-virtual {v1, v2, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v2, 0x6

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v10}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x8

    const/4 v13, -0x1

    invoke-virtual {v9}, Ljava/lang/String;->hashCode()I

    move-result v14

    sparse-switch v14, :sswitch_data_0

    goto/16 :goto_28

    :sswitch_0
    const-string v14, "\u043e\u0431/\u043c\u0438\u043d"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_3f

    goto/16 :goto_28

    :cond_3f
    const/16 v9, 0x44

    goto/16 :goto_27

    :sswitch_1
    const-string v14, "\u043a\u043c/\u0447\u0430\u0441"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_40

    goto/16 :goto_28

    :cond_40
    const/16 v9, 0x43

    goto/16 :goto_27

    :sswitch_2
    const-string v14, "\u0433\u0440\u0430\u0434 \u0441"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_41

    goto/16 :goto_28

    :cond_41
    const/16 v9, 0x42

    goto/16 :goto_27

    :sswitch_3
    const-string v14, "degrees"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_42

    goto/16 :goto_28

    :cond_42
    const/16 v9, 0x41

    goto/16 :goto_27

    :sswitch_4
    const-string v14, "\u0433\u0440\u0430\u043c\u043c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_43

    goto/16 :goto_28

    :cond_43
    const/16 v13, 0x40

    goto/16 :goto_28

    :sswitch_5
    const-string v14, "mg/strk"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_44

    goto/16 :goto_28

    :cond_44
    const/16 v9, 0x3f

    goto/16 :goto_27

    :sswitch_6
    const-string v14, "volts"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_45

    goto/16 :goto_28

    :cond_45
    const/16 v9, 0x3e

    goto/16 :goto_27

    :sswitch_7
    const-string v14, "mg/cp"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_46

    goto/16 :goto_28

    :cond_46
    const/16 v9, 0x3d

    goto/16 :goto_27

    :sswitch_8
    const-string v14, "litre"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_47

    goto/16 :goto_28

    :cond_47
    const/16 v9, 0x3c

    goto/16 :goto_27

    :sswitch_9
    const-string v14, "grads"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_48

    goto/16 :goto_28

    :cond_48
    const/16 v13, 0x3b

    goto/16 :goto_28

    :sswitch_a
    const-string v14, "deg c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_49

    goto/16 :goto_28

    :cond_49
    const/16 v9, 0x3a

    goto/16 :goto_27

    :sswitch_b
    const-string v14, "\u043c\u0431\u0430\u0440"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4a

    goto/16 :goto_28

    :cond_4a
    const/16 v9, 0x39

    goto/16 :goto_27

    :sswitch_c
    const-string v14, "\u043b\u0438\u0442\u0440"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4b

    goto/16 :goto_28

    :cond_4b
    const/16 v9, 0x38

    goto/16 :goto_27

    :sswitch_d
    const-string v14, "\u0434\u0435\u043d\u044c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4c

    goto/16 :goto_28

    :cond_4c
    const/16 v9, 0x37

    goto/16 :goto_27

    :sswitch_e
    const-string v14, "\u043c/\u0441?"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4d

    goto/16 :goto_28

    :cond_4d
    const/16 v9, 0x36

    goto/16 :goto_27

    :sswitch_f
    const-string v14, "\u043c3/\u0447"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4e

    goto/16 :goto_28

    :cond_4e
    const/16 v9, 0x35

    goto/16 :goto_27

    :sswitch_10
    const-string v14, "\u00b0crk"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4f

    goto/16 :goto_28

    :cond_4f
    const/16 v9, 0x34

    goto/16 :goto_27

    :sswitch_11
    const-string v14, "watt"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_50

    goto/16 :goto_28

    :cond_50
    const/16 v9, 0x33

    goto/16 :goto_27

    :sswitch_12
    const-string v14, "volt"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_51

    goto/16 :goto_28

    :cond_51
    const/16 v9, 0x32

    goto/16 :goto_27

    :sswitch_13
    const-string v14, "revs"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_52

    goto/16 :goto_28

    :cond_52
    const/16 v9, 0x31

    goto/16 :goto_27

    :sswitch_14
    const-string v14, "mohm"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_53

    goto/16 :goto_28

    :cond_53
    const/16 v9, 0x30

    goto/16 :goto_27

    :sswitch_15
    const-string v14, "mm^3"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_54

    goto/16 :goto_28

    :cond_54
    const/16 v9, 0x2f

    goto/16 :goto_27

    :sswitch_16
    const-string v14, "mbar"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_55

    goto/16 :goto_28

    :cond_55
    const/16 v9, 0x2e

    goto/16 :goto_27

    :sswitch_17
    const-string v14, "m3/h"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_56

    goto/16 :goto_28

    :cond_56
    const/16 v9, 0x2d

    goto/16 :goto_27

    :sswitch_18
    const-string v14, "m/s2"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_57

    goto/16 :goto_28

    :cond_57
    const/16 v13, 0x2c

    goto/16 :goto_28

    :sswitch_19
    const-string v14, "kg/h"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_58

    goto/16 :goto_28

    :cond_58
    const/16 v9, 0x2b

    goto/16 :goto_27

    :sswitch_1a
    const-string v14, "\u0447\u0430\u0441"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_59

    goto/16 :goto_28

    :cond_59
    const/16 v9, 0x2a

    goto/16 :goto_27

    :sswitch_1b
    const-string v14, "\u043c\u043a\u0441"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5a

    goto/16 :goto_28

    :cond_5a
    const/16 v9, 0x29

    goto/16 :goto_27

    :sswitch_1c
    const-string v14, "\u043c\u0438\u043d"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5b

    goto/16 :goto_28

    :cond_5b
    const/16 v9, 0x28

    goto/16 :goto_27

    :sswitch_1d
    const-string v14, "\u0432\u00b0c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5c

    goto/16 :goto_28

    :cond_5c
    const/16 v9, 0x27

    goto/16 :goto_27

    :sswitch_1e
    const-string v14, "\u00b0/s"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5d

    goto/16 :goto_28

    :cond_5d
    const/16 v9, 0x26

    goto/16 :goto_27

    :sswitch_1f
    const-string v14, "n-m"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5e

    goto/16 :goto_28

    :cond_5e
    const/16 v9, 0x25

    goto/16 :goto_27

    :sswitch_20
    const-string v14, "kwh"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_5f

    goto/16 :goto_28

    :cond_5f
    const/16 v9, 0x24

    goto/16 :goto_27

    :sswitch_21
    const-string v14, "hpa"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_60

    goto/16 :goto_28

    :cond_60
    const/16 v9, 0x23

    goto/16 :goto_27

    :sswitch_22
    const-string v14, "g/s"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_61

    goto/16 :goto_28

    :cond_61
    const/16 v13, 0x22

    goto/16 :goto_28

    :sswitch_23
    const-string v14, "g/l"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_62

    goto/16 :goto_28

    :cond_62
    const/16 v9, 0x21

    goto/16 :goto_27

    :sswitch_24
    const-string v14, "deg"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_63

    goto/16 :goto_28

    :cond_63
    const/16 v9, 0x20

    goto/16 :goto_27

    :sswitch_25
    const-string v14, "bar"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_64

    goto/16 :goto_28

    :cond_64
    const/16 v9, 0x1f

    goto/16 :goto_27

    :sswitch_26
    const-string v14, "*/\u0441"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_65

    goto/16 :goto_28

    :cond_65
    const/16 v9, 0x1e

    goto/16 :goto_27

    :sswitch_27
    const-string v14, "\u043e\u043c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_66

    goto/16 :goto_28

    :cond_66
    const/16 v9, 0x1d

    goto/16 :goto_27

    :sswitch_28
    const-string v14, "\u043c\u043c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_67

    goto/16 :goto_28

    :cond_67
    const/16 v9, 0x1c

    goto/16 :goto_27

    :sswitch_29
    const-string v14, "\u043b."

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_68

    goto/16 :goto_28

    :cond_68
    const/16 v9, 0x1b

    goto/16 :goto_27

    :sswitch_2a
    const-string v14, "\u00b5s"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_69

    goto/16 :goto_28

    :cond_69
    const/16 v9, 0x1a

    goto/16 :goto_27

    :sswitch_2b
    const-string v14, "\u00b0f"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6a

    goto/16 :goto_28

    :cond_6a
    const/16 v9, 0x19

    goto/16 :goto_27

    :sswitch_2c
    const-string v14, "\u00b0c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6b

    goto/16 :goto_28

    :cond_6b
    const/16 v9, 0x18

    goto/16 :goto_27

    :sswitch_2d
    const-string v14, "wh"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6c

    goto/16 :goto_28

    :cond_6c
    const/16 v9, 0x17

    goto/16 :goto_27

    :sswitch_2e
    const-string v14, "nm"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6d

    goto/16 :goto_28

    :cond_6d
    const/16 v9, 0x16

    goto/16 :goto_27

    :sswitch_2f
    const-string v14, "mv"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6e

    goto/16 :goto_28

    :cond_6e
    const/16 v9, 0x15

    goto/16 :goto_27

    :sswitch_30
    const-string v14, "km"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_6f

    goto/16 :goto_28

    :cond_6f
    const/16 v9, 0x14

    goto/16 :goto_27

    :sswitch_31
    const-string v14, "d\u00b0"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_70

    goto/16 :goto_28

    :cond_70
    const/16 v9, 0x13

    goto/16 :goto_27

    :sswitch_32
    const-string v14, "d*"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_71

    goto/16 :goto_28

    :cond_71
    const/16 v9, 0x12

    goto/16 :goto_27

    :sswitch_33
    const-string v14, "*v"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_72

    goto/16 :goto_28

    :cond_72
    const/16 v9, 0x11

    goto/16 :goto_27

    :sswitch_34
    const-string v14, "*c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_73

    goto/16 :goto_28

    :cond_73
    const/16 v9, 0x10

    goto/16 :goto_27

    :sswitch_35
    const-string v14, "\u0430"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_74

    goto/16 :goto_28

    :cond_74
    const/16 v9, 0xf

    goto/16 :goto_27

    :sswitch_36
    const-string v14, "\u00b0"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_75

    goto/16 :goto_28

    :cond_75
    const/16 v9, 0xe

    goto/16 :goto_27

    :sswitch_37
    const-string v14, "w"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_76

    goto/16 :goto_28

    :cond_76
    const/16 v13, 0xd

    goto/16 :goto_28

    :sswitch_38
    const-string v14, "v"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_77

    goto/16 :goto_28

    :cond_77
    const/16 v9, 0xc

    goto/16 :goto_27

    :sswitch_39
    const-string v14, "s"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_78

    goto/16 :goto_28

    :cond_78
    const/16 v9, 0xb

    goto :goto_27

    :sswitch_3a
    const-string v14, "f"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_79

    goto/16 :goto_28

    :cond_79
    const/16 v13, 0xa

    goto/16 :goto_28

    :sswitch_3b
    const-string v14, "c"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7a

    goto/16 :goto_28

    :cond_7a
    const/16 v9, 0x9

    goto :goto_27

    :sswitch_3c
    const-string v14, "a"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7b

    goto/16 :goto_28

    :cond_7b
    const/16 v9, 0x8

    goto :goto_27

    :sswitch_3d
    const-string v14, "?"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7c

    goto :goto_28

    :cond_7c
    const/4 v13, 0x7

    goto :goto_28

    :sswitch_3e
    const-string v14, "%"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7d

    goto :goto_28

    :cond_7d
    const/4 v9, 0x6

    goto :goto_27

    :sswitch_3f
    invoke-virtual {v9, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7e

    goto :goto_28

    :cond_7e
    const/4 v9, 0x5

    goto :goto_27

    :sswitch_40
    const-string v14, "degrees/s"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7f

    goto :goto_28

    :cond_7f
    const/4 v9, 0x4

    :goto_27
    move v13, v9

    goto :goto_28

    :sswitch_41
    const-string v14, "mg/hub"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_80

    goto :goto_28

    :cond_80
    const/4 v13, 0x3

    goto :goto_28

    :sswitch_42
    const-string v14, "mg/cyc"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_81

    goto :goto_28

    :cond_81
    const/4 v13, 0x2

    goto :goto_28

    :sswitch_43
    const-string v14, "gm/sec"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_82

    goto :goto_28

    :cond_82
    const/4 v13, 0x1

    goto :goto_28

    :sswitch_44
    const-string v14, "degree"

    invoke-virtual {v9, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_83

    goto :goto_28

    :cond_83
    const/4 v13, 0x0

    :goto_28
    packed-switch v13, :pswitch_data_1

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v10}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x0

    :goto_29
    if-ltz v9, :cond_85

    const/16 v10, 0x70

    if-ge v9, v10, :cond_85

    invoke-static {v9}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    sget-object v13, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v10, v13}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_84

    move v7, v9

    goto/16 :goto_2a

    :cond_84
    const/4 v10, 0x1

    add-int/2addr v9, v10

    goto :goto_29

    :cond_85
    :pswitch_1
    const/4 v7, 0x0

    goto/16 :goto_2a

    :pswitch_2
    move v7, v2

    goto/16 :goto_2a

    :pswitch_3
    const/4 v7, 0x1

    goto/16 :goto_2a

    :pswitch_4
    const/16 v7, 0x26

    goto/16 :goto_2a

    :pswitch_5
    const/16 v7, 0x39

    goto/16 :goto_2a

    :pswitch_6
    const/16 v7, 0x46

    goto/16 :goto_2a

    :pswitch_7
    const/16 v7, 0x1c

    goto/16 :goto_2a

    :pswitch_8
    const/16 v7, 0x43

    goto/16 :goto_2a

    :pswitch_9
    const/16 v7, 0x34

    goto/16 :goto_2a

    :pswitch_a
    const/16 v7, 0x37

    goto/16 :goto_2a

    :pswitch_b
    const/16 v7, 0x2b

    goto/16 :goto_2a

    :pswitch_c
    const/16 v7, 0x21

    goto/16 :goto_2a

    :pswitch_d
    const/16 v7, 0x36

    goto :goto_2a

    :pswitch_e
    const/16 v7, 0x12

    goto :goto_2a

    :pswitch_f
    const/16 v7, 0x3c

    goto :goto_2a

    :pswitch_10
    const/16 v7, 0x45

    goto :goto_2a

    :pswitch_11
    const/16 v7, 0x41

    goto :goto_2a

    :pswitch_12
    const/16 v7, 0x30

    goto :goto_2a

    :pswitch_13
    const/16 v7, 0x1a

    goto :goto_2a

    :pswitch_14
    const/16 v7, 0x24

    goto :goto_2a

    :pswitch_15
    const/16 v7, 0x18

    goto :goto_2a

    :pswitch_16
    const/16 v7, 0x33

    goto :goto_2a

    :pswitch_17
    const/16 v7, 0x3d

    goto :goto_2a

    :pswitch_18
    const/16 v7, 0xd

    goto :goto_2a

    :pswitch_19
    const/16 v7, 0x31

    goto :goto_2a

    :pswitch_1a
    const/4 v7, 0x3

    goto :goto_2a

    :pswitch_1b
    const/16 v7, 0x35

    goto :goto_2a

    :pswitch_1c
    const/16 v7, 0xa

    goto :goto_2a

    :pswitch_1d
    const/16 v7, 0x11

    goto :goto_2a

    :pswitch_1e
    const/16 v7, 0x10

    goto :goto_2a

    :pswitch_1f
    const/16 v7, 0xf

    goto :goto_2a

    :pswitch_20
    const/16 v7, 0x3b

    goto :goto_2a

    :pswitch_21
    const/16 v7, 0xe

    goto :goto_2a

    :pswitch_22
    const/16 v7, 0x47

    goto :goto_2a

    :pswitch_23
    const/16 v7, 0x44

    goto :goto_2a

    :pswitch_24
    const/16 v7, 0x38

    goto :goto_2a

    :pswitch_25
    move v7, v11

    goto :goto_2a

    :pswitch_26
    const/4 v7, 0x7

    :goto_2a
    const-string v9, "UN"

    invoke-virtual {v1, v9, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v7, "HDR"

    invoke-virtual {v1, v7, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v6

    if-le v6, v11, :cond_86

    invoke-interface {v8, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    goto :goto_2b

    :cond_86
    move-object v6, v15

    :goto_2b
    const-string v7, "BCM"

    invoke-virtual {v1, v7, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v6

    const/16 v7, 0x9

    if-le v6, v7, :cond_87

    invoke-interface {v8, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    goto :goto_2c

    :cond_87
    move-object v6, v15

    :goto_2c
    const-string v7, "ACM"

    invoke-virtual {v1, v7, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "TP"

    const/4 v7, 0x0

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "SBI"

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "DL"

    const/4 v9, 0x1

    invoke-virtual {v1, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "MUL"

    invoke-virtual {v1, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "DIV"

    invoke-virtual {v1, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "OFS"

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "RL"

    invoke-virtual {v1, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "VIS"

    invoke-virtual {v1, v6, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    const-string v6, "sourceUnitText"

    invoke-interface {v8, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v6, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/lit8 v1, v28, 0x1

    move v7, v1

    move-object/from16 v2, v24

    move-object/from16 v6, v27

    const/16 v1, 0xa

    const/16 v13, 0xd

    goto/16 :goto_1e

    :cond_88
    move/from16 v28, v7

    const/4 v9, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "CSV: \u043d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e \u0441\u0442\u043e\u043b\u0431\u0446\u043e\u0432 \u0432 \u0441\u0442\u0440\u043e\u043a\u0435 "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int/lit8 v7, v28, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_89
    move-object/from16 v27, v6

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lc/d7;

    move-object/from16 v3, v27

    const/4 v2, 0x2

    invoke-direct {v1, v3, v4, v0, v2}, Lc/d7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Ljava/lang/String;I)V

    invoke-static {v1}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    goto :goto_2e

    :cond_8a
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CSV: \u0442\u0440\u0435\u0431\u0443\u0435\u0442\u0441\u044f \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043e\u043a \u0438 7\u201310 \u0441\u0442\u043e\u043b\u0431\u0446\u043e\u0432"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_2d
    new-instance v1, Lc/d7;

    const/4 v2, 0x2

    invoke-direct {v1, v3, v4, v0, v2}, Lc/d7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Ljava/lang/String;I)V

    invoke-static {v1}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    :goto_2e
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    :pswitch_27
    move-object v3, v1

    const/4 v7, 0x0

    invoke-static {v2}, Lc/k6;->q0(Ljava/lang/String;)V

    invoke-static {v3, v4}, Lc/k6;->f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;

    move-result-object v0

    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    const/4 v6, 0x0

    move-object v8, v6

    :goto_2f
    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-ge v7, v9, :cond_8c

    invoke-virtual {v0, v7}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v9

    invoke-virtual {v9, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8b

    move-object v8, v9

    :goto_30
    const/4 v9, 0x1

    goto :goto_31

    :cond_8b
    invoke-virtual {v1, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_30

    :goto_31
    add-int/2addr v7, v9

    goto :goto_2f

    :cond_8c
    if-nez v8, :cond_8d

    goto :goto_34

    :cond_8d
    if-nez v4, :cond_8e

    invoke-static {}, Lc/k6;->j()Lc/j6;

    move-result-object v5

    goto :goto_32

    :cond_8e
    move-object v5, v4

    :goto_32
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v7

    invoke-virtual {v5, v0, v7}, Lc/j6;->f(Lorg/json/JSONArray;Ljava/util/Map;)Lc/j6;

    move-result-object v0

    iget-object v5, v0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_8f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_92

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/i6;

    iget-object v8, v7, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v8, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_8f

    iget-object v8, v7, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_90
    :goto_33
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_8f

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v0, v9}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v9

    if-eqz v9, :cond_90

    iget-object v9, v9, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_91

    goto :goto_33

    :cond_91
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "PID \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u0432 \u0444\u043e\u0440\u043c\u0443\u043b\u0435: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v7, Lc/i6;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_92
    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v0

    invoke-static {v3, v4, v1, v0}, Lc/k6;->v0(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONArray;Ljava/util/Set;)V

    :goto_34
    return-object v6

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_27
        :pswitch_0
    .end packed-switch

    :sswitch_data_0
    .sparse-switch
        -0x4f9b9134 -> :sswitch_44
        -0x4a25bc58 -> :sswitch_43
        -0x403d6f48 -> :sswitch_42
        -0x403d5d00 -> :sswitch_41
        -0x884bc75 -> :sswitch_40
        0x0 -> :sswitch_3f
        0x25 -> :sswitch_3e
        0x3f -> :sswitch_3d
        0x61 -> :sswitch_3c
        0x63 -> :sswitch_3b
        0x66 -> :sswitch_3a
        0x73 -> :sswitch_39
        0x76 -> :sswitch_38
        0x77 -> :sswitch_37
        0xb0 -> :sswitch_36
        0x430 -> :sswitch_35
        0x579 -> :sswitch_34
        0x58c -> :sswitch_33
        0xc46 -> :sswitch_32
        0xccc -> :sswitch_31
        0xd62 -> :sswitch_30
        0xda9 -> :sswitch_2f
        0xdbf -> :sswitch_2e
        0xed1 -> :sswitch_2d
        0x15b3 -> :sswitch_2c
        0x15b6 -> :sswitch_2b
        0x165e -> :sswitch_2a
        0x8353 -> :sswitch_29
        0x8780 -> :sswitch_28
        0x87be -> :sswitch_27
        0xa79c -> :sswitch_26
        0x17c13 -> :sswitch_25
        0x18406 -> :sswitch_24
        0x188c4 -> :sswitch_23
        0x188cb -> :sswitch_22
        0x19459 -> :sswitch_21
        0x1a07c -> :sswitch_20
        0x1a2ce -> :sswitch_1f
        0x29ad4 -> :sswitch_1e
        0xfd565 -> :sswitch_1d
        0x106c41 -> :sswitch_1c
        0x106c83 -> :sswitch_1b
        0x109498 -> :sswitch_1a
        0x322c75 -> :sswitch_19
        0x324b01 -> :sswitch_18
        0x3251ff -> :sswitch_17
        0x330886 -> :sswitch_16
        0x333135 -> :sswitch_15
        0x333a27 -> :sswitch_14
        0x355c30 -> :sswitch_13
        0x375201 -> :sswitch_12
        0x3792ca -> :sswitch_11
        0x51832c -> :sswitch_10
        0x1ed8baf -> :sswitch_f
        0x1edf6d1 -> :sswitch_e
        0x1f971f0 -> :sswitch_d
        0x1fcac5b -> :sswitch_c
        0x1fd0445 -> :sswitch_b
        0x5b09ec9 -> :sswitch_a
        0x5e0bfe5 -> :sswitch_9
        0x623670a -> :sswitch_8
        0x62f9102 -> :sswitch_7
        0x6b2ee92 -> :sswitch_6
        0x3896bbaf -> :sswitch_5
        0x3d2b8623 -> :sswitch_4
        0x5c296b27 -> :sswitch_3
        0x6844a512 -> :sswitch_2
        0x722d084b -> :sswitch_1
        0x78653fe5 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_1
        :pswitch_21
        :pswitch_1
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_26
        :pswitch_20
        :pswitch_1f
        :pswitch_26
        :pswitch_26
        :pswitch_26
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_1f
        :pswitch_1e
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_26
        :pswitch_12
        :pswitch_26
        :pswitch_11
        :pswitch_25
        :pswitch_10
        :pswitch_f
        :pswitch_18
        :pswitch_22
        :pswitch_1f
        :pswitch_e
        :pswitch_16
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_1c
        :pswitch_1b
        :pswitch_26
        :pswitch_a
        :pswitch_b
        :pswitch_5
        :pswitch_15
        :pswitch_9
        :pswitch_1f
        :pswitch_26
        :pswitch_15
        :pswitch_24
        :pswitch_1c
        :pswitch_23
        :pswitch_4
        :pswitch_26
        :pswitch_1f
        :pswitch_3
        :pswitch_2
    .end packed-switch
.end method
