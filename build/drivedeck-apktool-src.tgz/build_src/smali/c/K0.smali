.class public final synthetic Lc/K0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:[Z

.field public final synthetic b:Lc/F0;

.field public final synthetic c:Lc/T5;

.field public final synthetic d:Lc/j6;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lc/n1;

.field public final synthetic g:Ljava/util/function/BooleanSupplier;

.field public final synthetic h:Landroid/widget/Switch;

.field public final synthetic i:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>([ZLc/F0;Lc/T5;Lc/j6;Ljava/lang/String;Lc/n1;Ljava/util/function/BooleanSupplier;Landroid/widget/Switch;Landroid/widget/TextView;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K0;->a:[Z

    iput-object p2, p0, Lc/K0;->b:Lc/F0;

    iput-object p3, p0, Lc/K0;->c:Lc/T5;

    iput-object p4, p0, Lc/K0;->d:Lc/j6;

    iput-object p5, p0, Lc/K0;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/K0;->f:Lc/n1;

    iput-object p7, p0, Lc/K0;->g:Ljava/util/function/BooleanSupplier;

    iput-object p8, p0, Lc/K0;->h:Landroid/widget/Switch;

    iput-object p9, p0, Lc/K0;->i:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 9

    iget-object p1, p0, Lc/K0;->a:[Z

    const/4 v0, 0x0

    aget-boolean v1, p1, v0

    if-eqz v1, :cond_0

    goto/16 :goto_7

    :cond_0
    const/4 v1, 0x1

    iget-object v2, p0, Lc/K0;->b:Lc/F0;

    iget-object v3, p0, Lc/K0;->c:Lc/T5;

    if-nez v2, :cond_2

    iget-object v4, v3, Lc/T5;->g:Lc/j6;

    iget-object v5, p0, Lc/K0;->d:Lc/j6;

    if-ne v4, v5, :cond_1

    goto :goto_0

    :cond_1
    move v4, v0

    goto :goto_1

    :cond_2
    :goto_0
    move v4, v1

    :goto_1
    if-eqz v4, :cond_8

    iget-object v4, p0, Lc/K0;->e:Ljava/lang/String;

    iget-object v5, p0, Lc/K0;->f:Lc/n1;

    const/4 v6, 0x7

    if-nez v2, :cond_3

    invoke-virtual {v4, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, p2, v7}, Lc/T5;->c1(ZLjava/lang/String;)V

    goto :goto_3

    :cond_3
    invoke-virtual {v5}, Lc/n1;->z()I

    move-result v7

    invoke-virtual {v2}, Lc/F0;->a()I

    move-result v8

    if-eqz p2, :cond_4

    or-int/2addr v7, v8

    goto :goto_2

    :cond_4
    not-int v8, v8

    and-int/2addr v7, v8

    :goto_2
    invoke-virtual {v5, v7}, Lc/n1;->N0(I)V

    :goto_3
    iget-object v7, p0, Lc/K0;->g:Ljava/util/function/BooleanSupplier;

    invoke-interface {v7}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result v7

    if-nez v7, :cond_7

    if-nez v2, :cond_5

    invoke-virtual {v4, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    xor-int/lit8 v4, p2, 0x1

    invoke-virtual {v3, v4, v2}, Lc/T5;->c1(ZLjava/lang/String;)V

    goto :goto_5

    :cond_5
    invoke-virtual {v5}, Lc/n1;->z()I

    move-result v3

    invoke-virtual {v2}, Lc/F0;->a()I

    move-result v2

    if-eqz p2, :cond_6

    not-int v2, v2

    and-int/2addr v2, v3

    goto :goto_4

    :cond_6
    or-int/2addr v2, v3

    :goto_4
    invoke-virtual {v5, v2}, Lc/n1;->N0(I)V

    :cond_7
    :goto_5
    move v4, v7

    :cond_8
    iget-object v2, p0, Lc/K0;->h:Landroid/widget/Switch;

    if-nez v4, :cond_9

    aput-boolean v1, p1, v0

    xor-int/2addr p2, v1

    invoke-virtual {v2, p2}, Landroid/widget/Switch;->setChecked(Z)V

    aput-boolean v0, p1, v0

    :cond_9
    invoke-virtual {v2}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    iget-object p2, p0, Lc/K0;->i:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v2}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    if-eqz p1, :cond_a

    const/high16 p1, 0x3f800000    # 1.0f

    goto :goto_6

    :cond_a
    const p1, 0x3ecccccd    # 0.4f

    :goto_6
    invoke-virtual {p2, p1}, Landroid/view/View;->setAlpha(F)V

    :goto_7
    return-void
.end method
