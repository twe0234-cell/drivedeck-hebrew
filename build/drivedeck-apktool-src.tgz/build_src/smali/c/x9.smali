.class public final Lc/x9;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/o9;

.field public final b:J

.field public final c:Z


# direct methods
.method public constructor <init>(Lc/o9;JZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/x9;->a:Lc/o9;

    iput-wide p2, p0, Lc/x9;->b:J

    iput-boolean p4, p0, Lc/x9;->c:Z

    return-void
.end method
