.class public final synthetic Lc/k4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/LauncherAccessibilityService;

.field public final synthetic c:J

.field public final synthetic d:Ljava/util/ArrayList;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLjava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0

    iput p7, p0, Lc/k4;->a:I

    iput-object p1, p0, Lc/k4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iput-wide p2, p0, Lc/k4;->c:J

    iput-object p4, p0, Lc/k4;->d:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    const-wide/16 v0, 0xfa

    iget-object v2, p0, Lc/k4;->d:Ljava/util/ArrayList;

    iget-wide v3, p0, Lc/k4;->c:J

    iget-object v5, p0, Lc/k4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget v6, p0, Lc/k4;->a:I

    packed-switch v6, :pswitch_data_0

    sget-object v6, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5, v3, v4}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v6

    if-nez v6, :cond_0

    goto :goto_0

    :cond_0
    iget-object v6, v5, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    invoke-virtual {v6, v2}, Lc/S1;->e(Ljava/util/ArrayList;)V

    iget-object v2, v5, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v6, Lc/m4;

    const/4 v7, 0x1

    invoke-direct {v6, v5, v3, v4, v7}, Lc/m4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JI)V

    invoke-virtual {v2, v6, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_0
    return-void

    :pswitch_0
    sget-object v6, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v5, v3, v4}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v6

    if-nez v6, :cond_1

    goto :goto_1

    :cond_1
    iget-object v6, v5, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    invoke-virtual {v6, v2}, Lc/S1;->e(Ljava/util/ArrayList;)V

    iget-object v2, v5, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v6, Lc/m4;

    const/4 v7, 0x0

    invoke-direct {v6, v5, v3, v4, v7}, Lc/m4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JI)V

    invoke-virtual {v2, v6, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
