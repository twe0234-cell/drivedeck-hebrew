.class public final Lc/e0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Lc/n1;

.field public final c:Landroid/appwidget/AppWidgetManager;

.field public final d:Lc/b0;

.field public final e:Lc/c0;

.field public final f:Landroid/widget/FrameLayout;

.field public final g:Ljava/util/HashMap;

.field public final h:Ljava/util/HashMap;

.field public i:Z

.field public j:Z

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Ljava/util/List;

.field public p:I

.field public q:I


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/n1;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lc/e0;->g:Ljava/util/HashMap;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lc/e0;->h:Ljava/util/HashMap;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lc/e0;->o:Ljava/util/List;

    const/4 v0, -0x1

    iput v0, p0, Lc/e0;->p:I

    iput v0, p0, Lc/e0;->q:I

    iput-object p1, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/e0;->b:Lc/n1;

    invoke-static {p1}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    move-result-object p2

    iput-object p2, p0, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    new-instance p2, Lc/b0;

    invoke-direct {p2, p0, p1, p1}, Lc/b0;-><init>(Lc/e0;Landroid/app/Activity;Lru/drivedeck/launcher/MainActivity;)V

    iput-object p2, p0, Lc/e0;->d:Lc/b0;

    new-instance p2, Landroid/widget/FrameLayout;

    invoke-direct {p2, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, Lc/e0;->f:Landroid/widget/FrameLayout;

    new-instance v1, Lc/c0;

    const/4 v2, 0x0

    invoke-direct {v1, p0, p1, v2}, Lc/c0;-><init>(Ljava/lang/Object;Landroid/app/Activity;I)V

    iput-object v1, p0, Lc/e0;->e:Lc/c0;

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, p2, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static a(Landroid/widget/FrameLayout;Landroid/graphics/Rect;)V
    .locals 3

    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p1}, Landroid/graphics/Rect;->width()I

    move-result v1

    invoke-virtual {p1}, Landroid/graphics/Rect;->height()I

    move-result v2

    invoke-direct {v0, v1, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    iget v1, p1, Landroid/graphics/Rect;->left:I

    iput v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iget p1, p1, Landroid/graphics/Rect;->top:I

    iput p1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    invoke-virtual {p0, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static b(Landroid/widget/FrameLayout;)Landroid/graphics/Rect;
    .locals 4

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroid/widget/FrameLayout$LayoutParams;

    new-instance v0, Landroid/graphics/Rect;

    iget v1, p0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iget v2, p0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    iget v3, p0, Landroid/widget/FrameLayout$LayoutParams;->width:I

    add-int/2addr v3, v1

    iget p0, p0, Landroid/widget/FrameLayout$LayoutParams;->height:I

    add-int/2addr p0, v2

    invoke-direct {v0, v1, v2, v3, p0}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object v0
.end method

.method public static k(Landroid/appwidget/AppWidgetProviderInfo;)I
    .locals 1

    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->resizeMode:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->minResizeHeight:I

    if-lez v0, :cond_0

    goto :goto_0

    :cond_0
    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->minHeight:I

    :goto_0
    return v0
.end method

.method public static l(Landroid/appwidget/AppWidgetProviderInfo;)I
    .locals 1

    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->resizeMode:I

    and-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_0

    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->minResizeWidth:I

    if-lez v0, :cond_0

    goto :goto_0

    :cond_0
    iget v0, p0, Landroid/appwidget/AppWidgetProviderInfo;->minWidth:I

    :goto_0
    return v0
.end method

.method public static o(Landroid/content/Context;Lc/n1;)Landroid/graphics/Rect;
    .locals 11

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    invoke-static {p0}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    move-result-object p0

    invoke-virtual {p1}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-virtual {p1, v5}, Lc/n1;->n(I)Landroid/graphics/Rect;

    move-result-object v6

    :try_start_0
    invoke-virtual {p0, v5}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    const/4 v5, 0x0

    :goto_1
    const/high16 v7, 0x42d00000    # 104.0f

    mul-float/2addr v7, v0

    invoke-static {v7}, Ljava/lang/Math;->round(F)I

    move-result v7

    if-eqz v5, :cond_0

    invoke-static {v5}, Lc/e0;->l(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v8

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-static {v5}, Lc/e0;->k(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v5

    invoke-static {v7, v5}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v5, v7

    move v7, v8

    goto :goto_2

    :cond_0
    move v5, v7

    :goto_2
    if-nez v6, :cond_1

    move v8, v2

    goto :goto_3

    :cond_1
    iget v8, v6, Landroid/graphics/Rect;->left:I

    int-to-float v8, v8

    mul-float/2addr v8, v0

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    :goto_3
    if-nez v6, :cond_2

    move v9, v4

    goto :goto_4

    :cond_2
    iget v9, v6, Landroid/graphics/Rect;->top:I

    int-to-float v9, v9

    mul-float/2addr v9, v0

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    :goto_4
    if-eqz v6, :cond_3

    invoke-virtual {v6}, Landroid/graphics/Rect;->width()I

    move-result v10

    int-to-float v10, v10

    mul-float/2addr v10, v0

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v10

    invoke-static {v7, v10}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-virtual {v6}, Landroid/graphics/Rect;->height()I

    move-result v6

    int-to-float v6, v6

    mul-float/2addr v6, v0

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    :cond_3
    add-int/2addr v8, v7

    invoke-static {v3, v8}, Ljava/lang/Math;->max(II)I

    move-result v3

    add-int/2addr v9, v5

    invoke-static {v4, v9}, Ljava/lang/Math;->max(II)I

    move-result v4

    goto :goto_0

    :cond_4
    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0, v2, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    return-object p0
.end method


# virtual methods
.method public final c()V
    .locals 4

    iget-object v0, p0, Lc/e0;->b:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "pending_home_android_widget_id"

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    if-lez v1, :cond_0

    :try_start_0
    iget-object v0, p0, Lc/e0;->d:Lc/b0;

    invoke-virtual {v0, v1}, Landroid/appwidget/AppWidgetHost;->deleteAppWidgetId(I)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method public final d()V
    .locals 18

    move-object/from16 v0, p0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :try_start_0
    iget-object v5, v0, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    invoke-virtual {v5}, Landroid/appwidget/AppWidgetManager;->getInstalledProviders()Ljava/util/List;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_2

    if-nez v5, :cond_0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v5

    :cond_0
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_0
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/appwidget/AppWidgetProviderInfo;

    iget v7, v6, Landroid/appwidget/AppWidgetProviderInfo;->widgetCategory:I

    and-int/lit8 v8, v7, 0x2

    if-eqz v8, :cond_1

    and-int/2addr v7, v2

    if-nez v7, :cond_1

    goto :goto_0

    :cond_1
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x1c

    if-lt v7, v8, :cond_2

    invoke-static {v6}, Lc/T;->a(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v7

    and-int/2addr v7, v1

    if-eqz v7, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_4

    const-string v1, "\u041d\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0445 Android-\u0432\u0438\u0434\u0436\u0435\u0442\u043e\u0432"

    invoke-virtual {v0, v1}, Lc/e0;->t(Ljava/lang/String;)V

    return-void

    :cond_4
    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    iget-object v8, v0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v7, :cond_6

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/appwidget/AppWidgetProviderInfo;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v8

    :try_start_1
    invoke-virtual {v7, v8}, Landroid/appwidget/AppWidgetProviderInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_5

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    if-nez v9, :cond_5

    goto :goto_2

    :catch_0
    :cond_5
    iget-object v8, v7, Landroid/appwidget/AppWidgetProviderInfo;->provider:Landroid/content/ComponentName;

    invoke-virtual {v8}, Landroid/content/ComponentName;->flattenToShortString()Ljava/lang/String;

    move-result-object v8

    :goto_2
    invoke-virtual {v5, v7, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_6
    new-instance v6, Lc/Y;

    invoke-direct {v6, v5, v3}, Lc/Y;-><init>(Ljava/util/HashMap;I)V

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    new-instance v6, Landroid/widget/GridLayout;

    invoke-direct {v6, v8}, Landroid/widget/GridLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v7, v7, Landroid/util/DisplayMetrics;->widthPixels:I

    const/16 v9, 0x20

    invoke-virtual {v0, v9}, Lc/e0;->f(I)I

    move-result v10

    sub-int/2addr v7, v10

    const/16 v10, 0x258

    invoke-virtual {v0, v10}, Lc/e0;->f(I)I

    move-result v11

    invoke-static {v7, v11}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/16 v11, 0x40

    invoke-virtual {v0, v11}, Lc/e0;->f(I)I

    move-result v12

    sub-int/2addr v7, v12

    const/16 v12, 0x1f4

    invoke-virtual {v0, v12}, Lc/e0;->f(I)I

    move-result v12

    if-lt v7, v12, :cond_7

    const/4 v1, 0x4

    goto :goto_3

    :cond_7
    const/16 v12, 0x168

    invoke-virtual {v0, v12}, Lc/e0;->f(I)I

    move-result v12

    if-lt v7, v12, :cond_8

    const/4 v1, 0x3

    :cond_8
    :goto_3
    invoke-virtual {v6, v1}, Landroid/widget/GridLayout;->setColumnCount(I)V

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lc/e0;->f(I)I

    move-result v7

    invoke-virtual {v0, v1}, Lc/e0;->f(I)I

    move-result v12

    invoke-virtual {v0, v1}, Lc/e0;->f(I)I

    move-result v14

    invoke-virtual {v0, v1}, Lc/e0;->f(I)I

    move-result v15

    invoke-virtual {v6, v7, v12, v14, v15}, Landroid/view/View;->setPadding(IIII)V

    new-array v7, v2, [Landroid/app/Dialog;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/appwidget/AppWidgetProviderInfo;

    invoke-virtual {v5, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    new-instance v15, Lc/Z;

    invoke-direct {v15, v0, v7, v12, v3}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v13, 0x11

    invoke-virtual {v3, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-static {v8}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v13

    iget v13, v13, Lc/r4;->c:I

    invoke-static {v8, v13, v9}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v13

    invoke-virtual {v3, v13}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v6}, Landroid/widget/GridLayout;->getColumnCount()I

    move-result v13

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v0, v9}, Lc/e0;->f(I)I

    move-result v16

    sub-int v2, v2, v16

    invoke-virtual {v0, v10}, Lc/e0;->f(I)I

    move-result v9

    invoke-static {v2, v9}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-virtual {v0, v11}, Lc/e0;->f(I)I

    move-result v9

    sub-int/2addr v2, v9

    const/16 v9, 0x64

    invoke-virtual {v0, v9}, Lc/e0;->f(I)I

    move-result v9

    invoke-virtual {v0, v1}, Lc/e0;->f(I)I

    move-result v17

    mul-int v17, v17, v13

    sub-int v2, v2, v17

    div-int/2addr v2, v13

    invoke-static {v9, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    new-instance v9, Landroid/widget/ImageView;

    invoke-direct {v9, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    sget-object v13, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v9, v13}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v13, 0x0

    if-eqz v12, :cond_9

    :try_start_2
    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->densityDpi:I

    invoke-virtual {v12, v8, v1}, Landroid/appwidget/AppWidgetProviderInfo;->loadPreviewImage(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v13

    if-nez v13, :cond_9

    invoke-virtual {v8}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->densityDpi:I

    invoke-virtual {v12, v8, v1}, Landroid/appwidget/AppWidgetProviderInfo;->loadIcon(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1

    move-object v13, v1

    :catch_1
    :cond_9
    if-eqz v13, :cond_a

    invoke-virtual {v9, v13}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_5

    :cond_a
    const v1, 0x108002b

    invoke-virtual {v9, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_5
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x60

    invoke-virtual {v0, v12}, Lc/e0;->f(I)I

    move-result v12

    const/4 v13, -0x1

    invoke-direct {v1, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v9, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v14}, Lc/e0;->j(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v1

    const/high16 v9, 0x41600000    # 14.0f

    invoke-virtual {v1, v9}, Landroid/widget/TextView;->setTextSize(F)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x34

    invoke-virtual {v0, v12}, Lc/e0;->f(I)I

    move-result v12

    invoke-direct {v9, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v1, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Lc/c;

    const/4 v9, 0x1

    invoke-direct {v1, v15, v9}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v3, v9}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {v8, v14}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v1, Landroid/widget/GridLayout$LayoutParams;

    invoke-direct {v1}, Landroid/widget/GridLayout$LayoutParams;-><init>()V

    iput v2, v1, Landroid/widget/GridLayout$LayoutParams;->width:I

    const/16 v2, 0x9c

    invoke-virtual {v0, v2}, Lc/e0;->f(I)I

    move-result v2

    iput v2, v1, Landroid/widget/GridLayout$LayoutParams;->height:I

    const/4 v2, 0x4

    invoke-virtual {v0, v2}, Lc/e0;->f(I)I

    move-result v9

    invoke-virtual {v0, v2}, Lc/e0;->f(I)I

    move-result v12

    invoke-virtual {v0, v2}, Lc/e0;->f(I)I

    move-result v13

    invoke-virtual {v0, v2}, Lc/e0;->f(I)I

    move-result v14

    invoke-virtual {v1, v9, v12, v13, v14}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v6, v3, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v1, 0x8

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v9, 0x20

    goto/16 :goto_4

    :cond_b
    new-instance v1, Landroid/app/Dialog;

    invoke-direct {v1, v8}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v8}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v2

    invoke-virtual {v2, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v3, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v4, 0x1

    invoke-static {v8, v3, v4}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v3

    new-instance v5, Lc/a0;

    const/4 v6, 0x0

    invoke-direct {v5, v1, v6}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v3, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v4, v4, [Landroid/view/View;

    aput-object v3, v4, v6

    invoke-static {v8, v4}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v3

    const-string v4, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 Android-\u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-static {v1, v8, v4, v2, v3}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    aput-object v1, v7, v6

    return-void

    :catch_2
    invoke-virtual/range {p0 .. p0}, Lc/e0;->i()V

    return-void
.end method

.method public final e(I)V
    .locals 8

    :try_start_0
    iget-object v0, p0, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    invoke-virtual {v0, p1}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_0

    invoke-virtual {p0}, Lc/e0;->c()V

    invoke-virtual {p0}, Lc/e0;->i()V

    return-void

    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1c

    if-lt v1, v2, :cond_1

    invoke-static {v0}, Lc/T;->a(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v1

    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_1

    const/4 v1, 0x1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    :goto_1
    iget-object v0, v0, Landroid/appwidget/AppWidgetProviderInfo;->configure:Landroid/content/ComponentName;

    if-eqz v0, :cond_2

    if-nez v1, :cond_2

    :try_start_1
    iget-object v2, p0, Lc/e0;->d:Lc/b0;

    iget-object v3, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v7, 0x0

    const/4 v5, 0x0

    const/16 v6, 0x1cec

    move v4, p1

    invoke-virtual/range {v2 .. v7}, Landroid/appwidget/AppWidgetHost;->startAppWidgetConfigureActivityForResult(Landroid/app/Activity;IIILandroid/os/Bundle;)V
    :try_end_1
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    invoke-virtual {p0}, Lc/e0;->c()V

    invoke-virtual {p0}, Lc/e0;->i()V

    goto :goto_2

    :cond_2
    invoke-virtual {p0, p1}, Lc/e0;->p(I)V

    :goto_2
    return-void
.end method

.method public final f(I)I
    .locals 1

    int-to-float p1, p1

    iget-object v0, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final g(FF)Z
    .locals 5

    iget-boolean v0, p0, Lc/e0;->m:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    cmpg-float v2, p1, v0

    if-ltz v2, :cond_2

    cmpg-float v0, p2, v0

    if-ltz v0, :cond_2

    iget-object v0, p0, Lc/e0;->e:Lc/c0;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    cmpl-float v2, p1, v2

    if-gez v2, :cond_2

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v0, v0

    cmpl-float v0, p2, v0

    if-ltz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/View;->getX()F

    move-result v2

    sub-float/2addr p1, v2

    invoke-virtual {v0}, Landroid/view/View;->getY()F

    move-result v2

    sub-float/2addr p2, v2

    move v2, v1

    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_2

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    instance-of v4, v3, Landroid/widget/FrameLayout;

    if-eqz v4, :cond_1

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v4

    int-to-float v4, v4

    cmpl-float v4, p1, v4

    if-ltz v4, :cond_1

    invoke-virtual {v3}, Landroid/view/View;->getRight()I

    move-result v4

    int-to-float v4, v4

    cmpg-float v4, p1, v4

    if-gez v4, :cond_1

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    move-result v4

    int-to-float v4, v4

    cmpl-float v4, p2, v4

    if-ltz v4, :cond_1

    invoke-virtual {v3}, Landroid/view/View;->getBottom()I

    move-result v3

    int-to-float v3, v3

    cmpg-float v3, p2, v3

    if-gez v3, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    return v1
.end method

.method public final h(II)Z
    .locals 16

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v3, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v4, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-static {v3, v4}, Lc/G8;->M(II)Z

    move-result v3

    iget-object v4, v0, Lc/e0;->b:Lc/n1;

    invoke-virtual {v4, v3}, Lc/n1;->j(Z)Lc/u0;

    move-result-object v12

    sget-object v5, Lc/s0;->j:Lc/s0;

    invoke-virtual {v12, v5}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v13

    if-eqz v13, :cond_0

    iget-boolean v5, v13, Lc/r0;->g:Z

    if-eqz v5, :cond_1

    :cond_0
    const/4 v10, 0x0

    goto/16 :goto_5

    :cond_1
    iget v6, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v7, v2, Landroid/util/DisplayMetrics;->heightPixels:I

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-static {v1, v15}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v8

    iget v9, v2, Landroid/util/DisplayMetrics;->density:F

    invoke-virtual {v4}, Lc/n1;->f0()Z

    move-result v10

    invoke-virtual {v4}, Lc/n1;->C()I

    invoke-virtual {v4}, Lc/n1;->B()I

    invoke-virtual {v4}, Lc/n1;->m0()Z

    move-result v11

    move-object v5, v12

    invoke-static/range {v5 .. v11}, Lc/G8;->k(Lc/u0;IIFFZZ)Lc/o0;

    move-result-object v2

    iget v5, v13, Lc/r0;->f:I

    move v6, v5

    :goto_0
    iget v7, v12, Lc/u0;->a:I

    if-gt v6, v7, :cond_9

    iget v8, v13, Lc/r0;->e:I

    move v9, v8

    :goto_1
    const/16 v10, 0x1e

    if-gt v9, v10, :cond_8

    invoke-virtual {v13, v9, v6}, Lc/r0;->c(II)Lc/r0;

    move-result-object v10

    rsub-int/lit8 v11, v9, 0x1e

    iget v14, v13, Lc/r0;->c:I

    invoke-static {v14, v11}, Ljava/lang/Math;->min(II)I

    move-result v11

    iget v14, v13, Lc/r0;->d:I

    sub-int v15, v7, v6

    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    move-result v14

    invoke-virtual {v10, v11, v14}, Lc/r0;->a(II)Lc/r0;

    move-result-object v10

    iget-boolean v11, v2, Lc/o0;->f:Z

    if-eqz v11, :cond_2

    new-instance v11, Lc/m0;

    iget-object v14, v2, Lc/o0;->c:Lc/m0;

    invoke-virtual {v14}, Lc/m0;->d()F

    move-result v14

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-static {v1, v15}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v10, v0}, Lc/G8;->U(Lc/r0;F)F

    move-result v0

    const/4 v15, 0x0

    invoke-direct {v11, v15, v15, v14, v0}, Lc/m0;-><init>(FFFF)V

    goto :goto_2

    :cond_2
    invoke-virtual {v2, v10}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v11

    :goto_2
    invoke-virtual {v11}, Lc/m0;->d()F

    move-result v0

    const/high16 v14, 0x3f000000    # 0.5f

    add-float/2addr v0, v14

    move/from16 v15, p1

    int-to-float v14, v15

    cmpg-float v0, v0, v14

    if-ltz v0, :cond_7

    invoke-virtual {v11}, Lc/m0;->b()F

    move-result v0

    const/high16 v11, 0x3f000000    # 0.5f

    add-float/2addr v0, v11

    move/from16 v11, p2

    int-to-float v14, v11

    cmpg-float v0, v0, v14

    if-gez v0, :cond_3

    :goto_3
    const/4 v10, 0x0

    goto :goto_4

    :cond_3
    invoke-static {v12, v10}, Lc/G8;->r0(Lc/u0;Lc/r0;)Lc/u0;

    move-result-object v0

    if-nez v0, :cond_4

    goto :goto_3

    :cond_4
    const/4 v2, 0x1

    if-ne v9, v8, :cond_5

    if-ne v6, v5, :cond_5

    return v2

    :cond_5
    const/4 v10, 0x0

    invoke-virtual {v4, v0, v3, v10}, Lc/n1;->B0(Lc/u0;ZZ)Z

    move-result v0

    if-nez v0, :cond_6

    return v10

    :cond_6
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->U()V

    return v2

    :cond_7
    move/from16 v11, p2

    goto :goto_3

    :goto_4
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v0, p0

    const/high16 v15, 0x3f800000    # 1.0f

    goto :goto_1

    :cond_8
    move/from16 v15, p1

    move/from16 v11, p2

    const/4 v10, 0x0

    add-int/lit8 v6, v6, 0x1

    move-object/from16 v0, p0

    const/high16 v15, 0x3f800000    # 1.0f

    goto/16 :goto_0

    :cond_9
    const/4 v10, 0x0

    :goto_5
    return v10
.end method

.method public final i()V
    .locals 1

    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c Android-\u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-virtual {p0, v0}, Lc/e0;->t(Ljava/lang/String;)V

    return-void
.end method

.method public final j(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 2

    new-instance v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p1

    iget p1, p1, Lc/r4;->d:I

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 p1, 0x41800000    # 16.0f

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 p1, 0x11

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 p1, 0x30

    invoke-virtual {p0, p1}, Lc/e0;->f(I)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setMinHeight(I)V

    return-object v0
.end method

.method public final m()V
    .locals 11

    iget-object v0, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    iget-object v4, p0, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v4}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    if-ge v3, v5, :cond_9

    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    instance-of v5, v4, Landroid/widget/TextView;

    if-eqz v5, :cond_0

    move-object v6, v4

    check-cast v6, Landroid/widget/TextView;

    iget v7, v1, Lc/r4;->d:I

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    :cond_0
    instance-of v6, v4, Landroid/widget/FrameLayout;

    const/16 v7, 0x8

    if-eqz v6, :cond_6

    invoke-static {v0, v2, v2}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    iget-boolean v8, p0, Lc/e0;->m:Z

    const/4 v9, 0x1

    if-eqz v8, :cond_1

    invoke-virtual {p0, v9}, Lc/e0;->f(I)I

    move-result v8

    iget v10, v1, Lc/r4;->h:I

    invoke-virtual {v6, v8, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_1
    invoke-virtual {v4, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    move-object v6, v4

    check-cast v6, Landroid/widget/FrameLayout;

    invoke-virtual {v6, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    iget-boolean v9, p0, Lc/e0;->m:Z

    if-eqz v9, :cond_2

    move v9, v2

    goto :goto_1

    :cond_2
    move v9, v7

    :goto_1
    invoke-virtual {v8, v9}, Landroid/view/View;->setVisibility(I)V

    const/4 v8, 0x2

    invoke-virtual {v6, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/LinearLayout;

    iget-boolean v9, p0, Lc/e0;->m:Z

    if-eqz v9, :cond_3

    move v9, v2

    goto :goto_2

    :cond_3
    move v9, v7

    :goto_2
    invoke-virtual {v8, v9}, Landroid/view/View;->setVisibility(I)V

    move v9, v2

    :goto_3
    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v10

    if-ge v9, v10, :cond_4

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/ImageView;

    invoke-virtual {p0, v10, v1}, Lc/e0;->r(Landroid/widget/ImageView;Lc/r4;)V

    add-int/lit8 v9, v9, 0x1

    goto :goto_3

    :cond_4
    iget-object v8, p0, Lc/e0;->h:Ljava/util/HashMap;

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v8, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/appwidget/AppWidgetProviderInfo;

    const/4 v9, 0x3

    invoke-virtual {v6, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    iget-boolean v9, p0, Lc/e0;->m:Z

    if-eqz v9, :cond_5

    if-eqz v8, :cond_5

    iget v8, v8, Landroid/appwidget/AppWidgetProviderInfo;->resizeMode:I

    if-eqz v8, :cond_5

    move v8, v2

    goto :goto_4

    :cond_5
    move v8, v7

    :goto_4
    invoke-virtual {v6, v8}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-virtual {p0, v6, v1}, Lc/e0;->r(Landroid/widget/ImageView;Lc/r4;)V

    :cond_6
    if-eqz v5, :cond_8

    invoke-virtual {v4}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v5

    if-nez v5, :cond_8

    iget-boolean v5, p0, Lc/e0;->m:Z

    if-eqz v5, :cond_7

    goto :goto_5

    :cond_7
    move v7, v2

    :goto_5
    invoke-virtual {v4, v7}, Landroid/view/View;->setVisibility(I)V

    :cond_8
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_9
    return-void
.end method

.method public final n()V
    .locals 12

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/e0;->n:Z

    iget-object v0, p0, Lc/e0;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v1, p0, Lc/e0;->o:Ljava/util/List;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Lc/e0;->g:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    iget-object v4, p0, Lc/e0;->h:Ljava/util/HashMap;

    if-eqz v3, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    iget-object v1, p0, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v6

    :try_start_0
    iget-object v7, p0, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    invoke-virtual {v7, v6}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    move-result-object v7
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    const/4 v7, 0x0

    :goto_2
    const-string v8, " \u00b7 "

    const-string v9, "\u0412\u0438\u0434\u0436\u0435\u0442 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    iget-object v10, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    if-nez v7, :cond_2

    invoke-virtual {v2, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v10, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5}, Lc/e0;->j(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {p0, v5, v6}, Lc/e0;->s(Landroid/view/View;I)Landroid/widget/FrameLayout;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_1

    :cond_2
    invoke-virtual {v2, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/appwidget/AppWidgetHostView;

    if-nez v11, :cond_3

    :try_start_1
    iget-object v11, p0, Lc/e0;->d:Lc/b0;

    invoke-virtual {v11, v10, v6, v7}, Landroid/appwidget/AppWidgetHost;->createView(Landroid/content/Context;ILandroid/appwidget/AppWidgetProviderInfo;)Landroid/appwidget/AppWidgetHostView;

    move-result-object v11

    invoke-virtual {v2, v5, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v10, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v5}, Lc/e0;->j(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v5

    invoke-virtual {p0, v5, v6}, Lc/e0;->s(Landroid/view/View;I)Landroid/widget/FrameLayout;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto :goto_1

    :cond_3
    :goto_3
    invoke-virtual {v4, v5, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v11}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    instance-of v5, v5, Landroid/view/ViewGroup;

    if-eqz v5, :cond_4

    invoke-virtual {v11}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    check-cast v5, Landroid/view/ViewGroup;

    invoke-virtual {v5, v11}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_4
    invoke-virtual {p0, v11, v6}, Lc/e0;->s(Landroid/view/View;I)Landroid/widget/FrameLayout;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto/16 :goto_1

    :cond_5
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_7

    const-string v0, "+ \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c Android-\u0432\u0438\u0434\u0436\u0435\u0442"

    invoke-virtual {p0, v0}, Lc/e0;->j(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    new-instance v2, Lc/c;

    const/4 v3, 0x2

    invoke-direct {v2, p0, v3}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-boolean v2, p0, Lc/e0;->m:Z

    if-eqz v2, :cond_6

    const/16 v2, 0x8

    goto :goto_4

    :cond_6
    const/4 v2, 0x0

    :goto_4
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_7
    const/4 v0, -0x1

    iput v0, p0, Lc/e0;->q:I

    iput v0, p0, Lc/e0;->p:I

    new-instance v0, Lc/X;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/X;-><init>(Lc/e0;I)V

    iget-object v1, p0, Lc/e0;->e:Lc/c0;

    invoke-virtual {v1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final p(I)V
    .locals 8

    :try_start_0
    iget-object v0, p0, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    invoke-virtual {v0, p1}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_0

    invoke-virtual {p0}, Lc/e0;->c()V

    invoke-virtual {p0}, Lc/e0;->i()V

    return-void

    :cond_0
    iget-object v1, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, p0, Lc/e0;->b:Lc/n1;

    invoke-static {v1, v2}, Lc/e0;->o(Landroid/content/Context;Lc/n1;)Landroid/graphics/Rect;

    move-result-object v3

    iget v4, v3, Landroid/graphics/Rect;->right:I

    const/16 v5, 0x68

    invoke-virtual {p0, v5}, Lc/e0;->f(I)I

    move-result v6

    iget v7, v0, Landroid/appwidget/AppWidgetProviderInfo;->minWidth:I

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    move-result v4

    iget v3, v3, Landroid/graphics/Rect;->bottom:I

    invoke-virtual {p0, v5}, Lc/e0;->f(I)I

    move-result v5

    iget v0, v0, Landroid/appwidget/AppWidgetProviderInfo;->minHeight:I

    invoke-static {v5, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/2addr v0, v3

    invoke-virtual {p0, v4, v0}, Lc/e0;->h(II)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lc/e0;->c()V

    const-string p1, "\u0423\u0432\u0435\u043b\u0438\u0447\u044c\u0442\u0435 \u043a\u043e\u043d\u0442\u0435\u0439\u043d\u0435\u0440, \u0447\u0442\u043e\u0431\u044b Android-\u0432\u0438\u0434\u0436\u0435\u0442 \u043f\u043e\u043c\u0435\u0449\u0430\u043b\u0441\u044f \u043f\u043e\u043b\u043d\u043e\u0441\u0442\u044c\u044e"

    invoke-virtual {p0, p1}, Lc/e0;->t(Ljava/lang/String;)V

    return-void

    :cond_1
    invoke-virtual {v2}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    invoke-virtual {v2, v0}, Lc/n1;->F0(Ljava/util/ArrayList;)Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {p0}, Lc/e0;->c()V

    invoke-virtual {p0}, Lc/e0;->i()V

    return-void

    :cond_3
    iget-object p1, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "pending_home_android_widget_id"

    const/4 v2, 0x0

    invoke-interface {p1, v0, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    invoke-virtual {p0}, Lc/e0;->n()V

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->U()V

    return-void
.end method

.method public final q(Z)V
    .locals 0

    iput-boolean p1, p0, Lc/e0;->j:Z

    invoke-virtual {p0}, Lc/e0;->w()V

    return-void
.end method

.method public final r(Landroid/widget/ImageView;Lc/r4;)V
    .locals 4

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    iget v1, p2, Lc/r4;->d:I

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    iget-object v2, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/high16 v3, 0x41800000    # 16.0f

    invoke-static {v2, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    sub-int/2addr v1, v3

    new-instance v3, Landroid/graphics/drawable/InsetDrawable;

    invoke-direct {v3, v0, v1}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;I)V

    invoke-virtual {p1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget p2, p2, Lc/r4;->a:I

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setColorFilter(I)V

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result p2

    div-int/lit8 p2, p2, 0x2

    const/high16 v0, 0x41300000    # 11.0f

    invoke-static {v2, v0}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    sub-int/2addr p2, v0

    invoke-virtual {p1, p2, p2, p2, p2}, Landroid/view/View;->setPadding(IIII)V

    return-void
.end method

.method public final s(Landroid/view/View;I)Landroid/widget/FrameLayout;
    .locals 9

    new-instance v0, Landroid/widget/FrameLayout;

    iget-object v1, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    const v3, 0x7f0300c9

    const-string v4, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0440\u0430\u0437\u043c\u0435\u0440"

    invoke-virtual {p0, v4, v3}, Lc/e0;->u(Ljava/lang/String;I)Landroid/widget/ImageView;

    move-result-object v3

    iget-object v4, p0, Lc/e0;->h:Ljava/util/HashMap;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/appwidget/AppWidgetProviderInfo;

    iget-boolean v5, p0, Lc/e0;->m:Z

    const/16 v6, 0x8

    if-eqz v5, :cond_0

    if-eqz v4, :cond_0

    iget v5, v4, Landroid/appwidget/AppWidgetProviderInfo;->resizeMode:I

    if-eqz v5, :cond_0

    move v5, v2

    goto :goto_0

    :cond_0
    move v5, v6

    :goto_0
    invoke-virtual {v3, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    new-instance v5, Lc/d0;

    const/4 v7, 0x1

    invoke-direct {v5, p0, v0, v7, p2}, Lc/d0;-><init>(Lc/e0;Landroid/widget/FrameLayout;ZI)V

    invoke-virtual {v3, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v8, -0x1

    invoke-direct {v5, v8, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/view/View;

    invoke-direct {p1, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v7}, Landroid/view/View;->setClickable(Z)V

    iget-boolean v5, p0, Lc/e0;->m:Z

    if-eqz v5, :cond_1

    move v5, v2

    goto :goto_1

    :cond_1
    move v5, v6

    :goto_1
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    new-instance v5, Lc/d0;

    invoke-direct {v5, p0, v0, v2, p2}, Lc/d0;-><init>(Lc/e0;Landroid/widget/FrameLayout;ZI)V

    invoke-virtual {p1, v5}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v5, v8, v8}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/LinearLayout;

    invoke-direct {p1, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iget-boolean v5, p0, Lc/e0;->m:Z

    if-eqz v5, :cond_2

    goto :goto_2

    :cond_2
    move v2, v6

    :goto_2
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const v2, 0x7f0300c3

    const-string v5, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual {p0, v5, v2}, Lc/e0;->u(Ljava/lang/String;I)Landroid/widget/ImageView;

    move-result-object v2

    new-instance v5, Lc/V;

    const/4 v6, 0x0

    invoke-direct {v5, p0, p2, v6}, Lc/V;-><init>(Lc/e0;II)V

    invoke-virtual {v2, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v6

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v8

    invoke-direct {v5, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v2, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v4, :cond_4

    iget-object v2, v4, Landroid/appwidget/AppWidgetProviderInfo;->configure:Landroid/content/ComponentName;

    if-eqz v2, :cond_4

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1c

    if-lt v2, v5, :cond_3

    invoke-static {v4}, Lc/T;->a(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v2

    and-int/2addr v2, v7

    if-eqz v2, :cond_4

    :cond_3
    const v2, 0x7f0300cb

    const-string v4, "\u041d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u044c"

    invoke-virtual {p0, v4, v2}, Lc/e0;->u(Ljava/lang/String;I)Landroid/widget/ImageView;

    move-result-object v2

    new-instance v4, Lc/V;

    const/4 v5, 0x1

    invoke-direct {v4, p0, p2, v5}, Lc/V;-><init>(Lc/e0;II)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v4

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v5

    invoke-direct {p2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v2, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_4
    const/high16 p2, 0x41800000    # 16.0f

    invoke-static {v1, p2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p2

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    sub-int/2addr p2, v1

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v2

    const/16 v4, 0x53

    const/4 v5, -0x2

    invoke-direct {v1, v5, v2, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    iput p2, v1, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iput p2, v1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v0, p1, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v1

    invoke-virtual {p0}, Lc/e0;->v()I

    move-result v2

    const/16 v4, 0x55

    invoke-direct {p1, v1, v2, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    iput p2, p1, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    iput p2, p1, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    invoke-virtual {v0, v3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method public final t(Ljava/lang/String;)V
    .locals 2

    iget-object v0, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x0

    invoke-static {v0, p1, v0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void
.end method

.method public final u(Ljava/lang/String;I)Landroid/widget/ImageView;
    .locals 2

    new-instance v0, Landroid/widget/ImageView;

    iget-object v1, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p2}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p2

    invoke-virtual {p0, v0, p2}, Lc/e0;->r(Landroid/widget/ImageView;Lc/r4;)V

    invoke-static {v1, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-object v0
.end method

.method public final v()I
    .locals 2

    iget-object v0, p0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v0, v1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method public final w()V
    .locals 3

    iget-boolean v0, p0, Lc/e0;->i:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/e0;->j:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-boolean v2, p0, Lc/e0;->k:Z

    if-eq v0, v2, :cond_3

    if-eqz v0, :cond_1

    iget-boolean v2, p0, Lc/e0;->l:Z

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    iput-boolean v0, p0, Lc/e0;->k:Z

    iget-object v2, p0, Lc/e0;->d:Lc/b0;

    if-eqz v0, :cond_2

    :try_start_0
    invoke-virtual {v2}, Landroid/appwidget/AppWidgetHost;->startListening()V

    goto :goto_1

    :cond_2
    invoke-virtual {v2}, Landroid/appwidget/AppWidgetHost;->stopListening()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    iput-boolean v1, p0, Lc/e0;->k:Z

    iput-boolean v0, p0, Lc/e0;->l:Z

    :cond_3
    :goto_1
    return-void
.end method

.method public final x(II)V
    .locals 23

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    if-lez v1, :cond_d

    if-lez v2, :cond_d

    iget v3, v0, Lc/e0;->p:I

    if-ne v1, v3, :cond_0

    iget v3, v0, Lc/e0;->q:I

    if-ne v2, v3, :cond_0

    goto/16 :goto_7

    :cond_0
    iput v1, v0, Lc/e0;->p:I

    iput v2, v0, Lc/e0;->q:I

    iget-object v3, v0, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    :goto_0
    iget-object v8, v0, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v8}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v9

    if-ge v5, v9, :cond_b

    invoke-virtual {v8, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    instance-of v9, v8, Landroid/widget/FrameLayout;

    if-nez v9, :cond_1

    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v10, 0x30

    invoke-virtual {v0, v10}, Lc/e0;->f(I)I

    move-result v10

    const/4 v11, -0x1

    invoke-direct {v9, v11, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move/from16 v16, v5

    goto/16 :goto_6

    :cond_1
    invoke-virtual {v8}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v10

    iget-object v11, v0, Lc/e0;->h:Ljava/util/HashMap;

    invoke-virtual {v11, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/appwidget/AppWidgetProviderInfo;

    iget-object v12, v0, Lc/e0;->b:Lc/n1;

    invoke-virtual {v12, v10}, Lc/n1;->n(I)Landroid/graphics/Rect;

    move-result-object v13

    const/16 v14, 0x68

    invoke-virtual {v0, v14}, Lc/e0;->f(I)I

    move-result v15

    if-nez v11, :cond_2

    goto :goto_1

    :cond_2
    iget v4, v11, Landroid/appwidget/AppWidgetProviderInfo;->minWidth:I

    invoke-static {v15, v4}, Ljava/lang/Math;->max(II)I

    move-result v15

    :goto_1
    invoke-virtual {v0, v14}, Lc/e0;->f(I)I

    move-result v4

    if-nez v11, :cond_3

    goto :goto_2

    :cond_3
    iget v14, v11, Landroid/appwidget/AppWidgetProviderInfo;->minHeight:I

    invoke-static {v4, v14}, Ljava/lang/Math;->max(II)I

    move-result v4

    :goto_2
    if-nez v13, :cond_4

    new-instance v14, Landroid/graphics/Rect;

    add-int/2addr v4, v7

    move/from16 v16, v5

    const/4 v5, 0x0

    invoke-direct {v14, v5, v7, v15, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    move-object/from16 v17, v9

    goto :goto_3

    :cond_4
    move/from16 v16, v5

    const/4 v5, 0x0

    new-instance v14, Landroid/graphics/Rect;

    iget v4, v13, Landroid/graphics/Rect;->left:I

    int-to-float v4, v4

    mul-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    iget v15, v13, Landroid/graphics/Rect;->top:I

    int-to-float v15, v15

    mul-float/2addr v15, v3

    invoke-static {v15}, Ljava/lang/Math;->round(F)I

    move-result v15

    iget v5, v13, Landroid/graphics/Rect;->right:I

    int-to-float v5, v5

    mul-float/2addr v5, v3

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    move-object/from16 v17, v9

    iget v9, v13, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    mul-float/2addr v9, v3

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-direct {v14, v4, v15, v5, v9}, Landroid/graphics/Rect;-><init>(IIII)V

    :goto_3
    if-eqz v11, :cond_5

    iget v4, v14, Landroid/graphics/Rect;->right:I

    iget v5, v14, Landroid/graphics/Rect;->left:I

    const/16 v9, 0x68

    invoke-virtual {v0, v9}, Lc/e0;->f(I)I

    move-result v15

    invoke-static {v11}, Lc/e0;->l(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v9

    invoke-static {v15, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    add-int/2addr v9, v5

    invoke-static {v4, v9}, Ljava/lang/Math;->max(II)I

    move-result v4

    iput v4, v14, Landroid/graphics/Rect;->right:I

    iget v4, v14, Landroid/graphics/Rect;->bottom:I

    iget v5, v14, Landroid/graphics/Rect;->top:I

    const/16 v9, 0x68

    invoke-virtual {v0, v9}, Lc/e0;->f(I)I

    move-result v9

    invoke-static {v11}, Lc/e0;->k(Landroid/appwidget/AppWidgetProviderInfo;)I

    move-result v11

    invoke-static {v9, v11}, Ljava/lang/Math;->max(II)I

    move-result v9

    add-int/2addr v9, v5

    invoke-static {v4, v9}, Ljava/lang/Math;->max(II)I

    move-result v4

    iput v4, v14, Landroid/graphics/Rect;->bottom:I

    :cond_5
    move-object v4, v8

    check-cast v4, Landroid/widget/FrameLayout;

    invoke-static {v4, v14}, Lc/e0;->a(Landroid/widget/FrameLayout;Landroid/graphics/Rect;)V

    iget v4, v14, Landroid/graphics/Rect;->right:I

    invoke-static {v6, v4}, Ljava/lang/Math;->max(II)I

    move-result v6

    iget v4, v14, Landroid/graphics/Rect;->bottom:I

    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    move-result v7

    if-nez v13, :cond_6

    new-instance v4, Landroid/graphics/Rect;

    iget v5, v14, Landroid/graphics/Rect;->left:I

    int-to-float v5, v5

    div-float/2addr v5, v3

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget v9, v14, Landroid/graphics/Rect;->top:I

    int-to-float v9, v9

    div-float/2addr v9, v3

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    iget v11, v14, Landroid/graphics/Rect;->right:I

    int-to-float v11, v11

    div-float/2addr v11, v3

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    iget v13, v14, Landroid/graphics/Rect;->bottom:I

    int-to-float v13, v13

    div-float/2addr v13, v3

    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v13

    invoke-direct {v4, v5, v9, v11, v13}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v12, v10, v4}, Lc/n1;->E0(ILandroid/graphics/Rect;)Z

    :cond_6
    iget v4, v14, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x1

    if-gt v4, v1, :cond_7

    iget v4, v14, Landroid/graphics/Rect;->bottom:I

    if-gt v4, v2, :cond_7

    move v4, v5

    goto :goto_4

    :cond_7
    const/4 v4, 0x0

    :goto_4
    if-eqz v4, :cond_8

    const/4 v9, 0x0

    goto :goto_5

    :cond_8
    const/4 v9, 0x4

    :goto_5
    invoke-virtual {v8, v9}, Landroid/view/View;->setVisibility(I)V

    iget-object v8, v0, Lc/e0;->g:Ljava/util/HashMap;

    move-object/from16 v9, v17

    invoke-virtual {v8, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/appwidget/AppWidgetHostView;

    if-eqz v8, :cond_a

    if-eqz v4, :cond_a

    invoke-virtual {v14}, Landroid/graphics/Rect;->width()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-virtual {v14}, Landroid/graphics/Rect;->height()I

    move-result v9

    int-to-float v9, v9

    div-float/2addr v9, v3

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    move-result v5

    :try_start_0
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v10, 0x1f

    if-lt v9, v10, :cond_9

    new-instance v9, Landroid/os/Bundle;

    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    new-instance v10, Landroid/util/SizeF;

    int-to-float v4, v4

    int-to-float v5, v5

    invoke-direct {v10, v4, v5}, Landroid/util/SizeF;-><init>(FF)V

    invoke-static {v10}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    invoke-static {v8, v9, v4}, Lc/U;->b(Landroid/appwidget/AppWidgetHostView;Landroid/os/Bundle;Ljava/util/List;)V

    goto :goto_6

    :cond_9
    const/16 v18, 0x0

    move-object/from16 v17, v8

    move/from16 v19, v4

    move/from16 v20, v5

    move/from16 v21, v4

    move/from16 v22, v5

    invoke-virtual/range {v17 .. v22}, Landroid/appwidget/AppWidgetHostView;->updateAppWidgetSize(Landroid/os/Bundle;IIII)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_a
    :goto_6
    add-int/lit8 v5, v16, 0x1

    goto/16 :goto_0

    :cond_b
    if-gt v6, v1, :cond_c

    if-le v7, v2, :cond_d

    :cond_c
    new-instance v1, Lc/W;

    invoke-direct {v1, v0, v6, v7}, Lc/W;-><init>(Lc/e0;II)V

    iget-object v2, v0, Lc/e0;->e:Lc/c0;

    invoke-virtual {v2, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_d
    :goto_7
    return-void
.end method
