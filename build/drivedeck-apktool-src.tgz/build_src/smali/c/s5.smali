.class public final Lc/s5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:J

.field public b:J

.field public c:Z

.field public d:Ljava/lang/Boolean;


# direct methods
.method public static b(Ljava/lang/Double;)Z
    .locals 2

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->isFinite(D)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public final a()V
    .locals 2

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc/s5;->b:J

    iput-wide v0, p0, Lc/s5;->a:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/s5;->c:Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/s5;->d:Ljava/lang/Boolean;

    return-void
.end method
