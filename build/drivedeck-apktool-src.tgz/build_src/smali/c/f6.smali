.class public final Lc/f6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:I


# direct methods
.method public constructor <init>(IILjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc/f6;->a:Ljava/lang/String;

    iput p1, p0, Lc/f6;->b:I

    iput p2, p0, Lc/f6;->c:I

    return-void
.end method
