.class public final Lc/O4;
.super Landroid/database/ContentObserver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Landroid/os/Handler;I)V
    .locals 0

    iput p3, p0, Lc/O4;->a:I

    iput-object p1, p0, Lc/O4;->b:Ljava/lang/Object;

    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public final onChange(Z)V
    .locals 2

    iget p1, p0, Lc/O4;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/O4;->b:Ljava/lang/Object;

    check-cast p1, Lc/R1;

    invoke-virtual {p1}, Lc/R1;->a()V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/O4;->b:Ljava/lang/Object;

    check-cast p1, Lru/drivedeck/launcher/MainActivity;

    iget-object v0, p1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Lc/n1;->d0()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v0

    const-string v1, "auto"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->j0()Z

    move-result v0

    iget-boolean v1, p1, Lru/drivedeck/launcher/MainActivity;->v0:Z

    if-eq v0, v1, :cond_1

    iput-boolean v0, p1, Lru/drivedeck/launcher/MainActivity;->v0:Z

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->e()V

    goto :goto_0

    :cond_1
    invoke-static {p1}, Lc/R1;->b(Landroid/content/Context;)V

    :cond_2
    :goto_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
