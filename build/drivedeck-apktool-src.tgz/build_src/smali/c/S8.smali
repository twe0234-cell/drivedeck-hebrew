.class public final Lc/S8;
.super Ljava/io/FilterInputStream;
.source "SourceFile"


# instance fields
.field public final synthetic a:Ljava/net/HttpURLConnection;

.field public final synthetic b:J


# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ljava/net/HttpURLConnection;J)V
    .locals 0

    iput-object p2, p0, Lc/S8;->a:Ljava/net/HttpURLConnection;

    iput-wide p3, p0, Lc/S8;->b:J

    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    return-void
.end method


# virtual methods
.method public final read([BII)I
    .locals 2

    iget-wide v0, p0, Lc/S8;->b:J

    invoke-static {v0, v1}, Lc/T8;->e(J)I

    move-result v0

    const/16 v1, 0x61a8

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget-object v1, p0, Lc/S8;->a:Ljava/net/HttpURLConnection;

    invoke-virtual {v1, v0}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-super {p0, p1, p2, p3}, Ljava/io/FilterInputStream;->read([BII)I

    move-result p1

    return p1
.end method
