.class public final synthetic Lc/G2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Landroid/view/KeyEvent$Callback;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILc/n1;Lc/k3;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/G2;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc/G2;->c:Landroid/view/KeyEvent$Callback;

    iput p1, p0, Lc/G2;->b:I

    iput-object p2, p0, Lc/G2;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/Q3;Landroid/app/Dialog;I)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/G2;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/G2;->c:Landroid/view/KeyEvent$Callback;

    iput-object p2, p0, Lc/G2;->d:Ljava/lang/Object;

    iput p3, p0, Lc/G2;->b:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 8

    iget p1, p0, Lc/G2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/G2;->c:Landroid/view/KeyEvent$Callback;

    check-cast p1, Lc/Q3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/G2;->d:Ljava/lang/Object;

    check-cast v0, Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    const/4 v0, 0x1

    iget v1, p0, Lc/G2;->b:I

    if-ne v1, v0, :cond_0

    invoke-virtual {p1}, Lc/Q3;->S()V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Lc/Q3;->Q()V

    :goto_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/G2;->c:Landroid/view/KeyEvent$Callback;

    check-cast p1, Lc/k3;

    iget-object v0, p1, Lc/k3;->b:Lc/z;

    invoke-virtual {v0}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v2

    iget v0, p0, Lc/G2;->b:I

    if-nez v0, :cond_1

    const-string v1, "\u041e\u043a\u043d\u043e 1"

    :goto_1
    move-object v3, v1

    goto :goto_2

    :cond_1
    const-string v1, "\u041e\u043a\u043d\u043e 2"

    goto :goto_1

    :goto_2
    new-instance v4, Lc/H5;

    iget-object v1, p0, Lc/G2;->d:Ljava/lang/Object;

    check-cast v1, Lc/n1;

    const/4 v5, 0x2

    invoke-direct {v4, p1, v0, v1, v5}, Lc/H5;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    new-instance v5, Lc/a1;

    const/4 v0, 0x3

    invoke-direct {v5, v0}, Lc/a1;-><init>(I)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    iget-object v1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static/range {v1 .. v7}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
