.class public final synthetic Lc/B4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/n;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;JI)V
    .locals 0

    iput p4, p0, Lc/B4;->a:I

    iput-object p1, p0, Lc/B4;->c:Ljava/lang/Object;

    iput-wide p2, p0, Lc/B4;->b:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lc/a;)V
    .locals 6

    iget v0, p0, Lc/B4;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/B4;->c:Ljava/lang/Object;

    check-cast v0, Lc/y;

    iget-object v0, v0, Lc/y;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-wide v3, p0, Lc/B4;->b:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/n1;->A0(Z)V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v2, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/n1;->J0(Ljava/lang/String;)V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, p1}, Lc/n1;->I0(Ljava/lang/String;)V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1, p1}, Lc/n1;->v0(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Lru/drivedeck/launcher/MainActivity;->b(Ljava/lang/String;)V

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/B4;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-wide v3, p0, Lc/B4;->b:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_1

    goto/16 :goto_3

    :cond_1
    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const-string v3, "__launcher_settings__"

    iget-object v4, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    move v3, v2

    goto :goto_1

    :cond_2
    move v3, v1

    :goto_1
    const/4 v4, 0x0

    if-eqz v3, :cond_3

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iput-object v4, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v1, Lc/I4;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v2}, Lc/I4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_3

    :cond_3
    iget-object v3, p1, Lc/a;->a:Ljava/lang/String;

    const-string v5, "__launcher_phone__"

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iput-object v4, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v1, Lc/J1;

    const/16 v2, 0x15

    invoke-direct {v1, v0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_3

    :cond_4
    const-string v3, "__launcher_music__"

    iget-object v5, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iput-object v4, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v1, Lc/J1;

    const/16 v2, 0x16

    invoke-direct {v1, v0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    goto/16 :goto_3

    :cond_5
    iget-object p1, p1, Lc/a;->d:Landroid/content/ComponentName;

    if-eqz p1, :cond_a

    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v3, p1, v1}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    move-result-object v3

    invoke-virtual {p1}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lc/z;->g(Landroid/content/pm/ActivityInfo;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_6

    iget-object v4, v3, Landroid/content/pm/ActivityInfo;->permission:Ljava/lang/String;

    if-eqz v4, :cond_7

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_7

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->permission:Ljava/lang/String;

    invoke-virtual {v0, v3}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v3

    if-nez v3, :cond_6

    goto :goto_2

    :cond_6
    move v2, v1

    :cond_7
    :goto_2
    if-eqz v2, :cond_9

    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.MAIN"

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v3, "android.intent.category.LAUNCHER"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p1

    const/high16 v2, 0x10000000

    invoke-virtual {p1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/app/ActivityOptions;->setLaunchDisplayId(I)Landroid/app/ActivityOptions;

    invoke-virtual {v2}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object v2

    invoke-virtual {v0, p1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, ""

    invoke-virtual {p1, v2}, Lc/n1;->w0(Ljava/lang/String;)V

    const-wide/16 v2, 0x0

    iput-wide v2, v0, Lru/drivedeck/launcher/MainActivity;->H:J

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz p1, :cond_8

    invoke-virtual {p1, v1}, Lc/Q3;->P(Z)V

    :cond_8
    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_b

    invoke-virtual {p1, v1}, Lc/m2;->G(Z)V

    goto :goto_3

    :cond_9
    new-instance p1, Ljava/lang/SecurityException;

    const-string v2, "Activity unavailable"

    invoke-direct {p1, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0430\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c"

    invoke-static {v0, p1, v0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_3

    :cond_a
    invoke-virtual {v0, v2, v5}, Lru/drivedeck/launcher/MainActivity;->N(ZLjava/lang/String;)V

    :cond_b
    :goto_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
