.class public final Lc/M1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/String;

.field public final c:Ljava/util/concurrent/atomic/AtomicLong;

.field public final d:Lc/u1;

.field public volatile e:J

.field public volatile f:I

.field public volatile g:I

.field public volatile h:I


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    iput-object v0, p0, Lc/M1;->c:Ljava/util/concurrent/atomic/AtomicLong;

    new-instance v0, Lc/u1;

    invoke-direct {v0}, Lc/u1;-><init>()V

    iput-object v0, p0, Lc/M1;->d:Lc/u1;

    const/4 v0, -0x1

    iput v0, p0, Lc/M1;->h:I

    iput p2, p0, Lc/M1;->a:I

    iput-object p1, p0, Lc/M1;->b:Ljava/lang/String;

    return-void
.end method
