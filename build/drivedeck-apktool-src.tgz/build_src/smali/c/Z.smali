.class public final synthetic Lc/Z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p4, p0, Lc/Z;->a:I

    iput-object p1, p0, Lc/Z;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/Z;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/Z;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/F;[Landroid/app/Dialog;)V
    .locals 1

    .line 2
    const/16 v0, 0xd

    iput v0, p0, Lc/Z;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Z;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/Z;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/Z;->c:Ljava/lang/Object;

    return-void
.end method

.method private final a()V
    .locals 9

    iget-object v0, p0, Lc/Z;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lc/Z;->b:Ljava/lang/Object;

    check-cast v1, Lc/z5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "selections/"

    const/4 v3, 0x0

    :try_start_0
    iget-object v4, v1, Lc/z5;->f:Landroid/content/SharedPreferences;

    const-string v5, "profile_sha"

    const-string v6, ""

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "[a-f0-9]{24}"

    invoke-virtual {v0, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_4

    const-string v5, "[a-f0-9]{64}"

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "-"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ".json"

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/high16 v5, 0x400000

    invoke-virtual {v1, v2, v5}, Lc/z5;->e(Ljava/lang/String;I)[B

    move-result-object v2

    invoke-static {v2}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v2

    invoke-static {v2}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/x5;

    iget-object v6, v5, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    iget-object v6, v5, Lc/x5;->e:Ljava/lang/String;

    invoke-virtual {v6, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    goto :goto_0

    :cond_1
    move-object v5, v3

    :goto_0
    if-eqz v5, :cond_3

    iget-object v2, v5, Lc/x5;->d:Ljava/lang/String;

    iget v4, v5, Lc/x5;->h:I

    invoke-virtual {v1, v2, v4}, Lc/z5;->e(Ljava/lang/String;I)[B

    move-result-object v2

    invoke-static {v5, v2}, Lc/z5;->g(Lc/x5;[B)V

    new-instance v4, Lc/j6;

    new-instance v6, Lorg/json/JSONObject;

    new-instance v7, Ljava/lang/String;

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v7, v2, v8}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iget-object v2, v5, Lc/x5;->e:Ljava/lang/String;

    invoke-direct {v4, v6, v2}, Lc/j6;-><init>(Lorg/json/JSONObject;Ljava/lang/String;)V

    iget-object v2, v4, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move-object v0, v3

    move-object v3, v4

    goto :goto_1

    :cond_2
    new-instance v0, Ljava/lang/SecurityException;

    const-string v2, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c"

    invoke-direct {v0, v2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    new-instance v0, Ljava/io/IOException;

    const-string v2, "\u041f\u0440\u043e\u0444\u0438\u043b\u044f \u043d\u0435\u0442 \u0432 \u043b\u043e\u043a\u0430\u043b\u044c\u043d\u043e\u043c \u043a\u0430\u0442\u0430\u043b\u043e\u0433\u0435"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4
    new-instance v0, Ljava/io/IOException;

    const-string v2, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0443\u0436\u043d\u043e \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u0441\u043d\u043e\u0432\u0430"

    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string v0, "\u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d. \u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0435\u0433\u043e \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 OBD"

    :goto_1
    iget-object v1, v1, Lc/z5;->h:Landroid/os/Handler;

    new-instance v2, Lc/Z;

    iget-object v4, p0, Lc/Z;->d:Ljava/lang/Object;

    check-cast v4, Lc/y5;

    const/16 v5, 0xf

    invoke-direct {v2, v4, v3, v0, v5}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private final b()V
    .locals 12

    iget-object v0, p0, Lc/Z;->c:Ljava/lang/Object;

    check-cast v0, Lc/x5;

    iget-object v1, p0, Lc/Z;->b:Ljava/lang/Object;

    check-cast v1, Lc/z5;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    :try_start_0
    iget-object v3, v0, Lc/x5;->d:Ljava/lang/String;

    iget v4, v0, Lc/x5;->h:I

    invoke-virtual {v1, v3, v4}, Lc/z5;->e(Ljava/lang/String;I)[B

    move-result-object v3

    invoke-static {v0, v3}, Lc/z5;->g(Lc/x5;[B)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    :try_start_1
    iget-object v3, v0, Lc/x5;->d:Ljava/lang/String;

    iget v4, v0, Lc/x5;->h:I

    const-string v5, "https://storage.yandexcloud.net/drivedeck-updates-ru/obd/v2/"
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    :try_start_2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v4}, Lc/z5;->a(Ljava/lang/String;I)[B

    move-result-object v5

    invoke-static {v0, v5}, Lc/z5;->g(Lc/x5;[B)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    move-object v3, v5

    goto :goto_0

    :catch_1
    move-exception v5

    :try_start_3
    invoke-static {v3}, Lc/z5;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lc/z5;->a(Ljava/lang/String;I)[B

    move-result-object v3

    invoke-static {v0, v3}, Lc/z5;->g(Lc/x5;[B)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :goto_0
    :try_start_4
    invoke-static {v0, v3}, Lc/z5;->g(Lc/x5;[B)V

    :goto_1
    new-instance v4, Lc/j6;

    new-instance v5, Lorg/json/JSONObject;

    new-instance v6, Ljava/lang/String;

    sget-object v7, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v6, v3, v7}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v5, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    iget-object v6, v0, Lc/x5;->e:Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_3

    iget-object v7, v0, Lc/x5;->a:Ljava/lang/String;

    :try_start_5
    invoke-direct {v4, v5, v6}, Lc/j6;-><init>(Lorg/json/JSONObject;Ljava/lang/String;)V

    iget-object v5, v4, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v7, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3

    const-string v5, "catalog.json"

    const/high16 v6, 0x400000

    invoke-virtual {v1, v5, v6}, Lc/z5;->e(Ljava/lang/String;I)[B

    move-result-object v5

    invoke-static {v5}, Lc/z5;->h([B)Lorg/json/JSONObject;

    move-result-object v6

    invoke-static {v6}, Lc/z5;->d(Lorg/json/JSONObject;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    const/4 v8, 0x0

    :cond_0
    :goto_2
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v9
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    iget-object v10, v0, Lc/x5;->e:Ljava/lang/String;

    if-eqz v9, :cond_1

    :try_start_6
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/x5;

    iget-object v11, v9, Lc/x5;->a:Ljava/lang/String;

    invoke-virtual {v11, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_0

    iget-object v9, v9, Lc/x5;->e:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_0

    const/4 v8, 0x1

    goto :goto_2

    :cond_1
    if-eqz v8, :cond_2

    iget-object v0, v0, Lc/x5;->d:Ljava/lang/String;

    invoke-virtual {v1, v0, v3}, Lc/z5;->f(Ljava/lang/String;[B)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "selections/"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "-"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".json"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0, v5}, Lc/z5;->f(Ljava/lang/String;[B)V

    move-object v0, v2

    move-object v2, v4

    goto :goto_3

    :cond_2
    new-instance v0, Ljava/lang/SecurityException;

    const-string v3, "\u041a\u0430\u0442\u0430\u043b\u043e\u0433 \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u0441\u044f. \u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043d\u043e\u0432\u0430"

    invoke-direct {v0, v3}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    new-instance v0, Ljava/lang/SecurityException;

    const-string v3, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043d\u0435 \u0441\u043e\u043e\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043a\u0430\u0442\u0430\u043b\u043e\u0433\u0443"

    invoke-direct {v0, v3}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_2
    move-exception v0

    invoke-virtual {v0, v5}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    :catch_3
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c \u0438 \u043f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c \u043f\u0440\u043e\u0444\u0438\u043b\u044c. \u041f\u0440\u0435\u0434\u044b\u0434\u0443\u0449\u0438\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    :goto_3
    iget-object v1, v1, Lc/z5;->h:Landroid/os/Handler;

    new-instance v3, Lc/Z;

    iget-object v4, p0, Lc/Z;->d:Ljava/lang/Object;

    check-cast v4, Lc/y6;

    const/16 v5, 0x11

    invoke-direct {v3, v4, v2, v0, v5}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private final c()V
    .locals 10

    iget-object v0, p0, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/B0;

    iget-object v1, p0, Lc/Z;->c:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, p0, Lc/Z;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    :try_start_0
    iget-object v3, v0, Lc/B0;->a:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v4, v0, Lc/B0;->c:Ljava/lang/Object;

    check-cast v4, Lc/T5;

    :try_start_1
    invoke-virtual {v4}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    iget-object v3, v0, Lc/B0;->d:Ljava/lang/Object;

    check-cast v3, Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u0418\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e: "

    invoke-static {v1, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Lc/T5;->s0()V

    invoke-virtual {v4}, Lc/T5;->p()V

    iget-object v6, v4, Lc/T5;->h:Lc/j6;

    new-instance v7, Lc/d7;

    iget-object v8, v4, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v9, 0x1

    invoke-direct {v7, v8, v6, v2, v9}, Lc/d7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Ljava/lang/String;I)V

    invoke-static {v7}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    invoke-virtual {v4}, Lc/T5;->o0()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :catch_0
    move-exception v2

    goto :goto_0

    :cond_0
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u0441\u044f. \u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u043e\u0442\u043c\u0435\u043d\u0435\u043d\u0430"

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    :goto_0
    iget-object v0, v0, Lc/B0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    return-void
.end method

.method private final d()V
    .locals 3

    iget-object v0, p0, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/B0;

    iget-object v0, v0, Lc/B0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/Z;->d:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Exception;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2, v1}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method private final e()V
    .locals 6

    iget-object v0, p0, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    iget-object v1, p0, Lc/Z;->c:Ljava/lang/Object;

    check-cast v1, Lc/e8;

    iget-object v2, p0, Lc/Z;->d:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-boolean v3, v0, Lc/Z7;->r:Z

    if-eqz v3, :cond_0

    goto/16 :goto_1

    :cond_0
    iget-boolean v3, v0, Lc/Z7;->m:Z

    if-eqz v3, :cond_3

    iget v3, v0, Lc/Z7;->v:I

    const/4 v4, 0x2

    if-lt v3, v4, :cond_1

    const/4 v4, 0x5

    if-le v3, v4, :cond_2

    :cond_1
    const/4 v4, 0x7

    if-eq v3, v4, :cond_2

    invoke-virtual {v1}, Lc/e8;->c()Z

    move-result v3

    if-nez v3, :cond_3

    :cond_2
    invoke-virtual {v0}, Lc/Z7;->m()V

    goto :goto_0

    :cond_3
    iget-object v3, v0, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->a:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4

    iget v3, v0, Lc/Z7;->B:I

    add-int/lit8 v3, v3, 0x1

    iput v3, v0, Lc/Z7;->B:I

    const/4 v3, 0x0

    iput-boolean v3, v0, Lc/Z7;->q:Z

    :cond_4
    iget-object v3, v0, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->a:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    iget-object v3, v0, Lc/Z7;->a:Lc/e8;

    iget v4, v3, Lc/e8;->e:I

    iget v5, v1, Lc/e8;->e:I

    if-ne v4, v5, :cond_5

    iget-object v3, v3, Lc/e8;->c:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->c:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_6

    :cond_5
    iget v3, v0, Lc/Z7;->C:I

    add-int/lit8 v3, v3, 0x1

    iput v3, v0, Lc/Z7;->C:I

    :cond_6
    iget-object v3, v0, Lc/Z7;->a:Lc/e8;

    iget-object v4, v1, Lc/e8;->a:Ljava/lang/String;

    iput-object v4, v3, Lc/e8;->a:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->b:Ljava/lang/String;

    if-nez v4, :cond_7

    const-string v4, ""

    :cond_7
    iput-object v4, v3, Lc/e8;->b:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->d:Ljava/lang/String;

    iput-object v4, v3, Lc/e8;->d:Ljava/lang/String;

    iget-object v4, v1, Lc/e8;->c:Ljava/lang/String;

    iput-object v4, v3, Lc/e8;->c:Ljava/lang/String;

    iget v1, v1, Lc/e8;->e:I

    iput v1, v3, Lc/e8;->e:I

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_8

    iput-object v2, v0, Lc/Z7;->K:Ljava/lang/String;

    :cond_8
    invoke-virtual {v0}, Lc/Z7;->l()V

    iget-object v1, v0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v1}, Lc/J1;->run()V

    :goto_0
    iget-object v1, v0, Lc/Z7;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/Z7;->N:Lc/P7;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, v0, Lc/Z7;->c:Landroid/os/Handler;

    iget-object v0, v0, Lc/Z7;->N:Lc/P7;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_1
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 22

    move-object/from16 v1, p0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, v1, Lc/Z;->a:I

    packed-switch v0, :pswitch_data_0

    const-string v2, "; \u0432\u0442\u043e\u0440\u043e\u0439: "

    const-string v4, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u0438\u0437 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443. \u041f\u0435\u0440\u0432\u044b\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    move-object v14, v0

    check-cast v14, Lc/Z6;

    new-instance v15, Ljava/io/File;

    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Landroid/content/Context;

    invoke-virtual {v12}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v0

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "drivedeck-update-"

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v8, v1, Lc/Z;->c:Ljava/lang/Object;

    move-object v13, v8

    check-cast v13, Lc/U8;

    iget v8, v13, Lc/U8;->a:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, ".apk"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v15, v0, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :try_start_0
    new-instance v0, Lc/n1;

    invoke-direct {v0, v12}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->P()Ljava/lang/String;

    move-result-object v0

    iget-object v7, v13, Lc/U8;->h:Ljava/lang/String;

    invoke-virtual {v0, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_6

    const-string v11, "\u041a\u0430\u043d\u0430\u043b \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0439 \u0438\u0437\u043c\u0435\u043d\u0451\u043d. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f \u0437\u0430\u043d\u043e\u0432\u043e."

    if-eqz v0, :cond_1

    const-wide/32 v7, 0x927c0

    :try_start_1
    invoke-static {v7, v8}, Lc/T8;->a(J)J

    move-result-wide v9
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_6

    :try_start_2
    iget-object v8, v13, Lc/U8;->c:Ljava/lang/String;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    move-object v7, v12

    move-wide/from16 v16, v9

    move-object v9, v15

    move-object v10, v13

    move-object v6, v11

    move-object v11, v14

    move-object/from16 v18, v12

    move-object v5, v13

    move-wide/from16 v12, v16

    :try_start_3
    invoke-static/range {v7 .. v13}, Lc/c9;->d(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;Lc/U8;Lc/Z6;J)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    goto/16 :goto_6

    :catch_0
    move-exception v0

    :goto_0
    move-object v12, v0

    goto :goto_1

    :catch_1
    move-exception v0

    move-wide/from16 v16, v9

    move-object v6, v11

    move-object/from16 v18, v12

    move-object v5, v13

    goto :goto_0

    :goto_1
    :try_start_4
    iget-object v0, v5, Lc/U8;->c:Ljava/lang/String;

    invoke-static {v0}, Lc/k6;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v7, v5, Lc/U8;->h:Ljava/lang/String;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    move-wide/from16 v10, v16

    :try_start_5
    invoke-static {v0, v7, v10, v11}, Lc/k6;->g0(Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    move-result-object v8
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_3

    move-object/from16 v7, v18

    move-object v9, v15

    move-wide/from16 v16, v10

    move-object v10, v5

    move-object v11, v14

    move-object/from16 v20, v12

    move-wide/from16 v12, v16

    :try_start_6
    invoke-static/range {v7 .. v13}, Lc/c9;->d(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;Lc/U8;Lc/Z6;J)V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    goto :goto_6

    :catch_2
    move-exception v0

    goto :goto_3

    :catch_3
    move-exception v0

    move-wide/from16 v16, v10

    goto :goto_2

    :catch_4
    move-exception v0

    :goto_2
    move-object/from16 v20, v12

    :goto_3
    :try_start_7
    new-instance v7, Ljava/io/IOException;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object/from16 v8, v20

    invoke-virtual {v7, v8}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v7
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_5

    :goto_4
    move-object v12, v0

    goto :goto_5

    :catch_5
    move-exception v0

    goto :goto_4

    :goto_5
    :try_start_8
    invoke-static {v5}, Lc/k6;->G(Lc/U8;)Ljava/lang/String;

    move-result-object v8
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_8

    move-object/from16 v7, v18

    move-object v9, v15

    move-object v10, v5

    move-object v11, v14

    move-object/from16 v20, v12

    move-wide/from16 v12, v16

    :try_start_9
    invoke-static/range {v7 .. v13}, Lc/c9;->d(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;Lc/U8;Lc/Z6;J)V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_7

    :goto_6
    :try_start_a
    new-instance v0, Lc/n1;

    move-object/from16 v2, v18

    invoke-direct {v0, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->P()Ljava/lang/String;

    move-result-object v0

    iget-object v4, v5, Lc/U8;->h:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v15, v0}, Lc/c9;->f(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V

    new-instance v0, Lc/b1;

    invoke-direct {v0, v3}, Lc/b1;-><init>(I)V

    const/4 v2, 0x1

    invoke-virtual {v14, v0, v2}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    goto :goto_9

    :catch_6
    move-exception v0

    goto :goto_8

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :catch_7
    move-exception v0

    goto :goto_7

    :catch_8
    move-exception v0

    move-object/from16 v20, v12

    :goto_7
    new-instance v3, Ljava/io/IOException;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v3, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object/from16 v2, v20

    invoke-virtual {v3, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v3

    :cond_1
    move-object v6, v11

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, v6}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_6

    :goto_8
    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v15}, Ljava/io/File;->delete()Z

    :cond_2
    new-instance v2, Lc/W8;

    const/4 v3, 0x0

    invoke-direct {v2, v0, v3}, Lc/W8;-><init>(Ljava/lang/Exception;I)V

    const/4 v3, 0x1

    invoke-virtual {v14, v2, v3}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    :goto_9
    return-void

    :pswitch_0
    invoke-direct/range {p0 .. p0}, Lc/Z;->e()V

    return-void

    :pswitch_1
    iget-object v0, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v0, Lc/r4;

    iget-object v2, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v2, Lc/T5;

    iget-object v3, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v3, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v4, v3, v0, v2}, Lc/b7;->g(Lorg/json/JSONObject;Lru/drivedeck/launcher/MainActivity;Lc/r4;Lc/T5;)V

    return-void

    :pswitch_2
    invoke-direct/range {p0 .. p0}, Lc/Z;->d()V

    return-void

    :pswitch_3
    invoke-direct/range {p0 .. p0}, Lc/Z;->c()V

    return-void

    :pswitch_4
    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/LinkedHashMap;

    const-string v2, "FR"

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/EditText;

    if-nez v0, :cond_3

    goto/16 :goto_c

    :cond_3
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iget-object v3, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v3, Lc/T5;

    iget-object v5, v3, Lc/T5;->g:Lc/j6;

    if-eqz v5, :cond_4

    iget-object v5, v5, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v5}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_4
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_5

    goto :goto_c

    :cond_5
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5

    new-array v5, v5, [Ljava/lang/String;

    const/4 v6, 0x0

    :goto_a
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v6, v7, :cond_7

    iget-object v7, v3, Lc/T5;->g:Lc/j6;

    iget-object v7, v7, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/i6;

    if-nez v7, :cond_6

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    goto :goto_b

    :cond_6
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v7, Lc/i6;->b:Ljava/lang/String;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " \u00b7 "

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    :goto_b
    aput-object v7, v5, v6

    const/4 v7, 0x1

    add-int/2addr v6, v7

    goto :goto_a

    :cond_7
    const/4 v7, 0x1

    new-instance v3, Landroid/app/AlertDialog$Builder;

    iget-object v6, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v6, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v3, v6}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v8, "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u044c PID"

    invoke-static {v6, v8}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v3, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v3

    new-instance v8, Lc/D4;

    invoke-direct {v8, v0, v2, v7}, Lc/D4;-><init>(Landroid/view/KeyEvent$Callback;Ljava/util/ArrayList;I)V

    invoke-virtual {v3, v5, v8}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v6, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v4}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    :goto_c
    return-void

    :pswitch_5
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v0, v0, Lc/H6;->c:Lc/T5;

    invoke-virtual {v0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_8
    return-void

    :pswitch_6
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Landroid/widget/Spinner;

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v2

    iget-object v0, v0, Lc/H6;->c:Lc/T5;

    invoke-virtual {v0}, Lc/T5;->j()I

    move-result v3

    if-eq v2, v3, :cond_9

    iget-object v3, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "battery_mode"

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v0}, Lc/T5;->l()V

    :cond_9
    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Lc/x6;

    invoke-virtual {v0}, Lc/x6;->run()V

    return-void

    :pswitch_7
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/y6;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Lc/j6;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, Lc/y6;->b(Lc/j6;Ljava/lang/String;)V

    return-void

    :pswitch_8
    invoke-direct/range {p0 .. p0}, Lc/Z;->b()V

    return-void

    :pswitch_9
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/y5;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Lc/j6;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-interface {v0, v2, v3}, Lc/y5;->b(Lc/j6;Ljava/lang/String;)V

    return-void

    :pswitch_a
    invoke-direct/range {p0 .. p0}, Lc/Z;->a()V

    return-void

    :pswitch_b
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v2, Lc/F;

    if-eqz v2, :cond_a

    sget v3, Lru/drivedeck/launcher/MainActivity;->F0:I

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Lc/F;->r(Z)V

    goto :goto_d

    :cond_a
    const/4 v3, 0x0

    :goto_d
    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iget-object v5, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v5, [Landroid/app/Dialog;

    aget-object v5, v5, v3

    if-ne v2, v5, :cond_b

    iput-object v4, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iput-boolean v3, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    :cond_b
    return-void

    :pswitch_c
    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v0, v3, v2}, Lru/drivedeck/launcher/MainActivity;->w(Ljava/lang/String;I)V

    return-void

    :pswitch_d
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Landroid/net/Uri;

    iget-object v4, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v4, [B

    sget-object v5, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    :try_start_b
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v2, v4}, Lc/q4;->E(Landroid/content/Context;Landroid/net/Uri;[B)V

    new-instance v2, Lc/J1;

    invoke-direct {v2, v0, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_9
    .catchall {:try_start_b .. :try_end_b} :catchall_0

    const/4 v2, 0x0

    :goto_e
    invoke-virtual {v5, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    goto :goto_f

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    goto :goto_10

    :catch_9
    :try_start_c
    new-instance v2, Lc/J1;

    const/4 v3, 0x5

    invoke-direct {v2, v0, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    const/4 v2, 0x0

    goto :goto_e

    :goto_f
    return-void

    :goto_10
    invoke-virtual {v5, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw v0

    :pswitch_e
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v3, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v3, Landroid/net/Uri;

    iget-object v4, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    :try_start_d
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    invoke-virtual {v5, v3}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v3
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_a

    if-eqz v3, :cond_c

    const/high16 v5, 0x200000

    :try_start_e
    invoke-static {v3, v5}, Lc/q4;->d(Ljava/io/InputStream;I)[B

    move-result-object v5

    invoke-static {v0, v5}, Lc/q4;->A(Landroid/content/Context;[B)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    :try_start_f
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V

    new-instance v3, Lc/H;

    const/16 v5, 0x11

    invoke-direct {v3, v4, v0, v5}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v3}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_a

    goto :goto_12

    :catchall_1
    move-exception v0

    move-object v5, v0

    :try_start_10
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_2

    goto :goto_11

    :catchall_2
    move-exception v0

    move-object v3, v0

    :try_start_11
    invoke-virtual {v5, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_11
    throw v5

    :cond_c
    new-instance v0, Ljava/io/IOException;

    const-string v3, "\u0424\u0430\u0439\u043b \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_11} :catch_a

    :catch_a
    new-instance v0, Lc/J1;

    invoke-direct {v0, v4, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v4, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_12
    return-void

    :pswitch_f
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Lc/u2;

    :try_start_12
    invoke-static {v0}, Lc/q4;->t(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v4, v2}, Lorg/json/JSONObject;->remove(Ljava/lang/String;)Ljava/lang/Object;

    invoke-static {v0, v4}, Lc/q4;->y(Landroid/content/Context;Lorg/json/JSONObject;)V

    invoke-virtual {v3}, Lc/u2;->run()V
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_b

    goto :goto_13

    :catch_b
    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v0, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :goto_13
    return-void

    :pswitch_10
    iget-object v0, v1, Lc/Z;->c:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Landroid/content/Context;

    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lru/drivedeck/launcher/MainActivity;

    :try_start_13
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    :try_end_13
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_13} :catch_d

    iget-object v5, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v5, [B

    const-string v6, "DriveDeck-layout-"

    const-string v7, "DriveDeck-settings-"

    if-nez v5, :cond_d

    move-object v8, v7

    goto :goto_14

    :cond_d
    move-object v8, v6

    :goto_14
    :try_start_14
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-virtual {v0, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_14} :catch_d

    const-string v8, ".drivedeck-layout"

    const-string v9, ".zip"

    if-nez v5, :cond_e

    move-object v10, v9

    goto :goto_15

    :cond_e
    move-object v10, v8

    :goto_15
    :try_start_15
    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_15} :catch_d

    const-string v11, "Downloads unavailable"

    const-string v12, "is_pending"

    const-string v13, "application/vnd.drivedeck.layout+json"

    const-string v14, "application/zip"

    const/16 v15, 0x1d

    if-lt v10, v15, :cond_11

    :try_start_16
    new-instance v6, Landroid/content/ContentValues;

    invoke-direct {v6}, Landroid/content/ContentValues;-><init>()V

    const-string v7, "_display_name"

    invoke-virtual {v6, v7, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v7, "mime_type"

    if-nez v5, :cond_f

    move-object v8, v14

    goto :goto_16

    :cond_f
    move-object v8, v13

    :goto_16
    invoke-virtual {v6, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string v7, "relative_path"

    sget-object v8, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-virtual {v6, v7, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v6, v12, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v7

    invoke-static {}, Lc/A1;->e()Landroid/net/Uri;

    move-result-object v8

    invoke-virtual {v7, v8, v6}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v6
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_16} :catch_d

    if-eqz v6, :cond_10

    move-object v7, v4

    goto :goto_18

    :cond_10
    :try_start_17
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v11}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_17 .. :try_end_17} :catch_c

    :catch_c
    move-exception v0

    move-object v5, v0

    move-object v0, v6

    move-object v6, v4

    goto/16 :goto_1b

    :catch_d
    move-exception v0

    move-object v5, v0

    move-object v0, v4

    move-object v6, v0

    goto/16 :goto_1b

    :cond_11
    :try_start_18
    sget-object v0, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-static {v0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v16

    if-nez v16, :cond_13

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v16

    if-eqz v16, :cond_12

    goto :goto_17

    :cond_12
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, v11}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_13
    :goto_17
    if-nez v5, :cond_14

    move-object v6, v7

    :cond_14
    if-nez v5, :cond_15

    move-object v8, v9

    :cond_15
    invoke-static {v6, v8, v0}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v6
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_18} :catch_d

    :try_start_19
    invoke-virtual {v6}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v6}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v7
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_19} :catch_f

    move-object/from16 v21, v7

    move-object v7, v6

    move-object/from16 v6, v21

    :goto_18
    if-nez v5, :cond_16

    :try_start_1a
    invoke-static {v2, v6}, Lc/q4;->k(Landroid/content/Context;Landroid/net/Uri;)V

    goto :goto_19

    :catch_e
    move-exception v0

    move-object v5, v0

    move-object v0, v6

    move-object v6, v7

    goto :goto_1b

    :cond_16
    invoke-static {v2, v6, v5}, Lc/q4;->E(Landroid/content/Context;Landroid/net/Uri;[B)V

    :goto_19
    if-lt v10, v15, :cond_18

    new-instance v5, Landroid/content/ContentValues;

    invoke-direct {v5}, Landroid/content/ContentValues;-><init>()V

    const/4 v8, 0x0

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v5, v12, v8}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v8

    invoke-virtual {v8, v6, v5, v4, v4}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x1

    if-ne v5, v8, :cond_17

    goto :goto_1a

    :cond_17
    new-instance v0, Ljava/io/IOException;

    const-string v5, "Cannot publish backup"

    invoke-direct {v0, v5}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_18
    invoke-virtual {v7}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v8

    filled-new-array {v8}, [Ljava/lang/String;

    move-result-object v8

    if-nez v5, :cond_19

    move-object v13, v14

    :cond_19
    filled-new-array {v13}, [Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v8, v5, v4}, Landroid/media/MediaScannerConnection;->scanFile(Landroid/content/Context;[Ljava/lang/String;[Ljava/lang/String;Landroid/media/MediaScannerConnection$OnScanCompletedListener;)V

    :goto_1a
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v8, Landroid/os/Environment;->DIRECTORY_DOWNLOADS:Ljava/lang/String;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "/"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v5, Lc/H;

    const/16 v8, 0x12

    invoke-direct {v5, v3, v0, v8}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v5}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_1a} :catch_e

    goto :goto_1e

    :catch_f
    move-exception v0

    move-object v5, v0

    move-object v0, v4

    :goto_1b
    const-string v7, "DriveDeck"

    const-string v8, "Configuration Downloads export failed"

    invoke-static {v7, v8, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    if-eqz v6, :cond_1a

    :try_start_1b
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    goto :goto_1d

    :catch_10
    move-exception v0

    goto :goto_1c

    :cond_1a
    if-eqz v0, :cond_1b

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-virtual {v2, v0, v4, v4}, Landroid/content/ContentResolver;->delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_1b
    .catch Ljava/lang/RuntimeException; {:try_start_1b .. :try_end_1b} :catch_10

    goto :goto_1d

    :goto_1c
    const-string v2, "Cannot remove incomplete backup"

    invoke-static {v7, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1b
    :goto_1d
    new-instance v0, Lc/J1;

    const/16 v2, 0xb

    invoke-direct {v0, v3, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v3, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_1e
    return-void

    :pswitch_11
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Lorg/json/JSONObject;

    :try_start_1c
    invoke-static {v0}, Lc/q4;->t(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v4

    const-string v5, "snapshot"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    invoke-virtual {v4, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {v0, v4}, Lc/q4;->y(Landroid/content/Context;Lorg/json/JSONObject;)V

    const-string v2, "\u041a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0430 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0430"

    invoke-static {v0, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v2, :cond_1c

    invoke-virtual {v2}, Landroid/app/Dialog;->isShowing()Z

    move-result v2

    if-eqz v2, :cond_1c

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    const-string v3, "home"

    iput-object v3, v2, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v2}, Lc/k3;->X()V

    goto :goto_1f

    :cond_1c
    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->K()V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_1c} :catch_11

    goto :goto_1f

    :catch_11
    const-string v2, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v0, v2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :goto_1f
    return-void

    :pswitch_12
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Lc/n1;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v3}, Lc/n1;->H0(Ljava/lang/String;)V

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_13
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, [Z

    const/4 v2, 0x0

    aget-boolean v3, v0, v2

    if-eqz v3, :cond_1d

    goto :goto_20

    :cond_1d
    iget-object v3, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v3, [I

    aget v4, v3, v2

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    aput v4, v3, v2

    if-eqz v4, :cond_1e

    goto :goto_20

    :cond_1e
    aput-boolean v5, v0, v2

    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    if-eqz v0, :cond_1f

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_1f
    :goto_20
    return-void

    :pswitch_14
    invoke-static {}, Lc/N1;->B()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Landroid/app/Activity;

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {}, Lc/N1;->s()I

    move-result v0

    if-lez v0, :cond_20

    invoke-static {}, Lc/N1;->p()Z

    move-result v0

    if-nez v0, :cond_20

    invoke-static {}, Lc/N1;->o()Z

    move-result v0

    if-nez v0, :cond_20

    const/4 v5, 0x1

    goto :goto_21

    :cond_20
    const/4 v5, 0x0

    :goto_21
    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Landroid/widget/Button;

    invoke-virtual {v0, v5}, Landroid/view/View;->setEnabled(Z)V

    return-void

    :pswitch_15
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Lc/N1;

    iget-object v0, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v0, Landroid/net/Uri;

    iget-object v4, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v4, Lc/y4;

    new-instance v5, Ljava/io/File;

    iget-object v6, v2, Lc/N1;->a:Lru/drivedeck/launcher/DriveDeckApplication;

    invoke-virtual {v6}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v6

    const-string v7, "diagnostic-import.apk"

    invoke-direct {v5, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    :try_start_1d
    iget-object v6, v2, Lc/N1;->a:Lru/drivedeck/launcher/DriveDeckApplication;

    invoke-virtual {v6}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    invoke-virtual {v6, v0}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v6
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_1d} :catch_13
    .catch Ljava/lang/LinkageError; {:try_start_1d .. :try_end_1d} :catch_13
    .catchall {:try_start_1d .. :try_end_1d} :catchall_a

    if-eqz v6, :cond_28

    :try_start_1e
    new-instance v0, Ljava/io/BufferedInputStream;

    invoke-direct {v0, v6}, Ljava/io/BufferedInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0, v3}, Ljava/io/BufferedInputStream;->mark(I)V

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->read()I

    move-result v3

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->read()I

    move-result v7

    invoke-virtual {v0}, Ljava/io/BufferedInputStream;->reset()V

    const/16 v8, 0x50

    const/16 v9, 0x4000

    const-wide/16 v10, 0x0

    if-ne v3, v8, :cond_26

    const/16 v3, 0x4b

    if-ne v7, v3, :cond_26

    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_5

    const/16 v7, 0x2000

    :try_start_1f
    new-array v7, v7, [B

    move-wide v12, v10

    :goto_22
    invoke-virtual {v0, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    const/4 v14, -0x1

    if-eq v8, v14, :cond_22

    int-to-long v14, v8

    add-long/2addr v12, v14

    const-wide/32 v14, 0x1000000

    cmp-long v14, v12, v14

    if-gtz v14, :cond_21

    const/4 v14, 0x0

    invoke-virtual {v3, v7, v14, v8}, Ljava/io/FileOutputStream;->write([BII)V

    goto :goto_22

    :catchall_3
    move-exception v0

    move-object v7, v0

    goto :goto_27

    :cond_21
    new-instance v0, Ljava/io/IOException;

    const-string v7, "Import limit"

    invoke-direct {v0, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_3

    :cond_22
    :try_start_20
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V

    new-instance v3, Ljava/util/zip/ZipFile;

    invoke-direct {v3, v5}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_5

    :try_start_21
    const-string v0, "assets/diagnostics-profile.json"

    invoke-virtual {v3, v0}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object v0

    if-eqz v0, :cond_25

    invoke-virtual {v3, v0}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    move-result-object v7
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_4

    :try_start_22
    invoke-static {v7, v9}, Lc/T8;->c(Ljava/io/InputStream;I)[B

    move-result-object v0
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_6

    if-eqz v7, :cond_23

    :try_start_23
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_4

    goto :goto_23

    :catchall_4
    move-exception v0

    move-object v7, v0

    goto :goto_25

    :cond_23
    :goto_23
    :try_start_24
    invoke-virtual {v3}, Ljava/util/zip/ZipFile;->close()V
    :try_end_24
    .catchall {:try_start_24 .. :try_end_24} :catchall_5

    goto :goto_29

    :catchall_5
    move-exception v0

    move-object v3, v0

    goto/16 :goto_2a

    :catchall_6
    move-exception v0

    move-object v8, v0

    if-eqz v7, :cond_24

    :try_start_25
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_25
    .catchall {:try_start_25 .. :try_end_25} :catchall_7

    goto :goto_24

    :catchall_7
    move-exception v0

    move-object v7, v0

    :try_start_26
    invoke-virtual {v8, v7}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_24
    :goto_24
    throw v8

    :cond_25
    new-instance v0, Ljava/io/IOException;

    const-string v7, "No enrollment"

    invoke-direct {v0, v7}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_26
    .catchall {:try_start_26 .. :try_end_26} :catchall_4

    :goto_25
    :try_start_27
    invoke-virtual {v3}, Ljava/util/zip/ZipFile;->close()V
    :try_end_27
    .catchall {:try_start_27 .. :try_end_27} :catchall_8

    goto :goto_26

    :catchall_8
    move-exception v0

    move-object v3, v0

    :try_start_28
    invoke-virtual {v7, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_26
    throw v7
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_5

    :goto_27
    :try_start_29
    invoke-virtual {v3}, Ljava/io/FileOutputStream;->close()V
    :try_end_29
    .catchall {:try_start_29 .. :try_end_29} :catchall_9

    goto :goto_28

    :catchall_9
    move-exception v0

    move-object v3, v0

    :try_start_2a
    invoke-virtual {v7, v3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_28
    throw v7

    :cond_26
    invoke-static {v0, v9}, Lc/T8;->c(Ljava/io/InputStream;I)[B

    move-result-object v0

    :goto_29
    new-instance v3, Lc/v1;

    new-instance v7, Ljava/lang/String;

    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v7, v0, v8}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v3, v7}, Lc/v1;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3}, Lc/v1;->a()Z

    move-result v7

    if-eqz v7, :cond_27

    invoke-virtual {v2, v0}, Lc/N1;->x([B)V

    iput-object v3, v2, Lc/N1;->J:Lc/v1;

    iget-object v0, v2, Lc/N1;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v3, "retry_at"

    invoke-interface {v0, v3, v10, v11}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v3, 0x1

    invoke-static {v3}, Lc/N1;->A(Z)V
    :try_end_2a
    .catchall {:try_start_2a .. :try_end_2a} :catchall_5

    :try_start_2b
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V
    :try_end_2b
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_2b} :catch_12
    .catch Ljava/lang/LinkageError; {:try_start_2b .. :try_end_2b} :catch_12
    .catchall {:try_start_2b .. :try_end_2b} :catchall_a

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    const/4 v5, 0x1

    goto :goto_2d

    :catchall_a
    move-exception v0

    goto :goto_2e

    :catch_12
    const/16 v19, 0x1

    goto :goto_2c

    :cond_27
    :try_start_2c
    new-instance v0, Ljava/lang/SecurityException;

    const-string v3, "Expired enrollment"

    invoke-direct {v0, v3}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_28
    new-instance v0, Ljava/io/IOException;

    const-string v3, "No input"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_2c
    .catchall {:try_start_2c .. :try_end_2c} :catchall_5

    :goto_2a
    if-eqz v6, :cond_29

    :try_start_2d
    invoke-virtual {v6}, Ljava/io/InputStream;->close()V
    :try_end_2d
    .catchall {:try_start_2d .. :try_end_2d} :catchall_b

    goto :goto_2b

    :catchall_b
    move-exception v0

    move-object v6, v0

    :try_start_2e
    invoke-virtual {v3, v6}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    goto :goto_2b

    :catch_13
    const/16 v19, 0x0

    goto :goto_2c

    :cond_29
    :goto_2b
    throw v3
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_2e .. :try_end_2e} :catch_13
    .catch Ljava/lang/LinkageError; {:try_start_2e .. :try_end_2e} :catch_13
    .catchall {:try_start_2e .. :try_end_2e} :catchall_a

    :goto_2c
    :try_start_2f
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c: \u043d\u0443\u0436\u0435\u043d \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044e\u0449\u0438\u0439 \u043f\u0440\u0438\u0432\u0430\u0442\u043d\u044b\u0439 \u043f\u0440\u043e\u0444\u0438\u043b\u044c \u0438\u043b\u0438 \u0441\u0442\u0430\u0440\u044b\u0439 \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 APK"

    iput-object v0, v2, Lc/N1;->R:Ljava/lang/String;
    :try_end_2f
    .catchall {:try_start_2f .. :try_end_2f} :catchall_a

    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    move/from16 v5, v19

    :goto_2d
    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    new-instance v2, Lc/K1;

    const/4 v3, 0x0

    invoke-direct {v2, v4, v5, v3}, Lc/K1;-><init>(Ljava/lang/Object;ZI)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :goto_2e
    invoke-virtual {v5}, Ljava/io/File;->delete()Z

    throw v0

    :pswitch_16
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/N1;

    iget-object v2, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/MainActivity;

    iget-object v3, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v3, Landroid/net/Uri;

    :try_start_30
    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v4

    if-eqz v4, :cond_2a

    invoke-virtual {v0}, Lc/N1;->w()V

    const/4 v4, 0x0

    invoke-virtual {v0, v4}, Lc/N1;->l(Z)V

    :cond_2a
    iget-object v4, v0, Lc/N1;->I:Lc/y1;

    monitor-enter v4
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_30} :catch_14

    :try_start_31
    iget-object v5, v0, Lc/N1;->I:Lc/y1;

    invoke-virtual {v5}, Lc/y1;->a()[Ljava/io/File;

    move-result-object v5

    array-length v5, v5

    if-eqz v5, :cond_2c

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    const-string v6, "wt"

    invoke-virtual {v5, v3, v6}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object v3

    if-eqz v3, :cond_2b

    iget-object v0, v0, Lc/N1;->I:Lc/y1;

    invoke-static {v3, v0}, Lc/N1;->G(Ljava/io/OutputStream;Lc/y1;)V

    monitor-exit v4
    :try_end_31
    .catchall {:try_start_31 .. :try_end_31} :catchall_c

    :try_start_32
    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    new-instance v3, Lc/J1;

    const/4 v4, 0x0

    invoke-direct {v3, v2, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_32
    .catch Ljava/lang/Exception; {:try_start_32 .. :try_end_32} :catch_14

    goto :goto_30

    :catchall_c
    move-exception v0

    goto :goto_2f

    :cond_2b
    :try_start_33
    new-instance v0, Ljava/io/IOException;

    const-string v3, "Document unavailable"

    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2c
    new-instance v0, Ljava/io/FileNotFoundException;

    const-string v3, "No queued reports"

    invoke-direct {v0, v3}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_2f
    monitor-exit v4
    :try_end_33
    .catchall {:try_start_33 .. :try_end_33} :catchall_c

    :try_start_34
    throw v0
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_34 .. :try_end_34} :catch_14

    :catch_14
    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    new-instance v3, Lc/J1;

    const/4 v4, 0x1

    invoke-direct {v3, v2, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_30
    return-void

    :pswitch_17
    iget-object v0, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v0, Lc/o1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v3, Landroid/os/IBinder;

    if-eqz v3, :cond_2d

    :try_start_35
    iget-object v0, v0, Lc/o1;->l:Lc/O;

    invoke-static {v3, v2, v0}, Lc/o1;->e(Landroid/os/IBinder;ILandroid/os/Binder;)Landroid/os/Parcel;
    :try_end_35
    .catch Landroid/os/RemoteException; {:try_start_35 .. :try_end_35} :catch_15
    .catch Ljava/lang/RuntimeException; {:try_start_35 .. :try_end_35} :catch_15

    :catch_15
    :cond_2d
    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void

    :pswitch_18
    iget-object v0, v1, Lc/Z;->d:Ljava/lang/Object;

    check-cast v0, Landroid/appwidget/AppWidgetProviderInfo;

    iget-object v2, v1, Lc/Z;->b:Ljava/lang/Object;

    check-cast v2, Lc/e0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v1, Lc/Z;->c:Ljava/lang/Object;

    check-cast v3, [Landroid/app/Dialog;

    const/4 v4, 0x0

    aget-object v3, v3, v4

    invoke-virtual {v3}, Landroid/app/Dialog;->dismiss()V

    iget-object v3, v2, Lc/e0;->b:Lc/n1;

    iget-object v5, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    const-string v6, "pending_home_android_widget_id"

    invoke-interface {v5, v6, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    iget-object v5, v2, Lc/e0;->d:Lc/b0;

    if-lez v4, :cond_2e

    invoke-virtual {v3}, Lc/n1;->o()Ljava/util/ArrayList;

    move-result-object v7

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_2e

    :try_start_36
    invoke-virtual {v5, v4}, Landroid/appwidget/AppWidgetHost;->deleteAppWidgetId(I)V
    :try_end_36
    .catch Ljava/lang/RuntimeException; {:try_start_36 .. :try_end_36} :catch_16

    :catch_16
    :cond_2e
    :try_start_37
    invoke-virtual {v5}, Landroid/appwidget/AppWidgetHost;->allocateAppWidgetId()I

    move-result v4
    :try_end_37
    .catch Ljava/lang/RuntimeException; {:try_start_37 .. :try_end_37} :catch_19

    iget-object v3, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3, v6, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v3

    if-nez v3, :cond_2f

    :try_start_38
    invoke-virtual {v5, v4}, Landroid/appwidget/AppWidgetHost;->deleteAppWidgetId(I)V
    :try_end_38
    .catch Ljava/lang/RuntimeException; {:try_start_38 .. :try_end_38} :catch_17

    :catch_17
    invoke-virtual {v2}, Lc/e0;->i()V

    goto :goto_31

    :cond_2f
    new-instance v3, Landroid/os/Bundle;

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string v5, "appWidgetCategory"

    const/4 v6, 0x1

    invoke-virtual {v3, v5, v6}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :try_start_39
    iget-object v5, v2, Lc/e0;->c:Landroid/appwidget/AppWidgetManager;

    iget-object v6, v0, Landroid/appwidget/AppWidgetProviderInfo;->provider:Landroid/content/ComponentName;

    invoke-virtual {v5, v4, v6, v3}, Landroid/appwidget/AppWidgetManager;->bindAppWidgetIdIfAllowed(ILandroid/content/ComponentName;Landroid/os/Bundle;)Z

    move-result v5

    if-eqz v5, :cond_30

    invoke-virtual {v2, v4}, Lc/e0;->e(I)V

    goto :goto_31

    :cond_30
    new-instance v5, Landroid/content/Intent;

    const-string v6, "android.appwidget.action.APPWIDGET_BIND"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v6, "appWidgetId"

    invoke-virtual {v5, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v4

    const-string v5, "appWidgetProvider"

    iget-object v0, v0, Landroid/appwidget/AppWidgetProviderInfo;->provider:Landroid/content/ComponentName;

    invoke-virtual {v4, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object v0

    const-string v4, "appWidgetOptions"

    invoke-virtual {v0, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    move-result-object v0

    iget-object v3, v2, Lc/e0;->a:Lru/drivedeck/launcher/MainActivity;

    const/16 v4, 0x1ceb

    invoke-virtual {v3, v0, v4}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_39
    .catch Landroid/content/ActivityNotFoundException; {:try_start_39 .. :try_end_39} :catch_18
    .catch Ljava/lang/SecurityException; {:try_start_39 .. :try_end_39} :catch_18

    goto :goto_31

    :catch_18
    invoke-virtual {v2}, Lc/e0;->c()V

    invoke-virtual {v2}, Lc/e0;->i()V

    goto :goto_31

    :catch_19
    invoke-virtual {v2}, Lc/e0;->i()V

    :goto_31
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
