.class public final Lc/g3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic a:Landroid/widget/LinearLayout;

.field public final synthetic b:Lc/c0;

.field public final synthetic c:Landroid/widget/LinearLayout;

.field public final synthetic d:I

.field public final synthetic e:I

.field public final synthetic f:Lc/k3;


# direct methods
.method public constructor <init>(Lc/k3;Landroid/widget/LinearLayout;Lc/c0;Landroid/widget/LinearLayout;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/g3;->f:Lc/k3;

    iput-object p2, p0, Lc/g3;->a:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lc/g3;->b:Lc/c0;

    iput-object p4, p0, Lc/g3;->c:Landroid/widget/LinearLayout;

    iput p5, p0, Lc/g3;->d:I

    iput p6, p0, Lc/g3;->e:I

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 8

    iget-object v0, p0, Lc/g3;->a:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    iget-object v1, p0, Lc/g3;->f:Lc/k3;

    iget-object v2, v1, Lc/k3;->j:Landroid/widget/LinearLayout;

    const/4 v3, 0x1

    if-ne v2, v0, :cond_1

    iget-object v2, v1, Lc/k3;->l:Lc/c0;

    iget-object v4, p0, Lc/g3;->b:Lc/c0;

    if-ne v2, v4, :cond_1

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    new-array v2, v2, [F

    fill-array-data v2, :array_0

    invoke-static {v2}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v2

    iput-object v2, v1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    const-wide/16 v4, 0xf0

    invoke-virtual {v2, v4, v5}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    iget-object v2, v1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    new-instance v4, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v4}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    invoke-virtual {v2, v4}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    iget-object v2, v1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    new-instance v4, Lc/b3;

    iget-object v5, p0, Lc/g3;->c:Landroid/widget/LinearLayout;

    iget v6, p0, Lc/g3;->d:I

    iget v7, p0, Lc/g3;->e:I

    invoke-direct {v4, v5, v6, v7, v0}, Lc/b3;-><init>(Landroid/widget/LinearLayout;IILandroid/widget/LinearLayout;)V

    invoke-virtual {v2, v4}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    iget-object v0, v1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    new-instance v2, Lc/c3;

    invoke-direct {v2, p0}, Lc/c3;-><init>(Lc/g3;)V

    invoke-virtual {v0, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    iget-object v0, v1, Lc/k3;->n:Landroid/animation/ValueAnimator;

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    :cond_1
    :goto_0
    return v3

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method
