.class public interface abstract Lc/h7;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract run()Ljava/lang/Object;
.end method
