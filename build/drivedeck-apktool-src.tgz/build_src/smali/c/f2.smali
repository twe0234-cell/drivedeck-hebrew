.class public interface abstract Lc/f2;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lc/a;)V
.end method
