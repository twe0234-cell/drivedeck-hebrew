.class public final synthetic Lc/X8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:J

.field public final synthetic c:Lc/n1;

.field public final synthetic d:Ljava/lang/Exception;


# direct methods
.method public synthetic constructor <init>(JLc/n1;Ljava/lang/Exception;I)V
    .locals 0

    iput p5, p0, Lc/X8;->a:I

    iput-wide p1, p0, Lc/X8;->b:J

    iput-object p3, p0, Lc/X8;->c:Lc/n1;

    iput-object p4, p0, Lc/X8;->d:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 4

    iget v0, p0, Lc/X8;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lc/a9;

    iget-object v0, p0, Lc/X8;->c:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->Q()J

    move-result-wide v0

    iget-wide v2, p0, Lc/X8;->b:J

    cmp-long v0, v2, v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/X8;->d:Ljava/lang/Exception;

    invoke-static {v0}, Lc/c9;->j(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, v0}, Lc/a9;->a(Ljava/lang/String;)V

    :cond_0
    return-void

    :pswitch_0
    check-cast p1, Lc/P8;

    iget-object v0, p0, Lc/X8;->c:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->Q()J

    move-result-wide v0

    iget-wide v2, p0, Lc/X8;->b:J

    cmp-long v0, v2, v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/X8;->d:Ljava/lang/Exception;

    invoke-static {v0}, Lc/c9;->j(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p1, Lc/P8;->c:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p1, Lc/P8;->b:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p1, p1, Lc/P8;->a:Landroid/widget/Button;

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setEnabled(Z)V

    :cond_1
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
