.class public final Lc/g0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/P3;

.field public final b:Lc/n1;

.field public final c:Lc/z;

.field public final d:Lc/E3;

.field public final e:Landroid/graphics/Paint;

.field public final f:Ljava/util/ArrayList;

.field public final g:Ljava/util/ArrayList;

.field public h:Ljava/util/ArrayList;

.field public final i:Landroid/graphics/RectF;

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:F

.field public o:F

.field public p:F

.field public q:F

.field public r:Z

.field public s:Z

.field public t:Lc/j;


# direct methods
.method public constructor <init>(Lc/P3;Lc/n1;Lc/z;Lc/E3;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/g0;->e:Landroid/graphics/Paint;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/g0;->f:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/g0;->g:Ljava/util/ArrayList;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/g0;->i:Landroid/graphics/RectF;

    const/4 v0, -0x1

    iput v0, p0, Lc/g0;->j:I

    iput v0, p0, Lc/g0;->k:I

    iput v0, p0, Lc/g0;->l:I

    iput-object p1, p0, Lc/g0;->a:Lc/P3;

    iput-object p2, p0, Lc/g0;->b:Lc/n1;

    iput-object p3, p0, Lc/g0;->c:Lc/z;

    iput-object p4, p0, Lc/g0;->d:Lc/E3;

    invoke-virtual {p2}, Lc/n1;->U()Ljava/util/ArrayList;

    move-result-object p1

    iput-object p1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {p3}, Lc/z;->c()Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a(I)Landroid/graphics/RectF;
    .locals 2

    if-ltz p1, :cond_0

    iget-object v0, p0, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_0

    new-instance v1, Landroid/graphics/RectF;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-direct {v1, p1}, Landroid/graphics/RectF;-><init>(Landroid/graphics/RectF;)V

    goto :goto_0

    :cond_0
    new-instance v1, Landroid/graphics/RectF;

    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    :goto_0
    return-object v1
.end method

.method public final b(I)Z
    .locals 1

    if-ltz p1, :cond_1

    iget-object v0, p0, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    iget-object v0, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    iget-object v0, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object v0, p0, Lc/g0;->c:Lc/z;

    invoke-virtual {v0, p1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p1

    if-eqz p1, :cond_1

    :cond_0
    const/4 p1, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final c()V
    .locals 9

    iget-boolean v0, p0, Lc/g0;->s:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget v1, p0, Lc/g0;->m:I

    if-lt v0, v1, :cond_0

    goto :goto_1

    :cond_0
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, p0, Lc/g0;->c:Lc/z;

    invoke-virtual {v0}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/a;

    iget-object v2, p0, Lc/g0;->h:Ljava/util/ArrayList;

    iget-object v4, v1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/g0;->s:Z

    iget-object v0, p0, Lc/g0;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    new-instance v5, Lc/f0;

    invoke-direct {v5, p0}, Lc/f0;-><init>(Ljava/lang/Object;)V

    new-instance v6, Lc/i;

    const/4 v0, 0x2

    invoke-direct {v6, p0, v0}, Lc/i;-><init>(Ljava/lang/Object;I)V

    const/4 v7, 0x0

    const-string v4, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    const/4 v8, 0x0

    invoke-static/range {v2 .. v8}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    move-result-object v0

    iput-object v0, p0, Lc/g0;->t:Lc/j;

    :cond_3
    :goto_1
    return-void
.end method

.method public final d(F)F
    .locals 1

    iget-object v0, p0, Lc/g0;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p1

    return p1
.end method

.method public final e(Landroid/graphics/Canvas;Landroid/graphics/RectF;ZLc/r4;)V
    .locals 21

    move-object/from16 v8, p0

    move-object/from16 v9, p2

    iget-object v0, v8, Lc/g0;->i:Landroid/graphics/RectF;

    invoke-virtual {v0, v9}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    iget-object v10, v8, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v10}, Ljava/util/ArrayList;->clear()V

    iget-object v11, v8, Lc/g0;->g:Ljava/util/ArrayList;

    invoke-virtual {v11}, Ljava/util/ArrayList;->clear()V

    iget-object v0, v8, Lc/g0;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->V()I

    move-result v0

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v8, v2}, Lc/g0;->d(F)F

    move-result v3

    const/high16 v4, 0x40800000    # 4.0f

    mul-float v5, v3, v4

    sub-float/2addr v1, v5

    const/high16 v12, 0x3f000000    # 0.5f

    add-float/2addr v1, v12

    int-to-float v0, v0

    add-float v5, v0, v4

    mul-float/2addr v3, v5

    div-float/2addr v1, v3

    float-to-int v1, v1

    const/4 v3, 0x1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v13

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v1

    invoke-virtual {v8, v2}, Lc/g0;->d(F)F

    move-result v2

    mul-float v6, v2, v4

    sub-float/2addr v1, v6

    add-float/2addr v1, v12

    mul-float/2addr v5, v2

    div-float/2addr v1, v5

    float-to-int v1, v1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    mul-int v2, v13, v1

    iput v2, v8, Lc/g0;->m:I

    iget-object v5, v8, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    iget-object v6, v8, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    iget v7, v8, Lc/g0;->m:I

    const/4 v14, 0x0

    if-ge v6, v7, :cond_0

    goto :goto_0

    :cond_0
    move v3, v14

    :goto_0
    add-int/2addr v5, v3

    invoke-static {v2, v5}, Ljava/lang/Math;->min(II)I

    move-result v15

    const/high16 v7, 0x40000000    # 2.0f

    invoke-virtual {v8, v7}, Lc/g0;->d(F)F

    move-result v16

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float v3, v16, v7

    sub-float/2addr v2, v3

    int-to-float v3, v13

    div-float v17, v2, v3

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    invoke-virtual {v8, v4}, Lc/g0;->d(F)F

    move-result v3

    sub-float/2addr v2, v3

    int-to-float v1, v1

    div-float v18, v2, v1

    const/high16 v1, 0x41a00000    # 20.0f

    invoke-virtual {v8, v1}, Lc/g0;->d(F)F

    move-result v1

    invoke-virtual {v8, v0}, Lc/g0;->d(F)F

    move-result v0

    invoke-virtual {v8, v4}, Lc/g0;->d(F)F

    move-result v2

    sub-float v2, v17, v2

    invoke-virtual {v8, v4}, Lc/g0;->d(F)F

    move-result v3

    sub-float v3, v18, v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v19

    :goto_1
    if-ge v14, v15, :cond_2

    iget v0, v9, Landroid/graphics/RectF;->left:F

    add-float v0, v0, v16

    rem-int v1, v14, v13

    int-to-float v1, v1

    add-float/2addr v1, v12

    mul-float v1, v1, v17

    add-float v3, v1, v0

    iget v0, v9, Landroid/graphics/RectF;->top:F

    invoke-virtual {v8, v7}, Lc/g0;->d(F)F

    move-result v1

    add-float/2addr v1, v0

    div-int v0, v14, v13

    int-to-float v0, v0

    mul-float v0, v0, v18

    add-float/2addr v0, v1

    mul-float v1, v18, v12

    add-float v4, v1, v0

    new-instance v0, Landroid/graphics/RectF;

    div-float v1, v17, v7

    sub-float v2, v3, v1

    div-float v5, v18, v7

    sub-float v6, v4, v5

    add-float/2addr v1, v3

    add-float/2addr v5, v4

    invoke-direct {v0, v2, v6, v1, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v10, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v0, Landroid/graphics/RectF;

    div-float v1, v19, v7

    add-float v2, v3, v1

    const/high16 v5, 0x41c00000    # 24.0f

    invoke-virtual {v8, v5}, Lc/g0;->d(F)F

    move-result v5

    sub-float v5, v2, v5

    sub-float v1, v4, v1

    const/high16 v6, 0x41200000    # 10.0f

    invoke-virtual {v8, v6}, Lc/g0;->d(F)F

    move-result v6

    sub-float v6, v1, v6

    const/high16 v7, 0x41600000    # 14.0f

    invoke-virtual {v8, v7}, Lc/g0;->d(F)F

    move-result v7

    add-float/2addr v7, v2

    const/high16 v2, 0x41e00000    # 28.0f

    invoke-virtual {v8, v2}, Lc/g0;->d(F)F

    move-result v2

    add-float/2addr v2, v1

    invoke-direct {v0, v5, v6, v7, v2}, Landroid/graphics/RectF;-><init>(FFFF)V

    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget v0, v8, Lc/g0;->k:I

    if-ne v14, v0, :cond_1

    const/high16 v20, 0x40000000    # 2.0f

    goto :goto_2

    :cond_1
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v14

    move/from16 v5, v19

    move/from16 v6, p3

    const/high16 v20, 0x40000000    # 2.0f

    move-object/from16 v7, p4

    invoke-virtual/range {v0 .. v7}, Lc/g0;->h(Landroid/graphics/Canvas;IFFFZLc/r4;)V

    :goto_2
    add-int/lit8 v14, v14, 0x1

    move/from16 v7, v20

    goto :goto_1

    :cond_2
    iget v2, v8, Lc/g0;->k:I

    if-ltz v2, :cond_3

    iget v3, v8, Lc/g0;->p:F

    iget v4, v8, Lc/g0;->q:F

    const/4 v6, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v5, v19

    move-object/from16 v7, p4

    invoke-virtual/range {v0 .. v7}, Lc/g0;->h(Landroid/graphics/Canvas;IFFFZLc/r4;)V

    :cond_3
    return-void
.end method

.method public final f(Landroid/view/MotionEvent;)Z
    .locals 10

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    iget-object v2, p0, Lc/g0;->g:Ljava/util/ArrayList;

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_2

    invoke-virtual {p0, v0, v1}, Lc/g0;->g(FF)I

    move-result p1

    iput p1, p0, Lc/g0;->j:I

    if-gez p1, :cond_0

    return v4

    :cond_0
    iput v0, p0, Lc/g0;->p:F

    iput v0, p0, Lc/g0;->n:F

    iput v1, p0, Lc/g0;->q:F

    iput v1, p0, Lc/g0;->o:F

    iput-boolean v4, p0, Lc/g0;->r:Z

    iget-object v4, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge p1, v4, :cond_1

    iget p1, p0, Lc/g0;->j:I

    invoke-virtual {v2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/graphics/RectF;

    invoke-virtual {p1, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result p1

    if-eqz p1, :cond_1

    iget v3, p0, Lc/g0;->j:I

    :cond_1
    iput v3, p0, Lc/g0;->l:I

    return v5

    :cond_2
    iget v6, p0, Lc/g0;->j:I

    if-gez v6, :cond_3

    return v4

    :cond_3
    const/4 v6, 0x3

    iget-object v7, p0, Lc/g0;->a:Lc/P3;

    if-eq p1, v6, :cond_c

    const/4 v6, 0x5

    if-ne p1, v6, :cond_4

    goto/16 :goto_1

    :cond_4
    const/4 v6, 0x2

    if-ne p1, v6, :cond_7

    iget-boolean p1, p0, Lc/g0;->r:Z

    iget v2, p0, Lc/g0;->n:F

    sub-float v2, v0, v2

    float-to-double v2, v2

    iget v6, p0, Lc/g0;->o:F

    sub-float v6, v1, v6

    float-to-double v8, v6

    invoke-static {v2, v3, v8, v9}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v2

    invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v6

    int-to-double v8, v6

    cmpl-double v2, v2, v8

    if-lez v2, :cond_5

    move v4, v5

    :cond_5
    or-int/2addr p1, v4

    iput-boolean p1, p0, Lc/g0;->r:Z

    if-eqz p1, :cond_6

    iget p1, p0, Lc/g0;->l:I

    if-gez p1, :cond_6

    iget p1, p0, Lc/g0;->j:I

    iget-object v2, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge p1, v2, :cond_6

    iget p1, p0, Lc/g0;->j:I

    iput p1, p0, Lc/g0;->k:I

    iput v0, p0, Lc/g0;->p:F

    iput v1, p0, Lc/g0;->q:F

    :cond_6
    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    return v5

    :cond_7
    if-ne p1, v5, :cond_b

    invoke-virtual {p0, v0, v1}, Lc/g0;->g(FF)I

    move-result p1

    iget v4, p0, Lc/g0;->k:I

    iget-object v6, p0, Lc/g0;->b:Lc/n1;

    if-ltz v4, :cond_8

    if-ltz p1, :cond_8

    iget-object v4, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    iget v8, p0, Lc/g0;->m:I

    invoke-static {v4, v8}, Ljava/lang/Math;->min(II)I

    move-result v4

    if-ge p1, v4, :cond_8

    iget-object v0, p0, Lc/g0;->h:Ljava/util/ArrayList;

    iget v1, p0, Lc/g0;->k:I

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v1, p1, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget-object p1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v6, p1}, Lc/n1;->W0(Ljava/util/ArrayList;)V

    goto :goto_0

    :cond_8
    iget-boolean v4, p0, Lc/g0;->r:Z

    if-nez v4, :cond_9

    iget v4, p0, Lc/g0;->l:I

    if-ltz v4, :cond_9

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/graphics/RectF;

    invoke-virtual {v2, v0, v1}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v0

    if-eqz v0, :cond_9

    iget-object p1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    iget v0, p0, Lc/g0;->l:I

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    iget-object p1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v6, p1}, Lc/n1;->W0(Ljava/util/ArrayList;)V

    goto :goto_0

    :cond_9
    iget-boolean v0, p0, Lc/g0;->r:Z

    if-nez v0, :cond_a

    iget v0, p0, Lc/g0;->j:I

    iget-object v1, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ne v0, v1, :cond_a

    iget v0, p0, Lc/g0;->j:I

    if-ne p1, v0, :cond_a

    invoke-virtual {p0}, Lc/g0;->c()V

    :cond_a
    :goto_0
    iput v3, p0, Lc/g0;->l:I

    iput v3, p0, Lc/g0;->k:I

    iput v3, p0, Lc/g0;->j:I

    invoke-virtual {v7}, Landroid/view/View;->requestLayout()V

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    :cond_b
    return v5

    :cond_c
    :goto_1
    iput v3, p0, Lc/g0;->l:I

    iput v3, p0, Lc/g0;->k:I

    iput v3, p0, Lc/g0;->j:I

    invoke-virtual {v7}, Landroid/view/View;->invalidate()V

    return v5
.end method

.method public final g(FF)I
    .locals 3

    const/4 v0, 0x0

    :goto_0
    iget-object v1, p0, Lc/g0;->f:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v0, v2, :cond_1

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/RectF;

    invoke-virtual {v1, p1, p2}, Landroid/graphics/RectF;->contains(FF)Z

    move-result v1

    if-eqz v1, :cond_0

    return v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 p1, -0x1

    return p1
.end method

.method public final h(Landroid/graphics/Canvas;IFFFZLc/r4;)V
    .locals 11

    move-object v0, p0

    move-object v7, p1

    move v1, p2

    move-object/from16 v2, p7

    new-instance v3, Landroid/graphics/RectF;

    const/high16 v4, 0x40000000    # 2.0f

    div-float v5, p5, v4

    sub-float v6, p3, v5

    sub-float v8, p4, v5

    add-float v9, p3, v5

    add-float/2addr v5, p4

    invoke-direct {v3, v6, v8, v9, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    iget-object v5, v0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    iget-object v10, v0, Lc/g0;->e:Landroid/graphics/Paint;

    const/high16 v6, 0x41400000    # 12.0f

    if-lt v1, v5, :cond_0

    iget v1, v2, Lc/r4;->c:I

    invoke-virtual {v10, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p0, v6}, Lc/g0;->d(F)F

    move-result v1

    invoke-virtual {p0, v6}, Lc/g0;->d(F)F

    move-result v4

    invoke-virtual {p1, v3, v1, v4, v10}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    iget v1, v2, Lc/r4;->d:I

    invoke-virtual {v10, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x40400000    # 3.0f

    invoke-virtual {p0, v1}, Lc/g0;->d(F)F

    move-result v1

    invoke-virtual {v10, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    sget-object v1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v10, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const v1, 0x3e4ccccd    # 0.2f

    mul-float v8, p5, v1

    sub-float v2, p3, v8

    add-float v4, p3, v8

    move-object v1, p1

    move v3, p4

    move v5, p4

    move-object v6, v10

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    sub-float v3, p4, v8

    add-float v5, p4, v8

    move v2, p3

    move v4, p3

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void

    :cond_0
    iget-object v5, v0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {v5, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v5, v0, Lc/g0;->c:Lc/z;

    invoke-virtual {v5, v1}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v1

    if-eqz v1, :cond_1

    iget-object v1, v1, Lc/a;->c:Landroid/graphics/drawable/Drawable;

    invoke-static {p1, v1, v3, v2}, Lc/s;->d(Landroid/graphics/Canvas;Landroid/graphics/drawable/Drawable;Landroid/graphics/RectF;Lc/r4;)V

    goto :goto_0

    :cond_1
    iget v1, v2, Lc/r4;->c:I

    invoke-virtual {v10, v1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p0, v6}, Lc/g0;->d(F)F

    move-result v1

    invoke-virtual {p0, v6}, Lc/g0;->d(F)F

    move-result v5

    invoke-virtual {p1, v3, v1, v5, v10}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :goto_0
    if-eqz p6, :cond_2

    const/high16 v1, 0x40a00000    # 5.0f

    invoke-virtual {p0, v1}, Lc/g0;->d(F)F

    move-result v1

    sub-float/2addr v9, v1

    const/high16 v1, 0x41100000    # 9.0f

    invoke-virtual {p0, v1}, Lc/g0;->d(F)F

    move-result v1

    add-float/2addr v1, v8

    iget v3, v2, Lc/r4;->d:I

    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v3, 0x41200000    # 10.0f

    invoke-virtual {p0, v3}, Lc/g0;->d(F)F

    move-result v3

    invoke-virtual {p1, v9, v1, v3, v10}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    iget v2, v2, Lc/r4;->a:I

    invoke-virtual {v10, v2}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p0, v4}, Lc/g0;->d(F)F

    move-result v2

    invoke-virtual {v10, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v2, 0x40800000    # 4.0f

    invoke-virtual {p0, v2}, Lc/g0;->d(F)F

    move-result v3

    sub-float v3, v9, v3

    invoke-virtual {p0, v2}, Lc/g0;->d(F)F

    move-result v2

    add-float/2addr v2, v9

    move p2, v3

    move p3, v1

    move p4, v2

    move/from16 p5, v1

    move-object/from16 p6, v10

    invoke-virtual/range {p1 .. p6}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :cond_2
    return-void
.end method

.method public final i(FFFF)Z
    .locals 0

    invoke-virtual {p0, p1, p2}, Lc/g0;->g(FF)I

    move-result p1

    const/4 p2, 0x0

    if-ltz p1, :cond_3

    invoke-virtual {p0, p3, p4}, Lc/g0;->g(FF)I

    move-result p3

    if-eq p3, p1, :cond_0

    goto :goto_1

    :cond_0
    iget-object p3, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result p3

    if-ge p1, p3, :cond_2

    iget-object p3, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    iget-object p4, p0, Lc/g0;->c:Lc/z;

    invoke-virtual {p4, p3}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object p3

    if-nez p3, :cond_1

    return p2

    :cond_1
    iget-object p2, p0, Lc/g0;->h:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object p2, p0, Lc/g0;->d:Lc/E3;

    invoke-virtual {p2, p1}, Lc/E3;->accept(Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Lc/g0;->c()V

    :goto_0
    const/4 p1, 0x1

    return p1

    :cond_3
    :goto_1
    return p2
.end method
