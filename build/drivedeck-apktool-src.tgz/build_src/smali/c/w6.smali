.class public final synthetic Lc/w6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/w6;->a:I

    iput-object p1, p0, Lc/w6;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 2

    iget p1, p0, Lc/w6;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/w6;->b:Ljava/lang/Object;

    check-cast p1, Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "update_auto"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/w6;->b:Ljava/lang/Object;

    check-cast p1, Lc/O7;

    iget-object p1, p1, Lc/O7;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {p1, p2}, Lru/drivedeck/launcher/MainActivity;->f0(Z)V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/w6;->b:Ljava/lang/Object;

    check-cast p1, Lc/H6;

    iget-object p1, p1, Lc/H6;->c:Lc/T5;

    iget-object v0, p1, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "battery_screen"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p1}, Lc/T5;->l()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
