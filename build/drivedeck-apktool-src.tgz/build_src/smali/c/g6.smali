.class public final Lc/g6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Z

.field public final d:Ljava/util/ArrayList;

.field public e:I

.field public f:I

.field public g:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;ILjava/util/List;)V
    .locals 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/g6;->d:Ljava/util/ArrayList;

    const/4 v0, 0x6

    const/16 v1, 0x9

    const/16 v2, 0x8

    const/4 v3, 0x7

    if-eq p2, v0, :cond_1

    if-eq p2, v3, :cond_1

    if-eq p2, v2, :cond_1

    if-ne p2, v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Manual flow requires CAN protocol"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    if-eqz p1, :cond_6

    const-string v0, "(?:[0-9A-F]{2}){1,7}"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v5, "%02X"

    invoke-static {v0, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/g6;->a:Ljava/lang/String;

    if-eq p2, v3, :cond_3

    if-ne p2, v1, :cond_2

    goto :goto_1

    :cond_2
    const/4 v2, 0x3

    :cond_3
    :goto_1
    iput v2, p0, Lc/g6;->b:I

    const/4 p1, 0x0

    if-eqz p3, :cond_5

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_4
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_5

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    const-string v0, "ATCEA"

    invoke-virtual {p3, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_4

    const/4 p1, 0x1

    goto :goto_2

    :cond_5
    iput-boolean p1, p0, Lc/g6;->c:Z

    return-void

    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Manual flow query requires 1..7 bytes; long send is separate"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static g(IZ)I
    .locals 3

    const/4 v0, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    const/4 v2, 0x7

    if-eqz p1, :cond_1

    goto :goto_1

    :cond_1
    move v0, v2

    :goto_1
    const/4 p1, 0x0

    sub-int/2addr p0, v1

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    add-int/2addr p0, v0

    const/4 p1, 0x1

    sub-int/2addr p0, p1

    div-int/2addr p0, v0

    add-int/2addr p0, v2

    div-int/lit8 p0, p0, 0x8

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method


# virtual methods
.method public final a(ZLjava/lang/String;)V
    .locals 12

    iget v0, p0, Lc/g6;->e:I

    const/4 v1, 0x7

    if-ge v0, v1, :cond_14

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-lt v0, v2, :cond_13

    const/4 v3, 0x5

    if-lt v0, v3, :cond_0

    goto/16 :goto_6

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x0

    if-nez p2, :cond_1

    goto :goto_1

    :cond_1
    const-string v5, "[\\r\\n]+"

    invoke-virtual {p2, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v6, v5

    move v7, v4

    :goto_0
    if-ge v7, v6, :cond_3

    aget-object v8, v5, v7

    const-string v9, " "

    const-string v10, ""

    invoke-virtual {v8, v9, v10}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    const-string v10, "[0-9A-Fa-f]{"

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v10, p0, Lc/g6;->b:I

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, "}(?:[0-9A-Fa-f]{2}){1,8}"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_2

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_3
    :goto_1
    iget v5, p0, Lc/g6;->e:I

    iget-object v6, p0, Lc/g6;->d:Ljava/util/ArrayList;

    const/4 v7, 0x4

    iget-boolean v8, p0, Lc/g6;->c:Z

    if-ne v5, v2, :cond_7

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_4
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    invoke-virtual {p0, p2}, Lc/g6;->d(Ljava/lang/String;)I

    move-result v4

    if-lez v4, :cond_4

    :cond_5
    if-nez v4, :cond_6

    iput v3, p0, Lc/g6;->e:I

    return-void

    :cond_6
    invoke-static {v4, v8}, Lc/g6;->g(IZ)I

    move-result p1

    iput p1, p0, Lc/g6;->f:I

    iput v7, p0, Lc/g6;->e:I

    return-void

    :cond_7
    if-eqz p2, :cond_8

    const-string v5, "NO DATA"

    invoke-virtual {p2, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_9

    :cond_8
    if-eqz p1, :cond_a

    :cond_9
    iput v3, p0, Lc/g6;->e:I

    return-void

    :cond_a
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-ne p1, v1, :cond_f

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lc/g6;->b(Ljava/lang/String;)[B

    move-result-object p1

    array-length p2, p1

    const/4 v5, 0x2

    if-gt p2, v8, :cond_b

    :goto_2
    new-array p1, v4, [B

    goto :goto_5

    :cond_b
    aget-byte p2, p1, v8

    and-int/lit16 v9, p2, 0xff

    ushr-int/2addr v9, v7

    if-ne v9, v1, :cond_c

    move v10, v5

    goto :goto_3

    :cond_c
    move v10, v1

    :goto_3
    add-int/2addr v10, v8

    array-length v11, p1

    if-le v10, v11, :cond_d

    goto :goto_2

    :cond_d
    if-nez v9, :cond_e

    array-length v9, p1

    and-int/lit8 p2, p2, 0xf

    add-int/2addr p2, v10

    invoke-static {v9, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    goto :goto_4

    :cond_e
    array-length p2, p1

    :goto_4
    invoke-static {p1, v10, p2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    :goto_5
    array-length p2, p1

    if-lt p2, v7, :cond_f

    aget-byte p2, p1, v4

    and-int/lit16 p2, p2, 0xff

    if-ne p2, v2, :cond_f

    aget-byte p2, p1, v1

    and-int/lit16 p2, p2, 0xff

    const/16 v4, 0x7f

    if-ne p2, v4, :cond_f

    aget-byte p2, p1, v5

    and-int/lit16 p2, p2, 0xff

    const/16 v4, 0x8

    if-ne p2, v4, :cond_f

    aget-byte p1, p1, v2

    and-int/lit16 p1, p1, 0xff

    const/16 p2, 0x22

    if-ne p1, p2, :cond_f

    iput-boolean v1, p0, Lc/g6;->g:Z

    iput v3, p0, Lc/g6;->e:I

    return-void

    :cond_f
    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget p1, p0, Lc/g6;->f:I

    sub-int/2addr p1, v1

    iput p1, p0, Lc/g6;->f:I

    if-lez p1, :cond_10

    return-void

    :cond_10
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result p1

    if-le p1, v1, :cond_12

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v1

    invoke-virtual {v6, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lc/g6;->b(Ljava/lang/String;)[B

    move-result-object p2

    array-length v0, p2

    if-le v0, v8, :cond_12

    aget-byte p2, p2, v8

    and-int/lit16 v0, p2, 0xff

    ushr-int/2addr v0, v7

    if-ne v0, v1, :cond_11

    invoke-virtual {p0, p1}, Lc/g6;->d(Ljava/lang/String;)I

    move-result p1

    invoke-static {p1, v8}, Lc/g6;->g(IZ)I

    move-result p1

    iput p1, p0, Lc/g6;->f:I

    return-void

    :cond_11
    if-nez v0, :cond_12

    and-int/lit8 p1, p2, 0xf

    invoke-static {p1, v8}, Lc/g6;->g(IZ)I

    move-result p1

    iput p1, p0, Lc/g6;->f:I

    return-void

    :cond_12
    iput v3, p0, Lc/g6;->e:I

    return-void

    :cond_13
    :goto_6
    add-int/2addr v0, v1

    iput v0, p0, Lc/g6;->e:I

    return-void

    :cond_14
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Manual flow finished"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final b(Ljava/lang/String;)[B
    .locals 6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    iget v1, p0, Lc/g6;->b:I

    sub-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x2

    new-array v2, v0, [B

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v0, :cond_0

    mul-int/lit8 v4, v3, 0x2

    add-int v5, v1, v4

    add-int/2addr v4, v1

    add-int/lit8 v4, v4, 0x2

    invoke-virtual {p1, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x10

    invoke-static {v4, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    int-to-byte v4, v4

    aput-byte v4, v2, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-object v2
.end method

.method public final c()Z
    .locals 1

    iget-boolean v0, p0, Lc/g6;->g:Z

    return v0
.end method

.method public final d(Ljava/lang/String;)I
    .locals 4

    invoke-virtual {p0, p1}, Lc/g6;->b(Ljava/lang/String;)[B

    move-result-object p1

    array-length v0, p1

    iget-boolean v1, p0, Lc/g6;->c:Z

    add-int/lit8 v2, v1, 0x1

    if-le v0, v2, :cond_0

    aget-byte v0, p1, v1

    and-int/lit16 v1, v0, 0xff

    ushr-int/lit8 v1, v1, 0x4

    const/4 v3, 0x1

    if-ne v1, v3, :cond_0

    and-int/lit8 v0, v0, 0xf

    shl-int/lit8 v0, v0, 0x8

    aget-byte p1, p1, v2

    and-int/lit16 p1, p1, 0xff

    or-int/2addr p1, v0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final e()Lc/f6;
    .locals 4

    iget v0, p0, Lc/g6;->e:I

    const/16 v1, 0x1400

    const/16 v2, 0x800

    const/4 v3, -0x1

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    return-object v0

    :pswitch_0
    new-instance v0, Lc/f6;

    const-string v1, "ATCFC1"

    invoke-direct {v0, v3, v2, v1}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_1
    new-instance v0, Lc/f6;

    const-string v1, "ATCAF1"

    invoke-direct {v0, v3, v2, v1}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_2
    new-instance v0, Lc/f6;

    const-string v2, "300800"

    const/16 v3, 0x8

    invoke-direct {v0, v3, v1, v2}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_3
    new-instance v0, Lc/f6;

    iget-object v2, p0, Lc/g6;->a:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-direct {v0, v3, v1, v2}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_4
    new-instance v0, Lc/f6;

    const-string v1, "ATAL"

    invoke-direct {v0, v3, v2, v1}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_5
    new-instance v0, Lc/f6;

    const-string v1, "ATCFC0"

    invoke-direct {v0, v3, v2, v1}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    :pswitch_6
    new-instance v0, Lc/f6;

    const-string v1, "ATCAF0"

    invoke-direct {v0, v3, v2, v1}, Lc/f6;-><init>(IILjava/lang/String;)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final f()Ljava/lang/String;
    .locals 8

    iget v0, p0, Lc/g6;->e:I

    const/4 v1, 0x7

    if-lt v0, v1, :cond_3

    iget-object v0, p0, Lc/g6;->d:Ljava/util/ArrayList;

    const-string v1, "\r"

    invoke-static {v1, v0}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v2

    iget-boolean v3, p0, Lc/g6;->c:Z

    if-nez v3, :cond_0

    return-object v2

    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    iget v5, p0, Lc/g6;->b:I

    add-int/lit8 v6, v5, 0x2

    if-lt v4, v6, :cond_1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    invoke-virtual {v3, v7, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    invoke-static {v1, v2}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Restoration pending"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
