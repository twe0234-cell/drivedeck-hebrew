.class public interface abstract Lc/y5;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Lc/j6;Ljava/lang/String;)V
.end method
