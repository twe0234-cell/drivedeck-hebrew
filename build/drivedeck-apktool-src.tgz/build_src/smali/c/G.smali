.class public final synthetic Lc/G;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/BooleanSupplier;


# virtual methods
.method public final getAsBoolean()Z
    .locals 1

    sget-object v0, Lc/J;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v0, 0x1

    return v0
.end method
