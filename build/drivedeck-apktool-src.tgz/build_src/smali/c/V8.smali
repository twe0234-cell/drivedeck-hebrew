.class public final synthetic Lc/V8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:J

.field public final synthetic d:Ljava/io/Serializable;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lc/Z6;JLc/n1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/V8;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V8;->b:Ljava/lang/String;

    iput-object p2, p0, Lc/V8;->d:Ljava/io/Serializable;

    iput-object p3, p0, Lc/V8;->e:Ljava/lang/Object;

    iput-object p4, p0, Lc/V8;->f:Ljava/lang/Object;

    iput-wide p5, p0, Lc/V8;->c:J

    iput-object p7, p0, Lc/V8;->g:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/concurrent/atomic/AtomicBoolean;Landroid/location/LocationManager;Lc/w9;Ljava/lang/String;JLjava/lang/Runnable;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/V8;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V8;->d:Ljava/io/Serializable;

    iput-object p2, p0, Lc/V8;->e:Ljava/lang/Object;

    iput-object p3, p0, Lc/V8;->f:Ljava/lang/Object;

    iput-object p4, p0, Lc/V8;->b:Ljava/lang/String;

    iput-wide p5, p0, Lc/V8;->c:J

    iput-object p7, p0, Lc/V8;->g:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 16

    move-object/from16 v1, p0

    iget v0, v1, Lc/V8;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, Lc/V8;->d:Ljava/io/Serializable;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v1, Lc/V8;->e:Ljava/lang/Object;

    check-cast v0, Landroid/location/LocationManager;

    iget-object v2, v1, Lc/V8;->f:Ljava/lang/Object;

    check-cast v2, Lc/w9;

    invoke-virtual {v0, v2}, Landroid/location/LocationManager;->removeUpdates(Landroid/location/LocationListener;)V

    iget-object v0, v1, Lc/V8;->b:Ljava/lang/String;

    iget-object v2, v1, Lc/V8;->g:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Runnable;

    iget-wide v3, v1, Lc/V8;->c:J

    invoke-static {v0, v3, v4, v2}, Lc/y9;->b(Ljava/lang/String;JLjava/lang/Runnable;)V

    :goto_0
    return-void

    :pswitch_0
    const-string v2, "; \u0432\u0442\u043e\u0440\u043e\u0439: "

    const-string v3, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u0438\u0437 \u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0445 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a\u043e\u0432. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443. \u041f\u0435\u0440\u0432\u044b\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a: "

    iget-object v0, v1, Lc/V8;->b:Ljava/lang/String;

    iget-object v4, v1, Lc/V8;->d:Ljava/io/Serializable;

    check-cast v4, Ljava/lang/String;

    iget-object v5, v1, Lc/V8;->e:Ljava/lang/Object;

    check-cast v5, Landroid/content/Context;

    iget-object v6, v1, Lc/V8;->f:Ljava/lang/Object;

    check-cast v6, Lc/Z6;

    iget-wide v13, v1, Lc/V8;->c:J

    iget-object v7, v1, Lc/V8;->g:Ljava/lang/Object;

    move-object v15, v7

    check-cast v15, Lc/n1;

    const/4 v12, 0x1

    :try_start_0
    new-instance v7, Lc/f0;

    invoke-direct {v7, v4}, Lc/f0;-><init>(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    const-wide/16 v8, 0x4e20

    :try_start_1
    invoke-static {v8, v9}, Lc/T8;->a(J)J

    move-result-wide v10

    invoke-static {v10, v11, v0}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v0, v4}, Lc/c9;->g(Lorg/json/JSONObject;Ljava/lang/String;)Lc/U8;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_3

    :goto_1
    move-object v10, v0

    goto :goto_2

    :catch_0
    move-exception v0

    goto :goto_1

    :goto_2
    :try_start_2
    invoke-static {v8, v9}, Lc/T8;->a(J)J

    move-result-wide v8

    const-string v0, "update.json"

    invoke-static {v0, v4, v8, v9}, Lc/k6;->g0(Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v9, v0}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v0, v4}, Lc/c9;->g(Lorg/json/JSONObject;Ljava/lang/String;)Lc/U8;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    :goto_3
    move-object v11, v0

    goto :goto_6

    :catch_1
    move-exception v0

    :try_start_3
    new-instance v4, Ljava/io/IOException;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v4, v8, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v4, v10}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v4
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    :goto_4
    move-object v4, v0

    goto :goto_5

    :catch_2
    move-exception v0

    goto :goto_4

    :goto_5
    :try_start_4
    iget-object v0, v7, Lc/f0;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "https://github.com/RotkivKiv/DriveDeck-Updates/releases/download/channels/"

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lc/k6;->H(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "-update.json"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-wide/16 v8, 0x4e20

    invoke-static {v8, v9}, Lc/T8;->a(J)J

    move-result-wide v8

    invoke-static {v8, v9, v7}, Lc/c9;->i(JLjava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    invoke-static {v7, v0}, Lc/c9;->g(Lorg/json/JSONObject;Ljava/lang/String;)Lc/U8;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_5

    goto :goto_3

    :goto_6
    :try_start_5
    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1c

    if-lt v2, v3, :cond_1

    invoke-static {v0}, Lc/T;->b(Landroid/content/pm/PackageInfo;)J

    move-result-wide v2

    long-to-int v0, v2

    goto :goto_7

    :cond_1
    iget v0, v0, Landroid/content/pm/PackageInfo;->versionCode:I

    :goto_7
    new-instance v2, Lc/Z8;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_4

    move-object v7, v2

    move-wide v8, v13

    move-object v10, v15

    move v5, v12

    move v12, v0

    :try_start_6
    invoke-direct/range {v7 .. v12}, Lc/Z8;-><init>(JLc/n1;Lc/U8;I)V

    invoke-virtual {v6, v2, v5}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    goto :goto_a

    :catch_3
    move-exception v0

    :goto_8
    move-object v11, v0

    goto :goto_9

    :catch_4
    move-exception v0

    move v5, v12

    goto :goto_8

    :catch_5
    move-exception v0

    move v5, v12

    new-instance v7, Ljava/io/IOException;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v7, v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v7, v4}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    throw v7
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_3

    :goto_9
    new-instance v0, Lc/X8;

    const/4 v12, 0x1

    move-object v7, v0

    move-wide v8, v13

    move-object v10, v15

    invoke-direct/range {v7 .. v12}, Lc/X8;-><init>(JLc/n1;Ljava/lang/Exception;I)V

    invoke-virtual {v6, v0, v5}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    :goto_a
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
