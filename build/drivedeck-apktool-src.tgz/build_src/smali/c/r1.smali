.class public final Lc/r1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Ljava/util/ArrayList;

.field public final c:J

.field public final d:J


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;JJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/r1;->a:Ljava/util/ArrayList;

    iput-object p2, p0, Lc/r1;->b:Ljava/util/ArrayList;

    iput-wide p3, p0, Lc/r1;->c:J

    iput-wide p5, p0, Lc/r1;->d:J

    return-void
.end method
