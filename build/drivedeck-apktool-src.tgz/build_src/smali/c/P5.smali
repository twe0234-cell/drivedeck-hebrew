.class public final Lc/P5;
.super Ljava/io/OutputStream;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/P6;


# direct methods
.method public constructor <init>(Lc/P6;)V
    .locals 0

    iput-object p1, p0, Lc/P5;->a:Lc/P6;

    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    return-void
.end method


# virtual methods
.method public final close()V
    .locals 1

    iget-object v0, p0, Lc/P5;->a:Lc/P6;

    invoke-virtual {v0}, Lc/P6;->close()V

    return-void
.end method

.method public final write(I)V
    .locals 2

    int-to-byte p1, p1

    const/4 v0, 0x1

    .line 1
    new-array v0, v0, [B

    const/4 v1, 0x0

    aput-byte p1, v0, v1

    invoke-virtual {p0, v0}, Ljava/io/OutputStream;->write([B)V

    return-void
.end method

.method public final write([BII)V
    .locals 6

    add-int v0, p2, p3

    .line 2
    invoke-static {p1, p2, v0}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    .line 3
    iget-object p2, p0, Lc/P5;->a:Lc/P6;

    add-int/lit8 p3, p3, -0x1

    const/16 v0, 0x11

    if-le p3, v0, :cond_0

    const/16 p3, 0x3a98

    goto :goto_0

    :cond_0
    const/16 p3, 0x1388

    .line 4
    :goto_0
    iget-object v1, p2, Lc/P6;->b:Lcom/hoho/android/usbserial/driver/UsbSerialPort;

    if-eqz v1, :cond_2

    .line 5
    iget-object v2, p2, Lc/P6;->g:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v2, 0x0

    move v3, v2

    .line 6
    :goto_1
    :try_start_0
    array-length v4, p1

    if-ge v3, v4, :cond_1

    .line 7
    array-length v4, p1

    sub-int/2addr v4, v3

    invoke-static {v0, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 8
    new-array v5, v4, [B

    invoke-static {p1, v3, v5, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 9
    invoke-interface {v1, v5, p3}, Lcom/hoho/android/usbserial/driver/UsbSerialPort;->write([BI)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/lit8 v3, v3, 0x11

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_2

    .line 10
    :cond_1
    iget-object p1, p2, Lc/P6;->g:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    return-void

    :goto_2
    iget-object p2, p2, Lc/P6;->g:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {p2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    throw p1

    .line 11
    :cond_2
    new-instance p1, Ljava/io/IOException;

    const-string p2, "USB disconnected"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
