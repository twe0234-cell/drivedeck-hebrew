.class public final Lc/r8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/view/View;

.field public final b:I

.field public final c:Landroid/graphics/Rect;

.field public final d:Ljava/lang/Runnable;

.field public final e:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/r8;->a:Landroid/view/View;

    iput p2, p0, Lc/r8;->b:I

    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1, p3}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    iput-object p1, p0, Lc/r8;->c:Landroid/graphics/Rect;

    iput-object p4, p0, Lc/r8;->d:Ljava/lang/Runnable;

    iput-object p5, p0, Lc/r8;->e:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final a(Lc/r8;)Z
    .locals 2

    if-eqz p1, :cond_0

    iget-object v0, p0, Lc/r8;->a:Landroid/view/View;

    iget-object v1, p1, Lc/r8;->a:Landroid/view/View;

    if-ne v0, v1, :cond_0

    iget v0, p0, Lc/r8;->b:I

    iget p1, p1, Lc/r8;->b:I

    if-ne v0, p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method
