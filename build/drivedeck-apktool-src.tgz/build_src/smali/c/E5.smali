.class public final synthetic Lc/E5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/T5;

.field public final synthetic c:I

.field public final synthetic d:Ljava/io/OutputStream;


# direct methods
.method public synthetic constructor <init>(Lc/T5;ILjava/io/OutputStream;I)V
    .locals 0

    iput p4, p0, Lc/E5;->a:I

    iput-object p1, p0, Lc/E5;->b:Lc/T5;

    iput p2, p0, Lc/E5;->c:I

    iput-object p3, p0, Lc/E5;->d:Ljava/io/OutputStream;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/E5;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/E5;->b:Lc/T5;

    iget v1, p0, Lc/E5;->c:I

    iget-object v2, p0, Lc/E5;->d:Ljava/io/OutputStream;

    iget v3, v0, Lc/T5;->t:I

    if-ne v1, v3, :cond_0

    iget-object v1, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-ne v1, v2, :cond_0

    invoke-virtual {v0}, Lc/T5;->W()V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/E5;->b:Lc/T5;

    iget v1, p0, Lc/E5;->c:I

    iget-object v2, p0, Lc/E5;->d:Ljava/io/OutputStream;

    iget v3, v0, Lc/T5;->t:I

    if-ne v1, v3, :cond_1

    iget-object v1, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-ne v1, v2, :cond_1

    const-string v1, "\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0435\u0440\u0435\u0434\u0430\u0447\u0438 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0443"

    invoke-virtual {v0, v1}, Lc/T5;->Q0(Ljava/lang/String;)V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
