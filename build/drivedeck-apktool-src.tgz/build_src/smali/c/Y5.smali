.class public final Lc/Y5;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:D

.field public final b:I

.field public final c:J


# direct methods
.method public constructor <init>(DIJ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lc/Y5;->a:D

    iput p3, p0, Lc/Y5;->b:I

    iput-wide p4, p0, Lc/Y5;->c:J

    return-void
.end method
