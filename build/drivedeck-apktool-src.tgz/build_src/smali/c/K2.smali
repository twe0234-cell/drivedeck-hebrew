.class public final synthetic Lc/K2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnScrollChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/view/ViewTreeObserver$OnPreDrawListener;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Landroid/view/ViewTreeObserver$OnPreDrawListener;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/K2;->a:I

    iput-object p1, p0, Lc/K2;->b:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    iput-object p2, p0, Lc/K2;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onScrollChange(Landroid/view/View;IIII)V
    .locals 0

    iget p1, p0, Lc/K2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/K2;->b:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    check-cast p1, Lc/d3;

    iget-object p1, p1, Lc/d3;->d:Lc/k3;

    iget-object p1, p1, Lc/k3;->u:Ljava/util/HashMap;

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    iget-object p3, p0, Lc/K2;->c:Ljava/lang/Object;

    check-cast p3, Ljava/lang/String;

    invoke-virtual {p1, p3, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :pswitch_0
    const/4 p1, 0x1

    iget-object p2, p0, Lc/K2;->c:Ljava/lang/Object;

    check-cast p2, Landroid/widget/ScrollView;

    invoke-virtual {p2, p1}, Landroid/view/View;->canScrollVertically(I)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    goto :goto_0

    :cond_0
    const/16 p1, 0x8

    :goto_0
    iget-object p2, p0, Lc/K2;->b:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    check-cast p2, Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/view/View;->setVisibility(I)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
