.class public final Lc/V4;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static f:Lc/V4;

.field public static g:J

.field public static h:Z


# instance fields
.field public final a:Landroid/media/session/MediaController;

.field public final b:Ljava/lang/String;

.field public final c:Z

.field public final d:I

.field public final e:Landroid/media/session/PlaybackState$CustomAction;


# direct methods
.method public constructor <init>(Landroid/media/session/MediaController;Ljava/lang/String;ZILandroid/media/session/PlaybackState$CustomAction;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/V4;->a:Landroid/media/session/MediaController;

    iput-object p2, p0, Lc/V4;->b:Ljava/lang/String;

    iput-boolean p3, p0, Lc/V4;->c:Z

    iput p4, p0, Lc/V4;->d:I

    iput-object p5, p0, Lc/V4;->e:Landroid/media/session/PlaybackState$CustomAction;

    return-void
.end method

.method public static a(Ljava/lang/String;)Z
    .locals 11

    const-string v9, "like selected"

    const-string v10, "like marked as"

    const-string v0, "\u0443\u0431\u0440\u0430\u0442\u044c \u043b\u0430\u0439\u043a"

    const-string v1, "\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e"

    const-string v2, "\u0443\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e"

    const-string v3, "\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0437 \u043a\u043e\u043b\u043b\u0435\u043a\u0446\u0438\u0438"

    const-string v4, "unlike"

    const-string v5, "remove from favorites"

    const-string v6, "remove from favourites"

    const-string v7, "undo favorite"

    const-string v8, "undo favourite"

    filled-new-array/range {v0 .. v10}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public static b(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 1

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    :cond_0
    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static d(Landroid/media/session/MediaController;)Lc/V4;
    .locals 22

    const/4 v0, 0x0

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    move-result-object v1

    if-nez v1, :cond_1

    return-object v0

    :cond_1
    const-string v2, "android.media.metadata.MEDIA_ID"

    invoke-virtual {v1, v2}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "android.media.metadata.TITLE"

    invoke-virtual {v1, v3}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "android.media.metadata.ARTIST"

    invoke-virtual {v1, v4}, Landroid/media/MediaMetadata;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_3

    :cond_2
    if-eqz v3, :cond_4

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_3

    goto :goto_0

    :cond_3
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v2, v5}, Ljava/util/Objects;->toString(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0xa

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {v3, v5}, Ljava/util/Objects;->toString(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {v4, v5}, Ljava/util/Objects;->toString(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    move-object v3, v2

    goto :goto_1

    :cond_4
    :goto_0
    move-object v3, v5

    :goto_1
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_5

    return-object v0

    :cond_5
    invoke-virtual/range {p0 .. p0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v2

    const-string v4, "android.media.metadata.USER_RATING"

    invoke-virtual {v1, v4}, Landroid/media/MediaMetadata;->getRating(Ljava/lang/String;)Landroid/media/Rating;

    move-result-object v1

    const/4 v4, 0x1

    if-eqz v1, :cond_7

    invoke-virtual {v1}, Landroid/media/Rating;->isRated()Z

    move-result v5

    if-eqz v5, :cond_7

    invoke-virtual {v1}, Landroid/media/Rating;->hasHeart()Z

    move-result v5

    if-nez v5, :cond_6

    invoke-virtual {v1}, Landroid/media/Rating;->isThumbUp()Z

    move-result v1

    if-eqz v1, :cond_7

    :cond_6
    move v1, v4

    goto :goto_2

    :cond_7
    const/4 v1, 0x0

    :goto_2
    invoke-virtual/range {p0 .. p0}, Landroid/media/session/MediaController;->getRatingType()I

    move-result v5

    if-eqz v2, :cond_c

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getCustomActions()Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    move-object v7, v0

    :cond_8
    :goto_3
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_b

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/media/session/PlaybackState$CustomAction;

    invoke-virtual {v8}, Landroid/media/session/PlaybackState$CustomAction;->getName()Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Lc/V4;->b(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lc/V4;->a(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_9

    move v1, v4

    :cond_9
    const-string v18, "add to favorites"

    const-string v19, "add to favourites"

    const-string v10, "\u043d\u0440\u0430\u0432\u0438\u0442\u0441\u044f"

    const-string v11, "\u043b\u0430\u0439\u043a"

    const-string v12, "\u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435"

    const-string v13, "\u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435"

    const-string v14, "\u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u043a\u043e\u043b\u043b\u0435\u043a\u0446\u0438\u044e"

    const-string v15, "like"

    const-string v16, "favorite"

    const-string v17, "favourite"

    const-string v20, "save to library"

    const-string v21, "like not selected"

    filled-new-array/range {v10 .. v21}, [Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    invoke-static {v9}, Lc/V4;->b(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v9

    invoke-interface {v10, v9}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_a

    invoke-virtual/range {p0 .. p0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "com.zvooq.openplay"

    invoke-virtual {v10, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    const-string v9, "ACTION_LIKE"

    invoke-virtual {v8}, Landroid/media/session/PlaybackState$CustomAction;->getAction()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    :cond_a
    move-object v7, v8

    goto :goto_3

    :cond_b
    :goto_4
    move v6, v1

    goto :goto_5

    :cond_c
    move-object v7, v0

    goto :goto_4

    :goto_5
    if-eqz v7, :cond_d

    new-instance v0, Lc/V4;

    const/4 v5, 0x0

    move-object v1, v0

    move-object/from16 v2, p0

    move v4, v6

    move-object v6, v7

    invoke-direct/range {v1 .. v6}, Lc/V4;-><init>(Landroid/media/session/MediaController;Ljava/lang/String;ZILandroid/media/session/PlaybackState$CustomAction;)V

    return-object v0

    :cond_d
    if-eqz v2, :cond_f

    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getActions()J

    move-result-wide v1

    const-wide/16 v8, 0x80

    and-long/2addr v1, v8

    const-wide/16 v8, 0x0

    cmp-long v1, v1, v8

    if-eqz v1, :cond_f

    if-eq v5, v4, :cond_e

    const/4 v1, 0x2

    if-ne v5, v1, :cond_f

    :cond_e
    new-instance v0, Lc/V4;

    const/4 v7, 0x0

    move-object v1, v0

    move-object/from16 v2, p0

    move v4, v6

    move-object v6, v7

    invoke-direct/range {v1 .. v6}, Lc/V4;-><init>(Landroid/media/session/MediaController;Ljava/lang/String;ZILandroid/media/session/PlaybackState$CustomAction;)V

    return-object v0

    :cond_f
    if-nez v7, :cond_10

    if-eqz v6, :cond_11

    :cond_10
    new-instance v0, Lc/V4;

    const/4 v5, 0x0

    move-object v1, v0

    move-object/from16 v2, p0

    move v4, v6

    move-object v6, v7

    invoke-direct/range {v1 .. v6}, Lc/V4;-><init>(Landroid/media/session/MediaController;Ljava/lang/String;ZILandroid/media/session/PlaybackState$CustomAction;)V

    :cond_11
    return-object v0
.end method


# virtual methods
.method public final c()Z
    .locals 7

    iget-object v0, p0, Lc/V4;->a:Landroid/media/session/MediaController;

    invoke-static {v0}, Lc/V4;->d(Landroid/media/session/MediaController;)Lc/V4;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/V4;->e(Lc/V4;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_6

    iget-boolean v2, v1, Lc/V4;->c:Z

    if-nez v2, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v2

    if-nez v2, :cond_1

    return v3

    :cond_1
    invoke-virtual {v2}, Landroid/media/session/PlaybackState;->getCustomActions()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x1

    if-eqz v4, :cond_3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/media/session/PlaybackState$CustomAction;

    invoke-virtual {v4}, Landroid/media/session/PlaybackState$CustomAction;->getName()Ljava/lang/CharSequence;

    move-result-object v6

    invoke-static {v6}, Lc/V4;->b(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lc/V4;->a(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    invoke-virtual {v4}, Landroid/media/session/PlaybackState$CustomAction;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    invoke-virtual {v0, v4, v1}, Landroid/media/session/MediaController$TransportControls;->sendCustomAction(Landroid/media/session/PlaybackState$CustomAction;Landroid/os/Bundle;)V

    return v5

    :cond_3
    iget v1, v1, Lc/V4;->d:I

    if-nez v1, :cond_4

    return v3

    :cond_4
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    if-ne v1, v5, :cond_5

    invoke-static {v3}, Landroid/media/Rating;->newHeartRating(Z)Landroid/media/Rating;

    move-result-object v1

    goto :goto_0

    :cond_5
    const/4 v1, 0x2

    invoke-static {v1}, Landroid/media/Rating;->newUnratedRating(I)Landroid/media/Rating;

    move-result-object v1

    :goto_0
    invoke-virtual {v0, v1}, Landroid/media/session/MediaController$TransportControls;->setRating(Landroid/media/Rating;)V

    return v5

    :cond_6
    :goto_1
    return v3
.end method

.method public final e(Lc/V4;)Z
    .locals 2

    if-eqz p1, :cond_0

    iget-object v0, p0, Lc/V4;->a:Landroid/media/session/MediaController;

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v0

    iget-object v1, p1, Lc/V4;->a:Landroid/media/session/MediaController;

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getSessionToken()Landroid/media/session/MediaSession$Token;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/media/session/MediaSession$Token;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/V4;->b:Ljava/lang/String;

    iget-object p1, p1, Lc/V4;->b:Ljava/lang/String;

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final f()Z
    .locals 5

    iget-object v0, p0, Lc/V4;->a:Landroid/media/session/MediaController;

    invoke-static {v0}, Lc/V4;->d(Landroid/media/session/MediaController;)Lc/V4;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/V4;->e(Lc/V4;)Z

    move-result v2

    const/4 v3, 0x0

    if-eqz v2, :cond_3

    iget-boolean v2, v1, Lc/V4;->c:Z

    if-eqz v2, :cond_0

    goto :goto_2

    :cond_0
    const/4 v2, 0x1

    iget v4, v1, Lc/V4;->d:I

    if-eqz v4, :cond_2

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    if-ne v4, v2, :cond_1

    invoke-static {v2}, Landroid/media/Rating;->newHeartRating(Z)Landroid/media/Rating;

    move-result-object v1

    goto :goto_0

    :cond_1
    invoke-static {v2}, Landroid/media/Rating;->newThumbRating(Z)Landroid/media/Rating;

    move-result-object v1

    :goto_0
    invoke-virtual {v0, v1}, Landroid/media/session/MediaController$TransportControls;->setRating(Landroid/media/Rating;)V

    goto :goto_1

    :cond_2
    iget-object v1, v1, Lc/V4;->e:Landroid/media/session/PlaybackState$CustomAction;

    if-eqz v1, :cond_3

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v0

    invoke-virtual {v1}, Landroid/media/session/PlaybackState$CustomAction;->getExtras()Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/media/session/MediaController$TransportControls;->sendCustomAction(Landroid/media/session/PlaybackState$CustomAction;Landroid/os/Bundle;)V

    :goto_1
    return v2

    :cond_3
    :goto_2
    return v3
.end method
