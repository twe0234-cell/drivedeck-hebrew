.class public final synthetic Lc/D2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;


# direct methods
.method public synthetic constructor <init>(Lc/k3;I)V
    .locals 0

    iput p2, p0, Lc/D2;->a:I

    iput-object p1, p0, Lc/D2;->b:Lc/k3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 3

    iget p1, p0, Lc/D2;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-boolean v0, p1, Lc/k3;->G:Z

    if-nez v0, :cond_0

    iget-object v0, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, p2}, Lru/drivedeck/launcher/MainActivity;->f0(Z)V

    const-string p2, "voice"

    iget-object v0, p1, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-virtual {p1}, Lc/k3;->S()V

    :cond_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    const-string v0, "com.android.bluetooth"

    invoke-virtual {p1, p2, v0}, Lc/n1;->K0(ZLjava/lang/String;)V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "dock_single_fullscreen"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v1, "split_page_enabled"

    if-eqz v0, :cond_2

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-static {p1, v1, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-nez p2, :cond_3

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string p2, "cards"

    invoke-virtual {p1, p2}, Lc/n1;->C0(Ljava/lang/String;)V

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-object p1, v0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lc/Q3;->O()V

    :cond_1
    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->W()V

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->h0()V

    goto :goto_0

    :cond_2
    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-static {p1, v1, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    :cond_3
    :goto_0
    return-void

    :pswitch_3
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "auto_theme_sunset"

    invoke-static {v1, v2, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p2, p1, Lc/k3;->d:Lc/u0;

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_4
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "ignore_daytime_headlights"

    invoke-static {v1, v2, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p2, p1, Lc/k3;->d:Lc/u0;

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_5
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "auto_theme_headlights"

    invoke-static {v1, v2, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p2, p1, Lc/k3;->d:Lc/u0;

    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_6
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "theme_schedule_enabled"

    invoke-static {v1, v2, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-eqz p2, :cond_4

    const-string p2, "auto"

    goto :goto_1

    :cond_4
    invoke-virtual {v0}, Lc/n1;->O()Ljava/lang/String;

    move-result-object p2

    :goto_1
    iget-object v0, p1, Lc/k3;->d:Lc/u0;

    invoke-virtual {v0, p2}, Lc/u0;->l(Ljava/lang/String;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_7
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "resume_music_on_start"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_8
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "track_popup_enabled"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_9
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "keyboard_in_app_window"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_a
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v1, "screen_fullscreen"

    invoke-static {v0, v1, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p2, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p2, :cond_5

    invoke-virtual {p2}, Lru/drivedeck/launcher/MainActivity;->U()V

    invoke-virtual {p2}, Lru/drivedeck/launcher/MainActivity;->v()V

    :cond_5
    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p2

    invoke-static {p2}, Lc/b4;->b(Landroid/view/Window;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_b
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "all_apps_activities"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_c
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_6

    invoke-virtual {p1, p2}, Lru/drivedeck/launcher/MainActivity;->c0(Z)V

    :cond_6
    return-void

    :pswitch_d
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "wait_for_internet_before_music"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_e
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "dock_status_visible"

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p1}, Lc/k3;->S()V

    return-void

    :pswitch_f
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object p1, p1, Lc/k3;->c:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "dock_auto_hide"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    return-void

    :pswitch_10
    iget-object p1, p0, Lc/D2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v1, "dimmer_dark_only"

    invoke-static {v0, v1, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p1}, Lc/R1;->b(Landroid/content/Context;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
