.class public final Lc/a2;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field public a:Z

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lc/b2;


# direct methods
.method public constructor <init>(Lc/b2;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lc/a2;->d:Lc/b2;

    iput-object p2, p0, Lc/a2;->b:Ljava/lang/String;

    iput-object p3, p0, Lc/a2;->c:Ljava/lang/String;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .locals 0

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/a2;->a:Z

    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    iget-object p1, p0, Lc/a2;->d:Lc/b2;

    const/4 v0, 0x0

    iput-object v0, p1, Lc/b2;->c0:Landroid/animation/ValueAnimator;

    const/4 v1, 0x0

    iput-boolean v1, p1, Lc/b2;->U:Z

    iput-object v0, p1, Lc/b2;->V:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p1, Lc/b2;->W:I

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    iget-boolean v0, p0, Lc/a2;->a:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/a2;->b:Ljava/lang/String;

    iget-object v1, p0, Lc/a2;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    iget-object p1, p1, Lc/b2;->Q:Lc/v8;

    iget-object p1, p1, Lc/v8;->b:Ljava/lang/Object;

    check-cast p1, Lc/k3;

    invoke-virtual {p1, v0, v1}, Lc/k3;->K(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method
