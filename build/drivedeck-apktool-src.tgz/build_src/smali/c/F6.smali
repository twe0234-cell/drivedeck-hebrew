.class public final Lc/F6;
.super Landroid/widget/ArrayAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Ljava/util/List;Lc/r4;Lru/drivedeck/launcher/MainActivity;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, Lc/F6;->a:I

    .line 2
    iput-object p3, p0, Lc/F6;->b:Ljava/lang/Object;

    iput-object p4, p0, Lc/F6;->c:Ljava/lang/Object;

    const p3, 0x1090008

    invoke-direct {p0, p1, p3, p2}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    return-void
.end method

.method public constructor <init>(Lc/H6;Lru/drivedeck/launcher/MainActivity;Ljava/util/List;Ljava/util/List;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lc/F6;->a:I

    .line 3
    iput-object p1, p0, Lc/F6;->c:Ljava/lang/Object;

    iput-object p4, p0, Lc/F6;->b:Ljava/lang/Object;

    const p1, 0x1090008

    invoke-direct {p0, p2, p1, p3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    return-void
.end method

.method public constructor <init>(Lc/l9;Landroid/content/Context;[Ljava/lang/String;Lc/r4;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lc/F6;->a:I

    .line 1
    iput-object p1, p0, Lc/F6;->c:Ljava/lang/Object;

    iput-object p4, p0, Lc/F6;->b:Ljava/lang/Object;

    const p1, 0x1090003

    invoke-direct {p0, p2, p1, p3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;IZ)V
    .locals 5

    check-cast p1, Landroid/widget/TextView;

    iget-object v0, p0, Lc/F6;->c:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    iget-object v1, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v2, p0, Lc/F6;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-interface {v2, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    invoke-static {v1, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object p2, v0, Lc/H6;->b:Lc/r4;

    iget v1, p2, Lc/r4;->d:I

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    iget v2, p2, Lc/r4;->b:I

    goto :goto_0

    :cond_0
    move v2, v1

    :goto_0
    invoke-virtual {p1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setSingleLine(Z)V

    if-eqz p3, :cond_1

    const/4 v1, 0x5

    goto :goto_1

    :cond_1
    const/4 v1, 0x2

    :goto_1
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setMaxLines(I)V

    const/16 v1, 0x30

    invoke-virtual {v0, v1}, Lc/H6;->g(I)I

    move-result v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    const/16 v1, 0x10

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x18

    invoke-virtual {v0, v1}, Lc/H6;->g(I)I

    move-result v2

    const/4 v3, 0x6

    invoke-virtual {v0, v3}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {v0, v1}, Lc/H6;->g(I)I

    move-result v1

    invoke-virtual {v0, v3}, Lc/H6;->g(I)I

    move-result v3

    invoke-virtual {p1, v2, v4, v1, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v1, 0x0

    if-eqz p3, :cond_2

    move-object p3, v1

    goto :goto_2

    :cond_2
    const p3, 0x7f030019

    iget-object v2, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v2, p3}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p3

    :goto_2
    if-eqz p3, :cond_3

    iget p2, p2, Lc/r4;->d:I

    invoke-virtual {p3, p2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    :cond_3
    invoke-virtual {p1, v1, v1, p3, v1}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/16 p2, 0xc

    invoke-virtual {v0, p2}, Lc/H6;->g(I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    return-void
.end method

.method public getDropDownView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3

    iget v0, p0, Lc/F6;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0, p1, p2, p3}, Landroid/widget/ArrayAdapter;->getDropDownView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    return-object p1

    :pswitch_0
    invoke-super {p0, p1, p2, p3}, Landroid/widget/ArrayAdapter;->getDropDownView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object p2, p0, Lc/F6;->b:Ljava/lang/Object;

    check-cast p2, Lc/r4;

    iget p3, p2, Lc/r4;->d:I

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setTextColor(I)V

    iget p2, p2, Lc/r4;->b:I

    invoke-virtual {p1, p2}, Landroid/view/View;->setBackgroundColor(I)V

    const/16 p2, 0x30

    iget-object p3, p0, Lc/F6;->c:Ljava/lang/Object;

    check-cast p3, Lru/drivedeck/launcher/MainActivity;

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setMinHeight(I)V

    const/16 p2, 0x10

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v0

    const/16 v1, 0x8

    invoke-static {p3, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    invoke-static {p3, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p3

    invoke-virtual {p1, v0, v2, p2, p3}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p1

    :pswitch_1
    invoke-super {p0, p1, p2, p3}, Landroid/widget/ArrayAdapter;->getDropDownView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    const/4 p3, 0x1

    invoke-virtual {p0, p2, p1, p3}, Lc/F6;->a(Landroid/view/View;IZ)V

    return-object p2

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 6

    iget v0, p0, Lc/F6;->a:I

    packed-switch v0, :pswitch_data_0

    new-instance p2, Landroid/widget/FrameLayout;

    iget-object p3, p0, Lc/F6;->c:Ljava/lang/Object;

    check-cast p3, Lc/l9;

    iget-object v0, p3, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0}, Landroid/widget/ArrayAdapter;->getCount()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    if-ge p1, v0, :cond_0

    iget-object v0, p3, Lc/l9;->b:Lc/k9;

    iget v0, v0, Lc/k9;->d:F

    const/high16 v3, 0x41000000    # 8.0f

    mul-float/2addr v0, v3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    invoke-virtual {p2, v2, v2, v2, v0}, Landroid/view/View;->setPadding(IIII)V

    new-instance v3, Landroid/widget/AbsListView$LayoutParams;

    iget-object v4, p3, Lc/l9;->b:Lc/k9;

    iget v4, v4, Lc/k9;->d:F

    const/high16 v5, 0x42500000    # 52.0f

    mul-float/2addr v4, v5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    add-int/2addr v4, v0

    const/4 v0, -0x1

    invoke-direct {v3, v0, v4}, Landroid/widget/AbsListView$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v3, Landroid/widget/TextView;

    iget-object p3, p3, Lc/l9;->b:Lc/k9;

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    invoke-direct {v3, p3}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p0, p1}, Landroid/widget/ArrayAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/CharSequence;

    invoke-virtual {v3, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance p3, Ljava/lang/StringBuilder;

    const-string v4, "voice-feedback-choice:"

    invoke-direct {p3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v3, p3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    iget-object p3, p0, Lc/F6;->b:Ljava/lang/Object;

    check-cast p3, Lc/r4;

    invoke-static {v3, p3, v2}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    const/16 p3, 0x11

    invoke-virtual {v3, p3}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v3}, Landroid/widget/TextView;->setSingleLine()V

    const/16 p3, 0x10

    const/16 v2, 0x14

    const/4 v4, 0x2

    invoke-virtual {v3, p3, v2, v1, v4}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    invoke-virtual {v3, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    invoke-virtual {p0, p1}, Landroid/widget/ArrayAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/CharSequence;

    invoke-virtual {p2, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object p2

    :pswitch_0
    invoke-super {p0, p1, p2, p3}, Landroid/widget/ArrayAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    iget-object p2, p0, Lc/F6;->b:Ljava/lang/Object;

    check-cast p2, Lc/r4;

    iget p2, p2, Lc/r4;->d:I

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 p2, 0x30

    iget-object p3, p0, Lc/F6;->c:Ljava/lang/Object;

    check-cast p3, Lru/drivedeck/launcher/MainActivity;

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setMinHeight(I)V

    const/high16 p2, 0x41600000    # 14.0f

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 p2, 0x10

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v0

    const/16 v1, 0x8

    invoke-static {p3, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result v2

    invoke-static {p3, p2}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p2

    invoke-static {p3, v1}, Lc/b7;->f(Landroid/content/Context;I)I

    move-result p3

    invoke-virtual {p1, v0, v2, p2, p3}, Landroid/widget/TextView;->setPadding(IIII)V

    return-object p1

    :pswitch_1
    invoke-super {p0, p1, p2, p3}, Landroid/widget/ArrayAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p2

    const/4 p3, 0x0

    invoke-virtual {p0, p2, p1, p3}, Lc/F6;->a(Landroid/view/View;IZ)V

    return-object p2

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
