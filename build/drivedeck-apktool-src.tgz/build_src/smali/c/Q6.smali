.class public final synthetic Lc/Q6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lorg/json/JSONObject;

.field public final synthetic b:Ljava/util/LinkedHashMap;

.field public final synthetic c:Landroid/widget/Spinner;

.field public final synthetic d:Landroid/widget/Spinner;

.field public final synthetic e:Landroid/widget/CheckBox;

.field public final synthetic f:Landroid/widget/CheckBox;

.field public final synthetic g:Lc/T5;

.field public final synthetic h:Landroid/widget/EditText;

.field public final synthetic i:Landroid/widget/TextView;

.field public final synthetic j:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;Lc/T5;Landroid/widget/EditText;Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q6;->a:Lorg/json/JSONObject;

    iput-object p2, p0, Lc/Q6;->b:Ljava/util/LinkedHashMap;

    iput-object p3, p0, Lc/Q6;->c:Landroid/widget/Spinner;

    iput-object p4, p0, Lc/Q6;->d:Landroid/widget/Spinner;

    iput-object p5, p0, Lc/Q6;->e:Landroid/widget/CheckBox;

    iput-object p6, p0, Lc/Q6;->f:Landroid/widget/CheckBox;

    iput-object p7, p0, Lc/Q6;->g:Lc/T5;

    iput-object p8, p0, Lc/Q6;->h:Landroid/widget/EditText;

    iput-object p9, p0, Lc/Q6;->i:Landroid/widget/TextView;

    iput-object p10, p0, Lc/Q6;->j:Lru/drivedeck/launcher/MainActivity;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget-object v0, p0, Lc/Q6;->a:Lorg/json/JSONObject;

    iget-object v1, p0, Lc/Q6;->b:Ljava/util/LinkedHashMap;

    iget-object v2, p0, Lc/Q6;->c:Landroid/widget/Spinner;

    iget-object v3, p0, Lc/Q6;->d:Landroid/widget/Spinner;

    iget-object v4, p0, Lc/Q6;->e:Landroid/widget/CheckBox;

    iget-object v5, p0, Lc/Q6;->f:Landroid/widget/CheckBox;

    iget-object v6, p0, Lc/Q6;->g:Lc/T5;

    iget-object v7, p0, Lc/Q6;->h:Landroid/widget/EditText;

    iget-object v8, p0, Lc/Q6;->i:Landroid/widget/TextView;

    iget-object v9, p0, Lc/Q6;->j:Lru/drivedeck/launcher/MainActivity;

    :try_start_0
    invoke-static/range {v0 .. v5}, Lc/b7;->d(Lorg/json/JSONObject;Ljava/util/LinkedHashMap;Landroid/widget/Spinner;Landroid/widget/Spinner;Landroid/widget/CheckBox;Landroid/widget/CheckBox;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v0, v1}, Lc/T5;->y0(Lorg/json/JSONObject;Ljava/lang/String;)Lc/Q5;

    move-result-object v0

    invoke-static {v9, v0}, Lc/b7;->j(Lru/drivedeck/launcher/MainActivity;Lc/Q5;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Lc/b7;->h(Landroid/app/Activity;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v0, Lc/i;

    const/16 v1, 0xd

    invoke-direct {v0, v8, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v8, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    return-void
.end method
