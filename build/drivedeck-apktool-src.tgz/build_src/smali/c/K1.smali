.class public final synthetic Lc/K1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ZI)V
    .locals 0

    iput p3, p0, Lc/K1;->a:I

    iput-object p1, p0, Lc/K1;->c:Ljava/lang/Object;

    iput-boolean p2, p0, Lc/K1;->b:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/K1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-boolean v0, p0, Lc/K1;->b:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iget-object v1, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/function/Consumer;

    invoke-interface {v1, v0}, Ljava/util/function/Consumer;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v0, Lc/v4;

    iget-boolean v1, p0, Lc/K1;->b:Z

    invoke-virtual {v0, v1}, Lc/v4;->a(Z)V

    return-void

    :pswitch_1
    iget-boolean v0, p0, Lc/K1;->b:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iget-object v1, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v1, Lc/y4;

    invoke-virtual {v1, v0}, Lc/y4;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-boolean v1, p0, Lc/K1;->b:Z

    invoke-virtual {v0, v1}, Lc/P3;->r(Z)Z

    return-void

    :pswitch_3
    iget-object v0, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    iget-boolean v1, p0, Lc/K1;->b:Z

    if-nez v1, :cond_0

    const-string v1, "voice"

    iput-object v1, v0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->X()V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "package:ru.drivedeck.voice"

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    :goto_0
    return-void

    :pswitch_4
    iget-boolean v0, p0, Lc/K1;->b:Z

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    iget-object v1, p0, Lc/K1;->c:Ljava/lang/Object;

    check-cast v1, Lc/y4;

    invoke-virtual {v1, v0}, Lc/y4;->accept(Ljava/lang/Object;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
