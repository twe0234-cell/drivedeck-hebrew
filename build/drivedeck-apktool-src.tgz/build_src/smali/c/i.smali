.class public final synthetic Lc/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/i;->a:I

    iput-object p1, p0, Lc/i;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v3, p0, Lc/i;->a:I

    packed-switch v3, :pswitch_data_0

    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/n9;

    invoke-virtual {v0}, Lc/n9;->a()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Ljava/net/HttpURLConnection;

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/p8;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/t8;

    invoke-virtual {v0}, Lc/t8;->h()V

    return-void

    :pswitch_3
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    :try_start_0
    invoke-static {}, Lc/j8;->j()V

    sget-object v1, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    sget-object v1, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v1}, Ljava/io/BufferedWriter;->newLine()V

    sget-object v1, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v1}, Ljava/io/BufferedWriter;->flush()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    const-string v2, "shell_write"

    invoke-static {v2, v1}, Lc/N1;->j(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {}, Lc/j8;->d()V

    :try_start_1
    invoke-static {}, Lc/j8;->j()V

    sget-object v1, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    sget-object v0, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v0}, Ljava/io/BufferedWriter;->newLine()V

    sget-object v0, Lc/j8;->d:Ljava/io/BufferedWriter;

    invoke-virtual {v0}, Ljava/io/BufferedWriter;->flush()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    invoke-static {}, Lc/j8;->d()V

    :goto_0
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/Q0;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    return-void

    :pswitch_5
    new-instance v0, Landroid/graphics/Rect;

    iget-object v1, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-direct {v0, v2, v2, v3, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    invoke-virtual {v1, v0, v2}, Landroid/view/View;->requestRectangleOnScreen(Landroid/graphics/Rect;Z)Z

    return-void

    :pswitch_6
    iget-object v1, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v1, Lc/u5;

    iget-object v2, v1, Lc/u5;->c:Lc/Z;

    if-eqz v2, :cond_4

    const/high16 v2, -0x80000000

    :try_start_2
    iget-object v3, v1, Lc/u5;->a:Lru/drivedeck/launcher/MainActivity;

    const-class v4, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/bluetooth/BluetoothManager;

    if-nez v3, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v3}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    :goto_1
    if-nez v0, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothAdapter;->getState()I

    move-result v2
    :try_end_2
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :goto_2
    const/16 v0, 0xc

    if-ne v2, v0, :cond_2

    iget-object v0, v1, Lc/u5;->c:Lc/Z;

    invoke-virtual {v1}, Lc/u5;->a()V

    invoke-virtual {v0}, Lc/Z;->run()V

    goto :goto_3

    :cond_2
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, v1, Lc/u5;->e:J

    cmp-long v0, v2, v4

    if-ltz v0, :cond_3

    iget-object v0, v1, Lc/u5;->d:Lc/E3;

    invoke-virtual {v1}, Lc/u5;->a()V

    const-string v1, "Bluetooth \u0430\u043a\u0441\u0435\u0441\u0441\u0443\u0430\u0440\u043e\u0432 \u043d\u0435 \u0432\u043a\u043b\u044e\u0447\u0451\u043d. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 Android"

    invoke-virtual {v0, v1}, Lc/E3;->accept(Ljava/lang/Object;)V

    goto :goto_3

    :cond_3
    iget-object v0, v1, Lc/u5;->f:Lc/i;

    iget-object v1, v1, Lc/u5;->b:Landroid/os/Handler;

    const-wide/16 v2, 0xfa

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    :goto_3
    return-void

    :pswitch_7
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/n5;

    iget-object v0, v0, Lc/n5;->a:Lc/o5;

    iget-boolean v3, v0, Lc/o5;->c:Z

    if-nez v3, :cond_5

    goto :goto_6

    :cond_5
    iget-object v3, v0, Lc/o5;->b:Landroid/net/ConnectivityManager;

    invoke-virtual {v3}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v3

    if-eqz v3, :cond_6

    const/16 v4, 0x10

    invoke-virtual {v3, v4}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v3

    if-eqz v3, :cond_6

    move v3, v1

    goto :goto_4

    :cond_6
    move v3, v2

    :goto_4
    if-eqz v3, :cond_7

    iget-boolean v4, v0, Lc/o5;->d:Z

    if-nez v4, :cond_7

    goto :goto_5

    :cond_7
    move v1, v2

    :goto_5
    iput-boolean v3, v0, Lc/o5;->d:Z

    if-eqz v1, :cond_8

    iget-object v0, v0, Lc/o5;->e:Lc/F3;

    invoke-virtual {v0}, Lc/F3;->run()V

    :cond_8
    :goto_6
    return-void

    :pswitch_8
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/M3;

    iget-object v3, v0, Lc/M3;->a:Lc/P3;

    invoke-virtual {v3}, Lc/P3;->p()V

    invoke-static {}, Lc/G8;->l()V

    iget-object v3, v0, Lc/M3;->a:Lc/P3;

    iget-object v3, v3, Lc/P3;->b0:Lc/y;

    iget-object v4, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v4}, Lc/J;->b(Landroid/content/Context;)Z

    move-result v4

    if-nez v4, :cond_9

    iget-object v1, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0421\u043b\u0443\u0436\u0431\u0430 Bluetooth-\u0430\u0443\u0434\u0438\u043e \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430 \u043d\u0430 \u044d\u0442\u043e\u043c \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435"

    invoke-static {v1, v3, v1, v2}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_7

    :cond_9
    iget-object v4, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    const-string v5, "com.android.bluetooth"

    invoke-static {v4, v5}, Lc/G8;->c0(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v4, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    iget-object v4, v4, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4, v1}, Lc/n1;->A0(Z)V

    iget-object v1, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v4, ""

    invoke-virtual {v1, v4}, Lc/n1;->v0(Ljava/lang/String;)V

    iget-object v1, v3, Lc/y;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v1, :cond_a

    iget-object v1, v1, Lc/Q3;->t:Lc/P3;

    iget-object v3, v1, Lc/P3;->y1:Lc/P;

    iget-object v5, v3, Lc/P;->a:Lc/K;

    invoke-virtual {v5}, Lc/K;->b()V

    iput-object v4, v3, Lc/P;->m:Ljava/lang/String;

    iput-object v4, v3, Lc/P;->l:Ljava/lang/String;

    iput-boolean v2, v3, Lc/P;->o:Z

    iput-boolean v2, v3, Lc/P;->n:Z

    invoke-virtual {v3}, Lc/P;->f()V

    invoke-virtual {v1}, Lc/P3;->Y()V

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    :cond_a
    :goto_7
    iget-object v1, v0, Lc/M3;->a:Lc/P3;

    invoke-virtual {v1}, Lc/P3;->Y()V

    iget-object v0, v0, Lc/M3;->a:Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_9
    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->c()V

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->f:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void

    :pswitch_a
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Landroid/media/session/MediaController;

    :try_start_3
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v1

    if-eqz v1, :cond_b

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v2

    const/4 v3, 0x3

    if-eq v2, v3, :cond_c

    invoke-virtual {v1}, Landroid/media/session/PlaybackState;->getState()I

    move-result v1

    const/4 v2, 0x6

    if-eq v1, v2, :cond_c

    goto :goto_8

    :catch_3
    move-exception v1

    goto :goto_9

    :cond_b
    :goto_8
    invoke-virtual {v0}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v1

    invoke-virtual {v1}, Landroid/media/session/MediaController$TransportControls;->play()V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_a

    :goto_9
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Play failed: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "DriveDeckMusic"

    invoke-static {v2, v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_c
    :goto_a
    return-void

    :pswitch_b
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/P3;

    if-eqz v0, :cond_d

    iget-boolean v1, v0, Lc/P3;->U1:Z

    if-eqz v1, :cond_d

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-eqz v1, :cond_d

    invoke-virtual {v0}, Lc/P3;->N()V

    :cond_d
    return-void

    :pswitch_c
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/u0;

    iget-object v0, v0, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iput-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->y:Z

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-nez v1, :cond_e

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-eqz v1, :cond_e

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_e

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->j0(Landroid/view/View;)V

    :cond_e
    return-void

    :pswitch_d
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/o1;

    invoke-virtual {v0}, Lc/o1;->b()V

    return-void

    :pswitch_e
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    return-void

    :pswitch_f
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/function/BooleanSupplier;

    invoke-interface {v0}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    return-void

    :pswitch_10
    iget-object v1, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v1, Lc/g0;

    iput-boolean v2, v1, Lc/g0;->s:Z

    iput-object v0, v1, Lc/g0;->t:Lc/j;

    return-void

    :pswitch_11
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/S;

    invoke-virtual {v0}, Lc/S;->a()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_f
    return-void

    :pswitch_12
    iget-object v0, p0, Lc/i;->b:Ljava/lang/Object;

    check-cast v0, Lc/j;

    invoke-static {v0}, Lc/j;->a(Lc/j;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
