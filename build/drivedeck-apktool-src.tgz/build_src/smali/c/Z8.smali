.class public final synthetic Lc/Z8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:J

.field public final synthetic b:Lc/n1;

.field public final synthetic c:Lc/U8;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(JLc/n1;Lc/U8;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lc/Z8;->a:J

    iput-object p3, p0, Lc/Z8;->b:Lc/n1;

    iput-object p4, p0, Lc/Z8;->c:Lc/U8;

    iput p5, p0, Lc/Z8;->d:I

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 4

    check-cast p1, Lc/a9;

    iget-object v0, p0, Lc/Z8;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->Q()J

    move-result-wide v0

    iget-wide v2, p0, Lc/Z8;->a:J

    cmp-long v0, v2, v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/Z8;->c:Lc/U8;

    iget v1, v0, Lc/U8;->a:I

    iget v2, p0, Lc/Z8;->d:I

    if-le v1, v2, :cond_1

    invoke-interface {p1, v0}, Lc/a9;->c(Lc/U8;)V

    goto :goto_0

    :cond_1
    invoke-interface {p1}, Lc/a9;->b()V

    :goto_0
    return-void
.end method
