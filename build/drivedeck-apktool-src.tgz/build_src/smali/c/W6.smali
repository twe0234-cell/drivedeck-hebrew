.class public final synthetic Lc/W6;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic c:Lc/T5;

.field public final synthetic d:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Lc/T5;Landroid/widget/TextView;I)V
    .locals 0

    iput p4, p0, Lc/W6;->a:I

    iput-object p1, p0, Lc/W6;->b:Lru/drivedeck/launcher/MainActivity;

    iput-object p2, p0, Lc/W6;->c:Lc/T5;

    iput-object p3, p0, Lc/W6;->d:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/W6;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v3, p0, Lc/W6;->c:Lc/T5;

    invoke-virtual {v3}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v2

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v4, p0, Lc/W6;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v4}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u042d\u043a\u0441\u043f\u043e\u0440\u0442 PID"

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u0412 \u0444\u0430\u0439\u043b"

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v5, "\u0412 \u0431\u0443\u0444\u0435\u0440 \u043e\u0431\u043c\u0435\u043d\u0430"

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v1, v5}, [Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lc/T6;

    iget-object v5, p0, Lc/W6;->d:Landroid/widget/TextView;

    const/4 v6, 0x1

    move-object v1, v8

    invoke-direct/range {v1 .. v6}, Lc/T6;-><init>(Ljava/lang/String;Lc/T5;Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;I)V

    invoke-virtual {v0, v7, v8}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :pswitch_0
    iget-object v3, p0, Lc/W6;->c:Lc/T5;

    invoke-virtual {v3}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v2

    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v4, p0, Lc/W6;->b:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, v4}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "\u0418\u043c\u043f\u043e\u0440\u0442 PID"

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "\u0418\u0437 \u0444\u0430\u0439\u043b\u0430"

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v5, "\u0418\u0437 \u0431\u0443\u0444\u0435\u0440\u0430 \u043e\u0431\u043c\u0435\u043d\u0430"

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v1, v5}, [Ljava/lang/String;

    move-result-object v7

    new-instance v8, Lc/T6;

    iget-object v5, p0, Lc/W6;->d:Landroid/widget/TextView;

    const/4 v6, 0x0

    move-object v1, v8

    invoke-direct/range {v1 .. v6}, Lc/T6;-><init>(Ljava/lang/String;Lc/T5;Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;I)V

    invoke-virtual {v0, v7, v8}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
