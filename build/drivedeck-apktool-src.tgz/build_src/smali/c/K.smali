.class public final Lc/K;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:J

.field public b:J

.field public c:J

.field public d:I

.field public e:I

.field public f:Z

.field public g:Z


# virtual methods
.method public final a(J)J
    .locals 7

    iget-boolean v0, p0, Lc/K;->f:Z

    const-wide/16 v1, -0x1

    if-eqz v0, :cond_3

    iget-wide v3, p0, Lc/K;->b:J

    const-wide/16 v5, 0x0

    cmp-long v0, v3, v5

    if-gez v0, :cond_0

    goto :goto_1

    :cond_0
    iget-wide v3, p0, Lc/K;->c:J

    sub-long/2addr p1, v3

    invoke-static {v5, v6, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide p1

    iget-boolean v0, p0, Lc/K;->g:Z

    if-eqz v0, :cond_1

    const-wide/16 v3, 0x7530

    cmp-long v3, p1, v3

    if-lez v3, :cond_1

    return-wide v1

    :cond_1
    iget-wide v1, p0, Lc/K;->b:J

    if-eqz v0, :cond_2

    const-wide/16 v3, 0x1388

    invoke-static {p1, p2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p1

    goto :goto_0

    :cond_2
    move-wide p1, v5

    :goto_0
    add-long/2addr v1, p1

    iget-wide p1, p0, Lc/K;->a:J

    cmp-long v0, p1, v5

    if-lez v0, :cond_3

    invoke-static {v1, v2, p1, p2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    :cond_3
    :goto_1
    return-wide v1
.end method

.method public final b()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/K;->g:Z

    iput-boolean v0, p0, Lc/K;->f:Z

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc/K;->b:J

    iput-wide v0, p0, Lc/K;->a:J

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/K;->c:J

    const/4 v0, -0x1

    iput v0, p0, Lc/K;->e:I

    iput v0, p0, Lc/K;->d:I

    return-void
.end method
