.class public final Lc/a6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Z

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;


# direct methods
.method public constructor <init>(IIZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lc/a6;->a:I

    iput p2, p0, Lc/a6;->b:I

    iput-boolean p3, p0, Lc/a6;->c:Z

    iput-object p4, p0, Lc/a6;->d:Ljava/lang/String;

    iput-object p5, p0, Lc/a6;->e:Ljava/lang/String;

    iput-object p6, p0, Lc/a6;->f:Ljava/lang/String;

    iput-object p7, p0, Lc/a6;->g:Ljava/lang/String;

    return-void
.end method
