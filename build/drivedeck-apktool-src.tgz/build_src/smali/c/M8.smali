.class public final synthetic Lc/M8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:Landroid/widget/TextView;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Landroid/widget/TextView;

.field public final synthetic e:Landroid/widget/TextView;

.field public final synthetic f:Landroid/widget/TextView;

.field public final synthetic g:Landroid/widget/TextView;

.field public final synthetic h:Landroid/widget/Switch;

.field public final synthetic i:Landroid/widget/Switch;

.field public final synthetic j:Landroid/widget/Switch;

.field public final synthetic k:Landroid/widget/LinearLayout;

.field public final synthetic l:Landroid/widget/LinearLayout;

.field public final synthetic m:Landroid/widget/LinearLayout;

.field public final synthetic n:Landroid/widget/LinearLayout;

.field public final synthetic o:Landroid/widget/TextView;

.field public final synthetic p:Landroid/widget/TextView;

.field public final synthetic q:Landroid/widget/Button;

.field public final synthetic r:Lc/N8;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Switch;Landroid/widget/Switch;Landroid/widget/Switch;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;Lc/N8;)V
    .locals 2

    move-object v0, p0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    move-object v1, p1

    iput-object v1, v0, Lc/M8;->a:Lru/drivedeck/launcher/MainActivity;

    move-object v1, p2

    iput-object v1, v0, Lc/M8;->b:Landroid/widget/TextView;

    move-object v1, p3

    iput-object v1, v0, Lc/M8;->c:Landroid/widget/TextView;

    move-object v1, p4

    iput-object v1, v0, Lc/M8;->d:Landroid/widget/TextView;

    move-object v1, p5

    iput-object v1, v0, Lc/M8;->e:Landroid/widget/TextView;

    move-object v1, p6

    iput-object v1, v0, Lc/M8;->f:Landroid/widget/TextView;

    move-object v1, p7

    iput-object v1, v0, Lc/M8;->g:Landroid/widget/TextView;

    move-object v1, p8

    iput-object v1, v0, Lc/M8;->h:Landroid/widget/Switch;

    move-object v1, p9

    iput-object v1, v0, Lc/M8;->i:Landroid/widget/Switch;

    move-object v1, p10

    iput-object v1, v0, Lc/M8;->j:Landroid/widget/Switch;

    move-object v1, p11

    iput-object v1, v0, Lc/M8;->k:Landroid/widget/LinearLayout;

    move-object v1, p12

    iput-object v1, v0, Lc/M8;->l:Landroid/widget/LinearLayout;

    move-object v1, p13

    iput-object v1, v0, Lc/M8;->m:Landroid/widget/LinearLayout;

    move-object/from16 v1, p14

    iput-object v1, v0, Lc/M8;->n:Landroid/widget/LinearLayout;

    move-object/from16 v1, p15

    iput-object v1, v0, Lc/M8;->o:Landroid/widget/TextView;

    move-object/from16 v1, p16

    iput-object v1, v0, Lc/M8;->p:Landroid/widget/TextView;

    move-object/from16 v1, p17

    iput-object v1, v0, Lc/M8;->q:Landroid/widget/Button;

    move-object/from16 v1, p18

    iput-object v1, v0, Lc/M8;->r:Lc/N8;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    iget-object v0, p0, Lc/M8;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    iget v2, v1, Lc/r4;->d:I

    iget-object v3, p0, Lc/M8;->b:Landroid/widget/TextView;

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, p0, Lc/M8;->c:Landroid/widget/TextView;

    iget v3, v1, Lc/r4;->d:I

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, p0, Lc/M8;->d:Landroid/widget/TextView;

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-boolean v2, v1, Lc/r4;->m:Z

    iget v4, v1, Lc/r4;->e:I

    if-eqz v2, :cond_0

    const v2, -0xb0a399

    goto :goto_0

    :cond_0
    move v2, v4

    :goto_0
    iget-object v5, p0, Lc/M8;->e:Landroid/widget/TextView;

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v5, p0, Lc/M8;->f:Landroid/widget/TextView;

    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v5, p0, Lc/M8;->g:Landroid/widget/TextView;

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setTextColor(I)V

    new-instance v5, Landroid/content/res/ColorStateList;

    const v6, -0x101009e

    filled-new-array {v6}, [I

    move-result-object v6

    const/4 v7, 0x0

    new-array v7, v7, [I

    filled-new-array {v6, v7}, [[I

    move-result-object v6

    filled-new-array {v4, v3}, [I

    move-result-object v4

    invoke-direct {v5, v6, v4}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    iget-object v4, p0, Lc/M8;->h:Landroid/widget/Switch;

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    iget-object v6, p0, Lc/M8;->i:Landroid/widget/Switch;

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    iget-object v7, p0, Lc/M8;->j:Landroid/widget/Switch;

    invoke-virtual {v7, v5}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    iget v5, v1, Lc/r4;->c:I

    invoke-static {v0, v5}, Lc/k6;->r(Lru/drivedeck/launcher/MainActivity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    iget-object v9, p0, Lc/M8;->k:Landroid/widget/LinearLayout;

    invoke-virtual {v9, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v0, v5}, Lc/k6;->r(Lru/drivedeck/launcher/MainActivity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    iget-object v9, p0, Lc/M8;->l:Landroid/widget/LinearLayout;

    invoke-virtual {v9, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v0, v5}, Lc/k6;->r(Lru/drivedeck/launcher/MainActivity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v8

    iget-object v9, p0, Lc/M8;->m:Landroid/widget/LinearLayout;

    invoke-virtual {v9, v8}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v0, v5}, Lc/k6;->r(Lru/drivedeck/launcher/MainActivity;I)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    iget-object v5, p0, Lc/M8;->n:Landroid/widget/LinearLayout;

    invoke-virtual {v5, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v0, p0, Lc/M8;->o:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Lc/M8;->p:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v0, p0, Lc/M8;->q:Landroid/widget/Button;

    iget v2, v1, Lc/r4;->g:I

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    iget v2, v1, Lc/r4;->f:I

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    invoke-static {v4, v1}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-static {v6, v1}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-static {v7, v1}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    iget-object v2, p0, Lc/M8;->r:Lc/N8;

    const/4 v3, 0x1

    invoke-static {v2, v1, v3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    invoke-static {v0, v1, v3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    return-void
.end method
