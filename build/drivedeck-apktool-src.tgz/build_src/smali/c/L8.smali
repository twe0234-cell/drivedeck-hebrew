.class public final synthetic Lc/L8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:[Z

.field public final synthetic c:Landroid/widget/Switch;

.field public final synthetic d:Lc/K8;


# direct methods
.method public synthetic constructor <init>([ZLandroid/widget/Switch;Lc/K8;I)V
    .locals 0

    iput p4, p0, Lc/L8;->a:I

    iput-object p1, p0, Lc/L8;->b:[Z

    iput-object p2, p0, Lc/L8;->c:Landroid/widget/Switch;

    iput-object p3, p0, Lc/L8;->d:Lc/K8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 2

    iget p1, p0, Lc/L8;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/L8;->b:[Z

    const/4 v0, 0x0

    aget-boolean v1, p1, v0

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v1, 0x1

    aput-boolean v1, p1, v0

    if-eqz p2, :cond_1

    iget-object v1, p0, Lc/L8;->c:Landroid/widget/Switch;

    invoke-virtual {v1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_1
    if-eqz p2, :cond_2

    const-string p2, "alpha"

    goto :goto_0

    :cond_2
    const-string p2, "stable"

    :goto_0
    iget-object v1, p0, Lc/L8;->d:Lc/K8;

    invoke-virtual {v1, p2}, Lc/K8;->accept(Ljava/lang/Object;)V

    aput-boolean v0, p1, v0

    :goto_1
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/L8;->b:[Z

    const/4 v0, 0x0

    aget-boolean v1, p1, v0

    if-eqz v1, :cond_3

    goto :goto_3

    :cond_3
    const/4 v1, 0x1

    aput-boolean v1, p1, v0

    if-eqz p2, :cond_4

    iget-object v1, p0, Lc/L8;->c:Landroid/widget/Switch;

    invoke-virtual {v1, v0}, Landroid/widget/Switch;->setChecked(Z)V

    :cond_4
    if-eqz p2, :cond_5

    const-string p2, "beta"

    goto :goto_2

    :cond_5
    const-string p2, "stable"

    :goto_2
    iget-object v1, p0, Lc/L8;->d:Lc/K8;

    invoke-virtual {v1, p2}, Lc/K8;->accept(Ljava/lang/Object;)V

    aput-boolean v0, p1, v0

    :goto_3
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
