.class public final synthetic Lc/u4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/BiConsumer;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/u4;->a:Lru/drivedeck/launcher/MainActivity;

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    check-cast p1, Ljava/lang/Integer;

    check-cast p2, Ljava/lang/String;

    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/u4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Lc/Z;

    const/16 v2, 0xc

    invoke-direct {v1, v0, p1, p2, v2}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->a0(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-virtual {v0, p2, p1}, Lru/drivedeck/launcher/MainActivity;->w(Ljava/lang/String;I)V

    :goto_0
    return-void
.end method
