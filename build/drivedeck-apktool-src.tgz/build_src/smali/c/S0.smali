.class public final Lc/S0;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final A:[I


# instance fields
.field public final a:Lru/drivedeck/launcher/MainActivity;

.field public final b:Lc/n1;

.field public final c:Landroid/text/TextPaint;

.field public final d:Landroid/text/TextPaint;

.field public final e:Landroid/graphics/Paint;

.field public final f:Landroid/graphics/Rect;

.field public final g:Landroid/graphics/RectF;

.field public final h:Landroid/graphics/RectF;

.field public final i:Landroid/util/SparseArray;

.field public final j:Ljava/text/SimpleDateFormat;

.field public k:Landroid/graphics/Typeface;

.field public l:Lc/R0;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public final r:[Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:Ljava/lang/String;

.field public u:Ljava/lang/String;

.field public v:Landroid/text/StaticLayout;

.field public w:Ljava/lang/String;

.field public x:I

.field public y:I

.field public z:F


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const v0, 0x7f030046

    const v1, 0x7f0300b8

    const v2, 0x7f0300ac

    const v3, 0x7f0300be

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lc/S0;->A:[I

    return-void
.end method

.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/text/TextPaint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v0, p0, Lc/S0;->c:Landroid/text/TextPaint;

    new-instance v0, Landroid/text/TextPaint;

    invoke-direct {v0, v1}, Landroid/text/TextPaint;-><init>(I)V

    iput-object v0, p0, Lc/S0;->d:Landroid/text/TextPaint;

    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/S0;->e:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lc/S0;->f:Landroid/graphics/Rect;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/S0;->g:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/S0;->h:Landroid/graphics/RectF;

    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    iput-object v0, p0, Lc/S0;->i:Landroid/util/SparseArray;

    const-string v0, ""

    iput-object v0, p0, Lc/S0;->m:Ljava/lang/String;

    iput-object v0, p0, Lc/S0;->n:Ljava/lang/String;

    const-string v1, "\u043c/\u0441"

    iput-object v1, p0, Lc/S0;->o:Ljava/lang/String;

    const-string v1, "\u2014"

    iput-object v1, p0, Lc/S0;->p:Ljava/lang/String;

    iput-object v1, p0, Lc/S0;->q:Ljava/lang/String;

    filled-new-array {v1, v1, v1, v1}, [Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lc/S0;->r:[Ljava/lang/String;

    iput-object v1, p0, Lc/S0;->s:Ljava/lang/String;

    iput-object v1, p0, Lc/S0;->t:Ljava/lang/String;

    const-string v1, "\u2014 / \u2014"

    iput-object v1, p0, Lc/S0;->u:Ljava/lang/String;

    iput-object v0, p0, Lc/S0;->w:Ljava/lang/String;

    iput-object p1, p0, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    new-instance v0, Lc/n1;

    invoke-direct {v0, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/S0;->b:Lc/n1;

    new-instance v0, Ljava/text/SimpleDateFormat;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object p1

    const-string v1, "HH:mm"

    invoke-direct {v0, v1, p1}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    iput-object v0, p0, Lc/S0;->j:Ljava/text/SimpleDateFormat;

    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V
    .locals 10

    move-object v9, p0

    move/from16 v0, p6

    iget-object v1, v9, Lc/S0;->c:Landroid/text/TextPaint;

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    iget-object v2, v9, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    move-object v3, p2

    invoke-static {v2, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float v4, p5, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(FF)F

    move-result v5

    div-float/2addr v4, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    mul-float v6, v3, v0

    invoke-virtual {v1, v6}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    sub-float v3, p3, v0

    const/4 v8, 0x0

    move-object v0, p0

    move-object v1, p1

    move v4, p4

    move v5, p5

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v8}, Lc/S0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    return-void
.end method

.method public final b(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V
    .locals 15

    move-object v8, p0

    move/from16 v9, p2

    move-object/from16 v10, p7

    const/high16 v0, 0x42940000    # 74.0f

    mul-float v0, v0, p8

    div-float v0, p5, v0

    const/high16 v1, 0x42c00000    # 96.0f

    mul-float v1, v1, p8

    div-float v1, p6, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const v1, 0x3faccccd    # 1.35f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    mul-float v11, v0, p8

    const/high16 v0, 0x41000000    # 8.0f

    mul-float v12, p8, v0

    const/high16 v0, 0x42bc0000    # 94.0f

    mul-float/2addr v0, v11

    sub-float v0, p6, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    const/4 v2, 0x0

    invoke-static {v2, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-static {v12, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    add-float v13, v0, p4

    sget-object v0, Lc/S0;->A:[I

    aget v2, v0, v9

    div-float v0, p5, v1

    add-float v14, v0, p3

    const/high16 v0, 0x41600000    # 14.0f

    mul-float/2addr v0, v11

    add-float v4, v0, v13

    const/high16 v0, 0x41e00000    # 28.0f

    mul-float/2addr v0, v11

    iget v6, v10, Lc/r4;->d:I

    mul-float/2addr v0, v1

    const/high16 v1, 0x40400000    # 3.0f

    div-float v5, v0, v1

    move-object v0, p0

    move-object/from16 v1, p1

    move v3, v14

    invoke-virtual/range {v0 .. v6}, Lc/S0;->e(Landroid/graphics/Canvas;IFFFI)V

    if-nez p9, :cond_0

    const v0, 0x3e4ccccd    # 0.2f

    mul-float v0, v0, p5

    add-float v2, v0, p3

    const/high16 v0, 0x42100000    # 36.0f

    mul-float/2addr v0, v11

    add-float v5, v0, v13

    const v0, 0x3f4ccccd    # 0.8f

    mul-float v0, v0, p5

    add-float v4, v0, p3

    move-object v0, p0

    move-object/from16 v1, p1

    move v3, v5

    move-object/from16 v6, p7

    move/from16 v7, p8

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    :cond_0
    const/4 v0, 0x3

    const/high16 v1, 0x42380000    # 46.0f

    if-ne v9, v0, :cond_1

    iget-object v2, v8, Lc/S0;->s:Ljava/lang/String;

    mul-float/2addr v1, v11

    add-float v4, v1, v13

    sub-float v9, p5, v12

    const/high16 v0, 0x41900000    # 18.0f

    mul-float v12, v11, v0

    iget v7, v10, Lc/r4;->d:I

    move-object v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move v5, v9

    move v6, v12

    invoke-virtual/range {v0 .. v7}, Lc/S0;->a(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    iget-object v0, v8, Lc/S0;->t:Ljava/lang/String;

    const/high16 v1, 0x428c0000    # 70.0f

    mul-float/2addr v11, v1

    add-float v1, v11, v13

    iget v2, v10, Lc/r4;->d:I

    move-object/from16 p2, p0

    move-object/from16 p3, p1

    move-object/from16 p4, v0

    move/from16 p5, v14

    move/from16 p6, v1

    move/from16 p7, v9

    move/from16 p8, v12

    move/from16 p9, v2

    invoke-virtual/range {p2 .. p9}, Lc/S0;->a(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    goto :goto_3

    :cond_1
    if-nez v9, :cond_2

    if-eqz p9, :cond_2

    iget-object v0, v8, Lc/S0;->q:Ljava/lang/String;

    :goto_0
    move-object v2, v0

    goto :goto_1

    :cond_2
    iget-object v0, v8, Lc/S0;->r:[Ljava/lang/String;

    aget-object v0, v0, v9

    goto :goto_0

    :goto_1
    mul-float/2addr v1, v11

    add-float v4, v1, v13

    sub-float v12, p5, v12

    const/high16 v0, 0x41b80000    # 23.0f

    mul-float v6, v11, v0

    iget v7, v10, Lc/r4;->d:I

    move-object v0, p0

    move-object/from16 v1, p1

    move v3, v14

    move v5, v12

    invoke-virtual/range {v0 .. v7}, Lc/S0;->a(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    if-nez v9, :cond_4

    if-eqz p9, :cond_3

    const-string v0, "\u0412\u043b\u0430\u0436\u043d\u043e\u0441\u0442\u044c"

    goto :goto_2

    :cond_3
    const-string v0, "%"

    goto :goto_2

    :cond_4
    const/4 v0, 0x1

    if-ne v9, v0, :cond_5

    iget-object v0, v8, Lc/S0;->o:Ljava/lang/String;

    goto :goto_2

    :cond_5
    const-string v0, "\u043c\u043c \u0440\u0442. \u0441\u0442."

    :goto_2
    const/high16 v1, 0x42980000    # 76.0f

    mul-float/2addr v1, v11

    add-float/2addr v1, v13

    const/high16 v2, 0x41400000    # 12.0f

    mul-float/2addr v2, v11

    iget v3, v10, Lc/r4;->e:I

    move-object/from16 p2, p0

    move-object/from16 p3, p1

    move-object/from16 p4, v0

    move/from16 p5, v14

    move/from16 p6, v1

    move/from16 p7, v12

    move/from16 p8, v2

    move/from16 p9, v3

    invoke-virtual/range {p2 .. p9}, Lc/S0;->a(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    :goto_3
    return-void
.end method

.method public final c(Landroid/graphics/Canvas;Landroid/graphics/RectF;Lc/R0;Ljava/lang/String;ILc/r4;FZLandroid/graphics/RectF;)V
    .locals 30

    move-object/from16 v10, p0

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    move-object/from16 v11, p9

    const/4 v12, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x2

    const/4 v15, 0x1

    invoke-virtual/range {p9 .. p9}, Landroid/graphics/RectF;->setEmpty()V

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_34

    const/4 v2, 0x0

    cmpg-float v3, p7, v2

    if-gtz v3, :cond_0

    goto/16 :goto_2c

    :cond_0
    iget-object v3, v10, Lc/S0;->l:Lc/R0;

    if-ne v3, v1, :cond_1

    goto/16 :goto_b

    :cond_1
    iput-object v1, v10, Lc/S0;->l:Lc/R0;

    iget-object v3, v1, Lc/R0;->a:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_2

    const-string v3, "\u041c\u0435\u0441\u0442\u043e\u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    :cond_2
    iput-object v3, v10, Lc/S0;->m:Ljava/lang/String;

    invoke-virtual/range {p3 .. p3}, Lc/R0;->b()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v10, Lc/S0;->n:Ljava/lang/String;

    const-string v3, "\u2014"

    iget-object v4, v1, Lc/R0;->f:Ljava/lang/Integer;

    if-nez v4, :cond_3

    move-object v5, v3

    goto :goto_0

    :cond_3
    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    :goto_0
    iget-object v6, v10, Lc/S0;->r:[Ljava/lang/String;

    aput-object v5, v6, v13

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v7, v6, v13

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, ""

    if-nez v4, :cond_4

    move-object v4, v7

    goto :goto_1

    :cond_4
    const-string v4, "%"

    :goto_1
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    iput-object v4, v10, Lc/S0;->q:Ljava/lang/String;

    const-string v4, "%.1f"

    const-string v5, "ru"

    iget-object v8, v1, Lc/R0;->j:Ljava/lang/Double;

    if-nez v8, :cond_5

    move-object v2, v3

    goto :goto_2

    :cond_5
    new-instance v9, Ljava/util/Locale;

    invoke-direct {v9, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    filled-new-array {v8}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v9, v4, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    :goto_2
    aput-object v2, v6, v15

    iget-object v2, v1, Lc/R0;->g:Ljava/lang/Integer;

    if-nez v2, :cond_6

    move-object v2, v3

    goto :goto_3

    :cond_6
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    :goto_3
    aput-object v2, v6, v14

    const-string v2, " \u00b7 "

    if-nez v8, :cond_7

    const-string v1, "\u0412\u0435\u0442\u0435\u0440 \u2014"

    goto/16 :goto_8

    :cond_7
    iget-object v1, v1, Lc/R0;->l:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v17

    sparse-switch v17, :sswitch_data_0

    :goto_4
    const/4 v9, -0x1

    goto/16 :goto_5

    :sswitch_0
    const-string v9, "sw"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_4

    :cond_8
    const/4 v9, 0x7

    goto :goto_5

    :sswitch_1
    const-string v9, "se"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    goto :goto_4

    :cond_9
    const/4 v9, 0x6

    goto :goto_5

    :sswitch_2
    const-string v9, "nw"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_a

    goto :goto_4

    :cond_a
    const/4 v9, 0x5

    goto :goto_5

    :sswitch_3
    const-string v9, "ne"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    goto :goto_4

    :cond_b
    move v9, v12

    goto :goto_5

    :sswitch_4
    const-string v9, "w"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    goto :goto_4

    :cond_c
    const/4 v9, 0x3

    goto :goto_5

    :sswitch_5
    const-string v9, "s"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_d

    goto :goto_4

    :cond_d
    move v9, v14

    goto :goto_5

    :sswitch_6
    const-string v9, "n"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e

    goto :goto_4

    :cond_e
    move v9, v15

    goto :goto_5

    :sswitch_7
    const-string v9, "e"

    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_f

    goto :goto_4

    :cond_f
    move v9, v13

    :goto_5
    packed-switch v9, :pswitch_data_0

    move-object v1, v7

    goto :goto_6

    :pswitch_0
    const-string v1, "\u042e\u0417"

    goto :goto_6

    :pswitch_1
    const-string v1, "\u042e\u0412"

    goto :goto_6

    :pswitch_2
    const-string v1, "\u0421\u0417"

    goto :goto_6

    :pswitch_3
    const-string v1, "\u0421\u0412"

    goto :goto_6

    :pswitch_4
    const-string v1, "\u0417"

    goto :goto_6

    :pswitch_5
    const-string v1, "\u042e"

    goto :goto_6

    :pswitch_6
    const-string v1, "\u0421"

    goto :goto_6

    :pswitch_7
    const-string v1, "\u0412"

    :goto_6
    new-instance v9, Ljava/lang/StringBuilder;

    const-string v13, "\u0412\u0435\u0442\u0435\u0440 "

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    new-instance v13, Ljava/util/Locale;

    invoke-direct {v13, v5}, Ljava/util/Locale;-><init>(Ljava/lang/String;)V

    filled-new-array {v8}, [Ljava/lang/Object;

    move-result-object v5

    invoke-static {v13, v4, v5}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " \u043c/\u0441"

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_10

    move-object v1, v7

    goto :goto_7

    :cond_10
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :goto_7
    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_8
    invoke-virtual {v1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "\u043c/\u0441"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-gez v2, :cond_11

    goto :goto_9

    :cond_11
    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    :goto_9
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v10, Lc/S0;->o:Ljava/lang/String;

    if-nez v8, :cond_12

    goto :goto_a

    :cond_12
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v2, v6, v15

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v10, Lc/S0;->o:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :goto_a
    iput-object v3, v10, Lc/S0;->p:Ljava/lang/String;

    :goto_b
    sget-object v1, Lc/s0;->c:Lc/s0;

    iget-object v2, v10, Lc/S0;->b:Lc/n1;

    invoke-virtual {v2, v1}, Lc/n1;->X(Lc/s0;)I

    move-result v1

    invoke-static {v1}, Lc/r9;->b(I)Landroid/graphics/Typeface;

    move-result-object v1

    iput-object v1, v10, Lc/S0;->k:Landroid/graphics/Typeface;

    iget-object v1, v10, Lc/S0;->c:Landroid/text/TextPaint;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextScaleX(F)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v13

    invoke-virtual/range {p1 .. p2}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    const/high16 v1, 0x41800000    # 16.0f

    mul-float v9, p7, v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->width()F

    move-result v1

    invoke-virtual/range {p2 .. p2}, Landroid/graphics/RectF;->height()F

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const v2, 0x3da3d70a    # 0.08f

    mul-float/2addr v1, v2

    invoke-static {v9, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    iget-object v8, v10, Lc/S0;->g:Landroid/graphics/RectF;

    iget v2, v0, Landroid/graphics/RectF;->left:F

    add-float/2addr v2, v1

    iget v3, v0, Landroid/graphics/RectF;->top:F

    add-float/2addr v3, v1

    iget v4, v0, Landroid/graphics/RectF;->right:F

    sub-float/2addr v4, v1

    iget v5, v0, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v5, v1

    invoke-virtual {v8, v2, v3, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v7

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v6

    iget-object v1, v10, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    const/high16 v2, 0x42400000    # 48.0f

    invoke-static {v1, v2}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v3

    const/high16 v4, 0x42c00000    # 96.0f

    invoke-static {v1, v4}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v1

    invoke-static {v7, v6}, Ljava/lang/Math;->min(FF)F

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v4, 0x43000000    # 128.0f

    mul-float v4, v4, p7

    cmpl-float v4, v7, v4

    if-ltz v4, :cond_13

    const/high16 v4, 0x42b00000    # 88.0f

    mul-float v4, v4, p7

    cmpl-float v4, v6, v4

    if-ltz v4, :cond_13

    cmpl-float v3, v1, v3

    if-ltz v3, :cond_13

    move v3, v15

    goto :goto_c

    :cond_13
    const/4 v3, 0x0

    :goto_c
    const/high16 v4, 0x41000000    # 8.0f

    mul-float v18, p7, v4

    mul-float v2, v2, p7

    if-eqz p8, :cond_14

    if-eqz v3, :cond_14

    iget v4, v0, Landroid/graphics/RectF;->right:F

    sub-float v5, v4, v1

    iget v0, v0, Landroid/graphics/RectF;->top:F

    add-float/2addr v1, v0

    invoke-virtual {v11, v5, v0, v4, v1}, Landroid/graphics/RectF;->set(FFFF)V

    :cond_14
    const/high16 v0, 0x42c80000    # 100.0f

    mul-float v0, v0, p7

    cmpg-float v1, v6, v0

    iget-object v5, v10, Lc/S0;->h:Landroid/graphics/RectF;

    const/high16 v19, 0x40400000    # 3.0f

    const/high16 v20, 0x40000000    # 2.0f

    const/high16 v4, 0x43a00000    # 320.0f

    const/high16 v21, 0x430c0000    # 140.0f

    const/high16 v22, 0x40800000    # 4.0f

    const/high16 v23, 0x42980000    # 76.0f

    if-ltz v1, :cond_15

    mul-float v24, p7, v21

    cmpg-float v1, v7, v24

    if-gez v1, :cond_16

    const/high16 v1, 0x433e0000    # 190.0f

    mul-float v1, v1, p7

    cmpg-float v1, v6, v1

    if-gez v1, :cond_16

    :cond_15
    move-object v15, v5

    move/from16 v25, v7

    move-object v12, v8

    goto/16 :goto_22

    :cond_16
    const/high16 v1, 0x43900000    # 288.0f

    mul-float v21, p7, v1

    cmpl-float v1, v7, v21

    const/high16 v25, 0x42e00000    # 112.0f

    const/high16 v26, 0x42900000    # 72.0f

    if-ltz v1, :cond_1e

    div-float v27, v7, v6

    const v28, 0x3fb9999a    # 1.45f

    cmpl-float v28, v27, v28

    if-ltz v28, :cond_1e

    const/high16 v0, 0x44020000    # 520.0f

    mul-float v0, v0, p7

    cmpl-float v0, v7, v0

    if-ltz v0, :cond_17

    const/high16 v0, 0x43340000    # 180.0f

    mul-float v0, v0, p7

    cmpl-float v0, v6, v0

    if-ltz v0, :cond_17

    move/from16 v16, v15

    goto :goto_d

    :cond_17
    const/16 v16, 0x0

    :goto_d
    const/high16 v0, 0x43aa0000    # 340.0f

    mul-float v0, v0, p7

    cmpl-float v0, v7, v0

    if-ltz v0, :cond_18

    const/high16 v0, 0x43080000    # 136.0f

    mul-float v0, v0, p7

    cmpg-float v0, v6, v0

    if-gez v0, :cond_18

    move/from16 v22, v15

    goto :goto_e

    :cond_18
    const/16 v22, 0x0

    :goto_e
    mul-float v0, p7, v25

    mul-float v1, p7, v4

    const v2, 0x3ee147ae    # 0.44f

    mul-float/2addr v7, v2

    invoke-static {v1, v7}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    iget v1, v8, Landroid/graphics/RectF;->left:F

    add-float/2addr v1, v0

    add-float/2addr v1, v9

    iget v2, v8, Landroid/graphics/RectF;->top:F

    add-float v2, v2, v18

    iget v3, v8, Landroid/graphics/RectF;->right:F

    iget v4, v8, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v5, v1, v2, v3, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget v1, v8, Landroid/graphics/RectF;->left:F

    add-float/2addr v1, v0

    iput v1, v8, Landroid/graphics/RectF;->right:F

    iget v0, v5, Landroid/graphics/RectF;->left:F

    div-float v9, v9, v20

    sub-float v4, v0, v9

    iget v0, v8, Landroid/graphics/RectF;->top:F

    add-float v3, v0, v18

    iget v0, v8, Landroid/graphics/RectF;->bottom:F

    sub-float v6, v0, v18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v4

    move-object v9, v5

    move v5, v6

    move-object/from16 v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    const/4 v8, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    move-object/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p6

    move/from16 v5, p7

    invoke-virtual/range {v0 .. v8}, Lc/S0;->d(Landroid/graphics/Canvas;Ljava/lang/String;ILc/r4;FZZF)V

    if-nez v16, :cond_19

    if-nez v22, :cond_19

    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v1, 0x438c0000    # 280.0f

    mul-float v1, v1, p7

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_1a

    invoke-virtual {v9}, Landroid/graphics/RectF;->height()F

    move-result v0

    const/high16 v1, 0x42d00000    # 104.0f

    mul-float v1, v1, p7

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_1a

    const/high16 v0, 0x40600000    # 3.5f

    cmpl-float v0, v27, v0

    if-gez v0, :cond_19

    goto :goto_10

    :cond_19
    :goto_f
    move-object/from16 v29, v9

    goto/16 :goto_12

    :cond_1a
    :goto_10
    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v0

    cmpl-float v0, v0, v24

    if-ltz v0, :cond_1b

    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v0

    cmpg-float v0, v0, v21

    if-gez v0, :cond_1b

    invoke-virtual {v9}, Landroid/graphics/RectF;->height()F

    move-result v0

    mul-float v1, p7, v26

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_1b

    goto :goto_f

    :cond_1b
    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v0

    mul-float v1, p7, v26

    div-float/2addr v0, v1

    float-to-int v0, v0

    invoke-static {v12, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-static {v15, v0}, Ljava/lang/Math;->max(II)I

    move-result v12

    const/4 v14, 0x0

    :goto_11
    if-ge v14, v12, :cond_32

    iget v0, v9, Landroid/graphics/RectF;->left:F

    int-to-float v1, v14

    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float/2addr v2, v1

    int-to-float v8, v12

    div-float/2addr v2, v8

    add-float v16, v2, v0

    if-lez v14, :cond_1c

    iget v0, v9, Landroid/graphics/RectF;->top:F

    add-float v3, v0, v18

    iget v0, v9, Landroid/graphics/RectF;->bottom:F

    sub-float v5, v0, v18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v16

    move/from16 v4, v16

    move-object/from16 v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    :cond_1c
    iget v4, v9, Landroid/graphics/RectF;->top:F

    invoke-virtual {v9}, Landroid/graphics/RectF;->width()F

    move-result v0

    div-float v5, v0, v8

    invoke-virtual {v9}, Landroid/graphics/RectF;->height()F

    move-result v6

    const/16 v17, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v14

    move/from16 v3, v16

    move-object/from16 v7, p6

    move/from16 v8, p7

    move-object/from16 v29, v9

    move/from16 v9, v17

    invoke-virtual/range {v0 .. v9}, Lc/S0;->b(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    add-int/2addr v14, v15

    move-object/from16 v9, v29

    goto :goto_11

    :goto_12
    const/4 v9, 0x0

    :goto_13
    if-ge v9, v12, :cond_32

    move-object/from16 v8, v29

    iget v0, v8, Landroid/graphics/RectF;->left:F

    rem-int/lit8 v1, v9, 0x2

    int-to-float v1, v1

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float/2addr v2, v1

    div-float v2, v2, v20

    add-float v3, v2, v0

    iget v0, v8, Landroid/graphics/RectF;->top:F

    div-int/lit8 v1, v9, 0x2

    int-to-float v1, v1

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v2

    mul-float/2addr v2, v1

    div-float v2, v2, v20

    add-float v4, v2, v0

    if-eqz v22, :cond_1d

    invoke-virtual {v8}, Landroid/graphics/RectF;->width()F

    move-result v0

    div-float v5, v0, v20

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v0

    div-float v6, v0, v20

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v9

    move-object/from16 v7, p6

    move-object/from16 v29, v8

    move/from16 v8, p7

    move/from16 v17, v9

    move/from16 v9, v16

    invoke-virtual/range {v0 .. v9}, Lc/S0;->f(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    goto :goto_14

    :cond_1d
    move-object/from16 v29, v8

    move/from16 v17, v9

    invoke-virtual/range {v29 .. v29}, Landroid/graphics/RectF;->width()F

    move-result v0

    div-float v5, v0, v20

    invoke-virtual/range {v29 .. v29}, Landroid/graphics/RectF;->height()F

    move-result v0

    div-float v6, v0, v20

    const/4 v9, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v17

    move-object/from16 v7, p6

    move/from16 v8, p7

    invoke-virtual/range {v0 .. v9}, Lc/S0;->h(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    :goto_14
    add-int/lit8 v9, v17, 0x1

    goto :goto_13

    :cond_1e
    move-object/from16 v29, v5

    div-float v4, v7, v6

    const v5, 0x3f6147ae    # 0.88f

    cmpg-float v4, v4, v5

    const/high16 v5, 0x42100000    # 36.0f

    if-gez v4, :cond_23

    const/high16 v4, 0x43700000    # 240.0f

    mul-float v4, v4, p7

    cmpl-float v4, v6, v4

    if-ltz v4, :cond_23

    const/high16 v0, 0x42700000    # 60.0f

    mul-float v0, v0, p7

    mul-float v1, p7, v5

    const/high16 v4, 0x43480000    # 200.0f

    mul-float v4, v4, p7

    cmpl-float v4, v7, v4

    if-ltz v4, :cond_1f

    const/16 v5, 0x70

    goto :goto_15

    :cond_1f
    const/16 v5, 0x54

    :goto_15
    int-to-float v5, v5

    mul-float v5, v5, p7

    sub-float v5, v6, v5

    sub-float/2addr v5, v9

    div-float v5, v5, v22

    invoke-static {v1, v5}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v14

    mul-float v22, v22, v14

    sub-float v6, v6, v22

    sub-float/2addr v6, v9

    iget v0, v8, Landroid/graphics/RectF;->left:F

    iget v1, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v1, v6

    add-float/2addr v1, v9

    iget v5, v8, Landroid/graphics/RectF;->right:F

    iget v7, v8, Landroid/graphics/RectF;->bottom:F

    move-object/from16 v15, v29

    invoke-virtual {v15, v0, v1, v5, v7}, Landroid/graphics/RectF;->set(FFFF)V

    iget v0, v8, Landroid/graphics/RectF;->top:F

    add-float/2addr v0, v6

    iput v0, v8, Landroid/graphics/RectF;->bottom:F

    if-ltz v4, :cond_20

    invoke-virtual {v8}, Landroid/graphics/RectF;->height()F

    move-result v0

    mul-float v1, p7, v25

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_20

    const/16 v21, 0x1

    goto :goto_16

    :cond_20
    const/16 v21, 0x0

    :goto_16
    if-eqz v3, :cond_21

    move/from16 v16, v2

    goto :goto_17

    :cond_21
    const/16 v16, 0x0

    :goto_17
    const/4 v6, 0x1

    const/4 v7, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p6

    move/from16 v5, p7

    move-object v12, v8

    move/from16 v8, v16

    invoke-virtual/range {v0 .. v8}, Lc/S0;->d(Landroid/graphics/Canvas;Ljava/lang/String;ILc/r4;FZZF)V

    iget v2, v12, Landroid/graphics/RectF;->left:F

    iget v0, v15, Landroid/graphics/RectF;->top:F

    div-float v9, v9, v20

    sub-float v5, v0, v9

    iget v4, v12, Landroid/graphics/RectF;->right:F

    move-object/from16 v0, p0

    move v3, v5

    move-object/from16 v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    invoke-virtual {v15}, Landroid/graphics/RectF;->height()F

    move-result v0

    add-float v0, v0, p7

    div-float/2addr v0, v14

    float-to-int v0, v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v1, 0x4

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v12

    const/4 v9, 0x0

    :goto_18
    if-ge v9, v12, :cond_32

    if-eqz v21, :cond_22

    iget v3, v15, Landroid/graphics/RectF;->left:F

    iget v0, v15, Landroid/graphics/RectF;->top:F

    int-to-float v1, v9

    mul-float/2addr v1, v14

    add-float v4, v1, v0

    invoke-virtual {v15}, Landroid/graphics/RectF;->width()F

    move-result v5

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v9

    move v6, v14

    move-object/from16 v7, p6

    move/from16 v8, p7

    move v10, v9

    move/from16 v9, v16

    invoke-virtual/range {v0 .. v9}, Lc/S0;->f(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    :goto_19
    const/4 v0, 0x1

    goto :goto_1a

    :cond_22
    move v10, v9

    iget v3, v15, Landroid/graphics/RectF;->left:F

    iget v0, v15, Landroid/graphics/RectF;->top:F

    int-to-float v1, v10

    mul-float/2addr v1, v14

    add-float v4, v1, v0

    invoke-virtual {v15}, Landroid/graphics/RectF;->width()F

    move-result v5

    const/4 v9, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v10

    move v6, v14

    move-object/from16 v7, p6

    move/from16 v8, p7

    invoke-virtual/range {v0 .. v9}, Lc/S0;->h(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    goto :goto_19

    :goto_1a
    add-int/lit8 v9, v10, 0x1

    move-object/from16 v10, p0

    goto :goto_18

    :cond_23
    move-object v12, v8

    move-object/from16 v15, v29

    if-ltz v1, :cond_24

    const/4 v1, 0x4

    const/4 v10, 0x4

    goto :goto_1b

    :cond_24
    move v10, v14

    const/4 v1, 0x4

    :goto_1b
    if-ne v10, v1, :cond_25

    mul-float v1, p7, v26

    const v4, 0x3e99999a    # 0.3f

    mul-float/2addr v4, v6

    invoke-static {v1, v4}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    :goto_1c
    move/from16 v21, v0

    goto :goto_1d

    :cond_25
    mul-float v0, p7, v5

    const/high16 v1, 0x42300000    # 44.0f

    mul-float v1, v1, p7

    mul-float v4, p7, v23

    sub-float v4, v6, v4

    div-float v4, v4, v20

    invoke-static {v1, v4}, Ljava/lang/Math;->min(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    goto :goto_1c

    :goto_1d
    mul-float v0, p7, v23

    sub-float/2addr v6, v0

    add-float v6, v6, p7

    div-float v6, v6, v21

    float-to-int v0, v6

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    mul-int/2addr v0, v10

    const/4 v1, 0x4

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v8

    add-int v0, v8, v10

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    div-int/2addr v0, v10

    int-to-float v0, v0

    mul-float v22, v21, v0

    if-lez v8, :cond_26

    const/16 v23, 0x1

    goto :goto_1e

    :cond_26
    const/16 v23, 0x0

    :goto_1e
    if-eqz v23, :cond_27

    iget v0, v12, Landroid/graphics/RectF;->left:F

    iget v1, v12, Landroid/graphics/RectF;->bottom:F

    sub-float v4, v1, v22

    iget v5, v12, Landroid/graphics/RectF;->right:F

    invoke-virtual {v15, v0, v4, v5, v1}, Landroid/graphics/RectF;->set(FFFF)V

    iget v0, v15, Landroid/graphics/RectF;->top:F

    sub-float/2addr v0, v9

    iput v0, v12, Landroid/graphics/RectF;->bottom:F

    :cond_27
    if-eqz v3, :cond_28

    move/from16 v16, v2

    goto :goto_1f

    :cond_28
    const/16 v16, 0x0

    :goto_1f
    const/4 v6, 0x1

    const/4 v12, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p6

    move/from16 v5, p7

    move/from16 v25, v7

    move v7, v12

    move v12, v8

    move/from16 v8, v16

    invoke-virtual/range {v0 .. v8}, Lc/S0;->d(Landroid/graphics/Canvas;Ljava/lang/String;ILc/r4;FZZF)V

    if-eqz v23, :cond_32

    const/4 v0, 0x4

    if-ne v10, v0, :cond_29

    const/4 v10, 0x0

    :goto_20
    if-ge v10, v12, :cond_32

    iget v0, v15, Landroid/graphics/RectF;->left:F

    int-to-float v1, v10

    mul-float v1, v1, v25

    int-to-float v2, v12

    div-float/2addr v1, v2

    add-float v3, v1, v0

    iget v4, v15, Landroid/graphics/RectF;->top:F

    div-float v5, v25, v2

    const/4 v9, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v10

    move/from16 v6, v22

    move-object/from16 v7, p6

    move/from16 v8, p7

    invoke-virtual/range {v0 .. v9}, Lc/S0;->b(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    const/4 v0, 0x1

    add-int/2addr v10, v0

    goto :goto_20

    :cond_29
    iget v2, v15, Landroid/graphics/RectF;->left:F

    iget v0, v15, Landroid/graphics/RectF;->top:F

    div-float v9, v9, v20

    sub-float v5, v0, v9

    iget v4, v15, Landroid/graphics/RectF;->right:F

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v5

    move-object/from16 v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    const/4 v10, 0x0

    :goto_21
    if-ge v10, v12, :cond_32

    iget v0, v15, Landroid/graphics/RectF;->left:F

    rem-int/lit8 v1, v10, 0x2

    int-to-float v1, v1

    mul-float v1, v1, v25

    div-float v1, v1, v20

    add-float v3, v1, v0

    iget v0, v15, Landroid/graphics/RectF;->top:F

    div-int/lit8 v1, v10, 0x2

    int-to-float v1, v1

    mul-float v1, v1, v21

    add-float v4, v1, v0

    div-float v5, v25, v20

    const/4 v9, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v10

    move/from16 v6, v21

    move-object/from16 v7, p6

    move/from16 v8, p7

    invoke-virtual/range {v0 .. v9}, Lc/S0;->h(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    const/4 v0, 0x1

    add-int/2addr v10, v0

    goto :goto_21

    :goto_22
    mul-float v0, p7, v4

    cmpl-float v0, v25, v0

    if-ltz v0, :cond_2a

    const/high16 v0, 0x42800000    # 64.0f

    mul-float v0, v0, p7

    cmpl-float v0, v6, v0

    if-ltz v0, :cond_2a

    const/4 v10, 0x1

    goto :goto_23

    :cond_2a
    const/4 v10, 0x0

    :goto_23
    if-eqz v10, :cond_2b

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_24

    :cond_2b
    div-float v7, v25, v6

    cmpl-float v0, v7, v19

    if-ltz v0, :cond_2c

    mul-float v0, p7, v21

    sub-float v7, v25, v0

    mul-float v0, p7, v23

    div-float/2addr v7, v0

    float-to-int v0, v7

    const/4 v9, 0x0

    invoke-static {v9, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v1, 0x4

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    move v8, v0

    goto :goto_24

    :cond_2c
    const/4 v9, 0x0

    move v8, v9

    :goto_24
    if-lez v8, :cond_30

    const/high16 v0, 0x41400000    # 12.0f

    if-eqz v10, :cond_2d

    const/high16 v1, 0x42f00000    # 120.0f

    mul-float v1, v1, p7

    const v2, 0x3eb851ec    # 0.36f

    mul-float v7, v25, v2

    invoke-static {v1, v7}, Ljava/lang/Math;->max(FF)F

    move-result v1

    sub-float v7, v25, v1

    mul-float v1, p7, v0

    sub-float/2addr v7, v1

    goto :goto_25

    :cond_2d
    mul-int/lit8 v1, v8, 0x4c

    int-to-float v1, v1

    mul-float v7, v1, p7

    :goto_25
    iget v1, v12, Landroid/graphics/RectF;->right:F

    sub-float v2, v1, v7

    iget v3, v12, Landroid/graphics/RectF;->top:F

    iget v4, v12, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v15, v2, v3, v1, v4}, Landroid/graphics/RectF;->set(FFFF)V

    iget v1, v15, Landroid/graphics/RectF;->left:F

    mul-float v0, v0, p7

    sub-float v0, v1, v0

    iput v0, v12, Landroid/graphics/RectF;->right:F

    const/high16 v0, 0x40c00000    # 6.0f

    mul-float v0, v0, p7

    sub-float v4, v1, v0

    iget v0, v12, Landroid/graphics/RectF;->top:F

    mul-float v1, p7, v22

    add-float v3, v0, v1

    iget v0, v12, Landroid/graphics/RectF;->bottom:F

    sub-float v5, v0, v1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v4

    move v12, v6

    move-object/from16 v6, p6

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v7}, Lc/S0;->i(Landroid/graphics/Canvas;FFFFLc/r4;F)V

    move v7, v9

    :goto_26
    if-ge v7, v8, :cond_2f

    if-eqz v10, :cond_2e

    iget v0, v15, Landroid/graphics/RectF;->left:F

    rem-int/lit8 v1, v7, 0x2

    int-to-float v1, v1

    invoke-virtual {v15}, Landroid/graphics/RectF;->width()F

    move-result v2

    mul-float/2addr v2, v1

    div-float v2, v2, v20

    add-float v3, v2, v0

    iget v0, v15, Landroid/graphics/RectF;->top:F

    div-int/lit8 v1, v7, 0x2

    int-to-float v1, v1

    mul-float/2addr v1, v12

    div-float v1, v1, v20

    add-float v4, v1, v0

    invoke-virtual {v15}, Landroid/graphics/RectF;->width()F

    move-result v0

    div-float v5, v0, v20

    div-float v6, v12, v20

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v2, v7

    move/from16 v17, v7

    move-object/from16 v7, p6

    move/from16 v24, v8

    move/from16 v8, p7

    move/from16 v21, v9

    move/from16 v9, v16

    invoke-virtual/range {v0 .. v9}, Lc/S0;->f(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    :goto_27
    const/4 v0, 0x1

    goto :goto_28

    :cond_2e
    move/from16 v17, v7

    move/from16 v24, v8

    move/from16 v21, v9

    iget v0, v15, Landroid/graphics/RectF;->left:F

    mul-int/lit8 v7, v17, 0x4c

    int-to-float v1, v7

    mul-float v1, v1, p7

    add-float v3, v1, v0

    iget v4, v15, Landroid/graphics/RectF;->top:F

    mul-float v5, p7, v23

    const/4 v9, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, v17

    move v6, v12

    move-object/from16 v7, p6

    move/from16 v8, p7

    invoke-virtual/range {v0 .. v9}, Lc/S0;->h(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V

    goto :goto_27

    :goto_28
    add-int/lit8 v7, v17, 0x1

    move/from16 v9, v21

    move/from16 v8, v24

    goto :goto_26

    :cond_2f
    :goto_29
    move/from16 v21, v9

    const/4 v0, 0x1

    goto :goto_2a

    :cond_30
    move v12, v6

    goto :goto_29

    :goto_2a
    const/high16 v1, 0x42840000    # 66.0f

    mul-float v1, v1, p7

    cmpl-float v1, v12, v1

    if-ltz v1, :cond_31

    move v6, v0

    goto :goto_2b

    :cond_31
    move/from16 v6, v21

    :goto_2b
    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p4

    move/from16 v3, p5

    move-object/from16 v4, p6

    move/from16 v5, p7

    invoke-virtual/range {v0 .. v8}, Lc/S0;->d(Landroid/graphics/Canvas;Ljava/lang/String;ILc/r4;FZZF)V

    :cond_32
    invoke-virtual/range {p9 .. p9}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_33

    iget v0, v11, Landroid/graphics/RectF;->right:F

    const/high16 v1, 0x41a00000    # 20.0f

    mul-float v1, v1, p7

    sub-float/2addr v0, v1

    iget v2, v11, Landroid/graphics/RectF;->top:F

    add-float/2addr v1, v2

    const/high16 v2, 0x42200000    # 40.0f

    mul-float v2, v2, p7

    move-object/from16 v3, p6

    iget v3, v3, Lc/r4;->e:I

    mul-float v2, v2, v20

    div-float v2, v2, v19

    const v4, 0x7f0300b4

    move-object/from16 p2, p0

    move-object/from16 p3, p1

    move/from16 p4, v4

    move/from16 p5, v0

    move/from16 p6, v1

    move/from16 p7, v2

    move/from16 p8, v3

    invoke-virtual/range {p2 .. p8}, Lc/S0;->e(Landroid/graphics/Canvas;IFFFI)V

    :cond_33
    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_34
    :goto_2c
    return-void

    :sswitch_data_0
    .sparse-switch
        0x65 -> :sswitch_7
        0x6e -> :sswitch_6
        0x73 -> :sswitch_5
        0x77 -> :sswitch_4
        0xdb7 -> :sswitch_3
        0xdc9 -> :sswitch_2
        0xe52 -> :sswitch_1
        0xe64 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final d(Landroid/graphics/Canvas;Ljava/lang/String;ILc/r4;FZZF)V
    .locals 21

    move-object/from16 v9, p0

    move-object/from16 v10, p1

    move-object/from16 v11, p2

    move-object/from16 v12, p4

    move/from16 v13, p5

    iget-object v14, v9, Lc/S0;->g:Landroid/graphics/RectF;

    invoke-virtual {v14}, Landroid/graphics/RectF;->width()F

    move-result v15

    invoke-virtual {v14}, Landroid/graphics/RectF;->height()F

    move-result v16

    const/high16 v0, 0x41a00000    # 20.0f

    mul-float/2addr v0, v13

    const/high16 v1, 0x41500000    # 13.0f

    mul-float/2addr v1, v13

    const v2, 0x3d851eb8    # 0.065f

    mul-float/2addr v2, v15

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v6

    const/4 v8, 0x0

    if-eqz p6, :cond_0

    const v0, 0x3fcccccd    # 1.6f

    mul-float/2addr v0, v6

    move/from16 v17, v0

    goto :goto_0

    :cond_0
    move/from16 v17, v8

    :goto_0
    if-eqz p6, :cond_1

    iget-object v2, v9, Lc/S0;->m:Ljava/lang/String;

    iget v3, v14, Landroid/graphics/RectF;->left:F

    iget v4, v14, Landroid/graphics/RectF;->top:F

    sub-float v5, v15, p8

    iget v7, v12, Lc/r4;->d:I

    const/16 v18, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v10, v8

    move/from16 v8, v18

    invoke-virtual/range {v0 .. v8}, Lc/S0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    goto :goto_1

    :cond_1
    move v10, v8

    :goto_1
    const/high16 v0, 0x42c80000    # 100.0f

    if-eqz p7, :cond_2

    const/high16 v1, 0x42e00000    # 112.0f

    mul-float/2addr v1, v13

    cmpl-float v1, v16, v1

    if-ltz v1, :cond_2

    mul-float v1, v13, v0

    cmpl-float v1, v15, v1

    if-ltz v1, :cond_2

    const/high16 v1, 0x42180000    # 38.0f

    mul-float/2addr v1, v13

    const v2, 0x3e4ccccd    # 0.2f

    mul-float v2, v2, v16

    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v8

    goto :goto_2

    :cond_2
    move v8, v10

    :goto_2
    iget v1, v14, Landroid/graphics/RectF;->top:F

    add-float v1, v1, v17

    iget v2, v14, Landroid/graphics/RectF;->bottom:F

    sub-float/2addr v2, v8

    cmpl-float v7, v8, v10

    const/high16 v3, 0x41000000    # 8.0f

    if-lez v7, :cond_3

    mul-float v4, v13, v3

    goto :goto_3

    :cond_3
    move v4, v10

    :goto_3
    sub-float/2addr v2, v4

    sub-float/2addr v2, v1

    invoke-static {v13, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    const/high16 v4, 0x42900000    # 72.0f

    mul-float/2addr v4, v13

    const v5, 0x3e6147ae    # 0.22f

    mul-float/2addr v5, v15

    const v6, 0x3f19999a    # 0.6f

    mul-float/2addr v6, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->min(FF)F

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(FF)F

    move-result v5

    sub-float v4, v15, v5

    const/high16 v6, 0x41200000    # 10.0f

    mul-float/2addr v6, v13

    sub-float/2addr v4, v6

    invoke-static {v13, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    const/high16 v6, 0x43100000    # 144.0f

    mul-float/2addr v6, v13

    iget-object v10, v9, Lc/S0;->c:Landroid/text/TextPaint;

    iget-object v3, v9, Lc/S0;->k:Landroid/graphics/Typeface;

    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v0, 0x0

    move/from16 v16, v8

    iget-object v8, v9, Lc/S0;->f:Landroid/graphics/Rect;

    invoke-virtual {v10, v11, v0, v3, v8}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    div-float v3, v4, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v18

    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v0

    move/from16 v19, v15

    const/4 v15, 0x1

    invoke-static {v15, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    int-to-float v0, v0

    div-float v0, v18, v0

    invoke-static {v3, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v3, 0x42c80000    # 100.0f

    mul-float/2addr v0, v3

    invoke-static {v6, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-static {v3, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v10, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x0

    invoke-virtual {v10, v11, v3, v0, v8}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v0

    int-to-float v0, v0

    invoke-static {v0, v5}, Ljava/lang/Math;->max(FF)F

    move-result v18

    const/high16 v3, 0x41000000    # 8.0f

    mul-float/2addr v3, v13

    sub-float v2, v2, v18

    const/high16 v20, 0x40000000    # 2.0f

    div-float v2, v2, v20

    const/4 v15, 0x0

    invoke-static {v15, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->min(FF)F

    move-result v2

    add-float v15, v2, v1

    iget v1, v14, Landroid/graphics/RectF;->left:F

    sub-float v2, v18, v0

    div-float v2, v2, v20

    add-float/2addr v2, v15

    move/from16 p6, v3

    iget v3, v12, Lc/r4;->d:I

    iget-object v13, v9, Lc/S0;->k:Landroid/graphics/Typeface;

    invoke-virtual {v10, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/high16 v13, 0x42c80000    # 100.0f

    invoke-virtual {v10, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v13

    const/4 v9, 0x0

    invoke-virtual {v10, v11, v9, v13, v8}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v9

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-static {v13, v9}, Ljava/lang/Math;->max(FF)F

    move-result v9

    div-float/2addr v4, v9

    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v9

    const/4 v13, 0x1

    invoke-static {v13, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    int-to-float v9, v9

    div-float v9, v0, v9

    invoke-static {v4, v9}, Ljava/lang/Math;->min(FF)F

    move-result v4

    const/high16 v9, 0x42c80000    # 100.0f

    mul-float/2addr v4, v9

    invoke-static {v6, v4}, Ljava/lang/Math;->min(FF)F

    move-result v4

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v6, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v10, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x0

    invoke-virtual {v10, v11, v6, v4, v8}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    invoke-virtual {v10, v3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {v8}, Landroid/graphics/Rect;->height()I

    move-result v3

    int-to-float v3, v3

    sub-float/2addr v0, v3

    div-float v0, v0, v20

    add-float/2addr v0, v2

    iget v2, v8, Landroid/graphics/Rect;->top:I

    int-to-float v2, v2

    sub-float/2addr v0, v2

    move-object/from16 v8, p1

    invoke-static {v8, v11, v1, v0, v10}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    iget v0, v14, Landroid/graphics/RectF;->right:F

    div-float v1, v5, v20

    sub-float v3, v0, v1

    div-float v0, v18, v20

    add-float v4, v0, v15

    iget v9, v12, Lc/r4;->d:I

    move v10, v6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    move/from16 v11, p6

    move v6, v9

    invoke-virtual/range {v0 .. v6}, Lc/S0;->e(Landroid/graphics/Canvas;IFFFI)V

    if-lez v7, :cond_7

    const/high16 v0, 0x41800000    # 16.0f

    mul-float v0, v0, p5

    const/high16 v1, 0x41400000    # 12.0f

    mul-float v1, v1, p5

    const v2, 0x3d408312    # 0.047f

    mul-float v2, v2, v19

    invoke-static {v1, v2}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    iget v1, v14, Landroid/graphics/RectF;->left:F

    add-float v15, v15, v18

    add-float/2addr v15, v11

    move-object/from16 v2, p0

    iget-object v3, v2, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v4, v2, Lc/S0;->n:Ljava/lang/String;

    invoke-static {v3, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move/from16 v4, v19

    float-to-int v4, v4

    const/4 v5, 0x1

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    iget-object v6, v2, Lc/S0;->d:Landroid/text/TextPaint;

    sget-object v7, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    iget v7, v12, Lc/r4;->e:I

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    const v7, 0x40133333    # 2.3f

    mul-float/2addr v7, v0

    cmpl-float v7, v16, v7

    if-ltz v7, :cond_4

    const/4 v5, 0x2

    :cond_4
    iget-object v7, v2, Lc/S0;->v:Landroid/text/StaticLayout;

    if-eqz v7, :cond_5

    iget-object v7, v2, Lc/S0;->w:Ljava/lang/String;

    invoke-virtual {v3, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5

    iget v7, v2, Lc/S0;->x:I

    if-ne v4, v7, :cond_5

    iget v7, v2, Lc/S0;->z:F

    cmpl-float v7, v0, v7

    if-nez v7, :cond_5

    iget v7, v2, Lc/S0;->y:I

    if-eq v5, v7, :cond_6

    :cond_5
    iput-object v3, v2, Lc/S0;->w:Ljava/lang/String;

    iput v4, v2, Lc/S0;->x:I

    iput v0, v2, Lc/S0;->z:F

    iput v5, v2, Lc/S0;->y:I

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v0

    invoke-static {v3, v10, v0, v6, v4}, Landroid/text/StaticLayout$Builder;->obtain(Ljava/lang/CharSequence;IILandroid/text/TextPaint;I)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    invoke-virtual {v0, v10}, Landroid/text/StaticLayout$Builder;->setIncludePad(Z)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    invoke-virtual {v0, v5}, Landroid/text/StaticLayout$Builder;->setMaxLines(I)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    sget-object v3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, v3}, Landroid/text/StaticLayout$Builder;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)Landroid/text/StaticLayout$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/text/StaticLayout$Builder;->build()Landroid/text/StaticLayout;

    move-result-object v0

    iput-object v0, v2, Lc/S0;->v:Landroid/text/StaticLayout;

    :cond_6
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    invoke-virtual {v8, v1, v15}, Landroid/graphics/Canvas;->translate(FF)V

    iget-object v1, v2, Lc/S0;->v:Landroid/text/StaticLayout;

    invoke-static {v8, v1}, Lc/q9;->d(Landroid/graphics/Canvas;Landroid/text/StaticLayout;)V

    invoke-virtual {v8, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    goto :goto_4

    :cond_7
    move-object/from16 v2, p0

    :goto_4
    return-void
.end method

.method public final e(Landroid/graphics/Canvas;IFFFI)V
    .locals 2

    const/4 v0, 0x0

    cmpg-float v0, p5, v0

    if-gtz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/S0;->i:Landroid/util/SparseArray;

    invoke-virtual {v0, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_2

    iget-object v1, p0, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1, p2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    if-nez v1, :cond_1

    return-void

    :cond_1
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, p2, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_2
    invoke-static {p6}, Lc/q9;->a(I)I

    move-result p2

    invoke-virtual {v1, p2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/high16 p2, 0x40000000    # 2.0f

    div-float/2addr p5, p2

    sub-float p2, p3, p5

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    sub-float p6, p4, p5

    invoke-static {p6}, Ljava/lang/Math;->round(F)I

    move-result p6

    add-float/2addr p3, p5

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    add-float/2addr p4, p5

    invoke-static {p4}, Ljava/lang/Math;->round(F)I

    move-result p4

    invoke-virtual {v1, p2, p6, p3, p4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    return-void
.end method

.method public final f(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V
    .locals 18

    move-object/from16 v8, p0

    move/from16 v9, p2

    move-object/from16 v10, p7

    const/high16 v0, 0x42300000    # 44.0f

    mul-float v0, v0, p8

    div-float v0, p6, v0

    const/high16 v1, 0x3fa00000    # 1.25f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    mul-float v11, v0, p8

    const/high16 v0, 0x41c00000    # 24.0f

    mul-float v7, v11, v0

    sget-object v0, Lc/S0;->A:[I

    aget v2, v0, v9

    const/high16 v0, 0x40000000    # 2.0f

    div-float v1, v7, v0

    add-float v3, v1, p3

    div-float v1, p6, v0

    add-float v12, v1, p4

    iget v6, v10, Lc/r4;->d:I

    mul-float/2addr v0, v7

    const/high16 v1, 0x40400000    # 3.0f

    div-float v5, v0, v1

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v12

    invoke-virtual/range {v0 .. v6}, Lc/S0;->e(Landroid/graphics/Canvas;IFFFI)V

    add-float v0, p3, v7

    const/high16 v1, 0x41200000    # 10.0f

    mul-float/2addr v1, v11

    add-float v3, v1, v0

    const/high16 v13, 0x41000000    # 8.0f

    if-eqz p9, :cond_0

    const v0, 0x3f147ae1    # 0.58f

    mul-float v0, v0, p5

    add-float v0, v0, p3

    :goto_0
    move v14, v0

    goto :goto_1

    :cond_0
    add-float v0, p3, p5

    mul-float v1, p8, v13

    sub-float/2addr v0, v1

    goto :goto_0

    :goto_1
    const/4 v15, 0x1

    const/4 v7, 0x2

    if-nez v9, :cond_1

    iget-object v0, v8, Lc/S0;->q:Ljava/lang/String;

    :goto_2
    move-object v2, v0

    goto :goto_3

    :cond_1
    if-ne v9, v15, :cond_2

    iget-object v0, v8, Lc/S0;->p:Ljava/lang/String;

    goto :goto_2

    :cond_2
    if-ne v9, v7, :cond_3

    iget-object v0, v8, Lc/S0;->r:[Ljava/lang/String;

    aget-object v0, v0, v7

    goto :goto_2

    :cond_3
    iget-object v0, v8, Lc/S0;->u:Ljava/lang/String;

    goto :goto_2

    :goto_3
    const/high16 v0, 0x41400000    # 12.0f

    mul-float v16, v11, v0

    sub-float v4, v12, v16

    sub-float v5, v14, v3

    const/high16 v0, 0x41a00000    # 20.0f

    mul-float v6, v11, v0

    iget v1, v10, Lc/r4;->d:I

    move-object/from16 v0, p0

    move/from16 v17, v1

    move-object/from16 v1, p1

    move v13, v7

    move/from16 v7, v17

    invoke-virtual/range {v0 .. v7}, Lc/S0;->j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    if-eqz p9, :cond_7

    if-nez v9, :cond_4

    const-string v0, "\u0412\u043b\u0430\u0436\u043d\u043e\u0441\u0442\u044c"

    goto :goto_4

    :cond_4
    if-ne v9, v15, :cond_5

    const-string v0, "\u0412\u0435\u0442\u0435\u0440"

    goto :goto_4

    :cond_5
    if-ne v9, v13, :cond_6

    const-string v0, "\u043c\u043c \u0440\u0442. \u0441\u0442."

    goto :goto_4

    :cond_6
    const-string v0, "\u0412\u043e\u0441\u0445\u043e\u0434 / \u0417\u0430\u043a\u0430\u0442"

    :goto_4
    iget-object v1, v8, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/high16 v1, 0x41000000    # 8.0f

    mul-float v1, v1, p8

    add-float v2, v14, v1

    const/high16 v3, 0x40e00000    # 7.0f

    mul-float/2addr v11, v3

    sub-float v3, v12, v11

    add-float v4, p3, p5

    sub-float/2addr v4, v14

    sub-float v1, v4, v1

    iget v4, v10, Lc/r4;->e:I

    move-object/from16 p2, p0

    move-object/from16 p3, p1

    move-object/from16 p4, v0

    move/from16 p5, v2

    move/from16 p6, v3

    move/from16 p7, v1

    move/from16 p8, v16

    move/from16 p9, v4

    invoke-virtual/range {p2 .. p9}, Lc/S0;->j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    :cond_7
    return-void
.end method

.method public final g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V
    .locals 1

    const/4 v0, 0x0

    cmpg-float v0, p5, v0

    if-gtz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/S0;->c:Landroid/text/TextPaint;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTextSize(F)V

    if-eqz p8, :cond_1

    sget-object p6, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    goto :goto_0

    :cond_1
    sget-object p6, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    :goto_0
    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v0, p7}, Landroid/graphics/Paint;->setColor(I)V

    iget-object p6, p0, Lc/S0;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {p6, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    sget-object p6, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-static {p2, v0, p5, p6}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object p2

    invoke-interface {p2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0}, Landroid/graphics/Paint;->ascent()F

    move-result p5

    sub-float/2addr p4, p5

    invoke-static {p1, p2, p3, p4, v0}, Lc/q9;->b(Landroid/graphics/Canvas;Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final h(Landroid/graphics/Canvas;IFFFFLc/r4;FZ)V
    .locals 16

    move-object/from16 v9, p0

    move/from16 v7, p2

    move-object/from16 v8, p7

    const/high16 v0, 0x42400000    # 48.0f

    mul-float v0, v0, p8

    div-float v0, p6, v0

    const/high16 v1, 0x42c00000    # 96.0f

    mul-float v1, v1, p8

    div-float v1, p5, v1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/high16 v1, 0x3fa00000    # 1.25f

    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    mul-float v10, v0, p8

    const/high16 v0, 0x41c00000    # 24.0f

    mul-float/2addr v0, v10

    add-float v1, p3, v0

    const/high16 v2, 0x41200000    # 10.0f

    mul-float/2addr v2, v10

    add-float v11, v2, v1

    sub-float v1, p5, v0

    const/high16 v2, 0x41900000    # 18.0f

    mul-float/2addr v2, v10

    sub-float v12, v1, v2

    sget-object v1, Lc/S0;->A:[I

    aget v2, v1, v7

    const/high16 v1, 0x40000000    # 2.0f

    div-float v3, v0, v1

    add-float v3, v3, p3

    div-float v4, p6, v1

    add-float v13, v4, p4

    iget v6, v8, Lc/r4;->d:I

    mul-float/2addr v0, v1

    const/high16 v14, 0x40400000    # 3.0f

    div-float v5, v0, v14

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v4, v13

    invoke-virtual/range {v0 .. v6}, Lc/S0;->e(Landroid/graphics/Canvas;IFFFI)V

    const/4 v0, 0x3

    if-nez v7, :cond_0

    iget-object v1, v9, Lc/S0;->q:Ljava/lang/String;

    :goto_0
    move-object v2, v1

    goto :goto_1

    :cond_0
    if-ne v7, v0, :cond_1

    iget-object v1, v9, Lc/S0;->u:Ljava/lang/String;

    goto :goto_0

    :cond_1
    iget-object v1, v9, Lc/S0;->r:[Ljava/lang/String;

    aget-object v1, v1, v7

    goto :goto_0

    :goto_1
    const-string v1, ""

    if-nez v7, :cond_3

    if-eqz p9, :cond_2

    const-string v1, "\u0412\u043b\u0430\u0436\u043d\u043e\u0441\u0442\u044c"

    :cond_2
    :goto_2
    move-object v15, v1

    goto :goto_3

    :cond_3
    const/4 v3, 0x1

    if-ne v7, v3, :cond_4

    iget-object v1, v9, Lc/S0;->o:Ljava/lang/String;

    goto :goto_2

    :cond_4
    const/4 v3, 0x2

    if-ne v7, v3, :cond_5

    const-string v1, "\u043c\u043c \u0440\u0442. \u0441\u0442."

    goto :goto_2

    :cond_5
    if-eqz p9, :cond_2

    const-string v1, "\u0412\u043e\u0441\u0445\u043e\u0434 / \u0417\u0430\u043a\u0430\u0442"

    goto :goto_2

    :goto_3
    const/high16 v1, 0x41880000    # 17.0f

    const/high16 v3, 0x41a80000    # 21.0f

    if-ne v7, v0, :cond_6

    const/high16 v4, 0x43020000    # 130.0f

    mul-float/2addr v4, v10

    cmpg-float v4, v12, v4

    if-gez v4, :cond_6

    iget-object v2, v9, Lc/S0;->s:Ljava/lang/String;

    mul-float/2addr v3, v10

    sub-float v4, v13, v3

    mul-float v15, v10, v1

    iget v7, v8, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v11

    move v5, v12

    move v6, v15

    invoke-virtual/range {v0 .. v7}, Lc/S0;->j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    iget-object v0, v9, Lc/S0;->t:Ljava/lang/String;

    mul-float/2addr v10, v14

    add-float v1, v10, v13

    iget v2, v8, Lc/r4;->d:I

    move-object/from16 p2, p0

    move-object/from16 p3, p1

    move-object/from16 p4, v0

    move/from16 p5, v11

    move/from16 p6, v1

    move/from16 p7, v12

    move/from16 p8, v15

    move/from16 p9, v2

    invoke-virtual/range {p2 .. p9}, Lc/S0;->j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    goto :goto_6

    :cond_6
    if-ne v7, v0, :cond_7

    mul-float/2addr v1, v10

    move v6, v1

    goto :goto_4

    :cond_7
    mul-float/2addr v3, v10

    move v6, v3

    :goto_4
    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_8

    const v0, 0x3f19999a    # 0.6f

    mul-float/2addr v0, v6

    goto :goto_5

    :cond_8
    const/high16 v0, 0x41b80000    # 23.0f

    mul-float/2addr v0, v10

    :goto_5
    sub-float v4, v13, v0

    iget v7, v8, Lc/r4;->d:I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move v3, v11

    move v5, v12

    invoke-virtual/range {v0 .. v7}, Lc/S0;->j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_9

    const/high16 v0, 0x40a00000    # 5.0f

    mul-float/2addr v0, v10

    add-float v4, v0, v13

    const/high16 v0, 0x41400000    # 12.0f

    mul-float v6, v10, v0

    iget v7, v8, Lc/r4;->e:I

    const/4 v8, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v2, v15

    move v3, v11

    move v5, v12

    invoke-virtual/range {v0 .. v8}, Lc/S0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    :cond_9
    :goto_6
    return-void
.end method

.method public final i(Landroid/graphics/Canvas;FFFFLc/r4;F)V
    .locals 6

    iget-object v5, p0, Lc/S0;->e:Landroid/graphics/Paint;

    iget p6, p6, Lc/r4;->e:I

    invoke-static {p6}, Lc/q9;->a(I)I

    move-result p6

    invoke-virtual {v5, p6}, Landroid/graphics/Paint;->setColor(I)V

    const/16 p6, 0x64

    invoke-virtual {v5, p6}, Landroid/graphics/Paint;->setAlpha(I)V

    const/high16 p6, 0x3f800000    # 1.0f

    invoke-static {p6, p7}, Ljava/lang/Math;->max(FF)F

    move-result p6

    invoke-virtual {v5, p6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    move-object v0, p1

    move v1, p2

    move v2, p3

    move v3, p4

    move v4, p5

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final j(Landroid/graphics/Canvas;Ljava/lang/String;FFFFI)V
    .locals 10

    move/from16 v0, p6

    move-object v9, p0

    iget-object v1, v9, Lc/S0;->c:Landroid/text/TextPaint;

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {v1, v0}, Landroid/graphics/Paint;->setTextSize(F)V

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float v3, p5, v2

    invoke-static {v2, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    move-object v4, p2

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    div-float/2addr v3, v1

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    mul-float v6, v1, v0

    const/4 v8, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move/from16 v7, p7

    invoke-virtual/range {v0 .. v8}, Lc/S0;->g(Landroid/graphics/Canvas;Ljava/lang/String;FFFFIZ)V

    return-void
.end method
