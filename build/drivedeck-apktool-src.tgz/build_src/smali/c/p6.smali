.class public abstract Lc/p6;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:[Ljava/util/regex/Pattern;

.field public static final b:[I


# direct methods
.method static constructor <clinit>()V
    .locals 49

    const-string v0, "vehicle speed|\u0441\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044f|pid_010d|speed limiter"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const-string v0, "awd|4wd|haldex|differential|awc|\u0434\u0438\u0444\u0444\u0435\u0440\u0435\u043d\u0446|\u043f\u043e\u043b\u043d\u044b\u0439 \u043f\u0440\u0438\u0432\u043e\u0434"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v2

    const-string v0, "alternator|generator|charger|obc|\u0433\u0435\u043d\u0435\u0440\u0430\u0442\u043e\u0440|\u0437\u0430\u0440\u044f\u0434\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v3

    const-string v0, "ambient|outside|atmospher|barometr|humidity|water temp|\u043d\u0430\u0440\u0443\u0436|\u0430\u0442\u043c\u043e\u0441\u0444\u0435\u0440|\u0432\u043b\u0430\u0436\u043d\u043e\u0441\u0442|\u0442\u0435\u043c\u043f\u0435\u0440\u0430\u0442\u0443\u0440\u0430 \u0432\u043e\u0434\u044b|pid_0146|pid_0133"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v4

    const-string v0, "tpms|tire|tyre|\u0448\u0438\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v5

    const-string v0, "wheel|\u043a\u043e\u043b\u0435\u0441|\\[abs\\]"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v6

    const-string v0, "airbag|\\[srs\\]|\u043f\u043e\u0434\u0443\u0448\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v7

    const-string v0, "seat.?belt|\u0440\u0435\u043c\u043d.*\u0431\u0435\u0437\u043e\u043f\u0430\u0441|buckle"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v8

    const-string v0, "seat|\u0441\u0438\u0434\u0435\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v9

    const-string v0, "door|window|\u0434\u0432\u0435\u0440|\u0441\u0442\u0435\u043a\u043b"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v10

    const-string v0, "head.?light|lamp|lighting|beam|\u0444\u0430\u0440\u044b|\u0441\u0432\u0435\u0442|\\[afl\\]"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v11

    const-string v0, "immobil|key|security|alarm|\u043a\u043b\u044e\u0447|\u0437\u0430\u043c\u043e\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v12

    const-string v0, "steer|\\[eps\\]|\\[ps\\]|\u0440\u0443\u043b"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v13

    const-string v0, "brake|braking|\u0442\u043e\u0440\u043c\u043e\u0437"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v14

    const-string v0, "suspension|damper|ride height|\u043f\u043e\u0434\u0432\u0435\u0441|\u0430\u043c\u043e\u0440\u0442\u0438\u0437"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v15

    const-string v0, "clutch|\u0441\u0446\u0435\u043f\u043b\u0435\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v16

    const-string v0, "\\[tcm\\]|\\[at\\]|\\(at\\)|transmission|atf|gear|shift|cvt|\u043a\u043f\u043f|\u043f\u0435\u0440\u0435\u0434\u0430\u0447|pid_at_|dq250|dq500|dl382|tcm/dsg|turbine speed"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v17

    const-string v0, "inverter|converter|dc.?dc|\u0438\u043d\u0432\u0435\u0440\u0442\u043e\u0440"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v18

    const-string v0, "battery|cell|bms|hvb|soc|soh|\u0430\u043a\u043a\u0443\u043c|\u0431\u0430\u0442\u0430\u0440|\\[hv\\]"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v19

    const-string v0, "motor|\u044d\u043b\u0435\u043a\u0442\u0440\u043e\u0434\u0432\u0438\u0433"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v20

    const-string v0, "adblue|urea|reductant|scr\\b|\u043c\u043e\u0447\u0435\u0432\u0438\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v21

    const-string v0, "dpf|gpf|particle|particulate|soot|\u0441\u0430\u0436|\\[pf\\]"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v22

    const-string v0, "egr|recircul|\u0440\u0435\u0446\u0438\u0440\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v23

    const-string v0, "oxygen|lambda|o2\\b|nox|pid_011[4-9]|pid_011[a-b]|a/f ratio|\u043b\u044f\u043c\u0431\u0434|\u043a\u0438\u0441\u043b\u043e\u0440\u043e\u0434"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v24

    const-string v0, "cataly|\u043a\u0430\u0442\u0430\u043b\u0438\u0437"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v25

    const-string v0, "turbo|boost|\u043d\u0430\u0434\u0434\u0443\u0432|\u0442\u0443\u0440\u0431\u0438\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v26

    const-string v0, "exhaust|\u0432\u044b\u0445\u043b\u043e\u043f|egt"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v27

    const-string v0, "inject|\u0432\u043f\u0440\u044b\u0441\u043a|\u0444\u043e\u0440\u0441\u0443\u043d\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v28

    const-string v0, "ignition|spark|knock|misfire|deton|pid_010e|pid_015d|\u0437\u0430\u0436\u0438\u0433\u0430\u043d|\u0434\u0435\u0442\u043e\u043d\u0430\u0446|\u043f\u0440\u043e\u043f\u0443\u0441\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v29

    const-string v0, "cylinder|piston|\u0446\u0438\u043b\u0438\u043d\u0434\u0440|\u043f\u043e\u0440\u0448\u0435\u043d|crankshaft|camshaft"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v30

    const-string v0, "oil|\u043c\u0430\u0441\u043b|pid_015c"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v31

    const-string v0, "coolant|cooling|antifreeze|\u043e\u0436\\b|\u043e\u0445\u043b\u0430\u0436\u0434|pid_0105"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v32

    const-string v0, "fan|\u0432\u0435\u043d\u0442\u0438\u043b"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v33

    const-string v0, "hvac|climate|refrigerant|deflector|evaporator|a/c|air.?con|compressor|cabin|interior temp|\u043a\u043b\u0438\u043c\u0430\u0442|\u043a\u043e\u043d\u0434\u0438\u0446|\u0441\u0430\u043b\u043e\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v34

    const-string v0, "intake|inlet|air flow|air mass|maf\\b|manifold|\u0432\u043f\u0443\u0441\u043a|\u0432\u043e\u0437\u0434\u0443\u0445|pid_010b|pid_010f|pid_0110"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v35

    const-string v0, "fuel|gasoline|petrol|diesel|rail pressure|evap|canister|\u0442\u043e\u043f\u043b\u0438\u0432|\u0431\u0435\u043d\u0437\u0438\u043d|pid_012f"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v36

    const-string v0, "throttle|accelerator|pedal|\u0434\u0440\u043e\u0441\u0441\u0435\u043b|\u043f\u0435\u0434\u0430\u043b|pid_0111"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v37

    const-string v0, "pump|\u043d\u0430\u0441\u043e\u0441"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v38

    const-string v0, "valve|solenoid|\u043a\u043b\u0430\u043f\u0430\u043d"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v39

    const-string v0, "relay|\u0440\u0435\u043b\u0435"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v40

    const-string v0, "switch|button|\u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447|\u043a\u043d\u043e\u043f\u043a"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v41

    const-string v0, "odometer|mileage|distance|\u043f\u0440\u043e\u0431\u0435\u0433|\u0440\u0430\u0441\u0441\u0442\u043e\u044f"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v42

    const-string v0, "gps|latitude|longitude|altitude|\u043a\u043e\u043e\u0440\u0434\u0438\u043d|\u0432\u044b\u0441\u043e\u0442"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v43

    const-string v0, "cruise|\u043a\u0440\u0443\u0438\u0437"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v44

    const-string v0, "accelerat|yaw|roll|pitch|\u0443\u0441\u043a\u043e\u0440|\\[esp\\]"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v45

    const-string v0, "engine|\\[ecm\\]|\\[\u0434\u0432\u0441\\]|rpm|idle|\u0434\u0432\u0438\u0433\u0430\u0442\u0435\u043b|pid_0104|pid_010c"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v46

    const-string v0, "ecu|computer|module|can\\b|obd|dtc|error|code|fault|\u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442|\u043e\u0448\u0438\u0431|\u043d\u0435\u0438\u0441\u043f\u0440\u0430\u0432|bcm|dash|vmcu|mcu|becm|evc|pid_0142"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v47

    const-string v0, ".*"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v48

    filled-new-array/range {v1 .. v48}, [Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lc/p6;->a:[Ljava/util/regex/Pattern;

    const/16 v0, 0x30

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lc/p6;->b:[I

    return-void

    :array_0
    .array-data 4
        0x7f03008b
        0x7f030061
        0x7f030072
        0x7f030060
        0x7f030086
        0x7f03008c
        0x7f03005f
        0x7f030063
        0x7f03007f
        0x7f03006a
        0x7f030078
        0x7f030080
        0x7f030083
        0x7f030064
        0x7f030084
        0x7f030066
        0x7f030087
        0x7f030077
        0x7f030062
        0x7f030079
        0x7f030089
        0x7f03006b
        0x7f03006d
        0x7f03007c
        0x7f030065
        0x7f030088
        0x7f03006f
        0x7f030075
        0x7f030082
        0x7f030069
        0x7f03007b
        0x7f030067
        0x7f030070
        0x7f030074
        0x7f030076
        0x7f030071
        0x7f03005e
        0x7f03007d
        0x7f03008a
        0x7f03007e
        0x7f030085
        0x7f03007a
        0x7f030073
        0x7f030068
        0x7f03005d
        0x7f03006e
        0x7f03006c
        0x7f030081
    .end array-data
.end method

.method public static a(Ljava/lang/String;)I
    .locals 4

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v0, 0x0

    :goto_1
    sget-object v1, Lc/p6;->a:[Ljava/util/regex/Pattern;

    array-length v2, v1

    sget-object v3, Lc/p6;->b:[I

    if-ge v0, v2, :cond_2

    aget-object v1, v1, v0

    invoke-virtual {v1, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    if-eqz v1, :cond_1

    aget p0, v3, v0

    return p0

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    array-length p0, v3

    add-int/lit8 p0, p0, -0x1

    aget p0, v3, p0

    return p0
.end method
