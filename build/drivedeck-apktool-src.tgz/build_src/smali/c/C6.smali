.class public final Lc/C6;
.super Landroid/widget/BaseAdapter;
.source "SourceFile"


# instance fields
.field public final synthetic a:Lc/H6;


# direct methods
.method public constructor <init>(Lc/H6;)V
    .locals 0

    iput-object p1, p0, Lc/C6;->a:Lc/H6;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final getCount()I
    .locals 1

    iget-object v0, p0, Lc/C6;->a:Lc/H6;

    iget-object v0, v0, Lc/H6;->K:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public final getItem(I)Ljava/lang/Object;
    .locals 1

    iget-object v0, p0, Lc/C6;->a:Lc/H6;

    iget-object v0, v0, Lc/H6;->K:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final getItemId(I)J
    .locals 2

    int-to-long v0, p1

    return-wide v0
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 12

    instance-of p3, p2, Landroid/widget/Switch;

    iget-object v0, p0, Lc/C6;->a:Lc/H6;

    if-eqz p3, :cond_0

    check-cast p2, Landroid/widget/Switch;

    goto :goto_0

    :cond_0
    new-instance p2, Landroid/widget/Switch;

    iget-object p3, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p2, p3}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    :goto_0
    iget-object p3, v0, Lc/H6;->K:Ljava/util/ArrayList;

    invoke-virtual {p3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/i6;

    iget-object p3, v0, Lc/H6;->c:Lc/T5;

    iget-object v1, p3, Lc/T5;->g:Lc/j6;

    const/4 v2, 0x0

    invoke-virtual {p2, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    iget-object v3, v0, Lc/H6;->b:Lc/r4;

    invoke-static {p2, v3}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    const/4 v4, 0x4

    invoke-virtual {v0, v4}, Lc/H6;->g(I)I

    move-result v5

    const/16 v6, 0x8

    invoke-virtual {v0, v6}, Lc/H6;->g(I)I

    move-result v7

    invoke-virtual {v0, v4}, Lc/H6;->g(I)I

    move-result v4

    invoke-virtual {v0, v6}, Lc/H6;->g(I)I

    move-result v6

    invoke-virtual {p2, v5, v7, v4, v6}, Landroid/view/View;->setPadding(IIII)V

    iget-object v4, v0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {p3, v5}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v6

    if-nez v6, :cond_1

    iget v7, p1, Lc/i6;->o:I

    goto :goto_1

    :cond_1
    invoke-virtual {v6, p1}, Lc/S5;->a(Lc/i6;)I

    move-result v7

    :goto_1
    invoke-static {v7}, Lc/j6;->d(I)Ljava/lang/String;

    move-result-object v7

    if-nez v6, :cond_2

    move-object v8, v2

    goto :goto_2

    :cond_2
    iget-wide v8, v6, Lc/S5;->a:D

    invoke-virtual {p1, v8, v9}, Lc/i6;->f(D)Ljava/lang/String;

    move-result-object v8

    :goto_2
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\n"

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v6, :cond_3

    const-string v8, "\u2014"

    goto :goto_3

    :cond_3
    if-nez v8, :cond_4

    iget-wide v10, v6, Lc/S5;->a:D

    const/4 v6, 0x2

    invoke-static {v10, v11, v6}, Lc/H6;->k(DI)Ljava/lang/String;

    move-result-object v8

    :cond_4
    :goto_3
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_5

    const-string v6, ""

    goto :goto_4

    :cond_5
    const-string v6, " \u00b7 "

    invoke-virtual {v6, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_4
    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    iget-object v7, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    iget-boolean v8, p1, Lc/i6;->v:Z

    if-nez v8, :cond_6

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\u041d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0434\u043b\u044f \u0447\u0442\u0435\u043d\u0438\u044f: \u043a\u043e\u043c\u0430\u043d\u0434\u0430, \u0444\u043e\u0440\u043c\u0443\u043b\u0430 \u0438\u043b\u0438 \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f"

    invoke-static {v7, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    :cond_6
    iget-object v4, p1, Lc/i6;->c:Ljava/lang/String;

    invoke-static {v4}, Lc/p6;->a(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v7, v4}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    iget v3, v3, Lc/r4;->d:I

    invoke-virtual {v4, v3}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/16 v3, 0x1c

    invoke-virtual {v0, v3}, Lc/H6;->g(I)I

    move-result v7

    invoke-virtual {v0, v3}, Lc/H6;->g(I)I

    move-result v3

    const/4 v9, 0x0

    invoke-virtual {v4, v9, v9, v7, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {p2, v4, v2, v2, v2}, Landroid/widget/TextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/16 v2, 0xa

    invoke-virtual {v0, v2}, Lc/H6;->g(I)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    invoke-virtual {p3}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object p3

    invoke-interface {p3, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p3

    invoke-virtual {p2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p2, p3}, Landroid/widget/Switch;->setChecked(Z)V

    if-nez v8, :cond_7

    if-eqz p3, :cond_8

    :cond_7
    const/4 v9, 0x1

    :cond_8
    invoke-virtual {p2, v9}, Landroid/view/View;->setEnabled(Z)V

    new-instance p3, Lc/A;

    const/4 v0, 0x3

    invoke-direct {p3, p0, v0}, Lc/A;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance p3, Lc/w0;

    const/4 v0, 0x4

    invoke-direct {p3, p0, v1, p1, v0}, Lc/w0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p2, p3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    return-object p2
.end method
