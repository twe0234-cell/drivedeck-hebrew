.class public final Lc/L5;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/T5;


# direct methods
.method public synthetic constructor <init>(Lc/T5;I)V
    .locals 0

    iput p2, p0, Lc/L5;->a:I

    iput-object p1, p0, Lc/L5;->b:Lc/T5;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    iget p1, p0, Lc/L5;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/L5;->b:Lc/T5;

    invoke-virtual {p1}, Lc/T5;->j()I

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "cmd.acc"

    invoke-virtual {p2, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    const/4 v1, -0x1

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v0, 0x1

    if-eqz p2, :cond_1

    if-eq p2, v0, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    if-ne p2, v0, :cond_2

    move v2, v0

    goto :goto_0

    :cond_2
    move v2, v1

    :goto_0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    iput-object v2, p1, Lc/T5;->x:Ljava/lang/Boolean;

    if-nez p2, :cond_3

    invoke-virtual {p1, v1}, Lc/T5;->c0(Z)V

    goto :goto_1

    :cond_3
    if-ne p2, v0, :cond_4

    invoke-virtual {p1}, Lc/T5;->Y0()V

    :cond_4
    :goto_1
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/L5;->b:Lc/T5;

    invoke-virtual {p1}, Lc/T5;->j()I

    move-result v0

    if-nez v0, :cond_5

    goto :goto_2

    :cond_5
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    const-string v0, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    invoke-virtual {p1, v1}, Lc/T5;->c0(Z)V

    goto :goto_2

    :cond_6
    invoke-virtual {p1}, Lc/T5;->j()I

    move-result v0

    const/4 v2, 0x1

    if-eq v0, v2, :cond_7

    invoke-virtual {p1}, Lc/T5;->j()I

    move-result v0

    const/4 v3, 0x3

    if-ne v0, v3, :cond_b

    :cond_7
    const-string v0, "android.intent.action.ACTION_POWER_DISCONNECTED"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-virtual {p1, v1}, Lc/T5;->c0(Z)V

    goto :goto_2

    :cond_8
    const-string v0, "android.intent.action.ACTION_POWER_CONNECTED"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-virtual {p1}, Lc/T5;->Y0()V

    goto :goto_2

    :cond_9
    invoke-virtual {p1}, Lc/T5;->j()I

    move-result v0

    if-ne v0, v2, :cond_b

    iget-object v0, p1, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "battery_screen"

    invoke-interface {v0, v3, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_b

    const-string v0, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    iput-boolean v2, p1, Lc/T5;->y:Z

    invoke-virtual {p1, v1}, Lc/T5;->c0(Z)V

    goto :goto_2

    :cond_a
    const-string v0, "android.intent.action.SCREEN_ON"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_b

    iput-boolean v1, p1, Lc/T5;->y:Z

    invoke-virtual {p1}, Lc/T5;->Y0()V

    :cond_b
    :goto_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
