.class public final Lc/A3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/widget/TextView;

.field public final synthetic c:Lc/n1;

.field public final synthetic d:Lc/t2;

.field public final synthetic e:Lc/Q3;


# direct methods
.method public synthetic constructor <init>(Lc/Q3;Landroid/widget/TextView;Lc/n1;Lc/t2;I)V
    .locals 0

    iput p5, p0, Lc/A3;->a:I

    iput-object p1, p0, Lc/A3;->e:Lc/Q3;

    iput-object p2, p0, Lc/A3;->b:Landroid/widget/TextView;

    iput-object p3, p0, Lc/A3;->c:Lc/n1;

    iput-object p4, p0, Lc/A3;->d:Lc/t2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final b(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method


# virtual methods
.method public final onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 1

    iget p1, p0, Lc/A3;->a:I

    packed-switch p1, :pswitch_data_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lc/A3;->e:Lc/Q3;

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    const-string v0, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438"

    invoke-static {p3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, " \u2014 "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 p2, p2, 0x19

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "%"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lc/A3;->b:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_0
    if-eqz p3, :cond_0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lc/A3;->e:Lc/Q3;

    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p3

    const-string v0, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0433\u043e \u2014 "

    invoke-static {p3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 p2, p2, 0x32

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, "%"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lc/A3;->b:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_0
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0

    iget p1, p0, Lc/A3;->a:I

    return-void
.end method

.method public final onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 4

    iget v0, p0, Lc/A3;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-virtual {p1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result p1

    const/16 v0, 0x19

    add-int/2addr p1, v0

    iget-object v1, p0, Lc/A3;->c:Lc/n1;

    iget-object v2, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "home_edge_fade_size"

    invoke-virtual {v1, v3}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x96

    invoke-static {v3, p1, v0, v2, v1}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object p1, p0, Lc/A3;->d:Lc/t2;

    invoke-virtual {p1}, Lc/t2;->I()V

    return-void

    :pswitch_0
    invoke-virtual {p1}, Landroid/widget/ProgressBar;->getProgress()I

    move-result p1

    const/16 v0, 0x32

    add-int/2addr p1, v0

    iget-object v1, p0, Lc/A3;->c:Lc/n1;

    iget-object v2, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "home_window_scale"

    invoke-virtual {v1, v3}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v3, 0x78

    invoke-static {v3, p1, v0, v2, v1}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object p1, p0, Lc/A3;->d:Lc/t2;

    invoke-virtual {p1}, Lc/t2;->J()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
