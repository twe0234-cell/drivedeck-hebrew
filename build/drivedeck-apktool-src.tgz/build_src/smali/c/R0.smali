.class public final Lc/R0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/Integer;

.field public final e:Ljava/lang/Integer;

.field public final f:Ljava/lang/Integer;

.field public final g:Ljava/lang/Integer;

.field public final h:Ljava/lang/Integer;

.field public final i:Ljava/lang/Integer;

.field public final j:Ljava/lang/Double;

.field public final k:Ljava/lang/Double;

.field public final l:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;)V
    .locals 13

    .line 1
    const-string v12, ""

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    move-object/from16 v10, p10

    move-object/from16 v11, p11

    invoke-direct/range {v0 .. v12}, Lc/R0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3
    const-string v0, ""

    if-nez p1, :cond_0

    move-object p1, v0

    :cond_0
    iput-object p1, p0, Lc/R0;->a:Ljava/lang/String;

    if-nez p2, :cond_1

    move-object p2, v0

    :cond_1
    iput-object p2, p0, Lc/R0;->b:Ljava/lang/String;

    .line 4
    iput-object p3, p0, Lc/R0;->d:Ljava/lang/Integer;

    iput-object p4, p0, Lc/R0;->e:Ljava/lang/Integer;

    iput-object p5, p0, Lc/R0;->f:Ljava/lang/Integer;

    iput-object p6, p0, Lc/R0;->g:Ljava/lang/Integer;

    .line 5
    iput-object p7, p0, Lc/R0;->h:Ljava/lang/Integer;

    iput-object p8, p0, Lc/R0;->i:Ljava/lang/Integer;

    iput-object p9, p0, Lc/R0;->j:Ljava/lang/Double;

    iput-object p10, p0, Lc/R0;->k:Ljava/lang/Double;

    if-nez p11, :cond_2

    move-object p11, v0

    :cond_2
    iput-object p11, p0, Lc/R0;->l:Ljava/lang/String;

    if-nez p12, :cond_3

    move-object p12, v0

    .line 6
    :cond_3
    iput-object p12, p0, Lc/R0;->c:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lc/R0;
    .locals 17

    const-string v0, ""

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    move-object/from16 v2, p0

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v1}, Lc/R0;->e(Lorg/json/JSONObject;)Lc/R0;

    move-result-object v2

    const-string v3, "locality"

    invoke-virtual {v1, v3, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Lc/R0;->h(Ljava/lang/String;)Lc/R0;

    move-result-object v2

    new-instance v16, Lc/R0;

    iget-object v4, v2, Lc/R0;->a:Ljava/lang/String;

    iget-object v5, v2, Lc/R0;->b:Ljava/lang/String;

    iget-object v6, v2, Lc/R0;->d:Ljava/lang/Integer;

    iget-object v7, v2, Lc/R0;->e:Ljava/lang/Integer;

    iget-object v8, v2, Lc/R0;->f:Ljava/lang/Integer;

    iget-object v9, v2, Lc/R0;->g:Ljava/lang/Integer;

    iget-object v10, v2, Lc/R0;->h:Ljava/lang/Integer;

    iget-object v11, v2, Lc/R0;->i:Ljava/lang/Integer;

    iget-object v12, v2, Lc/R0;->j:Ljava/lang/Double;

    iget-object v13, v2, Lc/R0;->k:Ljava/lang/Double;

    iget-object v14, v2, Lc/R0;->l:Ljava/lang/String;

    const-string v2, "attribution"

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v3, v16

    invoke-direct/range {v3 .. v15}, Lc/R0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v16

    :catch_0
    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object v0

    return-object v0
.end method

.method public static c()Lc/R0;
    .locals 13

    new-instance v12, Lc/R0;

    const/4 v10, 0x0

    const-string v11, ""

    const-string v1, ""

    const-string v2, ""

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v0, v12

    invoke-direct/range {v0 .. v11}, Lc/R0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;)V

    return-object v12
.end method

.method public static e(Lorg/json/JSONObject;)Lc/R0;
    .locals 21

    move-object/from16 v0, p0

    const-string v1, "fact"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    if-nez v1, :cond_0

    invoke-static {}, Lc/R0;->c()Lc/R0;

    move-result-object v0

    return-object v0

    :cond_0
    const-string v2, "geo_object"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v8, ""

    if-eqz v0, :cond_1

    const-string v2, "locality"

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v2, "name"

    invoke-virtual {v0, v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object v10, v0

    goto :goto_0

    :cond_1
    move-object v10, v8

    :goto_0
    new-instance v0, Lc/R0;

    const-string v2, "condition"

    invoke-virtual {v1, v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v2, "temp"

    const/16 v3, -0x64

    const/16 v4, 0x64

    invoke-static {v1, v2, v3, v4}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v12

    const/16 v2, -0x78

    const/16 v3, 0x78

    const-string v5, "feels_like"

    invoke-static {v1, v5, v2, v3}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v13

    const-string v2, "humidity"

    const/4 v3, 0x0

    invoke-static {v1, v2, v3, v4}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v14

    const-string v2, "pressure_mm"

    const/16 v5, 0x4b0

    invoke-static {v1, v2, v4, v5}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v15

    const-string v2, "prec_prob"

    invoke-static {v1, v2, v3, v4}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v16

    const-string v2, "uv_index"

    const/16 v4, 0x1e

    invoke-static {v1, v2, v3, v4}, Lc/R0;->f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;

    move-result-object v17

    const-wide/16 v4, 0x0

    const-wide v6, 0x4062c00000000000L    # 150.0

    const-string v3, "wind_speed"

    move-object v2, v1

    invoke-static/range {v2 .. v7}, Lc/R0;->i(Lorg/json/JSONObject;Ljava/lang/String;DD)Ljava/lang/Double;

    move-result-object v18

    const-string v3, "wind_gust"

    invoke-static/range {v2 .. v7}, Lc/R0;->i(Lorg/json/JSONObject;Ljava/lang/String;DD)Ljava/lang/Double;

    move-result-object v19

    const-string v2, "wind_dir"

    invoke-virtual {v1, v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    move-object v9, v0

    invoke-direct/range {v9 .. v20}, Lc/R0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;)V

    return-object v0
.end method

.method public static f(Lorg/json/JSONObject;Ljava/lang/String;II)Ljava/lang/Integer;
    .locals 6

    int-to-double v2, p2

    int-to-double v4, p3

    move-object v0, p0

    move-object v1, p1

    invoke-static/range {v0 .. v5}, Lc/R0;->i(Lorg/json/JSONObject;Ljava/lang/String;DD)Ljava/lang/Double;

    move-result-object p0

    if-nez p0, :cond_0

    const/4 p0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/Double;->intValue()I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    :goto_0
    return-object p0
.end method

.method public static g(Lorg/json/JSONObject;Ljava/lang/String;IIZ)Z
    .locals 4

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    xor-int/lit8 p0, p4, 0x1

    return p0

    :cond_0
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/Number;

    const/4 p4, 0x0

    if-nez p1, :cond_1

    return p4

    :cond_1
    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->isFinite(D)Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-static {p0, p1}, Ljava/lang/Math;->rint(D)D

    move-result-wide v2

    cmpl-double v0, p0, v2

    if-nez v0, :cond_2

    int-to-double v2, p2

    cmpl-double p2, p0, v2

    if-ltz p2, :cond_2

    int-to-double p2, p3

    cmpg-double p0, p0, p2

    if-gtz p0, :cond_2

    goto :goto_0

    :cond_2
    move v1, p4

    :goto_0
    return v1
.end method

.method public static i(Lorg/json/JSONObject;Ljava/lang/String;DD)Ljava/lang/Double;
    .locals 2

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/Number;

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_1

    cmpl-double p2, p0, p2

    if-ltz p2, :cond_1

    cmpg-double p2, p0, p4

    if-gtz p2, :cond_1

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    :cond_1
    return-object v0
.end method

.method public static j(Lorg/json/JSONObject;Ljava/lang/String;)Z
    .locals 4

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Ljava/lang/Number;

    const/4 v0, 0x0

    if-nez p1, :cond_1

    return v0

    :cond_1
    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->isFinite(D)Z

    move-result v2

    if-eqz v2, :cond_2

    const-wide/16 v2, 0x0

    cmpl-double v2, p0, v2

    if-ltz v2, :cond_2

    const-wide v2, 0x4062c00000000000L    # 150.0

    cmpg-double p0, p0, v2

    if-gtz p0, :cond_2

    goto :goto_0

    :cond_2
    move v1, v0

    :goto_0
    return v1
.end method


# virtual methods
.method public final b()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lc/R0;->b:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, -0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    sparse-switch v2, :sswitch_data_0

    goto/16 :goto_0

    :sswitch_0
    const-string v2, "showers"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_0

    :cond_0
    const/16 v1, 0x14

    goto/16 :goto_0

    :sswitch_1
    const-string v2, "moderate-rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    goto/16 :goto_0

    :cond_1
    const/16 v1, 0x13

    goto/16 :goto_0

    :sswitch_2
    const-string v2, "thunderstorm-with-rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    goto/16 :goto_0

    :cond_2
    const/16 v1, 0x12

    goto/16 :goto_0

    :sswitch_3
    const-string v2, "thunderstorm-with-hail"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    goto/16 :goto_0

    :cond_3
    const/16 v1, 0x11

    goto/16 :goto_0

    :sswitch_4
    const-string v2, "drizzle"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4

    goto/16 :goto_0

    :cond_4
    const/16 v1, 0x10

    goto/16 :goto_0

    :sswitch_5
    const-string v2, "heavy-rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5

    goto/16 :goto_0

    :cond_5
    const/16 v1, 0xf

    goto/16 :goto_0

    :sswitch_6
    const-string v2, "overcast"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    goto/16 :goto_0

    :cond_6
    const/16 v1, 0xe

    goto/16 :goto_0

    :sswitch_7
    const-string v2, "clear"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    goto/16 :goto_0

    :cond_7
    const/16 v1, 0xd

    goto/16 :goto_0

    :sswitch_8
    const-string v2, "snow-showers"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    goto/16 :goto_0

    :cond_8
    const/16 v1, 0xc

    goto/16 :goto_0

    :sswitch_9
    const-string v2, "snow"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_9

    goto/16 :goto_0

    :cond_9
    const/16 v1, 0xb

    goto/16 :goto_0

    :sswitch_a
    const-string v2, "rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    goto/16 :goto_0

    :cond_a
    const/16 v1, 0xa

    goto/16 :goto_0

    :sswitch_b
    const-string v2, "mist"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_b

    goto/16 :goto_0

    :cond_b
    const/16 v1, 0x9

    goto/16 :goto_0

    :sswitch_c
    const-string v2, "hail"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c

    goto/16 :goto_0

    :cond_c
    const/16 v1, 0x8

    goto/16 :goto_0

    :sswitch_d
    const-string v2, "fog"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_d

    goto :goto_0

    :cond_d
    const/4 v1, 0x7

    goto :goto_0

    :sswitch_e
    const-string v2, "wet-snow"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    goto :goto_0

    :cond_e
    const/4 v1, 0x6

    goto :goto_0

    :sswitch_f
    const-string v2, "light-snow"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_f

    goto :goto_0

    :cond_f
    const/4 v1, 0x5

    goto :goto_0

    :sswitch_10
    const-string v2, "light-rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_10

    goto :goto_0

    :cond_10
    const/4 v1, 0x4

    goto :goto_0

    :sswitch_11
    const-string v2, "partly-cloudy"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_11

    goto :goto_0

    :cond_11
    const/4 v1, 0x3

    goto :goto_0

    :sswitch_12
    const-string v2, "continuous-heavy-rain"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12

    goto :goto_0

    :cond_12
    const/4 v1, 0x2

    goto :goto_0

    :sswitch_13
    const-string v2, "cloudy"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_13

    goto :goto_0

    :cond_13
    const/4 v1, 0x1

    goto :goto_0

    :sswitch_14
    const-string v2, "thunderstorm"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_14

    goto :goto_0

    :cond_14
    const/4 v1, 0x0

    :goto_0
    packed-switch v1, :pswitch_data_0

    const-string v0, ""

    return-object v0

    :pswitch_0
    const-string v0, "\u041b\u0438\u0432\u0435\u043d\u044c"

    return-object v0

    :pswitch_1
    const-string v0, "\u0414\u043e\u0436\u0434\u044c \u0441 \u0433\u0440\u043e\u0437\u043e\u0439"

    return-object v0

    :pswitch_2
    const-string v0, "\u0413\u0440\u043e\u0437\u0430 \u0441 \u0433\u0440\u0430\u0434\u043e\u043c"

    return-object v0

    :pswitch_3
    const-string v0, "\u041c\u043e\u0440\u043e\u0441\u044c"

    return-object v0

    :pswitch_4
    const-string v0, "\u041f\u0430\u0441\u043c\u0443\u0440\u043d\u043e"

    return-object v0

    :pswitch_5
    const-string v0, "\u042f\u0441\u043d\u043e"

    return-object v0

    :pswitch_6
    const-string v0, "\u0421\u043d\u0435\u0433\u043e\u043f\u0430\u0434"

    return-object v0

    :pswitch_7
    const-string v0, "\u0421\u043d\u0435\u0433"

    return-object v0

    :pswitch_8
    const-string v0, "\u0414\u043e\u0436\u0434\u044c"

    return-object v0

    :pswitch_9
    const-string v0, "\u0413\u0440\u0430\u0434"

    return-object v0

    :pswitch_a
    const-string v0, "\u0422\u0443\u043c\u0430\u043d"

    return-object v0

    :pswitch_b
    const-string v0, "\u0414\u043e\u0436\u0434\u044c \u0441\u043e \u0441\u043d\u0435\u0433\u043e\u043c"

    return-object v0

    :pswitch_c
    const-string v0, "\u041d\u0435\u0431\u043e\u043b\u044c\u0448\u043e\u0439 \u0441\u043d\u0435\u0433"

    return-object v0

    :pswitch_d
    const-string v0, "\u041d\u0435\u0431\u043e\u043b\u044c\u0448\u043e\u0439 \u0434\u043e\u0436\u0434\u044c"

    return-object v0

    :pswitch_e
    const-string v0, "\u041c\u0430\u043b\u043e\u043e\u0431\u043b\u0430\u0447\u043d\u043e"

    return-object v0

    :pswitch_f
    const-string v0, "\u0421\u0438\u043b\u044c\u043d\u044b\u0439 \u0434\u043e\u0436\u0434\u044c"

    return-object v0

    :pswitch_10
    const-string v0, "\u041e\u0431\u043b\u0430\u0447\u043d\u043e \u0441 \u043f\u0440\u043e\u044f\u0441\u043d\u0435\u043d\u0438\u044f\u043c\u0438"

    return-object v0

    :pswitch_11
    const-string v0, "\u0413\u0440\u043e\u0437\u0430"

    return-object v0

    :sswitch_data_0
    .sparse-switch
        -0x6fc1b57b -> :sswitch_14
        -0x50ea171c -> :sswitch_13
        -0x4e3db5a8 -> :sswitch_12
        -0x1b63456f -> :sswitch_11
        -0xf300a15 -> :sswitch_10
        -0xf2f6426 -> :sswitch_f
        -0xedc8876 -> :sswitch_e
        0x18cbe -> :sswitch_d
        0x30bfdc -> :sswitch_c
        0x3324fd -> :sswitch_b
        0x354b94 -> :sswitch_a
        0x35f183 -> :sswitch_9
        0x48712ff -> :sswitch_8
        0x5a5b64d -> :sswitch_7
        0x1f902e13 -> :sswitch_6
        0x4c70e0da -> :sswitch_5
        0x72788cd4 -> :sswitch_4
        0x75c4473b -> :sswitch_3
        0x75c8d2f3 -> :sswitch_2
        0x78471a1e -> :sswitch_1
        0x7b387149 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_a
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_f
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_8
        :pswitch_0
    .end packed-switch
.end method

.method public final d()Ljava/lang/String;
    .locals 5

    :try_start_0
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "locality"

    iget-object v2, p0, Lc/R0;->a:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "attribution"

    iget-object v2, p0, Lc/R0;->c:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "fact"

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v3, "temp"

    iget-object v4, p0, Lc/R0;->d:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "feels_like"

    iget-object v4, p0, Lc/R0;->e:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "condition"

    iget-object v4, p0, Lc/R0;->b:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "humidity"

    iget-object v4, p0, Lc/R0;->f:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "pressure_mm"

    iget-object v4, p0, Lc/R0;->g:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "prec_prob"

    iget-object v4, p0, Lc/R0;->h:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "uv_index"

    iget-object v4, p0, Lc/R0;->i:Ljava/lang/Integer;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "wind_speed"

    iget-object v4, p0, Lc/R0;->j:Ljava/lang/Double;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "wind_gust"

    iget-object v4, p0, Lc/R0;->k:Ljava/lang/Double;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "wind_dir"

    iget-object v4, p0, Lc/R0;->l:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    const-string v0, "{}"

    return-object v0
.end method

.method public final h(Ljava/lang/String;)Lc/R0;
    .locals 14

    new-instance v13, Lc/R0;

    iget-object v11, p0, Lc/R0;->l:Ljava/lang/String;

    iget-object v12, p0, Lc/R0;->c:Ljava/lang/String;

    iget-object v2, p0, Lc/R0;->b:Ljava/lang/String;

    iget-object v3, p0, Lc/R0;->d:Ljava/lang/Integer;

    iget-object v4, p0, Lc/R0;->e:Ljava/lang/Integer;

    iget-object v5, p0, Lc/R0;->f:Ljava/lang/Integer;

    iget-object v6, p0, Lc/R0;->g:Ljava/lang/Integer;

    iget-object v7, p0, Lc/R0;->h:Ljava/lang/Integer;

    iget-object v8, p0, Lc/R0;->i:Ljava/lang/Integer;

    iget-object v9, p0, Lc/R0;->j:Ljava/lang/Double;

    iget-object v10, p0, Lc/R0;->k:Ljava/lang/Double;

    move-object v0, v13

    move-object v1, p1

    invoke-direct/range {v0 .. v12}, Lc/R0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;Ljava/lang/String;Ljava/lang/String;)V

    return-object v13
.end method
