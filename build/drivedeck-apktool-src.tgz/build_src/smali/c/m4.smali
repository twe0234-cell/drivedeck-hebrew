.class public final synthetic Lc/m4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lru/drivedeck/launcher/LauncherAccessibilityService;

.field public final synthetic c:J


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JI)V
    .locals 0

    iput p4, p0, Lc/m4;->a:I

    iput-object p1, p0, Lc/m4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iput-wide p2, p0, Lc/m4;->c:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget-wide v0, p0, Lc/m4;->c:J

    iget-object v2, p0, Lc/m4;->b:Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget v3, p0, Lc/m4;->a:I

    packed-switch v3, :pswitch_data_0

    sget-object v3, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2, v0, v1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v2}, Lru/drivedeck/launcher/LauncherAccessibilityService;->k()V

    :cond_0
    return-void

    :pswitch_0
    sget-object v3, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v2, v0, v1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->e(J)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {v2}, Lru/drivedeck/launcher/LauncherAccessibilityService;->k()V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
