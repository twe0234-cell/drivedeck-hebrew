.class public final synthetic Lc/K7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/f1;

.field public final synthetic c:Lc/y7;

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/f1;Lc/y7;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/K7;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K7;->b:Lc/f1;

    iput-object p2, p0, Lc/K7;->c:Lc/y7;

    iput-object p3, p0, Lc/K7;->d:Ljava/lang/String;

    return-void
.end method

.method public synthetic constructor <init>(Lc/f1;Ljava/lang/String;Lc/y7;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/K7;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K7;->b:Lc/f1;

    iput-object p2, p0, Lc/K7;->d:Ljava/lang/String;

    iput-object p3, p0, Lc/K7;->c:Lc/y7;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget v0, p0, Lc/K7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/K7;->b:Lc/f1;

    iget-object v0, v0, Lc/f1;->d:Ljava/lang/Object;

    check-cast v0, Lc/O7;

    const/4 v1, 0x1

    iget-object v2, p0, Lc/K7;->c:Lc/y7;

    iget-object v3, p0, Lc/K7;->d:Ljava/lang/String;

    invoke-static {v0, v2, v3, v1}, Lc/O7;->a(Lc/O7;Lc/y7;Ljava/lang/String;Z)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/K7;->b:Lc/f1;

    iget-object v0, v0, Lc/f1;->d:Ljava/lang/Object;

    check-cast v0, Lc/O7;

    iget-object v1, v0, Lc/O7;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    iget-object v2, p0, Lc/K7;->d:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lc/K7;->c:Lc/y7;

    iget-object v2, v1, Lc/y7;->b:Ljava/lang/String;

    iget-boolean v1, v1, Lc/y7;->c:Z

    xor-int/lit8 v1, v1, 0x1

    iget-object v0, v0, Lc/O7;->b:Lc/Z7;

    iget-object v3, v0, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->a:Ljava/lang/String;

    new-instance v4, Lc/u3;

    invoke-direct {v4, v0, v3, v2, v1}, Lc/u3;-><init>(Lc/Z7;Ljava/lang/String;Ljava/lang/String;Z)V

    iget-object v0, v0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
