.class public final synthetic Lc/K3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/BooleanSupplier;


# instance fields
.field public final synthetic a:Lc/P3;


# direct methods
.method public synthetic constructor <init>(Lc/P3;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K3;->a:Lc/P3;

    return-void
.end method


# virtual methods
.method public final getAsBoolean()Z
    .locals 2

    const/4 v0, 0x1

    iget-object v1, p0, Lc/K3;->a:Lc/P3;

    invoke-virtual {v1, v0}, Lc/P3;->K(Z)Z

    move-result v0

    return v0
.end method
