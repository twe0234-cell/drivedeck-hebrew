.class public final Lc/z8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final a:Landroid/content/Context;

.field public b:Landroid/os/IBinder;

.field public c:Z


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lc/z8;->a:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 0

    iget-boolean p1, p0, Lc/z8;->c:Z

    if-eqz p1, :cond_0

    iput-object p2, p0, Lc/z8;->b:Landroid/os/IBinder;

    :cond_0
    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lc/z8;->b:Landroid/os/IBinder;

    return-void
.end method
