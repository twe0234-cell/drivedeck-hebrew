.class public final Lc/m9;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/RectF;

.field public final c:Landroid/graphics/Path;

.field public final d:Landroid/graphics/Path;

.field public final e:Landroid/graphics/LinearGradient;

.field public final f:Landroid/graphics/Matrix;

.field public final g:Landroid/graphics/PorterDuffXfermode;

.field public final h:Landroid/graphics/PorterDuffXfermode;

.field public final i:[F

.field public final j:[F

.field public final k:[F

.field public final l:[F

.field public final m:F

.field public final n:F

.field public final o:Ljava/lang/String;

.field public p:Landroid/animation/ValueAnimator;

.field public q:I

.field public r:F

.field public s:F

.field public t:J

.field public u:J


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 10

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/m9;->a:Landroid/graphics/Paint;

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/m9;->b:Landroid/graphics/RectF;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/m9;->c:Landroid/graphics/Path;

    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lc/m9;->d:Landroid/graphics/Path;

    new-instance v0, Landroid/graphics/LinearGradient;

    const/4 v2, 0x6

    new-array v7, v2, [I

    fill-array-data v7, :array_0

    new-array v8, v2, [F

    fill-array-data v8, :array_1

    sget-object v9, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    move-object v2, v0

    invoke-direct/range {v2 .. v9}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    iput-object v0, p0, Lc/m9;->e:Landroid/graphics/LinearGradient;

    new-instance v0, Landroid/graphics/Matrix;

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    iput-object v0, p0, Lc/m9;->f:Landroid/graphics/Matrix;

    new-instance v0, Landroid/graphics/PorterDuffXfermode;

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v0, v2}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    iput-object v0, p0, Lc/m9;->g:Landroid/graphics/PorterDuffXfermode;

    new-instance v0, Landroid/graphics/PorterDuffXfermode;

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v0, v2}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    iput-object v0, p0, Lc/m9;->h:Landroid/graphics/PorterDuffXfermode;

    const/16 v0, 0x1c

    new-array v2, v0, [F

    iput-object v2, p0, Lc/m9;->i:[F

    new-array v2, v0, [F

    iput-object v2, p0, Lc/m9;->j:[F

    new-array v2, v0, [F

    iput-object v2, p0, Lc/m9;->k:[F

    new-array v0, v0, [F

    iput-object v0, p0, Lc/m9;->l:[F

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Lc/m9;->m:F

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->scaledDensity:F

    const/high16 v2, 0x41900000    # 18.0f

    mul-float/2addr v0, v2

    iput v0, p0, Lc/m9;->n:F

    const-string v0, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c"

    invoke-static {p1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/m9;->o:Ljava/lang/String;

    const/4 p1, 0x0

    invoke-virtual {p0, v1, p1}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    new-instance p1, Ljava/util/Random;

    const-wide/16 v2, 0x25

    invoke-direct {p1, v2, v3}, Ljava/util/Random;-><init>(J)V

    const/4 v0, 0x0

    :goto_0
    iget-object v2, p0, Lc/m9;->i:[F

    array-length v3, v2

    if-ge v0, v3, :cond_0

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result v3

    aput v3, v2, v0

    iget-object v2, p0, Lc/m9;->j:[F

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result v3

    const v4, 0x3f333333    # 0.7f

    mul-float/2addr v3, v4

    const v4, 0x3e19999a    # 0.15f

    add-float/2addr v3, v4

    aput v3, v2, v0

    iget-object v2, p0, Lc/m9;->k:[F

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result v3

    const v4, 0x3e99999a    # 0.3f

    mul-float/2addr v3, v4

    const v4, 0x3df5c28f    # 0.12f

    add-float/2addr v3, v4

    aput v3, v2, v0

    iget-object v2, p0, Lc/m9;->l:[F

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result v3

    const v4, 0x3fb33333    # 1.4f

    mul-float/2addr v3, v4

    const v4, 0x3f4ccccd    # 0.8f

    add-float/2addr v3, v4

    aput v3, v2, v0

    add-int/2addr v0, v1

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v1}, Landroid/view/View;->setAccessibilityLiveRegion(I)V

    return-void

    nop

    :array_0
    .array-data 4
        -0xfcd690
        -0xf8cf88
        -0xeab971
        -0xd4954b
        -0xb66417
        -0xb25e10
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x3e0f5c29    # 0.14f
        0x3eb851ec    # 0.36f
        0x3f23d70a    # 0.64f
        0x3f7851ec    # 0.97f
        0x3f800000    # 1.0f
    .end array-data
.end method


# virtual methods
.method public final onDetachedFromWindow()V
    .locals 1

    iget-object v0, p0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    :cond_0
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 24

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super/range {p0 .. p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    iget v2, v0, Lc/m9;->m:F

    const/high16 v3, 0x41400000    # 12.0f

    mul-float/2addr v3, v2

    iget-object v4, v0, Lc/m9;->b:Landroid/graphics/RectF;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v5

    int-to-float v5, v5

    sub-float/2addr v5, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    move-result v6

    int-to-float v6, v6

    sub-float/2addr v6, v3

    invoke-virtual {v4, v3, v3, v5, v6}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v3, v5

    iget-object v6, v0, Lc/m9;->a:Landroid/graphics/Paint;

    sget-object v7, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v7, 0x40e00000    # 7.0f

    mul-float/2addr v7, v2

    const/high16 v8, 0x75000000

    const/4 v9, 0x0

    invoke-virtual {v6, v7, v9, v9, v8}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    invoke-virtual {v1, v4, v3, v3, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    invoke-virtual {v6}, Landroid/graphics/Paint;->clearShadowLayer()V

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v7

    iget-wide v10, v0, Lc/m9;->t:J

    sub-long/2addr v7, v10

    long-to-float v7, v7

    const/high16 v8, 0x43340000    # 180.0f

    div-float/2addr v7, v8

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-static {v8, v7}, Ljava/lang/Math;->min(FF)F

    move-result v7

    iget-object v10, v0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    const/high16 v11, 0x42c80000    # 100.0f

    if-nez v10, :cond_0

    iget v7, v0, Lc/m9;->q:I

    int-to-float v7, v7

    div-float/2addr v7, v11

    goto :goto_0

    :cond_0
    iget v10, v0, Lc/m9;->r:F

    iget v12, v0, Lc/m9;->q:I

    int-to-float v12, v12

    div-float/2addr v12, v11

    sub-float/2addr v12, v10

    sub-float v7, v8, v7

    mul-float/2addr v7, v7

    sub-float v7, v8, v7

    mul-float/2addr v7, v12

    add-float/2addr v7, v10

    :goto_0
    iput v7, v0, Lc/m9;->s:F

    iget v7, v4, Landroid/graphics/RectF;->left:F

    invoke-virtual {v4}, Landroid/graphics/RectF;->width()F

    move-result v10

    iget v11, v0, Lc/m9;->s:F

    mul-float/2addr v10, v11

    add-float/2addr v10, v7

    iget-object v7, v0, Lc/m9;->p:Landroid/animation/ValueAnimator;

    if-nez v7, :cond_1

    move v7, v9

    goto :goto_1

    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v11

    iget-wide v13, v0, Lc/m9;->u:J

    sub-long/2addr v11, v13

    long-to-float v7, v11

    const/high16 v11, 0x447a0000    # 1000.0f

    div-float/2addr v7, v11

    :goto_1
    const/high16 v11, 0x40c00000    # 6.0f

    mul-float/2addr v11, v2

    iget v12, v4, Landroid/graphics/RectF;->left:F

    sub-float v12, v10, v12

    iget v13, v4, Landroid/graphics/RectF;->right:F

    sub-float/2addr v13, v10

    invoke-static {v12, v13}, Ljava/lang/Math;->min(FF)F

    move-result v12

    invoke-static {v11, v12}, Ljava/lang/Math;->min(FF)F

    move-result v11

    iget-object v15, v0, Lc/m9;->d:Landroid/graphics/Path;

    invoke-virtual {v15}, Landroid/graphics/Path;->reset()V

    iget v12, v4, Landroid/graphics/RectF;->left:F

    iget v13, v4, Landroid/graphics/RectF;->top:F

    invoke-virtual {v15, v12, v13}, Landroid/graphics/Path;->moveTo(FF)V

    neg-float v12, v7

    const/high16 v19, 0x40400000    # 3.0f

    mul-float v12, v12, v19

    float-to-double v12, v12

    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v11

    add-float/2addr v8, v10

    const v9, 0x40490fdb    # (float)Math.PI

    mul-float v14, v11, v9

    mul-float v20, v14, v5

    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    double-to-float v12, v12

    mul-float v12, v12, v20

    iget v13, v4, Landroid/graphics/RectF;->top:F

    invoke-virtual {v15, v8, v13}, Landroid/graphics/Path;->lineTo(FF)V

    const/4 v13, 0x1

    :goto_2
    const/16 v14, 0x8

    const/high16 v17, 0x41c00000    # 24.0f

    if-gt v13, v14, :cond_2

    int-to-float v14, v13

    const/high16 v18, 0x41000000    # 8.0f

    div-float v14, v14, v18

    mul-float v21, v14, v9

    mul-float v21, v21, v5

    mul-float v22, v7, v19

    sub-float v9, v21, v22

    move-object/from16 v22, v6

    float-to-double v5, v9

    move v9, v2

    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    mul-float/2addr v1, v11

    add-float/2addr v1, v10

    invoke-static {v5, v6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v5

    double-to-float v2, v5

    mul-float v2, v2, v20

    iget v5, v4, Landroid/graphics/RectF;->top:F

    add-int/lit8 v6, v13, -0x1

    int-to-float v6, v6

    div-float v6, v6, v18

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v18

    mul-float v18, v18, v6

    add-float v18, v18, v5

    iget v5, v4, Landroid/graphics/RectF;->top:F

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v6

    mul-float/2addr v6, v14

    add-float/2addr v5, v6

    div-float v12, v12, v17

    add-float v6, v12, v8

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v8

    div-float v8, v8, v17

    add-float v14, v8, v18

    div-float v8, v2, v17

    sub-float v8, v1, v8

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v12

    div-float v12, v12, v17

    sub-float v17, v5, v12

    move-object v12, v15

    move/from16 v23, v13

    move v13, v6

    const/4 v6, 0x1

    move-object v6, v15

    move v15, v8

    move/from16 v16, v17

    move/from16 v17, v1

    move/from16 v18, v5

    invoke-virtual/range {v12 .. v18}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    add-int/lit8 v13, v23, 0x1

    move v8, v1

    move v12, v2

    move-object v15, v6

    move v2, v9

    move-object/from16 v6, v22

    const/high16 v5, 0x40000000    # 2.0f

    const v9, 0x40490fdb    # (float)Math.PI

    move-object/from16 v1, p1

    goto :goto_2

    :cond_2
    move v9, v2

    move-object/from16 v22, v6

    move-object v6, v15

    iget v1, v4, Landroid/graphics/RectF;->left:F

    iget v2, v4, Landroid/graphics/RectF;->bottom:F

    invoke-virtual {v6, v1, v2}, Landroid/graphics/Path;->lineTo(FF)V

    invoke-virtual {v6}, Landroid/graphics/Path;->close()V

    iget-object v1, v0, Lc/m9;->c:Landroid/graphics/Path;

    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    sget-object v2, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v1, v4, v3, v3, v2}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    sget-object v2, Landroid/graphics/Path$Op;->INTERSECT:Landroid/graphics/Path$Op;

    invoke-virtual {v6, v1, v2}, Landroid/graphics/Path;->op(Landroid/graphics/Path;Landroid/graphics/Path$Op;)Z

    const/4 v1, 0x0

    move-object/from16 v2, p1

    invoke-virtual {v2, v4, v1}, Landroid/graphics/Canvas;->saveLayer(Landroid/graphics/RectF;Landroid/graphics/Paint;)I

    move-result v3

    move-object/from16 v5, v22

    invoke-virtual {v2, v6, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    iget-object v6, v0, Lc/m9;->f:Landroid/graphics/Matrix;

    iget v8, v4, Landroid/graphics/RectF;->left:F

    sub-float/2addr v10, v8

    const/high16 v8, 0x3f800000    # 1.0f

    invoke-static {v8, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    invoke-virtual {v6, v10, v8}, Landroid/graphics/Matrix;->setScale(FF)V

    iget v8, v4, Landroid/graphics/RectF;->left:F

    const/4 v10, 0x0

    invoke-virtual {v6, v8, v10}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    iget-object v8, v0, Lc/m9;->e:Landroid/graphics/LinearGradient;

    invoke-virtual {v8, v6}, Landroid/graphics/Shader;->setLocalMatrix(Landroid/graphics/Matrix;)V

    iget-object v6, v0, Lc/m9;->g:Landroid/graphics/PorterDuffXfermode;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    invoke-virtual {v5, v8}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    invoke-virtual {v2, v4, v5}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    iget-object v6, v0, Lc/m9;->h:Landroid/graphics/PorterDuffXfermode;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    const v6, -0x55000001

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v6, 0x0

    :goto_3
    iget-object v8, v0, Lc/m9;->i:[F

    array-length v10, v8

    if-ge v6, v10, :cond_4

    aget v8, v8, v6

    iget-object v10, v0, Lc/m9;->k:[F

    aget v10, v10, v6

    mul-float v11, v7, v10

    sub-float/2addr v8, v11

    const/high16 v11, 0x3f800000    # 1.0f

    rem-float/2addr v8, v11

    const/4 v12, 0x0

    cmpg-float v13, v8, v12

    if-gez v13, :cond_3

    add-float/2addr v8, v11

    :cond_3
    add-float/2addr v10, v11

    mul-float/2addr v10, v7

    int-to-float v11, v6

    add-float/2addr v10, v11

    float-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v10, v10

    const v11, 0x3d3851ec    # 0.045f

    mul-float/2addr v10, v11

    iget v11, v4, Landroid/graphics/RectF;->left:F

    invoke-virtual {v4}, Landroid/graphics/RectF;->width()F

    move-result v13

    mul-float/2addr v13, v8

    add-float/2addr v13, v11

    iget v8, v4, Landroid/graphics/RectF;->top:F

    iget-object v11, v0, Lc/m9;->j:[F

    aget v11, v11, v6

    add-float/2addr v11, v10

    invoke-virtual {v4}, Landroid/graphics/RectF;->height()F

    move-result v10

    mul-float/2addr v10, v11

    add-float/2addr v10, v8

    iget-object v8, v0, Lc/m9;->l:[F

    aget v8, v8, v6

    mul-float/2addr v8, v9

    invoke-virtual {v2, v13, v10, v8, v5}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_4
    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    invoke-virtual {v2, v3}, Landroid/graphics/Canvas;->restoreToCount(I)V

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v1, -0x1000000

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setColor(I)V

    const-string v1, "sans-serif"

    const/4 v3, 0x1

    invoke-static {v1, v3}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, v0, Lc/m9;->o:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v0, Lc/m9;->q:I

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "%"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iget v3, v0, Lc/m9;->n:F

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    invoke-virtual {v4}, Landroid/graphics/RectF;->width()F

    move-result v6

    mul-float v7, v9, v17

    sub-float/2addr v6, v7

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v7, v6}, Ljava/lang/Math;->max(FF)F

    move-result v6

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v7

    cmpl-float v7, v7, v6

    if-lez v7, :cond_5

    mul-float/2addr v3, v6

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v6

    div-float/2addr v3, v6

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    :cond_5
    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v5, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    invoke-virtual {v4}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    invoke-virtual {v4}, Landroid/graphics/RectF;->centerY()F

    move-result v4

    invoke-virtual {v5}, Landroid/graphics/Paint;->ascent()F

    move-result v6

    invoke-virtual {v5}, Landroid/graphics/Paint;->descent()F

    move-result v7

    add-float/2addr v7, v6

    const/high16 v6, 0x40000000    # 2.0f

    div-float/2addr v7, v6

    sub-float/2addr v4, v7

    invoke-virtual {v2, v1, v3, v4, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/view/View;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const-string v0, "android.widget.ProgressBar"

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    iget v0, p0, Lc/m9;->q:I

    int-to-float v0, v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/high16 v3, 0x42c80000    # 100.0f

    invoke-static {v1, v2, v3, v0}, Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;->obtain(IFFF)Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setRangeInfo(Landroid/view/accessibility/AccessibilityNodeInfo$RangeInfo;)V

    return-void
.end method
