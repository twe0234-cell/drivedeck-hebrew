.class public final synthetic Lc/i9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnDrawListener;


# instance fields
.field public final synthetic a:Lc/l9;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lc/l9;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/i9;->a:Lc/l9;

    iput p2, p0, Lc/i9;->b:I

    return-void
.end method


# virtual methods
.method public final onDraw()V
    .locals 4

    iget-object v0, p0, Lc/i9;->a:Lc/l9;

    iget-boolean v1, v0, Lc/l9;->m:Z

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/l9;->m:Z

    new-instance v1, Lc/w;

    iget v2, p0, Lc/i9;->b:I

    const/16 v3, 0xd

    invoke-direct {v1, v0, v2, v3}, Lc/w;-><init>(Ljava/lang/Object;II)V

    iget-object v0, v0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :goto_0
    return-void
.end method
