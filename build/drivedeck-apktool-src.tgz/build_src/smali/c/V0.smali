.class public final Lc/V0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/s0;

.field public final b:Landroid/graphics/RectF;


# direct methods
.method public constructor <init>(Lc/s0;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lc/V0;->b:Landroid/graphics/RectF;

    iput-object p1, p0, Lc/V0;->a:Lc/s0;

    return-void
.end method
