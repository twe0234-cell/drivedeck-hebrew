.class public final synthetic Lc/O0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/n1;

.field public final synthetic c:Lc/F3;


# direct methods
.method public synthetic constructor <init>(Lc/n1;Lc/F3;I)V
    .locals 0

    iput p3, p0, Lc/O0;->a:I

    iput-object p1, p0, Lc/O0;->b:Lc/n1;

    iput-object p2, p0, Lc/O0;->c:Lc/F3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .locals 1

    iget p1, p0, Lc/O0;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/O0;->b:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "speed_navigation"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/O0;->c:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/O0;->b:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v0, "speed_obd"

    invoke-static {p1, v0, p2}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object p1, p0, Lc/O0;->c:Lc/F3;

    invoke-virtual {p1}, Lc/F3;->run()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
