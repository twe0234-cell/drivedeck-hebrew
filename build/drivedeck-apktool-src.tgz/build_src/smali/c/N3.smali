.class public final Lc/N3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Landroid/widget/TextView;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lc/k3;Landroid/widget/TextView;Lc/n1;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lc/N3;->a:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/N3;->d:Ljava/lang/Object;

    iput-object p2, p0, Lc/N3;->c:Landroid/widget/TextView;

    iput-object p3, p0, Lc/N3;->b:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>([ILandroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;I)V
    .locals 0

    .line 1
    iput p4, p0, Lc/N3;->a:I

    iput-object p1, p0, Lc/N3;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/N3;->c:Landroid/widget/TextView;

    iput-object p3, p0, Lc/N3;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final b(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final c(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final d(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final e(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method

.method private final f(Landroid/widget/SeekBar;)V
    .locals 0

    return-void
.end method


# virtual methods
.method public final onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .locals 4

    iget p1, p0, Lc/N3;->a:I

    packed-switch p1, :pswitch_data_0

    const/16 p1, 0x19

    add-int/2addr p2, p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/N3;->d:Ljava/lang/Object;

    check-cast v1, Lc/k3;

    iget-object v2, v1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v3, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438 \u043e\u043a\u043d\u0430 \u043e\u0442 25 \u0434\u043e 150 \u043f\u0440\u043e\u0446\u0435\u043d\u0442\u043e\u0432"

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "%"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lc/N3;->c:Landroid/widget/TextView;

    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-nez p3, :cond_0

    goto :goto_0

    :cond_0
    iget-object p3, p0, Lc/N3;->b:Ljava/lang/Object;

    check-cast p3, Lc/n1;

    iget-object v0, p3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "home_edge_fade_size"

    invoke-virtual {p3, v2}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/16 v2, 0x96

    invoke-static {v2, p2, p1, v0, p3}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object p1, v1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_1
    :goto_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/N3;->b:Ljava/lang/Object;

    check-cast p1, [I

    const/4 p3, 0x0

    aput p2, p1, p3

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lc/N3;->d:Ljava/lang/Object;

    check-cast p3, Lru/drivedeck/launcher/MainActivity;

    const-string v0, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u2014 "

    invoke-static {p3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " dp"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lc/N3;->c:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_1
    iget-object p1, p0, Lc/N3;->b:Ljava/lang/Object;

    check-cast p1, [I

    const/4 p3, 0x0

    aput p2, p1, p3

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p3, p0, Lc/N3;->d:Ljava/lang/Object;

    check-cast p3, Lru/drivedeck/launcher/MainActivity;

    const-string v0, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u2014 "

    invoke-static {p3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p2, " dp"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lc/N3;->c:Landroid/widget/TextView;

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0

    iget p1, p0, Lc/N3;->a:I

    return-void
.end method

.method public final onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .locals 0

    iget p1, p0, Lc/N3;->a:I

    return-void
.end method
