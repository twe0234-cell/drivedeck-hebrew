.class public final synthetic Lc/u2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;


# direct methods
.method public synthetic constructor <init>(Lc/k3;I)V
    .locals 0

    iput p2, p0, Lc/u2;->a:I

    iput-object p1, p0, Lc/u2;->b:Lc/k3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    iget v0, p0, Lc/u2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->l()V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/app/AlertDialog$Builder;

    iget-object v2, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->j0()Z

    move-result v3

    if-eqz v3, :cond_1

    const v3, 0x103023a

    goto :goto_0

    :cond_1
    const v3, 0x1030226

    :goto_0
    iget-object v4, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v1, v4, v3}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v3, "\u042f\u0437\u044b\u043a \u0440\u0430\u0441\u043f\u043e\u0437\u043d\u0430\u0432\u0430\u043d\u0438\u044f"

    invoke-static {v4, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    sget-object v3, Ld/a;->b:[Ljava/lang/String;

    invoke-virtual {v2}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ld/a;->b(Ljava/lang/String;)I

    move-result v2

    new-instance v4, Lc/B2;

    const/4 v5, 0x0

    invoke-direct {v4, v0, v5}, Lc/B2;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v1, v3, v2, v4}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.ACCESSIBILITY_SETTINGS"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->b:Lc/z;

    invoke-virtual {v1}, Lc/z;->c()Ljava/util/List;

    move-result-object v3

    new-instance v5, Lc/A2;

    const/4 v1, 0x0

    invoke-direct {v5, v0, v1}, Lc/A2;-><init>(Lc/k3;I)V

    new-instance v6, Lc/a1;

    const/4 v1, 0x3

    invoke-direct {v6, v1}, Lc/a1;-><init>(I)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    iget-object v2, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v4, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u043c\u0443\u0437\u044b\u043a\u0438"

    invoke-static/range {v2 .. v8}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    return-void

    :pswitch_3
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "package:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_4
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget v1, v0, Lc/k3;->q:I

    if-ltz v1, :cond_2

    iget-object v2, v0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_2

    iget v1, v0, Lc/k3;->q:I

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    iget v1, v0, Lc/k3;->q:I

    invoke-virtual {v0, v1}, Lc/k3;->y(I)V

    goto :goto_1

    :cond_2
    const/4 v1, -0x1

    iput v1, v0, Lc/k3;->r:I

    const-string v1, ""

    iput-object v1, v0, Lc/k3;->w:Ljava/lang/String;

    iput-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    const/high16 v1, 0x3f000000    # 0.5f

    iput v1, v0, Lc/k3;->x:F

    const/16 v1, 0x64

    iput v1, v0, Lc/k3;->z:I

    iput v1, v0, Lc/k3;->y:I

    const/4 v1, 0x0

    iput v1, v0, Lc/k3;->s:I

    const-string v1, "pairs"

    iput-object v1, v0, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->X()V

    :goto_1
    return-void

    :pswitch_5
    const-string v0, "dock"

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iput-object v0, v1, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v1}, Lc/k3;->X()V

    return-void

    :pswitch_6
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_7
    const/4 v0, 0x0

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v1, v0}, Lc/k3;->v0(Z)V

    return-void

    :pswitch_8
    const/4 v0, 0x1

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v1, v0}, Lc/k3;->v0(Z)V

    return-void

    :pswitch_9
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "package:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Lc/k3;->N(Landroid/content/Intent;)V

    return-void

    :pswitch_a
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->X()V

    return-void

    :pswitch_b
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->b:Lc/z;

    invoke-virtual {v1}, Lc/z;->c()Ljava/util/List;

    move-result-object v3

    new-instance v5, Lc/A2;

    const/4 v1, 0x1

    invoke-direct {v5, v0, v1}, Lc/A2;-><init>(Lc/k3;I)V

    new-instance v6, Lc/a1;

    const/4 v1, 0x3

    invoke-direct {v6, v1}, Lc/a1;-><init>(I)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    iget-object v2, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    const-string v4, "\u041c\u0443\u0437\u044b\u043a\u0430\u043b\u044c\u043d\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435"

    invoke-static/range {v2 .. v8}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    return-void

    :pswitch_c
    const-string v0, "home"

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iput-object v0, v1, Lc/k3;->h:Ljava/lang/String;

    invoke-virtual {v1}, Lc/k3;->X()V

    return-void

    :pswitch_d
    sget-object v0, Lc/Q1;->b:Lc/Q1;

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iget-object v2, v1, Lc/k3;->c:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->i()Lc/u0;

    move-result-object v3

    new-instance v4, Lc/u0;

    iget-object v5, v3, Lc/u0;->c:Ljava/lang/Object;

    check-cast v5, Lc/q0;

    iget-object v6, v3, Lc/u0;->d:Ljava/lang/Object;

    check-cast v6, Ljava/util/List;

    iget v3, v3, Lc/u0;->a:I

    invoke-direct {v4, v0, v5, v6, v3}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    const/4 v0, 0x0

    invoke-virtual {v2, v4, v0, v0}, Lc/n1;->B0(Lc/u0;ZZ)Z

    iget-object v0, v1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_3
    invoke-virtual {v1}, Lc/k3;->X()V

    return-void

    :pswitch_e
    sget-object v0, Lc/Q1;->a:Lc/Q1;

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iget-object v2, v1, Lc/k3;->c:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->i()Lc/u0;

    move-result-object v3

    new-instance v4, Lc/u0;

    iget-object v5, v3, Lc/u0;->c:Ljava/lang/Object;

    check-cast v5, Lc/q0;

    iget-object v6, v3, Lc/u0;->d:Ljava/lang/Object;

    check-cast v6, Ljava/util/List;

    iget v3, v3, Lc/u0;->a:I

    invoke-direct {v4, v0, v5, v6, v3}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    const/4 v0, 0x0

    invoke-virtual {v2, v4, v0, v0}, Lc/n1;->B0(Lc/u0;ZZ)Z

    iget-object v0, v1, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Lru/drivedeck/launcher/MainActivity;->U()V

    :cond_4
    invoke-virtual {v1}, Lc/k3;->X()V

    return-void

    :pswitch_f
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    iget-object v2, v0, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x0

    iput-object v2, v0, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, -0x1

    if-eqz v1, :cond_5

    move v1, v2

    goto :goto_2

    :cond_5
    const/4 v1, 0x0

    :goto_2
    iput v1, v0, Lc/k3;->q:I

    iput v2, v0, Lc/k3;->r:I

    const-string v1, ""

    iput-object v1, v0, Lc/k3;->w:Ljava/lang/String;

    iput-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    const/high16 v1, 0x3f000000    # 0.5f

    iput v1, v0, Lc/k3;->x:F

    invoke-virtual {v0}, Lc/k3;->l()V

    const-string v1, "\u0412\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e"

    iput-object v1, v0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void

    :pswitch_10
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, v0, Lc/k3;->e:Ljava/util/ArrayList;

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iput-object v1, v0, Lc/k3;->A:Ljava/util/ArrayList;

    iget v1, v0, Lc/k3;->r:I

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    const/4 v1, -0x1

    iput v1, v0, Lc/k3;->q:I

    iput v1, v0, Lc/k3;->r:I

    const-string v1, ""

    iput-object v1, v0, Lc/k3;->w:Ljava/lang/String;

    iput-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    const/high16 v1, 0x3f000000    # 0.5f

    iput v1, v0, Lc/k3;->x:F

    const/16 v1, 0x64

    iput v1, v0, Lc/k3;->z:I

    iput v1, v0, Lc/k3;->y:I

    const/4 v1, 0x0

    iput v1, v0, Lc/k3;->s:I

    invoke-virtual {v0}, Lc/k3;->l()V

    const-string v1, "\u041f\u0430\u0440\u0430 \u0443\u0434\u0430\u043b\u0435\u043d\u0430 \u0438\u0437 \u0434\u043e\u043a\u0430"

    iput-object v1, v0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->S()V

    return-void

    :pswitch_11
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_e

    iget-object v1, v0, Lc/k3;->w:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_6

    goto/16 :goto_7

    :cond_6
    iget-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    iget-object v2, v0, Lc/k3;->w:Ljava/lang/String;

    iget-object v3, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lc/n1;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "\u041e\u0434\u043d\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043d\u0435\u043b\u044c\u0437\u044f \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u0432 \u0434\u0432\u0443\u0445 \u043e\u043a\u043d\u0430\u0445"

    invoke-virtual {v0, v1}, Lc/k3;->J(Ljava/lang/String;)V

    goto/16 :goto_8

    :cond_7
    iget v1, v0, Lc/k3;->r:I

    iget-object v2, v0, Lc/k3;->e:Ljava/util/ArrayList;

    if-gez v1, :cond_9

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    iget-object v3, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v3, :cond_8

    invoke-virtual {v3}, Lru/drivedeck/launcher/MainActivity;->p()I

    move-result v3

    goto :goto_3

    :cond_8
    iget v3, v0, Lc/k3;->f:I

    :goto_3
    if-lt v1, v3, :cond_9

    const-string v1, "\u0414\u043e\u043a \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d \u2014 \u0441\u043d\u0430\u0447\u0430\u043b\u0430 \u043e\u0441\u0432\u043e\u0431\u043e\u0434\u0438\u0442\u0435 \u043c\u0435\u0441\u0442\u043e"

    invoke-virtual {v0, v1}, Lc/k3;->J(Ljava/lang/String;)V

    goto/16 :goto_8

    :cond_9
    const/4 v1, 0x0

    :goto_4
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-ge v1, v3, :cond_b

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    iget v4, v0, Lc/k3;->r:I

    if-eq v1, v4, :cond_a

    invoke-static {v3}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_a

    iget-object v4, v0, Lc/k3;->v:Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    iget-object v4, v0, Lc/k3;->w:Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a

    iget v4, v0, Lc/k3;->x:F

    invoke-static {v3}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v3

    sub-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const v4, 0x3a83126f    # 0.001f

    cmpg-float v3, v3, v4

    if-gez v3, :cond_a

    const-string v1, "\u0422\u0430\u043a\u0430\u044f \u043f\u0430\u0440\u0430 \u0443\u0436\u0435 \u0437\u0430\u043a\u0440\u0435\u043f\u043b\u0435\u043d\u0430"

    invoke-virtual {v0, v1}, Lc/k3;->J(Ljava/lang/String;)V

    goto :goto_8

    :cond_a
    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_b
    iget-object v1, v0, Lc/k3;->v:Ljava/lang/String;

    iget-object v3, v0, Lc/k3;->w:Ljava/lang/String;

    iget v4, v0, Lc/k3;->x:F

    iget v5, v0, Lc/k3;->y:I

    iget v6, v0, Lc/k3;->z:I

    invoke-static {v1, v3, v4, v5, v6}, Lc/G8;->b0(Ljava/lang/String;Ljava/lang/String;FII)Ljava/lang/String;

    move-result-object v1

    iget v3, v0, Lc/k3;->r:I

    if-ltz v3, :cond_c

    invoke-virtual {v2, v3, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    goto :goto_5

    :cond_c
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_5
    iget v1, v0, Lc/k3;->r:I

    if-ltz v1, :cond_d

    goto :goto_6

    :cond_d
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_6
    iput v1, v0, Lc/k3;->q:I

    iput v1, v0, Lc/k3;->r:I

    const/4 v1, 0x0

    iput-object v1, v0, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v0}, Lc/k3;->l()V

    const-string v1, "\u041f\u0430\u0440\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0430"

    iput-object v1, v0, Lc/k3;->B:Ljava/lang/String;

    invoke-virtual {v0}, Lc/k3;->S()V

    goto :goto_8

    :cond_e
    :goto_7
    const-string v1, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043e\u0431\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-virtual {v0, v1}, Lc/k3;->J(Ljava/lang/String;)V

    :goto_8
    return-void

    :pswitch_12
    const/4 v0, -0x1

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iput v0, v1, Lc/k3;->r:I

    const-string v0, ""

    iput-object v0, v1, Lc/k3;->w:Ljava/lang/String;

    iput-object v0, v1, Lc/k3;->v:Ljava/lang/String;

    const/high16 v0, 0x3f000000    # 0.5f

    iput v0, v1, Lc/k3;->x:F

    const/16 v0, 0x64

    iput v0, v1, Lc/k3;->z:I

    iput v0, v1, Lc/k3;->y:I

    const/4 v0, 0x0

    iput v0, v1, Lc/k3;->s:I

    invoke-virtual {v1}, Lc/k3;->S()V

    return-void

    :pswitch_13
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->i(Ljava/lang/Boolean;)V

    return-void

    :pswitch_14
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->i(Ljava/lang/Boolean;)V

    return-void

    :pswitch_15
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "home_wallpaper"

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_16
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    const/4 v1, 0x0

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0, v1}, Lru/drivedeck/launcher/MainActivity;->i(Ljava/lang/Boolean;)V

    return-void

    :pswitch_17
    const/4 v0, 0x0

    iget-object v1, p0, Lc/u2;->b:Lc/k3;

    iput-boolean v0, v1, Lc/k3;->K:Z

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-static {}, Lc/N1;->B()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lc/k3;->J(Ljava/lang/String;)V

    invoke-virtual {v1}, Lc/k3;->X()V

    :cond_f
    return-void

    :pswitch_18
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Landroid/content/Intent;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "package:"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string v3, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    return-void

    :pswitch_19
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_10

    const-string v1, "\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442\u0441\u044f"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_9

    :cond_10
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "android.intent.category.OPENABLE"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v2, "*/*"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x1d5b

    :try_start_0
    invoke-virtual {v0, v1, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_9

    :catch_0
    const-string v1, "\u041d\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435 \u043d\u0435\u0442 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0434\u043b\u044f \u0432\u044b\u0431\u043e\u0440\u0430 \u0444\u0430\u0439\u043b\u043e\u0432"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :goto_9
    return-void

    :pswitch_1a
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_11

    const-string v1, "\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442\u0441\u044f"

    invoke-static {v0, v1}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_a

    :cond_11
    const/4 v1, 0x0

    invoke-static {v0, v1}, Lc/q4;->e(Lru/drivedeck/launcher/MainActivity;Z)V

    :goto_a
    return-void

    :pswitch_1b
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    invoke-virtual {v0}, Lc/k3;->X()V

    return-void

    :pswitch_1c
    iget-object v0, p0, Lc/u2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "android.intent.category.OPENABLE"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v2, "application/vnd.android.package-archive"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x1d60

    :try_start_1
    invoke-virtual {v0, v1, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_1
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_b

    :catch_1
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0432\u044b\u0431\u043e\u0440 APK. \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u043d\u0430\u0431\u043e\u0440 \u0447\u0435\u0440\u0435\u0437 \u0444\u0430\u0439\u043b\u043e\u0432\u044b\u0439 \u043c\u0435\u043d\u0435\u0434\u0436\u0435\u0440."

    const/4 v2, 0x1

    invoke-static {v0, v1, v0, v2}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :goto_b
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
