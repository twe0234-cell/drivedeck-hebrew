.class public final Lc/A8;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final n:[I

.field public static final o:Ljava/lang/reflect/Method;

.field public static final p:Ljava/lang/reflect/Method;

.field public static final q:Ljava/util/concurrent/ExecutorService;

.field public static final r:Landroid/os/Handler;

.field public static final s:Ljava/lang/Object;

.field public static final t:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public static final u:Ljava/util/concurrent/atomic/AtomicLong;

.field public static volatile v:Lc/A8;

.field public static volatile w:J


# instance fields
.field public final a:Z

.field public final b:Z

.field public final c:Z

.field public final d:Z

.field public final e:Z

.field public final f:I

.field public final g:I

.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/String;

.field public final j:Z

.field public final k:Z

.field public final l:Z

.field public final m:Z


# direct methods
.method static constructor <clinit>()V
    .locals 18

    const/4 v0, 0x1

    const/4 v1, 0x6

    new-array v1, v1, [I

    fill-array-data v1, :array_0

    sput-object v1, Lc/A8;->n:[I

    const-class v1, Landroid/bluetooth/BluetoothAdapter;

    const-string v2, "getConnectionState"

    const/4 v3, 0x0

    :try_start_0
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-object v1, v3

    :goto_0
    sput-object v1, Lc/A8;->o:Ljava/lang/reflect/Method;

    const-class v1, Landroid/bluetooth/BluetoothDevice;

    const-string v2, "isConnected"

    :try_start_1
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move-object v3, v1

    :catch_1
    sput-object v3, Lc/A8;->p:Ljava/lang/reflect/Method;

    new-instance v0, Lc/A8;

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, -0x1

    const/4 v11, -0x1

    const-string v12, ""

    const-string v13, ""

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v4, v0

    invoke-direct/range {v4 .. v17}, Lc/A8;-><init>(ZZZZZIILjava/lang/String;Ljava/lang/String;ZZZZ)V

    new-instance v1, Lc/o3;

    const/4 v2, 0x4

    invoke-direct {v1, v2}, Lc/o3;-><init>(I)V

    invoke-static {v1}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    sput-object v1, Lc/A8;->q:Ljava/util/concurrent/ExecutorService;

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v1, Lc/A8;->r:Landroid/os/Handler;

    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    sput-object v1, Lc/A8;->s:Ljava/lang/Object;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    sput-object v1, Lc/A8;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v1, Ljava/util/concurrent/atomic/AtomicLong;

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    sput-object v1, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    sput-object v0, Lc/A8;->v:Lc/A8;

    return-void

    nop

    :array_0
    .array-data 4
        0x2
        0x1
        0xb
        0x10
        0x11
        0x12
    .end array-data
.end method

.method public constructor <init>(ZZZZZIILjava/lang/String;Ljava/lang/String;ZZZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lc/A8;->a:Z

    iput-boolean p2, p0, Lc/A8;->b:Z

    iput-boolean p3, p0, Lc/A8;->c:Z

    iput-boolean p4, p0, Lc/A8;->d:Z

    iput-boolean p5, p0, Lc/A8;->e:Z

    iput p6, p0, Lc/A8;->f:I

    iput p7, p0, Lc/A8;->g:I

    iput-object p8, p0, Lc/A8;->h:Ljava/lang/String;

    iput-object p9, p0, Lc/A8;->i:Ljava/lang/String;

    iput-boolean p10, p0, Lc/A8;->j:Z

    iput-boolean p11, p0, Lc/A8;->k:Z

    iput-boolean p12, p0, Lc/A8;->l:Z

    iput-boolean p13, p0, Lc/A8;->m:Z

    return-void
.end method

.method public static a(I)I
    .locals 1

    if-eqz p0, :cond_4

    const/4 v0, 0x1

    if-eq p0, v0, :cond_3

    const/4 v0, 0x2

    if-eq p0, v0, :cond_2

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1

    const/4 v0, 0x4

    if-eq p0, v0, :cond_0

    const p0, 0x7f03002c

    return p0

    :cond_0
    const p0, 0x7f03002b

    return p0

    :cond_1
    const p0, 0x7f03002a

    return p0

    :cond_2
    const p0, 0x7f030029

    return p0

    :cond_3
    const p0, 0x7f030028

    return p0

    :cond_4
    const p0, 0x7f030027

    return p0
.end method

.method public static b(Landroid/bluetooth/BluetoothAdapter;)Z
    .locals 6

    const/4 v0, 0x0

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_2

    :cond_0
    sget-object v1, Lc/A8;->n:[I

    move v2, v0

    :goto_0
    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ge v2, v5, :cond_2

    aget v5, v1, v2

    :try_start_0
    invoke-virtual {p0, v5}, Landroid/bluetooth/BluetoothAdapter;->getProfileConnectionState(I)I

    move-result v5
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    if-ne v5, v3, :cond_1

    return v4

    :catch_0
    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    :try_start_1
    sget-object v2, Lc/A8;->o:Ljava/lang/reflect/Method;

    if-nez v2, :cond_3

    move-object v2, v1

    goto :goto_1

    :cond_3
    invoke-virtual {v2, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    :goto_1
    instance-of v5, v2, Ljava/lang/Integer;

    if-eqz v5, :cond_4

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    if-ne v2, v3, :cond_4

    return v4

    :catch_1
    :cond_4
    sget-object v2, Lc/A8;->p:Ljava/lang/reflect/Method;

    if-nez v2, :cond_5

    return v0

    :cond_5
    :try_start_2
    invoke-virtual {p0}, Landroid/bluetooth/BluetoothAdapter;->getBondedDevices()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_6
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/bluetooth/BluetoothDevice;

    invoke-virtual {v2, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    instance-of v5, v3, Ljava/lang/Boolean;

    if-eqz v5, :cond_6

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3
    :try_end_2
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    if-eqz v3, :cond_6

    return v4

    :catch_2
    :cond_7
    :goto_2
    return v0
.end method

.method public static c(Landroid/content/Context;)Lc/A8;
    .locals 21

    move-object/from16 v0, p0

    const-string v1, "connectivity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/ConnectivityManager;

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v6

    if-nez v6, :cond_0

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v1, v6}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v6

    :goto_0
    const/16 v7, 0xc

    if-eqz v6, :cond_1

    invoke-virtual {v6, v7}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v6

    if-eqz v6, :cond_1

    move v6, v4

    goto :goto_1

    :cond_1
    move v6, v5

    :goto_1
    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getAllNetworks()[Landroid/net/Network;

    move-result-object v8

    array-length v9, v8

    move v10, v5

    move v11, v10

    move v12, v11

    move v13, v12

    :goto_2
    if-ge v10, v9, :cond_3

    aget-object v14, v8, v10

    invoke-virtual {v1, v14}, Landroid/net/ConnectivityManager;->getNetworkCapabilities(Landroid/net/Network;)Landroid/net/NetworkCapabilities;

    move-result-object v14

    if-nez v14, :cond_2

    goto :goto_3

    :cond_2
    invoke-virtual {v14, v7}, Landroid/net/NetworkCapabilities;->hasCapability(I)Z

    move-result v15

    or-int/2addr v6, v15

    invoke-virtual {v14, v4}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v15

    or-int/2addr v11, v15

    invoke-virtual {v14, v2}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v15

    or-int/2addr v12, v15

    invoke-virtual {v14, v5}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v14

    or-int/2addr v13, v14

    :goto_3
    add-int/lit8 v10, v10, 0x1

    goto :goto_2

    :cond_3
    move v9, v11

    move v10, v12

    goto :goto_4

    :cond_4
    move v6, v5

    move v9, v6

    move v10, v9

    move v13, v10

    :goto_4
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v7, "wifi"

    invoke-virtual {v1, v7}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/wifi/WifiManager;

    if-eqz v1, :cond_5

    :try_start_0
    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->isWifiEnabled()Z

    move-result v7
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v7, :cond_5

    goto :goto_5

    :catch_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v7

    const-string v8, "wifi_on"

    invoke-static {v7, v8, v5}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v7

    if-eqz v7, :cond_5

    :goto_5
    move v7, v4

    goto :goto_6

    :cond_5
    move v7, v5

    :goto_6
    move/from16 v17, v7

    const/4 v7, -0x1

    const-string v8, ""

    if-eqz v9, :cond_e

    if-nez v1, :cond_6

    const/4 v1, 0x0

    goto :goto_7

    :cond_6
    invoke-virtual {v1}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object v1

    :goto_7
    if-eqz v1, :cond_e

    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getRssi()I

    move-result v11

    if-gez v11, :cond_9

    const/16 v12, -0x7f

    if-gt v11, v12, :cond_7

    goto :goto_8

    :cond_7
    const/4 v12, 0x5

    invoke-static {v11, v12}, Landroid/net/wifi/WifiManager;->calculateSignalLevel(II)I

    move-result v11

    if-gez v11, :cond_8

    goto :goto_8

    :cond_8
    invoke-static {v2, v11}, Ljava/lang/Math;->min(II)I

    move-result v11

    goto :goto_9

    :cond_9
    :goto_8
    move v11, v7

    :goto_9
    invoke-virtual {v1}, Landroid/net/wifi/WifiInfo;->getFrequency()I

    move-result v1

    const/16 v12, 0x960

    if-lt v1, v12, :cond_a

    const/16 v12, 0x9c4

    if-ge v1, v12, :cond_a

    const-string v1, "2,4 \u0413\u0413\u0446"

    goto :goto_a

    :cond_a
    const/16 v12, 0x1324

    if-lt v1, v12, :cond_b

    const/16 v12, 0x170c

    if-ge v1, v12, :cond_b

    const-string v1, "5 \u0413\u0413\u0446"

    goto :goto_a

    :cond_b
    const/16 v12, 0x1725

    if-lt v1, v12, :cond_c

    const/16 v12, 0x1bd5

    if-ge v1, v12, :cond_c

    const-string v1, "6 \u0413\u0413\u0446"

    goto :goto_a

    :cond_c
    const v12, 0xdea8

    if-lt v1, v12, :cond_d

    const v12, 0x11558

    if-ge v1, v12, :cond_d

    const-string v1, "60 \u0413\u0413\u0446"

    goto :goto_a

    :cond_d
    move-object v1, v8

    :goto_a
    move-object/from16 v16, v1

    move v14, v11

    goto :goto_b

    :cond_e
    move v14, v7

    move-object/from16 v16, v8

    :goto_b
    const-string v1, "phone"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    const/16 v11, 0x1e

    if-eqz v1, :cond_20

    :try_start_1
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getDataState()I

    move-result v12
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v15, 0x2

    if-ne v12, v15, :cond_f

    move v12, v4

    goto :goto_c

    :cond_f
    move v12, v5

    :goto_c
    or-int/2addr v13, v12

    :catch_1
    :try_start_2
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getDataNetworkType()I

    move-result v12

    if-nez v12, :cond_10

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getNetworkType()I

    move-result v12

    :cond_10
    sget v15, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1d

    if-lt v15, v3, :cond_11

    const/16 v3, 0x14

    if-ne v12, v3, :cond_11

    const-string v8, "5G"

    goto :goto_d

    :cond_11
    const/16 v3, 0xf

    if-eq v12, v3, :cond_13

    const/16 v3, 0x12

    if-eq v12, v3, :cond_12

    packed-switch v12, :pswitch_data_0

    goto :goto_d

    :pswitch_0
    const-string v8, "2G"

    goto :goto_d

    :cond_12
    :pswitch_1
    const-string v8, "LTE"

    goto :goto_d

    :cond_13
    :pswitch_2
    const-string v8, "3G"
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :goto_d
    if-eqz v13, :cond_20

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1c

    if-lt v3, v12, :cond_15

    :try_start_3
    invoke-static {v1}, Lc/T;->g(Landroid/telephony/TelephonyManager;)Landroid/telephony/SignalStrength;

    move-result-object v3

    if-eqz v3, :cond_15

    invoke-virtual {v3}, Landroid/telephony/SignalStrength;->getLevel()I

    move-result v3

    if-gez v3, :cond_14

    goto :goto_e

    :cond_14
    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v3
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_3

    goto :goto_f

    :catch_3
    :cond_15
    :goto_e
    move v3, v7

    :goto_f
    if-gez v3, :cond_21

    :try_start_4
    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getAllCellInfo()Ljava/util/List;

    move-result-object v1

    if-nez v1, :cond_16

    goto/16 :goto_13

    :cond_16
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    move v3, v7

    :cond_17
    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_1f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/telephony/CellInfo;

    if-eqz v12, :cond_17

    invoke-virtual {v12}, Landroid/telephony/CellInfo;->isRegistered()Z

    move-result v15

    if-nez v15, :cond_18

    goto :goto_10

    :cond_18
    sget v15, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v15, v11, :cond_19

    invoke-static {v12}, Lc/B1;->f(Landroid/telephony/CellInfo;)Landroid/telephony/CellSignalStrength;

    move-result-object v12

    goto :goto_11

    :cond_19
    instance-of v15, v12, Landroid/telephony/CellInfoLte;

    if-eqz v15, :cond_1a

    check-cast v12, Landroid/telephony/CellInfoLte;

    invoke-virtual {v12}, Landroid/telephony/CellInfoLte;->getCellSignalStrength()Landroid/telephony/CellSignalStrengthLte;

    move-result-object v12

    goto :goto_11

    :cond_1a
    instance-of v15, v12, Landroid/telephony/CellInfoWcdma;

    if-eqz v15, :cond_1b

    check-cast v12, Landroid/telephony/CellInfoWcdma;

    invoke-virtual {v12}, Landroid/telephony/CellInfoWcdma;->getCellSignalStrength()Landroid/telephony/CellSignalStrengthWcdma;

    move-result-object v12

    goto :goto_11

    :cond_1b
    instance-of v15, v12, Landroid/telephony/CellInfoGsm;

    if-eqz v15, :cond_1c

    check-cast v12, Landroid/telephony/CellInfoGsm;

    invoke-virtual {v12}, Landroid/telephony/CellInfoGsm;->getCellSignalStrength()Landroid/telephony/CellSignalStrengthGsm;

    move-result-object v12

    goto :goto_11

    :cond_1c
    instance-of v15, v12, Landroid/telephony/CellInfoCdma;

    if-eqz v15, :cond_1d

    check-cast v12, Landroid/telephony/CellInfoCdma;

    invoke-virtual {v12}, Landroid/telephony/CellInfoCdma;->getCellSignalStrength()Landroid/telephony/CellSignalStrengthCdma;

    move-result-object v12

    goto :goto_11

    :cond_1d
    const/4 v12, 0x0

    :goto_11
    if-eqz v12, :cond_17

    invoke-virtual {v12}, Landroid/telephony/CellSignalStrength;->getLevel()I

    move-result v12

    if-gez v12, :cond_1e

    move v12, v7

    goto :goto_12

    :cond_1e
    invoke-static {v2, v12}, Ljava/lang/Math;->min(II)I

    move-result v12

    :goto_12
    invoke-static {v3, v12}, Ljava/lang/Math;->max(II)I

    move-result v3
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_4

    goto :goto_10

    :cond_1f
    move v7, v3

    :catch_4
    :cond_20
    :goto_13
    move-object v15, v8

    move v12, v13

    move v13, v7

    goto :goto_14

    :cond_21
    move-object v15, v8

    move v12, v13

    move v13, v3

    :goto_14
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-le v1, v11, :cond_23

    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_22

    goto :goto_15

    :cond_22
    move v1, v5

    goto :goto_16

    :cond_23
    :goto_15
    move v1, v4

    :goto_16
    const-string v2, "bluetooth_on"

    if-eqz v1, :cond_25

    :try_start_5
    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v3

    invoke-static {v3}, Lc/A8;->b(Landroid/bluetooth/BluetoothAdapter;)Z

    move-result v7
    :try_end_5
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_5

    if-eqz v3, :cond_24

    :try_start_6
    invoke-virtual {v3}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v3
    :try_end_6
    .catch Ljava/lang/SecurityException; {:try_start_6 .. :try_end_6} :catch_6

    if-eqz v3, :cond_24

    :goto_17
    move v3, v4

    goto :goto_18

    :cond_24
    move v3, v5

    :goto_18
    move v11, v7

    goto :goto_19

    :catch_5
    move v7, v5

    :catch_6
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-static {v3, v2, v5}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v3

    if-eqz v3, :cond_24

    goto :goto_17

    :cond_25
    move v3, v5

    move v11, v3

    :goto_19
    if-nez v1, :cond_27

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    invoke-static {v1, v2, v5}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-eqz v1, :cond_26

    move v1, v4

    goto :goto_1a

    :cond_26
    move v1, v5

    :goto_1a
    move/from16 v18, v1

    goto :goto_1b

    :cond_27
    move/from16 v18, v3

    :goto_1b
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "mobile_data"

    invoke-static {v1, v2, v4}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-eqz v1, :cond_28

    move/from16 v19, v4

    goto :goto_1c

    :cond_28
    move/from16 v19, v5

    :goto_1c
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "airplane_mode_on"

    invoke-static {v0, v1, v5}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v0

    if-eqz v0, :cond_29

    move/from16 v20, v4

    goto :goto_1d

    :cond_29
    move/from16 v20, v5

    :goto_1d
    new-instance v0, Lc/A8;

    if-nez v6, :cond_2b

    if-nez v9, :cond_2b

    if-eqz v12, :cond_2a

    goto :goto_1e

    :cond_2a
    move v8, v5

    goto :goto_1f

    :cond_2b
    :goto_1e
    move v8, v4

    :goto_1f
    move-object v7, v0

    invoke-direct/range {v7 .. v20}, Lc/A8;-><init>(ZZZZZIILjava/lang/String;Ljava/lang/String;ZZZZ)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public static d(Landroid/content/Context;Ljava/lang/Runnable;)Lc/A8;
    .locals 7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sget-wide v2, Lc/A8;->w:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x1388

    cmp-long v0, v0, v2

    if-ltz v0, :cond_0

    sget-object v0, Lc/A8;->t:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    sget-object p0, Lc/A8;->u:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v3

    sget-object p0, Lc/A8;->q:Ljava/util/concurrent/ExecutorService;

    new-instance v0, Lc/k1;

    const/4 v6, 0x7

    move-object v1, v0

    move-object v5, p1

    invoke-direct/range {v1 .. v6}, Lc/k1;-><init>(Ljava/lang/Object;JLjava/lang/Object;I)V

    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_0
    sget-object p0, Lc/A8;->v:Lc/A8;

    return-object p0
.end method

.method public static e(I)I
    .locals 1

    if-eqz p0, :cond_4

    const/4 v0, 0x1

    if-eq p0, v0, :cond_3

    const/4 v0, 0x2

    if-eq p0, v0, :cond_2

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1

    const/4 v0, 0x4

    if-eq p0, v0, :cond_0

    const p0, 0x7f030032

    return p0

    :cond_0
    const p0, 0x7f030031

    return p0

    :cond_1
    const p0, 0x7f030030

    return p0

    :cond_2
    const p0, 0x7f03002f

    return p0

    :cond_3
    const p0, 0x7f03002e

    return p0

    :cond_4
    const p0, 0x7f03002d

    return p0
.end method
