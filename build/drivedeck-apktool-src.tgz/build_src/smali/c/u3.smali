.class public final synthetic Lc/u3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/io/Serializable;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/Z7;Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    iput v0, p0, Lc/u3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/u3;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/u3;->d:Ljava/io/Serializable;

    iput-object p3, p0, Lc/u3;->e:Ljava/lang/Object;

    iput-boolean p4, p0, Lc/u3;->b:Z

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/io/Serializable;ZLjava/lang/Object;I)V
    .locals 0

    .line 2
    iput p5, p0, Lc/u3;->a:I

    iput-object p1, p0, Lc/u3;->c:Ljava/lang/Object;

    iput-object p2, p0, Lc/u3;->d:Ljava/io/Serializable;

    iput-boolean p3, p0, Lc/u3;->b:Z

    iput-object p4, p0, Lc/u3;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 9

    const/4 v0, 0x0

    iget-object v1, p0, Lc/u3;->c:Ljava/lang/Object;

    iget-boolean v2, p0, Lc/u3;->b:Z

    iget-object v3, p0, Lc/u3;->e:Ljava/lang/Object;

    iget-object v4, p0, Lc/u3;->d:Ljava/io/Serializable;

    iget v5, p0, Lc/u3;->a:I

    packed-switch v5, :pswitch_data_0

    check-cast v4, Ljava/lang/String;

    check-cast v3, Ljava/lang/String;

    check-cast v1, Lc/Z7;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_0
    iget-object v5, v1, Lc/Z7;->e:Lc/z7;

    invoke-virtual {v5, v4, v3, v2}, Lc/z7;->a(Ljava/lang/String;Ljava/lang/String;Z)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object v2, v1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v3, Lc/W7;

    invoke-direct {v3, v1, v4, v0}, Lc/W7;-><init>(Lc/Z7;Ljava/lang/String;I)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :catch_0
    return-void

    :pswitch_0
    sget-object v5, Lc/X3;->f:Ljava/util/HashMap;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/W3;

    if-nez v6, :cond_0

    new-instance v6, Lc/W3;

    check-cast v4, Ljava/lang/String;

    const/16 v7, 0x190

    const/16 v8, 0xf0

    invoke-static {v7, v8, v4, v2}, Lc/G8;->s(IILjava/lang/String;Z)Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-direct {v6, v2}, Lc/W3;-><init>(Landroid/graphics/Bitmap;)V

    invoke-virtual {v5, v1, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    sget-object v1, Lc/X3;->c:Landroid/os/Handler;

    new-instance v2, Lc/R3;

    check-cast v3, Ljava/util/function/Consumer;

    invoke-direct {v2, v3, v6, v0}, Lc/R3;-><init>(Ljava/util/function/Consumer;Lc/W3;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_1
    check-cast v1, Lc/Q3;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, [I

    aget v5, v4, v0

    const/4 v6, 0x1

    sub-int/2addr v5, v6

    aput v5, v4, v0

    if-eqz v5, :cond_1

    goto :goto_0

    :cond_1
    if-eqz v2, :cond_2

    iget-boolean v0, v1, Lc/Q3;->T:Z

    if-eqz v0, :cond_2

    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object v0, v1, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v0, v6}, Lc/P3;->f0(Z)V

    :cond_2
    check-cast v3, Ljava/lang/Runnable;

    if-eqz v3, :cond_3

    invoke-interface {v3}, Ljava/lang/Runnable;->run()V

    :cond_3
    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
