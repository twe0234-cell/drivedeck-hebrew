.class public final Lc/m6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:Z

.field public final e:Z

.field public final f:Ljava/lang/String;


# direct methods
.method public constructor <init>(IIZZILjava/lang/String;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-ltz p1, :cond_1

    const/16 v0, 0x2d

    if-gt p1, v0, :cond_1

    const/4 v0, 0x1

    if-lt p2, v0, :cond_1

    const/16 v0, 0x64

    if-gt p2, v0, :cond_1

    if-ltz p5, :cond_1

    iput p1, p0, Lc/m6;->a:I

    iput p2, p0, Lc/m6;->b:I

    iput-boolean p3, p0, Lc/m6;->d:Z

    iput-boolean p4, p0, Lc/m6;->e:Z

    iput p5, p0, Lc/m6;->c:I

    if-nez p6, :cond_0

    const-string p6, ""

    :cond_0
    iput-object p6, p0, Lc/m6;->f:Ljava/lang/String;

    return-void

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "Invalid search parameters"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
