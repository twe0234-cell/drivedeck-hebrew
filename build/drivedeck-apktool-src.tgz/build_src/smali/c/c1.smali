.class public final synthetic Lc/c1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/c1;->a:I

    iput-object p1, p0, Lc/c1;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/c1;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .locals 2

    iget p1, p0, Lc/c1;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/c1;->b:Ljava/lang/Object;

    check-cast p1, Lc/Q0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lc/c1;->c:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-ne v1, p1, :cond_0

    const/4 p1, 0x0

    iput-object p1, v0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    const/4 p1, 0x0

    iput-boolean p1, v0, Lru/drivedeck/launcher/MainActivity;->c0:Z

    :cond_0
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/c1;->b:Ljava/lang/Object;

    check-cast p1, Lc/O7;

    iget-object v0, p1, Lc/O7;->r:Landroid/app/Dialog;

    iget-object v1, p0, Lc/c1;->c:Ljava/lang/Object;

    check-cast v1, Landroid/app/Dialog;

    if-ne v0, v1, :cond_1

    const/4 v0, 0x0

    iput-object v0, p1, Lc/O7;->r:Landroid/app/Dialog;

    iget v0, p1, Lc/O7;->s:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p1, Lc/O7;->s:I

    :cond_1
    return-void

    :pswitch_1
    iget-object p1, p0, Lc/c1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/os/Handler;

    iget-object v0, p0, Lc/c1;->c:Ljava/lang/Object;

    check-cast v0, Lc/P1;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    return-void

    :pswitch_2
    iget-object p1, p0, Lc/c1;->b:Ljava/lang/Object;

    check-cast p1, Lc/g1;

    iget-object v0, p1, Lc/g1;->W:Landroid/app/AlertDialog;

    iget-object v1, p0, Lc/c1;->c:Ljava/lang/Object;

    check-cast v1, Landroid/app/AlertDialog;

    if-ne v0, v1, :cond_2

    const/4 v0, 0x0

    iput-object v0, p1, Lc/g1;->W:Landroid/app/AlertDialog;

    :cond_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
