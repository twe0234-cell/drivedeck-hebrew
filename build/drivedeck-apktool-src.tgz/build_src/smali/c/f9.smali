.class public final synthetic Lc/f9;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lc/g9;

.field public final synthetic b:J

.field public final synthetic c:Z

.field public final synthetic d:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Lc/g9;JZLjava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/f9;->a:Lc/g9;

    iput-wide p2, p0, Lc/f9;->b:J

    iput-boolean p4, p0, Lc/f9;->c:Z

    iput-object p5, p0, Lc/f9;->d:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    iget-object v0, p0, Lc/f9;->a:Lc/g9;

    iget-boolean v1, v0, Lc/g9;->m:Z

    if-nez v1, :cond_1

    iget-boolean v1, v0, Lc/g9;->p:Z

    if-nez v1, :cond_1

    iget-wide v1, v0, Lc/g9;->t:J

    iget-wide v3, p0, Lc/f9;->b:J

    cmp-long v1, v1, v3

    if-nez v1, :cond_1

    iget-boolean v1, p0, Lc/f9;->c:Z

    iget-object v0, v0, Lc/g9;->b:Lc/n1;

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/n1;->p0()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lc/n1;->r0()Z

    move-result v0

    if-eqz v0, :cond_1

    :goto_0
    iget-object v0, p0, Lc/f9;->d:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_1
    return-void
.end method
