.class public final synthetic Lc/B;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/F;


# direct methods
.method public synthetic constructor <init>(Lc/F;I)V
    .locals 0

    iput p2, p0, Lc/B;->a:I

    iput-object p1, p0, Lc/B;->b:Lc/F;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 1

    iget v0, p0, Lc/B;->a:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Lc/W3;

    iget-object v0, p0, Lc/B;->b:Lc/F;

    iput-object p1, v0, Lc/F;->h:Lc/W3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iget-object v0, p0, Lc/B;->b:Lc/F;

    iput-boolean p1, v0, Lc/F;->b:Z

    invoke-virtual {v0}, Lc/F;->d()V

    return-void

    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iget-object v0, p0, Lc/B;->b:Lc/F;

    iput-boolean p1, v0, Lc/F;->b:Z

    invoke-virtual {v0}, Lc/F;->d()V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
