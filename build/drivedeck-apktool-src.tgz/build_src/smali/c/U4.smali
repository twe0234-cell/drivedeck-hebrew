.class public final Lc/U4;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Z

.field public b:Z

.field public c:J

.field public d:J

.field public e:F

.field public f:F


# virtual methods
.method public final a(J)F
    .locals 2

    iget-wide v0, p0, Lc/U4;->d:J

    sub-long/2addr p1, v0

    long-to-float p1, p1

    const/high16 p2, 0x43820000    # 260.0f

    div-float/2addr p1, p2

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-static {p2, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const/4 v0, 0x0

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    sub-float p1, p2, p1

    mul-float/2addr p1, p1

    sub-float/2addr p2, p1

    iget p1, p0, Lc/U4;->e:F

    iget v0, p0, Lc/U4;->f:F

    sub-float/2addr v0, p1

    mul-float/2addr v0, p2

    add-float/2addr v0, p1

    return v0
.end method

.method public final b(J)Z
    .locals 1

    iget-boolean v0, p0, Lc/U4;->a:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0, p1, p2}, Lc/U4;->a(J)F

    move-result p1

    const p2, 0x3f7fbe77    # 0.999f

    cmpl-float p1, p1, p2

    if-ltz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method public final c()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/U4;->b:Z

    iput-boolean v0, p0, Lc/U4;->a:Z

    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lc/U4;->f:F

    iput v0, p0, Lc/U4;->e:F

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/U4;->c:J

    iput-wide v0, p0, Lc/U4;->d:J

    return-void
.end method

.method public final d(JZZ)V
    .locals 2

    if-nez p3, :cond_0

    invoke-virtual {p0}, Lc/U4;->c()V

    return-void

    :cond_0
    iget-boolean p3, p0, Lc/U4;->a:Z

    if-nez p3, :cond_1

    const/4 p3, 0x1

    iput-boolean p3, p0, Lc/U4;->a:Z

    iput-wide p1, p0, Lc/U4;->c:J

    :cond_1
    if-eqz p4, :cond_2

    iput-wide p1, p0, Lc/U4;->c:J

    goto :goto_0

    :cond_2
    iget-boolean p3, p0, Lc/U4;->b:Z

    if-eqz p3, :cond_3

    iput-wide p1, p0, Lc/U4;->c:J

    :cond_3
    :goto_0
    iput-boolean p4, p0, Lc/U4;->b:Z

    if-nez p4, :cond_5

    iget-wide p3, p0, Lc/U4;->c:J

    sub-long/2addr p1, p3

    const-wide/16 v0, 0x5dc

    cmp-long p1, p1, v0

    if-ltz p1, :cond_5

    add-long/2addr p3, v0

    iget p1, p0, Lc/U4;->f:F

    const/4 p2, 0x0

    cmpl-float p1, p1, p2

    if-nez p1, :cond_4

    goto :goto_1

    :cond_4
    invoke-virtual {p0, p3, p4}, Lc/U4;->a(J)F

    move-result p1

    iput p1, p0, Lc/U4;->e:F

    iput p2, p0, Lc/U4;->f:F

    iput-wide p3, p0, Lc/U4;->d:J

    :cond_5
    :goto_1
    return-void
.end method
