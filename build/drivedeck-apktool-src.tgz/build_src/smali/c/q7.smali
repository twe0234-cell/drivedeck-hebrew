.class public final synthetic Lc/q7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/v7;


# direct methods
.method public synthetic constructor <init>(Lc/v7;I)V
    .locals 0

    iput p2, p0, Lc/q7;->a:I

    iput-object p1, p0, Lc/q7;->b:Lc/v7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 20

    move-object/from16 v1, p0

    iget v0, v1, Lc/q7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v2, v1, Lc/q7;->b:Lc/v7;

    iget-boolean v0, v2, Lc/v7;->o:Z

    if-nez v0, :cond_6

    iget-boolean v0, v2, Lc/v7;->p:Z

    if-nez v0, :cond_6

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-wide v5, v2, Lc/v7;->I:J

    cmp-long v0, v3, v5

    if-lez v0, :cond_0

    goto/16 :goto_2

    :cond_0
    iget-object v0, v2, Lc/v7;->t:Landroid/os/Handler;

    iget-object v3, v2, Lc/v7;->H:Lc/q7;

    const-wide/16 v4, 0x3a98

    invoke-virtual {v0, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v3, v2, Lc/v7;->j:Landroid/view/SurfaceView;

    if-nez v3, :cond_1

    goto/16 :goto_2

    :cond_1
    invoke-virtual {v3}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v4

    invoke-interface {v4}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object v4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_2

    invoke-virtual {v4}, Landroid/view/Surface;->isValid()Z

    move-result v4

    if-eqz v4, :cond_2

    move v4, v5

    goto :goto_0

    :cond_2
    move v4, v6

    :goto_0
    iget-boolean v7, v2, Lc/v7;->N:Z

    iget v8, v2, Lc/v7;->b:I

    const-string v9, "pane_pixel_probe"

    if-eqz v7, :cond_5

    invoke-virtual {v2}, Landroid/view/View;->isShown()Z

    move-result v7

    if-eqz v7, :cond_5

    if-eqz v4, :cond_5

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v7

    if-lez v7, :cond_5

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v7

    if-gtz v7, :cond_3

    goto :goto_1

    :cond_3
    iget-boolean v7, v2, Lc/v7;->J:Z

    if-eqz v7, :cond_4

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v2}, Lc/v7;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    const-string v10, "renderer_id"

    const-string v12, "display_id"

    const-string v14, "result"

    const-string v15, "pending"

    filled-new-array/range {v10 .. v15}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v9, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_2

    :cond_4
    sget-object v7, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/16 v10, 0x20

    invoke-static {v10, v10, v7}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v7

    iput-boolean v5, v2, Lc/v7;->J:Z

    :try_start_0
    new-instance v5, Landroid/graphics/Rect;

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v10

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v11

    invoke-direct {v5, v6, v6, v10, v11}, Landroid/graphics/Rect;-><init>(IIII)V

    new-instance v10, Lc/s7;

    invoke-direct {v10, v2, v7, v4}, Lc/s7;-><init>(Lc/v7;Landroid/graphics/Bitmap;Z)V

    invoke-static {v3, v5, v7, v10, v0}, Landroid/view/PixelCopy;->request(Landroid/view/SurfaceView;Landroid/graphics/Rect;Landroid/graphics/Bitmap;Landroid/view/PixelCopy$OnPixelCopyFinishedListener;Landroid/os/Handler;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    iput-boolean v6, v2, Lc/v7;->J:Z

    invoke-virtual {v7}, Landroid/graphics/Bitmap;->recycle()V

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v2}, Lc/v7;->f()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v15

    const-string v10, "renderer_id"

    const-string v12, "display_id"

    const-string v14, "result"

    filled-new-array/range {v10 .. v15}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v9, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_2

    :cond_5
    :goto_1
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v2}, Lc/v7;->f()I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v2}, Landroid/view/View;->isShown()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v17

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v19

    const-string v16, "shown"

    const-string v18, "surface_valid"

    const-string v10, "renderer_id"

    const-string v12, "display_id"

    const-string v14, "result"

    const-string v15, "not_ready"

    filled-new-array/range {v10 .. v19}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v9, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_6
    :goto_2
    return-void

    :pswitch_0
    iget-object v0, v1, Lc/q7;->b:Lc/v7;

    iget-boolean v2, v0, Lc/v7;->o:Z

    if-nez v2, :cond_9

    iget-boolean v2, v0, Lc/v7;->p:Z

    if-nez v2, :cond_9

    iget-boolean v2, v0, Lc/v7;->N:Z

    if-eqz v2, :cond_9

    invoke-virtual {v0}, Lc/v7;->f()I

    move-result v2

    if-ltz v2, :cond_9

    invoke-virtual {v0}, Lc/v7;->f()I

    move-result v2

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v4

    iget v5, v0, Lc/v7;->b:I

    iget-object v6, v0, Lc/v7;->c:Ljava/lang/String;

    invoke-static {v5, v6, v2, v3, v4}, Lc/N1;->q(ILjava/lang/String;III)V

    invoke-virtual {v0}, Lc/v7;->f()I

    move-result v2

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1d

    if-lt v3, v4, :cond_8

    iget v3, v0, Lc/v7;->e:I

    if-eq v3, v2, :cond_8

    iget-boolean v3, v0, Lc/v7;->d:Z

    invoke-static {v2, v3}, Lc/j8;->f(IZ)Z

    move-result v4

    if-eqz v4, :cond_7

    iput v2, v0, Lc/v7;->e:I

    goto :goto_3

    :cond_7
    if-eqz v3, :cond_8

    const/4 v3, 0x0

    invoke-static {v2, v3}, Lc/j8;->f(IZ)Z

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v4

    const-string v5, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u044c \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0443 \u0432 \u043e\u043a\u043d\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f."

    invoke-static {v4, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-static {v3, v4, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v3

    invoke-virtual {v3}, Landroid/widget/Toast;->show()V

    iput v2, v0, Lc/v7;->e:I

    :cond_8
    :goto_3
    iget-object v2, v0, Lc/v7;->a:Lc/v8;

    iget-object v2, v2, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Lc/t2;

    invoke-virtual {v2, v0}, Lc/t2;->R(Lc/v7;)V

    :cond_9
    return-void

    :pswitch_1
    iget-object v2, v1, Lc/q7;->b:Lc/v7;

    iget-boolean v0, v2, Lc/v7;->o:Z

    if-nez v0, :cond_f

    iget-object v0, v2, Lc/v7;->l:Landroid/hardware/display/VirtualDisplay;

    if-eqz v0, :cond_f

    iget-object v0, v2, Lc/v7;->m:Landroid/view/Surface;

    if-eqz v0, :cond_f

    iget-object v0, v2, Lc/v7;->h:Landroid/view/TextureView;

    if-eqz v0, :cond_f

    iget v3, v2, Lc/v7;->C:I

    iget v4, v2, Lc/v7;->D:I

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v6

    if-lez v3, :cond_f

    if-lez v4, :cond_f

    if-ne v3, v5, :cond_f

    if-ne v4, v6, :cond_f

    iget v3, v2, Lc/v7;->x:I

    if-lez v3, :cond_a

    goto :goto_4

    :cond_a
    iget v3, v2, Lc/v7;->C:I

    :goto_4
    iget v4, v2, Lc/v7;->y:I

    if-lez v4, :cond_b

    goto :goto_5

    :cond_b
    iget v4, v2, Lc/v7;->D:I

    :goto_5
    iget v5, v2, Lc/v7;->B:I

    if-lez v5, :cond_c

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v5

    mul-int/lit16 v5, v5, 0xa0

    iget v6, v2, Lc/v7;->B:I

    div-int/2addr v5, v6

    const/4 v6, 0x1

    invoke-static {v6, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    goto :goto_6

    :cond_c
    invoke-virtual {v2}, Lc/v7;->e()I

    move-result v5

    :goto_6
    iget v6, v2, Lc/v7;->v:I

    if-ne v6, v3, :cond_d

    iget v6, v2, Lc/v7;->w:I

    if-ne v6, v4, :cond_d

    iget v6, v2, Lc/v7;->A:I

    if-ne v6, v5, :cond_d

    goto :goto_9

    :cond_d
    :try_start_1
    iput v3, v2, Lc/v7;->v:I

    iput v4, v2, Lc/v7;->w:I

    invoke-virtual {v0}, Landroid/view/TextureView;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object v0

    if-eqz v0, :cond_e

    invoke-virtual {v0, v3, v4}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    goto :goto_7

    :catch_1
    move-exception v0

    goto :goto_8

    :cond_e
    :goto_7
    iget-object v0, v2, Lc/v7;->l:Landroid/hardware/display/VirtualDisplay;

    invoke-virtual {v0, v3, v4, v5}, Landroid/hardware/display/VirtualDisplay;->resize(III)V

    iput v5, v2, Lc/v7;->A:I

    iget v0, v2, Lc/v7;->b:I

    iget-object v5, v2, Lc/v7;->c:Ljava/lang/String;

    invoke-virtual {v2}, Lc/v7;->f()I

    move-result v6

    invoke-static {v0, v5, v6, v3, v4}, Lc/N1;->q(ILjava/lang/String;III)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_9

    :goto_8
    invoke-virtual {v2, v0}, Lc/v7;->g(Ljava/lang/RuntimeException;)V

    :cond_f
    :goto_9
    return-void

    :pswitch_2
    iget-object v2, v1, Lc/q7;->b:Lc/v7;

    iget v3, v2, Lc/v7;->b:I

    iget-object v0, v2, Lc/v7;->r:Landroid/view/View;

    iget-boolean v4, v2, Lc/v7;->p:Z

    if-eqz v4, :cond_18

    if-nez v0, :cond_10

    goto/16 :goto_f

    :cond_10
    iget v4, v2, Lc/v7;->q:I

    const/4 v5, 0x1

    add-int/2addr v4, v5

    iput v4, v2, Lc/v7;->q:I

    invoke-static {v0}, Lc/v7;->b(Landroid/view/View;)Landroid/hardware/display/VirtualDisplay;

    move-result-object v4

    if-eqz v4, :cond_11

    iput-object v4, v2, Lc/v7;->s:Landroid/hardware/display/VirtualDisplay;

    :cond_11
    const/4 v4, 0x0

    :try_start_2
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const-string v7, "release"

    invoke-virtual {v6, v7, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    invoke-virtual {v6, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "activity_release_succeeded"

    const-string v6, "renderer_id"

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v8, "attempt"

    iget v9, v2, Lc/v7;->q:I

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v6, v7, v8, v9}, [Ljava/lang/Object;

    move-result-object v6

    invoke-static {v0, v6}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iput-object v4, v2, Lc/v7;->r:Landroid/view/View;

    iput-object v4, v2, Lc/v7;->s:Landroid/hardware/display/VirtualDisplay;

    invoke-virtual {v2}, Lc/v7;->i()V
    :try_end_2
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2

    goto/16 :goto_f

    :catch_2
    move-exception v0

    goto :goto_a

    :catch_3
    move-exception v0

    :goto_a
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    iget v7, v2, Lc/v7;->q:I

    const/16 v8, 0x1b

    if-eq v6, v8, :cond_12

    const/16 v8, 0x1c

    if-ne v6, v8, :cond_13

    :cond_12
    const/4 v6, 0x4

    if-ge v7, v6, :cond_13

    goto :goto_b

    :cond_13
    const/4 v5, 0x0

    :goto_b
    if-eqz v5, :cond_14

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "ActivityView release retry "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v7, v2, Lc/v7;->q:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_c

    :cond_14
    const-string v6, "ActivityView release failed after retries"

    :goto_c
    const-string v7, "DriveDeckRenderer"

    invoke-static {v7, v6, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    if-eqz v5, :cond_15

    const-string v6, "activity_release_retry"

    goto :goto_d

    :cond_15
    const-string v6, "activity_release_failed"

    :goto_d
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    iget v3, v2, Lc/v7;->q:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v13

    const-string v8, "renderer_id"

    const-string v10, "attempt"

    const-string v12, "error"

    filled-new-array/range {v8 .. v13}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v6, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    if-eqz v5, :cond_16

    iget-object v0, v2, Lc/v7;->t:Landroid/os/Handler;

    iget-object v2, v2, Lc/v7;->u:Lc/q7;

    const-wide/16 v3, 0xfa

    invoke-virtual {v0, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_f

    :cond_16
    iget-object v0, v2, Lc/v7;->s:Landroid/hardware/display/VirtualDisplay;

    if-eqz v0, :cond_17

    :try_start_3
    invoke-virtual {v0}, Landroid/hardware/display/VirtualDisplay;->release()V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_4

    goto :goto_e

    :catch_4
    move-exception v0

    move-object v3, v0

    const-string v0, "VirtualDisplay release failed"

    invoke-static {v7, v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_17
    :goto_e
    iput-object v4, v2, Lc/v7;->r:Landroid/view/View;

    iput-object v4, v2, Lc/v7;->s:Landroid/hardware/display/VirtualDisplay;

    invoke-virtual {v2}, Lc/v7;->i()V

    :cond_18
    :goto_f
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
