.class public final synthetic Lc/d4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/BooleanSupplier;


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic b:I

.field public final synthetic c:J

.field public final synthetic d:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;IJLjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/d4;->a:Landroid/content/Context;

    iput p2, p0, Lc/d4;->b:I

    iput-wide p3, p0, Lc/d4;->c:J

    iput-object p5, p0, Lc/d4;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final getAsBoolean()Z
    .locals 6

    new-instance v0, Lc/n1;

    iget-object v1, p0, Lc/d4;->a:Landroid/content/Context;

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    sget v2, Lc/G8;->B:I

    iget v3, p0, Lc/d4;->b:I

    if-ne v3, v2, :cond_0

    invoke-virtual {v0}, Lc/n1;->t0()J

    move-result-wide v2

    iget-wide v4, p0, Lc/d4;->c:J

    cmp-long v2, v4, v2

    if-nez v2, :cond_0

    invoke-static {v1, v0}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/d4;->d:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
