.class public final synthetic Lc/G5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/T5;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Exception;


# direct methods
.method public synthetic constructor <init>(Lc/T5;ILjava/lang/Exception;I)V
    .locals 0

    iput p4, p0, Lc/G5;->a:I

    iput-object p1, p0, Lc/G5;->b:Lc/T5;

    iput p2, p0, Lc/G5;->c:I

    iput-object p3, p0, Lc/G5;->d:Ljava/lang/Exception;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/G5;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/G5;->b:Lc/T5;

    iget v1, p0, Lc/G5;->c:I

    iget-object v2, p0, Lc/G5;->d:Ljava/lang/Exception;

    iget v3, v0, Lc/T5;->t:I

    if-ne v1, v3, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "\u0421\u0432\u044f\u0437\u044c USB \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->Q0(Ljava/lang/String;)V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/G5;->b:Lc/T5;

    iget v1, p0, Lc/G5;->c:I

    iget-object v2, p0, Lc/G5;->d:Ljava/lang/Exception;

    iget v3, v0, Lc/T5;->t:I

    if-ne v1, v3, :cond_1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "\u0421\u0432\u044f\u0437\u044c Wi-Fi \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->Q0(Ljava/lang/String;)V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
