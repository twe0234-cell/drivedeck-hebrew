.class public final Lc/z1;
.super Ljava/io/IOException;
.source "SourceFile"


# instance fields
.field public final a:I


# direct methods
.method public constructor <init>(I)V
    .locals 1

    const-string v0, "VK relay HTTP "

    invoke-static {v0, p1}, Lcom/hoho/android/usbserial/driver/a;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    iput p1, p0, Lc/z1;->a:I

    return-void
.end method
