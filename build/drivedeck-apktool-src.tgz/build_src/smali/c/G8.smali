.class public abstract Lc/G8;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static A:I

.field public static B:I

.field public static C:Ljava/lang/String;

.field public static D:Landroid/hardware/display/VirtualDisplay;

.field public static volatile a:Ljava/lang/String;

.field public static volatile b:[Ljava/lang/String;

.field public static volatile c:[Ljava/lang/String;

.field public static volatile d:[Ljava/lang/String;

.field public static volatile e:[Ljava/lang/String;

.field public static volatile f:[Ljava/lang/String;

.field public static volatile g:[Ljava/lang/String;

.field public static volatile h:[Ljava/lang/String;

.field public static volatile i:[Ljava/lang/String;

.field public static volatile j:[Ljava/lang/String;

.field public static volatile k:[Ljava/lang/String;

.field public static volatile l:[Ljava/lang/String;

.field public static volatile m:[[Ljava/lang/String;

.field public static volatile n:[Ljava/lang/String;

.field public static volatile o:[I

.field public static final p:[[Ljava/lang/String;

.field public static final q:[Ljava/lang/String;

.field public static final r:[[I

.field public static final s:Lc/v5;

.field public static final t:Lc/v5;

.field public static final u:Lc/v5;

.field public static final v:Lc/v5;

.field public static final w:Ljava/lang/Object;

.field public static final x:[Ljava/lang/String;

.field public static final y:[Ljava/lang/String;

.field public static z:Z


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 17

    const-string v0, " \u00b7 \u0160R"

    const-string v1, " \u00b7 \u6771\u5317"

    const-string v2, " \u00b7 \u0421\u0412"

    const-string v3, " \u00b7 NE"

    filled-new-array {v2, v3, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v4

    const-string v0, " \u00b7 \u0160V"

    const-string v1, " \u00b7 \u897f\u5317"

    const-string v2, " \u00b7 \u0421\u0417"

    const-string v3, " \u00b7 NW"

    const-string v5, " \u00b7 NO"

    filled-new-array {v2, v3, v5, v0, v1}, [Ljava/lang/String;

    move-result-object v5

    const-string v0, " \u00b7 PR"

    const-string v1, " \u00b7 \u6771\u5357"

    const-string v2, " \u00b7 \u042e\u0412"

    const-string v3, " \u00b7 SE"

    filled-new-array {v2, v3, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v6

    const-string v0, " \u00b7 PV"

    const-string v1, " \u00b7 \u897f\u5357"

    const-string v2, " \u00b7 \u042e\u0417"

    const-string v3, " \u00b7 SW"

    const-string v7, " \u00b7 SO"

    filled-new-array {v2, v3, v7, v0, v1}, [Ljava/lang/String;

    move-result-object v7

    const-string v0, " \u00b7 \u0160"

    const-string v1, " \u00b7 \u5317"

    const-string v2, " \u00b7 \u0421"

    const-string v3, " \u00b7 N"

    filled-new-array {v2, v3, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v8

    const-string v0, " \u00b7 P"

    const-string v1, " \u00b7 \u5357"

    const-string v2, " \u00b7 \u042e"

    const-string v3, " \u00b7 S"

    filled-new-array {v2, v3, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v9

    const-string v0, " \u00b7 R"

    const-string v1, " \u00b7 \u6771"

    const-string v2, " \u00b7 \u0412"

    const-string v3, " \u00b7 E"

    filled-new-array {v2, v3, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v10

    const-string v0, " \u00b7 V"

    const-string v1, " \u00b7 \u897f"

    const-string v2, " \u00b7 \u0417"

    const-string v3, " \u00b7 W"

    const-string v11, " \u00b7 O"

    filled-new-array {v2, v3, v11, v0, v1}, [Ljava/lang/String;

    move-result-object v11

    filled-new-array/range {v4 .. v11}, [[Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/G8;->p:[[Ljava/lang/String;

    const-string v0, "window_renderer"

    const-string v1, "home_app"

    const-string v2, "slot_0"

    const-string v3, "slot_1"

    const-string v4, "dashboard_mode"

    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/G8;->q:[Ljava/lang/String;

    const v0, -0x101009e

    filled-new-array {v0}, [I

    move-result-object v0

    const v1, 0x10100a0

    filled-new-array {v1}, [I

    move-result-object v1

    const/4 v2, 0x0

    new-array v2, v2, [I

    filled-new-array {v0, v1, v2}, [[I

    move-result-object v0

    sput-object v0, Lc/G8;->r:[[I

    new-instance v0, Lc/v5;

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v2, "816"

    const/4 v3, 0x2

    const/16 v4, 0x14

    const-wide/high16 v7, 0x3ff0000000000000L    # 1.0

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, Lc/v5;-><init>(Ljava/lang/String;IIIID)V

    sput-object v0, Lc/G8;->s:Lc/v5;

    new-instance v0, Lc/v5;

    const/4 v13, 0x0

    const/4 v14, 0x2

    const-string v10, "824"

    const/4 v3, 0x1

    const/16 v12, 0xa

    const-wide v15, 0x3f50624dd2f1a9fcL    # 0.001

    move-object v9, v0

    move v11, v3

    invoke-direct/range {v9 .. v16}, Lc/v5;-><init>(Ljava/lang/String;IIIID)V

    sput-object v0, Lc/G8;->t:Lc/v5;

    new-instance v0, Lc/v5;

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v2, "825"

    const/16 v4, 0xa

    const-wide v7, 0x3f50624dd2f1a9fcL    # 0.001

    move-object v1, v0

    invoke-direct/range {v1 .. v8}, Lc/v5;-><init>(Ljava/lang/String;IIIID)V

    sput-object v0, Lc/G8;->u:Lc/v5;

    new-instance v0, Lc/v5;

    const/4 v14, 0x1

    const-string v10, "13"

    const/4 v11, 0x3

    const/4 v12, 0x1

    const-wide/high16 v15, 0x3ff0000000000000L    # 1.0

    move-object v9, v0

    invoke-direct/range {v9 .. v16}, Lc/v5;-><init>(Ljava/lang/String;IIIID)V

    sput-object v0, Lc/G8;->v:Lc/v5;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lc/G8;->w:Ljava/lang/Object;

    const-string v0, "lagoon_fjord"

    const-string v1, "sand_twilight"

    const-string v2, "mist_cosmos"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/G8;->x:[Ljava/lang/String;

    const-string v0, "\u041b\u0430\u0433\u0443\u043d\u0430 / \u0424\u044c\u043e\u0440\u0434"

    const-string v1, "\u041f\u0435\u0441\u043e\u043a / \u0421\u0443\u043c\u0435\u0440\u043a\u0438"

    const-string v2, "\u0422\u0443\u043c\u0430\u043d / \u041a\u043e\u0441\u043c\u043e\u0441"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lc/G8;->y:[Ljava/lang/String;

    return-void
.end method

.method public static A(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 14

    const-string v0, "en"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "[+-]?\\d+(?:[.,]\\d+)?\\s*(?:\u043a\u043c|\u043c)"

    invoke-virtual {p0, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    const-string v3, "zh-TW"

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_4

    const-string v0, "\u043a\u043c"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v4

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    sub-int/2addr v2, v5

    :goto_0
    invoke-virtual {p0, v6, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v1, :cond_1

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    :cond_1
    const/16 p1, 0x2c

    const/16 v1, 0x2e

    invoke-virtual {v2, p1, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v2

    :cond_2
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_3

    const-string p0, "km"

    goto :goto_1

    :cond_3
    const-string p0, "m"

    :goto_1
    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_4
    const-string v1, "\u041e\u0449\u0443\u0449\u0430\u0435\u0442\u0441\u044f \u043a\u0430\u043a "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/16 v2, 0xe

    if-eqz v1, :cond_5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Temperatura percepita: "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5
    const-string v1, "\u041e\u0449\u0443\u0449\u0430\u0435\u0442\u0441\u044f "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/16 v7, 0xa

    if-eqz v1, :cond_6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Percepita: "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_6
    const-string v1, "\u041e\u0449. "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x4

    if-eqz v1, :cond_7

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Si sente "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_7
    const-string v1, "\u0414\u0430\u0432\u043b. "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x6

    if-eqz v1, :cond_8

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Pressione "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_8
    const-string v1, "\u0412\u043b. "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const-string v10, "Umidit\u00e0 "

    if-eqz v1, :cond_9

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1, v10}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_9
    const-string v1, "\u0412\u043b\u0430\u0436\u043d\u043e\u0441\u0442\u044c "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_a

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1, v10}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_a
    const-string v1, "\u042f\u043d\u0434\u0435\u043a\u0441 \u0414\u0438\u0441\u043a: HTTP "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Yandex Disk: HTTP "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x12

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_b
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u043b\u0443\u0447\u0438\u0442\u044c \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043d\u0438 \u0438\u0437 Object Storage, \u043d\u0438 \u0441 \u042f\u043d\u0434\u0435\u043a\u0441 \u0414\u0438\u0441\u043a\u0430."

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Impossibile recuperare l\'aggiornamento da Object Storage o Yandex Disk."

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x47

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const-string v1, "Controlla la tua connessione Internet."

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443."

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "Prima fonte:"

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\u041f\u0435\u0440\u0432\u044b\u0439 \u0438\u0441\u0442\u043e\u0447\u043d\u0438\u043a:"

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "; secondo:"

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "; \u0432\u0442\u043e\u0440\u043e\u0439:"

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_c
    const-string v1, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430\u2026 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_d

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Download in corso\u2026 "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_d
    const-string v1, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f\u2026 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/16 v10, 0x15

    if-eqz v1, :cond_e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Download dell\'aggiornamento\u2026 "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_e
    const-string v1, "\u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_f

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Aggiornamento non installato"

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x19

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_f
    const-string v1, "\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u0430 \u043d\u043e\u0432\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f DriveDeck "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u00c8 disponibile una nuova versione di DriveDeck: "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x20

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_10
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0431\u043d\u043e\u0432\u0438\u0442\u044c: "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_11

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Impossibile aggiornare: "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_11
    const-string v1, "\u0421\u0431\u043e\u0440 \u0432\u043a\u043b\u044e\u0447\u0451\u043d, \u043e\u0441\u0442\u0430\u043b\u043e\u0441\u044c \u043e\u043a\u043e\u043b\u043e "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Raccolta abilitata, circa "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x1d

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_12
    const-string v1, "\u0428\u0438\u0440\u0438\u043d\u0430 \u0440\u0430\u0441\u0442\u0443\u0448\u0451\u0432\u043a\u0438 \u2014 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_13

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Larghezza della dissolvenza del bordo \u2014 "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x14

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_13
    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0433\u043e \u2014 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_14

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Scala del contenuto \u2014 "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x16

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_14
    const-string v1, "\u041e\u0411\u0423\u0427\u0415\u041d\u0418\u0415 \u00b7 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_15

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "GUIDA \u00b7 "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0xb

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const-string p1, " \u0418\u0417 "

    const-string v1, " / "

    invoke-virtual {p0, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_15
    const-string v1, "\u042d\u0442\u0430\u043f "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    const-string v11, "Fase "

    const/4 v12, 0x5

    if-eqz v10, :cond_16

    const-string v10, ": \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 "

    invoke-virtual {p0, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_16

    invoke-virtual {p0, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p1, v11}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": preparare "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v10, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v1, " secondi, quindi "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, " \u0441\u0435\u043a\u0443\u043d\u0434, \u0437\u0430\u0442\u0435\u043c "

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v1, " minuti. Non cambiare lo schermo."

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, " \u043c\u0438\u043d\u0443\u0442\u044b. \u041d\u0435 \u043c\u0435\u043d\u044f\u0439\u0442\u0435 \u044d\u043a\u0440\u0430\u043d."

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_16
    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_17

    invoke-static {p1, v11}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Carte senza app"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u041a\u0430\u0440\u0442\u043e\u0447\u043a\u0438 \u0431\u0435\u0437 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Solo musica"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u0422\u043e\u043b\u044c\u043a\u043e \u043c\u0443\u0437\u044b\u043a\u0430"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Solo navigatore"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u0422\u043e\u043b\u044c\u043a\u043e \u041d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Due finestre"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\u0414\u0432\u0430 \u043e\u043a\u043d\u0430"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " completato"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " \u2014 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043d"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " \u2014 interrotto; ripetere la fase"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " \u2014 \u043f\u0440\u0435\u0440\u0432\u0430\u043d, \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u044d\u0442\u0430\u043f"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " \u2014 la riproduzione non \u00e8 stata confermata. Apri il lettore selezionato, avvia una traccia e ripeti il \u200b\u200btest."

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, " \u2014 \u043f\u043b\u0435\u0435\u0440 \u043d\u0435 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043b \u0432\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432\u0435\u0434\u0435\u043d\u0438\u0435. \u041e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043f\u043b\u0435\u0435\u0440, \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u0435 \u0442\u0440\u0435\u043a \u0438 \u043f\u043e\u0432\u0442\u043e\u0440\u0438\u0442\u0435 \u0442\u0435\u0441\u0442."

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\nPreparazione: "

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\n\u041f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430: "

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "Misura: "

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "\n\u0418\u0437\u043c\u0435\u0440\u0435\u043d\u0438\u0435: "

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, " s"

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, " \u0441"

    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_17
    const-string v1, "\u0412\u0435\u0442\u0435\u0440 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const-string v10, "vi"

    const/16 v11, 0x8

    if-eqz v1, :cond_1d

    invoke-virtual {p0, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const-string v1, " \u043c/\u0441"

    const-string v2, " m/s"

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_18

    move v4, v8

    goto :goto_2

    :cond_18
    const-string v1, "lt"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_19

    const/4 v4, 0x3

    goto :goto_2

    :cond_19
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1a

    invoke-virtual {v10, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    :cond_1a
    move v4, v5

    :cond_1b
    :goto_2
    sget-object v0, Lc/G8;->p:[[Ljava/lang/String;

    move v1, v6

    :goto_3
    if-ge v1, v11, :cond_1c

    aget-object v2, v0, v1

    aget-object v3, v2, v6

    aget-object v2, v2, v4

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    add-int/lit8 v1, v1, 0x1

    goto :goto_3

    :cond_1c
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Vento "

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1d
    const-string v1, " \u041c\u0413\u0446"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1e

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v8

    invoke-virtual {p0, v6, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " MHz"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1e
    const-string v1, " \u043a\u0413\u0446"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1f

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v8

    invoke-virtual {p0, v6, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " kHz"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1f
    const-string v1, ", \u0432\u044b\u0431\u0440\u0430\u043d\u043e \u0434\u043b\u044f \u0440\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_20

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x1c

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", selezionato per la modifica"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_20
    const-string v1, ", \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u0434\u043e\u043a"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_21

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x10

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", aggiungi al dock"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_21
    const-string v1, ", \u043f\u043e\u043a\u0430\u0437\u0430\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_22

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v7

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", mostrato"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_22
    const-string v1, ", \u0441\u043a\u0440\u044b\u0442\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_23

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v11

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", nascosto"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_23
    const-string v1, ", \u0443\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0434\u043e\u043a\u0430"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_24

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x10

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", rimuovere dal dock"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_24
    const-string v1, " \u00b7 \u043d\u0435 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_25

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v2

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " \u00b7 non aggiunto"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_25
    const-string v1, " \u00b7 \u0441\u043a\u0440\u044b\u0442"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_26

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v11

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " \u00b7 nascosto"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_26
    const-string v1, "\u2039 \u0413\u043b\u0430\u0432\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_27

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u2039 Casa"

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0xf

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_27
    const-string v1, "+ \u041d\u043e\u0432\u0430\u044f \u043f\u0430\u0440\u0430"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_28

    const-string p0, "+ Nuova coppia"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_28
    const-string v1, "\u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_29

    const-string p0, "non selezionato"

    invoke-static {p1, p0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_29
    const-string v1, " \u043c\u0438\u043d."

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2a

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    sub-int/2addr v0, v12

    invoke-virtual {p0, v6, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " min"

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2a
    const-string v1, " \u0441\u0442\u043e\u043b\u0431\u0435\u0446 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2b

    const-string v0, " colonna "

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2b
    const-string v1, ", \u0441\u0442\u0440\u043e\u043a\u0430 "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2c

    const-string v0, ", riga "

    invoke-static {p1, v0}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2c
    const-string v1, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    const-string v2, ", selezionato"

    if-eqz v1, :cond_2d

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    sub-int/2addr v1, v11

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1, v2}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2d
    const-string v1, ", \u0432\u044b\u0431\u0440\u0430\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2e

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x9

    invoke-virtual {p0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1, v2}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2e
    const-string v1, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c "

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2f

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Opacit\u00e0"

    invoke-static {p1, v1}, Lc/G8;->b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0xd

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2f
    const-string v1, "\u0412 \u043e\u0447\u0435\u0440\u0435\u0434\u0438:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u0421\u0431\u043e\u0440 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u0421\u0431\u043e\u0440 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u0421\u0440\u043e\u043a \u0434\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0451\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u041e\u0442\u0447\u0451\u0442\u044b"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u043f\u0440\u0438\u0451\u043c\u043d\u0438\u043a \u043d\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u041e\u0448\u0438\u0431\u043a\u0430 \u0441\u0431\u043e\u0440\u0430:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u041e\u0448\u0438\u0431\u043a\u0430 \u0437\u0430\u043f\u0438\u0441\u0438:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043f\u0440\u043e\u0441\u0440\u043e\u0447\u0435\u043d\u043e"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u0417\u0430\u043f\u0438\u0441\u044c \u043d\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_31

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u044c:"

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_30

    goto :goto_4

    :cond_30
    const/4 p0, 0x0

    return-object p0

    :cond_31
    :goto_4
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    sget-object p1, Lc/G8;->m:[[Ljava/lang/String;

    aget-object p1, p1, v6

    goto :goto_5

    :cond_32
    const-string v0, "es"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_33

    sget-object p1, Lc/G8;->m:[[Ljava/lang/String;

    aget-object p1, p1, v5

    goto :goto_5

    :cond_33
    invoke-virtual {v10, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_34

    sget-object p1, Lc/G8;->m:[[Ljava/lang/String;

    aget-object p1, p1, v4

    goto :goto_5

    :cond_34
    sget-object p1, Lc/G8;->k:[Ljava/lang/String;

    :goto_5
    sget-object v0, Lc/G8;->n:[Ljava/lang/String;

    array-length v0, v0

    if-ge v6, v0, :cond_35

    sget-object v0, Lc/G8;->n:[Ljava/lang/String;

    aget-object v0, v0, v6

    sget-object v1, Lc/G8;->o:[I

    aget v1, v1, v6

    aget-object v1, p1, v1

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    :cond_35
    return-object p0
.end method

.method public static A0(Ljava/lang/String;I)I
    .locals 3

    invoke-static {p0}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v0

    const/16 v1, 0x64

    if-nez v0, :cond_0

    return v1

    :cond_0
    const-string v0, "\\|"

    const/4 v2, -0x1

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    array-length v0, p0

    if-gt v0, p1, :cond_1

    return v1

    :cond_1
    :try_start_0
    aget-object p0, p0, p1

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/16 p1, 0x78

    invoke-static {p1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/16 p1, 0x32

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    return v1
.end method

.method public static B(Lc/u0;)Ljava/lang/String;
    .locals 6

    :try_start_0
    invoke-static {p0}, Lc/u0;->r(Lc/u0;)Lc/u0;

    move-result-object p0

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "version"

    const/16 v2, 0xb

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "edge"

    iget-object v2, p0, Lc/u0;->b:Ljava/lang/Object;

    check-cast v2, Lc/Q1;

    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "clock"

    iget-object v2, p0, Lc/u0;->c:Ljava/lang/Object;

    check-cast v2, Lc/q0;

    invoke-virtual {v2}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "gridRows"

    iget v2, p0, Lc/u0;->a:I

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    iget-object p0, p0, Lc/u0;->d:Ljava/lang/Object;

    check-cast p0, Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/r0;

    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const-string v4, "kind"

    iget-object v5, v2, Lc/r0;->a:Lc/s0;

    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "size"

    iget-object v5, v2, Lc/r0;->b:Lc/t0;

    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "column"

    iget v5, v2, Lc/r0;->c:I

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "row"

    iget v5, v2, Lc/r0;->d:I

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "hidden"

    iget-boolean v5, v2, Lc/r0;->g:Z

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "columns"

    iget v5, v2, Lc/r0;->e:I

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v3

    const-string v4, "rows"

    iget v5, v2, Lc/r0;->f:I

    invoke-virtual {v3, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v3

    iget-object v4, v2, Lc/r0;->a:Lc/s0;

    sget-object v5, Lc/s0;->i:Lc/s0;

    if-ne v4, v5, :cond_0

    const-string v4, "legacyWindow"

    iget-boolean v2, v2, Lc/r0;->h:Z

    invoke-virtual {v3, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    goto :goto_1

    :catch_0
    move-exception p0

    goto :goto_2

    :cond_0
    :goto_1
    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_0

    :cond_1
    const-string p0, "widgets"

    invoke-virtual {v0, p0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object p0

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :goto_2
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static B0(Landroid/widget/TextView;Lc/r4;Z)V
    .locals 3

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-static {p0, p1, p2}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    if-nez p2, :cond_0

    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const v0, 0x461c4000    # 10000.0f

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {p2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p2

    invoke-direct {v0, p2, p1, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    return-void
.end method

.method public static C()Ljava/net/URI;
    .locals 4

    new-instance v0, Ljava/net/URI;

    const-string v1, "https://functions.yandexcloud.net/d4e51f98772o7qcdhvfe"

    invoke-direct {v0, v1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v1

    const-string v2, "https"

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Ljava/net/URI;->getRawUserInfo()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    invoke-virtual {v0}, Ljava/net/URI;->getRawFragment()Ljava/lang/String;

    move-result-object v2

    if-nez v2, :cond_1

    invoke-virtual {v0}, Ljava/net/URI;->getPort()I

    move-result v2

    const/4 v3, -0x1

    if-eq v2, v3, :cond_0

    invoke-virtual {v0}, Ljava/net/URI;->getPort()I

    move-result v2

    const/16 v3, 0x1bb

    if-ne v2, v3, :cond_1

    :cond_0
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, ".yandexcloud.net"

    invoke-virtual {v1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    return-object v0

    :cond_1
    new-instance v0, Ljava/lang/SecurityException;

    const-string v1, "Untrusted diagnostic relay"

    invoke-direct {v0, v1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static C0(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lc/I6;ZZ)Lc/R1;
    .locals 17

    move-object/from16 v0, p3

    move-object/from16 v8, p4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static/range {p1 .. p1}, Lc/k6;->I(I)I

    move-result v1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, v2, :cond_0

    move v1, v3

    goto :goto_0

    :cond_0
    move v1, v10

    :goto_0
    const/4 v11, 0x0

    move-object/from16 v2, p0

    move/from16 v4, p1

    invoke-static {v2, v4, v1, v11, v11}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object v12

    const/4 v1, 0x4

    iget v2, v8, Lc/I6;->a:I

    if-eq v2, v3, :cond_1

    if-ne v2, v1, :cond_2

    :cond_1
    move-object/from16 v13, p2

    goto :goto_1

    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "CAN selector requires resolved CAN framing"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_1
    invoke-static {v13, v8}, Lc/k6;->R(Ljava/lang/String;Lc/I6;)[B

    move-result-object v14

    if-nez v0, :cond_3

    const-string v0, ""

    goto :goto_2

    :cond_3
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    :goto_2
    invoke-static {v0, v8}, Lc/G8;->E(Ljava/lang/String;Lc/I6;)Ljava/lang/String;

    move-result-object v15

    if-ne v2, v1, :cond_4

    const-string v0, "??"

    invoke-virtual {v15, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    move/from16 v16, v10

    goto :goto_3

    :cond_4
    move/from16 v16, v9

    :goto_3
    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v0, v12

    move-object/from16 v1, p2

    move-object v2, v15

    move-object v3, v14

    move-object/from16 v4, p4

    move/from16 v7, v16

    invoke-static/range {v0 .. v7}, Lc/G8;->H(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;[BLc/I6;ZZZ)Lc/R1;

    move-result-object v0

    if-eqz v0, :cond_5

    :goto_4
    move-object v11, v0

    goto/16 :goto_6

    :cond_5
    if-eqz p6, :cond_6

    array-length v0, v14

    if-le v0, v10, :cond_6

    if-nez v16, :cond_6

    aget-byte v0, v14, v9

    new-array v3, v10, [B

    aput-byte v0, v3, v9

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v0, v12

    move-object/from16 v1, p2

    move-object v2, v15

    move-object/from16 v4, p4

    invoke-static/range {v0 .. v7}, Lc/G8;->H(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;[BLc/I6;ZZZ)Lc/R1;

    move-result-object v0

    if-eqz v0, :cond_6

    goto :goto_4

    :cond_6
    if-eqz p5, :cond_7

    goto :goto_6

    :cond_7
    new-instance v0, Ljava/util/TreeSet;

    invoke-direct {v0}, Ljava/util/TreeSet;-><init>()V

    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_8
    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_9

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/n7;

    invoke-static {v2, v14}, Lc/G8;->S(Lc/n7;[B)Z

    move-result v3

    if-eqz v3, :cond_8

    iget-object v2, v2, Lc/n7;->a:Ljava/lang/String;

    invoke-static {v2, v8}, Lc/G8;->E(Ljava/lang/String;Lc/I6;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_8

    invoke-virtual {v0, v2}, Ljava/util/TreeSet;->add(Ljava/lang/Object;)Z

    goto :goto_5

    :cond_9
    invoke-virtual {v0}, Ljava/util/TreeSet;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_6

    :cond_a
    invoke-virtual {v0}, Ljava/util/TreeSet;->first()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    move-object v0, v12

    move-object/from16 v1, p2

    move-object v3, v14

    move-object/from16 v4, p4

    invoke-static/range {v0 .. v7}, Lc/G8;->H(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;[BLc/I6;ZZZ)Lc/R1;

    move-result-object v11

    :goto_6
    return-object v11
.end method

.method public static D()Ljava/net/URI;
    .locals 5

    new-instance v0, Ljava/net/URI;

    const-string v1, ""

    invoke-direct {v0, v1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v2

    const-string v3, "https"

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2

    if-eqz v2, :cond_2

    invoke-virtual {v0}, Ljava/net/URI;->getRawUserInfo()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/net/URI;->getRawFragment()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_2

    invoke-virtual {v0}, Ljava/net/URI;->getPort()I

    move-result v3

    const/4 v4, -0x1

    if-eq v3, v4, :cond_0

    invoke-virtual {v0}, Ljava/net/URI;->getPort()I

    move-result v3

    const/16 v4, 0x1bb

    if-ne v3, v4, :cond_2

    :cond_0
    const-string v3, "(?i)(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}"

    invoke-virtual {v1, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v2, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    :goto_0
    if-eqz v1, :cond_2

    return-object v0

    :cond_2
    new-instance v0, Ljava/lang/SecurityException;

    const-string v1, "Untrusted VK diagnostic relay"

    invoke-direct {v0, v1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static D0(Landroid/content/Context;Ljava/lang/String;I)Z
    .locals 5

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.MEDIA_BUTTON"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/16 v1, 0x20

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/content/pm/PackageManager;->queryBroadcastReceivers(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/pm/ResolveInfo;

    iget-object v4, v3, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-eqz v4, :cond_0

    iget-boolean v4, v4, Landroid/content/pm/ActivityInfo;->exported:Z

    if-nez v4, :cond_1

    goto :goto_0

    :cond_1
    new-instance v1, Landroid/content/ComponentName;

    iget-object v2, v3, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, v2, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {v1, p1, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    new-instance v1, Lc/x;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v0, p2, v2}, Lc/x;-><init>(Ljava/lang/Object;Ljava/lang/Object;II)V

    const/16 v0, 0x7e

    if-ne p2, v0, :cond_2

    invoke-static {p0, p1, v1}, Lc/G8;->X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V

    goto :goto_1

    :cond_2
    invoke-virtual {v1}, Lc/x;->run()V

    :goto_1
    const/4 p0, 0x1

    return p0

    :cond_3
    return v2
.end method

.method public static E(Ljava/lang/String;Lc/I6;)Ljava/lang/String;
    .locals 1

    iget p1, p1, Lc/I6;->a:I

    const/4 v0, 0x4

    if-ne p1, v0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    const/16 v0, 0x8

    if-ne p1, v0, :cond_0

    const/4 p1, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    :cond_0
    return-object p0
.end method

.method public static E0([B)Ljava/lang/String;
    .locals 6

    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    aget-byte v3, p0, v2

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    and-int/lit16 v3, v3, 0xff

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "%02x"

    invoke-static {v4, v5, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static F(Ljava/lang/String;)Lc/v5;
    .locals 1

    const-string v0, "816"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    sget-object p0, Lc/G8;->s:Lc/v5;

    return-object p0

    :cond_0
    const-string v0, "824"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object p0, Lc/G8;->t:Lc/v5;

    return-object p0

    :cond_1
    const-string v0, "825"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object p0, Lc/G8;->u:Lc/v5;

    return-object p0

    :cond_2
    const-string v0, "13"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    sget-object p0, Lc/G8;->v:Lc/v5;

    return-object p0

    :cond_3
    const/4 p0, 0x0

    return-object p0
.end method

.method public static F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    int-to-float p1, p2

    invoke-static {p0, p1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public static G(Landroid/app/Activity;Landroid/view/View;)V
    .locals 6

    instance-of v0, p1, Landroid/view/ViewGroup;

    if-nez v0, :cond_0

    return-void

    :cond_0
    move-object v0, p1

    check-cast v0, Landroid/view/ViewGroup;

    const-string v1, "widget-settings-card"

    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    instance-of p1, p1, Landroid/widget/LinearLayout;

    if-eqz p1, :cond_2

    const/4 p1, 0x1

    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge p1, v1, :cond_2

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout$LayoutParams;

    add-int/lit8 v4, p1, -0x1

    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout$LayoutParams;

    instance-of v1, v1, Landroid/widget/SeekBar;

    if-eqz v1, :cond_1

    move v1, v2

    goto :goto_1

    :cond_1
    const/high16 v1, 0x41800000    # 16.0f

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    :goto_1
    iget v5, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget v4, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    sub-int/2addr v1, v4

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_2
    :goto_2
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    if-ge v2, p1, :cond_3

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    invoke-static {p0, p1}, Lc/G8;->G(Landroid/app/Activity;Landroid/view/View;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_3
    return-void
.end method

.method public static G0(Lru/drivedeck/launcher/MainActivity;Ljava/util/function/BooleanSupplier;)Landroid/app/Dialog;
    .locals 38

    move-object/from16 v9, p0

    move-object/from16 v15, p1

    const/4 v13, 0x0

    const/4 v12, 0x1

    new-instance v11, Lc/n1;

    invoke-direct {v11, v9}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static/range {p0 .. p0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v10

    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v8

    new-instance v7, Landroid/app/Dialog;

    invoke-direct {v7, v9}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static/range {p0 .. p0}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v6

    const-string v0, "\u0412\u0438\u0434 \u043f\u043e\u043a\u0430\u0437\u0430\u043d\u0438\u0439"

    invoke-static {v9, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "obd_widget_compact_readings"

    iget-object v2, v11, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2, v1, v13}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    const-string v2, "\u0418\u043a\u043e\u043d\u043a\u0438 \u0432\u043c\u0435\u0441\u0442\u043e \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0439"

    invoke-static {v9, v2, v1}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v1

    new-instance v2, Lc/i0;

    invoke-direct {v2, v11, v15, v12}, Lc/i0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v9, v6, v0}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v0, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438"

    invoke-static {v9, v0}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v5

    iget v0, v8, Lc/r4;->e:I

    const-string v1, "\u041f\u0440\u0438 \u0441\u0436\u0430\u0442\u0438\u0438 \u0440\u0430\u043c\u043a\u0438 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0443\u043c\u0435\u043d\u044c\u0448\u0430\u044e\u0442\u0441\u044f \u0434\u043e 25%, \u043f\u0440\u0438 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043d\u0438\u0438 \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u044e\u0442\u0441\u044f \u043a \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u043c\u0443 \u043c\u0430\u0441\u0448\u0442\u0430\u0431\u0443. \u041f\u0435\u0440\u0435\u0442\u0430\u0441\u043a\u0438\u0432\u0430\u0439\u0442\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u0434\u043b\u044f \u0438\u0437\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043f\u043e\u0440\u044f\u0434\u043a\u0430; \u0443\u0433\u043b\u043e\u0432\u0430\u044f \u0440\u0443\u0447\u043a\u0430 \u043c\u0435\u043d\u044f\u0435\u0442 \u0438\u0445 \u0438\u0441\u0445\u043e\u0434\u043d\u044b\u0439 \u0440\u0430\u0437\u043c\u0435\u0440."

    const/16 v4, 0xe

    invoke-static {v9, v1, v4, v13, v0}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v0

    sget-object v3, Lc/G8;->w:Ljava/lang/Object;

    invoke-virtual {v0, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v5, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    iget-object v2, v10, Lc/T5;->g:Lc/j6;

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v4, Ljava/util/LinkedHashMap;

    invoke-direct {v4}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v14

    array-length v13, v14

    const/4 v12, 0x0

    :goto_0
    if-ge v12, v13, :cond_0

    move-object/from16 v20, v3

    aget-object v3, v14, v12

    move-object/from16 v21, v6

    invoke-virtual {v3}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v6

    iget-object v3, v3, Lc/F0;->a:Ljava/lang/String;

    invoke-interface {v4, v6, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    add-int/2addr v12, v3

    move-object/from16 v3, v20

    move-object/from16 v6, v21

    goto :goto_0

    :cond_0
    move-object/from16 v20, v3

    move-object/from16 v21, v6

    invoke-virtual {v10}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const-string v14, "sensor:"

    if-eqz v6, :cond_1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/i6;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v13, v6, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v6, v13}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v12, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    new-array v13, v6, [Z

    const/4 v3, 0x0

    aput-boolean v3, v13, v3

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v22

    const/16 v23, 0x0

    move-object/from16 v3, v23

    const/4 v12, 0x0

    :goto_2
    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_8

    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map$Entry;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v24

    move-object/from16 v15, v24

    check-cast v15, Ljava/lang/String;

    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v15, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v24

    if-eqz v24, :cond_2

    move-object/from16 v24, v23

    :goto_3
    const/16 v17, 0x3

    goto :goto_4

    :cond_2
    invoke-static {v15}, Lc/F0;->valueOf(Ljava/lang/String;)Lc/F0;

    move-result-object v24

    goto :goto_3

    :goto_4
    rem-int/lit8 v25, v12, 0x3

    if-nez v25, :cond_3

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v25, v4

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v27, v13

    move-object/from16 v26, v14

    const/4 v13, -0x2

    const/4 v14, -0x1

    invoke-direct {v4, v14, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v13, 0x41400000    # 12.0f

    invoke-static {v9, v13}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v13

    iput v13, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v5, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_5
    move-object v14, v3

    goto :goto_6

    :cond_3
    move-object/from16 v25, v4

    move-object/from16 v27, v13

    move-object/from16 v26, v14

    goto :goto_5

    :goto_6
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    invoke-virtual {v13, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    invoke-virtual {v13, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-static {v9, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    const/4 v4, 0x0

    invoke-virtual {v13, v3, v4, v3, v4}, Landroid/view/View;->setPadding(IIII)V

    iget v3, v8, Lc/r4;->d:I

    move-object/from16 v28, v5

    const/16 v5, 0xe

    invoke-static {v9, v6, v5, v4, v3}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v3

    const/16 v4, 0x11

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v4, 0x42800000    # 64.0f

    invoke-static {v9, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v29, v8

    move/from16 v30, v12

    const/4 v5, -0x1

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v12, 0x0

    invoke-direct {v4, v5, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez v24, :cond_4

    invoke-virtual {v10}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v4

    const/4 v5, 0x7

    invoke-virtual {v15, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    goto :goto_7

    :cond_4
    invoke-virtual {v11}, Lc/n1;->z()I

    move-result v4

    invoke-virtual/range {v24 .. v24}, Lc/F0;->a()I

    move-result v5

    and-int/2addr v4, v5

    if-eqz v4, :cond_5

    const/4 v4, 0x1

    goto :goto_7

    :cond_5
    const/4 v4, 0x0

    :goto_7
    const-string v5, ""

    invoke-static {v9, v5, v4}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v12

    invoke-static {v9, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-interface {v1, v15, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v4, Lc/I0;

    const/4 v5, 0x0

    invoke-direct {v4, v12, v5}, Lc/I0;-><init>(Landroid/widget/Switch;I)V

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v2, v15}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "%"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v9, v3, v5}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v8

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044f"

    invoke-static {v9, v4}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ": "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v9, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v8, v3}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-interface {v0, v15, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v12}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    invoke-virtual {v8, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v12}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    if-eqz v3, :cond_6

    const/high16 v3, 0x3f800000    # 1.0f

    goto :goto_8

    :cond_6
    const v3, 0x3ecccccd    # 0.4f

    :goto_8
    invoke-virtual {v8, v3}, Landroid/view/View;->setAlpha(F)V

    new-instance v6, Lc/J0;

    move-object/from16 v31, v0

    move-object v0, v6

    move-object/from16 v32, v1

    move-object/from16 v1, p0

    move-object/from16 v33, v2

    move-object v2, v7

    move-object/from16 v5, v20

    move-object v3, v11

    move-object/from16 v16, v10

    move-object/from16 v20, v25

    const/16 v10, 0x11

    move-object/from16 v4, v33

    move-object/from16 v35, v5

    move-object/from16 v34, v28

    move-object v5, v15

    move-object v10, v6

    move-object/from16 v36, v21

    move-object/from16 v6, v20

    move-object/from16 v25, v7

    move-object/from16 v7, v31

    move-object/from16 v28, v15

    move-object/from16 v37, v29

    move-object v15, v8

    move-object/from16 v8, p1

    invoke-direct/range {v0 .. v8}, Lc/J0;-><init>(Lru/drivedeck/launcher/MainActivity;Landroid/app/Dialog;Lc/n1;Lc/j6;Ljava/lang/String;Ljava/util/LinkedHashMap;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;)V

    invoke-virtual {v15, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x11

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v1, v1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v1, v2

    const/high16 v2, 0x43f00000    # 480.0f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_7

    const/4 v3, 0x1

    goto :goto_9

    :cond_7
    const/4 v3, 0x0

    :goto_9
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x40800000    # 4.0f

    invoke-static {v9, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v15, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v1, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v0, v3, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v14, v13, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    add-int/lit8 v1, v30, 0x1

    new-instance v2, Lc/K0;

    move-object/from16 v8, v16

    move-object v10, v2

    move-object/from16 v21, v11

    move-object/from16 v11, v27

    move v7, v0

    move-object v0, v12

    move-object/from16 v12, v24

    move v6, v3

    move-object/from16 v24, v27

    move-object v13, v8

    move-object v3, v14

    move/from16 v5, v17

    move-object/from16 v4, v26

    move-object/from16 v14, v33

    move-object/from16 v19, v15

    move-object/from16 v15, v28

    move-object/from16 v16, v21

    move-object/from16 v17, p1

    move-object/from16 v18, v0

    invoke-direct/range {v10 .. v19}, Lc/K0;-><init>([ZLc/F0;Lc/T5;Lc/j6;Ljava/lang/String;Lc/n1;Ljava/util/function/BooleanSupplier;Landroid/widget/Switch;Landroid/widget/TextView;)V

    invoke-virtual {v0, v2}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    move-object/from16 v15, p1

    move v12, v1

    move-object v14, v4

    move-object v10, v8

    move-object/from16 v4, v20

    move-object/from16 v11, v21

    move-object/from16 v13, v24

    move-object/from16 v7, v25

    move-object/from16 v0, v31

    move-object/from16 v1, v32

    move-object/from16 v2, v33

    move-object/from16 v5, v34

    move-object/from16 v20, v35

    move-object/from16 v21, v36

    move-object/from16 v8, v37

    goto/16 :goto_2

    :cond_8
    move-object/from16 v31, v0

    move-object/from16 v32, v1

    move-object/from16 v33, v2

    move-object/from16 v34, v5

    move-object/from16 v25, v7

    move-object/from16 v37, v8

    move-object v8, v10

    move/from16 v30, v12

    move-object/from16 v24, v13

    move-object/from16 v35, v20

    move-object/from16 v36, v21

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    move-object/from16 v20, v4

    move-object/from16 v21, v11

    :goto_a
    rem-int/lit8 v0, v12, 0x3

    if-eqz v0, :cond_9

    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v9}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v1, v6, v7, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/2addr v12, v7

    goto :goto_a

    :cond_9
    const-string v0, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0432\u0441\u0435\u0445 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0435\u0439"

    invoke-static {v9, v0, v6}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v10

    new-instance v11, Lc/L0;

    move-object v0, v11

    move-object/from16 v1, p0

    move-object/from16 v2, v25

    move-object/from16 v3, v21

    move-object/from16 v4, v33

    move v12, v5

    move-object/from16 v5, v20

    move v13, v6

    move-object/from16 v6, v31

    move v14, v7

    move-object/from16 v7, p1

    invoke-direct/range {v0 .. v7}, Lc/L0;-><init>(Lru/drivedeck/launcher/MainActivity;Landroid/app/Dialog;Lc/n1;Lc/j6;Ljava/util/LinkedHashMap;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v0, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0432\u0441\u0435"

    invoke-static {v9, v0, v13}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v11

    new-instance v15, Lc/J0;

    move-object v0, v15

    move-object v1, v8

    move-object/from16 v2, v33

    move-object/from16 v4, v20

    move-object/from16 v5, p1

    move-object/from16 v6, v24

    move-object/from16 v7, v32

    move-object/from16 v16, v8

    move-object/from16 v8, v31

    invoke-direct/range {v0 .. v8}, Lc/J0;-><init>(Lc/T5;Lc/j6;Lc/n1;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;[ZLjava/util/LinkedHashMap;Ljava/util/LinkedHashMap;)V

    invoke-virtual {v11, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x10

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v9, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v10, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v11, v1}, Landroid/widget/TextView;->setMinHeight(I)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, -0x2

    invoke-direct {v1, v13, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v13, v3, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41000000    # 8.0f

    invoke-static {v9, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v0, v10, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v11, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-static {v9, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    move-object/from16 v2, v34

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object/from16 v0, v36

    invoke-static {v9, v0, v2}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v1, "\u041f\u043e\u0435\u0437\u0434\u043a\u0430"

    invoke-static {v9, v1}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v2, "\u0421\u0440\u0435\u0434\u043d\u0438\u0439 \u0440\u0430\u0441\u0445\u043e\u0434 \u2014 \u043f\u043e \u0443\u0447\u0430\u0441\u0442\u043a\u0430\u043c \u0441 \u0434\u0430\u043d\u043d\u044b\u043c\u0438 \u0442\u043e\u043f\u043b\u0438\u0432\u0430 \u0438 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438, \u043f\u043e\u0441\u043b\u0435 100 \u043c. \u0418\u0437\u0440\u0430\u0441\u0445\u043e\u0434\u043e\u0432\u0430\u043d\u043e \u2014 \u043f\u043e \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u043d\u044b\u043c \u0434\u0430\u043d\u043d\u044b\u043c \u0442\u043e\u043f\u043b\u0438\u0432\u0430. \u041f\u0435\u0440\u0435\u0440\u044b\u0432\u044b \u0441\u0432\u044f\u0437\u0438 \u043d\u0435 \u0443\u0447\u0438\u0442\u044b\u0432\u0430\u044e\u0442\u0441\u044f. \u0417\u043d\u0430\u0447\u043e\u043a \u2248 \u043e\u0437\u043d\u0430\u0447\u0430\u0435\u0442 \u043e\u0446\u0435\u043d\u043a\u0443 \u0438\u043b\u0438 \u043d\u0435\u043f\u043e\u043b\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435."

    move-object/from16 v3, v37

    iget v3, v3, Lc/r4;->e:I

    const/16 v4, 0xe

    invoke-static {v9, v2, v4, v13, v3}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    move-object/from16 v5, v35

    invoke-virtual {v2, v5}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a \u0440\u0430\u0441\u0445\u043e\u0434\u0430: "

    invoke-static {v9, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {v16 .. v16}, Lc/T5;->S()Ljava/lang/Double;

    move-result-object v5

    if-nez v5, :cond_a

    const-string v5, "\u043d\u0435\u0442 \u0434\u0430\u043d\u043d\u044b\u0445"

    :goto_b
    invoke-static {v9, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_c

    :cond_a
    invoke-virtual/range {v16 .. v16}, Lc/T5;->T()Ljava/lang/String;

    move-result-object v5

    goto :goto_b

    :goto_c
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ". \u041d\u0430 \u043c\u0435\u0441\u0442\u0435 \u2014 \u043b/\u0447; \u043e\u0442 5 \u043a\u043c/\u0447 \u2014 \u043b/100 \u043a\u043c. \u0421\u0442\u0430\u0440\u0448\u0435 12 \u0441\u0435\u043a\u0443\u043d\u0434 \u2014 \u043f\u0440\u043e\u0447\u0435\u0440\u043a."

    invoke-static {v9, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2, v4, v13, v3}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v2, "\u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c \u043f\u043e\u0435\u0437\u0434\u043a\u0443"

    invoke-static {v9, v2, v13}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Lc/l;

    move-object/from16 v4, p1

    move-object/from16 v5, v16

    invoke-direct {v3, v5, v4, v9, v14}, Lc/l;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v9, v0, v1}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v1, "\u0424\u043e\u043d"

    invoke-static {v9, v1}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    sget-object v2, Lc/s0;->l:Lc/s0;

    new-instance v3, Lc/i;

    invoke-direct {v3, v4, v12}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-static {v9, v1, v2, v3}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v9, v0, v1}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v1, "\u0413\u043e\u0442\u043e\u0432\u043e"

    invoke-static {v9, v1, v14}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Lc/a0;

    move-object/from16 v3, v25

    invoke-direct {v2, v3, v12}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v2, v14, [Landroid/view/View;

    aput-object v1, v2, v13

    invoke-static {v9, v2}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v2, "\u0414\u0430\u043d\u043d\u044b\u0435 OBD"

    invoke-static {v3, v9, v2, v0, v1}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    return-object v3
.end method

.method public static H(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;[BLc/I6;ZZZ)Lc/R1;
    .locals 1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p5

    const/4 p6, 0x0

    if-eqz p5, :cond_4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Lc/n7;

    iget-object v0, p5, Lc/n7;->a:Ljava/lang/String;

    invoke-static {v0, p4}, Lc/G8;->E(Ljava/lang/String;Lc/I6;)Ljava/lang/String;

    move-result-object v0

    if-nez p7, :cond_1

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    :cond_1
    invoke-static {p5, p3}, Lc/G8;->S(Lc/n7;[B)Z

    move-result v0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    array-length p0, p3

    iget-object p2, p5, Lc/n7;->b:[B

    array-length p3, p2

    iget p4, p4, Lc/I6;->a:I

    invoke-static {p1, p0, p3, p4}, Lc/k6;->o0(Ljava/lang/String;III)I

    move-result p0

    array-length p1, p2

    if-le p0, p1, :cond_3

    return-object p6

    :cond_3
    new-instance p1, Lc/R1;

    array-length p3, p2

    invoke-static {p2, p0, p3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iget-object p2, p5, Lc/n7;->a:Ljava/lang/String;

    iput-object p2, p1, Lc/R1;->a:Ljava/lang/Object;

    iput-object p0, p1, Lc/R1;->b:Ljava/lang/Object;

    iget-object p0, p5, Lc/n7;->b:[B

    invoke-virtual {p0}, [B->clone()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [B

    iput-object p0, p1, Lc/R1;->c:Ljava/lang/Object;

    return-object p1

    :cond_4
    return-object p6
.end method

.method public static H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;
    .locals 17

    move-object/from16 v8, p0

    move/from16 v9, p5

    move-object/from16 v10, p6

    new-instance v11, Lc/j;

    invoke-direct {v11, v8, v9}, Lc/j;-><init>(Landroid/content/Context;Z)V

    const/4 v6, 0x1

    invoke-virtual {v11, v6}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v12

    const/4 v7, 0x0

    filled-new-array {v7}, [Lc/W3;

    move-result-object v13

    new-instance v14, Lc/h;

    move-object v0, v14

    move-object/from16 v1, p0

    move/from16 v2, p5

    move-object/from16 v3, p0

    move-object v4, v12

    move-object v5, v13

    invoke-direct/range {v0 .. v5}, Lc/h;-><init>(Landroid/content/Context;ZLandroid/content/Context;Lc/r4;[Lc/W3;)V

    invoke-virtual {v14, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x22

    int-to-float v0, v0

    invoke-static {v8, v0}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v1

    const/16 v2, 0x18

    int-to-float v2, v2

    invoke-static {v8, v2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {v8, v0}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/16 v3, 0x12

    int-to-float v3, v3

    invoke-static {v8, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {v14, v1, v2, v0, v3}, Landroid/view/View;->setPadding(IIII)V

    const/4 v15, 0x0

    if-eqz v9, :cond_0

    move v0, v15

    goto :goto_0

    :cond_0
    iget v0, v12, Lc/r4;->a:I

    :goto_0
    invoke-virtual {v14, v0}, Landroid/view/View;->setBackgroundColor(I)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setWillNotDraw(Z)V

    if-eqz v9, :cond_1

    new-instance v0, Lc/b;

    const/4 v1, 0x0

    invoke-direct {v0, v13, v14, v1}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {v8, v0}, Lc/X3;->f(Landroid/content/Context;Ljava/util/function/Consumer;)V

    :cond_1
    invoke-virtual {v14, v6}, Landroid/view/View;->setClickable(Z)V

    new-instance v0, Lc/c;

    const/4 v1, 0x0

    invoke-direct {v0, v11, v1}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v14, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v13, 0x0

    invoke-virtual {v14, v13}, Landroid/view/View;->setAlpha(F)V

    const v0, 0x3f7851ec    # 0.97f

    const/high16 v5, 0x3f800000    # 1.0f

    if-eqz v9, :cond_2

    move v1, v0

    goto :goto_1

    :cond_2
    move v1, v5

    :goto_1
    invoke-virtual {v14, v1}, Landroid/view/View;->setScaleX(F)V

    if-eqz v9, :cond_3

    goto :goto_2

    :cond_3
    move v0, v5

    :goto_2
    invoke-virtual {v14, v0}, Landroid/view/View;->setScaleY(F)V

    const/16 v0, 0x10

    if-eqz v9, :cond_4

    move v1, v13

    goto :goto_3

    :cond_4
    int-to-float v1, v0

    invoke-static {v8, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    int-to-float v1, v1

    :goto_3
    invoke-virtual {v14, v1}, Landroid/view/View;->setTranslationY(F)V

    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v2, p2

    invoke-static {v8, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, -0x1

    if-eqz v9, :cond_5

    move v2, v4

    goto :goto_4

    :cond_5
    iget v2, v12, Lc/r4;->d:I

    :goto_4
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v2, 0x41c80000    # 25.0f

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v2, 0x14

    const/16 v3, 0x19

    const/4 v13, 0x2

    invoke-virtual {v1, v2, v3, v6, v13}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setGravity(I)V

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x38

    int-to-float v2, v2

    invoke-static {v8, v2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-direct {v0, v4, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v14, v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v9, :cond_6

    new-instance v7, Lc/n1;

    invoke-direct {v7, v8}, Lc/n1;-><init>(Landroid/content/Context;)V

    :cond_6
    if-eqz v9, :cond_7

    invoke-virtual {v7}, Lc/n1;->f()I

    move-result v0

    mul-int/lit8 v0, v0, 0x4b

    int-to-float v0, v0

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    :goto_5
    move v3, v0

    goto :goto_6

    :cond_7
    const/16 v0, 0x32

    goto :goto_5

    :goto_6
    const/16 v0, 0xa

    if-eqz v9, :cond_9

    iget-object v1, v7, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "all_apps_columns"

    invoke-interface {v1, v2, v15}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    if-nez v1, :cond_8

    goto :goto_7

    :cond_8
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    goto :goto_8

    :cond_9
    :goto_7
    move v1, v15

    :goto_8
    if-eqz v9, :cond_b

    iget-object v2, v7, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    const-string v6, "all_apps_rows"

    invoke-interface {v2, v6, v15}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-nez v2, :cond_a

    goto :goto_9

    :cond_a
    const/16 v6, 0x8

    invoke-static {v6, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    goto :goto_a

    :cond_b
    :goto_9
    move v2, v15

    :goto_a
    new-instance v7, Lc/k;

    invoke-direct {v7, v8, v2, v8, v3}, Lc/k;-><init>(Landroid/content/Context;ILandroid/content/Context;I)V

    if-nez v1, :cond_c

    move v1, v4

    :cond_c
    invoke-virtual {v7, v1}, Landroid/widget/GridView;->setNumColumns(I)V

    if-eqz v9, :cond_d

    add-int/lit8 v1, v3, 0x3a

    goto :goto_b

    :cond_d
    const/16 v1, 0x6c

    :goto_b
    int-to-float v1, v1

    invoke-static {v8, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/widget/GridView;->setColumnWidth(I)V

    int-to-float v0, v0

    invoke-static {v8, v0}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v7, v1}, Landroid/widget/GridView;->setHorizontalSpacing(I)V

    invoke-static {v8, v0}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-virtual {v7, v0}, Landroid/widget/GridView;->setVerticalSpacing(I)V

    invoke-virtual {v7, v13}, Landroid/widget/GridView;->setStretchMode(I)V

    new-instance v0, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v0, v15}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v7, v0}, Landroid/widget/AbsListView;->setSelector(Landroid/graphics/drawable/Drawable;)V

    filled-new-array {v4}, [I

    move-result-object v6

    new-instance v2, Lc/m;

    move-object v0, v2

    move-object/from16 v1, p1

    move-object v13, v2

    move-object/from16 v2, p0

    move v10, v4

    move/from16 v4, p5

    move v8, v5

    move-object v5, v12

    move-object/from16 v16, v6

    move-object v8, v7

    move-object v7, v11

    invoke-direct/range {v0 .. v7}, Lc/m;-><init>(Ljava/util/List;Landroid/content/Context;IZLc/r4;[ILc/j;)V

    invoke-virtual {v8, v13}, Landroid/widget/GridView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-direct {v0, v10, v15, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v14, v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static/range {p0 .. p0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    const/4 v1, 0x2

    new-array v2, v1, [F

    new-instance v1, Lc/d;

    invoke-direct {v1, v2, v0, v8, v11}, Lc/d;-><init>([FILc/k;Lc/j;)V

    invoke-virtual {v8, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance v7, Lc/e;

    move-object v0, v7

    move-object/from16 v1, v16

    move-object v2, v13

    move-object/from16 v3, p1

    move-object/from16 v4, p3

    move-object v5, v11

    invoke-direct/range {v0 .. v5}, Lc/e;-><init>([ILc/m;Ljava/util/List;Lc/n;Lc/j;)V

    invoke-virtual {v8, v7}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    if-eqz v9, :cond_e

    new-instance v0, Lc/f;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move v3, v6

    move-object/from16 v4, v16

    invoke-direct {v0, v2, v1, v4, v13}, Lc/f;-><init>(Ljava/util/List;Landroid/content/Context;[ILc/m;)V

    invoke-virtual {v8, v0}, Landroid/widget/AdapterView;->setOnItemLongClickListener(Landroid/widget/AdapterView$OnItemLongClickListener;)V

    goto :goto_c

    :cond_e
    move v3, v6

    :goto_c
    invoke-virtual {v11, v14}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    iput-object v14, v11, Lc/j;->a:Lc/h;

    new-instance v0, Lc/g;

    const/4 v1, 0x0

    move-object/from16 v2, p4

    invoke-direct {v0, v2, v1}, Lc/g;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v11, v0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-virtual {v11}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_13

    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v1, v15}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    if-eqz v9, :cond_f

    const/4 v1, 0x0

    goto :goto_d

    :cond_f
    const v1, 0x3f3851ec    # 0.72f

    :goto_d
    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    if-eqz v9, :cond_10

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    goto :goto_e

    :cond_10
    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    :goto_e
    invoke-virtual {v0, v10, v10}, Landroid/view/Window;->setLayout(II)V

    if-eqz v9, :cond_11

    move v1, v15

    goto :goto_f

    :cond_11
    iget v1, v12, Lc/r4;->a:I

    :goto_f
    invoke-virtual {v0, v1}, Landroid/view/Window;->setNavigationBarColor(I)V

    if-eqz v9, :cond_12

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, v15, v15, v15, v15}, Landroid/view/View;->setPadding(IIII)V

    :cond_12
    invoke-virtual {v0, v15}, Landroid/view/Window;->setWindowAnimations(I)V

    invoke-static {v0}, Lc/b4;->b(Landroid/view/Window;)V

    :cond_13
    if-eqz v0, :cond_14

    move-object/from16 v1, p6

    if-eqz v1, :cond_14

    invoke-virtual {v11, v15}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    const/16 v2, 0x20

    invoke-virtual {v0, v2}, Landroid/view/Window;->addFlags(I)V

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    const/16 v4, 0x33

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->gravity:I

    iget v4, v1, Landroid/graphics/Rect;->left:I

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->x:I

    iget v4, v1, Landroid/graphics/Rect;->top:I

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->y:I

    invoke-virtual/range {p6 .. p6}, Landroid/graphics/Rect;->width()I

    move-result v4

    iput v4, v2, Landroid/view/WindowManager$LayoutParams;->width:I

    invoke-virtual/range {p6 .. p6}, Landroid/graphics/Rect;->height()I

    move-result v1

    iput v1, v2, Landroid/view/WindowManager$LayoutParams;->height:I

    invoke-virtual {v0, v2}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    :cond_14
    invoke-virtual {v11}, Landroid/app/Dialog;->show()V

    if-eqz v0, :cond_15

    new-instance v1, Lc/t8;

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    invoke-direct {v1, v2}, Lc/t8;-><init>(Landroid/view/View;)V

    iput-object v1, v11, Lc/j;->c:Lc/t8;

    :cond_15
    if-eqz v0, :cond_16

    invoke-static {v0}, Lc/b4;->b(Landroid/view/Window;)V

    :cond_16
    invoke-virtual {v14}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    if-eqz v9, :cond_17

    const-wide/16 v4, 0x12c

    goto :goto_10

    :cond_17
    const-wide/16 v4, 0xaa

    :goto_10
    invoke-virtual {v0, v4, v5}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    if-eqz v9, :cond_18

    new-instance v2, Landroid/view/animation/PathInterpolator;

    const v4, 0x3ecccccd    # 0.4f

    const v5, 0x3e4ccccd    # 0.2f

    invoke-direct {v2, v4, v1, v5, v3}, Landroid/view/animation/PathInterpolator;-><init>(FFFF)V

    goto :goto_11

    :cond_18
    new-instance v2, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {v2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    :goto_11
    invoke-virtual {v0, v2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->withLayer()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-object v11
.end method

.method public static varargs I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;
    .locals 5

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const v1, 0x800015

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v1, 0x0

    :goto_0
    array-length v2, p1

    if-ge v1, v2, :cond_1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x42400000    # 48.0f

    invoke-static {p0, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    const/4 v4, -0x2

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-lez v1, :cond_0

    const/high16 v3, 0x41000000    # 8.0f

    invoke-static {p0, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_0
    aget-object v3, p1, v1

    invoke-virtual {v0, v3, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public static I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V
    .locals 7

    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v5, Lc/i;

    const/4 v0, 0x4

    invoke-direct {v5, p0, v0}, Lc/i;-><init>(Ljava/lang/Object;I)V

    const/4 v6, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-static/range {v0 .. v6}, Lc/G8;->J0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Ljava/lang/Runnable;Z)V

    return-void
.end method

.method public static declared-synchronized J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 11

    const-class v0, Lc/G8;

    monitor-enter v0

    const/4 v1, 0x0

    if-nez p1, :cond_0

    monitor-exit v0

    return-object v1

    :cond_0
    :try_start_0
    sget-object v2, Lc/G8;->a:Ljava/lang/String;

    if-nez v2, :cond_2

    const-class v2, Lc/G8;

    monitor-enter v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    sget-object v3, Lc/G8;->a:Ljava/lang/String;

    if-nez v3, :cond_1

    new-instance v3, Lc/n1;

    invoke-direct {v3, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v3

    sput-object v3, Lc/G8;->a:Ljava/lang/String;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    :goto_0
    monitor-exit v2

    move-object v2, v3

    goto :goto_2

    :goto_1
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    throw p0

    :catchall_1
    move-exception p0

    goto/16 :goto_c

    :cond_2
    :goto_2
    const-string v3, "ru"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz v3, :cond_3

    monitor-exit v0

    return-object p1

    :cond_3
    :try_start_3
    sget-object v3, Lc/G8;->b:[Ljava/lang/String;

    if-nez v3, :cond_b

    const-class v3, Lc/G8;

    monitor-enter v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    sget-object v4, Lc/G8;->b:[Ljava/lang/String;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    if-nez v4, :cond_a

    const/4 v4, 0x0

    :try_start_5
    new-instance v5, Lorg/json/JSONObject;

    invoke-static {p0, v2}, Lc/F8;->c(Landroid/content/Context;Ljava/lang/String;)Ljava/util/zip/GZIPInputStream;

    move-result-object p0

    const/high16 v6, 0x60000

    invoke-static {p0, v6}, Lc/G8;->m0(Ljava/io/InputStream;I)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v5, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-static {v5, v2}, Lc/G8;->f1(Lorg/json/JSONObject;Ljava/lang/String;)V

    const-string p0, "ui_text_source"

    invoke-static {v5, p0}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const-string v6, "ui_text_en"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->c:[Ljava/lang/String;

    const-string v6, "ui_text_es"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->d:[Ljava/lang/String;

    const-string v6, "ui_text_vi"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->e:[Ljava/lang/String;

    const-string v6, "ui_text_it"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->f:[Ljava/lang/String;

    const-string v6, "ui_text_lt"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->g:[Ljava/lang/String;

    const-string v6, "ui_text_lt_dynamic_source"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->i:[Ljava/lang/String;

    const-string v6, "ui_text_lt_dynamic"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->j:[Ljava/lang/String;

    const-string v6, "ui_text_zh_tw"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->h:[Ljava/lang/String;

    const-string v6, "ui_text_zh_tw_dynamic_source"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->k:[Ljava/lang/String;

    const-string v6, "ui_text_zh_tw_dynamic"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->l:[Ljava/lang/String;

    const-string v6, "ui_text_dynamic_en"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const-string v7, "ui_text_dynamic_es"

    invoke-static {v5, v7}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const-string v8, "ui_text_dynamic_vi"

    invoke-static {v5, v8}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    filled-new-array {v6, v7, v8}, [[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->m:[[Ljava/lang/String;

    sget-object v6, Lc/G8;->m:[[Ljava/lang/String;

    array-length v7, v6

    move v8, v4

    :goto_3
    if-ge v8, v7, :cond_6

    aget-object v9, v6, v8

    array-length v10, v9

    if-eqz v10, :cond_5

    array-length v9, v9

    sget-object v10, Lc/G8;->k:[Ljava/lang/String;

    array-length v10, v10

    if-ne v9, v10, :cond_4

    goto :goto_4

    :cond_4
    new-instance p0, Lorg/json/JSONException;

    const-string v5, "Unaligned dynamic translations"

    invoke-direct {p0, v5}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_2
    move-exception p0

    goto/16 :goto_8

    :catch_0
    move-exception p0

    goto :goto_6

    :cond_5
    :goto_4
    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    :cond_6
    const-string v6, "ui_text_diagnostic_source"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    sput-object v6, Lc/G8;->n:[Ljava/lang/String;

    const-string v6, "ui_text_diagnostic_keys"

    invoke-static {v5, v6}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v6, v5

    sget-object v7, Lc/G8;->n:[Ljava/lang/String;

    array-length v7, v7

    if-ne v6, v7, :cond_8

    array-length v6, v5

    new-array v6, v6, [I

    sput-object v6, Lc/G8;->o:[I

    move v6, v4

    :goto_5
    array-length v7, v5

    if-ge v6, v7, :cond_9

    sget-object v7, Lc/G8;->o:[I

    sget-object v8, Lc/G8;->k:[Ljava/lang/String;

    aget-object v9, v5, v6

    invoke-static {v8, v9}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v8

    aput v8, v7, v6

    sget-object v7, Lc/G8;->o:[I

    aget v7, v7, v6

    if-ltz v7, :cond_7

    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    :cond_7
    new-instance p0, Lorg/json/JSONException;

    const-string v5, "Missing diagnostic translation"

    invoke-direct {p0, v5}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_8
    new-instance p0, Lorg/json/JSONException;

    const-string v5, "Unaligned diagnostic translations"

    invoke-direct {p0, v5}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :goto_6
    :try_start_6
    const-string v5, "DriveDeck"

    const-string v6, "Cannot load translations"

    invoke-static {v5, v6, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-array p0, v4, [Ljava/lang/String;

    sput-object p0, Lc/G8;->l:[Ljava/lang/String;

    sput-object p0, Lc/G8;->k:[Ljava/lang/String;

    sput-object p0, Lc/G8;->h:[Ljava/lang/String;

    sput-object p0, Lc/G8;->g:[Ljava/lang/String;

    sput-object p0, Lc/G8;->f:[Ljava/lang/String;

    sput-object p0, Lc/G8;->e:[Ljava/lang/String;

    sput-object p0, Lc/G8;->d:[Ljava/lang/String;

    sput-object p0, Lc/G8;->c:[Ljava/lang/String;

    new-array v5, v4, [Ljava/lang/String;

    sput-object v5, Lc/G8;->n:[Ljava/lang/String;

    sput-object v5, Lc/G8;->j:[Ljava/lang/String;

    sput-object v5, Lc/G8;->i:[Ljava/lang/String;

    new-array v4, v4, [I

    sput-object v4, Lc/G8;->o:[I

    sget-object v4, Lc/G8;->c:[Ljava/lang/String;

    sget-object v5, Lc/G8;->d:[Ljava/lang/String;

    sget-object v6, Lc/G8;->e:[Ljava/lang/String;

    filled-new-array {v4, v5, v6}, [[Ljava/lang/String;

    move-result-object v4

    sput-object v4, Lc/G8;->m:[[Ljava/lang/String;

    :cond_9
    sput-object p0, Lc/G8;->b:[Ljava/lang/String;

    goto :goto_7

    :cond_a
    move-object p0, v4

    :goto_7
    monitor-exit v3

    move-object v3, p0

    goto :goto_9

    :goto_8
    monitor-exit v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    throw p0

    :cond_b
    :goto_9
    array-length p0, v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    if-nez p0, :cond_c

    monitor-exit v0

    return-object p1

    :cond_c
    :try_start_8
    invoke-static {v3, p1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p0

    const-string v3, "en"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_d

    sget-object v1, Lc/G8;->c:[Ljava/lang/String;

    goto :goto_a

    :cond_d
    const-string v3, "es"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e

    sget-object v1, Lc/G8;->d:[Ljava/lang/String;

    goto :goto_a

    :cond_e
    const-string v3, "vi"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f

    sget-object v1, Lc/G8;->e:[Ljava/lang/String;

    goto :goto_a

    :cond_f
    const-string v3, "it"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_10

    sget-object v1, Lc/G8;->f:[Ljava/lang/String;

    goto :goto_a

    :cond_10
    const-string v3, "lt"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_11

    sget-object v1, Lc/G8;->g:[Ljava/lang/String;

    goto :goto_a

    :cond_11
    const-string v3, "zh-TW"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_12

    sget-object v1, Lc/G8;->h:[Ljava/lang/String;

    :cond_12
    :goto_a
    if-ltz p0, :cond_13

    if-eqz v1, :cond_13

    aget-object p0, v1, p0
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    monitor-exit v0

    return-object p0

    :cond_13
    :try_start_9
    invoke-static {p1, v2}, Lc/G8;->A(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    if-nez p0, :cond_14

    goto :goto_b

    :cond_14
    move-object p1, p0

    :goto_b
    monitor-exit v0

    return-object p1

    :goto_c
    :try_start_a
    monitor-exit v0
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    throw p0
.end method

.method public static J0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Ljava/lang/Runnable;Z)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    move-object/from16 v3, p4

    move-object/from16 v4, p5

    invoke-static/range {p1 .. p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v5

    iget v5, v5, Lc/r4;->d:I

    invoke-static {v2, v5}, Lc/G8;->p(Landroid/widget/LinearLayout;I)V

    invoke-static {v1, v2}, Lc/G8;->G(Landroid/app/Activity;Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Landroid/app/Dialog;->isShowing()Z

    move-result v5

    invoke-static/range {p1 .. p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v6

    const/4 v7, 0x1

    if-nez v5, :cond_0

    invoke-virtual {v0, v7}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    :cond_0
    invoke-static/range {p1 .. p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Landroid/app/Dialog;->setTitle(Ljava/lang/CharSequence;)V

    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct {v8, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v8, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    iget v9, v6, Lc/r4;->b:I

    const/16 v10, 0x20

    invoke-static {v1, v9, v10}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v8, v7}, Landroid/view/View;->setClipToOutline(Z)V

    const/16 v10, 0x10

    const/high16 v11, 0x41000000    # 8.0f

    const/high16 v12, 0x40800000    # 4.0f

    const/4 v15, 0x0

    if-eqz p6, :cond_1

    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v13, v10}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/high16 v10, 0x41a00000    # 20.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v1, v12}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    invoke-static {v1, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v14

    invoke-static {v1, v12}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    invoke-virtual {v13, v10, v9, v14, v11}, Landroid/view/View;->setPadding(IIII)V

    const/16 v9, 0x14

    iget v10, v6, Lc/r4;->d:I

    move-object/from16 v11, p2

    invoke-static {v1, v11, v9, v7, v10}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v9

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setSingleLine(Z)V

    sget-object v7, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, -0x2

    const/high16 v14, 0x3f800000    # 1.0f

    invoke-direct {v7, v15, v11, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v9, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v7, Landroid/widget/ImageButton;

    invoke-direct {v7, v1}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    const v9, 0x1080038

    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setImageResource(I)V

    invoke-static {v10}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v9

    invoke-virtual {v7, v9}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    new-instance v9, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v15}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v10

    const/16 v11, 0x3e8

    invoke-static {v1, v15, v11}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v11

    const/4 v14, 0x0

    invoke-direct {v9, v10, v11, v14}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v7, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v9, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v1, v9}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7, v9}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v9, Lc/h1;

    const/4 v10, 0x0

    invoke-direct {v9, v4, v10}, Lc/h1;-><init>(Ljava/lang/Runnable;I)V

    invoke-virtual {v7, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v9, 0x42400000    # 48.0f

    invoke-static {v1, v9}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v10

    invoke-static {v1, v9}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    invoke-direct {v4, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v7, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x42600000    # 56.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/4 v9, -0x1

    invoke-direct {v4, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v13, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v4, Landroid/view/View;

    invoke-direct {v4, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6}, Lc/r4;->a()I

    move-result v7

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v11

    invoke-direct {v7, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/high16 v11, 0x41000000    # 8.0f

    goto :goto_0

    :cond_1
    invoke-virtual/range {p3 .. p3}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    invoke-virtual/range {p3 .. p3}, Landroid/view/View;->getPaddingTop()I

    move-result v9

    invoke-virtual/range {p3 .. p3}, Landroid/view/View;->getPaddingRight()I

    move-result v10

    const/high16 v11, 0x41000000    # 8.0f

    invoke-static {v1, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v13

    invoke-virtual {v2, v7, v9, v10, v13}, Landroid/view/View;->setPadding(IIII)V

    new-instance v7, Lc/i1;

    invoke-direct {v7, v4}, Lc/i1;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v7}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    :goto_0
    new-instance v4, Landroid/widget/ScrollView;

    invoke-direct {v4, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, v15}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    invoke-virtual {v4, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v7, v9, v15, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz p6, :cond_2

    new-instance v4, Landroid/view/View;

    invoke-direct {v4, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    invoke-virtual {v6}, Lc/r4;->a()I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/view/View;->setBackgroundColor(I)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-static {v1, v10}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/4 v9, -0x1

    invoke-direct {v6, v9, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v4, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_2
    const/high16 v4, 0x41c00000    # 24.0f

    const/high16 v6, 0x41800000    # 16.0f

    if-eqz p6, :cond_3

    move v7, v6

    goto :goto_1

    :cond_3
    move v7, v4

    :goto_1
    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    if-eqz p6, :cond_4

    goto :goto_2

    :cond_4
    move v11, v12

    :goto_2
    invoke-static {v1, v11}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    if-eqz p6, :cond_5

    move v4, v6

    :cond_5
    invoke-static {v1, v4}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    if-eqz p6, :cond_6

    goto :goto_3

    :cond_6
    const/high16 v6, 0x41400000    # 12.0f

    :goto_3
    invoke-static {v1, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-virtual {v3, v7, v9, v4, v6}, Landroid/view/View;->setPadding(IIII)V

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/4 v7, -0x1

    invoke-direct {v4, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v3, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v0, v8}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    invoke-virtual/range {p0 .. p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    if-nez v4, :cond_7

    return-void

    :cond_7
    const v6, 0x106000d

    invoke-virtual {v4, v6}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    invoke-virtual {v4, v15}, Landroid/view/Window;->setWindowAnimations(I)V

    const/16 v6, 0x10

    invoke-virtual {v4, v6}, Landroid/view/Window;->setSoftInputMode(I)V

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    iget v6, v6, Landroid/util/DisplayMetrics;->widthPixels:I

    const/high16 v7, 0x42000000    # 32.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    sub-int/2addr v6, v7

    const/high16 v7, 0x44160000    # 600.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/high16 v7, 0x40000000    # 2.0f

    invoke-static {v6, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    invoke-static {v15, v15}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v10

    invoke-virtual {v2, v9, v10}, Landroid/view/View;->measure(II)V

    invoke-static {v6, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    invoke-static {v15, v15}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    invoke-virtual {v3, v7, v9}, Landroid/view/View;->measure(II)V

    if-eqz p6, :cond_8

    const/high16 v7, 0x42640000    # 57.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    goto :goto_4

    :cond_8
    move v7, v15

    :goto_4
    invoke-virtual/range {p3 .. p3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    add-int/2addr v9, v7

    if-eqz p6, :cond_9

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v1, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v15

    :cond_9
    invoke-virtual/range {p4 .. p4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    add-int/2addr v3, v15

    add-int/2addr v3, v9

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v1, v1

    const v7, 0x3f666666    # 0.9f

    mul-float/2addr v1, v7

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-virtual {v4, v6, v1}, Landroid/view/Window;->setLayout(II)V

    invoke-static {v4}, Lc/b4;->b(Landroid/view/Window;)V

    if-eqz v5, :cond_a

    goto :goto_5

    :cond_a
    move-object v2, v8

    :goto_5
    if-eqz v5, :cond_b

    const v1, 0x3f19999a    # 0.6f

    goto :goto_6

    :cond_b
    const/4 v1, 0x0

    :goto_6
    invoke-virtual {v2, v1}, Landroid/view/View;->setAlpha(F)V

    const v1, 0x3f7ae148    # 0.98f

    invoke-virtual {v2, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v2, v1}, Landroid/view/View;->setScaleY(F)V

    if-nez v5, :cond_c

    invoke-virtual/range {p0 .. p0}, Landroid/app/Dialog;->show()V

    :cond_c
    new-instance v0, Lc/j1;

    const/4 v1, 0x0

    invoke-direct {v0, v2, v1}, Lc/j1;-><init>(Landroid/widget/LinearLayout;I)V

    invoke-virtual {v2, v0}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    return-void
.end method

.method public static K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V
    .locals 9

    move-object v0, p0

    move/from16 v1, p8

    invoke-virtual {p0}, Landroid/graphics/Canvas;->save()I

    move-result v2

    move v3, p2

    int-to-float v3, v3

    mul-float v4, p4, v3

    const/high16 v5, 0x45160000    # 2400.0f

    div-float/2addr v4, v5

    move v6, p3

    int-to-float v6, v6

    mul-float v7, p5, v6

    const/high16 v8, 0x44960000    # 1200.0f

    div-float/2addr v7, v8

    invoke-virtual {p0, v4, v7}, Landroid/graphics/Canvas;->translate(FF)V

    mul-float/2addr v3, p6

    div-float/2addr v3, v5

    mul-float v4, p7, v6

    div-float/2addr v4, v8

    invoke-virtual {p0, v3, v4}, Landroid/graphics/Canvas;->scale(FF)V

    new-instance v3, Landroid/graphics/RadialGradient;

    const v4, 0xffffff

    and-int/2addr v4, v1

    filled-new-array {v1, v4}, [I

    move-result-object v1

    sget-object v4, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v5, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object p2, v3

    move p3, v7

    move p4, v5

    move p5, v6

    move-object p6, v1

    move-object/from16 p7, v8

    move-object/from16 p8, v4

    invoke-direct/range {p2 .. p8}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    move-object v1, p1

    invoke-virtual {p1, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/high16 v3, -0x40800000    # -1.0f

    const/high16 v4, -0x40800000    # -1.0f

    const/high16 v5, 0x3f800000    # 1.0f

    move-object p2, p0

    move p3, v3

    move p4, v4

    move p5, v5

    move p6, v6

    move-object/from16 p7, p1

    invoke-virtual/range {p2 .. p7}, Landroid/graphics/Canvas;->drawOval(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {p0, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void
.end method

.method public static K0(Landroid/view/View;Ljava/lang/CharSequence;)V
    .locals 7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    const/high16 v2, 0x41800000    # 16.0f

    mul-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v3

    new-instance v4, Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41600000    # 14.0f

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setTextSize(F)V

    iget p1, v1, Lc/r4;->d:I

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setTextColor(I)V

    invoke-virtual {v4, v3, v3, v3, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    new-instance p1, Landroid/widget/ScrollView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {p1, v5}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v4}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    const/high16 v4, 0x43b40000    # 360.0f

    mul-float/2addr v4, v0

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/View;->getWidth()I

    move-result v5

    mul-int/lit8 v3, v3, 0x2

    sub-int/2addr v5, v3

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    const/high16 v5, 0x40000000    # 2.0f

    invoke-static {v3, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    const/high16 v6, -0x80000000

    invoke-static {v4, v6}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    invoke-virtual {p1, v5, v4}, Landroid/view/View;->measure(II)V

    new-instance v4, Landroid/widget/PopupWindow;

    invoke-virtual {p1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    const/4 v6, 0x1

    invoke-direct {v4, p1, v3, v5, v6}, Landroid/widget/PopupWindow;-><init>(Landroid/view/View;IIZ)V

    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    iget v3, v1, Lc/r4;->c:I

    invoke-virtual {p1, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {p1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v1, v1, Lc/r4;->e:I

    invoke-virtual {p1, v2, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    invoke-virtual {v4, p1}, Landroid/widget/PopupWindow;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/high16 p1, 0x41000000    # 8.0f

    mul-float/2addr p1, v0

    invoke-virtual {v4, p1}, Landroid/widget/PopupWindow;->setElevation(F)V

    invoke-virtual {v4, v6}, Landroid/widget/PopupWindow;->setOutsideTouchable(Z)V

    const/high16 p1, 0x40800000    # 4.0f

    mul-float/2addr v0, p1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p1

    const v0, 0x800005

    const/4 v1, 0x0

    invoke-virtual {v4, p0, v1, p1, v0}, Landroid/widget/PopupWindow;->showAsDropDown(Landroid/view/View;III)V

    return-void
.end method

.method public static L(Ljava/lang/String;)Z
    .locals 2

    if-eqz p0, :cond_0

    const-string v0, "|"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-lez v1, :cond_0

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x1

    sub-int/2addr p0, v1

    if-ge v0, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public static L0(Lru/drivedeck/launcher/MainActivity;Landroid/app/Dialog;Lc/n1;Lc/j6;Ljava/lang/String;Ljava/util/LinkedHashMap;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;)V
    .locals 16

    move-object/from16 v7, p0

    move-object/from16 v10, p2

    move-object/from16 v11, p3

    move-object/from16 v15, p4

    const/4 v14, 0x1

    invoke-virtual/range {p1 .. p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v4

    const v0, 0x1020002

    invoke-virtual {v4, v0}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v13, 0x0

    invoke-virtual {v0, v13}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v4}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v5, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    invoke-virtual {v4}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v6, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    new-instance v12, Lc/M0;

    move-object v0, v12

    move-object/from16 v1, p1

    move-object/from16 v2, p0

    invoke-direct/range {v0 .. v6}, Lc/M0;-><init>(Landroid/app/Dialog;Lru/drivedeck/launcher/MainActivity;Landroid/view/View;Landroid/view/Window;II)V

    new-instance v0, Lc/H0;

    invoke-direct {v0, v12}, Lc/H0;-><init>(Lc/M0;)V

    invoke-virtual {v1, v0}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V

    invoke-static/range {p0 .. p0}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v2, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0431\u043b\u043e\u043a\u0430"

    invoke-static {v7, v2}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v15, :cond_0

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v4

    aget-object v4, v4, v13

    invoke-virtual {v4}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v4

    goto :goto_0

    :cond_0
    move-object v4, v15

    :goto_0
    invoke-virtual {v10, v11, v4}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "%"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v4

    iget v4, v4, Lc/r4;->d:I

    const/16 v5, 0x14

    invoke-static {v7, v3, v5, v14, v4}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static/range {p0 .. p0}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v4

    const/16 v5, 0x23

    invoke-virtual {v4, v5}, Landroid/widget/ProgressBar;->setMax(I)V

    if-nez v15, :cond_1

    invoke-static {}, Lc/F0;->values()[Lc/F0;

    move-result-object v5

    aget-object v5, v5, v13

    invoke-virtual {v5}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v5

    goto :goto_1

    :cond_1
    move-object v5, v15

    :goto_1
    invoke-virtual {v10, v11, v5}, Lc/n1;->w(Lc/j6;Ljava/lang/String;)I

    move-result v5

    add-int/lit8 v5, v5, -0x19

    div-int/lit8 v5, v5, 0x5

    invoke-virtual {v4, v5}, Landroid/widget/ProgressBar;->setProgress(I)V

    new-array v9, v14, [Z

    aput-boolean v13, v9, v13

    new-instance v5, Lc/N0;

    move-object v8, v5

    move-object/from16 v10, p2

    move-object/from16 v11, p3

    move-object v6, v12

    move-object/from16 v12, p4

    move v1, v13

    move-object/from16 v13, p6

    move-object/from16 v14, p7

    move-object v1, v15

    move-object v15, v3

    invoke-direct/range {v8 .. v15}, Lc/N0;-><init>([ZLc/n1;Lc/j6;Ljava/lang/String;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;Landroid/widget/TextView;)V

    invoke-virtual {v4, v5}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    invoke-virtual {v2, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    if-nez v1, :cond_2

    const-string v3, "\u0412\u0441\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u043f\u043e\u043b\u0443\u0447\u0430\u044e\u0442 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u043c\u0430\u0441\u0448\u0442\u0430\u0431. \u0421\u0436\u0430\u0442\u0438\u0435 \u0440\u0430\u043c\u043a\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u043d\u043e \u0443\u043c\u0435\u043d\u044c\u0448\u0430\u0435\u0442 \u0438\u0445; \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043d\u0438\u0435 \u0432\u043e\u0437\u0432\u0440\u0430\u0449\u0430\u0435\u0442 \u0437\u0430\u0434\u0430\u043d\u043d\u044b\u0439 \u0440\u0430\u0437\u043c\u0435\u0440."

    goto :goto_2

    :cond_2
    const-string v3, "\u041f\u043e\u0434\u043f\u0438\u0441\u044c, \u0446\u0438\u0444\u0440\u044b, \u0435\u0434\u0438\u043d\u0438\u0446\u044b \u0438 \u043e\u0442\u0441\u0442\u0443\u043f\u044b \u043c\u0435\u043d\u044f\u044e\u0442\u0441\u044f \u0432\u043c\u0435\u0441\u0442\u0435. \u041e\u0441\u0442\u0430\u043b\u044c\u043d\u044b\u0435 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u044f\u044e\u0442 \u0441\u0432\u043e\u0439 \u043c\u0430\u0441\u0448\u0442\u0430\u0431."

    :goto_2
    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v4

    iget v4, v4, Lc/r4;->e:I

    const/16 v5, 0xe

    const/4 v8, 0x0

    invoke-static {v7, v3, v5, v8, v4}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v7, v0, v2}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const-string v2, "\u0413\u043e\u0442\u043e\u0432\u043e"

    const/4 v3, 0x1

    invoke-static {v7, v2, v3}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Lc/c;

    const/4 v5, 0x3

    invoke-direct {v4, v6, v5}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    if-nez v1, :cond_3

    const-string v1, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431 \u0432\u0441\u0435\u0445 \u043f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0435\u0439"

    goto :goto_3

    :cond_3
    move-object/from16 v4, p5

    invoke-virtual {v4, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    :goto_3
    new-array v3, v3, [Landroid/view/View;

    const/4 v4, 0x0

    aput-object v2, v3, v4

    invoke-static {v7, v3}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v2

    const/4 v3, 0x0

    move-object/from16 p2, p0

    move-object/from16 p3, v1

    move-object/from16 p4, v0

    move-object/from16 p5, v2

    move-object/from16 p6, v6

    move/from16 p7, v3

    invoke-static/range {p1 .. p7}, Lc/G8;->J0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Ljava/lang/Runnable;Z)V

    return-void
.end method

.method public static M(II)Z
    .locals 0

    if-le p1, p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;
    .locals 1

    new-instance v0, Landroid/widget/SeekBar;

    invoke-direct {v0, p0}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p0

    invoke-static {v0, p0}, Lc/G8;->N0(Landroid/widget/SeekBar;Lc/r4;)V

    return-object v0
.end method

.method public static N(Ljava/lang/String;)Z
    .locals 1

    const-string v0, "__launcher_phone__"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "__launcher_music__"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static N0(Landroid/widget/SeekBar;Lc/r4;)V
    .locals 11

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/high16 v3, 0x42400000    # 48.0f

    invoke-static {v2, v3}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-virtual {p0, v3}, Landroid/view/View;->setMinimumHeight(I)V

    const/high16 v3, 0x41400000    # 12.0f

    invoke-static {v2, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-static {v2, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {p0, v4, v1, v5, v1}, Landroid/view/View;->setPadding(IIII)V

    iget v4, p1, Lc/r4;->h:I

    const/high16 v5, 0x40000000    # 2.0f

    invoke-static {v2, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-static {v4, v6}, Lc/G8;->x0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    const/high16 v6, 0x3f800000    # 1.0f

    invoke-static {v2, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    const/high16 v8, 0x40800000    # 4.0f

    invoke-static {v2, v8}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v4, v7, v9}, Landroid/graphics/drawable/GradientDrawable;->setSize(II)V

    invoke-static {v2, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    iget v7, p1, Lc/r4;->l:I

    invoke-static {v7, v5}, Lc/G8;->x0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-static {v2, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-static {v2, v8}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v5, v6, v9}, Landroid/graphics/drawable/GradientDrawable;->setSize(II)V

    new-instance v6, Landroid/graphics/drawable/LayerDrawable;

    new-instance v9, Landroid/graphics/drawable/ClipDrawable;

    const/4 v10, 0x3

    invoke-direct {v9, v5, v10, v0}, Landroid/graphics/drawable/ClipDrawable;-><init>(Landroid/graphics/drawable/Drawable;II)V

    const/4 v5, 0x2

    new-array v5, v5, [Landroid/graphics/drawable/Drawable;

    aput-object v4, v5, v1

    aput-object v9, v5, v0

    invoke-direct {v6, v5}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    invoke-static {v2, v8}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v6, v1, v4}, Landroid/graphics/drawable/LayerDrawable;->setLayerHeight(II)V

    invoke-static {v2, v8}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v6, v0, v4}, Landroid/graphics/drawable/LayerDrawable;->setLayerHeight(II)V

    const/16 v4, 0x10

    invoke-virtual {v6, v1, v4}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    invoke-virtual {v6, v0, v4}, Landroid/graphics/drawable/LayerDrawable;->setLayerGravity(II)V

    const/high16 v4, 0x1020000

    invoke-virtual {v6, v1, v4}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    const v4, 0x102000d

    invoke-virtual {v6, v0, v4}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    invoke-virtual {p0, v6}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    iget v0, p1, Lc/r4;->h:I

    invoke-static {v0, v7, v7}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object v4

    invoke-virtual {p0, v4}, Landroid/widget/ProgressBar;->setProgressTintList(Landroid/content/res/ColorStateList;)V

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/widget/ProgressBar;->setProgressBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/high16 v0, 0x40c00000    # 6.0f

    invoke-static {v2, v0}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    iget v5, p1, Lc/r4;->d:I

    invoke-static {v5, v4}, Lc/G8;->x0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-static {v2, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-static {v2, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    invoke-virtual {v4, v6, v3}, Landroid/graphics/drawable/GradientDrawable;->setSize(II)V

    invoke-virtual {p0, v4}, Landroid/widget/AbsSeekBar;->setThumb(Landroid/graphics/drawable/Drawable;)V

    invoke-static {v2, v0}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/AbsSeekBar;->setThumbOffset(I)V

    iget p1, p1, Lc/r4;->e:I

    invoke-static {p1, v5, v5}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/AbsSeekBar;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    invoke-virtual {p0, v1}, Landroid/widget/AbsSeekBar;->setSplitTrack(Z)V

    return-void
.end method

.method public static O(Landroid/widget/TextView;Lc/r4;)V
    .locals 2

    const/high16 v0, 0x41800000    # 16.0f

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    iget v0, p1, Lc/r4;->e:I

    iget p1, p1, Lc/r4;->d:I

    invoke-static {v0, p1, p1}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public static O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V
    .locals 10

    move-object v0, p0

    const/4 v1, 0x6

    new-array v2, v1, [F

    fill-array-data v2, :array_0

    new-array v3, v1, [I

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_0

    const/high16 v5, 0x437f0000    # 255.0f

    mul-float v5, v5, p9

    aget v6, v2, v4

    mul-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    shl-int/lit8 v5, v5, 0x18

    const v6, 0xffffff

    and-int v6, p8, v6

    or-int/2addr v5, v6

    aput v5, v3, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/graphics/Canvas;->save()I

    move-result v2

    move v4, p2

    int-to-float v4, v4

    mul-float v5, p4, v4

    const v6, 0x44ef2000    # 1913.0f

    div-float/2addr v5, v6

    move v7, p3

    int-to-float v7, v7

    mul-float v8, p5, v7

    const v9, 0x4482e000    # 1047.0f

    div-float/2addr v8, v9

    invoke-virtual {p0, v5, v8}, Landroid/graphics/Canvas;->translate(FF)V

    mul-float v4, v4, p6

    div-float/2addr v4, v6

    mul-float v5, p7, v7

    div-float/2addr v5, v9

    invoke-virtual {p0, v4, v5}, Landroid/graphics/Canvas;->scale(FF)V

    new-instance v4, Landroid/graphics/RadialGradient;

    new-array v1, v1, [F

    fill-array-data v1, :array_1

    sget-object v5, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v6, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    move-object p2, v4

    move p3, v8

    move p4, v6

    move p5, v7

    move-object/from16 p6, v3

    move-object/from16 p7, v1

    move-object/from16 p8, v5

    invoke-direct/range {p2 .. p8}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    move-object v1, p1

    invoke-virtual {p1, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/high16 v3, -0x40800000    # -1.0f

    const/high16 v4, -0x40800000    # -1.0f

    const/high16 v5, 0x3f800000    # 1.0f

    const/high16 v6, 0x3f800000    # 1.0f

    move-object p2, p0

    move p3, v3

    move p4, v4

    move p5, v5

    move/from16 p6, v6

    move-object/from16 p7, p1

    invoke-virtual/range {p2 .. p7}, Landroid/graphics/Canvas;->drawOval(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {p0, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    return-void

    nop

    :array_0
    .array-data 4
        0x3f800000    # 1.0f
        0x3f75c28f    # 0.96f
        0x3f428f5c    # 0.76f
        0x3edc28f6    # 0.43f
        0x3df5c28f    # 0.12f
        0x0
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x3e4ccccd    # 0.2f
        0x3ecccccd    # 0.4f
        0x3f19999a    # 0.6f
        0x3f4ccccd    # 0.8f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public static P(Landroid/content/Context;)Lc/a;
    .locals 4

    new-instance v0, Lc/a;

    const-string v1, "\u041c\u0443\u0437\u044b\u043a\u0430"

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f03001e

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    invoke-virtual {v2, v3, p0}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v2, 0x0

    const-string v3, "__launcher_music__"

    invoke-direct {v0, v3, v1, p0, v2}, Lc/a;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;Landroid/content/ComponentName;)V

    return-object v0
.end method

.method public static P0()Ljava/util/List;
    .locals 19

    const-string v0, "ATAT"

    const-string v1, "1"

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v15, "2212010401"

    const-string v16, "221201"

    const-string v2, "ATD"

    const-string v3, "ATD0"

    const-string v4, "ATE0"

    const-string v5, "ATH1"

    const-string v6, "ATM0"

    const-string v7, "ATS0"

    const-string v9, "ATSP5"

    const-string v10, "ATAL"

    const-string v11, "ATIB10"

    const-string v12, "ATSH8110FC"

    const-string v13, "ATST20"

    const-string v14, "ATSW05"

    const-string v17, "ATSW05"

    const-string v18, "ATWM221201"

    filled-new-array/range {v2 .. v18}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public static Q(Landroid/content/Context;)Lc/a;
    .locals 4

    new-instance v0, Lc/a;

    const-string v1, "\u0422\u0435\u043b\u0435\u0444\u043e\u043d"

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f03001f

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    invoke-virtual {v2, v3, p0}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v2, 0x0

    const-string v3, "__launcher_phone__"

    invoke-direct {v0, v3, v1, p0, v2}, Lc/a;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;Landroid/content/ComponentName;)V

    return-object v0
.end method

.method public static Q0(Ljava/lang/String;)Ljava/util/List;
    .locals 5

    if-nez p0, :cond_0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v1, "[;\\r\\n\\\\]+"

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, p0, v2

    invoke-static {v3}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public static R(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    if-nez p0, :cond_0

    const/4 v0, -0x1

    goto :goto_0

    :cond_0
    const-string v0, "|"

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    :goto_0
    if-gez v0, :cond_1

    goto :goto_1

    :cond_1
    const/4 v1, 0x0

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0
.end method

.method public static R0(III)Landroid/content/res/ColorStateList;
    .locals 2

    new-instance v0, Landroid/content/res/ColorStateList;

    sget-object v1, Lc/G8;->r:[[I

    filled-new-array {p0, p1, p2}, [I

    move-result-object p0

    invoke-direct {v0, v1, p0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    return-object v0
.end method

.method public static S(Lc/n7;[B)Z
    .locals 4

    invoke-virtual {p0}, Lc/n7;->a()I

    move-result v0

    const/4 v1, 0x0

    if-gez v0, :cond_3

    iget-object p0, p0, Lc/n7;->b:[B

    array-length v0, p0

    array-length v2, p1

    if-ge v0, v2, :cond_0

    goto :goto_1

    :cond_0
    move v0, v1

    :goto_0
    array-length v2, p1

    if-ge v0, v2, :cond_2

    aget-byte v2, p0, v0

    aget-byte v3, p1, v0

    if-eq v2, v3, :cond_1

    return v1

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_2
    const/4 p0, 0x1

    return p0

    :cond_3
    :goto_1
    return v1
.end method

.method public static S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;
    .locals 3

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p0

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result p1

    new-array v0, p1, [Ljava/lang/String;

    const/4 v1, 0x0

    :goto_0
    if-ge v1, p1, :cond_0

    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-object v0
.end method

.method public static T(Ljava/lang/String;ILjava/lang/String;Lc/v1;)Z
    .locals 4

    const-string v0, "/resources?"

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "&fields=size,sha256"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "GET"

    invoke-static {p0, v0, p3}, Lc/G8;->f(Ljava/lang/String;Ljava/lang/String;Lc/v1;)Lorg/json/JSONObject;

    move-result-object p0

    const-string p3, "size"

    const-wide/16 v0, -0x1

    invoke-virtual {p0, p3, v0, v1}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v0

    int-to-long v2, p1

    cmp-long p1, v0, v2

    if-nez p1, :cond_0

    const-string p1, "sha256"

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    return p0

    :catch_0
    move-exception p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Existing packet mismatch"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_0
    .catch Lc/q1; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    iget p1, p0, Lc/q1;->a:I

    const/16 p2, 0x194

    if-ne p1, p2, :cond_1

    const/4 p0, 0x0

    return p0

    :cond_1
    throw p0
.end method

.method public static T0(Landroid/widget/TextView;Ljava/lang/String;Lc/r4;Z)V
    .locals 1

    invoke-static {p0, p2, p3}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p3, :cond_0

    const-string p1, ", \u0432\u044b\u0431\u0440\u0430\u043d"

    goto :goto_0

    :cond_0
    const-string p1, ""

    :goto_0
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public static U(Lc/r0;F)F
    .locals 1

    iget p0, p0, Lc/r0;->f:I

    int-to-float p0, p0

    const/high16 v0, 0x42a00000    # 80.0f

    mul-float/2addr p0, v0

    const/high16 v0, 0x40c00000    # 6.0f

    div-float/2addr p0, v0

    const/high16 v0, 0x42400000    # 48.0f

    invoke-static {v0, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    mul-float/2addr p0, p1

    return p0
.end method

.method public static U0(Lc/r4;Lru/drivedeck/launcher/MainActivity;Z)Landroid/graphics/drawable/GradientDrawable;
    .locals 2

    iget v0, p0, Lc/r4;->b:I

    const/16 v1, 0x10

    invoke-static {p1, v0, v1}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    if-nez p2, :cond_0

    sget-object v1, Lc/r4;->p:Lc/r4;

    if-eq p0, v1, :cond_2

    :cond_0
    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {p1, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p1

    if-eqz p2, :cond_1

    iget p0, p0, Lc/r4;->f:I

    goto :goto_0

    :cond_1
    iget p0, p0, Lc/r4;->h:I

    :goto_0
    invoke-virtual {v0, p1, p0}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_2
    return-object v0
.end method

.method public static V(FFF)I
    .locals 1

    const/high16 v0, 0x41c00000    # 24.0f

    sub-float/2addr p0, v0

    const/high16 v0, 0x42e00000    # 112.0f

    div-float/2addr p0, v0

    const/high16 v0, 0x41600000    # 14.0f

    sub-float/2addr p1, v0

    const/high16 v0, 0x42c40000    # 98.0f

    div-float v0, p1, v0

    sub-float/2addr p1, p2

    const/high16 p2, 0x42280000    # 42.0f

    div-float/2addr p1, p2

    invoke-static {v0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    invoke-static {p0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/high16 p1, 0x42c80000    # 100.0f

    mul-float/2addr p0, p1

    float-to-double p0, p0

    invoke-static {p0, p1}, Ljava/lang/Math;->floor(D)D

    move-result-wide p0

    double-to-int p0, p0

    const/16 p1, 0xc8

    invoke-static {p1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 p1, 0x0

    invoke-static {p1, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method public static V0(Lc/r4;)I
    .locals 1

    iget-boolean v0, p0, Lc/r4;->m:Z

    if-eqz v0, :cond_0

    const p0, -0x171210

    goto :goto_0

    :cond_0
    sget-object v0, Lc/r4;->p:Lc/r4;

    if-ne p0, v0, :cond_1

    const p0, -0xcbcbcc

    goto :goto_0

    :cond_1
    iget p0, p0, Lc/r4;->h:I

    :goto_0
    return p0
.end method

.method public static W(Landroid/content/Context;Landroid/media/session/MediaSessionManager;Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/os/Handler;)V
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p1, p2, v0, p3}, Landroid/media/session/MediaSessionManager;->addOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/content/ComponentName;Landroid/os/Handler;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    new-instance v0, Landroid/content/ComponentName;

    const-class v1, Lru/drivedeck/launcher/NotificationBridgeService;

    invoke-direct {v0, p0, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, p2, v0, p3}, Landroid/media/session/MediaSessionManager;->addOnActiveSessionsChangedListener(Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/content/ComponentName;Landroid/os/Handler;)V

    :goto_0
    return-void
.end method

.method public static W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;
    .locals 1

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p0, p2

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, p4}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 p1, 0x1

    if-eqz p3, :cond_0

    const/4 p3, 0x0

    invoke-virtual {v0, p3, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_0
    const/16 p3, 0xb

    if-le p2, p3, :cond_1

    const p4, 0x3f4ccccd    # 0.8f

    mul-float/2addr p0, p4

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-static {p3, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 p3, 0x2

    invoke-virtual {v0, p0, p2, p1, p3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    :cond_1
    return-object v0
.end method

.method public static X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V
    .locals 7

    sget v2, Lc/G8;->B:I

    new-instance v0, Lc/n1;

    invoke-direct {v0, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->t0()J

    move-result-wide v3

    invoke-static {p0, v0}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Lc/d4;

    move-object v0, v6

    move-object v1, p0

    invoke-direct/range {v0 .. v5}, Lc/d4;-><init>(Landroid/content/Context;IJLjava/lang/String;)V

    new-instance v0, Lc/H;

    const/16 v1, 0xf

    invoke-direct {v0, v6, p2, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p1}, Lc/J;->d(Ljava/lang/String;)I

    move-result p1

    invoke-static {p0, p1, v0, v6}, Lc/J;->g(Landroid/content/Context;ILc/H;Ljava/util/function/BooleanSupplier;)Z

    move-result p0

    if-nez p0, :cond_0

    invoke-virtual {v0}, Lc/H;->run()V

    :cond_0
    return-void
.end method

.method public static X0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;FI)Landroid/widget/TextView;
    .locals 1

    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    return-object v0
.end method

.method public static Y(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    const/high16 v1, 0x10000000

    :try_start_0
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-static {p0, p1}, Lc/G8;->e0(Landroid/content/Context;Ljava/lang/String;)V

    :catch_0
    :cond_2
    :goto_0
    return-void
.end method

.method public static Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;
    .locals 1

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, p0}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p0

    invoke-static {v0, p0}, Lc/G8;->Z0(Landroid/widget/Switch;Lc/r4;)V

    invoke-virtual {v0, p2}, Landroid/widget/Switch;->setChecked(Z)V

    return-object v0
.end method

.method public static Z(Landroid/content/Context;Ljava/lang/String;)V
    .locals 12

    if-eqz p1, :cond_1a

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1a

    const-string v0, "com.syu.music"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_b

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    instance-of v1, p0, Lru/drivedeck/launcher/MainActivity;

    const/4 v2, 0x0

    if-eqz v1, :cond_6

    move-object v1, p0

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_1
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    :goto_0
    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eq v3, v4, :cond_2

    if-nez v3, :cond_3

    iget-boolean v5, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v5, :cond_3

    :cond_2
    if-eqz v4, :cond_3

    invoke-virtual {v4, p1}, Lc/Q3;->H(Ljava/lang/String;)Lc/t2;

    move-result-object v1

    goto :goto_1

    :cond_3
    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eq v3, v4, :cond_4

    if-nez v3, :cond_5

    iget-boolean v1, v1, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v1, :cond_5

    :cond_4
    if-eqz v4, :cond_5

    invoke-virtual {v4, p1}, Lc/m2;->B(Ljava/lang/String;)Lc/t2;

    move-result-object v1

    goto :goto_1

    :cond_5
    move-object v1, v2

    :goto_1
    if-eqz v1, :cond_6

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_6

    invoke-static {v0, p1}, Lc/G8;->e0(Landroid/content/Context;Ljava/lang/String;)V

    return-void

    :cond_6
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, p1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    if-nez v1, :cond_7

    return-void

    :cond_7
    :try_start_0
    const-string v3, "media_session"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/media/session/MediaSessionManager;

    if-eqz v3, :cond_a

    invoke-static {v0, v3}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_8
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_a

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/media/session/MediaController;

    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v5

    invoke-virtual {v4}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_8

    if-eqz v5, :cond_8

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v6, 0x3

    if-eq v4, v6, :cond_9

    invoke-virtual {v5}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v5, 0x6

    if-ne v4, v5, :cond_8

    goto :goto_4

    :catchall_0
    move-exception p0

    move-object v3, v2

    move-object v4, v3

    :goto_2
    move-object v11, v4

    goto/16 :goto_a

    :catch_0
    move-exception p0

    move-object v3, v2

    move-object v4, v3

    :goto_3
    move-object v11, v4

    goto/16 :goto_8

    :cond_9
    :goto_4
    return-void

    :cond_a
    sget-object v3, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    if-nez v3, :cond_f

    const-string v3, "display"

    invoke-virtual {v0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    move-object v4, v3

    check-cast v4, Landroid/hardware/display/DisplayManager;

    if-nez v4, :cond_b

    return-void

    :cond_b
    new-instance v3, Landroid/os/HandlerThread;

    const-string v5, "DriveDeck background player"

    invoke-direct {v3, v5}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    const/16 v5, 0x320

    const/16 v6, 0x1e0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v5, v6, v7, v8}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object v11
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    new-instance v5, Lc/e4;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    new-instance v6, Landroid/os/Handler;

    invoke-virtual {v3}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v7

    invoke-direct {v6, v7}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {v11, v5, v6}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V

    const-string v5, "DRIVEDECK-AUDIO"

    invoke-virtual {v11}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v9

    const/16 v7, 0x1e0

    const/16 v8, 0xa0

    const/16 v10, 0xa

    const/16 v6, 0x320

    invoke-virtual/range {v4 .. v10}, Landroid/hardware/display/DisplayManager;->createVirtualDisplay(Ljava/lang/String;IIILandroid/view/Surface;I)Landroid/hardware/display/VirtualDisplay;

    move-result-object v4
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    if-nez v4, :cond_e

    if-eqz v4, :cond_d

    sget-object p0, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    if-ne p0, v4, :cond_c

    sput-object v2, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    :cond_c
    invoke-virtual {v4}, Landroid/hardware/display/VirtualDisplay;->release()V

    :cond_d
    invoke-virtual {v11}, Landroid/media/ImageReader;->close()V

    invoke-virtual {v3}, Landroid/os/HandlerThread;->quitSafely()Z

    return-void

    :cond_e
    :try_start_3
    sput-object v4, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    goto :goto_5

    :catchall_1
    move-exception p0

    goto/16 :goto_a

    :catch_1
    move-exception p0

    goto :goto_8

    :catchall_2
    move-exception p0

    move-object v4, v2

    goto/16 :goto_a

    :catch_2
    move-exception p0

    move-object v4, v2

    goto :goto_8

    :catchall_3
    move-exception p0

    move-object v4, v2

    goto :goto_2

    :catch_3
    move-exception p0

    move-object v4, v2

    goto :goto_3

    :cond_f
    move-object v3, v2

    move-object v4, v3

    move-object v11, v4

    :goto_5
    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v5

    sget-object v6, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    invoke-virtual {v6}, Landroid/hardware/display/VirtualDisplay;->getDisplay()Landroid/view/Display;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/Display;->getDisplayId()I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/app/ActivityOptions;->setLaunchDisplayId(I)Landroid/app/ActivityOptions;

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    sget-object v7, Lc/j8;->a:Ljava/util/concurrent/ExecutorService;

    const/16 v7, 0x1b

    if-eq v6, v7, :cond_11

    const/16 v7, 0x1d

    if-lt v6, v7, :cond_10

    goto :goto_6

    :cond_10
    const/high16 v6, 0x10000000

    goto :goto_7

    :cond_11
    :goto_6
    const/high16 v6, 0x18000000

    :goto_7
    invoke-virtual {v1, v6}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v5}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object v5

    invoke-virtual {p0, v1, v5}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V

    invoke-static {v0, p1}, Lc/G8;->e0(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_9

    :goto_8
    :try_start_4
    const-string v0, "DriveDeckMusic"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Background player launch failed: "

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    if-eqz v4, :cond_13

    sget-object p0, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    if-ne p0, v4, :cond_12

    sput-object v2, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    :cond_12
    invoke-virtual {v4}, Landroid/hardware/display/VirtualDisplay;->release()V

    :cond_13
    if-eqz v11, :cond_14

    invoke-virtual {v11}, Landroid/media/ImageReader;->close()V

    :cond_14
    if-eqz v3, :cond_15

    invoke-virtual {v3}, Landroid/os/HandlerThread;->quitSafely()Z

    :cond_15
    :goto_9
    return-void

    :goto_a
    if-eqz v4, :cond_17

    sget-object p1, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    if-ne p1, v4, :cond_16

    sput-object v2, Lc/G8;->D:Landroid/hardware/display/VirtualDisplay;

    :cond_16
    invoke-virtual {v4}, Landroid/hardware/display/VirtualDisplay;->release()V

    :cond_17
    if-eqz v11, :cond_18

    invoke-virtual {v11}, Landroid/media/ImageReader;->close()V

    :cond_18
    if-eqz v3, :cond_19

    invoke-virtual {v3}, Landroid/os/HandlerThread;->quitSafely()Z

    :cond_19
    throw p0

    :cond_1a
    :goto_b
    return-void
.end method

.method public static Z0(Landroid/widget/Switch;Lc/r4;)V
    .locals 5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/high16 v2, 0x42400000    # 48.0f

    invoke-static {v0, v2}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-static {v0, v2}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/view/View;->setMinimumHeight(I)V

    const/16 v4, 0x10

    invoke-virtual {p0, v4}, Landroid/widget/TextView;->setGravity(I)V

    invoke-static {v0, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/widget/Switch;->setSwitchMinWidth(I)V

    invoke-static {v0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {p0, v4}, Landroid/widget/Switch;->setSwitchPadding(I)V

    invoke-virtual {p0, v3}, Landroid/widget/Switch;->setShowText(Z)V

    invoke-virtual {p0, v3}, Landroid/widget/Switch;->setSplitTrack(Z)V

    iget v3, p1, Lc/r4;->e:I

    iget v4, p1, Lc/r4;->d:I

    invoke-static {v3, v4, v4}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-virtual {p0, v3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    iget v3, p1, Lc/r4;->h:I

    const/4 v4, -0x1

    iget p1, p1, Lc/r4;->e:I

    invoke-static {v3, v4, p1}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/Switch;->setThumbTintList(Landroid/content/res/ColorStateList;)V

    const/high16 p1, 0x41000000    # 8.0f

    invoke-static {v0, p1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p1

    invoke-static {v4, p1}, Lc/G8;->x0(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-static {v0, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    invoke-static {v0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {p1, v2, v0}, Landroid/graphics/drawable/GradientDrawable;->setSize(II)V

    invoke-virtual {p0, p1}, Landroid/widget/Switch;->setTrackDrawable(Landroid/graphics/drawable/Drawable;)V

    const p1, 0xffffff

    and-int/2addr p1, v3

    const/high16 v0, 0x44000000    # 512.0f

    or-int/2addr v0, p1

    const/high16 v1, 0x66000000

    or-int/2addr p1, v1

    const v1, -0x9b4a0a

    invoke-static {v0, v1, p1}, Lc/G8;->R0(III)Landroid/content/res/ColorStateList;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/widget/Switch;->setTrackTintList(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public static a(Landroid/content/Context;F)I
    .locals 0

    invoke-static {p0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static a0(Ljava/lang/String;Ljava/lang/String;F)Ljava/lang/String;
    .locals 1

    const/high16 v0, 0x3f400000    # 0.75f

    invoke-static {v0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    const/high16 v0, 0x3e800000    # 0.25f

    invoke-static {v0, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "|"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a1(Landroid/content/Context;F)F
    .locals 2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/high16 v1, 0x42400000    # 48.0f

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    invoke-static {p0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p0

    invoke-static {v0, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    return p0
.end method

.method public static b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;
    .locals 2

    const/4 v0, 0x0

    :try_start_0
    invoke-virtual {p1, v0}, Landroid/media/session/MediaSessionManager;->getActiveSessions(Landroid/content/ComponentName;)Ljava/util/List;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    new-instance v0, Landroid/content/ComponentName;

    const-class v1, Lru/drivedeck/launcher/NotificationBridgeService;

    invoke-direct {v0, p0, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p1, v0}, Landroid/media/session/MediaSessionManager;->getActiveSessions(Landroid/content/ComponentName;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static b0(Ljava/lang/String;Ljava/lang/String;FII)Ljava/lang/String;
    .locals 1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p1, p2}, Lc/G8;->a0(Ljava/lang/String;Ljava/lang/String;F)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "|"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x78

    invoke-static {p1, p3}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/16 p3, 0x32

    invoke-static {p3, p2}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1, p4}, Ljava/lang/Math;->min(II)I

    move-result p0

    invoke-static {p3, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static b1(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "lt"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object p0, Lc/G8;->i:[Ljava/lang/String;

    invoke-static {p0, p1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p0

    if-gez p0, :cond_0

    goto :goto_0

    :cond_0
    sget-object p1, Lc/G8;->j:[Ljava/lang/String;

    aget-object p1, p1, p0

    :goto_0
    return-object p1

    :cond_1
    sget-object v0, Lc/G8;->k:[Ljava/lang/String;

    invoke-static {v0, p1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v0

    const-string v1, "en"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    sget-object p0, Lc/G8;->m:[[Ljava/lang/String;

    const/4 v1, 0x0

    aget-object p0, p0, v1

    goto :goto_1

    :cond_2
    const-string v1, "es"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    sget-object p0, Lc/G8;->m:[[Ljava/lang/String;

    const/4 v1, 0x1

    aget-object p0, p0, v1

    goto :goto_1

    :cond_3
    const-string v1, "vi"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    sget-object p0, Lc/G8;->m:[[Ljava/lang/String;

    const/4 v1, 0x2

    aget-object p0, p0, v1

    goto :goto_1

    :cond_4
    const-string v1, "zh-TW"

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5

    sget-object p0, Lc/G8;->l:[Ljava/lang/String;

    goto :goto_1

    :cond_5
    const/4 p0, 0x0

    :goto_1
    if-ltz v0, :cond_7

    if-nez p0, :cond_6

    goto :goto_2

    :cond_6
    aget-object p1, p0, v0

    :cond_7
    :goto_2
    return-object p1
.end method

.method public static c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V
    .locals 16

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    new-instance v9, Lc/n1;

    invoke-direct {v9, v6}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static/range {p0 .. p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v10

    invoke-virtual {v9, v8}, Lc/n1;->s0(Lc/s0;)Z

    move-result v0

    const-string v1, "\u0421\u0442\u0435\u043a\u043b\u044f\u043d\u043d\u044b\u0439 \u0444\u043e\u043d"

    invoke-static {v6, v1, v0}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v11

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v0, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v11, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget v0, v10, Lc/r4;->d:I

    const/16 v1, 0x10

    const/4 v2, 0x0

    const-string v3, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c "

    invoke-static {v6, v3, v1, v2, v0}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v14

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {v6, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v7, v14, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v9, v8}, Lc/n1;->W(Lc/s0;)I

    move-result v4

    new-instance v5, Lc/W0;

    const/4 v0, 0x1

    move-object/from16 v15, p3

    invoke-direct {v5, v9, v8, v15, v0}, Lc/W0;-><init>(Lc/n1;Lc/s0;Ljava/lang/Runnable;I)V

    const-string v2, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c "

    const-string v3, ""

    move-object/from16 v0, p0

    move-object v1, v14

    invoke-static/range {v0 .. v5}, Lc/G8;->d0(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;ILjava/util/function/IntConsumer;)Landroid/widget/SeekBar;

    move-result-object v5

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v0

    invoke-virtual {v5, v0}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v0

    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-static {v14, v10}, Lc/G8;->O(Landroid/widget/TextView;Lc/r4;)V

    const-string v0, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u0444\u043e\u043d\u0430 \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    invoke-static {v6, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v6, Lc/X0;

    move-object v0, v6

    move-object v1, v9

    move-object/from16 v2, p2

    move-object v3, v5

    move-object v4, v14

    move-object v8, v5

    move-object/from16 v5, p3

    invoke-direct/range {v0 .. v5}, Lc/X0;-><init>(Lc/n1;Lc/s0;Landroid/widget/SeekBar;Landroid/widget/TextView;Ljava/lang/Runnable;)V

    invoke-virtual {v11, v6}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v8, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static c0(Landroid/content/Context;Ljava/lang/String;)V
    .locals 6

    const-string v0, "DriveDeckMusic"

    if-eqz p1, :cond_5

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_4

    :cond_0
    const-class v1, Landroid/media/session/MediaSessionManager;

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/MediaSessionManager;

    if-nez v1, :cond_1

    return-void

    :cond_1
    :try_start_0
    invoke-static {p0, v1}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/MediaController;

    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2

    const-string v3, "com.android.bluetooth"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    const-string v3, "com.syu.bt"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v3, :cond_3

    goto :goto_0

    :catch_0
    move-exception p0

    goto :goto_3

    :cond_3
    :try_start_1
    invoke-virtual {v1}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v5, 0x3

    if-eq v4, v5, :cond_4

    invoke-virtual {v3}, Landroid/media/session/PlaybackState;->getState()I

    move-result v4

    const/4 v5, 0x6

    if-eq v4, v5, :cond_4

    invoke-virtual {v3}, Landroid/media/session/PlaybackState;->getState()I

    move-result v3

    const/16 v4, 0x8

    if-ne v3, v4, :cond_2

    goto :goto_1

    :catch_1
    move-exception v1

    goto :goto_2

    :cond_4
    :goto_1
    invoke-virtual {v1}, Landroid/media/session/MediaController;->getTransportControls()Landroid/media/session/MediaController$TransportControls;

    move-result-object v1

    invoke-virtual {v1}, Landroid/media/session/MediaController$TransportControls;->pause()V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :goto_2
    :try_start_2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Source switch pause failed: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_0

    :goto_3
    const-string p1, "Source switch sessions unavailable"

    invoke-static {v0, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_5
    :goto_4
    return-void
.end method

.method public static c1(Lc/v1;Ljava/lang/String;[B)V
    .locals 8

    invoke-virtual {p0}, Lc/v1;->a()Z

    move-result v0

    if-eqz v0, :cond_a

    const-string v0, "[A-Za-z0-9.-]{1,120}\\.dddiag"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9

    array-length v0, p2

    const/high16 v1, 0x40000

    if-gt v0, v1, :cond_9

    const-string v0, "app:/reports"

    invoke-static {v0, p0}, Lc/G8;->y(Ljava/lang/String;Lc/v1;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "app:/reports/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/v1;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p0}, Lc/G8;->y(Ljava/lang/String;Lc/v1;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "path="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "UTF-8"

    invoke-static {p1, v1}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2}, Lc/G8;->E0([B)Ljava/lang/String;

    move-result-object v0

    array-length v1, p2

    invoke-static {p1, v1, v0, p0}, Lc/G8;->T(Ljava/lang/String;ILjava/lang/String;Lc/v1;)Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "/resources/upload?"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "&overwrite=false"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "GET"

    invoke-static {v1, v2, p0}, Lc/G8;->f(Ljava/lang/String;Ljava/lang/String;Lc/v1;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "method"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "PUT"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    const-string v2, "templated"

    const/4 v4, 0x1

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_8

    const-string v2, "href"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/net/URI;

    invoke-direct {v2, v1}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/net/URI;->getHost()Ljava/lang/String;

    move-result-object v1

    const-string v5, "https"

    invoke-virtual {v2}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_7

    if-eqz v1, :cond_7

    invoke-virtual {v2}, Ljava/net/URI;->getRawUserInfo()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_7

    invoke-virtual {v2}, Ljava/net/URI;->getRawFragment()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_7

    invoke-virtual {v2}, Ljava/net/URI;->getPort()I

    move-result v5

    const/4 v6, -0x1

    if-eq v5, v6, :cond_1

    invoke-virtual {v2}, Ljava/net/URI;->getPort()I

    move-result v5

    const/16 v6, 0x1bb

    if-ne v5, v6, :cond_7

    :cond_1
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    const-string v7, ".disk.yandex.net"

    invoke-virtual {v6, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_2

    invoke-virtual {v1, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v5, ".disk.yandex.ru"

    invoke-virtual {v1, v5}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7

    :cond_2
    invoke-virtual {v2}, Ljava/net/URI;->toURL()Ljava/net/URL;

    move-result-object v1

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v1

    check-cast v1, Ljava/net/HttpURLConnection;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    const/16 v5, 0x1f40

    invoke-virtual {v1, v5}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/16 v5, 0x2ee0

    invoke-virtual {v1, v5}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {v1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/net/URLConnection;->setUseCaches(Z)V

    :try_start_0
    invoke-virtual {v1, v4}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const-string v2, "Content-Type"

    const-string v3, "application/octet-stream"

    invoke-virtual {v1, v2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    array-length v2, p2

    invoke-virtual {v1, v2}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    invoke-virtual {v1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v2, p2}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v2

    const/16 v3, 0xc9

    if-eq v2, v3, :cond_4

    const/16 v3, 0xca

    if-eq v2, v3, :cond_4

    const/16 v3, 0xc8

    if-ne v2, v3, :cond_3

    goto :goto_0

    :cond_3
    new-instance p0, Lc/q1;

    invoke-direct {p0, v2}, Lc/q1;-><init>(I)V

    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_4
    :goto_0
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    array-length p2, p2

    invoke-static {p1, p2, v0, p0}, Lc/G8;->T(Ljava/lang/String;ILjava/lang/String;Lc/v1;)Z

    move-result p0

    if-eqz p0, :cond_5

    return-void

    :cond_5
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Remote verification pending"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_1
    move-exception p0

    if-eqz v2, :cond_6

    :try_start_3
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_1

    :catchall_2
    move-exception p1

    :try_start_4
    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_6
    :goto_1
    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :goto_2
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p0

    :cond_7
    new-instance p0, Ljava/lang/SecurityException;

    const-string p1, "Untrusted upload destination"

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_8
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid upload link"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_9
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid packet"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a
    new-instance p0, Ljava/lang/SecurityException;

    const-string p1, "Profile expired"

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V
    .locals 6

    const/4 v0, 0x1

    :goto_0
    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p2, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    add-int/lit8 v3, v0, -0x1

    invoke-virtual {p2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout$LayoutParams;

    instance-of v1, v1, Landroid/widget/SeekBar;

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    move v1, v4

    goto :goto_1

    :cond_0
    const/high16 v1, 0x41000000    # 8.0f

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    :goto_1
    iget v5, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget v3, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    sub-int/2addr v1, v3

    invoke-static {v4, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-lez v1, :cond_2

    const/high16 v1, 0x41400000    # 12.0f

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    iput p0, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_2
    invoke-virtual {p1, p2, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static d0(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;ILjava/util/function/IntConsumer;)Landroid/widget/SeekBar;
    .locals 8

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "%"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p0}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v0

    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v0, p4}, Landroid/widget/ProgressBar;->setProgress(I)V

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {v0, p4}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance p4, Lc/Y0;

    const/4 v7, 0x0

    move-object v1, p4

    move-object v2, p1

    move-object v3, p0

    move-object v4, p2

    move-object v5, p3

    move-object v6, p5

    invoke-direct/range {v1 .. v7}, Lc/Y0;-><init>(Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v0, p4}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    return-object v0
.end method

.method public static d1(Ljava/lang/String;Ljava/lang/String;[BLc/I1;Lc/I1;)V
    .locals 0

    invoke-static {p0, p1, p2}, Lc/G8;->g1(Ljava/lang/String;Ljava/lang/String;[B)V

    :try_start_0
    invoke-virtual {p3}, Lc/I1;->a()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception p0

    if-eqz p4, :cond_4

    move-object p1, p0

    :goto_0
    if-eqz p1, :cond_4

    instance-of p2, p1, Lc/w1;

    if-eqz p2, :cond_0

    move-object p2, p1

    check-cast p2, Lc/w1;

    const/16 p3, 0x198

    iget p2, p2, Lc/w1;->a:I

    if-eq p2, p3, :cond_3

    const/16 p3, 0x1ad

    if-eq p2, p3, :cond_3

    const/16 p3, 0x1f4

    if-lt p2, p3, :cond_2

    const/16 p3, 0x257

    if-gt p2, p3, :cond_2

    goto :goto_1

    :cond_0
    instance-of p2, p1, Ljava/net/SocketTimeoutException;

    if-nez p2, :cond_3

    instance-of p2, p1, Ljava/net/UnknownHostException;

    if-nez p2, :cond_3

    instance-of p2, p1, Ljava/net/ConnectException;

    if-nez p2, :cond_3

    instance-of p2, p1, Ljava/net/NoRouteToHostException;

    if-nez p2, :cond_3

    instance-of p2, p1, Ljava/io/EOFException;

    if-eqz p2, :cond_1

    goto :goto_1

    :cond_1
    instance-of p2, p1, Ljava/net/SocketException;

    if-eqz p2, :cond_2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_2

    sget-object p3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p2, p3}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p2

    const-string p3, "connection reset"

    invoke-virtual {p2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p3

    if-nez p3, :cond_3

    const-string p3, "econnreset"

    invoke-virtual {p2, p3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    goto :goto_0

    :cond_3
    :goto_1
    invoke-virtual {p4}, Lc/I1;->a()V

    :goto_2
    return-void

    :cond_4
    throw p0
.end method

.method public static e(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Ljava/lang/String;ILjava/util/function/IntConsumer;)V
    .locals 9

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    iget v0, v0, Lc/r4;->d:I

    const/16 v1, 0x10

    const/4 v2, 0x0

    invoke-static {p0, p2, v1, v2, v0}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v4

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v6, ": "

    move-object v3, p0

    move-object v5, p2

    move v7, p3

    move-object v8, p4

    invoke-static/range {v3 .. v8}, Lc/G8;->d0(Lru/drivedeck/launcher/MainActivity;Landroid/widget/TextView;Ljava/lang/String;Ljava/lang/String;ILjava/util/function/IntConsumer;)Landroid/widget/SeekBar;

    move-result-object p0

    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p2, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p0, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static e0(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    sget v0, Lc/G8;->A:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lc/G8;->A:I

    new-instance v1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v2, Lc/f4;

    invoke-direct {v2, v0, p1, p0, v1}, Lc/f4;-><init>(ILjava/lang/String;Landroid/content/Context;Landroid/os/Handler;)V

    const-wide/16 p0, 0x3e8

    invoke-virtual {v1, v2, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static e1([BILjava/lang/String;)Z
    .locals 4

    const/4 v0, 0x0

    if-eqz p0, :cond_2

    if-nez p2, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    new-instance v2, Ljava/lang/String;

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v2, p0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p0, "size"

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    instance-of v2, p0, Ljava/lang/Integer;

    if-nez v2, :cond_1

    instance-of v2, p0, Ljava/lang/Long;

    if-nez v2, :cond_1

    return v0

    :cond_1
    check-cast p0, Ljava/lang/Number;

    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    move-result-wide v2

    int-to-long p0, p1

    cmp-long p0, v2, p0

    if-nez p0, :cond_2

    const-string p0, "sha256"

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p2, p0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p0, :cond_2

    const/4 v0, 0x1

    :catch_0
    :cond_2
    :goto_0
    return v0
.end method

.method public static f(Ljava/lang/String;Ljava/lang/String;Lc/v1;)Lorg/json/JSONObject;
    .locals 3

    new-instance v0, Ljava/net/URL;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "https://cloud-api.yandex.net/v1/disk"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p0

    check-cast p0, Ljava/net/HttpURLConnection;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    const/16 v1, 0x1f40

    invoke-virtual {p0, v1}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/16 v1, 0x2ee0

    invoke-virtual {p0, v1}, Ljava/net/URLConnection;->setReadTimeout(I)V

    invoke-virtual {p0, p1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Ljava/net/URLConnection;->setUseCaches(Z)V

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "OAuth "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p2, p2, Lc/v1;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "Authorization"

    invoke-virtual {p0, p2, p1}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "Accept"

    const-string p2, "application/json"

    invoke-virtual {p0, p1, p2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p1

    const/16 p2, 0xc8

    if-lt p1, p2, :cond_3

    const/16 p2, 0x12c

    if-ge p1, p2, :cond_3

    invoke-virtual {p0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/high16 p2, 0x10000

    :try_start_1
    invoke-static {p1, p2}, Lc/T8;->c(Ljava/io/InputStream;I)[B

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz p1, :cond_0

    :try_start_2
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_0
    :goto_0
    array-length p1, p2

    if-nez p1, :cond_1

    new-instance p1, Lorg/json/JSONObject;

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    goto :goto_1

    :cond_1
    new-instance p1, Lorg/json/JSONObject;

    new-instance v0, Ljava/lang/String;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v0, p2, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_1
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object p1

    :catchall_1
    move-exception p2

    if-eqz p1, :cond_2

    :try_start_3
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception p1

    :try_start_4
    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_2
    throw p2

    :cond_3
    new-instance p2, Lc/q1;

    invoke-direct {p2, p1}, Lc/q1;-><init>(I)V

    throw p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :goto_3
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p1
.end method

.method public static f0(Lc/s0;Lc/t0;)I
    .locals 6

    sget-object v0, Lc/s0;->b:Lc/s0;

    sget-object v1, Lc/t0;->d:Lc/t0;

    sget-object v2, Lc/t0;->c:Lc/t0;

    const/4 v3, 0x7

    if-ne p0, v0, :cond_2

    if-ne p1, v2, :cond_0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    if-ne p1, v1, :cond_1

    const/4 v3, 0x6

    :cond_1
    :goto_0
    return v3

    :cond_2
    sget-object v0, Lc/s0;->i:Lc/s0;

    const/16 v4, 0x1e

    const/16 v5, 0xf

    if-eq p0, v0, :cond_9

    sget-object v0, Lc/s0;->j:Lc/s0;

    if-ne p0, v0, :cond_3

    goto :goto_3

    :cond_3
    sget-object v0, Lc/s0;->g:Lc/s0;

    if-eq p0, v0, :cond_6

    sget-object v0, Lc/s0;->k:Lc/s0;

    if-ne p0, v0, :cond_4

    goto :goto_1

    :cond_4
    sget-object v0, Lc/s0;->e:Lc/s0;

    if-eq p0, v0, :cond_5

    sget-object p0, Lc/t0;->e:Lc/t0;

    if-ne p1, p0, :cond_5

    move v3, v5

    :cond_5
    return v3

    :cond_6
    :goto_1
    if-ne p1, v2, :cond_7

    move v4, v5

    goto :goto_2

    :cond_7
    if-ne p1, v1, :cond_8

    const/16 v4, 0x16

    :cond_8
    :goto_2
    return v4

    :cond_9
    :goto_3
    if-ne p1, v2, :cond_a

    goto :goto_4

    :cond_a
    if-ne p1, v1, :cond_b

    move v3, v5

    goto :goto_4

    :cond_b
    move v3, v4

    :goto_4
    return v3
.end method

.method public static f1(Lorg/json/JSONObject;Ljava/lang/String;)V
    .locals 6

    const-string v0, "ui_text_source"

    invoke-static {p0, v0}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    if-eqz v1, :cond_e

    const/4 v1, 0x1

    move v2, v1

    :goto_0
    array-length v3, v0

    if-ge v2, v3, :cond_1

    add-int/lit8 v3, v2, -0x1

    aget-object v3, v0, v3

    aget-object v4, v0, v2

    invoke-virtual {v3, v4}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v3

    if-gez v3, :cond_0

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Unsorted language keys"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    const-string v2, "zh-TW"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_2

    const-string v3, "zh_tw"

    goto :goto_1

    :cond_2
    move-object v3, p1

    :goto_1
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "ui_text_"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {p0, v3}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    array-length v3, v3

    array-length v0, v0

    if-ne v3, v0, :cond_d

    const-string v0, "ui_text_zh_tw_dynamic_source"

    invoke-static {p0, v0}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    :goto_2
    array-length v3, v0

    if-ge v1, v3, :cond_4

    add-int/lit8 v3, v1, -0x1

    aget-object v3, v0, v3

    aget-object v4, v0, v1

    invoke-virtual {v3, v4}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v3

    if-gez v3, :cond_3

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_3
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Unsorted dynamic keys"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    const-string v1, "lt"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    const-string v2, "ui_text_lt_dynamic"

    goto :goto_3

    :cond_5
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6

    const-string v2, "ui_text_zh_tw_dynamic"

    goto :goto_3

    :cond_6
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "ui_text_dynamic_"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_3
    const-string v3, "it"

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_9

    invoke-static {p0, v2}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    const-string p1, "ui_text_lt_dynamic_source"

    invoke-static {p0, p1}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    goto :goto_4

    :cond_7
    move-object p1, v0

    :goto_4
    array-length v1, v2

    array-length p1, p1

    if-ne v1, p1, :cond_8

    goto :goto_5

    :cond_8
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Unaligned dynamic language pack"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_9
    :goto_5
    const-string p1, "ui_text_diagnostic_keys"

    invoke-static {p0, p1}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v1, p1

    const-string v2, "ui_text_diagnostic_source"

    invoke-static {p0, v2}, Lc/G8;->S0(Lorg/json/JSONObject;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    array-length p0, p0

    if-ne v1, p0, :cond_c

    array-length p0, p1

    const/4 v1, 0x0

    :goto_6
    if-ge v1, p0, :cond_b

    aget-object v2, p1, v1

    invoke-static {v0, v2}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result v2

    if-ltz v2, :cond_a

    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_a
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Missing diagnostic key"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_b
    return-void

    :cond_c
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Unaligned diagnostic pack"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_d
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Unaligned language pack"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_e
    new-instance p0, Lorg/json/JSONException;

    const-string p1, "Empty language pack"

    invoke-direct {p0, p1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    new-instance v1, Ljava/io/FileInputStream;

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V

    const/16 p0, 0x2000

    :try_start_0
    new-array p0, p0, [B

    :goto_0
    invoke-virtual {v1, p0}, Ljava/io/FileInputStream;->read([B)I

    move-result v2

    const/4 v3, -0x1

    const/4 v4, 0x0

    if-eq v2, v3, :cond_0

    invoke-virtual {v0, p0, v4, v2}, Ljava/security/MessageDigest;->update([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_2

    :cond_0
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    const-string p0, "0123456789abcdef"

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/16 v1, 0x40

    new-array v1, v1, [C

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object v0

    :goto_1
    array-length v2, v0

    if-ge v4, v2, :cond_1

    mul-int/lit8 v2, v4, 0x2

    aget-byte v3, v0, v4

    ushr-int/lit8 v5, v3, 0x4

    and-int/lit8 v5, v5, 0xf

    aget-char v5, p0, v5

    aput-char v5, v1, v2

    add-int/lit8 v2, v2, 0x1

    and-int/lit8 v3, v3, 0xf

    aget-char v3, p0, v3

    aput-char v3, v1, v2

    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_1
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, v1}, Ljava/lang/String;-><init>([C)V

    return-object p0

    :goto_2
    :try_start_1
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception v0

    invoke-virtual {p0, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_3
    throw p0
.end method

.method public static g0(Lc/s0;Lc/t0;)I
    .locals 7

    sget-object v0, Lc/s0;->b:Lc/s0;

    sget-object v1, Lc/t0;->d:Lc/t0;

    sget-object v2, Lc/t0;->c:Lc/t0;

    if-ne p0, v0, :cond_2

    if-ne p1, v2, :cond_0

    const/4 p0, 0x5

    goto :goto_0

    :cond_0
    if-ne p1, v1, :cond_1

    const/16 p0, 0x8

    goto :goto_0

    :cond_1
    const/16 p0, 0xa

    :goto_0
    return p0

    :cond_2
    sget-object v0, Lc/s0;->i:Lc/s0;

    const/16 v3, 0x24

    const/16 v4, 0x12

    const/16 v5, 0xc

    if-eq p0, v0, :cond_f

    sget-object v0, Lc/s0;->j:Lc/s0;

    if-ne p0, v0, :cond_3

    goto :goto_4

    :cond_3
    sget-object v0, Lc/s0;->k:Lc/s0;

    const/4 v6, 0x6

    if-ne p0, v0, :cond_4

    return v6

    :cond_4
    sget-object v0, Lc/s0;->h:Lc/s0;

    if-ne p0, v0, :cond_7

    if-ne p1, v2, :cond_5

    move v4, v6

    goto :goto_1

    :cond_5
    if-ne p1, v1, :cond_6

    move v4, v5

    :cond_6
    :goto_1
    return v4

    :cond_7
    sget-object v0, Lc/s0;->g:Lc/s0;

    if-ne p0, v0, :cond_a

    if-ne p1, v2, :cond_8

    move v3, v6

    goto :goto_2

    :cond_8
    if-ne p1, v1, :cond_9

    move v3, v5

    :cond_9
    :goto_2
    return v3

    :cond_a
    sget-object v0, Lc/s0;->d:Lc/s0;

    if-eq p0, v0, :cond_d

    sget-object v0, Lc/s0;->e:Lc/s0;

    if-ne p0, v0, :cond_b

    goto :goto_3

    :cond_b
    if-ne p1, v2, :cond_c

    move v5, v6

    :cond_c
    return v5

    :cond_d
    :goto_3
    if-ne p1, v2, :cond_e

    move v4, v5

    :cond_e
    return v4

    :cond_f
    :goto_4
    if-ne p1, v2, :cond_10

    move v3, v5

    goto :goto_5

    :cond_10
    if-ne p1, v1, :cond_11

    move v3, v4

    :cond_11
    :goto_5
    return v3
.end method

.method public static g1(Ljava/lang/String;Ljava/lang/String;[B)V
    .locals 1

    if-eqz p0, :cond_0

    const-string v0, "[a-f0-9-]{36}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    if-eqz p1, :cond_0

    const-string p0, "[A-Za-z0-9.-]{1,120}\\.dddiag"

    invoke-virtual {p1, p0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    if-eqz p2, :cond_0

    array-length p0, p2

    const/high16 p1, 0x40000

    if-gt p0, p1, :cond_0

    array-length p0, p2

    const/16 p1, 0x2a

    if-lt p0, p1, :cond_0

    const/4 p0, 0x0

    aget-byte p0, p2, p0

    const/16 p1, 0x44

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    aget-byte p0, p2, p0

    if-ne p0, p1, :cond_0

    const/4 p0, 0x2

    aget-byte p0, p2, p0

    if-ne p0, p1, :cond_0

    const/4 p0, 0x3

    aget-byte p0, p2, p0

    const/16 p1, 0x49

    if-ne p0, p1, :cond_0

    const/4 p0, 0x4

    aget-byte p0, p2, p0

    const/16 p1, 0x41

    if-ne p0, p1, :cond_0

    const/4 p0, 0x5

    aget-byte p0, p2, p0

    const/16 p1, 0x47

    if-ne p0, p1, :cond_0

    const/4 p0, 0x6

    aget-byte p0, p2, p0

    const/16 p1, 0x30

    if-ne p0, p1, :cond_0

    const/4 p0, 0x7

    aget-byte p0, p2, p0

    const/16 p1, 0x31

    if-ne p0, p1, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Invalid packet"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static h(Landroid/widget/TextView;Lc/r4;Z)V
    .locals 7

    const v0, -0x101009e

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v1, 0x0

    new-array v2, v1, [I

    filled-new-array {v0, v2}, [[I

    move-result-object v0

    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    new-instance v3, Landroid/content/res/ColorStateList;

    iget-boolean v4, p1, Lc/r4;->m:Z

    if-eqz v4, :cond_0

    const v4, -0x120e0d

    goto :goto_0

    :cond_0
    iget v4, p1, Lc/r4;->b:I

    :goto_0
    if-eqz p2, :cond_1

    iget v5, p1, Lc/r4;->f:I

    goto :goto_1

    :cond_1
    invoke-static {p1}, Lc/G8;->V0(Lc/r4;)I

    move-result v5

    :goto_1
    filled-new-array {v4, v5}, [I

    move-result-object v4

    invoke-direct {v3, v0, v4}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    const v3, 0x461c4000    # 10000.0f

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v5, -0x1

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v3, 0x0

    invoke-virtual {p0, v3}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    new-instance v5, Landroid/graphics/drawable/RippleDrawable;

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v6

    invoke-direct {v5, v6, v2, v4}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    new-array v4, v1, [I

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0, v3}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    const/4 v2, 0x0

    invoke-virtual {p0, v2}, Landroid/view/View;->setElevation(F)V

    invoke-virtual {p0, v2}, Landroid/view/View;->setTranslationZ(F)V

    const/high16 v2, 0x41600000    # 14.0f

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {p0, v3, p2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    new-instance v2, Landroid/content/res/ColorStateList;

    if-eqz p2, :cond_2

    iget p2, p1, Lc/r4;->g:I

    goto :goto_2

    :cond_2
    iget p2, p1, Lc/r4;->d:I

    :goto_2
    iget p1, p1, Lc/r4;->e:I

    filled-new-array {p1, p2}, [I

    move-result-object p1

    invoke-direct {v2, v0, p1}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    instance-of p1, p0, Landroid/widget/Button;

    if-eqz p1, :cond_3

    move-object p1, p0

    check-cast p1, Landroid/widget/Button;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setAllCaps(Z)V

    :cond_3
    new-instance p1, Lc/e3;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Lc/e3;-><init>(I)V

    invoke-virtual {p0, p1}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    invoke-static {p0}, Lc/G8;->r(Landroid/widget/TextView;)V

    return-void
.end method

.method public static h0(I)Ljava/lang/String;
    .locals 1

    if-ltz p0, :cond_0

    const/16 v0, 0x9

    if-gt p0, v0, :cond_0

    const-string v0, "ATSP"

    invoke-static {v0, p0}, Lcom/hoho/android/usbserial/driver/a;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    const/16 v0, 0xa

    if-ne p0, v0, :cond_1

    const-string p0, "ATSPA"

    goto :goto_0

    :cond_1
    const-string p0, ""

    :goto_0
    return-object p0
.end method

.method public static h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "last_playback"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, ""

    invoke-interface {p0, p1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static i(Landroid/app/Activity;)Landroid/widget/LinearLayout;
    .locals 5

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/high16 v1, 0x41c00000    # 24.0f

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {v0, v2, v3, v4, p0}, Landroid/view/View;->setPadding(IIII)V

    return-object v0
.end method

.method public static i0(I)Ljava/lang/String;
    .locals 4

    const-string v0, "686AF1"

    packed-switch p0, :pswitch_data_0

    const-string v1, "8113F1"

    const-string v2, "7E0"

    const-string v3, "8013F1"

    packed-switch p0, :pswitch_data_1

    const-string p0, ""

    return-object p0

    :pswitch_0
    return-object v2

    :pswitch_1
    const-string p0, "8110F1"

    return-object p0

    :pswitch_2
    return-object v2

    :pswitch_3
    return-object v0

    :pswitch_4
    const-string p0, "8213F1"

    return-object p0

    :pswitch_5
    return-object v1

    :pswitch_6
    return-object v3

    :pswitch_7
    const-string p0, "8110FC"

    return-object p0

    :pswitch_8
    return-object v1

    :pswitch_9
    return-object v3

    :pswitch_a
    const-string p0, "8013FC"

    return-object p0

    :pswitch_b
    const-string p0, "8213F0"

    return-object p0

    :pswitch_c
    const-string p0, "8013F0"

    return-object p0

    :pswitch_d
    return-object v3

    :pswitch_e
    const-string p0, "DB33F1"

    return-object p0

    :pswitch_f
    const-string p0, "7DF"

    return-object p0

    :pswitch_10
    const-string p0, "C233F1"

    return-object p0

    :pswitch_11
    return-object v0

    :pswitch_12
    const-string p0, "616AF1"

    return-object p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_12
        :pswitch_11
        :pswitch_11
        :pswitch_10
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_f
        :pswitch_e
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x20
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;
    .locals 3

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    if-eqz p2, :cond_0

    iget v1, v0, Lc/r4;->g:I

    goto :goto_0

    :cond_0
    iget v1, v0, Lc/r4;->d:I

    :goto_0
    const/16 v2, 0xe

    invoke-static {p0, p1, v2, p2, v1}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object p0

    const/16 p1, 0x11

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setGravity(I)V

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Landroid/view/View;->setClickable(Z)V

    invoke-virtual {p0, p1}, Landroid/view/View;->setFocusable(Z)V

    invoke-static {p0, v0, p2}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    return-object p0
.end method

.method public static j0(Landroid/content/Context;F)F
    .locals 2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, v0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget v0, p0, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v0, v0

    iget v1, p0, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v0, v1

    iget p0, p0, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float p0, p0

    div-float/2addr p0, v1

    const v1, 0x448ee000    # 1143.0f

    div-float/2addr v0, v1

    const v1, 0x442b8000    # 686.0f

    div-float/2addr p0, v1

    invoke-static {v0, p0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-static {v0, p0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const v0, 0x3f333333    # 0.7f

    invoke-static {v0, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    mul-float/2addr p0, p1

    return p0
.end method

.method public static k(Lc/u0;IIFFZZ)Lc/o0;
    .locals 24

    move/from16 v0, p3

    const/4 v1, 0x0

    move/from16 v2, p1

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    move/from16 v3, p2

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-static/range {p0 .. p0}, Lc/u0;->r(Lc/u0;)Lc/u0;

    move-result-object v4

    const v5, 0x3dcccccd    # 0.1f

    invoke-static {v5, v0}, Ljava/lang/Math;->max(FF)F

    move-result v5

    const/high16 v6, 0x41400000    # 12.0f

    mul-float/2addr v6, v5

    invoke-static {v2, v3}, Lc/G8;->M(II)Z

    move-result v20

    const/high16 v7, 0x42100000    # 36.0f

    const/high16 v8, 0x42b80000    # 92.0f

    const/high16 v9, 0x42000000    # 32.0f

    int-to-float v10, v3

    if-eqz v20, :cond_1

    sub-float/2addr v10, v6

    if-eqz p5, :cond_0

    mul-float v11, v5, v9

    goto :goto_0

    :cond_0
    mul-float v11, v5, v8

    add-float/2addr v11, v6

    :goto_0
    sub-float/2addr v10, v11

    goto :goto_1

    :cond_1
    mul-float v11, v5, v7

    sub-float/2addr v10, v11

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    :goto_1
    mul-float/2addr v8, v5

    int-to-float v2, v2

    const/high16 v11, 0x40000000    # 2.0f

    mul-float/2addr v11, v6

    sub-float v11, v2, v11

    const/4 v12, 0x0

    invoke-static {v12, v11}, Ljava/lang/Math;->max(FF)F

    move-result v11

    invoke-static {v8, v11}, Ljava/lang/Math;->min(FF)F

    move-result v8

    if-eqz v20, :cond_2

    move v11, v6

    goto :goto_2

    :cond_2
    add-float v11, v6, v8

    add-float/2addr v11, v6

    :goto_2
    if-eqz v20, :cond_3

    sub-float v12, v2, v6

    goto :goto_3

    :cond_3
    const/high16 v12, 0x43820000    # 260.0f

    mul-float/2addr v12, v5

    add-float/2addr v12, v11

    const v13, 0x3f1c28f6    # 0.61f

    mul-float/2addr v13, v2

    sub-float v14, v2, v6

    const/high16 v15, 0x438c0000    # 280.0f

    mul-float/2addr v15, v5

    sub-float/2addr v14, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->min(FF)F

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    move-result v12

    :goto_3
    invoke-static {v6, v12}, Ljava/lang/Math;->max(FF)F

    move-result v12

    sub-float v13, v2, v6

    const/high16 v14, 0x42f00000    # 120.0f

    mul-float/2addr v14, v5

    sub-float v14, v13, v14

    invoke-static {v6, v14}, Ljava/lang/Math;->max(FF)F

    move-result v14

    invoke-static {v12, v14}, Ljava/lang/Math;->min(FF)F

    move-result v12

    new-instance v14, Lc/m0;

    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    move-result v15

    int-to-float v3, v3

    sub-float v1, v3, v6

    invoke-static {v6, v1}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-direct {v14, v12, v6, v15, v7}, Lc/m0;-><init>(FFFF)V

    if-eqz v20, :cond_4

    new-instance v7, Lc/m0;

    sub-float v8, v1, v8

    invoke-direct {v7, v6, v8, v13, v1}, Lc/m0;-><init>(FFFF)V

    :goto_4
    move-object v15, v7

    goto :goto_5

    :cond_4
    new-instance v7, Lc/m0;

    add-float/2addr v8, v6

    invoke-direct {v7, v6, v6, v8, v1}, Lc/m0;-><init>(FFFF)V

    goto :goto_4

    :goto_5
    if-eqz v20, :cond_5

    goto :goto_6

    :cond_5
    if-eqz p5, :cond_6

    mul-float/2addr v9, v5

    goto :goto_7

    :cond_6
    :goto_6
    move v9, v11

    :goto_7
    const/high16 v7, 0x41000000    # 8.0f

    mul-float/2addr v7, v5

    add-float/2addr v9, v7

    sub-float/2addr v12, v6

    invoke-static {v9, v12}, Ljava/lang/Math;->max(FF)F

    move-result v8

    invoke-static {v9, v8}, Ljava/lang/Math;->max(FF)F

    move-result v8

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    const/16 v17, 0x1

    if-nez v20, :cond_8

    add-float v18, v11, v7

    sub-float v12, v12, v18

    const/high16 v18, 0x43700000    # 240.0f

    mul-float v18, v18, p4

    cmpg-float v12, v12, v18

    if-gez v12, :cond_7

    goto :goto_8

    :cond_7
    const/4 v12, 0x0

    goto :goto_9

    :cond_8
    :goto_8
    move/from16 v12, v17

    :goto_9
    if-eqz v12, :cond_9

    sub-float v8, v10, v6

    const v14, 0x3ee147ae    # 0.44f

    mul-float/2addr v8, v14

    add-float/2addr v8, v6

    new-instance v14, Lc/m0;

    add-float/2addr v11, v7

    add-float v7, v8, v6

    move/from16 p1, v1

    invoke-static {v11, v13}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-static {v7, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    invoke-direct {v14, v11, v7, v1, v10}, Lc/m0;-><init>(FFFF)V

    new-instance v1, Lc/m0;

    invoke-static {v9, v13}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-direct {v1, v9, v6, v7, v8}, Lc/m0;-><init>(FFFF)V

    goto :goto_a

    :cond_9
    move/from16 p1, v1

    new-instance v1, Lc/m0;

    iget v7, v14, Lc/m0;->d:F

    invoke-direct {v1, v9, v6, v8, v7}, Lc/m0;-><init>(FFFF)V

    :goto_a
    iget v7, v15, Lc/m0;->b:F

    if-eqz v20, :cond_a

    move v8, v6

    goto :goto_b

    :cond_a
    move v8, v7

    :goto_b
    if-eqz v20, :cond_c

    if-eqz p5, :cond_b

    move/from16 v7, p1

    goto :goto_c

    :cond_b
    sub-float/2addr v7, v6

    invoke-static {v8, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    goto :goto_c

    :cond_c
    iget v7, v15, Lc/m0;->d:F

    :goto_c
    const/high16 v9, 0x41c00000    # 24.0f

    mul-float/2addr v9, v5

    new-instance v10, Lc/m0;

    if-eqz v20, :cond_d

    move v11, v9

    goto :goto_d

    :cond_d
    iget v11, v1, Lc/m0;->a:F

    invoke-static {v11, v9}, Ljava/lang/Math;->max(FF)F

    move-result v11

    :goto_d
    invoke-static {v8, v9}, Ljava/lang/Math;->max(FF)F

    move-result v8

    sub-float v13, v2, v9

    sub-float/2addr v3, v9

    invoke-static {v7, v3}, Ljava/lang/Math;->min(FF)F

    move-result v7

    invoke-direct {v10, v11, v8, v13, v7}, Lc/m0;-><init>(FFFF)V

    if-eqz p6, :cond_e

    new-instance v10, Lc/m0;

    invoke-direct {v10, v9, v9, v13, v3}, Lc/m0;-><init>(FFFF)V

    :cond_e
    move-object v3, v10

    const/high16 v7, 0x42400000    # 48.0f

    mul-float v7, v7, p4

    new-instance v13, Lc/m0;

    iget v8, v3, Lc/m0;->d:F

    sub-float v7, v8, v7

    iget v11, v3, Lc/m0;->a:F

    iget v9, v3, Lc/m0;->c:F

    invoke-direct {v13, v11, v7, v9, v8}, Lc/m0;-><init>(FFFF)V

    if-eqz v12, :cond_f

    if-nez v20, :cond_f

    move/from16 v21, v17

    goto :goto_e

    :cond_f
    const/16 v21, 0x0

    :goto_e
    new-instance v12, Ljava/util/EnumMap;

    const-class v10, Lc/s0;

    invoke-direct {v12, v10}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    if-eqz v20, :cond_10

    invoke-virtual {v3}, Lc/m0;->b()F

    move-result v5

    goto :goto_f

    :cond_10
    invoke-virtual {v3}, Lc/m0;->b()F

    move-result v7

    iget v8, v4, Lc/u0;->a:I

    int-to-float v9, v8

    mul-float/2addr v7, v9

    const/high16 v9, 0x42100000    # 36.0f

    div-float/2addr v7, v9

    mul-int/lit8 v8, v8, 0x50

    int-to-float v8, v8

    mul-float/2addr v8, v5

    const/high16 v5, 0x40c00000    # 6.0f

    div-float/2addr v8, v5

    sub-float/2addr v8, v6

    invoke-static {v7, v8}, Ljava/lang/Math;->max(FF)F

    move-result v5

    :goto_f
    new-instance v9, Lc/o0;

    iget v8, v4, Lc/u0;->a:I

    sget-object v22, Lc/Q1;->a:Lc/Q1;

    move-object v7, v9

    move/from16 v16, v8

    move-object v8, v15

    move-object/from16 p0, v1

    move-object v1, v9

    move-object v9, v14

    move-object/from16 p1, v1

    move-object v1, v10

    move-object v10, v3

    move/from16 v23, v11

    move-object v11, v13

    move-object/from16 p2, v12

    move-object/from16 p4, v13

    move/from16 v13, v21

    move-object/from16 p5, v14

    move/from16 v14, v20

    move-object/from16 p6, v15

    move/from16 v15, v16

    move/from16 v16, v5

    move-object/from16 v17, v22

    move/from16 v18, v2

    move/from16 v19, v6

    invoke-direct/range {v7 .. v19}, Lc/o0;-><init>(Lc/m0;Lc/m0;Lc/m0;Lc/m0;Ljava/util/EnumMap;ZZIFLc/Q1;FF)V

    sget-object v15, Lc/s0;->i:Lc/s0;

    iget-object v7, v4, Lc/u0;->d:Ljava/lang/Object;

    check-cast v7, Ljava/util/List;

    if-eqz v21, :cond_14

    new-instance v8, Ljava/util/EnumMap;

    invoke-direct {v8, v1}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    iget v7, v3, Lc/m0;->b:F

    move v9, v7

    :goto_10
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_12

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/r0;

    iget-boolean v11, v10, Lc/r0;->g:Z

    if-nez v11, :cond_11

    invoke-static {v10, v0}, Lc/G8;->U(Lc/r0;F)F

    move-result v11

    invoke-virtual {v3}, Lc/m0;->d()F

    move-result v12

    new-instance v13, Lc/m0;

    move/from16 v14, v23

    add-float/2addr v12, v14

    add-float v0, v9, v11

    invoke-direct {v13, v14, v9, v12, v0}, Lc/m0;-><init>(FFFF)V

    iget-object v0, v10, Lc/r0;->a:Lc/s0;

    invoke-virtual {v8, v0, v13}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-float/2addr v11, v6

    add-float/2addr v9, v11

    goto :goto_11

    :cond_11
    move/from16 v14, v23

    :goto_11
    move/from16 v0, p3

    move/from16 v23, v14

    goto :goto_10

    :cond_12
    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Ljava/util/EnumMap;->putAll(Ljava/util/Map;)V

    invoke-virtual {v0}, Ljava/util/EnumMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_12
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_13

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/m0;

    iget v8, v8, Lc/m0;->d:F

    sub-float/2addr v8, v7

    invoke-static {v5, v8}, Ljava/lang/Math;->max(FF)F

    move-result v5

    goto :goto_12

    :cond_13
    new-instance v1, Lc/o0;

    iget v14, v4, Lc/u0;->a:I

    move-object v7, v1

    move-object/from16 v8, p6

    move-object/from16 v9, p5

    move-object v10, v3

    move-object/from16 v11, p4

    move-object v12, v0

    move/from16 v13, v21

    move/from16 v16, v14

    move/from16 v14, v20

    move-object/from16 p1, v1

    move-object v1, v15

    move/from16 v15, v16

    move/from16 v16, v5

    move-object/from16 v17, v22

    move/from16 v18, v2

    move/from16 v19, v6

    invoke-direct/range {v7 .. v19}, Lc/o0;-><init>(Lc/m0;Lc/m0;Lc/m0;Lc/m0;Ljava/util/EnumMap;ZZIFLc/Q1;FF)V

    move-object/from16 v9, p1

    goto :goto_15

    :cond_14
    move-object/from16 v0, p2

    move-object v1, v15

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_13
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_16

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/r0;

    iget-boolean v9, v8, Lc/r0;->g:Z

    if-nez v9, :cond_15

    iget-object v9, v8, Lc/r0;->a:Lc/s0;

    if-eq v9, v1, :cond_15

    move-object/from16 v10, p1

    invoke-virtual {v10, v8}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v8

    invoke-virtual {v0, v9, v8}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_14

    :cond_15
    move-object/from16 v10, p1

    :goto_14
    move-object/from16 p1, v10

    goto :goto_13

    :cond_16
    move-object/from16 v10, p1

    move/from16 v16, v5

    move-object v9, v10

    :goto_15
    invoke-virtual {v4, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v5

    if-eqz v5, :cond_19

    iget-boolean v7, v5, Lc/r0;->g:Z

    if-eqz v7, :cond_17

    goto :goto_17

    :cond_17
    if-eqz v21, :cond_18

    invoke-virtual {v0, v1}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/m0;

    :goto_16
    move-object/from16 v14, p5

    goto :goto_18

    :cond_18
    invoke-virtual {v9, v5}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object v5

    goto :goto_16

    :cond_19
    :goto_17
    new-instance v5, Lc/m0;

    move-object/from16 v14, p5

    iget v7, v14, Lc/m0;->a:F

    iget v8, v14, Lc/m0;->b:F

    invoke-direct {v5, v7, v8, v7, v8}, Lc/m0;-><init>(FFFF)V

    :goto_18
    invoke-virtual {v0, v1, v5}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Lc/Q1;->b:Lc/Q1;

    iget-object v7, v4, Lc/u0;->b:Ljava/lang/Object;

    check-cast v7, Lc/Q1;

    if-ne v7, v1, :cond_1b

    move-object/from16 v7, p6

    invoke-virtual {v7, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v1

    invoke-virtual {v5, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v5

    invoke-virtual {v14, v2}, Lc/m0;->c(F)Lc/m0;

    move-object/from16 v7, p0

    invoke-virtual {v7, v2}, Lc/m0;->c(F)Lc/m0;

    invoke-virtual {v3, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v3

    move-object/from16 v8, p4

    invoke-virtual {v8, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v7

    invoke-virtual {v0}, Ljava/util/EnumMap;->entrySet()Ljava/util/Set;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_19
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_1a

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/m0;

    invoke-virtual {v10, v2}, Lc/m0;->c(F)Lc/m0;

    move-result-object v10

    invoke-interface {v9, v10}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_19

    :cond_1a
    move-object v8, v1

    move-object v10, v3

    move-object v9, v5

    move-object v11, v7

    goto :goto_1a

    :cond_1b
    move-object/from16 v8, p4

    move-object/from16 v7, p6

    move-object v10, v3

    move-object v9, v5

    move-object v11, v8

    move-object v8, v7

    :goto_1a
    new-instance v1, Lc/o0;

    iget v15, v4, Lc/u0;->a:I

    iget-object v3, v4, Lc/u0;->b:Ljava/lang/Object;

    move-object/from16 v17, v3

    check-cast v17, Lc/Q1;

    move-object v7, v1

    move-object v12, v0

    move/from16 v13, v21

    move/from16 v14, v20

    move/from16 v18, v2

    move/from16 v19, v6

    invoke-direct/range {v7 .. v19}, Lc/o0;-><init>(Lc/m0;Lc/m0;Lc/m0;Lc/m0;Ljava/util/EnumMap;ZZIFLc/Q1;FF)V

    return-object v1
.end method

.method public static k0(Lc/a;)Z
    .locals 3

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    iget-object v1, p0, Lc/a;->b:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "radio"

    iget-object p0, p0, Lc/a;->a:Ljava/lang/String;

    if-eqz p0, :cond_0

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const-string p0, "\u0440\u0430\u0434\u0438\u043e"

    invoke-virtual {v1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static l()V
    .locals 1

    sget v0, Lc/G8;->A:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lc/G8;->A:I

    sget v0, Lc/G8;->B:I

    add-int/lit8 v0, v0, 0x1

    sput v0, Lc/G8;->B:I

    return-void
.end method

.method public static l0(Ljava/lang/String;)F
    .locals 4

    const/high16 v0, 0x3f000000    # 0.5f

    if-nez p0, :cond_0

    return v0

    :cond_0
    const-string v1, "|"

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v2

    if-gez v2, :cond_1

    const/4 v2, -0x1

    goto :goto_0

    :cond_1
    add-int/lit8 v2, v2, 0x1

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v2

    :goto_0
    if-ltz v2, :cond_4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    if-lt v2, v3, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    :try_start_0
    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v1

    if-gez v1, :cond_3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    :cond_3
    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p0

    const/high16 v1, 0x3f400000    # 0.75f

    invoke-static {v1, p0}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/high16 v1, 0x3e800000    # 0.25f

    invoke-static {v1, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    :cond_4
    :goto_1
    return v0
.end method

.method public static m(Lc/z;Lc/n1;)Ljava/util/ArrayList;
    .locals 8

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    new-instance v2, Landroid/content/Intent;

    const-string v3, "android.intent.action.MAIN"

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v3, "android.intent.category.APP_MUSIC"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    iget-object v3, p0, Lc/z;->b:Landroid/content/pm/PackageManager;

    const/high16 v4, 0x20000

    invoke-virtual {v3, v2, v4}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/content/pm/ResolveInfo;

    iget-object v5, v5, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v5, v5, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    :try_start_0
    new-instance v2, Landroid/content/Intent;

    const-string v5, "android.media.browse.MediaBrowserService"

    invoke-direct {v2, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2, v4}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/pm/ResolveInfo;

    iget-object v4, v4, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-eqz v4, :cond_1

    iget-boolean v5, v4, Landroid/content/pm/ServiceInfo;->exported:Z

    if-eqz v5, :cond_1

    iget-object v4, v4, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    :cond_2
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lc/z;->c()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_3
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_6

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/a;

    :try_start_1
    iget-object v6, v5, Lc/a;->a:Ljava/lang/String;

    const/4 v7, 0x0

    invoke-virtual {v3, v6, v7}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v6

    iget v6, v6, Landroid/content/pm/ApplicationInfo;->category:I
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x1

    if-ne v6, v7, :cond_4

    goto :goto_3

    :catch_1
    :cond_4
    iget-object v6, v5, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v6}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    const-string v6, "com.syu.music"

    iget-object v7, v5, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    invoke-static {v5}, Lc/G8;->k0(Lc/a;)Z

    move-result v6

    if-nez v6, :cond_5

    const-string v6, "com.android.music"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    :cond_5
    :goto_3
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_6
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_4
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/a;

    iget-object v3, v2, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/HashSet;

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v2

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    const-string v3, "music_widget_added_sources"

    invoke-interface {p1, v3, v2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object p1

    invoke-direct {v1, p1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {p0}, Lc/z;->c()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_8
    :goto_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_9

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/a;

    iget-object v2, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v2, p1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v2, p1}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5

    :cond_9
    new-instance p0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    return-object p0
.end method

.method public static m0(Ljava/io/InputStream;I)Ljava/lang/String;
    .locals 6

    const/4 v0, 0x1

    if-lt p1, v0, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x1000

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    add-int/lit8 v2, p1, 0x1

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    new-array v3, v1, [C

    new-instance v4, Ljava/io/InputStreamReader;

    sget-object v5, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v4, p0, v5}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    :goto_0
    :try_start_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    if-gt p0, p1, :cond_1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    sub-int p0, v2, p0

    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v5, 0x0

    invoke-virtual {v4, v3, v5, p0}, Ljava/io/InputStreamReader;->read([CII)I

    move-result p0

    if-gez p0, :cond_0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v4}, Ljava/io/InputStreamReader;->close()V

    return-object p0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :try_start_1
    invoke-virtual {v0, v3, v5, p0}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :cond_1
    invoke-virtual {v4}, Ljava/io/InputStreamReader;->close()V

    new-instance p0, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Response exceeds "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " characters"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :goto_1
    :try_start_2
    invoke-virtual {v4}, Ljava/io/InputStreamReader;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception p1

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "maxChars must be positive"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;
    .locals 8

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const-string v3, "widget-settings-card"

    invoke-virtual {v1, v3}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    const/high16 v3, 0x41a00000    # 20.0f

    invoke-static {p0, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v4

    const/high16 v5, 0x41800000    # 16.0f

    invoke-static {p0, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-static {p0, v3}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v3

    invoke-static {p0, v5}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v5

    invoke-virtual {v1, v4, v6, v3, v5}, Landroid/view/View;->setPadding(IIII)V

    iget v3, v0, Lc/r4;->c:I

    const/16 v4, 0x10

    invoke-static {p0, v3, v4}, Lc/G8;->F0(Landroid/app/Activity;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    if-eqz p1, :cond_f

    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, p0}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const-string v5, "\u041e\u043a\u043d\u043e"

    invoke-virtual {p1, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    const v5, 0x7f03008f

    goto/16 :goto_6

    :cond_0
    const-string v5, "\u043e\u043a\u043d"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_e

    const-string v5, "\u041c\u0430\u0441\u0448\u0442\u0430\u0431"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_1

    goto/16 :goto_5

    :cond_1
    const-string v5, "\u0424\u043e\u043d"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_d

    const-string v5, "\u041e\u0442\u043e\u0431\u0440\u0430\u0436"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_d

    const-string v5, "\u041e\u0444\u043e\u0440\u043c"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_2

    goto/16 :goto_4

    :cond_2
    const-string v5, "\u041c\u0435\u0441\u0442\u043e\u043f\u043e\u043b\u043e\u0436"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_c

    const-string v5, "\u041d\u0430\u0432\u0438\u0433\u0430\u0446"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_3

    :cond_3
    const-string v5, "\u0421\u043a\u043e\u0440\u043e\u0441\u0442"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_4

    const v5, 0x7f030046

    goto :goto_6

    :cond_4
    const-string v5, "\u041f\u043e\u043a\u0430\u0437\u0430\u0442\u0435\u043b"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_b

    const-string v5, "\u041f\u043e\u0435\u0437\u0434"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_5

    goto :goto_2

    :cond_5
    const-string v5, "\u0427\u0430\u0441\u044b"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_a

    const-string v5, "\u0421\u0442\u0430\u0442\u0443\u0441"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_6

    goto :goto_1

    :cond_6
    const-string v5, "\u0412\u043e\u0441\u043f\u0440\u043e\u0438\u0437\u0432"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_9

    const-string v5, "\u041e\u0431\u043b\u043e\u0436"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_7

    goto :goto_0

    :cond_7
    const-string v5, "\u0412\u0438\u0434 \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_8

    const v5, 0x7f03004b

    goto :goto_6

    :cond_8
    const v5, 0x7f030052

    goto :goto_6

    :cond_9
    :goto_0
    const v5, 0x7f03004e

    goto :goto_6

    :cond_a
    :goto_1
    const v5, 0x7f030041

    goto :goto_6

    :cond_b
    :goto_2
    const v5, 0x7f030044

    goto :goto_6

    :cond_c
    :goto_3
    const v5, 0x7f030047

    goto :goto_6

    :cond_d
    :goto_4
    const v5, 0x7f03004f

    goto :goto_6

    :cond_e
    :goto_5
    const v5, 0x7f03004c

    :goto_6
    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    iget v0, v0, Lc/r4;->d:I

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/4 v5, 0x2

    invoke-virtual {v4, v5}, Landroid/view/View;->setImportantForAccessibility(I)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x41c00000    # 24.0f

    invoke-static {p0, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    invoke-static {p0, v6}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v6

    invoke-direct {v5, v7, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x12

    invoke-static {p0, p1, v4, v2, v0}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object p1

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, -0x2

    invoke-direct {v0, v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/high16 v2, 0x41600000    # 14.0f

    invoke-static {p0, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    iput p0, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    invoke-virtual {v3, p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance p0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 p1, -0x1

    invoke-direct {p0, p1, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v3, p0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_f
    return-object v1
.end method

.method public static n0(Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    const-string v0, "[a-f0-9]{64}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "schema"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v1, "apk_sha256"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "version"

    const-string v4, "0.6.7"

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "version_code"

    const/16 v4, 0x102

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "build_type"

    const-string v4, "system"

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    sget-object v3, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "manufacturer"

    invoke-virtual {v0, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "model"

    invoke-virtual {v0, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    const-string v3, "sdk"

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-static {}, Lc/G8;->C()Ljava/net/URI;

    move-result-object v4

    invoke-virtual {v4}, Ljava/net/URI;->toURL()Ljava/net/URL;

    move-result-object v4

    invoke-virtual {v4}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v4

    check-cast v4, Ljava/net/HttpURLConnection;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    const/16 v6, 0x2ee0

    invoke-virtual {v4, v6}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/16 v6, 0x61a8

    invoke-virtual {v4, v6}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const-string v6, "POST"

    invoke-virtual {v4, v6}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/net/URLConnection;->setDoOutput(Z)V

    invoke-virtual {v4, v5}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const-string v2, "Accept"

    const-string v5, "application/json"

    invoke-virtual {v4, v2, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "Content-Type"

    const-string v5, "application/json; charset=utf-8"

    invoke-virtual {v4, v2, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "User-Agent"

    const-string v5, "DriveDeck-Install/2"

    invoke-virtual {v4, v2, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "X-DriveDeck-Event"

    const-string v5, "build_seen"

    invoke-virtual {v4, v2, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "X-DriveDeck-Device"

    invoke-virtual {v4, v2, p0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    array-length v2, v0

    invoke-virtual {v4, v2}, Ljava/net/HttpURLConnection;->setFixedLengthStreamingMode(I)V

    :try_start_0
    invoke-virtual {v4}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    invoke-virtual {v2, v0}, Ljava/io/OutputStream;->write([B)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V

    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v0

    const/16 v2, 0xc8

    if-lt v0, v2, :cond_1

    const/16 v2, 0x12c

    if-ge v0, v2, :cond_1

    invoke-virtual {v4}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const/16 v2, 0x1000

    invoke-static {v0, v2}, Lc/T8;->c(Ljava/io/InputStream;I)[B

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v0, :cond_0

    :try_start_3
    new-instance v2, Lorg/json/JSONObject;

    new-instance v5, Ljava/lang/String;

    invoke-direct {v5, v0, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v2, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "device_id"

    invoke-virtual {v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    if-eqz p0, :cond_0

    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->disconnect()V

    return-void

    :catch_0
    :cond_0
    :try_start_4
    new-instance p0, Ljava/io/IOException;

    const-string p1, "Registration acknowledgement mismatch"

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_1
    new-instance p0, Lc/w1;

    invoke-direct {p0, v0}, Lc/w1;-><init>(I)V

    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catchall_1
    move-exception p0

    if-eqz v2, :cond_2

    :try_start_5
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_0

    :catchall_2
    move-exception p1

    :try_start_6
    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_0
    throw p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_1
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid installation identity"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static o(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, ""

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, " "

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "\t"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public static o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    if-eqz p2, :cond_3

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v0, "last_playback"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v0, ""

    if-nez p3, :cond_1

    move-object p3, v0

    :cond_1
    const-string v1, "source"

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const-string v3, "artist"

    const-string v4, "title"

    if-eqz v2, :cond_2

    invoke-interface {p0, v4, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p2, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {p0, v3, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    return-void

    :cond_2
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v4, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v3, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3
    :goto_0
    return-void
.end method

.method public static p(Landroid/widget/LinearLayout;I)V
    .locals 11

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p0, v0}, Lc/G8;->q(Landroid/view/View;Ljava/util/ArrayList;)V

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout;

    move-object v5, v4

    :goto_1
    if-eq v5, p0, :cond_2

    if-eqz v5, :cond_2

    instance-of v6, v5, Landroid/widget/LinearLayout;

    if-eqz v6, :cond_0

    invoke-virtual {v5}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    if-eqz v6, :cond_0

    move-object v6, v5

    check-cast v6, Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/widget/LinearLayout;->getOrientation()I

    move-result v7

    if-ne v7, v3, :cond_0

    goto :goto_2

    :cond_0
    invoke-virtual {v5}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    instance-of v6, v6, Landroid/view/View;

    if-eqz v6, :cond_1

    invoke-virtual {v5}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    check-cast v5, Landroid/view/View;

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    goto :goto_1

    :cond_2
    move-object v6, v4

    :goto_2
    invoke-virtual {v1, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/ArrayList;

    if-nez v3, :cond_3

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v1, v6, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    goto :goto_0

    :cond_4
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/ArrayList;

    new-instance v4, Landroid/widget/TextView;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const-string v5, "\u24d8"

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v5, 0x41a00000    # 20.0f

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextSize(F)V

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v5, 0x11

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    invoke-virtual {v4, v3}, Landroid/view/View;->setFocusable(Z)V

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    const-string v7, "\u0418\u043d\u0444\u043e\u0440\u043c\u0430\u0446\u0438\u044f"

    invoke-static {v6, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, ". "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    invoke-virtual {v7}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v5, Lc/c;

    const/16 v7, 0x9

    invoke-direct {v5, v1, v7}, Lc/c;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    const/high16 v5, 0x42400000    # 48.0f

    mul-float/2addr v1, v5

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    new-instance v5, Landroid/widget/LinearLayout;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v5, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x10

    invoke-virtual {v5, v7}, Landroid/widget/LinearLayout;->setGravity(I)V

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v7

    const/4 v8, -0x2

    if-lez v7, :cond_5

    invoke-virtual {v2, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v2, v7}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v9, v6, v8, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v5, v7, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_5
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v4, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v1, v4, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v5, v6, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    goto/16 :goto_3

    :cond_6
    return-void
.end method

.method public static p0(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 14

    const/4 v0, 0x0

    if-eqz p1, :cond_13

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_6

    :cond_0
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    const-string p0, "last_playback"

    invoke-virtual {v6, p0, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "player."

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "title"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, ""

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "artist"

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-interface {p0, v5, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "position"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const-wide/16 v10, -0x1

    invoke-interface {p0, v8, v10, v11}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v12

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_1

    const-string v8, "source"

    invoke-interface {p0, v8, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {p1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-interface {p0, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v7, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {p0, v9, v10, v11}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v12

    :cond_1
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const-wide/16 v7, 0x0

    if-nez v3, :cond_4

    cmp-long v3, v12, v7

    if-gez v3, :cond_2

    goto :goto_1

    :cond_2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "duration"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p0, v1, v10, v11}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v3

    cmp-long p0, v3, v7

    if-lez p0, :cond_3

    const-wide/16 v9, 0x3e8

    sub-long/2addr v3, v9

    invoke-static {v7, v8, v3, v4}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    invoke-static {v12, v13, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v12

    :cond_3
    new-instance p0, Lc/v1;

    invoke-direct {p0, v2, v5, v12, v13}, Lc/v1;-><init>(Ljava/lang/String;Ljava/lang/String;J)V

    :goto_0
    move-object v9, p0

    goto :goto_2

    :cond_4
    :goto_1
    const/4 p0, 0x0

    goto :goto_0

    :goto_2
    :try_start_0
    const-string p0, "media_session"

    invoke-virtual {v6, p0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/media/session/MediaSessionManager;

    const/4 v1, 0x1

    if-eqz p0, :cond_a

    invoke-static {v6, p0}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_5
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPlaybackState()Landroid/media/session/PlaybackState;

    move-result-object p0

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lc/i;

    const/16 v5, 0x8

    invoke-direct {v4, v2, v5}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-static {v6, v3, v4}, Lc/G8;->X(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Runnable;)V

    if-eqz p0, :cond_7

    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v2

    const/4 v3, 0x3

    if-eq v2, v3, :cond_6

    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getState()I

    move-result v2

    const/4 v3, 0x6

    if-ne v2, v3, :cond_7

    :cond_6
    return v1

    :cond_7
    if-eqz p0, :cond_8

    invoke-virtual {p0}, Landroid/media/session/PlaybackState;->getPosition()J

    move-result-wide v2

    cmp-long p0, v2, v7

    if-gtz p0, :cond_9

    :cond_8
    invoke-static {v6, p1, v9}, Lc/G8;->u0(Landroid/content/Context;Ljava/lang/String;Lc/v1;)V

    :cond_9
    return v1

    :cond_a
    const-string p0, "com.syu.music"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_c

    sget-object p0, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    if-eqz p0, :cond_b

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iget-wide v4, p0, Lc/w8;->f:J

    sub-long/2addr v2, v4

    const-wide/16 v4, 0x1388

    cmp-long p1, v2, v4

    if-gez p1, :cond_b

    iget-boolean p0, p0, Lc/w8;->h:Z

    if-nez p0, :cond_b

    const-string p0, "playpause"

    invoke-static {v6, p0}, Lru/drivedeck/launcher/StockMusicService;->a(Landroid/content/Context;Ljava/lang/String;)Z

    goto :goto_3

    :cond_b
    const-string p0, "Widget"

    invoke-static {v6, p0}, Lru/drivedeck/launcher/StockMusicService;->a(Landroid/content/Context;Ljava/lang/String;)Z

    :goto_3
    return v1

    :cond_c
    const-string p0, "com.syu.bt"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_12

    const-string p0, "com.android.bluetooth"

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_d

    goto :goto_5

    :cond_d
    const/16 p0, 0x7e

    invoke-static {v6, p1, p0}, Lc/G8;->D0(Landroid/content/Context;Ljava/lang/String;I)Z

    move-result p0

    if-eqz p0, :cond_e

    invoke-static {v6, p1, v9}, Lc/G8;->u0(Landroid/content/Context;Ljava/lang/String;Lc/v1;)V

    :cond_e
    invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.media.browse.MediaBrowserService"

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    invoke-virtual {v2, v3, v0}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_f
    :goto_4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_11

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/pm/ResolveInfo;

    iget-object v4, v3, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-eqz v4, :cond_f

    iget-boolean v4, v4, Landroid/content/pm/ServiceInfo;->exported:Z

    if-nez v4, :cond_10

    goto :goto_4

    :cond_10
    new-instance v10, Landroid/content/ComponentName;

    iget-object p0, v3, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object p0, p0, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-direct {v10, p1, p0}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {p0, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sget v3, Lc/G8;->B:I

    new-instance v2, Lc/n1;

    invoke-direct {v2, v6}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lc/n1;->t0()J

    move-result-wide v7

    new-instance v11, Lc/c4;

    move-object v2, v11

    move-object v4, p1

    move-object v5, p0

    invoke-direct/range {v2 .. v10}, Lc/c4;-><init>(ILjava/lang/String;Landroid/os/Handler;Landroid/content/Context;JLc/v1;Landroid/content/ComponentName;)V

    invoke-virtual {p0, v11}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return v1

    :cond_11
    return p0

    :cond_12
    :goto_5
    invoke-static {v6}, Lc/J;->b(Landroid/content/Context;)Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return p0

    :catch_0
    :cond_13
    :goto_6
    return v0
.end method

.method public static q(Landroid/view/View;Ljava/util/ArrayList;)V
    .locals 2

    instance-of v0, p0, Landroid/widget/TextView;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lc/G8;->w:Ljava/lang/Object;

    if-ne v0, v1, :cond_0

    check-cast p0, Landroid/widget/TextView;

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_1

    check-cast p0, Landroid/view/ViewGroup;

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1, p1}, Lc/G8;->q(Landroid/view/View;Ljava/util/ArrayList;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    return-void
.end method

.method public static q0(Lru/drivedeck/launcher/MainActivity;)V
    .locals 8

    const-string v0, "dock_auto_hide"

    const-string v1, "split_ratio"

    const-string v2, "drive_deck"

    const/4 v3, 0x0

    invoke-virtual {p0, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v2, "diagnostic_layout_snapshot"

    invoke-interface {p0, v2}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_0

    return-void

    :cond_0
    :try_start_0
    new-instance v4, Lorg/json/JSONObject;

    const-string v5, "{}"

    invoke-interface {p0, v2, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    sget-object v5, Lc/G8;->q:[Ljava/lang/String;

    :goto_0
    const/4 v6, 0x5

    if-ge v3, v6, :cond_2

    aget-object v6, v5, v3

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-interface {p0, v6, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_1

    :cond_1
    invoke-interface {p0, v6}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v4, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-virtual {v4, v1}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v5

    double-to-float v3, v5

    invoke-interface {p0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    goto :goto_2

    :cond_3
    invoke-interface {p0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_2
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->getBoolean(Ljava/lang/String;)Z

    move-result v1

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    goto :goto_3

    :cond_4
    invoke-interface {p0, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_3
    invoke-interface {p0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public static r(Landroid/widget/TextView;)V
    .locals 5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v2, 0x5

    if-gt v1, v2, :cond_0

    const/high16 v1, 0x41800000    # 16.0f

    goto :goto_0

    :cond_0
    const/high16 v1, 0x41c00000    # 24.0f

    :goto_0
    invoke-static {v0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x41000000    # 8.0f

    invoke-static {v1, v2}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v4

    invoke-static {v0, v4}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {p0, v2, v3, v0, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/high16 v1, 0x42400000    # 48.0f

    invoke-static {v0, v1}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {p0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    invoke-virtual {p0}, Landroid/widget/TextView;->getTextSize()F

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->scaledDensity:F

    div-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    const/16 v2, 0xb

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x2

    invoke-virtual {p0, v2, v1, v0, v3}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    return-void
.end method

.method public static r0(Lc/u0;Lc/r0;)Lc/u0;
    .locals 1

    invoke-virtual {p0, p1}, Lc/u0;->a(Lc/r0;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p0, p1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object p0

    return-object p0

    :cond_0
    invoke-virtual {p0, p1}, Lc/u0;->p(Lc/r0;)Lc/u0;

    move-result-object p0

    return-object p0
.end method

.method public static s(IILjava/lang/String;Z)Landroid/graphics/Bitmap;
    .locals 23

    move/from16 v10, p0

    move/from16 v11, p1

    move-object/from16 v0, p2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v10, v11, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v12

    new-instance v13, Landroid/graphics/Canvas;

    invoke-direct {v13, v12}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    new-instance v14, Landroid/graphics/Paint;

    const/4 v4, 0x5

    invoke-direct {v14, v4}, Landroid/graphics/Paint;-><init>(I)V

    sget-object v4, Lc/G8;->x:[Ljava/lang/String;

    const/4 v5, 0x2

    aget-object v6, v4, v5

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    if-eqz p3, :cond_0

    new-instance v0, Landroid/graphics/LinearGradient;

    int-to-float v8, v11

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v17, 0x0

    const v21, -0x8d8275

    const/16 v16, 0x0

    const/16 v18, 0x0

    const v20, -0x7d92a4

    move-object v15, v0

    move/from16 v19, v8

    invoke-direct/range {v15 .. v22}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    int-to-float v7, v10

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v4, v13

    move-object v9, v14

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const v8, -0x91b6d0

    const v9, 0x3f4ccccd    # 0.8f

    const/high16 v4, 0x43160000    # 150.0f

    const/high16 v5, 0x42b40000    # 90.0f

    const v6, 0x443b8000    # 750.0f

    const/high16 v7, 0x441b0000    # 620.0f

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x204283

    const v9, 0x3f6b851f    # 0.92f

    const/high16 v4, 0x43d20000    # 420.0f

    const/high16 v5, 0x44020000    # 520.0f

    const/high16 v6, 0x443e0000    # 760.0f

    const/high16 v7, 0x44160000    # 600.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x242831

    const v9, 0x3f70a3d7    # 0.94f

    const/high16 v4, 0x444d0000    # 820.0f

    const v5, 0x44548000    # 850.0f

    const/high16 v6, 0x442f0000    # 700.0f

    const/high16 v7, 0x43fa0000    # 500.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x36475c

    const v9, 0x3f5c28f6    # 0.86f

    const v4, 0x44924000    # 1170.0f

    const/high16 v5, 0x43200000    # 160.0f

    const/high16 v6, 0x442a0000    # 680.0f

    const v7, 0x44228000    # 650.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x342e34

    const v9, 0x3f666666    # 0.9f

    const v4, 0x44c08000    # 1540.0f

    const/high16 v5, 0x43d20000    # 420.0f

    const/high16 v6, 0x442f0000    # 700.0f

    const v7, 0x442c8000    # 690.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x625450

    const v9, 0x3f51eb85    # 0.82f

    const v4, 0x44ce4000    # 1650.0f

    const/high16 v5, 0x443e0000    # 760.0f

    const v6, 0x44368000    # 730.0f

    const/high16 v7, 0x44070000    # 540.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xb4ab8d

    const v9, 0x3f6e147b    # 0.93f

    const v4, 0x44884000    # 1090.0f

    const/high16 v5, 0x447f0000    # 1020.0f

    const/high16 v6, 0x44250000    # 660.0f

    const/high16 v7, 0x43f00000    # 480.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x8e999d

    const v9, 0x3f266666    # 0.65f

    const/high16 v4, 0x43af0000    # 350.0f

    const v5, 0x448fc000    # 1150.0f

    const/high16 v6, 0x440c0000    # 560.0f

    const/high16 v7, 0x441b0000    # 620.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    goto/16 :goto_0

    :cond_0
    new-instance v0, Landroid/graphics/LinearGradient;

    int-to-float v8, v11

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v17, 0x0

    const v21, -0xefeaef

    const/16 v16, 0x0

    const/16 v18, 0x0

    const v20, -0xf7e3d3

    move-object v15, v0

    move/from16 v19, v8

    invoke-direct/range {v15 .. v22}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v14, v0}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    int-to-float v7, v10

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v4, v13

    move-object v9, v14

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const v8, -0xebd69a

    const v9, 0x3f59999a    # 0.85f

    const/high16 v4, 0x432a0000    # 170.0f

    const/high16 v5, 0x43b90000    # 370.0f

    const v6, 0x44318000    # 710.0f

    const/high16 v7, 0x442f0000    # 700.0f

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xaba163

    const v9, 0x3f666666    # 0.9f

    const/high16 v4, 0x43d20000    # 420.0f

    const/high16 v5, 0x441b0000    # 620.0f

    const v6, 0x442c8000    # 690.0f

    const/high16 v7, 0x440c0000    # 560.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x79564c

    const v9, 0x3f2b851f    # 0.67f

    const/high16 v4, 0x442f0000    # 700.0f

    const/high16 v5, 0x444d0000    # 820.0f

    const/high16 v6, 0x43eb0000    # 470.0f

    const/high16 v7, 0x43af0000    # 350.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xa98664

    const v9, 0x3f6147ae    # 0.88f

    const/high16 v4, 0x448c0000    # 1120.0f

    const/high16 v5, 0x43340000    # 180.0f

    const v6, 0x44188000    # 610.0f

    const/high16 v7, 0x43f50000    # 490.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xbc838f

    const v9, 0x3f19999a    # 0.6f

    const v4, 0x44c1c000    # 1550.0f

    const/high16 v5, 0x43d70000    # 430.0f

    const v7, 0x44188000    # 610.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x968c63

    const v9, 0x3f4ccccd    # 0.8f

    const v4, 0x44f14000    # 1930.0f

    const/high16 v5, 0x43f00000    # 480.0f

    const/high16 v6, 0x44250000    # 660.0f

    const v7, 0x44548000    # 850.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x97bae8

    const v9, 0x3f3851ec    # 0.72f

    const/high16 v4, 0x44a00000    # 1280.0f

    const v5, 0x44834000    # 1050.0f

    const/high16 v6, 0x44110000    # 580.0f

    const v7, 0x44228000    # 650.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0x78ab8c

    const v9, 0x3f1c28f6    # 0.61f

    const v4, 0x44ed8000    # 1900.0f

    const/high16 v5, 0x448c0000    # 1120.0f

    const/high16 v6, 0x44200000    # 640.0f

    const/high16 v7, 0x44250000    # 660.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xf7f1f9

    const v9, 0x3f733333    # 0.95f

    const v4, 0x44098000    # 550.0f

    const v5, 0x448fc000    # 1150.0f

    const/high16 v6, 0x44110000    # 580.0f

    const/high16 v7, 0x43af0000    # 350.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    const v8, -0xfcefec

    const v9, 0x3f59999a    # 0.85f

    const/high16 v4, 0x44340000    # 720.0f

    const/high16 v5, 0x43200000    # 160.0f

    const/high16 v6, 0x44070000    # 540.0f

    const/high16 v7, 0x43be0000    # 380.0f

    invoke-static/range {v0 .. v9}, Lc/G8;->O0(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFIF)V

    :goto_0
    return-object v12

    :cond_1
    aget-object v4, v4, v3

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const v4, 0x3f051eb8    # 0.52f

    if-eqz p3, :cond_4

    if-eqz v0, :cond_2

    new-array v6, v1, [I

    const v7, -0xf080c

    aput v7, v6, v2

    const v7, -0x190e14

    aput v7, v6, v3

    const v7, -0x150e09

    aput v7, v6, v5

    goto :goto_1

    :cond_2
    new-array v6, v1, [I

    const v7, -0xb0d06

    aput v7, v6, v2

    const v7, -0x161109

    aput v7, v6, v3

    const v7, -0x120c10

    aput v7, v6, v5

    :goto_1
    if-eqz v0, :cond_3

    const/high16 v4, 0x3f000000    # 0.5f

    :cond_3
    :goto_2
    move-object/from16 v20, v6

    goto :goto_4

    :cond_4
    if-eqz v0, :cond_5

    new-array v6, v1, [I

    const v7, -0xefe4de

    aput v7, v6, v2

    const v7, -0xebdad6

    aput v7, v6, v3

    const v7, -0xe7dfd6

    aput v7, v6, v5

    goto :goto_3

    :cond_5
    new-array v6, v1, [I

    const v7, -0xede9da

    aput v7, v6, v2

    const v7, -0xe8e7d4

    aput v7, v6, v3

    const v7, -0xeee2d5

    aput v7, v6, v5

    :goto_3
    if-eqz v0, :cond_3

    const v4, 0x3f0a3d71    # 0.54f

    goto :goto_2

    :goto_4
    new-instance v6, Landroid/graphics/LinearGradient;

    int-to-float v7, v10

    int-to-float v8, v11

    new-array v1, v1, [F

    const/4 v9, 0x0

    aput v9, v1, v2

    aput v4, v1, v3

    const/high16 v2, 0x3f800000    # 1.0f

    aput v2, v1, v5

    sget-object v22, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v15, v6

    move/from16 v18, v7

    move/from16 v19, v8

    move-object/from16 v21, v1

    invoke-direct/range {v15 .. v22}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v14, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v4, v13

    move-object v9, v14

    invoke-virtual/range {v4 .. v9}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    if-eqz p3, :cond_6

    if-nez v0, :cond_6

    const/high16 v5, 0x437a0000    # 250.0f

    const v6, 0x44834000    # 1050.0f

    const/high16 v4, 0x43960000    # 300.0f

    const/high16 v7, 0x44430000    # 780.0f

    const v8, -0x5236480f

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    const/high16 v5, 0x44660000    # 920.0f

    const v6, 0x44778000    # 990.0f

    const/high16 v4, 0x44eb0000    # 1880.0f

    const/high16 v7, 0x44390000    # 740.0f

    const v8, -0x7356262e

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    goto/16 :goto_5

    :cond_6
    if-eqz p3, :cond_7

    const/high16 v5, 0x43660000    # 230.0f

    const v6, 0x44834000    # 1050.0f

    const v4, 0x44ed8000    # 1900.0f

    const/high16 v7, 0x44430000    # 780.0f

    const v8, -0x6e9d3858

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    const/high16 v5, 0x44700000    # 960.0f

    const v6, 0x44778000    # 990.0f

    const/high16 v4, 0x43d70000    # 430.0f

    const/high16 v7, 0x44390000    # 740.0f

    const v8, -0x7f8d5035

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    goto :goto_5

    :cond_7
    if-nez v0, :cond_8

    const/high16 v5, 0x43960000    # 300.0f

    const v6, 0x44834000    # 1050.0f

    const/high16 v4, 0x43d70000    # 430.0f

    const/high16 v7, 0x44430000    # 780.0f

    const v8, -0x75a69927

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    const v5, 0x445e8000    # 890.0f

    const v6, 0x44778000    # 990.0f

    const/high16 v4, 0x44f00000    # 1920.0f

    const/high16 v7, 0x44390000    # 740.0f

    const v8, 0x66b05bc1

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    goto :goto_5

    :cond_8
    const/high16 v5, 0x44660000    # 920.0f

    const v6, 0x44834000    # 1050.0f

    const/high16 v4, 0x43af0000    # 350.0f

    const/high16 v7, 0x44430000    # 780.0f

    const v8, -0x7fc75665

    move-object v0, v13

    move-object v1, v14

    move/from16 v2, p0

    move/from16 v3, p1

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    const/high16 v5, 0x43700000    # 240.0f

    const v6, 0x44778000    # 990.0f

    const v4, 0x44fc8000    # 2020.0f

    const/high16 v7, 0x44390000    # 740.0f

    const v8, 0x6b5487b4

    invoke-static/range {v0 .. v8}, Lc/G8;->K(Landroid/graphics/Canvas;Landroid/graphics/Paint;IIFFFFI)V

    :goto_5
    return-object v12
.end method

.method public static s0(Lc/u0;)Lc/u0;
    .locals 4

    sget-object v0, Lc/s0;->g:Lc/s0;

    invoke-virtual {p0, v0}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    if-eqz v1, :cond_0

    return-object p0

    :cond_0
    sget-object v1, Lc/s0;->f:Lc/s0;

    invoke-virtual {p0, v1}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v1

    if-nez v1, :cond_1

    move-object v1, p0

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1, v2, v3}, Lc/r0;->c(II)Lc/r0;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v1

    :goto_0
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v2

    invoke-virtual {v2, v0}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    invoke-virtual {v1, v0}, Lc/u0;->p(Lc/r0;)Lc/u0;

    move-result-object v0

    if-eqz v0, :cond_2

    move-object p0, v0

    :cond_2
    return-object p0
.end method

.method public static t(Landroid/graphics/Bitmap;FFII)Landroid/graphics/Bitmap;
    .locals 4

    int-to-float p3, p3

    mul-float/2addr p3, p1

    invoke-static {p3}, Ljava/lang/Math;->round(F)I

    move-result p3

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    new-instance v2, Landroid/graphics/BlurMaskFilter;

    mul-float/2addr p2, p1

    sget-object p1, Landroid/graphics/BlurMaskFilter$Blur;->NORMAL:Landroid/graphics/BlurMaskFilter$Blur;

    invoke-direct {v2, p2, p1}, Landroid/graphics/BlurMaskFilter;-><init>(FLandroid/graphics/BlurMaskFilter$Blur;)V

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    const/4 p1, 0x2

    new-array p1, p1, [I

    invoke-virtual {p0, v0, p1}, Landroid/graphics/Bitmap;->extractAlpha(Landroid/graphics/Paint;[I)Landroid/graphics/Bitmap;

    move-result-object p2

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    mul-int/lit8 v3, p3, 0x2

    add-int/2addr v2, v3

    invoke-virtual {p0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p0

    add-int/2addr p0, v3

    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, p0, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setMaskFilter(Landroid/graphics/MaskFilter;)Landroid/graphics/MaskFilter;

    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setColor(I)V

    new-instance p4, Landroid/graphics/Canvas;

    invoke-direct {p4, p0}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v2, 0x0

    aget v2, p1, v2

    add-int/2addr v2, p3

    int-to-float v2, v2

    aget p1, p1, v1

    add-int/2addr p3, p1

    int-to-float p1, p3

    invoke-virtual {p4, p2, v2, p1, v0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;FFLandroid/graphics/Paint;)V

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->recycle()V

    return-object p0
.end method

.method public static t0(Landroid/content/Context;)V
    .locals 9

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    new-instance v0, Lc/n1;

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    iget-object v3, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v3, Landroid/content/SharedPreferences;

    const-string v4, "resume_music_on_start"

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_0

    return-void

    :cond_0
    invoke-static {v1, v0}, Lc/G8;->v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    :cond_1
    new-instance v7, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v7, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sget v0, Lc/G8;->A:I

    add-int/lit8 v2, v0, 0x1

    sput v2, Lc/G8;->A:I

    new-instance v8, Lc/i4;

    move-object v0, v8

    move-object v3, v6

    move-object v4, v7

    move-object v5, p0

    invoke-direct/range {v0 .. v5}, Lc/i4;-><init>(Landroid/content/Context;ILjava/lang/String;Landroid/os/Handler;Landroid/content/Context;)V

    const-string p0, "com.syu.bt"

    invoke-virtual {v6, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    const-string p0, "com.syu.music"

    invoke-virtual {v6, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    goto :goto_0

    :cond_2
    const-wide/16 v0, 0x0

    goto :goto_1

    :cond_3
    :goto_0
    const-wide/16 v0, 0x7d0

    :goto_1
    invoke-virtual {v7, v8, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static u(Landroid/content/Context;)Landroid/widget/Button;
    .locals 2

    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p0

    const/4 v1, 0x0

    invoke-static {v0, p0, v1}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    return-object v0
.end method

.method public static u0(Landroid/content/Context;Ljava/lang/String;Lc/v1;)V
    .locals 10

    if-nez p2, :cond_0

    return-void

    :cond_0
    sget v2, Lc/G8;->B:I

    new-instance v0, Lc/n1;

    invoke-direct {v0, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->t0()J

    move-result-wide v3

    new-instance v8, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v8, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v9, Lc/h4;

    move-object v0, v9

    move-object v1, p0

    move-object v5, p1

    move-object v6, p2

    move-object v7, v8

    invoke-direct/range {v0 .. v7}, Lc/h4;-><init>(Landroid/content/Context;IJLjava/lang/String;Lc/v1;Landroid/os/Handler;)V

    const-wide/16 p0, 0x0

    invoke-virtual {v8, v9, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static v(Ljava/lang/String;)Lc/u0;
    .locals 27

    move-object/from16 v0, p0

    if-eqz v0, :cond_1b

    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1b

    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x4000

    if-le v1, v2, :cond_0

    goto/16 :goto_16

    :cond_0
    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "version"

    const/4 v2, -0x1

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v2, 0x1

    if-lt v0, v2, :cond_1a

    const/16 v3, 0xb

    if-le v0, v3, :cond_1

    goto/16 :goto_15

    :cond_1
    const/4 v3, 0x2

    if-ne v0, v2, :cond_2

    move v4, v3

    goto :goto_0

    :cond_2
    move v4, v2

    :goto_0
    const/4 v6, 0x4

    if-ge v0, v6, :cond_3

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    move v7, v2

    :goto_1
    const/16 v8, 0xa

    if-ge v0, v8, :cond_4

    goto :goto_2

    :cond_4
    move v3, v2

    :goto_2
    const-class v9, Lc/Q1;

    const-string v10, "edge"

    invoke-virtual {v1, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    sget-object v11, Lc/Q1;->a:Lc/Q1;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_4

    :try_start_1
    invoke-static {v9, v10}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v11
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_4

    :catch_0
    :try_start_2
    check-cast v11, Lc/Q1;

    const-class v9, Lc/q0;

    const-string v10, "clock"

    invoke-virtual {v1, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    sget-object v12, Lc/q0;->a:Lc/q0;
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_4

    :try_start_3
    invoke-static {v9, v10}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v12
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_4

    :catch_1
    :try_start_4
    check-cast v12, Lc/q0;

    const-string v9, "widgets"

    invoke-virtual {v1, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    if-nez v9, :cond_5

    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0

    return-object v0

    :cond_5
    new-instance v10, Ljava/util/ArrayList;

    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    const/4 v13, 0x0

    move v14, v13

    :goto_3
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v15

    const/16 v2, 0x20

    invoke-static {v15, v2}, Ljava/lang/Math;->min(II)I

    move-result v2
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_4

    sget-object v15, Lc/s0;->i:Lc/s0;

    if-ge v14, v2, :cond_15

    :try_start_5
    invoke-virtual {v9, v14}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v2

    if-nez v2, :cond_6

    :goto_4
    move-object/from16 v26, v9

    move v9, v13

    const/4 v15, 0x3

    goto/16 :goto_11

    :cond_6
    const-class v5, Lc/s0;

    const-string v6, "kind"

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_4

    :try_start_6
    invoke-static {v5, v6}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v5
    :try_end_6
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/NullPointerException; {:try_start_6 .. :try_end_6} :catch_2
    .catch Lorg/json/JSONException; {:try_start_6 .. :try_end_6} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_6 .. :try_end_6} :catch_4

    goto :goto_5

    :catch_2
    const/4 v5, 0x0

    :goto_5
    :try_start_7
    check-cast v5, Lc/s0;

    if-nez v5, :cond_7

    goto :goto_4

    :cond_7
    if-ne v5, v15, :cond_8

    const-string v6, "legacyWindow"

    const-string v8, "legacy"

    invoke-virtual {v2, v8, v13}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v8

    invoke-virtual {v2, v6, v8}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v6

    if-eqz v6, :cond_8

    const/16 v25, 0x1

    goto :goto_6

    :cond_8
    move/from16 v25, v13

    :goto_6
    const-class v6, Lc/t0;

    const-string v8, "size"

    invoke-virtual {v2, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    sget-object v13, Lc/t0;->d:Lc/t0;
    :try_end_7
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_7} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_4

    :try_start_8
    invoke-static {v6, v8}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v6
    :try_end_8
    .catch Ljava/lang/IllegalArgumentException; {:try_start_8 .. :try_end_8} :catch_3
    .catch Ljava/lang/NullPointerException; {:try_start_8 .. :try_end_8} :catch_3
    .catch Lorg/json/JSONException; {:try_start_8 .. :try_end_8} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_4

    goto :goto_7

    :catch_3
    move-object v6, v13

    :goto_7
    :try_start_9
    check-cast v6, Lc/t0;

    const-string v8, "columns"

    move-object/from16 v26, v9

    const/4 v9, 0x5

    if-ge v0, v9, :cond_e

    const/16 v18, 0xc

    if-eq v5, v15, :cond_b

    sget-object v15, Lc/s0;->g:Lc/s0;

    if-ne v5, v15, :cond_9

    goto :goto_a

    :cond_9
    sget-object v13, Lc/s0;->e:Lc/s0;

    if-eq v5, v13, :cond_a

    sget-object v13, Lc/t0;->e:Lc/t0;

    if-ne v6, v13, :cond_a

    :goto_8
    move/from16 v17, v18

    goto :goto_b

    :cond_a
    :goto_9
    const/16 v17, 0x6

    goto :goto_b

    :cond_b
    :goto_a
    sget-object v15, Lc/t0;->c:Lc/t0;

    if-ne v6, v15, :cond_c

    goto :goto_9

    :cond_c
    if-ne v6, v13, :cond_d

    goto :goto_8

    :cond_d
    const/16 v13, 0x18

    move/from16 v17, v13

    :goto_b
    div-int v17, v17, v4

    :goto_c
    move/from16 v13, v17

    goto :goto_d

    :cond_e
    const/16 v13, 0xa

    if-gt v0, v13, :cond_f

    invoke-static {v5, v6}, Lc/G8;->f0(Lc/s0;Lc/t0;)I

    move-result v17

    goto :goto_c

    :cond_f
    iget v13, v6, Lc/t0;->a:I

    :goto_d
    invoke-virtual {v2, v8, v13}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    mul-int/2addr v8, v4

    const-string v13, "column"

    const/4 v15, 0x0

    invoke-virtual {v2, v13, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v13

    mul-int/2addr v13, v4

    const/high16 v15, 0x41c00000    # 24.0f

    const/high16 v17, 0x41f00000    # 30.0f

    if-ge v0, v9, :cond_10

    int-to-float v9, v13

    mul-float v9, v9, v17

    div-float/2addr v9, v15

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    move/from16 v20, v9

    const/4 v9, 0x5

    goto :goto_e

    :cond_10
    move/from16 v20, v13

    :goto_e
    if-ge v0, v9, :cond_11

    add-int/2addr v13, v8

    int-to-float v8, v13

    mul-float v8, v8, v17

    div-float/2addr v8, v15

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    sub-int v8, v8, v20

    :cond_11
    const-string v9, "rows"

    const/16 v13, 0xa

    if-gt v0, v13, :cond_12

    invoke-static {v5, v6}, Lc/G8;->g0(Lc/s0;Lc/t0;)I

    move-result v6

    goto :goto_f

    :cond_12
    iget v6, v6, Lc/t0;->b:I

    :goto_f
    int-to-float v6, v6

    mul-int v13, v7, v3

    int-to-float v13, v13

    div-float/2addr v6, v13

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {v2, v9, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    mul-int/2addr v6, v7

    sget-object v9, Lc/s0;->b:Lc/s0;

    const/high16 v13, 0x40e00000    # 7.0f

    if-ne v5, v9, :cond_13

    const/16 v15, 0x9

    if-ge v0, v15, :cond_13

    int-to-float v8, v8

    div-float/2addr v8, v13

    int-to-float v6, v6

    const/high16 v15, 0x40c00000    # 6.0f

    div-float/2addr v6, v15

    invoke-static {v8, v6}, Ljava/lang/Math;->min(FF)F

    move-result v6

    const/high16 v8, 0x40800000    # 4.0f

    mul-float/2addr v8, v6

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    const/4 v15, 0x4

    invoke-static {v15, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    const/high16 v15, 0x40400000    # 3.0f

    mul-float/2addr v6, v15

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    const/4 v15, 0x3

    invoke-static {v15, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    goto :goto_10

    :cond_13
    const/4 v15, 0x3

    :goto_10
    mul-int/2addr v6, v3

    if-ne v5, v9, :cond_14

    const/16 v9, 0xa

    if-gt v0, v9, :cond_14

    int-to-float v9, v6

    mul-float/2addr v9, v13

    const/high16 v16, 0x41200000    # 10.0f

    div-float v9, v9, v16

    invoke-static {v9}, Ljava/lang/Math;->round(F)I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v8

    const/4 v9, 0x4

    invoke-static {v9, v8}, Ljava/lang/Math;->max(II)I

    move-result v8

    int-to-float v9, v8

    mul-float v9, v9, v16

    div-float/2addr v9, v13

    float-to-int v9, v9

    const/4 v13, 0x5

    invoke-static {v13, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-static {v6, v9}, Ljava/lang/Math;->min(II)I

    move-result v6

    :cond_14
    move/from16 v24, v6

    move/from16 v23, v8

    new-instance v6, Lc/r0;

    const-string v8, "row"

    const/4 v9, 0x0

    invoke-virtual {v2, v8, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    mul-int/2addr v8, v7

    mul-int v21, v8, v3

    const-string v8, "hidden"

    invoke-virtual {v2, v8, v9}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v22

    move-object/from16 v18, v6

    move-object/from16 v19, v5

    invoke-direct/range {v18 .. v25}, Lc/r0;-><init>(Lc/s0;IIZIIZ)V

    invoke-virtual {v10, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_11
    add-int/lit8 v14, v14, 0x1

    move v13, v9

    move-object/from16 v9, v26

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/16 v8, 0xa

    goto/16 :goto_3

    :cond_15
    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_16
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_17

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/r0;

    iget-object v4, v4, Lc/r0;->a:Lc/s0;

    if-ne v4, v15, :cond_16

    :goto_12
    const/4 v2, 0x6

    goto :goto_13

    :cond_17
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v2

    invoke-virtual {v2, v15}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_12

    :goto_13
    if-ge v0, v2, :cond_18

    new-instance v2, Lc/l0;

    const/4 v4, 0x0

    invoke-direct {v2, v4}, Lc/l0;-><init>(I)V

    invoke-static {v2}, Ljava/util/Comparator;->comparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v2

    new-instance v4, Lc/l0;

    const/4 v5, 0x1

    invoke-direct {v4, v5}, Lc/l0;-><init>(I)V

    invoke-interface {v2, v4}, Ljava/util/Comparator;->thenComparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v2

    new-instance v4, Lc/l0;

    const/4 v5, 0x2

    invoke-direct {v4, v5}, Lc/l0;-><init>(I)V

    invoke-interface {v2, v4}, Ljava/util/Comparator;->thenComparingInt(Ljava/util/function/ToIntFunction;)Ljava/util/Comparator;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    :cond_18
    new-instance v2, Lc/u0;

    const-string v4, "gridRows"

    const/16 v5, 0xa

    if-ge v0, v5, :cond_19

    const/16 v0, 0x12

    goto :goto_14

    :cond_19
    const/16 v0, 0x24

    :goto_14
    invoke-virtual {v1, v4, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    mul-int/2addr v0, v3

    invoke-direct {v2, v11, v12, v10, v0}, Lc/u0;-><init>(Lc/Q1;Lc/q0;Ljava/util/List;I)V

    invoke-static {v2}, Lc/u0;->r(Lc/u0;)Lc/u0;

    move-result-object v0

    invoke-static {v0}, Lc/G8;->s0(Lc/u0;)Lc/u0;

    move-result-object v0

    return-object v0

    :cond_1a
    :goto_15
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0
    :try_end_9
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_9} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_9} :catch_4

    return-object v0

    :catch_4
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0

    return-object v0

    :cond_1b
    :goto_16
    invoke-static {}, Lc/u0;->c()Lc/u0;

    move-result-object v0

    return-object v0
.end method

.method public static v0(Landroid/content/Context;Lc/n1;)Ljava/lang/String;
    .locals 2

    invoke-virtual {p1}, Lc/n1;->e0()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "com.syu.bt"

    return-object p0

    :cond_0
    invoke-virtual {p1}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    return-object v0

    :cond_1
    invoke-virtual {p1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string p1, "source"

    invoke-static {p0, p1}, Lc/G8;->h1(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_2
    return-object p1
.end method

.method public static w(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v0, 0x0

    if-eqz p0, :cond_3

    const-string v1, "[0-9a-fA-F]{1,16}"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "0000000000000000"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    invoke-virtual {v1, p0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const-string v1, "9774d56d682e549c"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_3

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_1

    :cond_1
    const-string v0, "SHA-256"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const-string v1, "DriveDeck-install-v1\u0000"

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0

    const-string v0, "0123456789abcdef"

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    array-length v1, p0

    mul-int/lit8 v1, v1, 0x2

    new-array v1, v1, [C

    const/4 v2, 0x0

    :goto_0
    array-length v3, p0

    if-ge v2, v3, :cond_2

    mul-int/lit8 v3, v2, 0x2

    aget-byte v4, p0, v2

    ushr-int/lit8 v5, v4, 0x4

    and-int/lit8 v5, v5, 0xf

    aget-char v5, v0, v5

    aput-char v5, v1, v3

    add-int/lit8 v3, v3, 0x1

    and-int/lit8 v4, v4, 0xf

    aget-char v4, v0, v4

    aput-char v4, v1, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    new-instance p0, Ljava/lang/String;

    invoke-direct {p0, v1}, Ljava/lang/String;-><init>([C)V

    return-object p0

    :cond_3
    :goto_1
    return-object v0
.end method

.method public static w0(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "|"

    if-nez p0, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    :cond_0
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v1

    :goto_0
    if-gez v1, :cond_1

    const-string p0, ""

    return-object p0

    :cond_1
    add-int/lit8 v1, v1, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v0

    if-gez v0, :cond_2

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_2
    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :goto_1
    return-object p0
.end method

.method public static x(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v0, "unknown"

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v2, v3, :cond_2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v3

    const/16 v4, 0x50

    if-ge v3, v4, :cond_2

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v4

    if-nez v4, :cond_1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    if-nez p0, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_1
    return-object v0
.end method

.method public static x0(II)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    int-to-float p0, p1

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public static y(Ljava/lang/String;Lc/v1;)V
    .locals 2

    const-string v0, "/resources?path="

    :try_start_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, "UTF-8"

    invoke-static {p0, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "PUT"

    invoke-static {p0, v0, p1}, Lc/G8;->f(Ljava/lang/String;Ljava/lang/String;Lc/v1;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lc/q1; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    iget p1, p0, Lc/q1;->a:I

    const/16 v0, 0x199

    if-ne p1, v0, :cond_0

    :goto_0
    return-void

    :cond_0
    throw p0
.end method

.method public static y0(Landroid/content/Context;F)I
    .locals 0

    invoke-static {p0, p1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static z(Landroid/content/Context;F)I
    .locals 0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr p1, p0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    return p0
.end method

.method public static z0(IIFFZ)Landroid/graphics/Bitmap;
    .locals 18

    move/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    int-to-float v4, v0

    const/high16 v5, 0x40000000    # 2.0f

    mul-float v6, v2, v5

    div-float v6, v4, v6

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-static {v7, v6}, Ljava/lang/Math;->min(FF)F

    move-result v6

    int-to-float v8, v1

    mul-float v9, v3, v5

    div-float v9, v8, v9

    invoke-static {v7, v9}, Ljava/lang/Math;->min(FF)F

    move-result v9

    mul-float/2addr v9, v6

    div-float/2addr v4, v5

    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    move-result v2

    div-float/2addr v8, v5

    invoke-static {v3, v8}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/4 v6, 0x0

    if-eqz p4, :cond_0

    sub-float/2addr v4, v2

    div-float/2addr v4, v2

    sub-float/2addr v8, v3

    div-float/2addr v8, v3

    invoke-static {v4, v8}, Ljava/lang/Math;->min(FF)F

    move-result v4

    const v8, 0x3eb33333    # 0.35f

    invoke-static {v8, v4}, Ljava/lang/Math;->min(FF)F

    move-result v4

    goto :goto_0

    :cond_0
    move v4, v6

    :goto_0
    mul-int v8, v0, v1

    new-array v8, v8, [I

    const/4 v11, 0x0

    :goto_1
    if-ge v11, v1, :cond_7

    int-to-float v12, v11

    const/high16 v13, 0x3f000000    # 0.5f

    add-float/2addr v12, v13

    sub-int v14, v1, v11

    int-to-float v14, v14

    sub-float/2addr v14, v13

    invoke-static {v12, v14}, Ljava/lang/Math;->min(FF)F

    move-result v12

    div-float/2addr v12, v3

    const/4 v14, 0x0

    :goto_2
    if-ge v14, v0, :cond_6

    int-to-float v15, v14

    add-float/2addr v15, v13

    sub-int v10, v0, v14

    int-to-float v10, v10

    sub-float/2addr v10, v13

    invoke-static {v15, v10}, Ljava/lang/Math;->min(FF)F

    move-result v10

    div-float/2addr v10, v2

    cmpg-float v15, v10, v7

    if-gez v15, :cond_1

    cmpg-float v15, v12, v7

    if-gez v15, :cond_1

    sub-float v15, v7, v10

    mul-float/2addr v15, v15

    sub-float v16, v7, v12

    mul-float v16, v16, v16

    add-float v15, v16, v15

    move/from16 v16, v14

    float-to-double v13, v15

    invoke-static {v13, v14}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v13

    double-to-float v13, v13

    sub-float v13, v7, v13

    goto :goto_3

    :cond_1
    move/from16 v16, v14

    invoke-static {v10, v12}, Ljava/lang/Math;->min(FF)F

    move-result v13

    :goto_3
    if-eqz p4, :cond_2

    add-float v13, v4, v7

    sub-float v10, v13, v10

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    sub-float v14, v13, v12

    invoke-static {v6, v14}, Ljava/lang/Math;->max(FF)F

    move-result v14

    mul-float/2addr v10, v10

    mul-float/2addr v14, v14

    add-float/2addr v14, v10

    float-to-double v14, v14

    invoke-static {v14, v15}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v14

    double-to-float v10, v14

    sub-float/2addr v13, v10

    :cond_2
    invoke-static {v7, v13}, Ljava/lang/Math;->min(FF)F

    move-result v10

    invoke-static {v6, v10}, Ljava/lang/Math;->max(FF)F

    move-result v10

    mul-float v13, v10, v10

    const/high16 v14, 0x40400000    # 3.0f

    mul-float/2addr v10, v5

    sub-float/2addr v14, v10

    mul-float/2addr v14, v13

    if-eqz p4, :cond_3

    mul-float/2addr v14, v14

    :cond_3
    const/high16 v10, 0x437f0000    # 255.0f

    mul-float/2addr v10, v9

    mul-float/2addr v10, v14

    if-eqz p4, :cond_5

    add-int/lit8 v13, v0, -0x1

    sub-int v13, v13, v16

    move/from16 v14, v16

    invoke-static {v14, v13}, Ljava/lang/Math;->min(II)I

    move-result v13

    add-int/lit8 v15, v1, -0x1

    sub-int/2addr v15, v11

    invoke-static {v11, v15}, Ljava/lang/Math;->min(II)I

    move-result v15

    const/4 v5, 0x0

    const/4 v6, 0x0

    :goto_4
    const/4 v7, 0x3

    if-ge v5, v7, :cond_4

    shr-int v7, v13, v5

    and-int/lit8 v7, v7, 0x1

    shr-int v17, v15, v5

    and-int/lit8 v17, v17, 0x1

    xor-int v7, v7, v17

    mul-int/lit8 v7, v7, 0x2

    add-int v7, v7, v17

    mul-int/lit8 v17, v5, 0x2

    rsub-int/lit8 v17, v17, 0x4

    shl-int v7, v7, v17

    or-int/2addr v6, v7

    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    :cond_4
    int-to-float v5, v6

    const/high16 v6, 0x3f000000    # 0.5f

    add-float/2addr v5, v6

    const/high16 v7, 0x42800000    # 64.0f

    div-float/2addr v5, v7

    add-float/2addr v5, v10

    float-to-double v6, v5

    invoke-static {v6, v7}, Ljava/lang/Math;->floor(D)D

    move-result-wide v5

    double-to-int v5, v5

    const/16 v6, 0xff

    invoke-static {v6, v5}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v6, 0x0

    invoke-static {v6, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    goto :goto_5

    :cond_5
    move/from16 v14, v16

    const/4 v6, 0x0

    invoke-static {v10}, Ljava/lang/Math;->round(F)I

    move-result v5

    :goto_5
    mul-int v7, v11, v0

    add-int/2addr v7, v14

    shl-int/lit8 v5, v5, 0x18

    const v10, 0xffffff

    or-int/2addr v5, v10

    aput v5, v8, v7

    add-int/lit8 v14, v14, 0x1

    const/high16 v5, 0x40000000    # 2.0f

    const/4 v6, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    const/high16 v13, 0x3f000000    # 0.5f

    goto/16 :goto_2

    :cond_6
    const/4 v6, 0x0

    add-int/lit8 v11, v11, 0x1

    const/high16 v5, 0x40000000    # 2.0f

    const/4 v6, 0x0

    const/high16 v7, 0x3f800000    # 1.0f

    goto/16 :goto_1

    :cond_7
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v8, v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap([IIILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    return-object v0
.end method
