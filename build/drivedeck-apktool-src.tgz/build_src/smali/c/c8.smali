.class public final synthetic Lc/c8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:Lc/d8;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lc/d8;Ljava/lang/String;I)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/c8;->a:Lc/d8;

    iput-object p2, p0, Lc/c8;->b:Ljava/lang/String;

    iput p3, p0, Lc/c8;->c:I

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 6

    check-cast p1, Ljava/lang/Boolean;

    iget-object v0, p0, Lc/c8;->a:Lc/d8;

    iget-object v1, v0, Lc/d8;->e:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_4

    iget-object v1, v0, Lc/d8;->l:Ljava/lang/String;

    iget-object v2, p0, Lc/c8;->b:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object v1, v0, Lc/d8;->b:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget v1, v1, Lc/e8;->e:I

    iget v3, p0, Lc/c8;->c:I

    if-eq v1, v3, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    iget-object v4, v0, Lc/d8;->a:Landroid/content/Context;

    invoke-static {v4, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    invoke-static {v4, v1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    :cond_1
    invoke-virtual {v0}, Lc/d8;->k()Z

    move-result v1

    if-nez v1, :cond_2

    invoke-virtual {v0}, Lc/d8;->f()V

    goto :goto_1

    :cond_2
    iget-object v1, v0, Lc/d8;->d:Landroid/os/Handler;

    new-instance v4, Lc/x;

    const/4 v5, 0x7

    invoke-direct {v4, v0, v2, v3, v5}, Lc/x;-><init>(Ljava/lang/Object;Ljava/lang/Object;II)V

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_3

    const-wide/16 v2, 0x5dc

    goto :goto_0

    :cond_3
    const-wide/16 v2, 0x0

    :goto_0
    invoke-virtual {v1, v4, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    :goto_1
    return-void
.end method
