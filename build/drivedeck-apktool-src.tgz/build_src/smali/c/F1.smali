.class public final synthetic Lc/F1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/Window$OnFrameMetricsAvailableListener;


# instance fields
.field public final synthetic a:Lc/N1;

.field public final synthetic b:[J


# direct methods
.method public synthetic constructor <init>(Lc/N1;[J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/F1;->a:Lc/N1;

    iput-object p2, p0, Lc/F1;->b:[J

    return-void
.end method


# virtual methods
.method public final onFrameMetricsAvailable(Landroid/view/Window;Landroid/view/FrameMetrics;I)V
    .locals 8

    iget-object p1, p0, Lc/F1;->a:Lc/N1;

    iget-object v0, p0, Lc/F1;->b:[J

    invoke-virtual {p1}, Lc/N1;->u()Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_3

    :cond_0
    const/16 v1, 0x8

    invoke-virtual {p2, v1}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v1

    const/4 v3, 0x0

    aput-wide v1, v0, v3

    const/4 v1, 0x4

    invoke-virtual {p2, v1}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v1

    const/4 v4, 0x1

    aput-wide v1, v0, v4

    move v1, v3

    :goto_0
    sget-object v2, Lc/N1;->Z:[I

    array-length v5, v2

    if-ge v1, v5, :cond_1

    add-int/lit8 v5, v1, 0x2

    aget v2, v2, v1

    invoke-virtual {p2, v2}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v6

    aput-wide v6, v0, v5

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    iget-object p1, p1, Lc/N1;->x:Lc/t1;

    const/16 v1, 0xa

    invoke-virtual {p2, v1}, Landroid/view/FrameMetrics;->getMetric(I)J

    move-result-wide v1

    monitor-enter p1

    const-wide/16 v5, 0x0

    cmp-long p2, v1, v5

    if-gez p2, :cond_2

    monitor-exit p1

    goto :goto_3

    :cond_2
    :try_start_0
    iget-wide v1, p1, Lc/t1;->b:J

    int-to-long p2, p3

    add-long/2addr v1, p2

    iput-wide v1, p1, Lc/t1;->b:J

    move p2, v3

    :goto_1
    iget-object p3, p1, Lc/t1;->c:[Ljava/lang/Object;

    check-cast p3, [Lc/u1;

    array-length v1, p3

    if-ge p2, v1, :cond_3

    aget-object p3, p3, p2

    aget-wide v1, v0, p2

    invoke-virtual {p3, v1, v2}, Lc/u1;->a(J)V

    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :catchall_0
    move-exception p2

    goto :goto_4

    :cond_3
    aget-wide p2, v0, v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-wide/32 v1, 0x1fca056

    cmp-long p2, p2, v1

    if-gtz p2, :cond_4

    monitor-exit p1

    goto :goto_3

    :cond_4
    move p2, v3

    :goto_2
    :try_start_1
    iget-object p3, p1, Lc/t1;->a:[[J

    array-length v1, p3

    if-ge v4, v1, :cond_7

    aget-object v1, p3, v4

    if-eqz v1, :cond_5

    aget-object p3, p3, p2

    if-eqz p3, :cond_6

    aget-wide v5, v1, v3

    aget-wide v1, p3, v3

    cmp-long p3, v5, v1

    if-gez p3, :cond_6

    :cond_5
    move p2, v4

    :cond_6
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    :cond_7
    aget-object v1, p3, p2

    if-eqz v1, :cond_8

    aget-wide v4, v0, v3

    aget-wide v2, v1, v3

    cmp-long v1, v4, v2

    if-lez v1, :cond_9

    :cond_8
    invoke-virtual {v0}, [J->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [J

    aput-object v0, p3, p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_9
    monitor-exit p1

    :goto_3
    return-void

    :goto_4
    :try_start_2
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p2
.end method
