.class public final synthetic Lc/I2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/k3;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/k3;Ljava/lang/String;I)V
    .locals 0

    iput p3, p0, Lc/I2;->a:I

    iput-object p1, p0, Lc/I2;->b:Lc/k3;

    iput-object p2, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 6

    iget v0, p0, Lc/I2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object p1, p0, Lc/I2;->c:Ljava/lang/String;

    iget-object v0, p0, Lc/I2;->b:Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "package:"

    :try_start_0
    iget-object v2, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.intent.action.DELETE"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Ld/a;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-direct {v3, v4, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v2, v3}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string p1, "\u042d\u0442\u043e\u0442 \u0440\u0430\u0437\u0434\u0435\u043b \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0432 \u043f\u0440\u043e\u0448\u0438\u0432\u043a\u0435"

    invoke-virtual {v0, p1}, Lc/k3;->J(Ljava/lang/String;)V

    :goto_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/I2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lc/G8;->K0(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/I2;->b:Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->O()Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    new-instance v1, Lc/x2;

    const/4 v3, 0x2

    invoke-direct {v1, v0, v2, v3}, Lc/x2;-><init>(Lc/k3;Ljava/lang/String;I)V

    invoke-static {p1, v1}, Lc/k3;->p0(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_0
    return-void

    :pswitch_2
    iget-object p1, p0, Lc/I2;->b:Lc/k3;

    iget-object v0, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lc/k3;->m0(Ljava/lang/String;)V

    return-void

    :pswitch_3
    iget-object v0, p0, Lc/I2;->b:Lc/k3;

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    iget-object v1, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Lc/G8;->K0(Landroid/view/View;Ljava/lang/CharSequence;)V

    return-void

    :pswitch_4
    iget-object p1, p0, Lc/I2;->b:Lc/k3;

    iget-object v0, p1, Lc/k3;->c:Lc/n1;

    iget-object v1, p0, Lc/I2;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/n1;->V0(Ljava/lang/String;)V

    invoke-virtual {p1}, Lc/k3;->X()V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
