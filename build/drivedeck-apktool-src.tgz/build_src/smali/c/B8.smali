.class public final synthetic Lc/B8;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/C8;


# direct methods
.method public synthetic constructor <init>(Lc/C8;I)V
    .locals 0

    iput p2, p0, Lc/B8;->a:I

    iput-object p1, p0, Lc/B8;->b:Lc/C8;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget v0, p0, Lc/B8;->a:I

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x0

    iget-object v1, p0, Lc/B8;->b:Lc/C8;

    iput-boolean v0, v1, Lc/C8;->j:Z

    invoke-virtual {v1}, Lc/C8;->e()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/B8;->b:Lc/C8;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/C8;->i:Z

    iget-object v0, v0, Lc/C8;->c:Lc/P7;

    invoke-virtual {v0}, Lc/P7;->run()V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/B8;->b:Lc/C8;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/C8;->i:Z

    iput-boolean v1, v0, Lc/C8;->j:Z

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
