.class public final Lc/q3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/location/LocationListener;


# instance fields
.field public final synthetic a:J

.field public final synthetic b:Lc/r3;


# direct methods
.method public constructor <init>(Lc/r3;J)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/q3;->b:Lc/r3;

    iput-wide p2, p0, Lc/q3;->a:J

    return-void
.end method


# virtual methods
.method public final onLocationChanged(Landroid/location/Location;)V
    .locals 5

    iget-object v0, p0, Lc/q3;->b:Lc/r3;

    iget-boolean v1, v0, Lc/r3;->g:Z

    if-eqz v1, :cond_1

    iget-wide v1, v0, Lc/r3;->f:J

    iget-wide v3, p0, Lc/q3;->a:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_1

    if-eqz p1, :cond_1

    const-string v1, "gps"

    invoke-virtual {p1}, Landroid/location/Location;->getProvider()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance v1, Landroid/location/Location;

    invoke-direct {v1, p1}, Landroid/location/Location;-><init>(Landroid/location/Location;)V

    iput-object v1, v0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Lc/r3;->b()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final onProviderDisabled(Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, Lc/q3;->b:Lc/r3;

    iget-boolean v1, v0, Lc/r3;->g:Z

    if-eqz v1, :cond_1

    iget-wide v1, v0, Lc/r3;->f:J

    iget-wide v3, p0, Lc/q3;->a:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_1

    const-string v1, "gps"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    iput-object p1, v0, Lc/r3;->j:Landroid/location/Location;

    invoke-virtual {v0}, Lc/r3;->b()V

    :cond_1
    :goto_0
    return-void
.end method

.method public final onProviderEnabled(Ljava/lang/String;)V
    .locals 5

    iget-object v0, p0, Lc/q3;->b:Lc/r3;

    iget-boolean v1, v0, Lc/r3;->g:Z

    if-eqz v1, :cond_0

    iget-wide v1, v0, Lc/r3;->f:J

    iget-wide v3, p0, Lc/q3;->a:J

    cmp-long v1, v3, v1

    if-nez v1, :cond_0

    const-string v1, "gps"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {v0}, Lc/r3;->b()V

    :cond_0
    return-void
.end method

.method public final onStatusChanged(Ljava/lang/String;ILandroid/os/Bundle;)V
    .locals 0

    return-void
.end method
