.class public final Lc/e1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/e1;->a:I

    iput-object p1, p0, Lc/e1;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    move-object/from16 v1, p0

    iget v0, v1, Lc/e1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    invoke-virtual {v0}, Lc/H6;->t()V

    iget-object v0, v0, Lc/H6;->m0:Landroid/os/Handler;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :pswitch_0
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/a5;

    iget-object v2, v0, Lc/a5;->f:Lc/Y4;

    invoke-virtual {v2}, Landroid/view/View;->getScrollX()I

    move-result v2

    iget-boolean v3, v0, Lc/a5;->k:Z

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_0
    iget v3, v0, Lc/a5;->j:I

    if-eq v2, v3, :cond_1

    iput v2, v0, Lc/a5;->j:I

    const-wide/16 v2, 0x50

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_1
    int-to-float v2, v2

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    const/high16 v4, 0x40800000    # 4.0f

    invoke-static {v3, v4}, Lc/G8;->a(Landroid/content/Context;F)I

    move-result v3

    iget v4, v0, Lc/a5;->s:I

    add-int/2addr v3, v4

    int-to-float v3, v3

    div-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Lc/a5;->b(IZ)V

    :goto_0
    return-void

    :pswitch_1
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-boolean v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->i:Z

    if-eqz v0, :cond_2

    goto/16 :goto_9

    :cond_2
    :try_start_0
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-static {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->a(Lru/drivedeck/launcher/LauncherAccessibilityService;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0

    iget-object v2, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v2}, Landroid/accessibilityservice/AccessibilityService;->getWindows()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/accessibility/AccessibilityWindowInfo;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-nez v0, :cond_3

    :try_start_1
    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->getId()I

    move-result v4

    iget-object v5, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v5, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget v5, v5, Lru/drivedeck/launcher/LauncherAccessibilityService;->j:I

    if-ne v4, v5, :cond_3

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->getRoot()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_2

    :catchall_0
    move-exception v0

    :try_start_2
    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    throw v0

    :cond_3
    :goto_2
    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    goto :goto_1

    :cond_4
    if-nez v0, :cond_5

    iget-object v2, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v3, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-nez v3, :cond_5

    invoke-virtual {v2}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    :cond_5
    move-object v2, v0

    if-eqz v2, :cond_a

    :try_start_3
    invoke-static {v2}, Lc/k5;->d(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-boolean v3, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->m:Z

    if-nez v3, :cond_6

    iget-object v3, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-nez v3, :cond_9

    :cond_6
    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v0, :cond_7

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    goto :goto_3

    :catchall_1
    move-exception v0

    goto :goto_5

    :cond_7
    :goto_3
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-static {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->obtain(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    iput-object v3, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    goto :goto_4

    :cond_8
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-boolean v3, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->m:Z

    if-eqz v3, :cond_9

    invoke-virtual {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->c()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :cond_9
    :goto_4
    :try_start_4
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    goto :goto_6

    :goto_5
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    throw v0

    :cond_a
    :goto_6
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v0, :cond_e

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getWindowId()I

    move-result v0

    iget-object v2, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v2, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo;->isVisibleToUser()Z

    move-result v2

    if-eqz v2, :cond_d

    iget-object v2, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget v2, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->j:I

    if-ltz v2, :cond_b

    if-ltz v0, :cond_b

    iget-object v2, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget v2, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->j:I

    if-ne v0, v2, :cond_d

    :cond_b
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->refresh()Z

    move-result v0

    if-eqz v0, :cond_d

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-static {v0}, Lc/k5;->d(Landroid/view/accessibility/AccessibilityNodeInfo;)Z

    move-result v0

    if-nez v0, :cond_c

    goto :goto_7

    :cond_c
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    invoke-static {v0}, Lc/k5;->e(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    goto :goto_8

    :cond_d
    :goto_7
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->c()V
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0

    goto :goto_8

    :catch_0
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->c()V

    :cond_e
    :goto_8
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-boolean v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->i:Z

    if-eqz v0, :cond_f

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    invoke-virtual {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->c()V

    goto :goto_9

    :cond_f
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->g:Landroid/os/Handler;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_9
    return-void

    :pswitch_2
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_1a

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-object v2, v0, Lc/P3;->B:Lc/U0;

    if-nez v2, :cond_10

    const/4 v2, -0x1

    goto :goto_a

    :cond_10
    iget v2, v2, Lc/U0;->r:I

    :goto_a
    iget-boolean v3, v0, Lc/P3;->r:Z

    invoke-virtual {v0}, Lc/P3;->j0()Z

    move-result v0

    iget-object v4, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v4, Lc/P3;

    sget-object v5, Lc/s0;->d:Lc/s0;

    invoke-virtual {v4, v5}, Lc/P3;->L(Lc/s0;)Z

    move-result v4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-object v7, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v7, Lc/P3;

    iget-object v7, v7, Lc/P3;->C1:Lc/n1;

    invoke-virtual {v7}, Lc/n1;->t0()J

    move-result-wide v7

    const-wide/16 v9, 0x1388

    add-long/2addr v7, v9

    iget-object v9, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v9, Lc/P3;

    iget-object v10, v9, Lc/P3;->o1:Lc/w8;

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eqz v10, :cond_11

    iget-object v9, v9, Lc/P3;->B:Lc/U0;

    if-eqz v9, :cond_11

    iget-boolean v9, v9, Lc/U0;->o:Z

    if-eqz v9, :cond_11

    invoke-virtual {v10, v5, v6}, Lc/w8;->b(J)Z

    move-result v9

    if-nez v9, :cond_11

    move v9, v11

    goto :goto_b

    :cond_11
    move v9, v12

    :goto_b
    if-nez v0, :cond_13

    sget-object v0, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    iget-object v10, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v10, Lc/P3;

    iget-object v13, v10, Lc/P3;->a1:Lc/w8;

    if-ne v0, v13, :cond_13

    if-nez v9, :cond_13

    invoke-virtual {v10}, Lc/P3;->P()Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-wide v9, v0, Lc/P3;->Z0:J

    sub-long v13, v5, v9

    const-wide/16 v15, 0x3a98

    cmp-long v0, v13, v15

    if-gez v0, :cond_13

    cmp-long v0, v9, v7

    if-gez v0, :cond_12

    cmp-long v0, v5, v7

    if-ltz v0, :cond_12

    goto :goto_c

    :cond_12
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Lc/P3;->a0()V

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Lc/P3;->W()V

    goto :goto_d

    :cond_13
    :goto_c
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Lc/P3;->Y()V

    :goto_d
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    sget-object v5, Lc/s0;->l:Lc/s0;

    invoke-virtual {v0, v5}, Lc/P3;->L(Lc/s0;)Z

    move-result v0

    if-eqz v0, :cond_14

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-object v0, v0, Lc/P3;->n:Lc/G0;

    invoke-virtual {v0, v12}, Lc/G0;->j(Z)Z

    move-result v0

    if-eqz v0, :cond_14

    move v0, v11

    goto :goto_e

    :cond_14
    move v0, v12

    :goto_e
    iget-object v5, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v5, Lc/P3;

    iget-object v6, v5, Lc/P3;->n:Lc/G0;

    invoke-virtual {v5}, Landroid/view/View;->isShown()Z

    move-result v5

    if-eqz v5, :cond_15

    iget-object v5, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v5, Lc/P3;

    iget-object v5, v5, Lc/P3;->n:Lc/G0;

    iget-boolean v5, v5, Lc/G0;->o:Z

    if-eqz v5, :cond_15

    goto :goto_f

    :cond_15
    move v11, v12

    :goto_f
    invoke-virtual {v6, v1, v11}, Lc/G0;->k(Ljava/lang/Object;Z)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-object v7, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v7, Lc/P3;

    iget-wide v8, v7, Lc/P3;->I:J

    sub-long v8, v5, v8

    const-wide/16 v10, 0x7530

    cmp-long v8, v8, v10

    if-ltz v8, :cond_16

    iput-wide v5, v7, Lc/P3;->I:J

    invoke-virtual {v7}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v5

    iget-object v6, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v6, Lc/P3;

    invoke-virtual {v6}, Lc/P3;->o0()Lc/i;

    move-result-object v6

    invoke-static {v5, v6, v12, v12}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    :cond_16
    iget-object v5, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v5, Lc/P3;

    sget-object v6, Lc/s0;->b:Lc/s0;

    invoke-virtual {v5, v6}, Lc/P3;->L(Lc/s0;)Z

    move-result v5

    if-nez v5, :cond_19

    if-eqz v4, :cond_17

    iget-object v4, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v4, Lc/P3;

    iget-object v4, v4, Lc/P3;->B:Lc/U0;

    if-eqz v4, :cond_17

    iget-boolean v4, v4, Lc/U0;->o:Z

    if-nez v4, :cond_19

    :cond_17
    if-nez v0, :cond_19

    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-object v4, v0, Lc/P3;->B:Lc/U0;

    if-eqz v4, :cond_18

    iget v4, v4, Lc/U0;->r:I

    if-ne v4, v2, :cond_19

    iget-boolean v2, v0, Lc/P3;->r:Z

    if-ne v2, v3, :cond_19

    :cond_18
    sget-object v2, Lc/s0;->k:Lc/s0;

    invoke-virtual {v0, v2}, Lc/P3;->L(Lc/s0;)Z

    move-result v0

    if-eqz v0, :cond_1a

    :cond_19
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_1a
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/P3;

    iget-boolean v2, v0, Lc/P3;->U1:Z

    if-eqz v2, :cond_1b

    iget-object v0, v0, Lc/P3;->W0:Landroid/os/Handler;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1b
    return-void

    :pswitch_3
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/r3;

    iget-boolean v2, v0, Lc/r3;->g:Z

    if-nez v2, :cond_1c

    goto :goto_12

    :cond_1c
    iget-boolean v2, v0, Lc/r3;->h:Z

    const/4 v3, 0x1

    if-nez v2, :cond_1e

    iget-object v2, v0, Lc/r3;->b:Landroid/location/LocationManager;

    if-eqz v2, :cond_1e

    iget-object v2, v0, Lc/r3;->a:Landroid/content/Context;

    const-string v4, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v2, v4}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_1d

    goto :goto_10

    :cond_1d
    iget-wide v4, v0, Lc/r3;->f:J

    new-instance v2, Lc/q3;

    invoke-direct {v2, v0, v4, v5}, Lc/q3;-><init>(Lc/r3;J)V

    :try_start_5
    iget-object v6, v0, Lc/r3;->b:Landroid/location/LocationManager;

    const-string v7, "gps"

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v12

    const-wide/16 v8, 0x3e8

    const/4 v10, 0x0

    move-object v11, v2

    invoke-virtual/range {v6 .. v12}, Landroid/location/LocationManager;->requestLocationUpdates(Ljava/lang/String;JFLandroid/location/LocationListener;Landroid/os/Looper;)V

    iput-object v2, v0, Lc/r3;->i:Lc/q3;

    iput-boolean v3, v0, Lc/r3;->h:Z
    :try_end_5
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_5} :catch_1

    :catch_1
    :cond_1e
    :goto_10
    invoke-virtual {v0}, Lc/r3;->b()V

    iget-wide v4, v0, Lc/r3;->f:J

    sget-object v2, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const-string v6, "ranchu"

    invoke-virtual {v2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_1f

    const-string v6, "goldfish"

    invoke-virtual {v2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1f

    goto :goto_11

    :cond_1f
    iget-object v2, v0, Lc/r3;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x0

    invoke-virtual {v2, v6, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v2

    if-nez v2, :cond_20

    goto :goto_11

    :cond_20
    new-instance v2, Lc/l1;

    const/4 v3, 0x1

    invoke-direct {v2, v0, v4, v5, v3}, Lc/l1;-><init>(Ljava/lang/Object;JI)V

    sget-object v3, Lc/r3;->o:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v3, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_11
    iget-object v0, v0, Lc/r3;->d:Landroid/os/Handler;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_12
    return-void

    :pswitch_4
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, v0, Lc/b2;->s0:Landroid/os/Handler;

    const-wide/16 v2, 0x1388

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :pswitch_5
    iget-object v0, v1, Lc/e1;->b:Ljava/lang/Object;

    check-cast v0, Lc/g1;

    iget-boolean v2, v0, Lc/g1;->J:Z

    if-eqz v2, :cond_24

    iget v2, v0, Lc/g1;->N:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_24

    iget-object v2, v0, Lc/g1;->F:Lc/o0;

    if-nez v2, :cond_21

    goto :goto_14

    :cond_21
    iget v4, v0, Lc/g1;->S:F

    iget-object v2, v2, Lc/o0;->c:Lc/m0;

    invoke-virtual {v0}, Lc/g1;->x()F

    move-result v5

    iget v2, v2, Lc/m0;->b:F

    add-float/2addr v5, v2

    cmpg-float v2, v4, v5

    const/4 v4, 0x0

    const/high16 v5, 0x41400000    # 12.0f

    if-gez v2, :cond_22

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v2

    neg-float v2, v2

    goto :goto_13

    :cond_22
    iget v2, v0, Lc/g1;->S:F

    iget-object v6, v0, Lc/g1;->F:Lc/o0;

    iget-object v6, v6, Lc/o0;->c:Lc/m0;

    invoke-virtual {v0}, Lc/g1;->x()F

    move-result v7

    iget v6, v6, Lc/m0;->d:F

    sub-float/2addr v6, v7

    cmpl-float v2, v2, v6

    if-lez v2, :cond_23

    invoke-virtual {v0, v5}, Lc/g1;->h(F)F

    move-result v2

    goto :goto_13

    :cond_23
    move v2, v4

    :goto_13
    iget-object v5, v0, Lc/g1;->F:Lc/o0;

    invoke-virtual {v5}, Lc/o0;->c()F

    move-result v5

    iget-object v6, v0, Lc/g1;->k:Lc/M3;

    iget-object v7, v6, Lc/M3;->a:Lc/P3;

    iget v7, v7, Lc/P3;->D:F

    add-float/2addr v7, v2

    invoke-static {v5, v7}, Ljava/lang/Math;->min(FF)F

    move-result v2

    invoke-static {v4, v2}, Ljava/lang/Math;->max(FF)F

    move-result v2

    iget-object v4, v6, Lc/M3;->a:Lc/P3;

    iget v5, v4, Lc/P3;->D:F

    cmpl-float v5, v2, v5

    if-eqz v5, :cond_24

    iput v2, v4, Lc/P3;->D:F

    invoke-virtual {v4}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lc/g1;->y(Z)V

    invoke-virtual {v0, v3}, Lc/g1;->m(Z)V

    const-wide/16 v2, 0x1e

    iget-object v0, v0, Lc/g1;->a:Lc/P3;

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_24
    :goto_14
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
