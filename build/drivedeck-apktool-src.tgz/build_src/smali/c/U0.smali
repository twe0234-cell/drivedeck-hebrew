.class public final Lc/U0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:J

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/String;

.field public final j:I

.field public final k:I

.field public final l:I

.field public final m:Z

.field public final n:Z

.field public final o:Z

.field public final p:Landroid/graphics/Bitmap;

.field public final q:Lc/R0;

.field public final r:I

.field public final s:I

.field public final t:Lc/j5;

.field public final u:Z

.field public final v:Ljava/util/List;


# direct methods
.method public constructor <init>(JLjava/lang/String;IZZIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/graphics/Bitmap;JJZLjava/lang/String;Ljava/lang/String;Ljava/util/List;Lc/R0;IIZ)V
    .locals 4

    move-object v0, p0

    move-object/from16 v1, p20

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    move-wide v2, p1

    iput-wide v2, v0, Lc/U0;->a:J

    move-object v2, p3

    iput-object v2, v0, Lc/U0;->d:Ljava/lang/String;

    move v2, p4

    iput v2, v0, Lc/U0;->j:I

    move v2, p5

    iput-boolean v2, v0, Lc/U0;->m:Z

    move v2, p6

    iput-boolean v2, v0, Lc/U0;->n:Z

    move v2, p7

    iput v2, v0, Lc/U0;->k:I

    move v2, p8

    iput v2, v0, Lc/U0;->l:I

    move-object v2, p9

    iput-object v2, v0, Lc/U0;->e:Ljava/lang/String;

    move-object v2, p10

    iput-object v2, v0, Lc/U0;->f:Ljava/lang/String;

    move-object v2, p11

    iput-object v2, v0, Lc/U0;->g:Ljava/lang/String;

    move-object/from16 v2, p12

    iput-object v2, v0, Lc/U0;->p:Landroid/graphics/Bitmap;

    move-wide/from16 v2, p13

    iput-wide v2, v0, Lc/U0;->b:J

    move-wide/from16 v2, p15

    iput-wide v2, v0, Lc/U0;->c:J

    move/from16 v2, p17

    iput-boolean v2, v0, Lc/U0;->o:Z

    move-object/from16 v2, p18

    iput-object v2, v0, Lc/U0;->h:Ljava/lang/String;

    move-object/from16 v3, p19

    iput-object v3, v0, Lc/U0;->i:Ljava/lang/String;

    invoke-static/range {p18 .. p19}, Lc/j5;->b(Ljava/lang/String;Ljava/lang/String;)Lc/j5;

    move-result-object v2

    iput-object v2, v0, Lc/U0;->t:Lc/j5;

    if-nez v1, :cond_0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto :goto_0

    :cond_0
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move-object v1, v2

    :goto_0
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    iput-object v1, v0, Lc/U0;->v:Ljava/util/List;

    move-object/from16 v1, p21

    iput-object v1, v0, Lc/U0;->q:Lc/R0;

    move/from16 v1, p22

    iput v1, v0, Lc/U0;->r:I

    move/from16 v1, p23

    iput v1, v0, Lc/U0;->s:I

    move/from16 v1, p24

    iput-boolean v1, v0, Lc/U0;->u:Z

    return-void
.end method
