.class public final synthetic Lc/D7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Lc/O7;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Z

.field public final synthetic f:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>(Lc/O7;Ljava/lang/String;ILjava/lang/String;ZLandroid/app/Dialog;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/D7;->a:Lc/O7;

    iput-object p2, p0, Lc/D7;->b:Ljava/lang/String;

    iput p3, p0, Lc/D7;->c:I

    iput-object p4, p0, Lc/D7;->d:Ljava/lang/String;

    iput-boolean p5, p0, Lc/D7;->e:Z

    iput-object p6, p0, Lc/D7;->f:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget-object p1, p0, Lc/D7;->a:Lc/O7;

    iget-object v0, p0, Lc/D7;->b:Ljava/lang/String;

    iget v1, p0, Lc/D7;->c:I

    invoke-virtual {p1, v0, v1}, Lc/O7;->e(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, p0, Lc/D7;->d:Ljava/lang/String;

    iget-boolean v3, p0, Lc/D7;->e:Z

    invoke-virtual {p1, v2, v0, v1, v3}, Lc/O7;->q(Ljava/lang/String;Ljava/lang/String;IZ)V

    :cond_0
    iget-object p1, p0, Lc/D7;->f:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method
