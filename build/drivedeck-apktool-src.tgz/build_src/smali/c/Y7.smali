.class public final Lc/Y7;
.super Landroid/content/BroadcastReceiver;
.source "SourceFile"


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Lc/b;

.field public final synthetic c:Lc/Z7;


# direct methods
.method public constructor <init>(Lc/Z7;ZLc/b;)V
    .locals 0

    iput-object p1, p0, Lc/Y7;->c:Lc/Z7;

    iput-boolean p2, p0, Lc/Y7;->a:Z

    iput-object p3, p0, Lc/Y7;->b:Lc/b;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 1

    iget-object p1, p0, Lc/Y7;->c:Lc/Z7;

    iget-boolean p1, p1, Lc/Z7;->r:Z

    if-nez p1, :cond_1

    iget-object p1, p0, Lc/Y7;->c:Lc/Z7;

    iget-boolean p2, p0, Lc/Y7;->a:Z

    if-eqz p2, :cond_0

    iget p2, p1, Lc/Z7;->v:I

    const/4 v0, 0x4

    if-ne p2, v0, :cond_0

    const/4 p2, 0x1

    goto :goto_0

    :cond_0
    const/4 p2, 0x0

    :goto_0
    invoke-virtual {p1, p2}, Lc/Z7;->r(Z)V

    :cond_1
    iget-object p1, p0, Lc/Y7;->c:Lc/Z7;

    iget-boolean p1, p1, Lc/Z7;->r:Z

    if-nez p1, :cond_2

    iget-object p1, p0, Lc/Y7;->b:Lc/b;

    if-eqz p1, :cond_2

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p1, p2}, Lc/b;->accept(Ljava/lang/Object;)V

    :cond_2
    return-void
.end method
