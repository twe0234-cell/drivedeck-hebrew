.class public final Lc/k;
.super Landroid/widget/GridView;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/Context;

.field public final synthetic c:I


# direct methods
.method public constructor <init>(Landroid/content/Context;ILandroid/content/Context;I)V
    .locals 0

    iput p2, p0, Lc/k;->a:I

    iput-object p3, p0, Lc/k;->b:Landroid/content/Context;

    iput p4, p0, Lc/k;->c:I

    invoke-direct {p0, p1}, Landroid/widget/GridView;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public final onMeasure(II)V
    .locals 4

    iget v0, p0, Lc/k;->a:I

    if-lez v0, :cond_0

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    iget v2, p0, Lc/k;->c:I

    add-int/lit8 v2, v2, 0x3e

    int-to-float v2, v2

    iget-object v3, p0, Lc/k;->b:Landroid/content/Context;

    invoke-static {v3, v2}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v2

    mul-int/2addr v2, v0

    sub-int/2addr v1, v2

    add-int/lit8 v0, v0, -0x1

    div-int/2addr v1, v0

    const/4 v0, 0x0

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0}, Landroid/widget/GridView;->getVerticalSpacing()I

    move-result v1

    if-eq v1, v0, :cond_0

    invoke-virtual {p0, v0}, Landroid/widget/GridView;->setVerticalSpacing(I)V

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/widget/GridView;->onMeasure(II)V

    return-void
.end method
