.class public abstract Lc/k6;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static A(Ljava/io/File;Ljava/io/File;)Landroid/graphics/Bitmap;
    .locals 6

    const/high16 v0, 0x800000

    const/4 v1, 0x0

    :try_start_0
    invoke-static {p0, p1, v0}, Lc/k6;->o(Ljava/io/File;Ljava/io/File;I)[B

    move-result-object p0

    if-nez p0, :cond_0

    return-object v1

    :cond_0
    new-instance p1, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {p1}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p1, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v2, p0

    const/4 v3, 0x0

    invoke-static {p0, v3, v2, p1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    iget v2, p1, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    if-lez v2, :cond_4

    iget v4, p1, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    if-lez v4, :cond_4

    const/16 v5, 0x4000

    if-gt v2, v5, :cond_4

    if-le v4, v5, :cond_1

    goto :goto_2

    :cond_1
    iput v0, p1, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    :goto_0
    iget v0, p1, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    iget v2, p1, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    div-int/2addr v0, v2

    const/16 v4, 0x400

    if-gt v0, v4, :cond_3

    iget v0, p1, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    div-int/2addr v0, v2

    if-le v0, v4, :cond_2

    goto :goto_1

    :cond_2
    iput-boolean v3, p1, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v0, p0

    invoke-static {p0, v3, v0, p1}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p0

    return-object p0

    :cond_3
    :goto_1
    mul-int/lit8 v2, v2, 0x2

    iput v2, p1, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    :cond_4
    :goto_2
    return-object v1
.end method

.method public static B(III)Lc/J6;
    .locals 22

    move/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    or-int v3, v0, v1

    or-int/2addr v3, v2

    if-ltz v3, :cond_50

    const/16 v3, 0xff

    if-gt v0, v3, :cond_50

    if-gt v1, v3, :cond_50

    if-gt v2, v3, :cond_50

    const/4 v8, 0x1

    const/16 v9, 0x30

    const/16 v10, 0x64

    const/16 v11, 0xe

    const/16 v12, 0xd

    const/16 v13, 0xa

    const/16 v14, 0xf

    const-wide/16 v6, 0x0

    const-wide v16, 0x3f50624dd2f1a9fcL    # 0.001

    const/4 v4, 0x7

    const-wide v18, 0x3f847ae147ae147bL    # 0.01

    const-wide v20, 0x3fb999999999999aL    # 0.1

    const/4 v5, 0x0

    const/16 v15, 0x80

    packed-switch v0, :pswitch_data_0

    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_0
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    div-int/lit16 v1, v1, 0x3e8

    int-to-double v1, v1

    const/16 v3, 0x6e

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    mul-int/lit16 v1, v1, 0x9c

    const v2, 0x9c40

    div-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x21

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_2
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0xa00

    mul-int/2addr v2, v13

    add-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x403e333333333333L    # 30.2

    mul-double/2addr v3, v5

    int-to-double v1, v2

    const-wide v5, 0x3fbe353f7ced9168L    # 0.118

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const-wide v3, 0x40ae1e3333333333L    # 3855.1

    sub-double/2addr v1, v3

    const/16 v3, 0x47

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_4
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    add-int/lit16 v1, v1, -0x8000

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x29

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    mul-double/2addr v1, v3

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    const/16 v3, 0x16

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x6e

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x6d

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x40438ccccccccccdL    # 39.1

    mul-double/2addr v1, v3

    const-wide v3, 0x40c3880000000000L    # 10000.0

    div-double/2addr v1, v3

    const/16 v3, 0x26

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_b
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x400f47ae147ae148L    # 3.91

    mul-double/2addr v1, v3

    const-wide v3, 0x40c3880000000000L    # 10000.0

    div-double/2addr v1, v3

    const/16 v3, 0x26

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_c
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    add-int/lit16 v1, v1, 0xc8

    int-to-double v1, v1

    const/16 v3, 0x31

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_d
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    mul-double v2, v2, v18

    int-to-double v4, v1

    const-wide v6, 0x40047ae147ae147bL    # 2.56

    mul-double/2addr v4, v6

    add-double/2addr v4, v2

    invoke-direct {v0, v4, v5, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_e
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    mul-int/2addr v1, v13

    div-int/lit16 v1, v1, 0x2710

    int-to-double v1, v1

    const/16 v3, 0x4f

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_f
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x280

    int-to-double v3, v1

    int-to-double v1, v2

    const-wide/high16 v5, 0x4004000000000000L    # 2.5

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const/16 v3, 0x47

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_10
    new-instance v0, Lc/J6;

    mul-int/lit16 v2, v2, 0x100

    add-int/2addr v2, v1

    add-int/lit16 v2, v2, -0x8000

    int-to-double v1, v2

    const/16 v3, 0x13

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_11
    new-instance v0, Lc/J6;

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_12
    new-instance v0, Lc/J6;

    mul-int/lit8 v1, v1, 0x3c

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x12

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_13
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v5, 0x3fdcac083126e979L    # 0.448

    mul-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_14
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_15
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_16
    new-instance v0, Lc/J6;

    mul-int/lit16 v2, v2, 0x100

    add-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v3, 0x40a9666666666666L    # 3251.2

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_17
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    mul-int/2addr v2, v13

    div-int/lit16 v2, v2, 0x3e8

    add-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_18
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const/16 v3, 0x4b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_19
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x4b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1a
    new-instance v0, Lc/J6;

    int-to-double v1, v1

    const-wide v5, 0x4004666666666666L    # 2.55

    mul-double/2addr v1, v5

    const-wide v5, 0x4056800000000000L    # 90.0

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1b
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1c
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_0

    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide/high16 v5, -0x4020000000000000L    # -0.5

    mul-double/2addr v3, v5

    int-to-double v1, v2

    const-wide v5, 0x3f7ff2e48e8a71deL    # 0.0078

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const/16 v3, 0x4d

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_0
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3f70624dd2f1a9fcL    # 0.004

    mul-double/2addr v1, v3

    const/16 v3, 0x4d

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1d
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_1

    new-instance v0, Lc/J6;

    and-int/2addr v2, v14

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3f9999999999999aL    # 0.025

    mul-double/2addr v1, v3

    const/16 v3, 0x4d

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    const-wide v4, 0x3f9999999999999aL    # 0.025

    mul-double/2addr v2, v4

    int-to-double v4, v1

    const-wide v6, 0x400999999999999aL    # 3.2

    mul-double/2addr v4, v6

    add-double/2addr v4, v2

    const/16 v1, 0x4d

    invoke-direct {v0, v4, v5, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1e
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_2

    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x3ff47ae147ae147bL    # 1.28

    mul-double/2addr v3, v5

    and-int/lit8 v1, v2, 0xf

    int-to-double v1, v1

    const-wide v5, 0x3f947ae147ae147bL    # 0.02

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const/16 v3, 0x51

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x51

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_1f
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_3

    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x3f76f0068db8bac7L    # 0.0056

    mul-double/2addr v3, v5

    const-wide v5, 0x4066c147ae147ae1L    # 182.04

    add-double/2addr v3, v5

    and-int/lit8 v1, v2, 0xf

    int-to-double v1, v1

    const-wide v5, 0x3ff6b851eb851eb8L    # 1.42

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x3f76f0068db8bac7L    # 0.0056

    mul-double/2addr v3, v5

    and-int/lit8 v1, v2, 0xf

    int-to-double v1, v1

    const-wide v5, 0x3ff6b851eb851eb8L    # 1.42

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_20
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_4

    new-instance v0, Lc/J6;

    mul-int/lit8 v1, v1, -0xa

    and-int/2addr v2, v14

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_4
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x4006666666666666L    # 2.8

    mul-double/2addr v3, v5

    and-int/lit8 v1, v2, 0xf

    int-to-double v1, v1

    const-wide v5, 0x3fd999999999999aL    # 0.4

    mul-double/2addr v1, v5

    add-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_21
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_5

    new-instance v0, Lc/J6;

    mul-int/lit8 v1, v1, 0x20

    rsub-int/lit8 v1, v1, 0x0

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_5
    new-instance v0, Lc/J6;

    and-int/lit8 v1, v2, 0xf

    mul-int/lit8 v1, v1, 0x2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_22
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_6

    new-instance v0, Lc/J6;

    sub-int/2addr v5, v1

    int-to-double v1, v5

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_6
    new-instance v0, Lc/J6;

    sub-int/2addr v3, v1

    int-to-double v1, v3

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_23
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_24
    if-nez v2, :cond_7

    new-instance v0, Lc/J6;

    const/16 v1, 0x16

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_7
    if-eqz v1, :cond_9

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_8

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    div-int/2addr v1, v10

    int-to-double v1, v1

    const/16 v3, 0x16

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_8
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    div-int/2addr v2, v10

    int-to-double v1, v2

    const-wide v3, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v3

    const/16 v3, 0x16

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_9
    new-instance v0, Lc/J6;

    const/16 v1, 0x16

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_25
    if-nez v2, :cond_a

    new-instance v0, Lc/J6;

    const/16 v1, 0xc

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_a
    if-eqz v1, :cond_c

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_b

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    div-int/2addr v1, v10

    int-to-double v1, v1

    const/16 v3, 0xc

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_b
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    div-int/2addr v2, v10

    int-to-double v1, v2

    const-wide v3, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v3

    const/16 v3, 0xc

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_c
    new-instance v0, Lc/J6;

    const/16 v1, 0xc

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_26
    if-nez v1, :cond_d

    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_d
    if-eqz v2, :cond_f

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_e

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    div-int/2addr v1, v10

    int-to-double v1, v1

    const-wide v5, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_e
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    div-int/2addr v2, v10

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_f
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_27
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_28
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_29
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_2a
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_2b
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    invoke-direct {v0, v1, v2, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_2c
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x2c

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_2d
    new-instance v0, Lc/J6;

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    long-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_2e
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_2f
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_30
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x404387ae147ae148L    # 39.06

    mul-double/2addr v1, v3

    const-wide v3, 0x40c3880000000000L    # 10000.0

    div-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_31
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide/high16 v5, 0x3fe0000000000000L    # 0.5

    mul-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_32
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_33
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3f39992e39cf2ea7L    # 3.906E-4

    mul-double/2addr v1, v3

    const/16 v3, 0x3b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_34
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3f7003eea209aaa4L    # 0.00391

    mul-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_35
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x69

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_36
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_37
    new-instance v0, Lc/J6;

    sub-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_38
    new-instance v0, Lc/J6;

    sub-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x6a

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_39
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x13

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3a
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_3b
    new-instance v0, Lc/J6;

    mul-int/lit16 v2, v2, 0x100

    add-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v18

    const-wide v3, 0x40747ae147ae147bL    # 327.68

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3c
    new-instance v0, Lc/J6;

    mul-int/lit16 v2, v2, 0x100

    add-int/2addr v2, v1

    int-to-double v1, v2

    const-wide/high16 v3, 0x3fe0000000000000L    # 0.5

    mul-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3d
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v5, 0x3ff6978d4fdf3b64L    # 1.412

    mul-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3e
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_3f
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_40
    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_10

    new-instance v0, Lc/J6;

    int-to-double v1, v1

    const-wide v3, -0x401b851eb851eb85L    # -0.64

    mul-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_10
    new-instance v0, Lc/J6;

    int-to-double v1, v1

    const-wide v3, 0x3fe47ae147ae147bL    # 0.64

    mul-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_41
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const/16 v3, 0x69

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_42
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const/16 v3, 0x35

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_43
    if-eqz v1, :cond_12

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_11

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_11
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    sub-int/2addr v2, v15

    int-to-double v1, v2

    const/16 v3, 0x14

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_12
    if-eqz v2, :cond_14

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_13

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_13
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    sub-int/2addr v2, v15

    int-to-double v1, v2

    const/16 v3, 0x14

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_14
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_44
    if-eqz v1, :cond_16

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_15

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_15
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v18

    const-wide v3, 0x3ff47ae147ae147bL    # 1.28

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_16
    if-eqz v2, :cond_18

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_17

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_17
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v18

    const-wide v3, 0x3ff47ae147ae147bL    # 1.28

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_18
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_45
    if-eqz v1, :cond_1a

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_19

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_19
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    const-wide v5, 0x3fc0624dd2f1a9fcL    # 0.128

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1a
    if-eqz v2, :cond_1c

    and-int/lit16 v0, v2, 0x80

    if-ne v0, v15, :cond_1b

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1b
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    const-wide v5, 0x3fc0624dd2f1a9fcL    # 0.128

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1c
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_46
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    mul-int/lit16 v1, v1, 0x100

    add-int/lit8 v1, v1, 0x48

    int-to-double v1, v1

    const/4 v3, 0x3

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_47
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_48
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_49
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_4a
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_4b
    if-eqz v1, :cond_1e

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_1d

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1d
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1e
    if-eqz v2, :cond_20

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_1f

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_1f
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_20
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_4c
    if-eqz v1, :cond_22

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_21

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x14

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_21
    const/16 v3, 0x14

    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v18

    const-wide v4, 0x3ff47ae147ae147bL    # 1.28

    sub-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_22
    const/16 v3, 0x14

    if-eqz v2, :cond_24

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_23

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_23
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v18

    const-wide v4, 0x3ff47ae147ae147bL    # 1.28

    sub-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_24
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_4d
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_4e
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    add-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_4f
    if-eqz v1, :cond_26

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_25

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x24

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_25
    const/16 v3, 0x24

    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v4, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_26
    const/16 v3, 0x24

    if-eqz v2, :cond_28

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_27

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_27
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v4, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_28
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_50
    if-eqz v1, :cond_2a

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_29

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    const/16 v3, 0x68

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_29
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    const-wide v3, 0x3fc0624dd2f1a9fcL    # 0.128

    add-double/2addr v1, v3

    const/16 v3, 0x68

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2a
    if-eqz v2, :cond_2c

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_2b

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    const/16 v3, 0x68

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2b
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    const-wide v3, 0x3fc0624dd2f1a9fcL    # 0.128

    add-double/2addr v1, v3

    const/16 v3, 0x68

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2c
    new-instance v0, Lc/J6;

    const/16 v1, 0x68

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_51
    if-eqz v1, :cond_2e

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_2d

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2d
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2e
    if-eqz v2, :cond_30

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_2f

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_2f
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_30
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_52
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_53
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_54
    new-instance v0, Lc/J6;

    mul-int/lit8 v2, v2, 0x5

    mul-int/lit8 v1, v1, 0x5

    sub-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_55
    if-eqz v1, :cond_32

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_31

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x34

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_31
    const/16 v3, 0x34

    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v4, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_32
    const/16 v3, 0x34

    if-eqz v2, :cond_34

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_33

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_33
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    const-wide v4, 0x402999999999999aL    # 12.8

    add-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_34
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_56
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_57
    if-eqz v1, :cond_36

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_35

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_35
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_36
    if-eqz v2, :cond_38

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_37

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_37
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_38
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_58
    if-eqz v1, :cond_3a

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_39

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    const-wide v3, 0x3fc0624dd2f1a9fcL    # 0.128

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_39
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3a
    if-eqz v2, :cond_3c

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_3b

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v16

    const-wide v3, 0x3fc0624dd2f1a9fcL    # 0.128

    sub-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3b
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v16

    invoke-direct {v0, v1, v2, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3c
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_59
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const/4 v3, 0x3

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5a
    if-eqz v1, :cond_3e

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_3d

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v5, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3d
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3e
    if-eqz v2, :cond_40

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_3f

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v5, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_3f
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_40
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5b
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x21

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5c
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_5d
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x1b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5e
    if-eqz v1, :cond_42

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_41

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v3, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v3

    const/16 v3, 0x67

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_41
    const/16 v3, 0x67

    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_42
    const/16 v3, 0x67

    if-eqz v2, :cond_44

    and-int/lit16 v0, v2, 0x80

    if-eq v0, v15, :cond_43

    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const-wide v4, 0x402999999999999aL    # 12.8

    sub-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_43
    new-instance v0, Lc/J6;

    and-int/lit8 v2, v2, 0x7f

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_44
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_5f
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    const/16 v3, 0x3b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_60
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const-wide v3, 0x3f676ddaceee0f3dL    # 0.00286

    mul-double/2addr v1, v3

    const/16 v3, 0x67

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_61
    and-int/lit16 v0, v1, 0x80

    if-eq v0, v15, :cond_45

    new-instance v0, Lc/J6;

    int-to-double v1, v2

    const-wide v3, 0x3fb8e8a71de69ad4L    # 0.0973

    mul-double/2addr v1, v3

    const/16 v3, 0x2b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_45
    new-instance v0, Lc/J6;

    int-to-double v1, v2

    const-wide v3, 0x3fb8e8a71de69ad4L    # 0.0973

    mul-double/2addr v1, v3

    const-wide v3, -0x3fc7174bc6a7ef9eL    # -24.909

    add-double/2addr v1, v3

    const/16 v3, 0x2b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_62
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    mul-double v1, v1, v18

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_63
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const-wide v3, 0x4058866666666666L    # 98.1

    mul-double/2addr v1, v3

    const-wide v3, 0x40c3880000000000L    # 10000.0

    div-double/2addr v1, v3

    const/16 v3, 0x2b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_64
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-short v1, v1

    int-to-double v1, v1

    const-wide v5, 0x3fa6666666666666L    # 0.04375

    mul-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_65
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x1b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_66
    new-instance v0, Lc/J6;

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_67
    new-instance v0, Lc/J6;

    int-to-double v1, v2

    const-wide v3, 0x3ffd1a9fbe76c8b4L    # 1.819

    mul-double/2addr v1, v3

    const/16 v3, 0x8

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_68
    new-instance v3, Lc/J6;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p0 .. p0}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p1 .. p1}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Lc/k6;->z(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v0

    long-to-double v0, v0

    invoke-direct {v3, v0, v1, v5}, Lc/J6;-><init>(DI)V

    return-object v3

    :pswitch_69
    if-gtz v1, :cond_46

    new-instance v0, Lc/J6;

    int-to-double v1, v2

    const/16 v3, 0x1b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_46
    new-instance v0, Lc/J6;

    add-int/2addr v1, v8

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x1b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6a
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6b
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6c
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x1a

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6d
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide/high16 v5, 0x4019000000000000L    # 6.25

    mul-double/2addr v3, v5

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    div-double/2addr v3, v5

    int-to-double v1, v2

    const-wide v5, 0x4014ae147ae147aeL    # 5.17

    mul-double/2addr v1, v5

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    div-double/2addr v1, v5

    add-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6e
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x4b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_6f
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3fc89374bc6a7efaL    # 0.192

    mul-double/2addr v1, v3

    const/16 v3, 0x2b

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_70
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x3fa0a915379fa97eL    # 0.03254

    mul-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_71
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x401d75c28f5c28f6L    # 7.365

    div-double/2addr v1, v3

    const/16 v3, 0x47

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_72
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x280

    int-to-double v5, v1

    int-to-double v1, v2

    const-wide/high16 v7, 0x4004000000000000L    # 2.5

    mul-double/2addr v1, v7

    add-double/2addr v1, v5

    invoke-direct {v0, v1, v2, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_73
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    const-wide v3, 0x407ff1eb851eb852L    # 511.12

    div-double/2addr v1, v3

    invoke-direct {v0, v1, v2, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_74
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v18

    add-int/lit8 v1, v2, -0x7f

    int-to-double v1, v1

    mul-double/2addr v3, v1

    const/16 v1, 0x24

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_75
    new-instance v0, Lc/J6;

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x1a

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_76
    new-instance v0, Lc/J6;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    long-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_77
    new-instance v0, Lc/J6;

    const-wide v3, 0x3fd0624dd2f1a9fcL    # 0.256

    int-to-double v5, v1

    mul-double/2addr v5, v3

    int-to-double v1, v2

    mul-double/2addr v5, v1

    const/16 v1, 0x67

    invoke-direct {v0, v5, v6, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_78
    if-eqz v1, :cond_47

    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    div-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_47
    new-instance v0, Lc/J6;

    add-int/lit8 v1, v2, -0x80

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_79
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x11

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7a
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    const v2, 0x8000

    div-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7b
    if-gt v2, v15, :cond_48

    new-instance v0, Lc/J6;

    const-wide v3, 0x3ff05c28f5c28f5cL    # 1.0225

    int-to-double v1, v2

    mul-double/2addr v1, v3

    const/16 v3, 0x67

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_48
    const/16 v3, 0x67

    new-instance v0, Lc/J6;

    rsub-int v1, v2, 0x100

    int-to-double v1, v1

    const-wide v4, 0x3ff05c28f5c28f5cL    # 1.0225

    mul-double/2addr v1, v4

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7c
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    const/high16 v2, 0x10000

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7d
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7e
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    div-int/lit16 v1, v1, 0xc8

    int-to-double v1, v1

    const/16 v3, 0x11

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_7f
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_80
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    int-to-double v2, v2

    const-wide v4, 0x3ff6c154c985f06fL    # 1.4222

    mul-double/2addr v2, v4

    const-wide v4, 0x3f789374bc6a7efaL    # 0.006

    int-to-double v6, v1

    mul-double/2addr v6, v4

    add-double/2addr v6, v2

    const/16 v1, 0x8

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_81
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    const-wide v4, 0x3f947ae147ae147bL    # 0.02

    mul-double/2addr v2, v4

    int-to-double v4, v1

    mul-double/2addr v2, v4

    sub-double/2addr v2, v4

    invoke-direct {v0, v2, v3, v12}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_82
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    div-int/2addr v2, v3

    mul-int/2addr v2, v1

    int-to-double v1, v2

    const/16 v3, 0x66

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_83
    if-eqz v1, :cond_49

    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    int-to-double v2, v2

    div-double v2, v2, v18

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const/16 v1, 0x34

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_49
    const/16 v1, 0x34

    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    int-to-double v2, v2

    div-double v2, v2, v18

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_84
    new-instance v0, Lc/J6;

    div-int/lit8 v2, v2, 0x4

    int-to-double v2, v2

    mul-double v2, v2, v20

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const/16 v1, 0x66

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_85
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v3

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_86
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    mul-int/2addr v2, v1

    int-to-double v1, v2

    const/16 v3, 0x2c

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_87
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    add-int/lit16 v1, v1, -0xc80

    int-to-double v1, v1

    const-wide v3, 0x3f661e4f765fd8aeL    # 0.0027

    mul-double/2addr v1, v3

    const/16 v3, 0x51

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_88
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v20

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const-wide/high16 v1, 0x4059000000000000L    # 100.0

    div-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_89
    new-instance v0, Lc/J6;

    mul-int/lit8 v1, v1, 0x3c

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x12

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8a
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    mul-double v2, v2, v20

    const-wide v4, 0x4039800000000000L    # 25.5

    int-to-double v6, v1

    mul-double/2addr v6, v4

    add-double/2addr v6, v2

    invoke-direct {v0, v6, v7, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8b
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    mul-double v2, v2, v20

    const-wide v4, 0x4039800000000000L    # 25.5

    int-to-double v6, v1

    mul-double/2addr v6, v4

    add-double/2addr v6, v2

    const-wide/high16 v1, 0x4079000000000000L    # 400.0

    sub-double/2addr v6, v1

    const/16 v1, 0x2e

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8c
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v3

    add-int/2addr v1, v2

    int-to-double v1, v1

    const/16 v3, 0x3e

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8d
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    mul-double v2, v2, v20

    const-wide v4, 0x4039800000000000L    # 25.5

    int-to-double v6, v1

    mul-double/2addr v6, v4

    add-double/2addr v6, v2

    const-wide/high16 v1, 0x4079000000000000L    # 400.0

    sub-double/2addr v6, v1

    const/16 v1, 0x3b

    invoke-direct {v0, v6, v7, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8e
    new-instance v0, Lc/J6;

    div-int/lit16 v2, v2, 0x100

    mul-int/2addr v2, v1

    int-to-double v1, v2

    const/16 v3, 0x66

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_8f
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    int-to-double v2, v2

    mul-double v2, v2, v16

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const/16 v1, 0x51

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_90
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_91
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0xa00

    mul-int/2addr v2, v13

    add-int/2addr v2, v1

    int-to-double v1, v2

    const/4 v3, 0x3

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_92
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v18

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const/16 v1, 0xc

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_93
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    int-to-double v2, v2

    mul-double v2, v2, v18

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const/16 v1, 0x2e

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_94
    if-eqz v1, :cond_4a

    new-instance v0, Lc/J6;

    mul-int/2addr v2, v10

    div-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_4a
    new-instance v0, Lc/J6;

    mul-int/lit8 v1, v2, 0x64

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_95
    if-gt v2, v15, :cond_4b

    new-instance v0, Lc/J6;

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_4b
    new-instance v0, Lc/J6;

    add-int/lit16 v1, v2, -0x100

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_96
    new-instance v0, Lc/J6;

    div-int/lit16 v2, v2, 0xa00

    sub-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_97
    new-instance v0, Lc/J6;

    div-int/lit8 v2, v2, 0xc

    sub-int/2addr v2, v1

    int-to-double v1, v2

    const/16 v3, 0x51

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_98
    if-lt v2, v1, :cond_4c

    new-instance v0, Lc/J6;

    const-wide/high16 v1, 0x4000000000000000L    # 2.0

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_4c
    new-instance v0, Lc/J6;

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_99
    new-instance v0, Lc/J6;

    sub-int v1, v2, v1

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9a
    add-int/lit8 v0, v2, -0x80

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v2

    int-to-double v2, v2

    mul-double v2, v2, v18

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const-wide/high16 v6, 0x4060000000000000L    # 128.0

    cmpl-double v1, v2, v6

    if-ltz v1, :cond_4d

    new-instance v1, Lc/J6;

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-double v2, v0

    mul-double v2, v2, v18

    mul-double/2addr v2, v4

    const/16 v0, 0x65

    invoke-direct {v1, v2, v3, v0}, Lc/J6;-><init>(DI)V

    return-object v1

    :cond_4d
    new-instance v1, Lc/J6;

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-double v2, v0

    mul-double v2, v2, v18

    mul-double/2addr v2, v4

    invoke-direct {v1, v2, v3, v10}, Lc/J6;-><init>(DI)V

    return-object v1

    :pswitch_9b
    new-instance v0, Lc/J6;

    sub-int v1, v2, v1

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9c
    new-instance v0, Lc/J6;

    int-to-double v2, v2

    const-wide v4, 0x3ff6bc6a7ef9db23L    # 1.421

    mul-double/2addr v2, v4

    div-int/lit16 v1, v1, 0xb6

    int-to-double v4, v1

    add-double/2addr v2, v4

    const/16 v1, 0x8

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9d
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v16

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const/16 v1, 0x3b

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9e
    new-instance v0, Lc/J6;

    div-int/lit16 v2, v2, 0x100

    mul-int/2addr v2, v1

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_9f
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v16

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const/16 v1, 0x2c

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a0
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v16

    int-to-double v1, v2

    mul-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a1
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v15

    mul-int/2addr v2, v1

    div-int/2addr v2, v15

    int-to-double v1, v2

    invoke-direct {v0, v1, v2, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a2
    new-instance v0, Lc/J6;

    mul-int/2addr v1, v2

    int-to-double v1, v1

    mul-double v1, v1, v18

    const/16 v3, 0x18

    invoke-direct {v0, v1, v2, v3}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a3
    new-instance v0, Lc/J6;

    const-wide v3, 0x3fa47ae147ae147bL    # 0.04

    int-to-double v5, v1

    mul-double/2addr v5, v3

    int-to-double v1, v2

    mul-double/2addr v5, v1

    const/16 v1, 0x34

    invoke-direct {v0, v5, v6, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a4
    new-instance v0, Lc/J6;

    mul-int/lit16 v1, v1, 0x100

    add-int/2addr v1, v2

    int-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a5
    new-instance v0, Lc/J6;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p2 .. p2}, Ljava/lang/Integer;->toBinaryString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    long-to-double v1, v1

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a6
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v18

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const/16 v1, 0x2c

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a7
    new-instance v0, Lc/J6;

    const-wide v3, 0x3f747ae147ae147bL    # 0.005

    int-to-double v5, v1

    mul-double/2addr v5, v3

    int-to-double v1, v2

    mul-double/2addr v5, v1

    invoke-direct {v0, v5, v6, v9}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a8
    new-instance v0, Lc/J6;

    add-int/lit8 v2, v2, -0x7f

    int-to-double v2, v2

    mul-double v2, v2, v16

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const/16 v1, 0x24

    invoke-direct {v0, v2, v3, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_a9
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v16

    int-to-double v1, v2

    mul-double/2addr v3, v1

    const/16 v1, 0x1a

    invoke-direct {v0, v3, v4, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_aa
    new-instance v0, Lc/J6;

    const-wide v3, 0x3f1a36e2eb1c432dL    # 1.0E-4

    int-to-double v6, v1

    mul-double/2addr v6, v3

    add-int/lit8 v1, v2, -0x80

    int-to-double v1, v1

    mul-double/2addr v6, v1

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    add-double/2addr v6, v1

    invoke-direct {v0, v6, v7, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_ab
    if-eqz v2, :cond_4e

    new-instance v0, Lc/J6;

    const-wide/high16 v1, 0x3ff0000000000000L    # 1.0

    invoke-direct {v0, v1, v2, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_4e
    new-instance v0, Lc/J6;

    invoke-direct {v0, v6, v7, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_ac
    new-instance v0, Lc/J6;

    add-int/lit8 v2, v2, -0x7f

    int-to-double v2, v2

    const-wide v5, 0x3f947ae147ae147bL    # 0.02

    mul-double/2addr v2, v5

    int-to-double v5, v1

    mul-double/2addr v2, v5

    invoke-direct {v0, v2, v3, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_ad
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v20

    int-to-double v1, v2

    mul-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v5}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_ae
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v18

    int-to-double v1, v2

    mul-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v8}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_af
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    mul-double v3, v3, v16

    int-to-double v1, v2

    mul-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v13}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_b0
    new-instance v0, Lc/J6;

    sub-int/2addr v2, v10

    mul-int/2addr v2, v1

    int-to-double v1, v2

    mul-double v1, v1, v20

    invoke-direct {v0, v1, v2, v14}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_b1
    add-int/lit8 v0, v2, -0x7f

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v2

    int-to-double v2, v2

    mul-double v2, v2, v18

    int-to-double v4, v1

    mul-double/2addr v2, v4

    const-wide v6, 0x405fc00000000000L    # 127.0

    cmpg-double v1, v2, v6

    if-gtz v1, :cond_4f

    new-instance v1, Lc/J6;

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-double v2, v0

    mul-double v2, v2, v18

    mul-double/2addr v2, v4

    const/16 v0, 0x65

    invoke-direct {v1, v2, v3, v0}, Lc/J6;-><init>(DI)V

    return-object v1

    :cond_4f
    new-instance v1, Lc/J6;

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-double v2, v0

    mul-double v2, v2, v18

    mul-double/2addr v2, v4

    invoke-direct {v1, v2, v3, v10}, Lc/J6;-><init>(DI)V

    return-object v1

    :pswitch_b2
    new-instance v0, Lc/J6;

    const-wide v5, 0x3f60624dd2f1a9fcL    # 0.002

    int-to-double v7, v1

    mul-double/2addr v7, v5

    int-to-double v1, v2

    mul-double/2addr v7, v1

    invoke-direct {v0, v7, v8, v4}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_b3
    new-instance v0, Lc/J6;

    int-to-double v3, v1

    const-wide v5, 0x3f60624dd2f1a9fcL    # 0.002

    mul-double/2addr v3, v5

    int-to-double v1, v2

    mul-double/2addr v3, v1

    invoke-direct {v0, v3, v4, v11}, Lc/J6;-><init>(DI)V

    return-object v0

    :pswitch_b4
    new-instance v0, Lc/J6;

    const-wide v3, 0x3fc999999999999aL    # 0.2

    int-to-double v5, v1

    mul-double/2addr v5, v3

    int-to-double v1, v2

    mul-double/2addr v5, v1

    const/4 v1, 0x6

    invoke-direct {v0, v5, v6, v1}, Lc/J6;-><init>(DI)V

    return-object v0

    :cond_50
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "TP5 requires unsigned bytes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_b4
        :pswitch_b3
        :pswitch_b2
        :pswitch_b1
        :pswitch_b0
        :pswitch_af
        :pswitch_ae
        :pswitch_ad
        :pswitch_ac
        :pswitch_ab
        :pswitch_aa
        :pswitch_a9
        :pswitch_a8
        :pswitch_a7
        :pswitch_a6
        :pswitch_a5
        :pswitch_a4
        :pswitch_a3
        :pswitch_a2
        :pswitch_a1
        :pswitch_a0
        :pswitch_9f
        :pswitch_9e
        :pswitch_9d
        :pswitch_9c
        :pswitch_9b
        :pswitch_9a
        :pswitch_99
        :pswitch_98
        :pswitch_97
        :pswitch_96
        :pswitch_95
        :pswitch_94
        :pswitch_93
        :pswitch_92
        :pswitch_91
        :pswitch_90
        :pswitch_8f
        :pswitch_8e
        :pswitch_8d
        :pswitch_8c
        :pswitch_8b
        :pswitch_8a
        :pswitch_89
        :pswitch_88
        :pswitch_87
        :pswitch_86
        :pswitch_85
        :pswitch_84
        :pswitch_83
        :pswitch_82
        :pswitch_81
        :pswitch_80
        :pswitch_7f
        :pswitch_7e
        :pswitch_7d
        :pswitch_7c
        :pswitch_7b
        :pswitch_7a
        :pswitch_79
        :pswitch_78
        :pswitch_77
        :pswitch_76
        :pswitch_75
        :pswitch_74
        :pswitch_73
        :pswitch_72
        :pswitch_71
        :pswitch_70
        :pswitch_6f
        :pswitch_6e
        :pswitch_6d
        :pswitch_6c
        :pswitch_6b
        :pswitch_6a
        :pswitch_69
        :pswitch_68
        :pswitch_67
        :pswitch_66
        :pswitch_65
        :pswitch_64
        :pswitch_63
        :pswitch_62
        :pswitch_61
        :pswitch_60
        :pswitch_5f
        :pswitch_5e
        :pswitch_5d
        :pswitch_5c
        :pswitch_5b
        :pswitch_5a
        :pswitch_59
        :pswitch_58
        :pswitch_57
        :pswitch_56
        :pswitch_55
        :pswitch_54
        :pswitch_53
        :pswitch_52
        :pswitch_51
        :pswitch_50
        :pswitch_4f
        :pswitch_4e
        :pswitch_4d
        :pswitch_4c
        :pswitch_4b
        :pswitch_4a
        :pswitch_49
        :pswitch_48
        :pswitch_47
        :pswitch_46
        :pswitch_45
        :pswitch_44
        :pswitch_43
        :pswitch_42
        :pswitch_41
        :pswitch_40
        :pswitch_3f
        :pswitch_3e
        :pswitch_3d
        :pswitch_3c
        :pswitch_3b
        :pswitch_3a
        :pswitch_39
        :pswitch_38
        :pswitch_37
        :pswitch_36
        :pswitch_35
        :pswitch_34
        :pswitch_33
        :pswitch_32
        :pswitch_31
        :pswitch_30
        :pswitch_2f
        :pswitch_2e
        :pswitch_2d
        :pswitch_2c
        :pswitch_2b
        :pswitch_2a
        :pswitch_29
        :pswitch_28
        :pswitch_27
        :pswitch_26
        :pswitch_25
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static C(Lc/j6;Lc/i6;Ljava/util/HashSet;Ljava/util/HashMap;Ljava/util/HashMap;)I
    .locals 6

    if-eqz p1, :cond_d

    iget-boolean v0, p1, Lc/i6;->v:Z

    if-eqz v0, :cond_d

    iget-object v0, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    invoke-virtual {p4, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-virtual {p3, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    const/16 v2, 0x40

    if-eqz v1, :cond_1

    invoke-virtual {p2}, Ljava/util/HashSet;->size()I

    move-result p0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    add-int/2addr p1, p0

    if-gt p1, v2, :cond_0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    :cond_0
    new-instance p0, Lc/g7;

    invoke-direct {p0}, Lc/g7;-><init>()V

    throw p0

    :cond_1
    invoke-virtual {p2}, Ljava/util/HashSet;->size()I

    move-result v1

    if-ge v1, v2, :cond_a

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :try_start_0
    iget-object p1, p1, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v1, 0x1

    move v3, v1

    :cond_2
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {p0, v4}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v5

    if-eqz v5, :cond_3

    invoke-static {p0, v5, p2, p3, p4}, Lc/k6;->C(Lc/j6;Lc/i6;Ljava/util/HashSet;Ljava/util/HashMap;Ljava/util/HashMap;)I

    move-result v4

    add-int/2addr v4, v1

    invoke-static {v3, v4}, Ljava/lang/Math;->max(II)I

    move-result v3

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_3

    :catch_0
    move-exception p0

    goto :goto_2

    :cond_3
    invoke-static {v4}, Lc/G8;->F(Ljava/lang/String;)Lc/v5;

    move-result-object v5

    if-nez v5, :cond_2

    const-string v5, "Vehicle speed"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_4

    sget-object v5, Lc/G8;->v:Lc/v5;

    goto :goto_1

    :cond_4
    const-string v5, "Altitude (GPS)"

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5

    sget-object v5, Lc/G8;->s:Lc/v5;

    goto :goto_1

    :cond_5
    const/4 v5, 0x0

    :goto_1
    if-eqz v5, :cond_6

    goto :goto_0

    :cond_6
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p3, "\u041d\u0435\u0442 \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u0438: "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7
    if-gt v3, v2, :cond_8

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {p3, v0, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    return v3

    :cond_8
    :try_start_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u0430\u044f \u0446\u0435\u043f\u043e\u0447\u043a\u0430 PID"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    :try_start_2
    instance-of p1, p0, Lc/g7;

    if-nez p1, :cond_9

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p4, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_9
    throw p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_3
    invoke-virtual {p2, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    throw p0

    :cond_a
    new-instance p0, Lc/g7;

    invoke-direct {p0}, Lc/g7;-><init>()V

    throw p0

    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p4, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u0426\u0438\u043a\u043b \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u0435\u0439 PID"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u0417\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u0430"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static D(Landroid/widget/TextView;I)V
    .locals 3

    int-to-float v0, p1

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const v1, 0x3f4ccccd    # 0.8f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/16 v1, 0xb

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v0, p1, v1, v2}, Landroid/widget/TextView;->setAutoSizeTextTypeUniformWithConfiguration(IIII)V

    return-void
.end method

.method public static E(IFFFI)Z
    .locals 0

    invoke-static {p0, p1, p3, p4}, Lc/k6;->u(IFFI)I

    move-result p1

    if-lez p1, :cond_0

    invoke-static {p0, p1}, Lc/k6;->l0(II)I

    move-result p0

    int-to-float p0, p0

    invoke-static {p4}, Lc/k6;->s(I)F

    move-result p1

    mul-float/2addr p1, p0

    mul-float/2addr p1, p3

    const/high16 p0, 0x3f000000    # 0.5f

    add-float/2addr p2, p0

    cmpg-float p0, p1, p2

    if-gtz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static F(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 1

    invoke-static {p0, p1, p2, p3}, Lc/k6;->Z(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    const/4 p2, 0x0

    if-nez p1, :cond_0

    return-object p2

    :cond_0
    array-length p3, p1

    const/4 v0, 0x4

    if-ne p3, v0, :cond_1

    return-object p1

    :cond_1
    invoke-static {p0}, Lc/k6;->I(I)I

    move-result p0

    const/4 p3, 0x6

    if-ne p0, p3, :cond_2

    array-length p0, p1

    const/4 p3, 0x5

    if-ne p0, p3, :cond_2

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p2

    :cond_2
    return-object p2
.end method

.method public static G(Lc/U8;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "https://github.com/RotkivKiv/DriveDeck-Updates/releases/download/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lc/U8;->h:Ljava/lang/String;

    invoke-static {v1}, Lc/k6;->H(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "-code"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lc/U8;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lc/U8;->c:Ljava/lang/String;

    invoke-static {p0}, Lc/k6;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static H(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "stable"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "beta"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "alpha"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "voice"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "voice-language-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043a\u0430\u043d\u0430\u043b \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-static {p0}, Lc/k6;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2f

    const/16 v1, 0x2d

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static I(I)I
    .locals 1

    const/16 v0, 0x2b

    if-eq p0, v0, :cond_0

    packed-switch p0, :pswitch_data_0

    const/4 p0, 0x0

    return p0

    :pswitch_0
    const/16 p0, 0x8

    return p0

    :pswitch_1
    const/4 p0, 0x6

    return p0

    :cond_0
    :pswitch_2
    const/4 p0, 0x3

    return p0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public static J(I)Ljava/lang/String;
    .locals 2

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string v1, "%02X"

    invoke-static {v0, v1, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static K(Ljava/lang/String;)[B
    .locals 5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    new-array v1, v0, [B

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    mul-int/lit8 v3, v2, 0x2

    add-int/lit8 v4, v3, 0x2

    invoke-virtual {p0, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v1
.end method

.method public static L(Ljava/lang/String;)[B
    .locals 5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    new-array v1, v0, [B

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_0

    mul-int/lit8 v3, v2, 0x2

    add-int/lit8 v4, v3, 0x2

    invoke-virtual {p0, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-object v1
.end method

.method public static M(Lorg/json/JSONObject;Ljava/lang/String;I)I
    .locals 4

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p0, p1}, Lc/k6;->V(Lorg/json/JSONObject;Ljava/lang/String;)D

    move-result-wide v0

    goto :goto_0

    :cond_0
    const-wide/16 v0, 0x0

    :goto_0
    invoke-static {v0, v1}, Ljava/lang/Math;->rint(D)D

    move-result-wide v2

    cmpl-double v2, v0, v2

    if-nez v2, :cond_1

    const/4 v2, 0x0

    int-to-double v2, v2

    cmpg-double v2, v0, v2

    if-ltz v2, :cond_1

    int-to-double v2, p2

    cmpl-double p2, v0, v2

    if-gtz p2, :cond_1

    double-to-int p2, v0

    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    return p2

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p2, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u043f\u043e\u043b\u0435: "

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static N(Landroid/content/Intent;)Z
    .locals 1

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p0

    const-string v0, "android.intent.action.ASSIST"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "android.intent.action.VOICE_ASSIST"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "android.intent.action.VOICE_COMMAND"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1

    :cond_0
    const/4 p0, 0x1

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static O(Lc/j6;)Ljava/lang/String;
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "user_pids_"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-nez p0, :cond_0

    const-string p0, "000000000000000000000000"

    goto :goto_0

    :cond_0
    iget-object p0, p0, Lc/j6;->a:Ljava/lang/String;

    :goto_0
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;
    .locals 2

    :try_start_0
    new-instance v0, Lc/c7;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lc/c7;-><init>(Landroid/content/SharedPreferences;Lc/j6;I)V

    invoke-static {v0}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lc/j6;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    return-object p1
.end method

.method public static Q(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "voice-language-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0xf

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ld/a;->b(Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "https://storage.yandexcloud.net/drivedeck-updates-ru/modules/voice/languages/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "/update.json"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-string v0, "voice"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string p0, "https://storage.yandexcloud.net/drivedeck-updates-ru/modules/voice/v3/update.json"

    return-object p0

    :cond_1
    const-string v0, "alpha"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string p0, "https://storage.yandexcloud.net/drivedeck-updates-ru/alpha-0.5.2/update.json"

    return-object p0

    :cond_2
    const-string v0, "beta"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    const-string p0, "https://storage.yandexcloud.net/drivedeck-updates-ru/beta/update.json"

    goto :goto_0

    :cond_3
    const-string p0, "https://storage.yandexcloud.net/drivedeck-updates-ru/update.json"

    :goto_0
    return-object p0
.end method

.method public static R(Ljava/lang/String;Lc/I6;)[B
    .locals 13

    invoke-static {p0}, Lc/k6;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/16 v4, 0xa

    const/16 v5, 0xc

    const-string v6, "23"

    const-string v7, "19"

    const-string v8, "13"

    const/16 v9, 0x8

    const/4 v10, 0x6

    if-ne v0, v9, :cond_1

    const-string v0, "18"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    :cond_0
    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_1

    :cond_1
    if-ne v0, v1, :cond_2

    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_2

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_1

    :cond_2
    if-ne v0, v10, :cond_5

    invoke-virtual {p0, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "17"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-virtual {p0, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_4
    :goto_0
    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_5
    if-ne v0, v5, :cond_6

    const-string v7, "1906"

    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_6

    invoke-virtual {p0, v3, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_6
    if-ne v0, v1, :cond_7

    invoke-virtual {p0, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_7

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_7
    if-le v0, v10, :cond_8

    const-string v7, "2F"

    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_8

    invoke-virtual {p0, v3, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_8
    invoke-virtual {p0, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_9

    move-object p0, v6

    goto :goto_1

    :cond_9
    const-string v7, "3D"

    invoke-virtual {p0, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_a

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_a
    if-lt v0, v10, :cond_b

    const-string v0, "2E"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    invoke-virtual {p0, v3, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_b
    :goto_1
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-le v0, v10, :cond_c

    const-string v0, "A8"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_c
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x1

    const/16 v8, 0x10

    if-ne v0, v9, :cond_d

    const-string v0, "21"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    const-string v0, "8001"

    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_d

    const-string p0, "61FF"

    goto/16 :goto_2

    :cond_d
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    if-ne v0, v10, :cond_e

    const-string v0, "AA"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {p0, v1, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_e
    invoke-virtual {p0, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_f

    const-string p0, "63"

    goto/16 :goto_2

    :cond_f
    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    add-int/lit8 v0, v0, 0x40

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v6

    if-ne v6, v2, :cond_10

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_10
    iget v11, p1, Lc/I6;->a:I

    if-lt v6, v10, :cond_11

    const/16 v12, 0x41

    if-ne v0, v12, :cond_11

    const/4 v12, 0x3

    if-ne v11, v12, :cond_11

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_11
    if-ne v6, v10, :cond_14

    iget-boolean p1, p1, Lc/I6;->c:Z

    if-eqz p1, :cond_13

    if-eq v11, v7, :cond_12

    if-ne v11, v2, :cond_13

    :cond_12
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_13
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_14
    const-string v12, "2C"

    invoke-virtual {p0, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_15

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto/16 :goto_2

    :cond_15
    if-ne v6, v9, :cond_16

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_16
    const/16 v12, 0x62

    if-ne v0, v12, :cond_17

    if-lt v6, v4, :cond_17

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_17
    if-eq v6, v5, :cond_18

    if-ne v6, v8, :cond_19

    :cond_18
    if-ne v11, v1, :cond_19

    iget-object p1, p1, Lc/I6;->b:Ljava/lang/String;

    const-string v4, "Volvo"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_19

    invoke-virtual {p0, v1, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    add-int/lit8 v0, v0, 0x40

    and-int/lit16 v0, v0, 0xff

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    goto :goto_2

    :cond_19
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_2
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    and-int/2addr p1, v7

    if-nez p1, :cond_1b

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    div-int/2addr p1, v2

    new-array v0, p1, [B

    :goto_3
    if-ge v3, p1, :cond_1a

    mul-int/lit8 v1, v3, 0x2

    add-int/lit8 v2, v1, 0x2

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v1

    int-to-byte v1, v1

    aput-byte v1, v0, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_3

    :cond_1a
    return-object v0

    :cond_1b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Source marker is not byte-aligned"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static S()Landroid/widget/LinearLayout$LayoutParams;
    .locals 3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    return-object v0
.end method

.method public static T(IILjava/lang/String;)I
    .locals 4

    if-nez p2, :cond_0

    const-string p2, ""

    :cond_0
    const-string v0, "NO DATA"

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_5

    const-string v0, "UNABLE"

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "ERROR"

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "STOPPED"

    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    const/16 v0, 0x2e

    invoke-virtual {p2, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v2, 0x2

    if-ltz v0, :cond_2

    const/16 v0, 0x56

    invoke-virtual {p2, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-ltz v0, :cond_2

    goto :goto_1

    :cond_2
    const/4 v0, 0x6

    if-eq p1, v0, :cond_3

    const/16 v3, 0x8

    if-ne p1, v3, :cond_4

    :cond_3
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    if-le p1, v0, :cond_4

    const/4 p1, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/16 v3, 0x37

    if-ne p1, v3, :cond_4

    invoke-virtual {p2, v0}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/16 v3, 0x46

    if-eq p1, v3, :cond_6

    invoke-virtual {p2, v0}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/16 p2, 0x66

    if-ne p1, p2, :cond_4

    goto :goto_1

    :cond_4
    const/4 v2, 0x3

    goto :goto_1

    :cond_5
    :goto_0
    move v2, v1

    :cond_6
    :goto_1
    invoke-static {v2}, Lc/t;->g(I)I

    move-result p1

    if-eqz p1, :cond_8

    if-eq p1, v1, :cond_7

    const/4 p0, 0x0

    :cond_7
    return p0

    :cond_8
    const p1, 0x7fffffff

    if-ne p0, p1, :cond_9

    goto :goto_2

    :cond_9
    add-int/lit8 p0, p0, 0x1

    :goto_2
    return p0
.end method

.method public static U(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, ""

    if-nez p0, :cond_0

    return-object v0

    :cond_0
    sget-object v1, Ljava/text/Normalizer$Form;->NFD:Ljava/text/Normalizer$Form;

    invoke-static {p0, v1}, Ljava/text/Normalizer;->normalize(Ljava/lang/CharSequence;Ljava/text/Normalizer$Form;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "\\p{M}+"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x451

    const/16 v1, 0x435

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p0

    const-string v0, "[^\\p{L}\\p{N}]+"

    const-string v1, " "

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static V(Lorg/json/JSONObject;Ljava/lang/String;)D
    .locals 2

    invoke-virtual {p0, p1}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2c

    const/16 v1, 0x2e

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->isFinite(D)Z

    move-result p0

    if-eqz p0, :cond_0

    return-wide v0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static W(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const-string v0, ""

    if-eqz p0, :cond_1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v2, 0x40

    if-le v1, v2, :cond_0

    goto :goto_0

    :cond_0
    const-string v1, "[ ()\\-\\u00a0]"

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v1, "\\+?[0-9]{3,20}"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1

    move-object v0, p0

    :cond_1
    :goto_0
    return-object v0
.end method

.method public static X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;
    .locals 21

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    invoke-static/range {p1 .. p1}, Lc/k6;->I(I)I

    move-result v6

    if-eqz v0, :cond_32

    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->length()I

    move-result v7

    const/high16 v8, 0x10000

    if-gt v7, v8, :cond_32

    if-eqz v6, :cond_32

    if-eqz v2, :cond_32

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-ne v6, v8, :cond_0

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    move v10, v9

    :goto_0
    const/4 v11, 0x3

    if-ne v2, v11, :cond_1

    const/4 v12, 0x1

    goto :goto_1

    :cond_1
    move v12, v9

    :goto_1
    if-eq v10, v12, :cond_2

    goto/16 :goto_18

    :cond_2
    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v10}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v10, "[\\r\\n]+"

    const/4 v12, -0x1

    invoke-virtual {v0, v10, v12}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    new-instance v10, Ljava/util/HashMap;

    invoke-direct {v10}, Ljava/util/HashMap;-><init>()V

    new-instance v12, Ljava/util/HashSet;

    invoke-direct {v12}, Ljava/util/HashSet;-><init>()V

    new-instance v13, Ljava/util/HashMap;

    invoke-direct {v13}, Ljava/util/HashMap;-><init>()V

    array-length v14, v0

    move v15, v9

    move/from16 v16, v15

    :goto_2
    if-ge v15, v14, :cond_9

    aget-object v18, v0, v15

    invoke-static/range {v18 .. v18}, Lc/k6;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_3

    const-string v11, "[0-9A-F]{8,}"

    invoke-virtual {v7, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_4

    :cond_3
    move/from16 v19, v14

    goto :goto_4

    :cond_4
    if-eqz v4, :cond_6

    if-ne v6, v8, :cond_6

    invoke-virtual {v7, v9, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->length()I

    move-result v9

    move/from16 v19, v14

    const/4 v14, 0x2

    if-ne v9, v14, :cond_5

    const/4 v9, 0x4

    invoke-virtual {v11, v9, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_8

    goto :goto_3

    :cond_5
    invoke-virtual {v11, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_7

    goto :goto_4

    :cond_6
    move/from16 v19, v14

    :cond_7
    :goto_3
    add-int/lit8 v16, v16, 0x1

    if-ne v6, v8, :cond_8

    const/4 v9, 0x4

    invoke-virtual {v7, v9, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x1

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    new-instance v9, Lc/l7;

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    invoke-virtual {v13, v7, v11, v9}, Ljava/util/HashMap;->merge(Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object;

    :cond_8
    :goto_4
    add-int/lit8 v15, v15, 0x1

    move/from16 v14, v19

    const/4 v9, 0x0

    goto :goto_2

    :cond_9
    array-length v7, v0

    const/4 v9, 0x0

    :goto_5
    if-ge v9, v7, :cond_31

    aget-object v11, v0, v9

    invoke-static {v11}, Lc/k6;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_b

    invoke-virtual {v11, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "NODATA"

    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "OK"

    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "?"

    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "STOPPED"

    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "SEARCHING"

    invoke-virtual {v11, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "BUSINIT"

    invoke-virtual {v11, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "ELM327"

    invoke-virtual {v11, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "UNABLETOCONNECT"

    invoke-virtual {v11, v14}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_b

    const-string v14, "ERROR"

    invoke-virtual {v11, v14}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_a

    goto :goto_6

    :cond_a
    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v14

    add-int/lit8 v15, v6, 0x2

    if-lt v14, v15, :cond_b

    const-string v14, "[0-9A-F]+"

    invoke-virtual {v11, v14}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_d

    :cond_b
    :goto_6
    move-object/from16 v19, v0

    :cond_c
    :goto_7
    const/4 v0, 0x3

    const/4 v11, 0x1

    goto/16 :goto_17

    :cond_d
    const/4 v14, 0x0

    invoke-virtual {v11, v14, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v15

    if-eqz v4, :cond_11

    if-ne v6, v8, :cond_f

    invoke-virtual/range {p4 .. p4}, Ljava/lang/String;->length()I

    move-result v14

    move-object/from16 v19, v0

    const/4 v0, 0x2

    if-ne v14, v0, :cond_10

    const/4 v0, 0x4

    invoke-virtual {v15, v0, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    :cond_e
    :goto_8
    const/4 v0, 0x3

    goto :goto_9

    :cond_f
    move-object/from16 v19, v0

    :cond_10
    invoke-virtual {v15, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    goto :goto_7

    :cond_11
    move-object/from16 v19, v0

    goto :goto_8

    :goto_9
    if-ne v6, v0, :cond_12

    const-string v0, "[0-7][0-9A-F]{2}"

    invoke-virtual {v15, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_c

    :cond_12
    const/16 v0, 0x8

    if-ne v6, v0, :cond_13

    const-string v14, "[01][0-9A-F]{7}"

    invoke-virtual {v15, v14}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v14

    if-nez v14, :cond_13

    goto :goto_7

    :cond_13
    invoke-virtual {v11, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v20

    const/16 v17, 0x1

    and-int/lit8 v20, v20, 0x1

    if-eqz v20, :cond_14

    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_14
    invoke-static {v14}, Lc/k6;->L(Ljava/lang/String;)[B

    move-result-object v14

    const/4 v0, 0x3

    if-ne v2, v0, :cond_1e

    invoke-static {v11}, Lc/k6;->L(Ljava/lang/String;)[B

    move-result-object v0

    array-length v11, v0

    const/4 v8, 0x2

    if-ge v11, v8, :cond_16

    :cond_15
    const/4 v3, 0x0

    goto :goto_b

    :cond_16
    const/4 v8, 0x0

    const/4 v11, 0x0

    :goto_a
    array-length v3, v0

    const/16 v17, 0x1

    add-int/lit8 v3, v3, -0x1

    if-ge v8, v3, :cond_17

    aget-byte v3, v0, v8

    and-int/lit16 v3, v3, 0xff

    add-int/2addr v11, v3

    add-int/lit8 v8, v8, 0x1

    goto :goto_a

    :cond_17
    and-int/lit16 v3, v11, 0xff

    array-length v8, v0

    add-int/lit8 v8, v8, -0x1

    aget-byte v8, v0, v8

    and-int/lit16 v8, v8, 0xff

    if-ne v3, v8, :cond_15

    const/4 v3, 0x1

    :goto_b
    if-nez v4, :cond_18

    const/4 v8, 0x6

    const/4 v11, 0x4

    invoke-virtual {v15, v11, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x0

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v13, v4, v8}, Ljava/util/HashMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    :goto_c
    const/4 v8, 0x1

    goto :goto_d

    :cond_18
    move/from16 v4, v16

    goto :goto_c

    :goto_d
    if-le v4, v8, :cond_19

    if-eqz v3, :cond_19

    array-length v3, v14

    sub-int/2addr v3, v8

    invoke-static {v14, v3}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v14

    :cond_19
    const/4 v3, 0x4

    if-eq v1, v3, :cond_1a

    const/4 v3, 0x5

    if-eq v1, v3, :cond_1a

    const/16 v3, 0xb

    if-ne v1, v3, :cond_1c

    :cond_1a
    const/4 v3, 0x0

    aget-byte v0, v0, v3

    and-int/lit8 v0, v0, 0x3f

    if-nez v0, :cond_1c

    array-length v0, v14

    const/4 v4, 0x2

    if-ge v0, v4, :cond_1b

    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7

    :cond_1b
    aget-byte v0, v14, v3

    array-length v0, v14

    const/4 v3, 0x1

    invoke-static {v14, v3, v0}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v14

    :cond_1c
    array-length v0, v14

    if-lez v0, :cond_1d

    new-instance v0, Lc/n7;

    invoke-direct {v0, v15, v14}, Lc/n7;-><init>(Ljava/lang/String;[B)V

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1d
    :goto_e
    const/4 v0, 0x3

    const/4 v11, 0x1

    goto/16 :goto_15

    :cond_1e
    const/4 v0, 0x2

    if-ne v2, v0, :cond_21

    array-length v0, v14

    if-eqz v0, :cond_20

    array-length v0, v14

    const/16 v3, 0xfff

    if-le v0, v3, :cond_1f

    goto :goto_f

    :cond_1f
    new-instance v0, Lc/n7;

    invoke-direct {v0, v15, v14}, Lc/n7;-><init>(Ljava/lang/String;[B)V

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_e

    :cond_20
    :goto_f
    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7

    :cond_21
    array-length v0, v14

    const/4 v3, 0x1

    if-lt v0, v3, :cond_2f

    array-length v0, v14

    const/16 v3, 0x8

    if-le v0, v3, :cond_22

    const/4 v0, 0x3

    const/4 v11, 0x1

    goto/16 :goto_16

    :cond_22
    const/4 v0, 0x0

    aget-byte v3, v14, v0

    and-int/lit16 v4, v3, 0xff

    const/4 v8, 0x4

    ushr-int/2addr v4, v8

    const/4 v11, 0x7

    if-nez v4, :cond_26

    and-int/lit8 v3, v3, 0xf

    if-eqz v3, :cond_23

    if-gt v3, v11, :cond_23

    array-length v4, v14

    add-int/lit8 v3, v3, 0x1

    if-lt v4, v3, :cond_23

    invoke-virtual {v10, v15}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_24

    :cond_23
    const/4 v11, 0x1

    goto :goto_11

    :cond_24
    new-instance v4, Lc/n7;

    const/4 v11, 0x1

    invoke-static {v14, v11, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v3

    invoke-direct {v4, v15, v3}, Lc/n7;-><init>(Ljava/lang/String;[B)V

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_25
    :goto_10
    const/4 v0, 0x3

    goto/16 :goto_15

    :goto_11
    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :goto_12
    const/4 v0, 0x3

    goto/16 :goto_17

    :cond_26
    const/4 v0, 0x1

    if-ne v4, v0, :cond_2a

    array-length v4, v14

    const/16 v8, 0x8

    if-ne v4, v8, :cond_29

    invoke-virtual {v10, v15}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_27

    goto :goto_13

    :cond_27
    and-int/lit8 v3, v3, 0xf

    shl-int/2addr v3, v8

    aget-byte v4, v14, v0

    and-int/lit16 v0, v4, 0xff

    or-int/2addr v0, v3

    if-gt v0, v11, :cond_28

    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7

    :cond_28
    new-instance v3, Lc/m7;

    invoke-direct {v3, v14, v0}, Lc/m7;-><init>([BI)V

    invoke-virtual {v10, v15, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_e

    :cond_29
    :goto_13
    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7

    :cond_2a
    const/4 v0, 0x2

    if-ne v4, v0, :cond_2d

    invoke-virtual {v10, v15}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/m7;

    if-eqz v4, :cond_2b

    and-int/lit8 v3, v3, 0xf

    iget v8, v4, Lc/m7;->c:I

    if-ne v3, v8, :cond_2b

    array-length v3, v14

    if-lt v3, v0, :cond_2b

    iget-object v3, v4, Lc/m7;->a:[B

    array-length v8, v3

    iget v0, v4, Lc/m7;->b:I

    sub-int/2addr v8, v0

    if-le v8, v11, :cond_2c

    array-length v8, v14

    const/16 v11, 0x8

    if-eq v8, v11, :cond_2c

    :cond_2b
    const/4 v11, 0x1

    goto :goto_14

    :cond_2c
    array-length v8, v14

    const/4 v11, 0x1

    sub-int/2addr v8, v11

    array-length v11, v3

    sub-int/2addr v11, v0

    invoke-static {v8, v11}, Ljava/lang/Math;->min(II)I

    move-result v0

    iget v8, v4, Lc/m7;->b:I

    const/4 v11, 0x1

    invoke-static {v14, v11, v3, v8, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget v8, v4, Lc/m7;->b:I

    add-int/2addr v8, v0

    iput v8, v4, Lc/m7;->b:I

    iget v0, v4, Lc/m7;->c:I

    add-int/2addr v0, v11

    and-int/lit8 v0, v0, 0xf

    iput v0, v4, Lc/m7;->c:I

    array-length v0, v3

    if-ne v8, v0, :cond_25

    invoke-virtual {v10, v15}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Lc/n7;

    invoke-direct {v0, v15, v3}, Lc/n7;-><init>(Ljava/lang/String;[B)V

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_10

    :goto_14
    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto/16 :goto_12

    :cond_2d
    const/4 v0, 0x3

    const/4 v11, 0x1

    if-eq v4, v0, :cond_2e

    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_2e
    :goto_15
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/16 v4, 0x100

    if-le v3, v4, :cond_30

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0

    :cond_2f
    move v11, v3

    const/4 v0, 0x3

    :goto_16
    invoke-virtual {v12, v15}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_30
    :goto_17
    add-int/lit8 v9, v9, 0x1

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v0, v19

    const/4 v8, 0x6

    goto/16 :goto_5

    :cond_31
    invoke-virtual {v10}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v12, v0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    new-instance v0, Lc/W4;

    const/4 v1, 0x1

    invoke-direct {v0, v12, v1}, Lc/W4;-><init>(Ljava/util/HashSet;I)V

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->removeIf(Ljava/util/function/Predicate;)Z

    invoke-static {v5}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    return-object v0

    :cond_32
    :goto_18
    return-object v5
.end method

.method public static Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const/4 v3, 0x0

    if-eqz v0, :cond_14

    invoke-virtual/range {p0 .. p0}, Ljava/lang/String;->length()I

    move-result v4

    const/high16 v5, 0x10000

    if-gt v4, v5, :cond_14

    if-eqz v1, :cond_14

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v5, 0x6

    if-gt v4, v5, :cond_14

    if-eqz v2, :cond_14

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v5, 0x8

    if-le v4, v5, :cond_0

    goto/16 :goto_8

    :cond_0
    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "(?:01|21)[0-9A-F]{2}|22[0-9A-F]{4}"

    invoke-virtual {v1, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_14

    const-string v6, "[0-7][0-9A-F]{2}|[01][0-9A-F]{7}"

    invoke-virtual {v2, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1

    goto/16 :goto_8

    :cond_1
    invoke-static {v1}, Lc/k6;->K(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v6, 0x0

    aget-byte v7, v1, v6

    add-int/lit8 v7, v7, 0x40

    int-to-byte v7, v7

    aput-byte v7, v1, v6

    invoke-virtual {v0, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v4, "[\\r\\n]+"

    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    array-length v4, v0

    const/4 v7, 0x1

    move-object v9, v3

    move v8, v6

    move v11, v8

    move v10, v7

    :goto_0
    if-ge v8, v4, :cond_14

    aget-object v12, v0, v8

    const-string v13, " "

    const-string v14, ""

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "\t"

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    const-string v13, ">"

    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v13

    if-nez v13, :cond_2

    :goto_1
    move/from16 v16, v6

    goto/16 :goto_7

    :cond_2
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    const-string v13, "[0-9A-F]{2,16}"

    invoke-virtual {v12, v13}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_14

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v13

    const/4 v14, 0x2

    rem-int/2addr v13, v14

    if-eqz v13, :cond_3

    goto/16 :goto_8

    :cond_3
    invoke-static {v12}, Lc/k6;->K(Ljava/lang/String;)[B

    move-result-object v12

    aget-byte v13, v12, v6

    and-int/lit16 v15, v13, 0xff

    shr-int/lit8 v15, v15, 0x4

    const/4 v6, 0x7

    if-nez v15, :cond_9

    and-int/lit8 v0, v13, 0xf

    if-nez v9, :cond_8

    array-length v2, v1

    if-lt v0, v2, :cond_8

    if-gt v0, v6, :cond_8

    array-length v2, v12

    add-int/2addr v0, v7

    if-ge v2, v0, :cond_4

    goto :goto_3

    :cond_4
    invoke-static {v12, v7, v0}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    array-length v2, v0

    array-length v4, v1

    if-ge v2, v4, :cond_5

    goto :goto_3

    :cond_5
    const/4 v6, 0x0

    :goto_2
    array-length v2, v1

    if-ge v6, v2, :cond_7

    aget-byte v2, v0, v6

    aget-byte v4, v1, v6

    if-eq v2, v4, :cond_6

    goto :goto_3

    :cond_6
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_7
    array-length v1, v1

    array-length v2, v0

    invoke-static {v0, v1, v2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v3

    :cond_8
    :goto_3
    return-object v3

    :cond_9
    if-ne v15, v7, :cond_d

    if-nez v9, :cond_c

    array-length v9, v12

    if-eq v9, v5, :cond_a

    goto :goto_4

    :cond_a
    and-int/lit8 v9, v13, 0xf

    shl-int/2addr v9, v5

    aget-byte v11, v12, v7

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v9, v11

    if-le v9, v6, :cond_c

    const/16 v6, 0xfff

    if-le v9, v6, :cond_b

    goto :goto_4

    :cond_b
    new-array v9, v9, [B

    array-length v6, v12

    add-int/lit8 v11, v6, -0x2

    const/4 v6, 0x0

    invoke-static {v12, v14, v9, v6, v11}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_1

    :cond_c
    :goto_4
    return-object v3

    :cond_d
    const/16 v16, 0x0

    if-ne v15, v14, :cond_14

    if-eqz v9, :cond_14

    and-int/lit8 v13, v13, 0xf

    if-ne v13, v10, :cond_14

    array-length v13, v12

    if-ge v13, v14, :cond_e

    goto :goto_8

    :cond_e
    array-length v13, v12

    sub-int/2addr v13, v7

    array-length v14, v9

    sub-int/2addr v14, v11

    invoke-static {v13, v14}, Ljava/lang/Math;->min(II)I

    move-result v13

    array-length v14, v9

    sub-int/2addr v14, v11

    if-le v14, v6, :cond_f

    array-length v6, v12

    if-eq v6, v5, :cond_f

    return-object v3

    :cond_f
    invoke-static {v12, v7, v9, v11, v13}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v11, v13

    add-int/lit8 v10, v10, 0x1

    and-int/lit8 v10, v10, 0xf

    array-length v6, v9

    if-ne v11, v6, :cond_13

    array-length v0, v9

    array-length v2, v1

    if-ge v0, v2, :cond_10

    goto :goto_6

    :cond_10
    move/from16 v6, v16

    :goto_5
    array-length v0, v1

    if-ge v6, v0, :cond_12

    aget-byte v0, v9, v6

    aget-byte v2, v1, v6

    if-eq v0, v2, :cond_11

    goto :goto_6

    :cond_11
    add-int/lit8 v6, v6, 0x1

    goto :goto_5

    :cond_12
    array-length v0, v1

    array-length v1, v9

    invoke-static {v9, v0, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v3

    :goto_6
    return-object v3

    :cond_13
    :goto_7
    add-int/lit8 v8, v8, 0x1

    move/from16 v6, v16

    goto/16 :goto_0

    :cond_14
    :goto_8
    return-object v3
.end method

.method public static Z(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 10

    invoke-static {p0}, Lc/k6;->I(I)I

    move-result v0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    move v0, v3

    goto :goto_0

    :cond_0
    move v0, v2

    :goto_0
    invoke-static {p2}, Lc/k6;->e0(Ljava/lang/String;)Z

    move-result v4

    const/4 v5, 0x0

    if-nez v4, :cond_1

    goto/16 :goto_4

    :cond_1
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v4

    div-int/lit8 v4, v4, 0x2

    invoke-static {p2}, Lc/k6;->e0(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_c

    if-eqz p3, :cond_c

    if-lt v4, v2, :cond_c

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v6

    div-int/lit8 v6, v6, 0x2

    if-gt v4, v6, :cond_c

    const/16 v6, 0x100

    if-le v4, v6, :cond_2

    goto/16 :goto_4

    :cond_2
    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p2, v6}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p3, v6}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p3

    invoke-static {p0}, Lc/k6;->I(I)I

    move-result v6

    if-ne v6, v1, :cond_3

    const-string v1, "[0-9A-F]{2}|[0-9A-F]{6}"

    goto :goto_1

    :cond_3
    if-ne v6, v3, :cond_4

    const-string v1, "[0-7][0-9A-F]{2}"

    goto :goto_1

    :cond_4
    const/16 v1, 0x8

    if-ne v6, v1, :cond_5

    const-string v1, "[01][0-9A-F]{7}"

    goto :goto_1

    :cond_5
    const-string v1, "(?!)"

    :goto_1
    invoke-virtual {p3, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_6

    goto :goto_4

    :cond_6
    invoke-static {p1, p0, v0, p2, p3}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    invoke-static {p2}, Lc/k6;->L(Ljava/lang/String;)[B

    move-result-object p1

    invoke-static {p1, v4}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object p1

    const/4 p2, 0x0

    aget-byte p3, p1, p2

    and-int/lit16 p3, p3, 0xff

    add-int/lit8 p3, p3, 0x40

    int-to-byte p3, p3

    aput-byte p3, p1, p2

    new-instance p3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    move v1, p2

    :cond_7
    :goto_2
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/n7;

    iget-object v7, v6, Lc/n7;->b:[B

    array-length v7, v7

    if-lt v7, v4, :cond_7

    invoke-virtual {v6}, Lc/n7;->a()I

    move-result v7

    if-gez v7, :cond_7

    move v7, p2

    :goto_3
    array-length v8, p1

    iget-object v9, v6, Lc/n7;->b:[B

    if-ge v7, v8, :cond_9

    aget-byte v8, v9, v7

    aget-byte v9, p1, v7

    if-eq v8, v9, :cond_8

    goto :goto_2

    :cond_8
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    :cond_9
    if-eqz v1, :cond_a

    if-eq v0, v3, :cond_a

    goto :goto_4

    :cond_a
    array-length v1, v9

    sub-int/2addr v1, v4

    invoke-virtual {p3, v9, v4, v1}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    move v1, v2

    goto :goto_2

    :cond_b
    if-eqz v1, :cond_c

    invoke-virtual {p3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v5

    :cond_c
    :goto_4
    return-object v5
.end method

.method public static a(Lc/r4;)I
    .locals 0

    iget-boolean p0, p0, Lc/r4;->m:Z

    if-eqz p0, :cond_0

    const p0, -0xd4954b

    goto :goto_0

    :cond_0
    const p0, -0xb25e10

    :goto_0
    return p0
.end method

.method public static a0(Ljava/lang/String;I)Ljava/lang/String;
    .locals 2

    if-ltz p1, :cond_1

    const/16 v0, 0xff

    if-gt p1, v0, :cond_1

    if-eqz p0, :cond_1

    const-string v0, "[0-9A-F]{2,4}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string v1, "%02X"

    invoke-static {v0, v1, p1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    :goto_0
    const/4 p0, 0x0

    return-object p0
.end method

.method public static b(Ljava/util/HashSet;I[B)V
    .locals 8

    array-length v0, p2

    const/4 v1, 0x4

    if-ne v0, v1, :cond_3

    array-length v0, p2

    const-wide/16 v1, 0x0

    const/4 v3, 0x0

    move-wide v4, v1

    :goto_0
    if-ge v3, v0, :cond_0

    aget-byte v6, p2, v3

    const/16 v7, 0x8

    shl-long/2addr v4, v7

    and-int/lit16 v6, v6, 0xff

    int-to-long v6, v6

    or-long/2addr v4, v6

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const/4 p2, 0x1

    :goto_1
    const/16 v0, 0x20

    if-gt p2, v0, :cond_2

    rsub-int/lit8 v0, p2, 0x20

    const-wide/16 v6, 0x1

    shl-long/2addr v6, v0

    and-long/2addr v6, v4

    cmp-long v0, v6, v1

    if-eqz v0, :cond_1

    add-int v0, p1, p2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_1

    :cond_2
    return-void

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid support bitmap"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static b0(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;)Landroid/widget/Switch;
    .locals 3

    new-instance v0, Landroid/widget/Switch;

    invoke-direct {v0, p0}, Landroid/widget/Switch;-><init>(Landroid/content/Context;)V

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 p1, 0x10

    invoke-static {v0, p1}, Lc/k6;->D(Landroid/widget/TextView;I)V

    const/16 v1, 0x30

    int-to-float v1, v1

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setMinHeight(I)V

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setGravity(I)V

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/Switch;->setSwitchMinWidth(I)V

    int-to-float p1, p1

    invoke-static {p0, p1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {v0, p0}, Landroid/widget/Switch;->setSwitchPadding(I)V

    const/4 p0, 0x0

    invoke-virtual {v0, p0}, Landroid/widget/Switch;->setShowText(Z)V

    invoke-virtual {v0, p0}, Landroid/widget/Switch;->setSplitTrack(Z)V

    return-object v0
.end method

.method public static c(Lc/j6;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/util/Set;)Ljava/util/LinkedHashMap;
    .locals 3

    invoke-static {p0, p1}, Lc/k6;->s0(Lc/j6;Lorg/json/JSONArray;)Ljava/util/LinkedHashMap;

    move-result-object p1

    invoke-static {p0, p2}, Lc/k6;->s0(Lc/j6;Lorg/json/JSONArray;)Ljava/util/LinkedHashMap;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {p3, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    return-object p0
.end method

.method public static c0(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    invoke-static {p2}, Lc/k6;->e0(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p2, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/k6;->L(Ljava/lang/String;)[B

    move-result-object v2

    const/4 v3, 0x0

    aget-byte v4, v2, v3

    and-int/lit16 v4, v4, 0xff

    add-int/lit8 v4, v4, 0x40

    int-to-byte v4, v4

    aput-byte v4, v2, v3

    invoke-static {p0}, Lc/k6;->I(I)I

    move-result v4

    const/4 v5, 0x6

    if-ne v4, v5, :cond_1

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    :goto_0
    invoke-virtual {p2, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, p0, v4, v0, v1}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_2
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_9

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/n7;

    iget-object v4, v0, Lc/n7;->b:[B

    array-length v6, v4

    array-length v7, v2

    if-lt v6, v7, :cond_2

    move v6, v3

    :goto_2
    array-length v7, v2

    if-ge v6, v7, :cond_4

    aget-byte v7, v4, v6

    aget-byte v8, v2, v6

    if-eq v7, v8, :cond_3

    goto :goto_1

    :cond_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_4
    const-string v4, "0100"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x4

    if-nez v4, :cond_5

    const-string v4, "22F400"

    invoke-virtual {p2, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_6

    :cond_5
    iget-object v4, v0, Lc/n7;->b:[B

    array-length v7, v4

    array-length v8, v2

    sub-int/2addr v7, v8

    if-eq v7, v6, :cond_6

    invoke-static {p0}, Lc/k6;->I(I)I

    move-result v7

    if-ne v7, v5, :cond_2

    array-length v4, v4

    array-length v7, v2

    sub-int/2addr v4, v7

    const/4 v7, 0x5

    if-eq v4, v7, :cond_6

    goto :goto_1

    :cond_6
    invoke-static {p0}, Lc/k6;->I(I)I

    move-result v4

    iget-object v0, v0, Lc/n7;->a:Ljava/lang/String;

    if-ne v4, v5, :cond_7

    invoke-virtual {v0, v6, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    :cond_7
    if-eqz v1, :cond_8

    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-gez v4, :cond_2

    :cond_8
    move-object v1, v0

    goto :goto_1

    :cond_9
    return-object v1
.end method

.method public static d(Ljava/lang/String;Ljava/lang/String;)I
    .locals 18

    move-object/from16 v0, p1

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->length()I

    move-result v2

    const/high16 v3, 0x10000

    if-le v2, v3, :cond_1

    :cond_0
    move v0, v1

    goto/16 :goto_10

    :cond_1
    invoke-static/range {p0 .. p0}, Lc/k6;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    invoke-virtual {v2, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x10

    invoke-static {v5, v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v5

    add-int/lit8 v5, v5, 0x40

    invoke-static {v5}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v7, 0x30

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-ne v5, v8, :cond_2

    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    if-eq v5, v7, :cond_2

    invoke-virtual {v2, v4, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    goto :goto_0

    :cond_2
    invoke-virtual {v2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    :goto_0
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, " "

    const-string v5, ""

    invoke-virtual {v0, v3, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "\r"

    const/4 v5, -0x1

    invoke-virtual {v0, v3, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v3, v0

    move v5, v1

    move v10, v5

    move v11, v10

    move v12, v11

    :goto_1
    const/4 v13, 0x7

    if-ge v5, v3, :cond_1d

    aget-object v14, v0, v5

    invoke-virtual {v14}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v14

    const-string v15, "SEARCHING..."

    invoke-virtual {v14, v15}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v15

    if-eqz v15, :cond_3

    const/16 v15, 0xc

    goto :goto_2

    :cond_3
    move v15, v1

    :goto_2
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x1

    if-ge v15, v4, :cond_8

    invoke-virtual {v14, v15}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Lc/k6;->e(C)Z

    move-result v4

    if-eqz v4, :cond_4

    add-int/lit8 v15, v15, 0x1

    goto :goto_2

    :cond_4
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v4

    sub-int/2addr v4, v6

    if-ne v15, v4, :cond_5

    invoke-virtual {v14, v1, v15}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    goto :goto_4

    :cond_5
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v15

    invoke-direct {v4, v15}, Ljava/lang/StringBuilder;-><init>(I)V

    move v15, v1

    :goto_3
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v8

    if-ge v15, v8, :cond_7

    invoke-virtual {v14, v15}, Ljava/lang/String;->charAt(I)C

    move-result v8

    invoke-static {v8}, Lc/k6;->e(C)Z

    move-result v8

    if-eqz v8, :cond_6

    invoke-virtual {v14, v15}, Ljava/lang/String;->charAt(I)C

    move-result v8

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_6
    add-int/lit8 v15, v15, 0x1

    goto :goto_3

    :cond_7
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    :cond_8
    :goto_4
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v8, 0x3

    if-le v4, v8, :cond_9

    invoke-virtual {v14, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_a

    :cond_9
    const/4 v6, 0x2

    const/16 v8, 0x10

    goto/16 :goto_e

    :cond_a
    invoke-virtual {v14, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v15

    invoke-virtual {v14, v1}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/16 v1, 0x37

    if-ne v6, v1, :cond_b

    add-int/lit8 v10, v10, 0x2

    :cond_b
    and-int/lit8 v6, v15, 0x1

    if-eqz v6, :cond_c

    add-int/lit8 v10, v10, 0x2

    :cond_c
    const/4 v1, 0x5

    if-ne v4, v1, :cond_e

    add-int/lit8 v16, v10, 0x2

    invoke-static {v14, v4}, Lc/k6;->f(Ljava/lang/String;I)Z

    move-result v17

    if-eqz v17, :cond_d

    add-int/lit8 v10, v10, 0x4

    goto :goto_5

    :cond_d
    move/from16 v10, v16

    :cond_e
    :goto_5
    const/16 v1, 0x31

    if-ne v4, v13, :cond_f

    invoke-virtual {v14, v8}, Ljava/lang/String;->charAt(I)C

    move-result v8

    if-ne v8, v1, :cond_f

    invoke-virtual {v14, v9}, Ljava/lang/String;->charAt(I)C

    move-result v8

    if-ne v8, v7, :cond_f

    add-int/lit8 v10, v10, 0x2

    :cond_f
    const/4 v8, 0x1

    invoke-virtual {v14, v8}, Ljava/lang/String;->charAt(I)C

    move-result v13

    const/16 v8, 0x8

    const/16 v7, 0x37

    if-ne v13, v7, :cond_12

    add-int/lit8 v15, v15, -0x1

    invoke-virtual {v14, v15}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/4 v13, 0x0

    invoke-virtual {v14, v13}, Ljava/lang/String;->charAt(I)C

    move-result v15

    if-ne v7, v15, :cond_10

    const/4 v7, 0x2

    goto :goto_6

    :cond_10
    const/4 v7, 0x1

    :goto_6
    add-int/2addr v10, v7

    const/4 v7, 0x6

    if-ne v4, v7, :cond_11

    add-int/lit8 v10, v10, 0x2

    :cond_11
    if-ne v4, v8, :cond_12

    invoke-virtual {v14, v9}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-ne v7, v1, :cond_12

    const/4 v7, 0x5

    invoke-virtual {v14, v7}, Ljava/lang/String;->charAt(I)C

    move-result v7

    const/16 v13, 0x30

    if-ne v7, v13, :cond_12

    add-int/lit8 v10, v10, 0x2

    :cond_12
    if-nez v6, :cond_13

    add-int/lit8 v11, v11, 0x1

    :cond_13
    const/16 v7, 0xa

    if-ne v4, v7, :cond_14

    add-int/lit8 v7, v11, 0x2

    invoke-static {v14, v4}, Lc/k6;->f(Ljava/lang/String;I)Z

    move-result v13

    if-eqz v13, :cond_15

    add-int/lit8 v11, v11, 0x4

    :cond_14
    :goto_7
    const/16 v7, 0xc

    goto :goto_8

    :cond_15
    move v11, v7

    goto :goto_7

    :goto_8
    if-ne v4, v7, :cond_16

    invoke-virtual {v14, v8}, Ljava/lang/String;->charAt(I)C

    move-result v7

    if-ne v7, v1, :cond_16

    const/16 v1, 0x9

    invoke-virtual {v14, v1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v7, 0x30

    if-ne v1, v7, :cond_17

    add-int/lit8 v11, v11, 0x2

    goto :goto_9

    :cond_16
    const/16 v7, 0x30

    :cond_17
    :goto_9
    if-nez v6, :cond_18

    add-int/lit8 v12, v12, 0x1

    :cond_18
    const/4 v1, 0x6

    if-ne v4, v1, :cond_19

    add-int/lit8 v12, v12, 0x2

    :cond_19
    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x2

    sub-int/2addr v1, v4

    const/4 v4, 0x0

    invoke-virtual {v14, v4, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v8, 0x1

    and-int/2addr v6, v8

    if-eqz v6, :cond_1a

    invoke-virtual {v1, v4, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_2

    const/16 v4, 0x10

    :try_start_1
    invoke-static {v6, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v13
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0

    move v6, v8

    goto :goto_b

    :catch_0
    move v8, v4

    :catch_1
    :goto_a
    const/4 v6, 0x2

    goto :goto_c

    :catch_2
    const/4 v6, 0x2

    const/16 v8, 0x10

    goto :goto_c

    :cond_1a
    const/4 v6, 0x0

    const/4 v13, 0x0

    :goto_b
    :try_start_2
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_2

    if-ge v6, v4, :cond_1b

    add-int/lit8 v4, v6, 0x2

    :try_start_3
    invoke-virtual {v1, v6, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6
    :try_end_3
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3} :catch_3

    const/16 v8, 0x10

    :try_start_4
    invoke-static {v6, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v6

    add-int/2addr v13, v6

    and-int/lit16 v13, v13, 0xff

    move v6, v4

    goto :goto_b

    :catch_3
    const/16 v8, 0x10

    goto :goto_a

    :cond_1b
    const/16 v8, 0x10

    invoke-static {v13}, Lc/k6;->J(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v4
    :try_end_4
    .catch Ljava/lang/NumberFormatException; {:try_start_4 .. :try_end_4} :catch_1

    const/4 v6, 0x2

    sub-int/2addr v4, v6

    :try_start_5
    invoke-virtual {v14, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13
    :try_end_5
    .catch Ljava/lang/NumberFormatException; {:try_start_5 .. :try_end_5} :catch_4

    goto :goto_d

    :catch_4
    :goto_c
    const/4 v13, 0x0

    :goto_d
    if-eqz v13, :cond_1c

    add-int/lit8 v12, v12, 0x2

    :cond_1c
    :goto_e
    add-int/lit8 v5, v5, 0x1

    move v4, v6

    move v6, v8

    const/4 v1, 0x0

    const/4 v8, 0x6

    goto/16 :goto_1

    :cond_1d
    if-le v10, v11, :cond_1e

    if-le v10, v12, :cond_1e

    const/4 v0, 0x6

    return v0

    :cond_1e
    if-le v11, v10, :cond_1f

    if-le v11, v12, :cond_1f

    return v13

    :cond_1f
    if-le v12, v10, :cond_20

    move v1, v9

    goto :goto_f

    :cond_20
    const/4 v1, 0x0

    :goto_f
    return v1

    :goto_10
    return v0
.end method

.method public static d0(Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    const/4 v0, 0x0

    if-eqz p0, :cond_6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/high16 v2, 0x10000

    if-le v1, v2, :cond_0

    goto/16 :goto_3

    :cond_0
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "01%02X"

    invoke-static {v1, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string v5, "7E8"

    invoke-static {p0, v3, v5}, Lc/k6;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v3

    const/4 v6, 0x4

    if-eqz v3, :cond_1

    array-length v3, v3

    if-ne v3, v6, :cond_1

    return-object v5

    :cond_1
    invoke-virtual {p0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "[\\r\\n]+"

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    array-length v3, v1

    move v5, v2

    :goto_0
    if-ge v5, v3, :cond_6

    aget-object v7, v1, v5

    const-string v8, " "

    const-string v9, ""

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "\t"

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    const-string v8, ">"

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    const-string v8, "18DAF1"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_2

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    const/16 v9, 0xa

    if-lt v8, v9, :cond_2

    const/16 v8, 0x8

    invoke-virtual {v7, v2, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_2
    const-string v8, "7E"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v9, 0x5

    if-lt v8, v9, :cond_3

    const/4 v8, 0x3

    invoke-virtual {v7, v2, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_3
    move-object v7, v0

    :goto_1
    if-nez v7, :cond_4

    move-object v8, v0

    goto :goto_2

    :cond_4
    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v9}, [Ljava/lang/Object;

    move-result-object v9

    invoke-static {v8, v4, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-static {p0, v8, v7}, Lc/k6;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v8

    :goto_2
    if-eqz v8, :cond_5

    array-length v8, v8

    if-ne v8, v6, :cond_5

    return-object v7

    :cond_5
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_6
    :goto_3
    return-object v0
.end method

.method public static e(C)Z
    .locals 1

    const/16 v0, 0x30

    if-lt p0, v0, :cond_0

    const/16 v0, 0x39

    if-le p0, v0, :cond_4

    :cond_0
    const/16 v0, 0x41

    if-lt p0, v0, :cond_1

    const/16 v0, 0x5a

    if-le p0, v0, :cond_4

    :cond_1
    const/16 v0, 0x61

    if-lt p0, v0, :cond_2

    const/16 v0, 0x7a

    if-le p0, v0, :cond_4

    :cond_2
    const/16 v0, 0xd

    if-eq p0, v0, :cond_4

    const/16 v0, 0xa

    if-ne p0, v0, :cond_3

    goto :goto_0

    :cond_3
    const/4 p0, 0x0

    goto :goto_1

    :cond_4
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static e0(Ljava/lang/String;)Z
    .locals 4

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x2

    if-lt v1, v2, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v3, 0x200

    if-gt v1, v3, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x1

    and-int/2addr v1, v3

    if-nez v1, :cond_0

    const-string v1, "[0-9A-Fa-f]+"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p0, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const/16 v1, 0x10

    invoke-static {p0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result p0

    const/16 v1, 0xbf

    if-gt p0, v1, :cond_0

    move v0, v3

    :cond_0
    return v0
.end method

.method public static f(Ljava/lang/String;I)Z
    .locals 3

    add-int/lit8 v0, p1, -0x2

    const/4 v1, 0x0

    :try_start_0
    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/16 v2, 0x10

    invoke-static {v0, v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    sub-int/2addr p0, p1

    div-int/lit8 p0, p0, 0x2
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-ne v0, p0, :cond_0

    const/4 v1, 0x1

    :catch_0
    :cond_0
    return v1
.end method

.method public static f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;
    .locals 2

    new-instance v0, Lc/c7;

    const/4 v1, 0x1

    invoke-direct {v0, p0, p1, v1}, Lc/c7;-><init>(Landroid/content/SharedPreferences;Lc/j6;I)V

    invoke-static {v0}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lorg/json/JSONArray;

    return-object p0
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .locals 1

    new-instance v0, Ljava/net/URI;

    invoke-direct {v0, p0}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object p0

    if-nez p0, :cond_0

    const-string p0, ""

    goto :goto_0

    :cond_0
    const/16 v0, 0x2f

    invoke-virtual {p0, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    :goto_0
    const-string v0, "[A-Za-z0-9][A-Za-z0-9._-]*\\.apk"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-object p0

    :cond_1
    new-instance p0, Ljava/lang/SecurityException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0438\u043c\u044f APK \u0434\u043b\u044f \u0437\u0435\u0440\u043a\u0430\u043b\u0430"

    invoke-direct {p0, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static g0(Ljava/lang/String;Ljava/lang/String;J)Ljava/lang/String;
    .locals 6

    const-string v0, "\u042f\u043d\u0434\u0435\u043a\u0441 \u0414\u0438\u0441\u043a: HTTP "

    const-string v1, "update.json"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "rollback.json"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "[A-Za-z0-9][A-Za-z0-9._-]*\\.apk"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/SecurityException;

    const-string p1, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430 \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    const-string v1, "stable"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string v2, "beta"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string v2, "alpha"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string v2, "voice"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_3

    const-string v2, "voice-language-"

    invoke-virtual {p1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_1

    :cond_2
    new-instance p0, Ljava/lang/SecurityException;

    const-string p1, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043a\u0430\u043d\u0430\u043b \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    :goto_1
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "https://cloud-api.yandex.net/v1/disk/public/resources/download?public_key="

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "https://yadi.sk/d/lPnFQWZhHcDbKQ"

    const-string v4, "UTF-8"

    invoke-static {v3, v4}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "&path="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v5, "/"

    if-eqz v1, :cond_4

    goto :goto_2

    :cond_4
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p1}, Lc/k6;->t(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :goto_2
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v4}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p0, p1, p2, p3}, Lc/T8;->b(Ljava/lang/String;ZJ)Ljava/net/HttpURLConnection;

    move-result-object p0

    :try_start_0
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    const/16 v2, 0xc8

    if-ne v1, v2, :cond_6

    new-instance v0, Lorg/json/JSONObject;

    new-instance v1, Ljava/lang/String;

    new-instance v2, Lc/S8;

    invoke-virtual {p0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v3

    invoke-direct {v2, v3, p0, p2, p3}, Lc/S8;-><init>(Ljava/io/InputStream;Ljava/net/HttpURLConnection;J)V

    const/high16 v3, 0x10000

    invoke-static {v2, v3, p2, p3}, Lc/T8;->d(Ljava/io/InputStream;IJ)[B

    move-result-object p2

    sget-object p3, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-direct {v1, p2, p3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p2, "GET"

    const-string p3, "method"

    invoke-virtual {v0, p3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_5

    const-string p2, "templated"

    invoke-virtual {v0, p2, p1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result p2

    if-nez p2, :cond_5

    const-string p2, "href"

    invoke-virtual {v0, p2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lc/T8;->f(ZLjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V

    return-object p2

    :catchall_0
    move-exception p1

    goto :goto_3

    :cond_5
    :try_start_1
    new-instance p1, Ljava/lang/SecurityException;

    const-string p2, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 API \u042f\u043d\u0434\u0435\u043a\u0441 \u0414\u0438\u0441\u043a\u0430"

    invoke-direct {p1, p2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_3
    invoke-virtual {p0}, Ljava/net/HttpURLConnection;->disconnect()V

    throw p1
.end method

.method public static h(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    invoke-static {p0}, Lc/k6;->v(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "VWTP:"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    const-string v0, "VWTP:[0-9A-F]{2}:[0-9A-F]+"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/16 v0, 0x8

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid VW query"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    and-int/lit8 v0, v0, 0x1

    if-nez v0, :cond_2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    if-lt v0, v1, :cond_2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0xffe

    if-gt v0, v1, :cond_2

    const-string v0, "[0-9A-F]+"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    return-object p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid application query"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static h0(ILjava/lang/String;Ljava/lang/String;)I
    .locals 8

    invoke-static {p0}, Lc/k6;->I(I)I

    move-result p0

    const/4 v0, 0x0

    if-eqz p1, :cond_6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/high16 v2, 0x10000

    if-gt v1, v2, :cond_6

    if-nez p0, :cond_0

    goto :goto_2

    :cond_0
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "[\\r\\n]+"

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v1, p1

    move v2, v0

    move v3, v2

    :goto_0
    const/16 v4, 0x10

    if-ge v2, v1, :cond_5

    aget-object v5, p1, v2

    invoke-static {v5}, Lc/k6;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz p2, :cond_1

    invoke-virtual {v5, p2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    add-int/lit8 v7, p0, 0x2

    if-lt v6, v7, :cond_4

    const-string v6, "[0-9A-F]+"

    invoke-virtual {v5, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_4

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    sub-int/2addr v6, p0

    and-int/lit8 v6, v6, 0x1

    if-eqz v6, :cond_2

    goto :goto_1

    :cond_2
    const/4 v6, 0x6

    if-eq p0, v6, :cond_3

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    sub-int/2addr v5, p0

    if-le v5, v4, :cond_3

    goto :goto_1

    :cond_3
    add-int/lit8 v3, v3, 0x1

    :cond_4
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_5
    if-lez v3, :cond_6

    if-ge v3, v4, :cond_6

    move v0, v3

    :cond_6
    :goto_2
    return v0
.end method

.method public static i(Lc/h7;)Ljava/lang/Object;
    .locals 2

    :try_start_0
    invoke-interface {p0}, Lc/h7;->run()Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    instance-of v0, p0, Ljava/lang/IllegalArgumentException;

    if-nez v0, :cond_1

    instance-of v0, p0, Ljava/lang/IllegalStateException;

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 PID"

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :cond_1
    :goto_0
    throw p0

    :catch_1
    move-exception p0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 JSON PID"

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static i0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .locals 8

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/16 v2, 0x8

    const/16 v3, 0x10

    const-string v4, "ATCRA"

    invoke-static {v4, p2}, Lc/k6;->k(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    const-string v6, ""

    if-nez v5, :cond_0

    invoke-virtual {p2, v4, v6}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    if-eqz p0, :cond_1f

    const-string p2, "[0-9A-Fa-f]{3}"

    invoke-virtual {p0, p2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_1

    goto/16 :goto_4

    :cond_1
    sget-object p2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, p2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    const/16 v5, 0x7e0

    const-string v6, "%03X"

    if-lt v4, v5, :cond_2

    const/16 v5, 0x7e7

    if-gt v4, v5, :cond_2

    add-int/2addr v4, v2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p2, v6, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_2
    if-eqz p1, :cond_1e

    const/4 v5, -0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v7

    sparse-switch v7, :sswitch_data_0

    :goto_0
    move v3, v5

    goto/16 :goto_1

    :sswitch_0
    const-string v3, "Bentley"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    const/16 v3, 0x19

    goto/16 :goto_1

    :sswitch_1
    const-string v3, "Porsche"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_4

    goto :goto_0

    :cond_4
    const/16 v3, 0x18

    goto/16 :goto_1

    :sswitch_2
    const-string v3, "Dongfeng"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5

    goto :goto_0

    :cond_5
    const/16 v3, 0x17

    goto/16 :goto_1

    :sswitch_3
    const-string v3, "Peugeot"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_6

    goto :goto_0

    :cond_6
    const/16 v3, 0x16

    goto/16 :goto_1

    :sswitch_4
    const-string v3, "Volkswagen"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_7

    goto :goto_0

    :cond_7
    const/16 v3, 0x15

    goto/16 :goto_1

    :sswitch_5
    const-string v3, "Infinity"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_8

    goto :goto_0

    :cond_8
    const/16 v3, 0x14

    goto/16 :goto_1

    :sswitch_6
    const-string v3, "Infiniti"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_9

    goto :goto_0

    :cond_9
    const/16 v3, 0x13

    goto/16 :goto_1

    :sswitch_7
    const-string v3, "XPeng"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_a

    goto :goto_0

    :cond_a
    const/16 v3, 0x12

    goto/16 :goto_1

    :sswitch_8
    const-string v3, "Skoda"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_b

    goto :goto_0

    :cond_b
    const/16 v3, 0x11

    goto/16 :goto_1

    :sswitch_9
    const-string v7, "Lifan"

    invoke-virtual {p1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1c

    goto/16 :goto_0

    :sswitch_a
    const-string v3, "Isuzu"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_c

    goto/16 :goto_0

    :cond_c
    const/16 v3, 0xf

    goto/16 :goto_1

    :sswitch_b
    const-string v3, "ISUZU"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_d

    goto/16 :goto_0

    :cond_d
    const/16 v3, 0xe

    goto/16 :goto_1

    :sswitch_c
    const-string v3, "Hover"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_e

    goto/16 :goto_0

    :cond_e
    const/16 v3, 0xd

    goto/16 :goto_1

    :sswitch_d
    const-string v3, "Haval"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_f

    goto/16 :goto_0

    :cond_f
    const/16 v3, 0xc

    goto/16 :goto_1

    :sswitch_e
    const-string v3, "Dacia"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_10

    goto/16 :goto_0

    :cond_10
    const/16 v3, 0xb

    goto/16 :goto_1

    :sswitch_f
    const-string v3, "Cupra"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_11

    goto/16 :goto_0

    :cond_11
    const/16 v3, 0xa

    goto/16 :goto_1

    :sswitch_10
    const-string v3, "Seat"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_12

    goto/16 :goto_0

    :cond_12
    const/16 v3, 0x9

    goto/16 :goto_1

    :sswitch_11
    const-string v3, "Audi"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_13

    goto/16 :goto_0

    :cond_13
    move v3, v2

    goto/16 :goto_1

    :sswitch_12
    const-string v3, "DS"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_14

    goto/16 :goto_0

    :cond_14
    const/4 v3, 0x7

    goto :goto_1

    :sswitch_13
    const-string v3, "Mitsubishi"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_15

    goto/16 :goto_0

    :cond_15
    const/4 v3, 0x6

    goto :goto_1

    :sswitch_14
    const-string v3, "Samsung"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_16

    goto/16 :goto_0

    :cond_16
    const/4 v3, 0x5

    goto :goto_1

    :sswitch_15
    const-string v3, "Renault"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_17

    goto/16 :goto_0

    :cond_17
    const/4 v3, 0x4

    goto :goto_1

    :sswitch_16
    const-string v3, "Great Wall"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_18

    goto/16 :goto_0

    :cond_18
    const/4 v3, 0x3

    goto :goto_1

    :sswitch_17
    const-string v3, "Suzuki"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_19

    goto/16 :goto_0

    :cond_19
    const/4 v3, 0x2

    goto :goto_1

    :sswitch_18
    const-string v3, "Citroen"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1a

    goto/16 :goto_0

    :cond_1a
    move v3, v1

    goto :goto_1

    :sswitch_19
    const-string v3, "Nissan"

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1b

    goto/16 :goto_0

    :cond_1b
    move v3, v0

    :cond_1c
    :goto_1
    packed-switch v3, :pswitch_data_0

    goto :goto_2

    :pswitch_0
    const/16 v1, 0x80

    goto :goto_3

    :pswitch_1
    const/16 v1, 0x6a

    goto :goto_3

    :pswitch_2
    const/16 v1, 0x40

    goto :goto_3

    :pswitch_3
    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/16 v0, 0x32

    if-ne p1, v0, :cond_1e

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "6"

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_4
    const/16 v1, -0x20

    goto :goto_3

    :pswitch_5
    const/16 p0, 0x7a0

    if-lt v4, p0, :cond_1d

    const/16 p0, 0x7a7

    if-gt v4, p0, :cond_1d

    goto :goto_2

    :cond_1d
    const/16 p0, 0x20

    move v1, p0

    goto :goto_3

    :cond_1e
    :goto_2
    move v1, v2

    :goto_3
    :pswitch_6
    add-int/2addr v4, v1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {p2, v6, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1f
    :goto_4
    return-object v6

    nop

    :sswitch_data_0
    .sparse-switch
        -0x74e85918 -> :sswitch_19
        -0x6df97eac -> :sswitch_18
        -0x6bb3cca5 -> :sswitch_17
        -0x6a36ec43 -> :sswitch_16
        -0x5bab9849 -> :sswitch_15
        -0x2d9ea826 -> :sswitch_14
        -0x1325074d -> :sswitch_13
        0x88f -> :sswitch_12
        0x1f4fd9 -> :sswitch_11
        0x274225 -> :sswitch_10
        0x3e708cd -> :sswitch_f
        0x3ebd6fe -> :sswitch_e
        0x4247b68 -> :sswitch_d
        0x42ad91c -> :sswitch_c
        0x42bb8e6 -> :sswitch_b
        0x43ac0e6 -> :sswitch_a
        0x4604056 -> :sswitch_9
        0x4c3efb4 -> :sswitch_8
        0x4fdfae6 -> :sswitch_7
        0xe2cce38 -> :sswitch_6
        0xe2cce48 -> :sswitch_5
        0x1489b7cb -> :sswitch_4
        0x3aed1443 -> :sswitch_3
        0x49340c5c -> :sswitch_2
        0x4bd8b000 -> :sswitch_1
        0x55f93417 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_5
        :pswitch_5
        :pswitch_6
        :pswitch_4
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_5
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_1
        :pswitch_0
        :pswitch_5
        :pswitch_5
        :pswitch_1
        :pswitch_4
        :pswitch_0
        :pswitch_1
        :pswitch_1
    .end packed-switch
.end method

.method public static j()Lc/j6;
    .locals 6

    new-instance v0, Lc/j6;

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const-string v2, "schema"

    const/4 v3, 0x2

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "id"

    const-string v3, "000000000000000000000000"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "name"

    const-string v3, "OBD II"

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "protocol"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, "useObd2"

    const/4 v4, 0x1

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v1

    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const-string v5, "UseOBD2"

    invoke-virtual {v2, v5, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v2

    const-string v4, "UseCustomInit"

    invoke-virtual {v2, v4, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v2

    const-string v3, "connection"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    new-instance v2, Lorg/json/JSONArray;

    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    const-string v3, "sensors"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v1

    const-string v2, ""

    invoke-direct {v0, v1, v2}, Lc/j6;-><init>(Lorg/json/JSONObject;Ljava/lang/String;)V

    return-object v0
.end method

.method public static j0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .locals 5

    const-string v0, "ATCRA"

    invoke-static {v0, p2}, Lc/k6;->k(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const-string v3, ""

    if-nez v2, :cond_0

    invoke-virtual {v1, v0, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    const-string v0, "ATCF"

    invoke-static {v0, p2}, Lc/k6;->k(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "ATCM"

    invoke-static {v0, p2}, Lc/k6;->k(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_1

    const-string p0, "??"

    return-object p0

    :cond_1
    if-nez p0, :cond_2

    return-object v3

    :cond_2
    sget-object p2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, p2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "[0-9A-F]{6}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    if-eqz p1, :cond_3

    const-string v0, "[0-9A-Fa-f]{2}"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1, p2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 p1, 0x2

    invoke-virtual {p0, v1, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Explicit CAN29 priority required"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    const-string p1, "[0-9A-F]{8}"

    invoke-virtual {p0, p1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v1, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p2, 0x8

    invoke-virtual {p0, v2, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_5
    return-object v3
.end method

.method public static k(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;
    .locals 4

    const-string v0, ""

    if-eqz p1, :cond_1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_0

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    const-string p1, " "

    invoke-virtual {p0, p1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    return-object v0
.end method

.method public static k0(Landroid/view/View;I)V
    .locals 4

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const p1, 0x461c4000    # 10000.0f

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    new-instance p1, Landroid/graphics/drawable/RippleDrawable;

    const/4 v2, 0x0

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v3

    invoke-direct {p1, v3, v0, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    new-array v0, v2, [I

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    return-void
.end method

.method public static l(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const-string v2, "00000000"

    invoke-virtual {v2, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static l0(II)I
    .locals 8

    const/4 v0, 0x1

    if-ge p1, v0, :cond_0

    const p0, 0x7fffffff

    return p0

    :cond_0
    const/4 v1, 0x0

    move v3, v0

    move v2, v1

    move v4, v2

    :goto_0
    const/4 v5, 0x7

    if-ge v2, v5, :cond_7

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ne v2, v6, :cond_2

    and-int/lit8 v7, p0, 0x10

    if-eqz v7, :cond_2

    if-ge p1, v5, :cond_2

    if-lez v4, :cond_1

    add-int/lit8 v3, v3, 0x1

    :cond_1
    add-int/2addr v3, v0

    move v4, v0

    goto :goto_2

    :cond_2
    shl-int v7, v0, v2

    and-int/2addr v7, p0

    if-nez v7, :cond_3

    move v5, v1

    goto :goto_1

    :cond_3
    if-ne v2, v6, :cond_4

    goto :goto_1

    :cond_4
    move v5, v0

    :goto_1
    if-nez v5, :cond_5

    goto :goto_2

    :cond_5
    add-int v6, v4, v5

    if-le v6, p1, :cond_6

    add-int/lit8 v3, v3, 0x1

    move v4, v1

    :cond_6
    add-int/2addr v4, v5

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_7
    return v3
.end method

.method public static m(FII)I
    .locals 4

    invoke-static {p1}, Landroid/graphics/Color;->red(I)I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x3f800000    # 1.0f

    sub-float/2addr v1, p0

    mul-float/2addr v0, v1

    invoke-static {p2}, Landroid/graphics/Color;->red(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, p0

    add-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v0

    invoke-static {p1}, Landroid/graphics/Color;->green(I)I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v1

    invoke-static {p2}, Landroid/graphics/Color;->green(I)I

    move-result v3

    int-to-float v3, v3

    mul-float/2addr v3, p0

    add-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-static {p1}, Landroid/graphics/Color;->blue(I)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v1

    invoke-static {p2}, Landroid/graphics/Color;->blue(I)I

    move-result p2

    int-to-float p2, p2

    mul-float/2addr p2, p0

    add-float/2addr p2, p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-static {v0, v2, p0}, Landroid/graphics/Color;->rgb(III)I

    move-result p0

    return p0
.end method

.method public static m0(Lc/r0;Lc/r0;ZIILc/o0;FI)I
    .locals 2

    iget v0, p0, Lc/r0;->e:I

    iget v1, p0, Lc/r0;->f:I

    mul-int/2addr v0, v1

    invoke-virtual {p5, p0}, Lc/o0;->a(Lc/r0;)Lc/m0;

    move-result-object p5

    invoke-virtual {p5}, Lc/m0;->d()F

    move-result p5

    invoke-static {p3, p5, p6, p4}, Lc/k6;->u(IFFI)I

    move-result p4

    invoke-static {p3, p4}, Lc/k6;->l0(II)I

    move-result p3

    iget p0, p0, Lc/r0;->e:I

    if-eqz p2, :cond_1

    if-le p3, p7, :cond_0

    const p1, 0xf4240

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    mul-int/lit16 p0, p0, 0x3e8

    add-int/2addr p0, p1

    add-int/2addr p0, v1

    goto :goto_1

    :cond_1
    iget p2, p1, Lc/r0;->e:I

    sub-int/2addr p0, p2

    invoke-static {p0}, Ljava/lang/Math;->abs(I)I

    move-result p0

    iget p1, p1, Lc/r0;->f:I

    sub-int/2addr v1, p1

    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    add-int/2addr p1, p0

    mul-int/lit16 p1, p1, 0x3e8

    add-int p0, p1, v0

    :goto_1
    return p0
.end method

.method public static n(Ljava/lang/String;)V
    .locals 9

    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    array-length v0, v0

    const/high16 v1, 0x100000

    if-gt v0, v1, :cond_a

    const/4 v0, 0x0

    move v1, v0

    move v2, v1

    move v3, v2

    move v4, v3

    :goto_0
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v5

    if-ge v1, v5, :cond_9

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/16 v6, 0x22

    const/4 v7, 0x1

    if-eqz v2, :cond_2

    if-eqz v3, :cond_0

    move v3, v0

    goto :goto_2

    :cond_0
    const/16 v8, 0x5c

    if-ne v5, v8, :cond_1

    move v3, v7

    goto :goto_2

    :cond_1
    if-ne v5, v6, :cond_7

    move v2, v0

    goto :goto_2

    :cond_2
    if-ne v5, v6, :cond_3

    move v2, v7

    goto :goto_2

    :cond_3
    const/16 v6, 0x7b

    if-eq v5, v6, :cond_6

    const/16 v6, 0x5b

    if-ne v5, v6, :cond_4

    goto :goto_1

    :cond_4
    const/16 v6, 0x7d

    if-eq v5, v6, :cond_5

    const/16 v6, 0x5d

    if-ne v5, v6, :cond_7

    :cond_5
    add-int/lit8 v4, v4, -0x1

    goto :goto_2

    :cond_6
    :goto_1
    add-int/lit8 v4, v4, 0x1

    const/16 v5, 0x40

    if-gt v4, v5, :cond_8

    :cond_7
    :goto_2
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_8
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0433\u043b\u0443\u0431\u043e\u043a\u0438\u0439 JSON PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_9
    return-void

    :cond_a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "JSON PID \u0431\u043e\u043b\u044c\u0448\u0435 1 \u041c\u0438\u0411"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static n0(Landroid/widget/TextView;Lc/N8;Lc/U8;)V
    .locals 4

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    iget-wide v1, p2, Lc/U8;->e:J

    long-to-float v1, v1

    const/high16 v2, 0x44800000    # 1024.0f

    div-float/2addr v1, v2

    div-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "%.1f MB"

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u0430 "

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p2, Lc/U8;->b:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " \u00b7 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p2, Lc/U8;->f:Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p2, ""

    goto :goto_0

    :cond_0
    const-string v0, "\n\n"

    invoke-virtual {v0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    :goto_0
    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    const-string p2, "\u0421\u043a\u0430\u0447\u0430\u0442\u044c \u0438 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c"

    invoke-static {p0, p2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {p1}, Lc/G8;->r(Landroid/widget/TextView;)V

    return-void
.end method

.method public static o(Ljava/io/File;Ljava/io/File;I)[B
    .locals 5

    invoke-virtual {p0}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object p0

    invoke-virtual {p1}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object p1

    invoke-virtual {p0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/io/File;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v0, 0x0

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Ljava/io/File;->isFile()Z

    move-result p1

    if-eqz p1, :cond_3

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long p1, v1, v3

    if-lez p1, :cond_3

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v1

    int-to-long v3, p2

    cmp-long p1, v1, v3

    if-lez p1, :cond_0

    goto :goto_5

    :cond_0
    new-instance p1, Ljava/io/FileInputStream;

    invoke-direct {p1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    :try_start_0
    new-instance p0, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v1, 0x2000

    :try_start_1
    new-array v1, v1, [B

    :goto_0
    invoke-virtual {p1, v1}, Ljava/io/FileInputStream;->read([B)I

    move-result v2

    const/4 v3, -0x1

    if-eq v2, v3, :cond_2

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    add-int/2addr v3, v2

    if-le v3, p2, :cond_1

    :try_start_2
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    invoke-virtual {p1}, Ljava/io/FileInputStream;->close()V

    return-object v0

    :catchall_0
    move-exception p0

    goto :goto_3

    :cond_1
    const/4 v3, 0x0

    :try_start_3
    invoke-virtual {p0, v1, v3, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_0

    :catchall_1
    move-exception p2

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    invoke-virtual {p1}, Ljava/io/FileInputStream;->close()V

    return-object p2

    :goto_1
    :try_start_5
    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception p0

    :try_start_6
    invoke-virtual {p2, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2
    throw p2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_3
    :try_start_7
    invoke-virtual {p1}, Ljava/io/FileInputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_3

    goto :goto_4

    :catchall_3
    move-exception p1

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_4
    throw p0

    :cond_3
    :goto_5
    return-object v0
.end method

.method public static o0(Ljava/lang/String;III)I
    .locals 3

    if-eqz p3, :cond_c

    if-ltz p1, :cond_b

    if-ltz p2, :cond_b

    const/16 v0, 0xfff

    if-gt p1, v0, :cond_b

    const/high16 v0, 0x10000

    if-gt p2, v0, :cond_b

    invoke-static {p0}, Lc/k6;->h(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-ne p3, v0, :cond_0

    add-int/2addr p1, v1

    return p1

    :cond_0
    const-string v0, "06"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    return v2

    :cond_1
    const/4 v0, 0x1

    if-eq p3, v0, :cond_a

    if-eq p3, v1, :cond_9

    const/4 v0, 0x4

    if-ne p3, v0, :cond_2

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p3

    div-int/2addr p3, v1

    if-le p2, p3, :cond_7

    const-string p3, "2C"

    invoke-virtual {p0, p3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p3

    if-nez p3, :cond_7

    const-string p2, "22"

    invoke-virtual {p0, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_3

    const/4 p0, 0x3

    return p0

    :cond_3
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p2

    const/4 p3, 0x6

    if-ne p2, p3, :cond_4

    const-string p2, "AA"

    invoke-virtual {p0, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_6

    :cond_4
    const-string p2, "01"

    invoke-virtual {p0, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-nez p2, :cond_6

    const-string p2, "21"

    invoke-virtual {p0, p2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_5

    const-string p2, "8001"

    invoke-virtual {p0, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_5

    goto :goto_0

    :cond_5
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    div-int/2addr p0, v1

    return p0

    :cond_6
    :goto_0
    return p1

    :cond_7
    if-le p2, p1, :cond_8

    goto :goto_1

    :cond_8
    move p1, v2

    :cond_9
    :goto_1
    return p1

    :cond_a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Resolve transport before stripping payload"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid response bounds"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Missing response transport"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static p(Landroid/widget/Button;Lc/r4;Z)V
    .locals 1

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    if-eqz p2, :cond_0

    const p1, -0x39d7d8

    goto :goto_0

    :cond_0
    const p1, -0xff79c2

    :goto_0
    invoke-static {p0, p1}, Lc/k6;->k0(Landroid/view/View;I)V

    const/4 p1, -0x1

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    return-void
.end method

.method public static p0(I)I
    .locals 3

    and-int/lit8 v0, p0, 0x4f

    invoke-static {v0}, Ljava/lang/Integer;->bitCount(I)I

    move-result v0

    and-int/lit8 v1, p0, 0x10

    const/4 v2, 0x0

    if-nez v1, :cond_0

    move v1, v2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    :goto_0
    add-int/2addr v0, v1

    and-int/lit8 p0, p0, 0x20

    if-nez p0, :cond_1

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    :goto_1
    add-int/2addr v0, v2

    return v0
.end method

.method public static q(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/LinearLayout;
    .locals 2

    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0xc

    int-to-float v1, v1

    invoke-static {p0, v1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    invoke-virtual {v0, p0, p0, p0, p0}, Landroid/view/View;->setPadding(IIII)V

    return-object v0
.end method

.method public static q0(Ljava/lang/String;)V
    .locals 1

    const-string v0, "user_[a-f0-9]{32}"

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0439 ID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static r(Lru/drivedeck/launcher/MainActivity;I)Landroid/graphics/drawable/GradientDrawable;
    .locals 1

    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 p1, 0x10

    int-to-float p1, p1

    invoke-static {p0, p1}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result p0

    int-to-float p0, p0

    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method public static r0(Ljava/lang/String;)Z
    .locals 5

    const/4 v0, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-lt v1, v3, :cond_13

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/16 v4, 0xffe

    if-gt v1, v4, :cond_13

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    and-int/2addr v1, v0

    if-nez v1, :cond_13

    const-string v1, "[0-9A-F]+"

    invoke-virtual {p0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_2

    :cond_0
    invoke-virtual {p0, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, -0x1

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v4

    sparse-switch v4, :sswitch_data_0

    :goto_0
    move v3, v1

    goto/16 :goto_1

    :sswitch_0
    const-string v3, "CD"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    goto :goto_0

    :cond_1
    const/16 v3, 0x11

    goto/16 :goto_1

    :sswitch_1
    const-string v3, "CC"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2

    goto :goto_0

    :cond_2
    const/16 v3, 0x10

    goto/16 :goto_1

    :sswitch_2
    const-string v3, "AA"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    const/16 v3, 0xf

    goto/16 :goto_1

    :sswitch_3
    const-string v3, "A8"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    goto :goto_0

    :cond_4
    const/16 v3, 0xe

    goto/16 :goto_1

    :sswitch_4
    const-string v3, "A0"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    goto :goto_0

    :cond_5
    const/16 v3, 0xd

    goto/16 :goto_1

    :sswitch_5
    const-string v3, "85"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_6

    goto :goto_0

    :cond_6
    const/16 v3, 0xc

    goto/16 :goto_1

    :sswitch_6
    const-string v3, "62"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_7

    goto :goto_0

    :cond_7
    const/16 v3, 0xb

    goto/16 :goto_1

    :sswitch_7
    const-string v3, "31"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_8

    goto :goto_0

    :cond_8
    const/16 v3, 0xa

    goto/16 :goto_1

    :sswitch_8
    const-string v3, "30"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_9

    goto :goto_0

    :cond_9
    const/16 v3, 0x9

    goto/16 :goto_1

    :sswitch_9
    const-string v3, "2C"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_a

    goto/16 :goto_0

    :cond_a
    const/16 v3, 0x8

    goto/16 :goto_1

    :sswitch_a
    const-string v3, "22"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_b

    goto/16 :goto_0

    :cond_b
    const/4 v3, 0x7

    goto :goto_1

    :sswitch_b
    const-string v3, "21"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_c

    goto/16 :goto_0

    :cond_c
    const/4 v3, 0x6

    goto :goto_1

    :sswitch_c
    const-string v3, "20"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_d

    goto/16 :goto_0

    :cond_d
    const/4 v3, 0x5

    goto :goto_1

    :sswitch_d
    const-string v3, "1A"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_e

    goto/16 :goto_0

    :cond_e
    const/4 v3, 0x4

    goto :goto_1

    :sswitch_e
    const-string v3, "19"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_f

    goto/16 :goto_0

    :cond_f
    const/4 v3, 0x3

    goto :goto_1

    :sswitch_f
    const-string v4, "12"

    invoke-virtual {p0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_12

    goto/16 :goto_0

    :sswitch_10
    const-string v3, "09"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_10

    goto/16 :goto_0

    :cond_10
    move v3, v0

    goto :goto_1

    :sswitch_11
    const-string v3, "01"

    invoke-virtual {p0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_11

    goto/16 :goto_0

    :cond_11
    move v3, v2

    :cond_12
    :goto_1
    packed-switch v3, :pswitch_data_0

    return v2

    :pswitch_0
    return v0

    :cond_13
    :goto_2
    return v2

    :sswitch_data_0
    .sparse-switch
        0x601 -> :sswitch_11
        0x609 -> :sswitch_10
        0x621 -> :sswitch_f
        0x628 -> :sswitch_e
        0x630 -> :sswitch_d
        0x63e -> :sswitch_c
        0x63f -> :sswitch_b
        0x640 -> :sswitch_a
        0x651 -> :sswitch_9
        0x65d -> :sswitch_8
        0x65e -> :sswitch_7
        0x6bc -> :sswitch_6
        0x6fd -> :sswitch_5
        0x80f -> :sswitch_4
        0x817 -> :sswitch_3
        0x820 -> :sswitch_2
        0x860 -> :sswitch_1
        0x861 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static s(I)F
    .locals 1

    int-to-float p0, p0

    const/high16 v0, 0x42a00000    # 80.0f

    mul-float/2addr p0, v0

    const/high16 v0, 0x42880000    # 68.0f

    div-float/2addr p0, v0

    return p0
.end method

.method public static s0(Lc/j6;Lorg/json/JSONArray;)Ljava/util/LinkedHashMap;
    .locals 8

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    new-instance v2, Lorg/json/JSONArray;

    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v5

    const-string v6, "Id"

    if-ge v4, v5, :cond_3

    invoke-virtual {p1, v4}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    const-string v7, ""

    invoke-virtual {v5, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    :try_start_0
    invoke-static {v5}, Lc/k6;->t0(Lorg/json/JSONObject;)V

    if-eqz p0, :cond_1

    iget-object v7, p0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-interface {v7, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_1

    iget-object v7, p0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v7, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/i6;

    iget-boolean v7, v7, Lc/i6;->z:Z

    if-eqz v7, :cond_0

    goto :goto_1

    :cond_0
    new-instance v5, Ljava/lang/IllegalArgumentException;

    const-string v7, "ID \u0437\u0430\u043d\u044f\u0442 \u043f\u0440\u043e\u0444\u0438\u043b\u0435\u043c"

    invoke-direct {v5, v7}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v5

    :catch_0
    move-exception v5

    goto :goto_2

    :catch_1
    move-exception v5

    goto :goto_2

    :cond_1
    :goto_1
    invoke-virtual {v2, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :goto_2
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v0, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_3
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u041f\u043e\u0432\u0442\u043e\u0440\u043d\u044b\u0439 ID PID"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    if-nez p0, :cond_4

    invoke-static {}, Lc/k6;->j()Lc/j6;

    move-result-object p0

    :cond_4
    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p1

    invoke-virtual {p0, v2, p1}, Lc/j6;->f(Lorg/json/JSONArray;Ljava/util/Map;)Lc/j6;

    move-result-object p0

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    :goto_4
    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v3, v4, :cond_5

    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :try_start_1
    iget-object v5, p0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v5, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/i6;

    new-instance v7, Ljava/util/HashSet;

    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    invoke-static {p0, v5, v7, p1, v1}, Lc/k6;->C(Lc/j6;Lc/i6;Ljava/util/HashSet;Ljava/util/HashMap;Ljava/util/HashMap;)I
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_2

    goto :goto_5

    :catch_2
    move-exception v5

    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_5
    add-int/lit8 v3, v3, 0x1

    goto :goto_4

    :cond_5
    return-object v0
.end method

.method public static t(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, "voice"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string p0, "modules/voice/v3"

    return-object p0

    :cond_0
    const-string v0, "voice-language-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/16 v0, 0xf

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ld/a;->b(Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "modules/voice/languages/"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1
    const-string v0, "alpha"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string p0, "alpha-0.5.2"

    :cond_2
    return-object p0
.end method

.method public static t0(Lorg/json/JSONObject;)V
    .locals 14

    const-string v0, "Id"

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/k6;->q0(Ljava/lang/String;)V

    invoke-virtual {p0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p0, v1}, Lorg/json/JSONObject;->opt(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_0

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x2000

    if-gt v2, v3, :cond_1

    goto :goto_0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u043e\u0435 \u043f\u043e\u043b\u0435: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    const-string v0, "NM"

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "SNM"

    invoke-virtual {p0, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x80

    if-gt v2, v3, :cond_21

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_20

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-gt v0, v3, :cond_20

    const-string v0, "ACT"

    const/4 v2, 0x0

    invoke-virtual {p0, v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1f

    const-string v0, "TP"

    const/4 v3, 0x5

    invoke-static {p0, v0, v3}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x3

    if-eq v0, v4, :cond_1e

    const/4 v4, 0x4

    if-eq v0, v4, :cond_1e

    const-string v4, "CMD"

    invoke-virtual {p0, v4, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "\\s"

    invoke-virtual {v5, v6, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v5, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "VWTP:"

    invoke-virtual {v5, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_3

    const-string v8, "^VWTP:[0-9A-F]{2}:"

    invoke-virtual {v5, v8, v1}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    goto :goto_1

    :cond_3
    move-object v8, v5

    :goto_1
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_5

    if-nez v0, :cond_4

    goto :goto_2

    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041f\u0443\u0441\u0442\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430 PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_5
    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v9

    const/16 v10, 0xffe

    if-gt v9, v10, :cond_1d

    const-string v9, "(?:01|09|12|19|1A|20|21|22)(?:[0-9A-F]{2}){0,2046}"

    invoke-virtual {v8, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_1d

    invoke-virtual {v5, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_6

    const-string v4, "VWTP:[0-9A-F]{2}:[0-9A-F]+"

    invoke-virtual {v5, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1d

    :cond_6
    :goto_2
    const-string v4, "HDR"

    invoke-virtual {p0, v4, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8, v6, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v4, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_8

    invoke-static {v6}, Lc/j6;->e(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_7

    goto :goto_3

    :cond_7
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0430\u0434\u0440\u0435\u0441 \u042d\u0411\u0423"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_8
    :goto_3
    const-string v4, "UN"

    const/16 v6, 0x3e8

    invoke-static {p0, v4, v6}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    move-result v4

    if-ltz v4, :cond_1c

    const/16 v6, 0x70

    if-ge v4, v6, :cond_1c

    const-string v4, "SBI"

    const/16 v6, 0xfff

    invoke-static {p0, v4, v6}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    const-string v4, "DL"

    invoke-static {p0, v4, v6}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    const-string v4, "BIT"

    const/4 v6, 0x7

    invoke-static {p0, v4, v6}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    const-string v4, "SkipCycles"

    const/16 v6, 0x2710

    invoke-static {p0, v4, v6}, Lc/k6;->M(Lorg/json/JSONObject;Ljava/lang/String;I)I

    const-string v4, "MUL"

    const-string v6, "DIV"

    const-string v7, "OFS"

    const-string v8, "MIN"

    const-string v9, "MAX"

    filled-new-array {v4, v6, v7, v8, v9}, [Ljava/lang/String;

    move-result-object v4

    move v6, v2

    :goto_4
    if-ge v6, v3, :cond_a

    aget-object v7, v4, v6

    invoke-virtual {p0, v7}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_9

    invoke-virtual {p0, v7}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_9

    invoke-static {p0, v7}, Lc/k6;->V(Lorg/json/JSONObject;Ljava/lang/String;)D

    move-result-wide v10

    invoke-virtual {p0, v7, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    :cond_9
    add-int/lit8 v6, v6, 0x1

    goto :goto_4

    :cond_a
    invoke-virtual {p0, v8}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {p0, v9}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {p0, v8}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_c

    invoke-virtual {p0, v9}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_c

    invoke-virtual {p0, v8}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v3

    invoke-virtual {p0, v9}, Lorg/json/JSONObject;->getDouble(Ljava/lang/String;)D

    move-result-wide v6

    cmpl-double v3, v3, v6

    if-gtz v3, :cond_b

    goto :goto_5

    :cond_b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "MIN \u0431\u043e\u043b\u044c\u0448\u0435 MAX"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_c
    :goto_5
    const-string v3, "BCM"

    const-string v4, "ACM"

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    move v4, v2

    :goto_6
    const/4 v6, 0x2

    const/16 v7, 0x40

    if-ge v4, v6, :cond_15

    aget-object v6, v3, v4

    invoke-virtual {p0, v6, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lc/G8;->Q0(Ljava/lang/String;)Ljava/util/List;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v8

    if-gt v8, v7, :cond_14

    invoke-interface {v6}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :cond_d
    :goto_7
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_13

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-static {v7}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "(?:AT(?:Z|D0?|DPN|DP|I|E[01]|H[01]|S[01]|L[01]|M[01]|AL|AR|AT[012]|ST(?:[0-9A-F]{2}|DEF)|SP(?:[0-9]|A[0-9A-F]?|B|DEF)|SH(?:[0-9A-F]{3}|[0-9A-F]{6}|[01][0-9A-F]{7})|V[01]|FI|SI|KW[01]|TP[0-9A-F]{1,2}|SR[0-9A-F]{1,2}|CRA(?:[0-9A-F]{3,8})?|CF[0-9A-F]{3,8}|PB[0-9A-F]{4}|CM[0-9A-F]{1,8}|FCSH[0-9A-F]{3,8}|FCSD[0-9A-F]{2,16}|FCSM[0-2]|FC[SDH][0-9A-F]{0,16}|CFC[01]|CAF[01]|CP[0-9A-F]{2}|IB[0-9A-F]{2}|SW[0-9A-F]{2}|WM[0-9A-F]+|CEA[0-9A-F]*|TA[0-9A-F]+|IIA[0-9A-F]+)|STP[0-9A-F]{2}|STC[0-9A-F]{2,4},[0-9A-F]{2,4})"

    invoke-virtual {v8, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_11

    const-string v8, "AT"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_e

    goto :goto_8

    :cond_e
    const-string v8, "ATWM"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_11

    const-string v8, "ATIIA"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-nez v8, :cond_11

    const-string v8, "ATTA"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_f

    goto :goto_8

    :cond_f
    const-string v8, "ATFC"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_10

    const-string v8, "AT(?:FCSM[0-2]|FCSH(?:[0-9A-F]{3}|[01][0-9A-F]{7})|FCSD30[0-9A-F]{4}(?:00){0,4})"

    invoke-virtual {v7, v8}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    goto :goto_9

    :cond_10
    const/4 v8, 0x1

    goto :goto_9

    :cond_11
    :goto_8
    move v8, v2

    :goto_9
    if-nez v8, :cond_d

    const-string v8, "1001"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_d

    const-string v8, "1003"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_d

    const-string v8, "3E00"

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_12

    goto :goto_7

    :cond_12
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u0430\u044f \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430: "

    invoke-virtual {v0, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_13
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_6

    :cond_14
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u0430\u044f \u043f\u043e\u0434\u0433\u043e\u0442\u043e\u0432\u043a\u0430 PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_15
    const-string v3, "FR"

    if-nez v0, :cond_17

    invoke-virtual {p0, v3, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_16

    goto :goto_a

    :cond_16
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041f\u0443\u0441\u0442\u0430\u044f \u0444\u043e\u0440\u043c\u0443\u043b\u0430"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_17
    :goto_a
    if-nez v0, :cond_19

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-virtual {p0, v3, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    new-instance v0, Lc/U5;

    const/16 v3, 0xb6

    new-array v10, v3, [B

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v11, 0x1

    move-object v8, v0

    invoke-direct/range {v8 .. v13}, Lc/U5;-><init>(Ljava/lang/String;[BZLjava/util/function/ToDoubleFunction;[B)V

    invoke-virtual {v0}, Lc/U5;->h()D

    iget-boolean v0, v0, Lc/U5;->i:Z

    if-nez v0, :cond_18

    goto :goto_b

    :cond_18
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0414\u043b\u044f \u0431\u0430\u0439\u0442\u043e\u0432 \u0444\u043e\u0440\u043c\u0443\u043b\u044b \u0443\u043a\u0430\u0436\u0438\u0442\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u0447\u0442\u0435\u043d\u0438\u044f"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_19
    :goto_b
    new-instance v0, Lc/i6;

    invoke-direct {v0, v1, p0, v2}, Lc/i6;-><init>(Ljava/lang/String;Lorg/json/JSONObject;Z)V

    iget-boolean p0, v0, Lc/i6;->v:Z

    if-eqz p0, :cond_1b

    iget-object p0, v0, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result p0

    if-gt p0, v7, :cond_1a

    return-void

    :cond_1a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u043d\u043e\u0433\u043e \u0437\u0430\u0432\u0438\u0441\u0438\u043c\u043e\u0441\u0442\u0435\u0439 PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u043e\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0438\u0435 PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1c
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u0435\u0434\u0438\u043d\u0438\u0446\u0430"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u044b \u0442\u043e\u043b\u044c\u043a\u043e \u043a\u043e\u043c\u0430\u043d\u0434\u044b \u0447\u0442\u0435\u043d\u0438\u044f PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1e
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0434\u0435\u043a\u043e\u0434\u0435\u0440"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1f
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044f \u042d\u0411\u0423 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u044e\u0442\u0441\u044f"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_20
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0438\u043c\u044f PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_21
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u043e\u0435 \u043a\u043e\u0440\u043e\u0442\u043a\u043e\u0435 \u0438\u043c\u044f PID"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static u(IFFI)I
    .locals 1

    invoke-static {p0}, Lc/k6;->p0(I)I

    move-result p0

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    invoke-static {p3}, Lc/k6;->s(I)F

    move-result p3

    mul-float/2addr p3, p2

    div-float/2addr p1, p3

    float-to-int p1, p1

    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    return p0
.end method

.method public static u0(Ljava/lang/String;I)V
    .locals 1

    const/4 v0, 0x3

    if-eq p1, v0, :cond_3

    if-ltz p1, :cond_3

    const/4 v0, 0x5

    if-gt p1, v0, :cond_3

    invoke-static {p0}, Lc/k6;->v(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string p1, "VWTP:[0-9A-F]{2}:[0-9A-F]+"

    invoke-virtual {p0, p1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1

    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lc/k6;->r0(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Invalid VW application query"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    invoke-static {p0}, Lc/k6;->r0(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_2

    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Unsupported source query"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Authenticated telemetry required"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static v(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    if-eqz p0, :cond_1

    const/16 v0, 0xd

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_0

    const/16 v0, 0xa

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_0

    const/16 v0, 0x3b

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_0

    const/16 v0, 0x5c

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    if-gez v0, :cond_0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const-string v0, " "

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p0, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Query must contain one command"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "Missing query"

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static v0(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONArray;Ljava/util/Set;)V
    .locals 2

    invoke-virtual {p2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/k6;->n(Ljava/lang/String;)V

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/16 v1, 0x100

    if-gt v0, v1, :cond_2

    invoke-static {p0, p1}, Lc/k6;->f0(Landroid/content/SharedPreferences;Lc/j6;)Lorg/json/JSONArray;

    move-result-object v0

    invoke-static {p1, v0, p2, p3}, Lc/k6;->c(Lc/j6;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/util/Set;)Ljava/util/LinkedHashMap;

    invoke-static {p1}, Lc/k6;->O(Lc/j6;)Ljava/lang/String;

    move-result-object p3

    const/4 v0, 0x0

    invoke-interface {p0, p3, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {p1}, Lc/k6;->O(Lc/j6;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {v0, v1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result p2

    if-nez p2, :cond_1

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-static {p1}, Lc/k6;->O(Lc/j6;)Ljava/lang/String;

    move-result-object p1

    if-nez p3, :cond_0

    invoke-interface {p0, p1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_0
    invoke-interface {p0, p1, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_0
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c PID"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1
    return-void

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u043c\u043d\u043e\u0433\u043e \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044c\u0441\u043a\u0438\u0445 PID"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static w(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const-string v0, " "

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\t"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, "\u0000"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const-string v0, ">"

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static x(Ljava/lang/String;D)D
    .locals 1

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-wide p1

    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/16 p1, 0x2c

    const/16 p2, 0x2e

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->isFinite(D)Z

    move-result p2

    if-eqz p2, :cond_1

    return-wide p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "CSV: \u043d\u0435\u0432\u0435\u0440\u043d\u043e\u0435 \u0447\u0438\u0441\u043b\u043e"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static y(Lc/r4;)I
    .locals 2

    iget-boolean v0, p0, Lc/r4;->m:Z

    iget v1, p0, Lc/r4;->d:I

    iget p0, p0, Lc/r4;->k:I

    if-eqz v0, :cond_0

    const v0, 0x3e6147ae    # 0.22f

    :goto_0
    invoke-static {v0, p0, v1}, Lc/k6;->m(FII)I

    move-result p0

    goto :goto_1

    :cond_0
    const v0, 0x3e99999a    # 0.3f

    goto :goto_0

    :goto_1
    return p0
.end method

.method public static z(I)Ljava/lang/String;
    .locals 1

    const/16 v0, 0xa

    if-ge p0, v0, :cond_0

    const-string v0, "00"

    :goto_0
    invoke-static {v0, p0}, Lcom/hoho/android/usbserial/driver/a;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p0

    goto :goto_1

    :cond_0
    const/16 v0, 0x64

    if-ge p0, v0, :cond_1

    const-string v0, "0"

    goto :goto_0

    :cond_1
    const-string v0, ""

    goto :goto_0

    :goto_1
    return-object p0
.end method
