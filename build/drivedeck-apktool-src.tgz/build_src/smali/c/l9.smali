.class public final Lc/l9;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/app/Dialog;

.field public final b:Lc/k9;

.field public c:Landroid/animation/ObjectAnimator;

.field public d:Z

.field public e:Z

.field public final f:Landroid/os/Handler;

.field public g:Lc/i9;

.field public final h:Lc/h9;

.field public final i:Lc/h9;

.field public final j:Lc/h9;

.field public k:J

.field public l:Z

.field public m:Z

.field public n:Z

.field public final o:Lc/h9;

.field public p:I

.field public final q:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lc/l9;->f:Landroid/os/Handler;

    new-instance v0, Lc/h9;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/h9;-><init>(Lc/l9;I)V

    iput-object v0, p0, Lc/l9;->h:Lc/h9;

    new-instance v0, Lc/h9;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/h9;-><init>(Lc/l9;I)V

    iput-object v0, p0, Lc/l9;->i:Lc/h9;

    new-instance v0, Lc/h9;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lc/h9;-><init>(Lc/l9;I)V

    iput-object v0, p0, Lc/l9;->j:Lc/h9;

    new-instance v0, Lc/h9;

    const/4 v1, 0x3

    invoke-direct {v0, p0, v1}, Lc/h9;-><init>(Lc/l9;I)V

    iput-object v0, p0, Lc/l9;->o:Lc/h9;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/l9;->q:Ljava/util/ArrayList;

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, p1}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lc/l9;->a:Landroid/app/Dialog;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    new-instance v1, Lc/k9;

    invoke-direct {v1, p0, p1}, Lc/k9;-><init>(Lc/l9;Landroid/app/Activity;)V

    iput-object v1, p0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setCancelable(Z)V

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_1

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v3, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x2

    invoke-virtual {v0, v3}, Landroid/view/Window;->clearFlags(I)V

    const/16 v3, 0x38

    invoke-virtual {v0, v3}, Landroid/view/Window;->addFlags(I)V

    invoke-static {p1}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/16 p1, 0x7f6

    invoke-virtual {v0, p1}, Landroid/view/Window;->setType(I)V

    :cond_0
    const/16 p1, 0x50

    invoke-virtual {v0, p1}, Landroid/view/Window;->setGravity(I)V

    const p1, 0x7f050002

    invoke-virtual {v0, p1}, Landroid/view/Window;->setWindowAnimations(I)V

    const/high16 p1, 0x1000000

    invoke-virtual {v0, p1}, Landroid/view/Window;->addFlags(I)V

    iget p1, v1, Lc/k9;->d:F

    const/high16 v1, 0x43700000    # 240.0f

    mul-float/2addr p1, v1

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v1, -0x1

    invoke-virtual {v0, v1, p1}, Landroid/view/Window;->setLayout(II)V

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1, v2, v2, v2, v2}, Landroid/view/View;->setPadding(IIII)V

    invoke-virtual {v0, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    invoke-virtual {v0, v2}, Landroid/view/Window;->setStatusBarColor(I)V

    invoke-static {v0}, Lc/b4;->b(Landroid/view/Window;)V

    :cond_1
    return-void
.end method


# virtual methods
.method public final a()V
    .locals 4

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/l9;->n:Z

    iget-object v1, p0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v2, p0, Lc/l9;->o:Lc/h9;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lc/l9;->b:Lc/k9;

    iget-object v2, v1, Lc/k9;->j:Landroid/widget/LinearLayout;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    iget-object v2, v1, Lc/k9;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->removeAllViews()V

    iput v0, v1, Lc/k9;->l:I

    invoke-virtual {p0}, Lc/l9;->e()V

    return-void
.end method

.method public final b()V
    .locals 2

    invoke-virtual {p0}, Lc/l9;->a()V

    iget-object v0, p0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v1, p0, Lc/l9;->j:Lc/h9;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/l9;->k:J

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/l9;->l:Z

    iget-object v1, p0, Lc/l9;->q:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {p0}, Lc/l9;->h()V

    iput-boolean v0, p0, Lc/l9;->e:Z

    iget-object v0, p0, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    return-void
.end method

.method public final c()V
    .locals 6

    iget-boolean v0, p0, Lc/l9;->l:Z

    if-eqz v0, :cond_4

    iget-boolean v0, p0, Lc/l9;->n:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-wide v0, p0, Lc/l9;->k:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    sub-long/2addr v0, v2

    iget-object v2, p0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v3, p0, Lc/l9;->j:Lc/h9;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v4, 0x0

    cmp-long v4, v0, v4

    if-lez v4, :cond_1

    invoke-virtual {v2, v3, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_1
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/l9;->l:Z

    iget-object v0, p0, Lc/l9;->q:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-boolean v0, p0, Lc/l9;->e:Z

    if-eqz v0, :cond_2

    return-void

    :cond_2
    invoke-virtual {p0}, Lc/l9;->h()V

    iget-object v0, p0, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-nez v1, :cond_3

    return-void

    :cond_3
    const/4 v1, 0x1

    iput-boolean v1, p0, Lc/l9;->e:Z

    iput-boolean v1, p0, Lc/l9;->d:Z

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    iget-object v0, p0, Lc/l9;->i:Lc/h9;

    invoke-virtual {p0}, Lc/l9;->i()J

    move-result-wide v3

    invoke-virtual {v2, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    :goto_0
    return-void
.end method

.method public final d()V
    .locals 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/l9;->d:Z

    const/4 v1, 0x0

    iput-boolean v1, p0, Lc/l9;->m:Z

    iget v1, p0, Lc/l9;->p:I

    add-int/2addr v1, v0

    iput v1, p0, Lc/l9;->p:I

    new-instance v0, Lc/i9;

    invoke-direct {v0, p0, v1}, Lc/i9;-><init>(Lc/l9;I)V

    iput-object v0, p0, Lc/l9;->g:Lc/i9;

    iget-object v0, p0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iget-object v1, p0, Lc/l9;->g:Lc/i9;

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    iget-object v0, p0, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    return-void
.end method

.method public final e()V
    .locals 5

    iget-object v0, p0, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lc/l9;->b:Lc/k9;

    iget v2, v1, Lc/k9;->l:I

    const/16 v3, 0x10

    if-lez v2, :cond_1

    invoke-virtual {v0, v3}, Landroid/view/Window;->clearFlags(I)V

    goto :goto_0

    :cond_1
    invoke-virtual {v0, v3}, Landroid/view/Window;->addFlags(I)V

    :goto_0
    iget v2, v1, Lc/k9;->d:F

    const/high16 v3, 0x43700000    # 240.0f

    mul-float/2addr v2, v3

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    iget v3, v1, Lc/k9;->l:I

    add-int/2addr v2, v3

    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    const v4, 0x3f666666    # 0.9f

    mul-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, -0x1

    invoke-virtual {v0, v3, v2}, Landroid/view/Window;->setLayout(II)V

    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .locals 3

    iget-boolean v0, p0, Lc/l9;->n:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v1, p0, Lc/l9;->j:Lc/h9;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/l9;->k:J

    sget v0, Lc/k9;->n:I

    iget-object v0, p0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v0, Lc/k9;->k:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setSelected(Z)V

    invoke-virtual {v0, p1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-boolean p1, p0, Lc/l9;->l:Z

    if-eqz p1, :cond_1

    return-void

    :cond_1
    iput-boolean v2, p0, Lc/l9;->l:Z

    iget-boolean p1, p0, Lc/l9;->e:Z

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lc/l9;->d()V

    :cond_2
    return-void
.end method

.method public final g(Ljava/lang/String;[Ljava/lang/String;Ljava/util/function/IntConsumer;Ljava/lang/Runnable;J)V
    .locals 14

    move-object v0, p0

    move-object/from16 v1, p2

    invoke-virtual {p0}, Lc/l9;->a()V

    invoke-virtual {p0, p1}, Lc/l9;->f(Ljava/lang/String;)V

    const/4 v2, 0x1

    iput-boolean v2, v0, Lc/l9;->n:Z

    iget-object v3, v0, Lc/l9;->b:Lc/k9;

    iget-object v4, v3, Lc/k9;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v4}, Landroid/view/ViewGroup;->removeAllViews()V

    invoke-virtual {v3}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v4, v4

    iget v5, v3, Lc/k9;->d:F

    div-float/2addr v4, v5

    const v6, 0x3f666666    # 0.9f

    mul-float/2addr v4, v6

    const/high16 v6, 0x43940000    # 296.0f

    sub-float/2addr v4, v6

    const/high16 v6, 0x42700000    # 60.0f

    div-float/2addr v4, v6

    float-to-int v4, v4

    const/4 v6, 0x3

    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    array-length v6, v1

    invoke-static {v4, v6}, Ljava/lang/Math;->min(II)I

    move-result v4

    array-length v6, v1

    iget-object v7, v3, Lc/k9;->j:Landroid/widget/LinearLayout;

    const/16 v8, 0x8

    const/4 v9, 0x0

    if-lez v6, :cond_0

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v6

    new-instance v10, Landroid/widget/ListView;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v11

    invoke-direct {v10, v11}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    const-string v11, "voice-feedback-choices"

    invoke-virtual {v10, v11}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    invoke-virtual {v10, v9}, Landroid/widget/ListView;->setDividerHeight(I)V

    new-instance v11, Lc/F6;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v12

    invoke-direct {v11, p0, v12, v1, v6}, Lc/F6;-><init>(Lc/l9;Landroid/content/Context;[Ljava/lang/String;Lc/r4;)V

    invoke-virtual {v10, v11}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    new-instance v11, Lc/d2;

    const/4 v12, 0x1

    move-object/from16 v13, p3

    invoke-direct {v11, p0, v13, v12}, Lc/d2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v11}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    mul-int/lit8 v12, v4, 0x34

    array-length v13, v1

    sub-int/2addr v13, v2

    invoke-static {v4, v13}, Ljava/lang/Math;->min(II)I

    move-result v13

    mul-int/2addr v13, v8

    add-int/2addr v13, v12

    int-to-float v12, v13

    mul-float/2addr v12, v5

    invoke-static {v12}, Ljava/lang/Math;->round(F)I

    move-result v12

    const/4 v13, -0x1

    invoke-direct {v11, v13, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v10

    invoke-static {v10}, Lc/G8;->u(Landroid/content/Context;)Landroid/widget/Button;

    move-result-object v10

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v11

    const-string v12, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v11, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v10, v6, v9}, Lc/G8;->h(Landroid/widget/TextView;Lc/r4;Z)V

    new-instance v6, Lc/w2;

    const/4 v11, 0x4

    move-object/from16 v12, p4

    invoke-direct {v6, p0, v12, v11}, Lc/w2;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v10, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-string v6, "voice-feedback-cancel"

    invoke-virtual {v10, v6}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x42400000    # 48.0f

    mul-float/2addr v11, v5

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    invoke-direct {v6, v13, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v11, 0x41000000    # 8.0f

    mul-float/2addr v11, v5

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    iput v11, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    invoke-virtual {v7, v10, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_0
    array-length v6, v1

    if-nez v6, :cond_1

    move v2, v9

    goto :goto_0

    :cond_1
    mul-int/lit8 v6, v4, 0x34

    array-length v10, v1

    sub-int/2addr v10, v2

    invoke-static {v4, v10}, Ljava/lang/Math;->min(II)I

    move-result v2

    mul-int/2addr v2, v8

    add-int/2addr v2, v6

    add-int/lit8 v2, v2, 0x38

    int-to-float v2, v2

    mul-float/2addr v2, v5

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    :goto_0
    iput v2, v3, Lc/k9;->l:I

    array-length v1, v1

    if-nez v1, :cond_2

    goto :goto_1

    :cond_2
    move v8, v9

    :goto_1
    invoke-virtual {v7, v8}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0}, Lc/l9;->e()V

    iget-object v1, v0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v2, v0, Lc/l9;->o:Lc/h9;

    move-wide/from16 v3, p5

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final h()V
    .locals 3

    iget v0, p0, Lc/l9;->p:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lc/l9;->p:I

    iget-object v0, p0, Lc/l9;->g:Lc/i9;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    iget-object v2, p0, Lc/l9;->g:Lc/i9;

    invoke-virtual {v0, v2}, Landroid/view/ViewTreeObserver;->removeOnDrawListener(Landroid/view/ViewTreeObserver$OnDrawListener;)V

    iput-object v1, p0, Lc/l9;->g:Lc/i9;

    :goto_0
    iget-object v0, p0, Lc/l9;->f:Landroid/os/Handler;

    iget-object v2, p0, Lc/l9;->h:Lc/h9;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/l9;->i:Lc/h9;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/l9;->d:Z

    iget-object v0, p0, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    iput-object v1, p0, Lc/l9;->c:Landroid/animation/ObjectAnimator;

    :cond_1
    return-void
.end method

.method public final i()J
    .locals 4

    iget-object v0, p0, Lc/l9;->b:Lc/k9;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "window_animation_scale"

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v0, v1, v2}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    move-result v0

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/high16 v1, 0x43960000    # 300.0f

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    int-to-long v0, v0

    const-wide/16 v2, 0x20

    add-long/2addr v0, v2

    return-wide v0
.end method
