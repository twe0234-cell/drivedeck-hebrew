.class public final synthetic Lc/G4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:Z

.field public final synthetic c:Z

.field public final synthetic d:Z


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;ZZZ)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/G4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-boolean p2, p0, Lc/G4;->b:Z

    iput-boolean p3, p0, Lc/G4;->c:Z

    iput-boolean p4, p0, Lc/G4;->d:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    const/4 v0, 0x1

    sget v1, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v1, p0, Lc/G4;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_10

    invoke-virtual {v1}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-eqz v2, :cond_0

    goto/16 :goto_8

    :cond_0
    const/4 v2, 0x0

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->p0:Z

    iget-boolean v3, p0, Lc/G4;->b:Z

    if-eqz v3, :cond_1

    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->i0()V

    goto/16 :goto_7

    :cond_1
    iget-boolean v3, p0, Lc/G4;->c:Z

    if-nez v3, :cond_f

    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v3

    invoke-static {v3}, Lc/k6;->N(Landroid/content/Intent;)Z

    move-result v3

    if-nez v3, :cond_f

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v3, :cond_2

    iget-boolean v3, v3, Lc/g9;->n:Z

    if-nez v3, :cond_f

    :cond_2
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v3, :cond_3

    invoke-virtual {v3}, Landroid/app/Dialog;->isShowing()Z

    move-result v3

    if-nez v3, :cond_f

    :cond_3
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v3, :cond_4

    invoke-virtual {v3}, Landroid/app/Dialog;->isShowing()Z

    move-result v3

    if-eqz v3, :cond_4

    goto/16 :goto_6

    :cond_4
    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->K()Ljava/lang/String;

    move-result-object v3

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v4, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    const-string v5, "startup_screen"

    invoke-interface {v4, v5}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4, v2}, Lc/n1;->J(I)Ljava/lang/String;

    move-result-object v4

    goto :goto_0

    :cond_5
    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    :goto_0
    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v6, v6, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    invoke-interface {v6, v5}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_6

    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v6, v0}, Lc/n1;->J(I)Ljava/lang/String;

    move-result-object v6

    :goto_1
    move-object v13, v6

    goto :goto_2

    :cond_6
    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v6, v0}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :goto_2
    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v7, "startup_single_from_home"

    iget-object v6, v6, Lc/n1;->b:Ljava/lang/Object;

    check-cast v6, Landroid/content/SharedPreferences;

    invoke-interface {v6, v7, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v6

    iget-object v7, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v7, v7, Lc/n1;->b:Ljava/lang/Object;

    check-cast v7, Landroid/content/SharedPreferences;

    invoke-interface {v7, v5}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v5

    const-string v14, "split"

    if-nez v5, :cond_7

    invoke-virtual {v14, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_7

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_e

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_e

    :cond_7
    invoke-virtual {v1, v4}, Lru/drivedeck/launcher/MainActivity;->f(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_e

    invoke-virtual {v1, v13}, Lru/drivedeck/launcher/MainActivity;->f(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_8

    goto/16 :goto_5

    :cond_8
    iget-boolean v5, p0, Lc/G4;->d:Z

    if-nez v5, :cond_a

    invoke-static {}, Lc/j8;->u()Z

    move-result v5

    if-eqz v5, :cond_9

    goto :goto_3

    :cond_9
    move v5, v2

    goto :goto_4

    :cond_a
    :goto_3
    move v5, v0

    :goto_4
    const-string v7, "single"

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_b

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_b

    iget-object v8, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v8}, Lc/n1;->o0()Z

    move-result v8

    if-eqz v8, :cond_b

    if-eqz v5, :cond_b

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->n0:Z

    iput-boolean v6, v1, Lru/drivedeck/launcher/MainActivity;->s0:Z

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->o()V

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v1, v2}, Lru/drivedeck/launcher/MainActivity;->t(Landroid/view/View;)V

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v2, v4}, Lc/m2;->K(Ljava/lang/String;)V

    filled-new-array {v4}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v7, v2}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->v()V

    goto/16 :goto_7

    :cond_b
    invoke-virtual {v14, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_c

    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v6}, Lc/n1;->o0()Z

    move-result v6

    if-eqz v6, :cond_c

    if-eqz v5, :cond_c

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->r0:Z

    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->n0:Z

    iput-boolean v2, v1, Lru/drivedeck/launcher/MainActivity;->s0:Z

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->o()V

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v1, v2}, Lru/drivedeck/launcher/MainActivity;->t(Landroid/view/View;)V

    iget-object v6, v1, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->I()F

    move-result v9

    invoke-virtual {v6}, Lc/F;->f()Z

    const/4 v10, -0x1

    const-wide/16 v11, 0x0

    move-object v7, v4

    move-object v8, v13

    invoke-virtual/range {v6 .. v12}, Lc/m2;->J(Ljava/lang/String;Ljava/lang/String;FIJ)V

    filled-new-array {v4, v13}, [Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v14, v2}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->v()V

    goto :goto_7

    :cond_c
    invoke-virtual {v14, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_d

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->o0()Z

    move-result v2

    if-eqz v2, :cond_d

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_d

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_d

    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    new-instance v3, Lc/I4;

    invoke-direct {v3, v1, v0}, Lc/I4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v4, 0xb4

    invoke-virtual {v2, v3, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_7

    :cond_d
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->h0()V

    goto :goto_7

    :cond_e
    :goto_5
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->m0()V

    goto :goto_7

    :cond_f
    :goto_6
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->h0()V

    :goto_7
    iput-boolean v0, v1, Lru/drivedeck/launcher/MainActivity;->A0:Z

    sget v0, Lc/G8;->B:I

    iput v0, v1, Lru/drivedeck/launcher/MainActivity;->B0:I

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const-wide/16 v4, 0x2ee0

    add-long/2addr v2, v4

    iput-wide v2, v1, Lru/drivedeck/launcher/MainActivity;->y0:J

    const-wide/16 v2, 0x0

    iput-wide v2, v1, Lru/drivedeck/launcher/MainActivity;->z0:J

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v1, v1, Lru/drivedeck/launcher/MainActivity;->C0:Lc/J1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-wide/16 v2, 0xfa

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_10
    :goto_8
    return-void
.end method
