.class public final synthetic Lc/c2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# instance fields
.field public final synthetic a:[F

.field public final synthetic b:[Z

.field public final synthetic c:I

.field public final synthetic d:Landroid/widget/GridView;

.field public final synthetic e:Lc/i2;


# direct methods
.method public synthetic constructor <init>([F[ZILandroid/widget/GridView;Lc/i2;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/c2;->a:[F

    iput-object p2, p0, Lc/c2;->b:[Z

    iput p3, p0, Lc/c2;->c:I

    iput-object p4, p0, Lc/c2;->d:Landroid/widget/GridView;

    iput-object p5, p0, Lc/c2;->e:Lc/i2;

    return-void
.end method


# virtual methods
.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 6

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    iget-object v0, p0, Lc/c2;->a:[F

    iget-object v1, p0, Lc/c2;->b:[Z

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez p1, :cond_1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    aput p1, v0, v3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p1

    aput p1, v0, v2

    aput-boolean v3, v1, v3

    :cond_0
    move v2, v3

    goto :goto_0

    :cond_1
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    aget v4, v0, v3

    sub-float/2addr p1, v4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    aget v5, v0, v2

    sub-float/2addr v4, v5

    mul-float/2addr p1, p1

    mul-float/2addr v4, v4

    add-float/2addr v4, p1

    iget p1, p0, Lc/c2;->c:I

    mul-int/2addr p1, p1

    int-to-float p1, p1

    cmpl-float p1, v4, p1

    if-lez p1, :cond_2

    aput-boolean v2, v1, v3

    :cond_2
    invoke-virtual {p2}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result p1

    if-ne p1, v2, :cond_0

    aget-boolean p1, v1, v3

    if-nez p1, :cond_0

    aget p1, v0, v3

    float-to-int p1, p1

    aget v0, v0, v2

    float-to-int v0, v0

    iget-object v1, p0, Lc/c2;->d:Landroid/widget/GridView;

    invoke-virtual {v1, p1, v0}, Landroid/widget/AbsListView;->pointToPosition(II)I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getX()F

    move-result p1

    float-to-int p1, p1

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getY()F

    move-result p2

    float-to-int p2, p2

    invoke-virtual {v1, p1, p2}, Landroid/widget/AbsListView;->pointToPosition(II)I

    move-result p1

    if-ne p1, v0, :cond_0

    iget-object p1, p0, Lc/c2;->e:Lc/i2;

    invoke-virtual {p1}, Lc/i2;->run()V

    :goto_0
    return v2
.end method
