.class public final synthetic Lc/H;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p3, p0, Lc/H;->a:I

    iput-object p1, p0, Lc/H;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/H;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 15

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v4, p0, Lc/H;->a:I

    packed-switch v4, :pswitch_data_0

    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/O7;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/E3;

    const/4 v2, 0x3

    invoke-direct {v1, v0, v2}, Lc/E3;-><init>(Ljava/lang/Object;I)V

    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Lc/Z7;

    invoke-virtual {v0, v1}, Lc/Z7;->j(Ljava/util/function/Consumer;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/B0;

    iget-object v0, v0, Lc/B0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    const-string v2, "PID \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b \u0432 \u0444\u0430\u0439\u043b"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    new-instance v4, Lc/v6;

    invoke-direct {v4, v0, v2, v1, v3}, Lc/v6;-><init>(Lc/H6;Ljava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {v0, v4}, Lc/H6;->C(Ljava/lang/Runnable;)V

    return-void

    :pswitch_2
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    iget-object v1, v0, Lc/H6;->l0:Landroid/widget/Spinner;

    invoke-virtual {v1}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v1

    iget-object v2, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v2, [I

    aget v1, v2, v1

    iget-object v0, v0, Lc/H6;->c:Lc/T5;

    iget-object v2, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const v3, 0x9600

    const-string v4, "usb_baud"

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    if-eq v1, v2, :cond_0

    invoke-virtual {v0}, Lc/T5;->E()V

    iget-object v0, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v4, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    return-void

    :pswitch_3
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/H6;

    iget-object v4, v0, Lc/H6;->c:Lc/T5;

    iget-object v5, v4, Lc/T5;->g:Lc/j6;

    if-nez v5, :cond_1

    goto/16 :goto_3

    :cond_1
    new-instance v6, Ljava/util/ArrayList;

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    iget-object v7, v4, Lc/T5;->g:Lc/j6;

    iget-object v7, v7, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v7}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_2
    :goto_0
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/i6;

    iget-boolean v9, v8, Lc/i6;->v:Z

    if-eqz v9, :cond_2

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_4

    goto/16 :goto_3

    :cond_4
    const-string v7, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438"

    iget-object v8, v0, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v8, v7}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v9

    add-int/2addr v9, v2

    new-array v9, v9, [Ljava/lang/String;

    aput-object v7, v9, v3

    iget-object v7, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v7, Lc/F0;

    iget v10, v7, Lc/F0;->d:I

    invoke-virtual {v4, v10}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v4

    :goto_1
    move v10, v3

    :cond_5
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v3, v11, :cond_7

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/i6;

    add-int/2addr v3, v2

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v13, v0, Lc/H6;->w:Lc/n1;

    invoke-virtual {v13}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v13}, Lc/i6;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v13, v11, Lc/i6;->e:Ljava/lang/String;

    invoke-virtual {v13}, Ljava/lang/String;->isEmpty()Z

    move-result v14

    if-eqz v14, :cond_6

    const-string v13, ""

    goto :goto_2

    :cond_6
    const-string v14, " \u00b7 "

    invoke-virtual {v14, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    :goto_2
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    aput-object v12, v9, v3

    if-eqz v4, :cond_5

    iget-object v12, v4, Lc/i6;->a:Ljava/lang/String;

    iget-object v11, v11, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_5

    goto :goto_1

    :cond_7
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, v8}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    iget-object v3, v7, Lc/F0;->a:Ljava/lang/String;

    invoke-static {v8, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    new-instance v3, Lc/z6;

    invoke-direct {v3, v0, v5, v7, v6}, Lc/z6;-><init>(Lc/H6;Lc/j6;Lc/F0;Ljava/util/ArrayList;)V

    invoke-virtual {v2, v9, v10, v3}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "\u041e\u0442\u043c\u0435\u043d\u0430"

    invoke-static {v8, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    :goto_3
    return-void

    :pswitch_4
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Landroid/bluetooth/le/ScanResult;

    iget-object v2, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v2, Lc/I5;

    iget-object v2, v2, Lc/I5;->a:Lc/T5;

    :try_start_0
    iget-boolean v3, v2, Lc/T5;->G1:Z

    if-nez v3, :cond_8

    goto :goto_5

    :cond_8
    invoke-virtual {v0}, Landroid/bluetooth/le/ScanResult;->getDevice()Landroid/bluetooth/BluetoothDevice;

    move-result-object v3

    invoke-virtual {v0}, Landroid/bluetooth/le/ScanResult;->getScanRecord()Landroid/bluetooth/le/ScanRecord;

    move-result-object v4

    if-nez v4, :cond_9

    goto :goto_4

    :cond_9
    invoke-virtual {v0}, Landroid/bluetooth/le/ScanResult;->getScanRecord()Landroid/bluetooth/le/ScanRecord;

    move-result-object v0

    invoke-virtual {v0}, Landroid/bluetooth/le/ScanRecord;->getDeviceName()Ljava/lang/String;

    move-result-object v1

    :goto_4
    if-nez v1, :cond_a

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothDevice;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_a
    if-eqz v1, :cond_b

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_b

    iget-object v0, v2, Lc/T5;->A1:Ljava/util/LinkedHashMap;

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2}, Lc/T5;->q()V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_b
    :goto_5
    return-void

    :pswitch_5
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/a5;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Lc/a;

    invoke-static {v1}, Lc/G8;->k0(Lc/a;)Z

    move-result v4

    if-nez v4, :cond_d

    iget-object v4, v0, Lc/a5;->b:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->D()Ljava/lang/String;

    move-result-object v4

    iget-object v5, v1, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_c

    goto :goto_6

    :cond_c
    move v2, v3

    :cond_d
    :goto_6
    iget-object v0, v0, Lc/a5;->c:Lc/M3;

    invoke-virtual {v0, v1, v2}, Lc/M3;->a(Lc/a;Z)V

    return-void

    :pswitch_6
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/y;

    iget-object v0, v0, Lc/y;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iget-object v4, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v4, [Landroid/app/Dialog;

    aget-object v4, v4, v3

    if-ne v2, v4, :cond_e

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    iput-boolean v3, v0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    :cond_e
    return-void

    :pswitch_7
    sget v0, Lru/drivedeck/launcher/MainActivity;->F0:I

    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_18

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_f

    goto/16 :goto_b

    :cond_f
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v0, v0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v0}, Lc/z;->c()Ljava/util/List;

    move-result-object v0

    invoke-virtual {v1, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_17

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_10

    goto/16 :goto_a

    :cond_10
    const-string v12, "com.android.calendar"

    const-string v13, "com.android.deskclock"

    const-string v5, "com.google.android.apps.maps"

    const-string v6, "ru.yandex.yandexmaps"

    const-string v7, "ru.yandex.yandexnavi"

    const-string v8, "com.spotify.music"

    const-string v9, "ru.yandex.music"

    const-string v10, "com.android.gallery3d"

    const-string v11, "com.android.messaging"

    filled-new-array/range {v5 .. v13}, [Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    move v6, v3

    :goto_7
    const/16 v7, 0x9

    if-ge v6, v7, :cond_13

    aget-object v7, v4, v6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_11
    :goto_8
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_12

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/a;

    iget-object v9, v9, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v7, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_11

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8

    :cond_12
    add-int/2addr v6, v2

    goto :goto_7

    :cond_13
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_14
    :goto_9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_15

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/a;

    iget-object v6, v4, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_14

    iget-object v4, v4, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_9

    :cond_15
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0, v3}, Lc/n1;->P0(Ljava/lang/String;I)V

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-le v0, v2, :cond_16

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Lc/n1;->P0(Ljava/lang/String;I)V

    :cond_16
    iget-object v0, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v2, "dock"

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_17

    const/4 v0, 0x5

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    invoke-virtual {v5, v3, v0}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v1, v0}, Lc/n1;->D0(Ljava/util/List;)V

    :cond_17
    :goto_a
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Lc/G4;

    invoke-virtual {v0}, Lc/G4;->run()V

    :cond_18
    :goto_b
    return-void

    :pswitch_8
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Lc/f9;

    iget-object v1, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    iget-object v3, v1, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    iput-boolean v2, v3, Lc/g9;->o:Z

    const-wide/16 v2, 0x7d0

    :try_start_1
    invoke-virtual {v0}, Lc/f9;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->r0()Z

    move-result v0

    if-eqz v0, :cond_19

    iget-object v0, v1, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v0, :cond_19

    iget-boolean v4, v0, Lc/l9;->l:Z

    if-eqz v4, :cond_19

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    add-long/2addr v4, v2

    iput-wide v4, v0, Lc/l9;->k:J

    :cond_19
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->V()V

    return-void

    :catchall_0
    move-exception v0

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4}, Lc/n1;->r0()Z

    move-result v4

    if-eqz v4, :cond_1a

    iget-object v4, v1, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v4, :cond_1a

    iget-boolean v5, v4, Lc/l9;->l:Z

    if-eqz v5, :cond_1a

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    add-long/2addr v5, v2

    iput-wide v5, v4, Lc/l9;->k:J

    :cond_1a
    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->V()V

    throw v0

    :pswitch_9
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/s4;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/RectF;

    invoke-static {v0, v1}, Lc/t8;->l(Landroid/view/View;Landroid/graphics/RectF;)V

    return-void

    :pswitch_a
    sget-object v0, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v4

    if-nez v4, :cond_1c

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v4

    if-eqz v4, :cond_1b

    goto :goto_c

    :cond_1b
    iget-object v4, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    invoke-static {v0, v4}, Lc/q4;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    new-instance v5, Landroid/app/Dialog;

    invoke-direct {v5, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v0, v1}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-virtual {v1, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const-string v4, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    invoke-static {v0, v5, v4}, Lc/q4;->g(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v4

    new-array v2, v2, [Landroid/view/View;

    aput-object v4, v2, v3

    const-string v3, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b"

    invoke-static {v5, v0, v3, v1, v2}, Lc/q4;->q(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;[Landroid/view/View;)V

    :cond_1c
    :goto_c
    return-void

    :pswitch_b
    sget-object v0, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_1f

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_1d

    goto :goto_e

    :cond_1d
    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Lorg/json/JSONObject;

    const-string v2, "name"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0}, Lc/q4;->s(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1e

    const-string v3, "\u0417\u0430\u043c\u0435\u043d\u0438\u0442\u044c \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443?"

    goto :goto_d

    :cond_1e
    const-string v3, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u043f\u043e\u043d\u043e\u0432\u043a\u0443?"

    :goto_d
    new-instance v4, Lc/Z;

    const/4 v5, 0x7

    invoke-direct {v4, v0, v2, v1, v5}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v1, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c"

    invoke-static {v0, v3, v2, v1, v4}, Lc/q4;->i(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;)V

    :cond_1f
    :goto_e
    return-void

    :pswitch_c
    sget-object v0, Lc/G8;->C:Ljava/lang/String;

    iget-object v2, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    sput-object v1, Lc/G8;->C:Ljava/lang/String;

    :cond_20
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, [Landroid/media/browse/MediaBrowser;

    aget-object v0, v0, v3

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->disconnect()V

    return-void

    :pswitch_d
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/d4;

    invoke-virtual {v0}, Lc/d4;->getAsBoolean()Z

    move-result v0

    if-eqz v0, :cond_21

    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_21
    return-void

    :pswitch_e
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/DriveDeckApplication;

    const-string v2, "acknowledged_build"

    :try_start_2
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    const-string v5, "android_id"

    invoke-static {v4, v5}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/G8;->w(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    iget-object v5, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v5, Ljava/util/concurrent/ScheduledExecutorService;

    if-nez v4, :cond_22

    :try_start_3
    invoke-interface {v5}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    goto :goto_10

    :catch_1
    move-exception v0

    goto :goto_f

    :cond_22
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v6

    iget-object v6, v6, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    invoke-static {v6}, Lc/G8;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "drivedeck_install_analytics"

    invoke-virtual {v0, v7, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-virtual {v4, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_23

    invoke-interface {v5}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    goto :goto_10

    :cond_23
    invoke-static {v4, v6}, Lc/G8;->n0(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-virtual {v4, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-interface {v5}, Ljava/util/concurrent/ExecutorService;->shutdown()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    goto :goto_10

    :goto_f
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Registration deferred: "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DriveDeckInstall"

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_24
    :goto_10
    return-void

    :pswitch_f
    iget-object v4, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v4, Lc/P3;

    iget-object v5, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_2a

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "/"

    invoke-virtual {v5, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_25

    goto :goto_15

    :cond_25
    new-instance v6, Landroid/media/MediaMetadataRetriever;

    invoke-direct {v6}, Landroid/media/MediaMetadataRetriever;-><init>()V

    :try_start_4
    invoke-virtual {v6, v5}, Landroid/media/MediaMetadataRetriever;->setDataSource(Ljava/lang/String;)V

    invoke-virtual {v6}, Landroid/media/MediaMetadataRetriever;->getEmbeddedPicture()[B

    move-result-object v7

    if-eqz v7, :cond_28

    array-length v8, v7

    if-eqz v8, :cond_28

    array-length v8, v7

    const/high16 v9, 0x800000

    if-le v8, v9, :cond_26

    goto :goto_12

    :cond_26
    new-instance v8, Landroid/graphics/BitmapFactory$Options;

    invoke-direct {v8}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    iput-boolean v2, v8, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v9, v7

    invoke-static {v7, v3, v9, v8}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    iput v2, v8, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    :goto_11
    iget v9, v8, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    iget v10, v8, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    div-int/2addr v9, v10

    const/16 v11, 0x400

    if-gt v9, v11, :cond_29

    iget v9, v8, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    div-int/2addr v9, v10

    if-le v9, v11, :cond_27

    goto :goto_13

    :cond_27
    iput-boolean v3, v8, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    array-length v0, v7

    invoke-static {v7, v3, v0, v8}, Landroid/graphics/BitmapFactory;->decodeByteArray([BIILandroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v1
    :try_end_4
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catch_2
    :cond_28
    :goto_12
    :try_start_5
    invoke-virtual {v6}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_4

    goto :goto_15

    :catchall_1
    move-exception v0

    goto :goto_14

    :cond_29
    :goto_13
    mul-int/2addr v10, v0

    :try_start_6
    iput v10, v8, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I
    :try_end_6
    .catch Ljava/lang/RuntimeException; {:try_start_6 .. :try_end_6} :catch_2
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    goto :goto_11

    :goto_14
    :try_start_7
    invoke-virtual {v6}, Landroid/media/MediaMetadataRetriever;->release()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_3
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_3

    :catch_3
    throw v0

    :catch_4
    :cond_2a
    :goto_15
    iget-object v0, v4, Lc/P3;->W0:Landroid/os/Handler;

    new-instance v3, Lc/G3;

    invoke-direct {v3, v4, v5, v1, v2}, Lc/G3;-><init>(Lc/P3;Ljava/lang/String;Landroid/graphics/Bitmap;I)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :pswitch_10
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    iput-boolean v3, v0, Lc/k3;->J:Z

    iget-object v1, v0, Lc/k3;->i:Landroid/widget/LinearLayout;

    iget-object v2, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v2, Landroid/widget/LinearLayout;

    if-ne v1, v2, :cond_2c

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v1

    if-lez v1, :cond_2c

    invoke-virtual {v2}, Landroid/view/View;->getHeight()I

    move-result v1

    const/high16 v3, 0x43480000    # 200.0f

    invoke-virtual {v0, v3}, Lc/k3;->x(F)I

    move-result v3

    if-lt v1, v3, :cond_2c

    invoke-virtual {v2}, Landroid/view/View;->hasWindowFocus()Z

    move-result v1

    if-eqz v1, :cond_2c

    invoke-static {v2}, Lc/b4;->c(Landroid/view/View;)Z

    move-result v1

    if-nez v1, :cond_2c

    invoke-virtual {v0}, Landroid/app/Dialog;->getCurrentFocus()Landroid/view/View;

    move-result-object v1

    if-eqz v1, :cond_2b

    invoke-virtual {v1}, Landroid/view/View;->onCheckIsTextEditor()Z

    move-result v1

    if-eqz v1, :cond_2b

    goto :goto_16

    :cond_2b
    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v1

    iput v1, v0, Lc/k3;->H:I

    invoke-virtual {v0}, Lc/k3;->s()I

    move-result v1

    iput v1, v0, Lc/k3;->I:I

    invoke-virtual {v0}, Lc/k3;->X()V

    :cond_2c
    :goto_16
    return-void

    :pswitch_11
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Landroid/widget/ScrollView;

    invoke-virtual {v0, v2}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-eqz v0, :cond_2d

    goto :goto_17

    :cond_2d
    const/16 v3, 0x8

    :goto_17
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    return-void

    :pswitch_12
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setEnabled(Z)V

    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return-void

    :pswitch_13
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/16 v2, 0x4b

    const-string v4, "dimmer_percent"

    invoke-static {v2, v3, v3, v1, v4}, Lc/t;->c(IIILandroid/content/SharedPreferences$Editor;Ljava/lang/String;)V

    iget-object v0, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/R1;->b(Landroid/content/Context;)V

    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Landroid/widget/SeekBar;

    invoke-virtual {v0, v3}, Landroid/widget/ProgressBar;->setProgress(I)V

    return-void

    :pswitch_14
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Lc/Y3;

    iget-object v1, v1, Lc/Y3;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/k3;->e(Ljava/lang/String;)V

    return-void

    :pswitch_15
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, [Z

    aget-boolean v1, v0, v3

    if-eqz v1, :cond_2e

    goto :goto_18

    :cond_2e
    aput-boolean v2, v0, v3

    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Runnable;

    if-eqz v0, :cond_2f

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_2f
    :goto_18
    return-void

    :pswitch_16
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Landroid/graphics/RectF;

    invoke-static {v0, v1}, Lc/t8;->l(Landroid/view/View;Landroid/graphics/RectF;)V

    return-void

    :pswitch_17
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lc/N1;

    invoke-virtual {v0}, Lc/N1;->u()Z

    move-result v1

    if-eqz v1, :cond_30

    invoke-virtual {v0}, Lc/N1;->w()V

    invoke-virtual {v0, v3}, Lc/N1;->l(Z)V

    :cond_30
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Lc/u2;

    invoke-static {v0}, Lc/N1;->g(Ljava/lang/Runnable;)V

    return-void

    :pswitch_18
    sget v0, Lru/drivedeck/launcher/DiagnosticExportProvider;->a:I

    new-instance v0, Landroid/net/Uri$Builder;

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    const-string v1, "content"

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ".diagnostic-exports"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    new-instance v1, Landroid/content/Intent;

    const-string v4, "android.intent.action.SEND"

    invoke-direct {v1, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v4, "application/zip"

    invoke-virtual {v1, v4}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v4, "android.intent.extra.STREAM"

    invoke-virtual {v1, v4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    const-string v4, "DriveDeck diagnostics"

    invoke-static {v4, v0}, Landroid/content/ClipData;->newRawUri(Ljava/lang/CharSequence;Landroid/net/Uri;)Landroid/content/ClipData;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    :try_start_8
    const-string v0, "\u041e\u0442\u043f\u0440\u0430\u0432\u0438\u0442\u044c \u043b\u043e\u0433\u0438 DriveDeck"

    invoke-static {v1, v0}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_8
    .catch Landroid/content/ActivityNotFoundException; {:try_start_8 .. :try_end_8} :catch_5

    goto :goto_19

    :catch_5
    const-string v0, "\u041d\u0435\u0442 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0434\u043b\u044f \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438 \u0444\u0430\u0439\u043b\u0430"

    invoke-static {v3, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_19
    return-void

    :pswitch_19
    iget-object v1, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v1, Lc/N1;

    iget-object v4, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v4, Landroid/app/Activity;

    :try_start_9
    invoke-virtual {v1}, Lc/N1;->u()Z

    move-result v5

    if-eqz v5, :cond_31

    invoke-virtual {v1}, Lc/N1;->w()V

    invoke-virtual {v1, v3}, Lc/N1;->l(Z)V

    :cond_31
    iget-object v5, v1, Lc/N1;->I:Lc/y1;

    monitor-enter v5
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_6

    :try_start_a
    iget-object v6, v1, Lc/N1;->I:Lc/y1;

    invoke-virtual {v6}, Lc/y1;->a()[Ljava/io/File;

    move-result-object v6

    array-length v6, v6

    if-nez v6, :cond_32

    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    new-instance v1, Lc/L1;

    invoke-direct {v1, v4, v3}, Lc/L1;-><init>(Landroid/app/Activity;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    monitor-exit v5

    goto/16 :goto_1d

    :catchall_2
    move-exception v0

    goto :goto_1c

    :cond_32
    new-instance v6, Ljava/io/File;

    iget-object v7, v1, Lc/N1;->a:Lru/drivedeck/launcher/DriveDeckApplication;

    invoke-virtual {v7}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v7

    const-string v8, "diagnostic-share"

    invoke-direct {v6, v7, v8}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/io/File;->isDirectory()Z

    move-result v7

    if-nez v7, :cond_34

    invoke-virtual {v6}, Ljava/io/File;->mkdirs()Z

    move-result v7

    if-eqz v7, :cond_33

    goto :goto_1a

    :cond_33
    new-instance v0, Ljava/io/IOException;

    const-string v1, "Export unavailable"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_34
    :goto_1a
    new-instance v7, Lc/x1;

    invoke-direct {v7, v0}, Lc/x1;-><init>(I)V

    invoke-virtual {v6, v7}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_35

    array-length v7, v0

    :goto_1b
    if-ge v3, v7, :cond_35

    aget-object v8, v0, v3

    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    add-int/2addr v3, v2

    goto :goto_1b

    :cond_35
    new-instance v0, Ljava/io/File;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "DriveDeck-diagnostics-"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    invoke-virtual {v3, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v7, ".zip"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v6, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    new-instance v3, Ljava/io/FileOutputStream;

    invoke-direct {v3, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    iget-object v1, v1, Lc/N1;->I:Lc/y1;

    invoke-static {v3, v1}, Lc/N1;->G(Ljava/io/OutputStream;Lc/y1;)V

    monitor-exit v5
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_2

    :try_start_b
    sget-object v1, Lc/N1;->W:Landroid/os/Handler;

    new-instance v3, Lc/H;

    const/4 v5, 0x4

    invoke-direct {v3, v4, v0, v5}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_6

    goto :goto_1d

    :goto_1c
    :try_start_c
    monitor-exit v5
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_2

    :try_start_d
    throw v0
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_6

    :catch_6
    sget-object v0, Lc/N1;->W:Landroid/os/Handler;

    new-instance v1, Lc/L1;

    invoke-direct {v1, v4, v2}, Lc/L1;-><init>(Landroid/app/Activity;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_1d
    return-void

    :pswitch_1a
    iget-object v0, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v0, Lru/drivedeck/launcher/DiagnosticUploadJob;

    iget-object v2, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v2, Landroid/app/job/JobParameters;

    iget-object v4, v0, Lru/drivedeck/launcher/DiagnosticUploadJob;->a:Landroid/app/job/JobParameters;

    if-ne v4, v2, :cond_36

    iput-object v1, v0, Lru/drivedeck/launcher/DiagnosticUploadJob;->a:Landroid/app/job/JobParameters;

    invoke-virtual {v0, v2, v3}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    :cond_36
    return-void

    :pswitch_1b
    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v0

    if-eqz v0, :cond_37

    const-string v0, "\u0414\u043e\u0441\u0442\u0443\u043f \u043f\u0440\u0435\u0434\u043e\u0441\u0442\u0430\u0432\u043b\u0435\u043d"

    goto :goto_1e

    :cond_37
    const-string v0, "\u041d\u0443\u0436\u0435\u043d \u0434\u043e\u0441\u0442\u0443\u043f"

    :goto_1e
    iget-object v1, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v1, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_1c
    iget-object v0, p0, Lc/H;->c:Ljava/lang/Object;

    check-cast v0, Landroid/content/Intent;

    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v0

    iget-object v1, p0, Lc/H;->b:Ljava/lang/Object;

    check-cast v1, Lc/I;

    invoke-virtual {v1, v0}, Lc/I;->onServiceDisconnected(Landroid/content/ComponentName;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
