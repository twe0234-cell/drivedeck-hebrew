.class public final Lc/m3;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final b:Landroid/graphics/Paint;

.field public final c:Landroid/graphics/Paint;

.field public final d:Landroid/graphics/RectF;

.field public final e:Landroid/graphics/RectF;

.field public final f:Landroid/graphics/RectF;

.field public final g:[I

.field public final h:[I

.field public final synthetic i:Lc/n3;


# direct methods
.method public constructor <init>(Lc/n3;Landroid/content/Context;)V
    .locals 5

    iput-object p1, p0, Lc/m3;->i:Lc/n3;

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p2, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p2, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p2, p0, Lc/m3;->a:Landroid/graphics/Paint;

    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v1, p0, Lc/m3;->b:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/Paint;

    invoke-direct {v2, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v2, p0, Lc/m3;->c:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    iput-object v3, p0, Lc/m3;->d:Landroid/graphics/RectF;

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    iput-object v3, p0, Lc/m3;->e:Landroid/graphics/RectF;

    new-instance v3, Landroid/graphics/RectF;

    invoke-direct {v3}, Landroid/graphics/RectF;-><init>()V

    iput-object v3, p0, Lc/m3;->f:Landroid/graphics/RectF;

    const/4 v3, 0x2

    new-array v4, v3, [I

    iput-object v4, p0, Lc/m3;->g:[I

    new-array v4, v3, [I

    iput-object v4, p0, Lc/m3;->h:[I

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v4}, Landroid/view/View;->setLayerType(ILandroid/graphics/Paint;)V

    const/high16 v0, -0x37000000    # -524288.0f

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    new-instance p2, Landroid/graphics/PorterDuffXfermode;

    sget-object v0, Landroid/graphics/PorterDuff$Mode;->CLEAR:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {p2, v0}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v1, p2}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    const/16 p2, -0x3fb5

    invoke-virtual {v2, p2}, Landroid/graphics/Paint;->setColor(I)V

    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 p2, 0x40000000    # 2.0f

    invoke-virtual {p1, p2}, Lc/n3;->b(F)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v2, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0, v3}, Landroid/view/View;->setImportantForAccessibility(I)V

    return-void
.end method


# virtual methods
.method public final a()Landroid/graphics/RectF;
    .locals 18

    move-object/from16 v0, p0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v3, v0, Lc/m3;->e:Landroid/graphics/RectF;

    invoke-virtual {v3}, Landroid/graphics/RectF;->setEmpty()V

    iget-object v4, v0, Lc/m3;->h:[I

    invoke-virtual {v0, v4}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-object v5, v0, Lc/m3;->i:Lc/n3;

    iget-object v6, v5, Lc/n3;->i:Landroid/view/View;

    instance-of v7, v6, Lc/Q3;

    const/4 v8, 0x2

    if-eqz v7, :cond_1

    iget v9, v5, Lc/n3;->l:I

    if-eq v9, v2, :cond_0

    if-ne v9, v8, :cond_1

    :cond_0
    new-array v6, v1, [Landroid/view/View;

    goto :goto_1

    :cond_1
    if-eqz v7, :cond_2

    check-cast v6, Lc/Q3;

    iget-object v6, v6, Lc/F;->l:Landroid/view/View;

    check-cast v6, Lc/b2;

    new-array v7, v2, [Landroid/view/View;

    aput-object v6, v7, v1

    :goto_0
    move-object v6, v7

    goto :goto_1

    :cond_2
    instance-of v7, v6, Lc/m2;

    if-nez v7, :cond_3

    new-array v6, v1, [Landroid/view/View;

    goto :goto_1

    :cond_3
    check-cast v6, Lc/m2;

    iget v7, v5, Lc/n3;->l:I

    const/4 v9, 0x4

    if-ne v7, v9, :cond_4

    iget-object v6, v6, Lc/m2;->w:Lc/l2;

    new-array v7, v2, [Landroid/view/View;

    aput-object v6, v7, v1

    goto :goto_0

    :cond_4
    const/4 v9, 0x5

    if-ne v7, v9, :cond_5

    iget-object v6, v6, Lc/m2;->t:[Lc/t2;

    aget-object v7, v6, v1

    iget-object v7, v7, Lc/t2;->m0:Landroid/view/View;

    aget-object v6, v6, v2

    iget-object v6, v6, Lc/t2;->m0:Landroid/view/View;

    filled-new-array {v7, v6}, [Landroid/view/View;

    move-result-object v6

    goto :goto_1

    :cond_5
    iget-object v6, v6, Lc/F;->l:Landroid/view/View;

    check-cast v6, Lc/b2;

    new-array v7, v2, [Landroid/view/View;

    aput-object v6, v7, v1

    goto :goto_0

    :goto_1
    array-length v7, v6

    move v9, v1

    :goto_2
    if-ge v9, v7, :cond_9

    aget-object v10, v6, v9

    if-eqz v10, :cond_8

    invoke-virtual {v10}, Landroid/view/View;->getVisibility()I

    move-result v11

    if-nez v11, :cond_8

    invoke-virtual {v10}, Landroid/view/View;->getWidth()I

    move-result v11

    if-eqz v11, :cond_8

    invoke-virtual {v10}, Landroid/view/View;->getHeight()I

    move-result v11

    if-nez v11, :cond_6

    goto :goto_3

    :cond_6
    iget-object v11, v0, Lc/m3;->g:[I

    invoke-virtual {v10, v11}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-object v12, v0, Lc/m3;->d:Landroid/graphics/RectF;

    aget v13, v11, v1

    aget v14, v4, v1

    sub-int v15, v13, v14

    int-to-float v15, v15

    aget v16, v11, v2

    aget v17, v4, v2

    sub-int v1, v16, v17

    int-to-float v1, v1

    sub-int/2addr v13, v14

    invoke-virtual {v10}, Landroid/view/View;->getWidth()I

    move-result v14

    add-int/2addr v14, v13

    int-to-float v13, v14

    aget v11, v11, v2

    aget v14, v4, v2

    sub-int/2addr v11, v14

    invoke-virtual {v10}, Landroid/view/View;->getHeight()I

    move-result v10

    add-int/2addr v10, v11

    int-to-float v10, v10

    invoke-virtual {v12, v15, v1, v13, v10}, Landroid/graphics/RectF;->set(FFFF)V

    invoke-virtual {v3}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {v3, v12}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_3

    :cond_7
    invoke-virtual {v3, v12}, Landroid/graphics/RectF;->union(Landroid/graphics/RectF;)V

    :cond_8
    :goto_3
    add-int/2addr v9, v2

    const/4 v1, 0x0

    goto :goto_2

    :cond_9
    iget-object v1, v5, Lc/n3;->i:Landroid/view/View;

    instance-of v6, v1, Lc/Q3;

    if-eqz v6, :cond_11

    check-cast v1, Lc/Q3;

    iget v6, v5, Lc/n3;->l:I

    iget-object v7, v0, Lc/m3;->f:Landroid/graphics/RectF;

    if-ne v6, v2, :cond_b

    iget-object v1, v1, Lc/F;->l:Landroid/view/View;

    check-cast v1, Lc/b2;

    iget-object v6, v1, Lc/b2;->B:Landroid/graphics/RectF;

    invoke-virtual {v7, v6}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    invoke-virtual {v7}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_a

    goto :goto_4

    :cond_a
    new-array v6, v8, [I

    invoke-virtual {v1, v6}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v1, 0x0

    aget v8, v6, v1

    int-to-float v1, v8

    aget v6, v6, v2

    int-to-float v6, v6

    invoke-virtual {v7, v1, v6}, Landroid/graphics/RectF;->offset(FF)V

    :goto_4
    const/4 v1, 0x0

    goto :goto_7

    :cond_b
    if-ne v6, v8, :cond_f

    iget-object v1, v1, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Landroid/graphics/RectF;->setEmpty()V

    invoke-static {}, Lc/s0;->values()[Lc/s0;

    move-result-object v6

    array-length v9, v6

    const/4 v10, 0x0

    :goto_5
    if-ge v10, v9, :cond_d

    aget-object v11, v6, v10

    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    move-result v11

    add-int/lit8 v11, v11, 0x64

    invoke-virtual {v1, v11, v7}, Lc/P3;->g(ILandroid/graphics/RectF;)V

    invoke-virtual {v7}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_c

    goto :goto_6

    :cond_c
    add-int/2addr v10, v2

    goto :goto_5

    :cond_d
    :goto_6
    invoke-virtual {v7}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_e

    goto :goto_4

    :cond_e
    new-array v6, v8, [I

    invoke-virtual {v1, v6}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v1, 0x0

    aget v8, v6, v1

    int-to-float v8, v8

    aget v6, v6, v2

    int-to-float v6, v6

    invoke-virtual {v7, v8, v6}, Landroid/graphics/RectF;->offset(FF)V

    goto :goto_7

    :cond_f
    const/4 v1, 0x0

    invoke-virtual {v7}, Landroid/graphics/RectF;->setEmpty()V

    :goto_7
    invoke-virtual {v7}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_11

    aget v1, v4, v1

    neg-int v1, v1

    int-to-float v1, v1

    aget v2, v4, v2

    neg-int v2, v2

    int-to-float v2, v2

    invoke-virtual {v7, v1, v2}, Landroid/graphics/RectF;->offset(FF)V

    invoke-virtual {v3}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-virtual {v3, v7}, Landroid/graphics/RectF;->set(Landroid/graphics/RectF;)V

    goto :goto_8

    :cond_10
    invoke-virtual {v3, v7}, Landroid/graphics/RectF;->union(Landroid/graphics/RectF;)V

    :cond_11
    :goto_8
    invoke-virtual {v3}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_12

    const/high16 v1, 0x41000000    # 8.0f

    invoke-virtual {v5, v1}, Lc/n3;->b(F)I

    move-result v2

    neg-int v2, v2

    int-to-float v2, v2

    invoke-virtual {v5, v1}, Lc/n3;->b(F)I

    move-result v1

    neg-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v3, v2, v1}, Landroid/graphics/RectF;->inset(FF)V

    :cond_12
    return-object v3
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 9

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    invoke-virtual {p0}, Lc/m3;->a()Landroid/graphics/RectF;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v5, v1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v1

    int-to-float v6, v1

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v2, p1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->saveLayer(FFFFLandroid/graphics/Paint;)I

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v6, v2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v7, v2

    iget-object v8, p0, Lc/m3;->a:Landroid/graphics/Paint;

    const/4 v5, 0x0

    move-object v3, p1

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v2

    const/high16 v3, 0x41600000    # 14.0f

    iget-object v4, p0, Lc/m3;->i:Lc/n3;

    if-nez v2, :cond_0

    invoke-virtual {v4, v3}, Lc/n3;->b(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v4, v3}, Lc/n3;->b(F)I

    move-result v5

    int-to-float v5, v5

    iget-object v6, p0, Lc/m3;->b:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v5, v6}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_0
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    invoke-virtual {v0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v4, v3}, Lc/n3;->b(F)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v4, v3}, Lc/n3;->b(F)I

    move-result v2

    int-to-float v2, v2

    iget-object v3, p0, Lc/m3;->c:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_1
    return-void
.end method
