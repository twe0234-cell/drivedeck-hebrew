.class public final synthetic Lc/L4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/IntConsumer;


# virtual methods
.method public final accept(I)V
    .locals 0

    sget p1, Lru/drivedeck/launcher/MainActivity;->F0:I

    return-void
.end method
