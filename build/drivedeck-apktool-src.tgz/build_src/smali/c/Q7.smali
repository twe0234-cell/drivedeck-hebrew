.class public final synthetic Lc/Q7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Z

.field public final synthetic d:Landroid/content/ServiceConnection;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/Z7;ILjava/lang/String;Z)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/Q7;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q7;->d:Landroid/content/ServiceConnection;

    iput p2, p0, Lc/Q7;->b:I

    iput-object p3, p0, Lc/Q7;->e:Ljava/lang/Object;

    iput-boolean p4, p0, Lc/Q7;->c:Z

    return-void
.end method

.method public synthetic constructor <init>(Lc/y8;IZLc/F3;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/Q7;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/Q7;->d:Landroid/content/ServiceConnection;

    iput p2, p0, Lc/Q7;->b:I

    iput-boolean p3, p0, Lc/Q7;->c:Z

    iput-object p4, p0, Lc/Q7;->e:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    iget v0, p0, Lc/Q7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/Q7;->d:Landroid/content/ServiceConnection;

    check-cast v0, Lc/y8;

    iget-boolean v1, v0, Lc/y8;->d:Z

    if-nez v1, :cond_2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, v0, Lc/y8;->b:Landroid/media/AudioManager;

    if-nez v0, :cond_0

    move v3, v2

    goto :goto_0

    :cond_0
    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v3

    :goto_0
    iget v4, p0, Lc/Q7;->b:I

    if-ne v3, v4, :cond_2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v3

    iget-boolean v5, p0, Lc/Q7;->c:Z

    const/4 v6, 0x1

    if-eqz v5, :cond_1

    move v5, v6

    goto :goto_1

    :cond_1
    const/4 v5, -0x1

    :goto_1
    add-int/2addr v4, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    invoke-virtual {v0, v1, v2, v6}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_2
    iget-object v0, p0, Lc/Q7;->e:Ljava/lang/Object;

    check-cast v0, Lc/F3;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lc/F3;->run()V

    :cond_3
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/Q7;->d:Landroid/content/ServiceConnection;

    check-cast v0, Lc/Z7;

    iget v1, p0, Lc/Q7;->b:I

    iget-object v2, p0, Lc/Q7;->e:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-boolean v3, p0, Lc/Q7;->c:Z

    iget-boolean v4, v0, Lc/Z7;->r:Z

    if-nez v4, :cond_5

    iget-boolean v4, v0, Lc/Z7;->q:Z

    if-eqz v4, :cond_5

    iget v4, v0, Lc/Z7;->B:I

    if-ne v1, v4, :cond_5

    iget-object v1, v0, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_2

    :cond_4
    if-nez v3, :cond_5

    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/Z7;->q:Z

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u043f\u0440\u043e\u0441\u0438\u0442\u044c \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u044b \u0442\u0435\u043b\u0435\u0444\u043e\u043d\u0430"

    iput-object v1, v0, Lc/Z7;->K:Ljava/lang/String;

    iget-object v0, v0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    :cond_5
    :goto_2
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
