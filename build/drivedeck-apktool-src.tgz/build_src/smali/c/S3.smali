.class public final synthetic Lc/S3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/U1;

.field public final synthetic c:Landroid/graphics/Bitmap;


# direct methods
.method public synthetic constructor <init>(Landroid/graphics/Bitmap;Lc/U1;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    iput v0, p0, Lc/S3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/S3;->c:Landroid/graphics/Bitmap;

    iput-object p2, p0, Lc/S3;->b:Lc/U1;

    return-void
.end method

.method public synthetic constructor <init>(Lc/U1;Landroid/graphics/Bitmap;)V
    .locals 1

    .line 2
    const/4 v0, 0x1

    iput v0, p0, Lc/S3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/S3;->b:Lc/U1;

    iput-object p2, p0, Lc/S3;->c:Landroid/graphics/Bitmap;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    iget v0, p0, Lc/S3;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/S3;->b:Lc/U1;

    iget-object v1, p0, Lc/S3;->c:Landroid/graphics/Bitmap;

    invoke-virtual {v0, v1}, Lc/U1;->accept(Ljava/lang/Object;)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/S3;->c:Landroid/graphics/Bitmap;

    const/4 v1, 0x2

    const/4 v2, 0x1

    :try_start_0
    invoke-static {v0, v1, v2}, Lc/X3;->b(Landroid/graphics/Bitmap;II)Landroid/graphics/Bitmap;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    goto :goto_0

    :catchall_0
    move-exception v1

    goto :goto_1

    :catch_0
    :try_start_1
    const-string v1, "DriveDeckWallpaper"

    const-string v2, "Cannot blur dock"

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    const/4 v1, 0x0

    :goto_0
    sget-object v0, Lc/X3;->c:Landroid/os/Handler;

    new-instance v2, Lc/S3;

    iget-object v3, p0, Lc/S3;->b:Lc/U1;

    invoke-direct {v2, v3, v1}, Lc/S3;-><init>(Lc/U1;Landroid/graphics/Bitmap;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :goto_1
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    throw v1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
