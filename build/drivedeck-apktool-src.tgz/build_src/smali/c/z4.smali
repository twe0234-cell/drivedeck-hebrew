.class public final synthetic Lc/z4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lc/n;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;JI)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/z4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/z4;->b:J

    iput p4, p0, Lc/z4;->c:I

    return-void
.end method


# virtual methods
.method public final a(Lc/a;)V
    .locals 9

    iget-object v0, p0, Lc/z4;->a:Lru/drivedeck/launcher/MainActivity;

    iget-wide v1, v0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-wide v3, p0, Lc/z4;->b:J

    cmp-long v1, v3, v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object p1, p1, Lc/a;->a:Ljava/lang/String;

    iget v6, p0, Lc/z4;->c:I

    invoke-virtual {v1, p1, v6}, Lc/n1;->R0(Ljava/lang/String;I)Z

    move-result p1

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    iput-boolean p1, v0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    invoke-virtual {v1}, Landroid/view/View;->invalidate()V

    iget-boolean v1, v0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v1, :cond_2

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v2, :cond_2

    iget-object v1, v2, Lc/m2;->y:Lc/n1;

    invoke-virtual {v1, p1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1}, Lc/n1;->I()F

    move-result v5

    const-wide/16 v7, 0x0

    invoke-virtual/range {v2 .. v8}, Lc/m2;->J(Ljava/lang/String;Ljava/lang/String;FIJ)V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-boolean v1, v1, Lc/m2;->I:Z

    if-nez v1, :cond_2

    iput-boolean p1, v0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    :cond_2
    :goto_0
    return-void
.end method
