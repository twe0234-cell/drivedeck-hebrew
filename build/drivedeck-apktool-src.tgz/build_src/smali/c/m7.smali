.class public final Lc/m7;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:[B

.field public b:I

.field public c:I


# direct methods
.method public constructor <init>([BI)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lc/m7;->c:I

    new-array p2, p2, [B

    iput-object p2, p0, Lc/m7;->a:[B

    array-length v0, p1

    const/4 v1, 0x2

    sub-int/2addr v0, v1

    iput v0, p0, Lc/m7;->b:I

    const/4 v2, 0x0

    invoke-static {p1, v1, p2, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method
