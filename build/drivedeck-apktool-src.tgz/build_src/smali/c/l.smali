.class public final synthetic Lc/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    iput p4, p0, Lc/l;->a:I

    iput-object p1, p0, Lc/l;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/l;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/l;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 14

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v4, p0, Lc/l;->d:Ljava/lang/Object;

    iget-object v5, p0, Lc/l;->c:Ljava/lang/Object;

    iget-object v6, p0, Lc/l;->b:Ljava/lang/Object;

    iget v7, p0, Lc/l;->a:I

    packed-switch v7, :pswitch_data_0

    check-cast v6, Lc/f1;

    iget-object p1, v6, Lc/f1;->d:Ljava/lang/Object;

    check-cast p1, Lc/O7;

    check-cast v5, Lc/y7;

    check-cast v4, Ljava/lang/String;

    invoke-static {p1, v5, v4, v3}, Lc/O7;->a(Lc/O7;Lc/y7;Ljava/lang/String;Z)V

    return-void

    :pswitch_0
    check-cast v5, Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    check-cast v4, Landroid/app/Dialog;

    new-instance v0, Lc/i;

    invoke-direct {v0, v4, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    check-cast v6, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v6, p1, v0}, Lc/q4;->x(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Ljava/lang/Runnable;)V

    return-void

    :pswitch_1
    check-cast v6, Lc/k3;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, Landroid/view/View;

    invoke-virtual {v5, v3}, Landroid/view/View;->setEnabled(Z)V

    new-instance p1, Lc/a3;

    check-cast v4, Landroid/widget/TextView;

    invoke-direct {p1, v6, v4, v5, v3}, Lc/a3;-><init>(Lc/k3;Landroid/widget/TextView;Landroid/view/View;I)V

    sget-object v1, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    iget-object v1, v6, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    new-instance v9, Lc/Z6;

    invoke-direct {v9, v5, p1}, Lc/Z6;-><init>(Landroid/view/View;Ljava/lang/Object;)V

    new-instance p1, Lc/b1;

    invoke-direct {p1, v0}, Lc/b1;-><init>(I)V

    invoke-virtual {v9, p1, v3}, Lc/Z6;->b(Ljava/util/function/Consumer;Z)V

    new-instance p1, Lc/F5;

    const-string v8, "ru.drivedeck.voice"

    const-string v10, "voice"

    const/4 v11, 0x3

    const/4 v12, 0x6

    move-object v6, p1

    invoke-direct/range {v6 .. v12}, Lc/F5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    sget-object v0, Lc/c9;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    :pswitch_2
    move-object v0, v6

    check-cast v0, Lc/k3;

    iget-boolean v1, v0, Lc/k3;->L:Z

    if-nez v1, :cond_3

    iget-object v1, v0, Lc/k3;->c:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v1

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    iget-object v6, v0, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v1, :cond_1

    sget-object v1, Lc/F8;->a:Ljava/util/concurrent/ExecutorService;

    const-string v1, "ru"

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-static {v6, v5}, Lc/F8;->c(Landroid/content/Context;Ljava/lang/String;)Ljava/util/zip/GZIPInputStream;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    :cond_1
    if-eqz v6, :cond_2

    iput-boolean v3, v6, Lru/drivedeck/launcher/MainActivity;->c:Z

    :cond_2
    iput-boolean v2, v0, Lc/k3;->L:Z

    check-cast v4, Landroid/widget/TextView;

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v4}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v6

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " \u2026"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-instance v7, Lc/C2;

    const/4 v8, 0x0

    move-object v1, v7

    move-object v2, v0

    move-object v3, v5

    move-object v5, v6

    move v6, v8

    invoke-direct/range {v1 .. v6}, Lc/C2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p1, v7}, Lc/k3;->p0(Landroid/view/View;Ljava/lang/Runnable;)V

    :cond_3
    :goto_0
    return-void

    :pswitch_3
    check-cast v6, Lc/k3;

    iget-object p1, v6, Lc/k3;->b:Lc/z;

    invoke-virtual {p1}, Lc/z;->c()Ljava/util/List;

    move-result-object v8

    new-instance v10, Lc/r2;

    check-cast v4, Ljava/util/function/Consumer;

    invoke-direct {v10, v6, v4, v2}, Lc/r2;-><init>(Landroid/view/KeyEvent$Callback;Ljava/lang/Object;I)V

    new-instance v11, Lc/a1;

    invoke-direct {v11, v0}, Lc/a1;-><init>(I)V

    move-object v9, v5

    check-cast v9, Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x0

    iget-object v7, v6, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static/range {v7 .. v13}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    return-void

    :pswitch_4
    check-cast v6, Landroid/widget/Button;

    invoke-virtual {v6, v3}, Landroid/view/View;->setEnabled(Z)V

    new-instance p1, Lc/Z;

    check-cast v5, Landroid/widget/TextView;

    check-cast v4, Landroid/app/Activity;

    invoke-direct {p1, v5, v4, v6, v1}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-static {p1}, Lc/N1;->g(Ljava/lang/Runnable;)V

    invoke-static {}, Lc/N1;->B()Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v5, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :pswitch_5
    check-cast v6, Lru/drivedeck/launcher/MainActivity;

    invoke-static {v6}, Lc/y9;->d(Landroid/content/Context;)Z

    move-result p1

    const-string v0, ""

    invoke-static {v6, p1, v0}, Lc/y9;->k(Lru/drivedeck/launcher/MainActivity;ZLjava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_4

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u043e\u0433\u043e\u0434\u044b"

    invoke-static {v6, p1, v6, v2}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    goto :goto_1

    :cond_4
    check-cast v5, Lc/i;

    invoke-virtual {v5}, Lc/i;->run()V

    invoke-static {v6, v5, v2, v3}, Lc/y9;->h(Landroid/content/Context;Ljava/lang/Runnable;ZZ)Z

    check-cast v4, Landroid/app/Dialog;

    invoke-virtual {v4}, Landroid/app/Dialog;->dismiss()V

    :goto_1
    return-void

    :pswitch_6
    check-cast v6, Lc/T5;

    invoke-virtual {v6}, Lc/T5;->t0()V

    check-cast v5, Ljava/util/function/BooleanSupplier;

    invoke-interface {v5}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    check-cast v4, Lru/drivedeck/launcher/MainActivity;

    const-string p1, "\u041f\u043e\u0435\u0437\u0434\u043a\u0430 \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u0430"

    invoke-static {v4, p1, v4, v3}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :pswitch_7
    check-cast v4, Landroid/content/Context;

    check-cast v6, Lc/j;

    invoke-virtual {v6}, Lc/j;->dismiss()V

    new-instance p1, Landroid/content/Intent;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "package:"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    check-cast v5, Lc/a;

    iget-object v1, v5, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const-string v1, "android.intent.action.DELETE"

    invoke-direct {p1, v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    :try_start_1
    invoke-virtual {v4, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_2

    :catch_1
    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v4, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v4, p1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    :goto_2
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
