.class public final Lc/t8;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Landroid/view/View;

.field public b:Lc/r8;

.field public c:Lc/r8;

.field public final d:Landroid/util/SparseBooleanArray;

.field public e:Lc/r8;

.field public f:Z

.field public final g:Lc/i;

.field public h:F

.field public final i:Landroid/graphics/Paint;

.field public final j:Lc/p8;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .locals 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, p0, Lc/t8;->d:Landroid/util/SparseBooleanArray;

    new-instance v0, Lc/i;

    const/16 v1, 0x10

    invoke-direct {v0, p0, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lc/t8;->g:Lc/i;

    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lc/t8;->i:Landroid/graphics/Paint;

    new-instance v1, Lc/p8;

    invoke-direct {v1, p0}, Lc/p8;-><init>(Lc/t8;)V

    iput-object v1, p0, Lc/t8;->j:Lc/p8;

    iput-object p1, p0, Lc/t8;->a:Landroid/view/View;

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x40400000    # 3.0f

    invoke-static {v1, v2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object p1

    iget p1, p1, Lc/r4;->f:I

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    return-void
.end method

.method public static b(Ljava/util/ArrayList;Landroid/view/View;ILandroid/graphics/RectF;Ljava/lang/Runnable;Ljava/lang/Runnable;)V
    .locals 6

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p3, v3}, Landroid/graphics/RectF;->roundOut(Landroid/graphics/Rect;)V

    new-instance p3, Landroid/graphics/Rect;

    invoke-direct {p3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroid/view/View;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1, p3}, Landroid/view/View;->getLocalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {v3, p3}, Landroid/graphics/Rect;->intersect(Landroid/graphics/Rect;)Z

    move-result p3

    if-eqz p3, :cond_0

    new-instance p3, Lc/r8;

    move-object v0, p3

    move-object v1, p1

    move v2, p2

    move-object v4, p4

    move-object v5, p5

    invoke-direct/range {v0 .. v5}, Lc/r8;-><init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-virtual {p0, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    return-void
.end method

.method public static k(Landroid/view/View;)V
    .locals 3

    invoke-virtual {p0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/view/View;->getAlpha()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    instance-of v0, p0, Lc/F;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    move-object v0, p0

    check-cast v0, Lc/F;

    iget-object v2, v0, Lc/F;->s:Lc/D;

    invoke-virtual {v0, v2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {v0, v1}, Lc/F;->s(Z)V

    :cond_1
    instance-of v0, p0, Landroid/view/ViewGroup;

    if-eqz v0, :cond_2

    check-cast p0, Landroid/view/ViewGroup;

    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    if-ge v1, v0, :cond_2

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Lc/t8;->k(Landroid/view/View;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    return-void
.end method

.method public static l(Landroid/view/View;Landroid/graphics/RectF;)V
    .locals 11

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v8

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    const/4 v7, 0x0

    const/4 v4, 0x0

    move-wide v0, v8

    move-wide v2, v8

    invoke-static/range {v0 .. v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object v10

    const-wide/16 v0, 0x1

    add-long v2, v8, v0

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerX()F

    move-result v5

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result v6

    const/4 v4, 0x1

    move-wide v0, v8

    invoke-static/range {v0 .. v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    move-result-object p1

    :try_start_0
    invoke-virtual {p0, v10}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    invoke-virtual {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-virtual {v10}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->recycle()V

    return-void

    :catchall_0
    move-exception p0

    invoke-virtual {v10}, Landroid/view/MotionEvent;->recycle()V

    invoke-virtual {p1}, Landroid/view/MotionEvent;->recycle()V

    throw p0
.end method

.method public static n(Landroid/view/KeyEvent;)Landroid/view/KeyEvent;
    .locals 15

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v1, 0x104

    if-eq v0, v1, :cond_0

    const/16 v2, 0x105

    if-eq v0, v2, :cond_0

    new-instance v0, Landroid/view/KeyEvent;

    invoke-direct {v0, p0}, Landroid/view/KeyEvent;-><init>(Landroid/view/KeyEvent;)V

    return-object v0

    :cond_0
    new-instance v14, Landroid/view/KeyEvent;

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getDownTime()J

    move-result-wide v2

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getEventTime()J

    move-result-wide v4

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result v8

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getMetaState()I

    move-result v7

    if-ne v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    or-int v9, v7, v0

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getDeviceId()I

    move-result v10

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getScanCode()I

    move-result v11

    invoke-virtual {p0}, Landroid/view/KeyEvent;->getFlags()I

    move-result v12

    const/16 v13, 0x101

    const/16 v7, 0x3d

    move-object v1, v14

    invoke-direct/range {v1 .. v13}, Landroid/view/KeyEvent;-><init>(JJIIIIIIII)V

    return-object v14
.end method


# virtual methods
.method public final a(Z)V
    .locals 3

    invoke-virtual {p0}, Lc/t8;->m()Ljava/util/ArrayList;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/r8;

    iget-object v2, p0, Lc/t8;->b:Lc/r8;

    invoke-virtual {v1, v2}, Lc/r8;->a(Lc/r8;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v0, v1, Lc/r8;->a:Landroid/view/View;

    instance-of v0, v0, Lc/q8;

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lc/t8;->d()V

    :cond_1
    if-eqz p1, :cond_2

    iget-object p1, v1, Lc/r8;->e:Ljava/lang/Runnable;

    goto :goto_0

    :cond_2
    iget-object p1, v1, Lc/r8;->d:Ljava/lang/Runnable;

    :goto_0
    if-eqz p1, :cond_3

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_3
    invoke-virtual {p0}, Lc/t8;->f()Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-virtual {p0}, Lc/t8;->m()Ljava/util/ArrayList;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/r8;

    iget-object v2, p0, Lc/t8;->b:Lc/r8;

    invoke-virtual {v1, v2}, Lc/r8;->a(Lc/r8;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_1

    :cond_5
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_6

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/r8;

    iput-object p1, p0, Lc/t8;->b:Lc/r8;

    :cond_6
    :goto_1
    iget-object p1, p0, Lc/t8;->j:Lc/p8;

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_7
    return-void

    :cond_8
    invoke-virtual {p0}, Lc/t8;->f()Z

    move-result p1

    if-nez p1, :cond_9

    invoke-virtual {p0}, Lc/t8;->d()V

    :cond_9
    return-void
.end method

.method public final c()V
    .locals 2

    iget-object v0, p0, Lc/t8;->g:Lc/i;

    iget-object v1, p0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v0, 0x0

    iput-object v0, p0, Lc/t8;->e:Lc/r8;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/t8;->f:Z

    return-void
.end method

.method public final d()V
    .locals 3

    invoke-virtual {p0}, Lc/t8;->c()V

    iget-object v0, p0, Lc/t8;->c:Lc/r8;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, v0, Lc/r8;->a:Landroid/view/View;

    check-cast v0, Lc/s8;

    check-cast v0, Lc/t2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-static {v0}, Lc/j8;->l(I)V

    sput-object v1, Lc/m8;->b:Lc/n1;

    sput-object v1, Lc/m8;->c:Lc/r5;

    :cond_0
    iput-object v1, p0, Lc/t8;->c:Lc/r8;

    iget-object v0, p0, Lc/t8;->b:Lc/r8;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lc/r8;->a:Landroid/view/View;

    instance-of v2, v0, Lc/q8;

    if-eqz v2, :cond_1

    check-cast v0, Lc/q8;

    invoke-interface {v0}, Lc/q8;->b()V

    :cond_1
    iput-object v1, p0, Lc/t8;->b:Lc/r8;

    const/4 v0, 0x0

    iput v0, p0, Lc/t8;->h:F

    iget-object v0, p0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object v0

    iget-object v1, p0, Lc/t8;->j:Lc/p8;

    invoke-virtual {v0, v1}, Landroid/view/ViewOverlay;->remove(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public final e(Landroid/view/View;Ljava/util/ArrayList;)V
    .locals 10

    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-virtual {p1}, Landroid/view/View;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-virtual {p1}, Landroid/view/View;->getAlpha()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_a

    invoke-virtual {p1}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_0

    goto/16 :goto_4

    :cond_0
    instance-of v0, p1, Lc/s8;

    if-eqz v0, :cond_1

    move-object v0, p1

    check-cast v0, Lc/s8;

    check-cast v0, Lc/t2;

    invoke-virtual {v0}, Lc/t2;->Y()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v4, Landroid/graphics/Rect;

    invoke-direct {v4}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p1, v4}, Landroid/view/View;->getLocalVisibleRect(Landroid/graphics/Rect;)Z

    move-result v0

    if-eqz v0, :cond_a

    invoke-virtual {v4}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    new-instance v0, Lc/r8;

    new-instance v5, Lc/F7;

    const/4 v1, 0x3

    invoke-direct {v5, p0, p1, v1}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 v6, 0x0

    const/4 v3, 0x0

    move-object v1, v0

    move-object v2, p1

    invoke-direct/range {v1 .. v6}, Lc/r8;-><init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_4

    :cond_1
    instance-of v0, p1, Lc/q8;

    if-eqz v0, :cond_2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    check-cast p1, Lc/q8;

    invoke-interface {p1, p2}, Lc/q8;->d(Ljava/util/ArrayList;)V

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p1

    invoke-virtual {p2, v0, p1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object p1

    new-instance p2, Lc/p0;

    const/4 v0, 0x1

    invoke-direct {p2, v0}, Lc/p0;-><init>(I)V

    invoke-interface {p1, p2}, Ljava/util/List;->sort(Ljava/util/Comparator;)V

    goto/16 :goto_4

    :cond_2
    instance-of v0, p1, Landroid/widget/AbsListView;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    check-cast p1, Landroid/widget/AbsListView;

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getAdapter()Landroid/widget/Adapter;

    move-result-object v0

    if-nez v0, :cond_3

    return-void

    :cond_3
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p1, v0}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    :goto_0
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getCount()I

    move-result v3

    if-ge v2, v3, :cond_a

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getAdapter()Landroid/widget/Adapter;

    move-result-object v3

    check-cast v3, Landroid/widget/ListAdapter;

    invoke-interface {v3, v2}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v3

    if-nez v3, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getOnItemLongClickListener()Landroid/widget/AdapterView$OnItemLongClickListener;

    move-result-object v3

    if-nez v3, :cond_5

    move-object v8, v1

    goto :goto_1

    :cond_5
    new-instance v3, Lc/n8;

    const/4 v4, 0x0

    invoke-direct {v3, p1, v2, v4}, Lc/n8;-><init>(Landroid/widget/AbsListView;II)V

    move-object v8, v3

    :goto_1
    new-instance v9, Lc/r8;

    new-instance v7, Lc/n8;

    const/4 v3, 0x1

    invoke-direct {v7, p1, v2, v3}, Lc/n8;-><init>(Landroid/widget/AbsListView;II)V

    move-object v3, v9

    move-object v4, p1

    move v5, v2

    move-object v6, v0

    invoke-direct/range {v3 .. v8}, Lc/r8;-><init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-virtual {p2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_6
    instance-of v0, p1, Landroid/view/ViewGroup;

    if-eqz v0, :cond_8

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    move-object v3, p1

    check-cast v3, Landroid/view/ViewGroup;

    :goto_3
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v4

    if-ge v2, v4, :cond_7

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {p0, v4, p2}, Lc/t8;->e(Landroid/view/View;Ljava/util/ArrayList;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_3

    :cond_7
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-eq v2, v0, :cond_8

    return-void

    :cond_8
    invoke-virtual {p1}, Landroid/view/View;->isClickable()Z

    move-result v0

    if-eqz v0, :cond_a

    instance-of v0, p1, Landroid/widget/EditText;

    if-nez v0, :cond_a

    new-instance v5, Landroid/graphics/Rect;

    invoke-direct {v5}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {p1, v5}, Landroid/view/View;->getDrawingRect(Landroid/graphics/Rect;)V

    invoke-virtual {v5}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_a

    new-instance v0, Lc/r8;

    new-instance v6, Lc/o8;

    const/4 v2, 0x0

    invoke-direct {v6, p1, v2}, Lc/o8;-><init>(Landroid/view/View;I)V

    invoke-virtual {p1}, Landroid/view/View;->isLongClickable()Z

    move-result v2

    if-eqz v2, :cond_9

    new-instance v1, Lc/o8;

    const/4 v2, 0x1

    invoke-direct {v1, p1, v2}, Lc/o8;-><init>(Landroid/view/View;I)V

    :cond_9
    move-object v7, v1

    const/4 v4, 0x0

    move-object v2, v0

    move-object v3, p1

    invoke-direct/range {v2 .. v7}, Lc/r8;-><init>(Landroid/view/View;ILandroid/graphics/Rect;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    :goto_4
    return-void
.end method

.method public final f()Z
    .locals 2

    iget-object v0, p0, Lc/t8;->b:Lc/r8;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lc/r8;->a:Landroid/view/View;

    instance-of v1, v0, Lc/q8;

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/t8;->b:Lc/r8;

    iget-object v0, v0, Lc/r8;->a:Landroid/view/View;

    check-cast v0, Lc/q8;

    invoke-interface {v0}, Lc/q8;->c()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final g(Landroid/view/KeyEvent;)Z
    .locals 10

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v1, 0x15

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    const/16 v1, 0x13

    if-eq v0, v1, :cond_1

    const/16 v1, 0x104

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v2

    goto :goto_1

    :cond_1
    :goto_0
    move v1, v3

    :goto_1
    const/16 v4, 0x16

    if-eq v0, v4, :cond_3

    const/16 v4, 0x14

    if-eq v0, v4, :cond_3

    const/16 v4, 0x105

    if-ne v0, v4, :cond_2

    goto :goto_2

    :cond_2
    move v4, v2

    goto :goto_3

    :cond_3
    :goto_2
    move v4, v3

    :goto_3
    const/16 v5, 0x17

    if-eq v0, v5, :cond_5

    const/16 v5, 0x42

    if-eq v0, v5, :cond_5

    const/16 v5, 0xa0

    if-ne v0, v5, :cond_4

    goto :goto_4

    :cond_4
    move v5, v2

    goto :goto_5

    :cond_5
    :goto_4
    move v5, v3

    :goto_5
    iget-object v6, p0, Lc/t8;->c:Lc/r8;

    if-eqz v6, :cond_b

    const/4 v7, 0x4

    if-nez v1, :cond_6

    if-nez v4, :cond_6

    if-nez v5, :cond_6

    if-ne v0, v7, :cond_b

    :cond_6
    iget-object v6, v6, Lc/r8;->a:Landroid/view/View;

    move-object v8, v6

    check-cast v8, Lc/s8;

    invoke-virtual {v6}, Landroid/view/View;->isShown()Z

    move-result v6

    if-eqz v6, :cond_a

    check-cast v8, Lc/t2;

    invoke-virtual {v8}, Lc/t2;->Y()Z

    move-result v6

    if-nez v6, :cond_7

    goto :goto_6

    :cond_7
    if-ne v0, v7, :cond_9

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-ne p1, v3, :cond_8

    const/4 p1, 0x0

    iput-object p1, p0, Lc/t8;->c:Lc/r8;

    sput-object p1, Lc/m8;->b:Lc/n1;

    sput-object p1, Lc/m8;->c:Lc/r5;

    invoke-static {v2}, Lc/j8;->l(I)V

    :cond_8
    return v3

    :cond_9
    invoke-static {p1}, Lc/t8;->n(Landroid/view/KeyEvent;)Landroid/view/KeyEvent;

    move-result-object p1

    invoke-virtual {v8, p1}, Lc/t2;->X(Landroid/view/KeyEvent;)Z

    return v3

    :cond_a
    :goto_6
    invoke-virtual {p0}, Lc/t8;->d()V

    :cond_b
    iget-object v6, p0, Lc/t8;->b:Lc/r8;

    if-eqz v6, :cond_c

    iget-object v6, v6, Lc/r8;->a:Landroid/view/View;

    instance-of v7, v6, Lc/q8;

    if-eqz v7, :cond_c

    invoke-virtual {v6}, Landroid/view/View;->isShown()Z

    move-result v6

    if-eqz v6, :cond_c

    iget-object v6, p0, Lc/t8;->b:Lc/r8;

    iget-object v6, v6, Lc/r8;->a:Landroid/view/View;

    check-cast v6, Lc/q8;

    invoke-interface {v6, p1}, Lc/q8;->e(Landroid/view/KeyEvent;)Z

    move-result v6

    if-eqz v6, :cond_c

    invoke-virtual {p0}, Lc/t8;->c()V

    iget-object p1, p0, Lc/t8;->j:Lc/p8;

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return v3

    :cond_c
    if-nez v1, :cond_d

    if-nez v4, :cond_d

    if-nez v5, :cond_d

    return v2

    :cond_d
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    iget-object v7, p0, Lc/t8;->g:Lc/i;

    iget-object v8, p0, Lc/t8;->a:Landroid/view/View;

    iget-object v9, p0, Lc/t8;->d:Landroid/util/SparseBooleanArray;

    if-ne v6, v3, :cond_11

    invoke-virtual {v9, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v6

    if-eqz v6, :cond_11

    invoke-virtual {v9, v0}, Landroid/util/SparseBooleanArray;->delete(I)V

    if-eqz v5, :cond_10

    invoke-virtual {v8, v7}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    invoke-virtual {p1}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result v0

    if-nez v0, :cond_f

    iget-boolean v0, p0, Lc/t8;->f:Z

    if-nez v0, :cond_f

    iget-object v0, p0, Lc/t8;->e:Lc/r8;

    if-eqz v0, :cond_f

    iget-object v1, p0, Lc/t8;->b:Lc/r8;

    invoke-virtual {v0, v1}, Lc/r8;->a(Lc/r8;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getEventTime()J

    move-result-wide v0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getDownTime()J

    move-result-wide v4

    sub-long/2addr v0, v4

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result p1

    int-to-long v4, p1

    cmp-long p1, v0, v4

    if-ltz p1, :cond_e

    invoke-virtual {p0}, Lc/t8;->h()V

    goto :goto_7

    :cond_e
    invoke-virtual {p0, v2}, Lc/t8;->a(Z)V

    :cond_f
    :goto_7
    invoke-virtual {p0}, Lc/t8;->c()V

    :cond_10
    return v3

    :cond_11
    invoke-virtual {v8}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v6

    instance-of v6, v6, Landroid/widget/EditText;

    if-nez v6, :cond_19

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v6

    if-eqz v6, :cond_12

    goto :goto_9

    :cond_12
    if-eqz v5, :cond_13

    iget-object v6, p0, Lc/t8;->b:Lc/r8;

    if-nez v6, :cond_13

    invoke-virtual {v9, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result p1

    return p1

    :cond_13
    if-nez v1, :cond_14

    if-eqz v4, :cond_16

    :cond_14
    if-eqz v1, :cond_15

    const/4 v1, -0x1

    goto :goto_8

    :cond_15
    move v1, v3

    :goto_8
    invoke-virtual {p0, v1}, Lc/t8;->j(I)Z

    move-result v1

    if-nez v1, :cond_16

    return v2

    :cond_16
    if-eqz v5, :cond_18

    invoke-virtual {v9, v0}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v1

    if-nez v1, :cond_17

    iget-object v1, p0, Lc/t8;->b:Lc/r8;

    iput-object v1, p0, Lc/t8;->e:Lc/r8;

    iput-boolean v2, p0, Lc/t8;->f:Z

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result v1

    int-to-long v1, v1

    invoke-virtual {v8, v7, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_17
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isLongPress()Z

    move-result p1

    if-eqz p1, :cond_18

    invoke-virtual {p0}, Lc/t8;->h()V

    :cond_18
    invoke-virtual {v9, v0, v3}, Landroid/util/SparseBooleanArray;->put(IZ)V

    return v3

    :cond_19
    :goto_9
    return v2
.end method

.method public final h()V
    .locals 2

    iget-boolean v0, p0, Lc/t8;->f:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/t8;->e:Lc/r8;

    if-eqz v0, :cond_1

    iget-object v1, p0, Lc/t8;->b:Lc/r8;

    invoke-virtual {v0, v1}, Lc/r8;->a(Lc/r8;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/t8;->f:Z

    invoke-virtual {p0, v0}, Lc/t8;->a(Z)V

    :cond_1
    :goto_0
    return-void
.end method

.method public final i(Landroid/view/MotionEvent;)Z
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v2

    const/16 v3, 0x8

    const/4 v4, 0x0

    if-ne v2, v3, :cond_e

    const/high16 v2, 0x400000

    invoke-virtual {v1, v2}, Landroid/view/InputEvent;->isFromSource(I)Z

    move-result v2

    if-eqz v2, :cond_e

    iget-object v2, v0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {v2}, Landroid/view/View;->findFocus()Landroid/view/View;

    move-result-object v2

    instance-of v2, v2, Landroid/widget/EditText;

    if-eqz v2, :cond_0

    goto/16 :goto_5

    :cond_0
    const/16 v2, 0x1a

    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v2

    const/4 v3, 0x0

    cmpl-float v5, v2, v3

    if-nez v5, :cond_1

    const/16 v2, 0x9

    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v2

    :cond_1
    cmpl-float v3, v2, v3

    if-nez v3, :cond_2

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v1

    neg-float v2, v1

    :cond_2
    invoke-static {v2}, Ljava/lang/Float;->isNaN(F)Z

    move-result v1

    if-nez v1, :cond_e

    invoke-static {v2}, Ljava/lang/Float;->isInfinite(F)Z

    move-result v1

    if-eqz v1, :cond_3

    goto/16 :goto_5

    :cond_3
    iget v1, v0, Lc/t8;->h:F

    add-float/2addr v1, v2

    const/high16 v2, 0x42c80000    # 100.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v2, -0x3d380000    # -100.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    float-to-int v2, v1

    int-to-float v3, v2

    sub-float/2addr v1, v3

    iput v1, v0, Lc/t8;->h:F

    iget-object v1, v0, Lc/t8;->c:Lc/r8;

    const/4 v3, 0x1

    const/16 v5, 0x105

    const/16 v6, 0x104

    if-eqz v1, :cond_8

    iget-object v1, v1, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_7

    iget-object v1, v0, Lc/t8;->c:Lc/r8;

    iget-object v1, v1, Lc/r8;->a:Landroid/view/View;

    check-cast v1, Lc/s8;

    check-cast v1, Lc/t2;

    invoke-virtual {v1}, Lc/t2;->Y()Z

    move-result v1

    if-nez v1, :cond_4

    goto :goto_2

    :cond_4
    :goto_0
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-ge v4, v1, :cond_6

    if-lez v2, :cond_5

    move v1, v6

    goto :goto_1

    :cond_5
    move v1, v5

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v15

    iget-object v7, v0, Lc/t8;->c:Lc/r8;

    iget-object v7, v7, Lc/r8;->a:Landroid/view/View;

    move-object/from16 v17, v7

    check-cast v17, Lc/s8;

    new-instance v18, Landroid/view/KeyEvent;

    const/4 v12, 0x0

    const/4 v14, 0x0

    move-object/from16 v7, v18

    move-wide v8, v15

    move-wide v10, v15

    move v13, v1

    invoke-direct/range {v7 .. v14}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-static/range {v18 .. v18}, Lc/t8;->n(Landroid/view/KeyEvent;)Landroid/view/KeyEvent;

    move-result-object v7

    move-object/from16 v14, v17

    check-cast v14, Lc/t2;

    invoke-virtual {v14, v7}, Lc/t2;->X(Landroid/view/KeyEvent;)Z

    new-instance v17, Landroid/view/KeyEvent;

    const/4 v12, 0x1

    const/16 v18, 0x0

    move-object/from16 v7, v17

    move-object v1, v14

    move/from16 v14, v18

    invoke-direct/range {v7 .. v14}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-static/range {v17 .. v17}, Lc/t8;->n(Landroid/view/KeyEvent;)Landroid/view/KeyEvent;

    move-result-object v7

    invoke-virtual {v1, v7}, Lc/t2;->X(Landroid/view/KeyEvent;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_6
    return v3

    :cond_7
    :goto_2
    invoke-virtual/range {p0 .. p0}, Lc/t8;->d()V

    :cond_8
    iget-object v1, v0, Lc/t8;->b:Lc/r8;

    if-eqz v1, :cond_c

    iget-object v1, v1, Lc/r8;->a:Landroid/view/View;

    instance-of v7, v1, Lc/q8;

    if-eqz v7, :cond_c

    check-cast v1, Lc/q8;

    if-lez v2, :cond_9

    move v5, v6

    :cond_9
    move v6, v4

    move v7, v6

    :goto_3
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v8

    if-ge v6, v8, :cond_b

    new-instance v7, Landroid/view/KeyEvent;

    invoke-direct {v7, v4, v5}, Landroid/view/KeyEvent;-><init>(II)V

    invoke-interface {v1, v7}, Lc/q8;->e(Landroid/view/KeyEvent;)Z

    move-result v7

    if-nez v7, :cond_a

    goto :goto_4

    :cond_a
    new-instance v8, Landroid/view/KeyEvent;

    invoke-direct {v8, v3, v5}, Landroid/view/KeyEvent;-><init>(II)V

    invoke-interface {v1, v8}, Lc/q8;->e(Landroid/view/KeyEvent;)Z

    add-int/lit8 v6, v6, 0x1

    goto :goto_3

    :cond_b
    :goto_4
    if-eqz v7, :cond_c

    iget-object v1, v0, Lc/t8;->j:Lc/p8;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return v3

    :cond_c
    if-eqz v2, :cond_d

    neg-int v1, v2

    invoke-virtual {v0, v1}, Lc/t8;->j(I)Z

    move-result v1

    if-eqz v1, :cond_e

    :cond_d
    move v4, v3

    :cond_e
    :goto_5
    return v4
.end method

.method public final j(I)Z
    .locals 8

    invoke-virtual {p0}, Lc/t8;->c()V

    iget-object v0, p0, Lc/t8;->a:Landroid/view/View;

    invoke-static {v0}, Lc/t8;->k(Landroid/view/View;)V

    invoke-virtual {p0}, Lc/t8;->m()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    invoke-virtual {p0}, Lc/t8;->f()Z

    move-result p1

    if-eqz p1, :cond_0

    return v4

    :cond_0
    invoke-virtual {p0}, Lc/t8;->d()V

    return v3

    :cond_1
    move v2, v3

    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v6, -0x1

    if-ge v2, v5, :cond_3

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/r8;

    iget-object v7, p0, Lc/t8;->b:Lc/r8;

    invoke-virtual {v5, v7}, Lc/r8;->a(Lc/r8;)Z

    move-result v5

    if-eqz v5, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    move v2, v6

    :goto_1
    if-gez v2, :cond_5

    if-lez p1, :cond_4

    goto :goto_2

    :cond_4
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    goto :goto_2

    :cond_5
    move v6, v2

    :goto_2
    add-int/2addr v6, p1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p1

    invoke-static {v6, p1}, Ljava/lang/Math;->floorMod(II)I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/r8;

    iput-object p1, p0, Lc/t8;->b:Lc/r8;

    iget-object p1, p1, Lc/r8;->a:Landroid/view/View;

    instance-of v1, p1, Landroid/widget/AbsListView;

    if-eqz v1, :cond_6

    invoke-virtual {p1, v4}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    iget-object p1, p0, Lc/t8;->b:Lc/r8;

    iget-object p1, p1, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    iget-object p1, p0, Lc/t8;->b:Lc/r8;

    iget-object v1, p1, Lc/r8;->a:Landroid/view/View;

    check-cast v1, Landroid/widget/AbsListView;

    iget p1, p1, Lc/r8;->b:I

    invoke-virtual {v1, p1}, Landroid/widget/AdapterView;->setSelection(I)V

    goto :goto_3

    :cond_6
    new-instance v1, Landroid/graphics/Rect;

    iget-object v2, p0, Lc/t8;->b:Lc/r8;

    iget-object v2, v2, Lc/r8;->c:Landroid/graphics/Rect;

    invoke-direct {v1, v2}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    invoke-virtual {p1, v1, v4}, Landroid/view/View;->requestRectangleOnScreen(Landroid/graphics/Rect;Z)Z

    :goto_3
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v1

    iget-object v2, p0, Lc/t8;->j:Lc/p8;

    invoke-virtual {v2, v3, v3, p1, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    invoke-virtual {v0}, Landroid/view/View;->getOverlay()Landroid/view/ViewOverlay;

    move-result-object p1

    invoke-virtual {p1, v2}, Landroid/view/ViewOverlay;->add(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    new-instance p1, Lc/i;

    const/16 v1, 0x11

    invoke-direct {p1, v2, v1}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, p1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return v4
.end method

.method public final m()Ljava/util/ArrayList;
    .locals 2

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lc/t8;->f()Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lc/t8;->b:Lc/r8;

    iget-object v1, v1, Lc/r8;->a:Landroid/view/View;

    invoke-virtual {p0, v1, v0}, Lc/t8;->e(Landroid/view/View;Ljava/util/ArrayList;)V

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lc/t8;->a:Landroid/view/View;

    invoke-virtual {p0, v1, v0}, Lc/t8;->e(Landroid/view/View;Ljava/util/ArrayList;)V

    :goto_0
    return-object v0
.end method
