.class public final Lc/l2;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public b:Z

.field public c:Z


# direct methods
.method public constructor <init>(Lru/drivedeck/launcher/MainActivity;)V
    .locals 1

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lc/l2;->a:Landroid/graphics/Paint;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 14

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    new-instance v0, Lc/n1;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->m0()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Lc/l2;->c:Z

    if-nez v1, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v1, v2}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    iget-object v11, p0, Lc/l2;->a:Landroid/graphics/Paint;

    const/high16 v12, 0x40000000    # 2.0f

    if-eqz v0, :cond_5

    const/high16 v3, -0x5a000000

    invoke-virtual {v11, v3}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v12

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v4, v12

    iget-boolean v5, p0, Lc/l2;->b:Z

    const/16 v6, 0xe

    const/16 v7, 0x36

    if-eqz v5, :cond_1

    move v8, v7

    goto :goto_0

    :cond_1
    move v8, v6

    :goto_0
    int-to-float v8, v8

    mul-float/2addr v8, v1

    sub-float v8, v3, v8

    if-eqz v5, :cond_2

    move v9, v6

    goto :goto_1

    :cond_2
    move v9, v7

    :goto_1
    int-to-float v9, v9

    mul-float/2addr v9, v1

    sub-float v9, v4, v9

    if-eqz v5, :cond_3

    move v10, v7

    goto :goto_2

    :cond_3
    move v10, v6

    :goto_2
    int-to-float v10, v10

    mul-float/2addr v10, v1

    add-float/2addr v10, v3

    if-eqz v5, :cond_4

    goto :goto_3

    :cond_4
    move v6, v7

    :goto_3
    int-to-float v3, v6

    mul-float/2addr v3, v1

    add-float v7, v3, v4

    const/high16 v3, 0x41600000    # 14.0f

    mul-float v13, v1, v3

    move-object v3, p1

    move v4, v8

    move v5, v9

    move v6, v10

    move v8, v13

    move v9, v13

    move-object v10, v11

    invoke-virtual/range {v3 .. v10}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    :cond_5
    iget-boolean v3, p0, Lc/l2;->c:Z

    if-eqz v3, :cond_6

    iget v2, v2, Lc/r4;->f:I

    goto :goto_5

    :cond_6
    iget-boolean v2, v2, Lc/r4;->m:Z

    if-eqz v2, :cond_7

    const/16 v2, 0xc1

    const/16 v3, 0xae

    const/16 v4, 0xba

    :goto_4
    invoke-static {v3, v4, v2}, Landroid/graphics/Color;->rgb(III)I

    move-result v2

    goto :goto_5

    :cond_7
    const/16 v2, 0xf0

    const/16 v3, 0xec

    const/16 v4, 0xf1

    goto :goto_4

    :goto_5
    invoke-virtual {v11, v2}, Landroid/graphics/Paint;->setColor(I)V

    if-eqz v0, :cond_8

    const/4 v0, -0x1

    invoke-virtual {v11, v0}, Landroid/graphics/Paint;->setColor(I)V

    :cond_8
    iget-boolean v0, p0, Lc/l2;->b:Z

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v4, 0x2a

    if-eqz v0, :cond_9

    move v5, v4

    goto :goto_6

    :cond_9
    iget-boolean v5, p0, Lc/l2;->c:Z

    if-eqz v5, :cond_a

    move v5, v3

    goto :goto_6

    :cond_a
    move v5, v2

    :goto_6
    int-to-float v5, v5

    mul-float/2addr v5, v1

    if-eqz v0, :cond_b

    iget-boolean v0, p0, Lc/l2;->c:Z

    if-eqz v0, :cond_c

    move v2, v3

    goto :goto_7

    :cond_b
    move v2, v4

    :cond_c
    :goto_7
    int-to-float v0, v2

    mul-float/2addr v0, v1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v12

    sub-float v4, v2, v5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v12

    sub-float/2addr v2, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v12

    add-float v6, v3, v5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v3, v12

    add-float v7, v3, v0

    const/high16 v0, 0x40400000    # 3.0f

    mul-float v9, v1, v0

    move-object v3, p1

    move v5, v2

    move v8, v9

    move-object v10, v11

    invoke-virtual/range {v3 .. v10}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    return-void
.end method
