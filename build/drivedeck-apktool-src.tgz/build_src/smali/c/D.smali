.class public final synthetic Lc/D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/F;


# direct methods
.method public synthetic constructor <init>(Lc/F;I)V
    .locals 0

    iput p2, p0, Lc/D;->a:I

    iput-object p1, p0, Lc/D;->b:Lc/F;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lc/D;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/D;->b:Lc/F;

    iget-boolean v1, v0, Lc/F;->e:Z

    if-nez v1, :cond_0

    iget-boolean v1, v0, Lc/F;->f:Z

    if-nez v1, :cond_0

    iget-boolean v1, v0, Lc/F;->d:Z

    if-nez v1, :cond_0

    iget-boolean v1, v0, Lc/F;->b:Z

    if-nez v1, :cond_0

    iget-boolean v1, v0, Lc/F;->n:Z

    if-nez v1, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Lc/n1;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Lc/n1;->f0()Z

    move-result v1

    if-eqz v1, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/F;->s(Z)V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/D;->b:Lc/F;

    iget-boolean v1, v0, Lc/F;->g:Z

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/F;->a:Z

    iget-object v2, v0, Lc/F;->l:Landroid/view/View;

    const/4 v3, 0x4

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    iget-object v2, v0, Lc/F;->l:Landroid/view/View;

    check-cast v2, Lc/b2;

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Lc/E;

    const/4 v4, 0x0

    invoke-direct {v3, v2, v4}, Lc/E;-><init>(Lc/b2;I)V

    const-wide/16 v4, 0x20

    invoke-virtual {v2, v3, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {v0, v1}, Lc/F;->o(Z)V

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :goto_0
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
