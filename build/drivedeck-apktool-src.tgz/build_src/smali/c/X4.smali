.class public final synthetic Lc/X4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/a5;


# direct methods
.method public synthetic constructor <init>(Lc/a5;I)V
    .locals 0

    iput p2, p0, Lc/X4;->a:I

    iput-object p1, p0, Lc/X4;->b:Lc/a5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/X4;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/X4;->b:Lc/a5;

    invoke-virtual {v0}, Lc/a5;->g()V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/X4;->b:Lc/a5;

    iget v1, v0, Lc/a5;->i:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lc/a5;->b(IZ)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/X4;->b:Lc/a5;

    iget v1, v0, Lc/a5;->i:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lc/a5;->b(IZ)V

    return-void

    :pswitch_2
    const/4 v0, 0x1

    iget-object v1, p0, Lc/X4;->b:Lc/a5;

    invoke-virtual {v1, v0}, Lc/a5;->e(Z)V

    return-void

    :pswitch_3
    const/4 v0, 0x0

    iget-object v1, p0, Lc/X4;->b:Lc/a5;

    invoke-virtual {v1, v0}, Lc/a5;->e(Z)V

    return-void

    :pswitch_4
    const/4 v0, 0x0

    iget-object v1, p0, Lc/X4;->b:Lc/a5;

    invoke-virtual {v1, v0, v0}, Lc/a5;->b(IZ)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
