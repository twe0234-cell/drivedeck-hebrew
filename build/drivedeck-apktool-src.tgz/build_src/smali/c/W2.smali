.class public final Lc/W2;
.super Landroid/view/View;
.source "SourceFile"


# instance fields
.field public final a:Landroid/graphics/Paint;

.field public final synthetic b:F

.field public final synthetic c:Lc/k3;


# direct methods
.method public constructor <init>(Lc/k3;Lru/drivedeck/launcher/MainActivity;F)V
    .locals 0

    iput-object p1, p0, Lc/W2;->c:Lc/k3;

    iput p3, p0, Lc/W2;->b:F

    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lc/W2;->a:Landroid/graphics/Paint;

    return-void
.end method


# virtual methods
.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 14

    iget-object v8, p0, Lc/W2;->a:Landroid/graphics/Paint;

    iget-object v9, p0, Lc/W2;->c:Lc/k3;

    iget-object v0, v9, Lc/k3;->g:Lc/r4;

    iget v0, v0, Lc/r4;->d:I

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v0, 0x3fc00000    # 1.5f

    invoke-virtual {v9, v0}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/high16 v10, 0x41800000    # 16.0f

    invoke-virtual {v9, v10}, Lc/k3;->x(F)I

    move-result v1

    sub-int/2addr v0, v1

    int-to-float v0, v0

    const/high16 v11, 0x40000000    # 2.0f

    div-float v12, v0, v11

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-virtual {v9, v13}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v1, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    invoke-virtual {v9, v13}, Lc/k3;->x(F)I

    move-result v2

    sub-int/2addr v0, v2

    int-to-float v3, v0

    invoke-virtual {v9, v10}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v0, v0

    add-float v4, v12, v0

    const/high16 v0, 0x40400000    # 3.0f

    invoke-virtual {v9, v0}, Lc/k3;->x(F)I

    move-result v2

    int-to-float v5, v2

    invoke-virtual {v9, v0}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v6, v0

    move-object v0, p1

    move v2, v12

    move-object v7, v8

    invoke-virtual/range {v0 .. v7}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    invoke-virtual {v9, v13}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v9, v11}, Lc/k3;->x(F)I

    move-result v2

    sub-int/2addr v1, v2

    int-to-float v1, v1

    iget v2, p0, Lc/W2;->b:F

    mul-float/2addr v1, v2

    add-float v3, v1, v0

    invoke-virtual {v9, v10}, Lc/k3;->x(F)I

    move-result v0

    int-to-float v0, v0

    add-float v4, v12, v0

    move-object v0, p1

    move v1, v3

    move v2, v12

    move-object v5, v8

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method
