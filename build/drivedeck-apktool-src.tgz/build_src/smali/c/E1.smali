.class public final synthetic Lc/E1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/N1;

.field public final synthetic c:J


# direct methods
.method public synthetic constructor <init>(JLc/N1;)V
    .locals 1

    .line 1
    const/4 v0, 0x3

    iput v0, p0, Lc/E1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lc/E1;->c:J

    iput-object p3, p0, Lc/E1;->b:Lc/N1;

    return-void
.end method

.method public synthetic constructor <init>(Lc/N1;JI)V
    .locals 0

    .line 2
    iput p4, p0, Lc/E1;->a:I

    iput-object p1, p0, Lc/E1;->b:Lc/N1;

    iput-wide p2, p0, Lc/E1;->c:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 6

    iget v0, p0, Lc/E1;->a:I

    packed-switch v0, :pswitch_data_0

    iget-wide v0, p0, Lc/E1;->c:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const-string v1, "duration_ms"

    filled-new-array {v1, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "timed_collection_started"

    invoke-static {v1, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, p0, Lc/E1;->b:Lc/N1;

    invoke-virtual {v0}, Lc/N1;->w()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/N1;->l(Z)V

    invoke-virtual {v0}, Lc/N1;->y()V

    const/4 v0, 0x0

    invoke-static {v0, v1}, Lc/N1;->D(Lc/H;Z)V

    return-void

    :pswitch_0
    iget-object v0, p0, Lc/E1;->b:Lc/N1;

    iget-wide v1, p0, Lc/E1;->c:J

    iget-object v3, v0, Lc/N1;->k:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v3

    cmp-long v3, v1, v3

    if-eqz v3, :cond_0

    goto :goto_1

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {v0, v3}, Lc/N1;->l(Z)V

    iget-object v3, v0, Lc/N1;->F:Ljava/lang/Object;

    monitor-enter v3

    :try_start_0
    iget-object v4, v0, Lc/N1;->k:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    cmp-long v1, v1, v4

    if-eqz v1, :cond_1

    monitor-exit v3

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_1
    iget-object v1, v0, Lc/N1;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iput-boolean v2, v0, Lc/N1;->L:Z

    iput-boolean v2, v0, Lc/N1;->K:Z

    const-wide/16 v4, 0x0

    iput-wide v4, v0, Lc/N1;->N:J

    iget-object v1, v0, Lc/N1;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v4, "enabled"

    invoke-interface {v1, v4, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v4, "send_consent"

    invoke-interface {v1, v4, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v4, "timed_until"

    invoke-interface {v1, v4}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v1, v0, Lc/N1;->m:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget v1, v0, Lc/N1;->Q:I

    if-nez v1, :cond_2

    const-string v1, "\u0421\u0431\u043e\u0440 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d"

    goto :goto_0

    :cond_2
    const-string v1, "\u0421\u0431\u043e\u0440 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d; \u043e\u0442\u0447\u0451\u0442\u044b \u0433\u043e\u0442\u043e\u0432\u044b \u043a \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0435"

    :goto_0
    iput-object v1, v0, Lc/N1;->R:Ljava/lang/String;

    iget-object v1, v0, Lc/N1;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    sget-object v1, Lc/N1;->W:Landroid/os/Handler;

    new-instance v2, Lc/D1;

    const/4 v3, 0x6

    invoke-direct {v2, v0, v3}, Lc/D1;-><init>(Lc/N1;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-virtual {v0}, Lc/N1;->y()V

    :goto_1
    return-void

    :goto_2
    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :pswitch_1
    iget-object v0, p0, Lc/E1;->b:Lc/N1;

    iget-wide v1, p0, Lc/E1;->c:J

    iget-object v3, v0, Lc/N1;->F:Ljava/lang/Object;

    monitor-enter v3

    :try_start_2
    iget-wide v4, v0, Lc/N1;->H:J

    cmp-long v1, v1, v4

    if-nez v1, :cond_4

    iget-boolean v1, v0, Lc/N1;->K:Z

    if-nez v1, :cond_4

    iget-wide v1, v0, Lc/N1;->N:J

    const-wide/16 v4, 0x0

    cmp-long v1, v1, v4

    if-eqz v1, :cond_3

    goto :goto_3

    :cond_3
    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    new-instance v1, Lc/D1;

    const/4 v2, 0x6

    invoke-direct {v1, v0, v2}, Lc/D1;-><init>(Lc/N1;I)V

    invoke-virtual {v1}, Lc/D1;->run()V

    goto :goto_4

    :catchall_1
    move-exception v0

    goto :goto_5

    :cond_4
    :goto_3
    :try_start_3
    monitor-exit v3

    :goto_4
    return-void

    :goto_5
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v0

    :pswitch_2
    iget-object v0, p0, Lc/E1;->b:Lc/N1;

    iget-wide v1, v0, Lc/N1;->H:J

    iget-wide v3, p0, Lc/E1;->c:J

    invoke-virtual {v0, v1, v2, v3, v4}, Lc/N1;->i(JJ)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
