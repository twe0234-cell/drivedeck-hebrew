.class public final synthetic Lc/d1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:Lc/g1;

.field public final synthetic b:Ljava/util/ArrayList;

.field public final synthetic c:Lc/f1;


# direct methods
.method public synthetic constructor <init>(Lc/g1;Ljava/util/ArrayList;Lc/f1;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/d1;->a:Lc/g1;

    iput-object p2, p0, Lc/d1;->b:Ljava/util/ArrayList;

    iput-object p3, p0, Lc/d1;->c:Lc/f1;

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 22

    move-object/from16 v0, p0

    move/from16 v1, p3

    iget-object v2, v0, Lc/d1;->a:Lc/g1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v0, Lc/d1;->b:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/s0;

    sget-object v5, Lc/s0;->f:Lc/s0;

    if-ne v4, v5, :cond_0

    goto/16 :goto_f

    :cond_0
    invoke-static {v4}, Lc/u0;->j(Lc/s0;)Lc/r0;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v5

    sget-object v7, Lc/s0;->l:Lc/s0;

    sget-object v8, Lc/s0;->j:Lc/s0;

    iget-object v10, v2, Lc/g1;->a:Lc/P3;

    iget-object v11, v5, Lc/r0;->a:Lc/s0;

    if-ne v11, v7, :cond_1

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    iget-object v11, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v11, v5}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v5

    iget-object v11, v2, Lc/g1;->F:Lc/o0;

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-virtual {v2, v12}, Lc/g1;->h(F)F

    move-result v12

    iget-object v13, v2, Lc/g1;->b:Lc/n1;

    invoke-static {v7, v13, v5, v11, v12}, Lc/G0;->f(Landroid/content/Context;Lc/n1;Lc/u0;Lc/o0;F)Lc/u0;

    move-result-object v5

    goto/16 :goto_e

    :cond_1
    const/16 v7, 0x1e

    const/4 v12, 0x2

    if-ne v11, v8, :cond_6

    iget-object v5, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v5, v8}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v11

    invoke-static {v8}, Lc/u0;->j(Lc/s0;)Lc/r0;

    move-result-object v14

    if-nez v11, :cond_2

    move-object v11, v14

    goto :goto_0

    :cond_2
    invoke-virtual {v11, v6}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v11

    :goto_0
    filled-new-array {v11, v14}, [Lc/r0;

    move-result-object v11

    move v14, v6

    :goto_1
    if-ge v14, v12, :cond_19

    aget-object v15, v11, v14

    iget v13, v15, Lc/r0;->e:I

    rsub-int/lit8 v13, v13, 0x1e

    iget v7, v15, Lc/r0;->c:I

    invoke-static {v13, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v7

    iget v13, v5, Lc/u0;->a:I

    iget v9, v15, Lc/r0;->f:I

    sub-int/2addr v13, v9

    iget v9, v15, Lc/r0;->d:I

    invoke-static {v13, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v6, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    invoke-virtual {v15, v7, v9}, Lc/r0;->a(II)Lc/r0;

    move-result-object v7

    invoke-virtual {v5, v7}, Lc/u0;->a(Lc/r0;)Z

    move-result v9

    if-eqz v9, :cond_3

    invoke-virtual {v5, v7}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v5

    goto/16 :goto_e

    :cond_3
    invoke-virtual {v5, v7}, Lc/u0;->e(Lc/r0;)Lc/r0;

    move-result-object v9

    if-eqz v9, :cond_4

    invoke-virtual {v5, v9}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v5

    goto/16 :goto_e

    :cond_4
    invoke-virtual {v5, v7}, Lc/u0;->p(Lc/r0;)Lc/u0;

    move-result-object v7

    if-eqz v7, :cond_5

    move-object v5, v7

    goto/16 :goto_e

    :cond_5
    add-int/lit8 v14, v14, 0x1

    const/16 v7, 0x1e

    goto :goto_1

    :cond_6
    sget-object v7, Lc/s0;->k:Lc/s0;

    const/16 v9, 0xc

    if-eq v11, v7, :cond_10

    sget-object v7, Lc/s0;->h:Lc/s0;

    if-ne v11, v7, :cond_7

    goto/16 :goto_7

    :cond_7
    iget-object v7, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-array v12, v12, [I

    const/4 v13, 0x1

    const/16 v14, 0x1e

    aput v14, v12, v13

    iget v13, v7, Lc/u0;->a:I

    aput v13, v12, v6

    sget-object v14, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    invoke-static {v14, v12}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;[I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, [[Z

    iget-object v7, v7, Lc/u0;->d:Ljava/lang/Object;

    check-cast v7, Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_8
    :goto_2
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_9

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lc/r0;

    iget-object v15, v14, Lc/r0;->a:Lc/s0;

    if-eq v15, v11, :cond_8

    iget-boolean v15, v14, Lc/r0;->g:Z

    if-nez v15, :cond_8

    invoke-static {v12, v14}, Lc/u0;->k([[ZLc/r0;)V

    goto :goto_2

    :cond_9
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lc/s0;->a()I

    move-result v7

    const/4 v14, 0x7

    const/16 v15, 0x1e

    invoke-static {v15, v14}, Ljava/lang/Math;->min(II)I

    move-result v14

    invoke-static {v7, v14}, Ljava/lang/Math;->max(II)I

    move-result v7

    invoke-virtual {v11}, Lc/s0;->b()I

    move-result v11

    const/16 v14, 0x48

    invoke-static {v14, v9}, Ljava/lang/Math;->min(II)I

    move-result v9

    invoke-static {v11, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    const/4 v11, -0x1

    iget v14, v5, Lc/r0;->f:I

    move v15, v14

    const/16 v16, 0x0

    :goto_3
    invoke-static {v14, v9}, Ljava/lang/Math;->min(II)I

    move-result v6

    if-lt v15, v6, :cond_e

    iget v6, v5, Lc/r0;->e:I

    move/from16 p2, v9

    move/from16 v17, v11

    move v9, v6

    :goto_4
    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v11

    if-lt v9, v11, :cond_d

    move/from16 v18, v6

    const/4 v11, 0x0

    :goto_5
    sub-int v6, v13, v15

    if-gt v11, v6, :cond_c

    move/from16 v19, v7

    move/from16 v7, v17

    const/4 v6, 0x0

    :goto_6
    move/from16 v20, v13

    rsub-int/lit8 v13, v9, 0x1e

    if-gt v6, v13, :cond_b

    invoke-virtual {v5, v9, v15}, Lc/r0;->c(II)Lc/r0;

    move-result-object v13

    invoke-virtual {v13, v6, v11}, Lc/r0;->a(II)Lc/r0;

    move-result-object v13

    move/from16 v21, v14

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Lc/r0;->b(Z)Lc/r0;

    move-result-object v13

    iget v14, v13, Lc/r0;->e:I

    iget v0, v13, Lc/r0;->f:I

    mul-int/2addr v14, v0

    if-le v14, v7, :cond_a

    invoke-static {v12, v13}, Lc/u0;->f([[ZLc/r0;)Z

    move-result v0

    if-eqz v0, :cond_a

    move-object/from16 v16, v13

    move v7, v14

    :cond_a
    add-int/lit8 v6, v6, 0x1

    move-object/from16 v0, p0

    move/from16 v13, v20

    move/from16 v14, v21

    goto :goto_6

    :cond_b
    move/from16 v21, v14

    add-int/lit8 v11, v11, 0x1

    move-object/from16 v0, p0

    move/from16 v17, v7

    move/from16 v7, v19

    move/from16 v13, v20

    goto :goto_5

    :cond_c
    move/from16 v19, v7

    move/from16 v20, v13

    move/from16 v21, v14

    add-int/lit8 v9, v9, -0x1

    move-object/from16 v0, p0

    move/from16 v6, v18

    goto :goto_4

    :cond_d
    move/from16 v19, v7

    move/from16 v20, v13

    move/from16 v21, v14

    add-int/lit8 v15, v15, -0x1

    move-object/from16 v0, p0

    move/from16 v9, p2

    move/from16 v11, v17

    goto :goto_3

    :cond_e
    move-object/from16 v0, v16

    if-eqz v0, :cond_19

    invoke-virtual {v2, v0}, Lc/g1;->e(Lc/r0;)Z

    move-result v5

    if-nez v5, :cond_f

    goto/16 :goto_d

    :cond_f
    iget-object v5, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v5, v0}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v0

    move-object v5, v0

    goto/16 :goto_e

    :cond_10
    :goto_7
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v13, 0x1

    :goto_8
    iget-object v6, v2, Lc/g1;->F:Lc/o0;

    iget v6, v6, Lc/o0;->h:I

    if-gt v13, v6, :cond_17

    const/4 v6, 0x1

    :goto_9
    const/16 v7, 0x1e

    if-gt v6, v7, :cond_16

    invoke-virtual {v5, v6, v13}, Lc/r0;->c(II)Lc/r0;

    move-result-object v7

    invoke-virtual {v2, v7}, Lc/g1;->e(Lc/r0;)Z

    move-result v11

    if-nez v11, :cond_11

    goto :goto_c

    :cond_11
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v11

    if-ge v11, v9, :cond_12

    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_12
    const/4 v11, 0x0

    :goto_a
    iget-object v12, v2, Lc/g1;->F:Lc/o0;

    iget v12, v12, Lc/o0;->h:I

    sub-int/2addr v12, v13

    if-gt v11, v12, :cond_15

    const/4 v12, 0x0

    :goto_b
    rsub-int/lit8 v14, v6, 0x1e

    if-gt v12, v14, :cond_14

    invoke-virtual {v7, v12, v11}, Lc/r0;->a(II)Lc/r0;

    move-result-object v14

    iget-object v15, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v15, v14}, Lc/u0;->a(Lc/r0;)Z

    move-result v15

    if-eqz v15, :cond_13

    iget-object v0, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v0, v14}, Lc/u0;->s(Lc/r0;)Lc/u0;

    move-result-object v5

    goto :goto_e

    :cond_13
    add-int/lit8 v12, v12, 0x1

    goto :goto_b

    :cond_14
    add-int/lit8 v11, v11, 0x1

    goto :goto_a

    :cond_15
    :goto_c
    add-int/lit8 v6, v6, 0x1

    goto :goto_9

    :cond_16
    add-int/lit8 v13, v13, 0x1

    goto :goto_8

    :cond_17
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_18
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_19

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/r0;

    iget-object v7, v2, Lc/g1;->C:Lc/u0;

    iget v9, v6, Lc/r0;->e:I

    const/16 v11, 0x1e

    rsub-int/lit8 v9, v9, 0x1e

    iget v12, v5, Lc/r0;->c:I

    invoke-static {v9, v12}, Ljava/lang/Math;->min(II)I

    move-result v9

    const/4 v12, 0x0

    invoke-static {v12, v9}, Ljava/lang/Math;->max(II)I

    move-result v9

    iget-object v13, v2, Lc/g1;->F:Lc/o0;

    iget v13, v13, Lc/o0;->h:I

    iget v14, v6, Lc/r0;->f:I

    sub-int/2addr v13, v14

    iget v14, v5, Lc/r0;->d:I

    invoke-static {v13, v14}, Ljava/lang/Math;->min(II)I

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->max(II)I

    move-result v13

    invoke-virtual {v6, v9, v13}, Lc/r0;->a(II)Lc/r0;

    move-result-object v6

    invoke-virtual {v7, v6}, Lc/u0;->p(Lc/r0;)Lc/u0;

    move-result-object v6

    if-eqz v6, :cond_18

    move-object v5, v6

    goto :goto_e

    :cond_19
    :goto_d
    const/4 v5, 0x0

    :goto_e
    if-nez v5, :cond_1b

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v10}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const-string v2, "\u041e\u0441\u0432\u043e\u0431\u043e\u0434\u0438\u0442\u0435 \u043c\u0435\u0441\u0442\u043e: \u0443\u043c\u0435\u043d\u044c\u0448\u0438\u0442\u0435 \u043e\u0434\u0438\u043d \u0438\u0437 \u0432\u0438\u0434\u0436\u0435\u0442\u043e\u0432"

    invoke-static {v1, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    invoke-static {v0, v1, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_1a
    :goto_f
    move-object/from16 v0, p0

    goto :goto_10

    :cond_1b
    const/4 v0, 0x1

    const/4 v6, 0x0

    iput-boolean v0, v2, Lc/g1;->J:Z

    if-ne v4, v8, :cond_1c

    move v6, v0

    :cond_1c
    invoke-virtual {v2, v5, v6}, Lc/g1;->t(Lc/u0;Z)V

    iget-object v0, v2, Lc/g1;->C:Lc/u0;

    invoke-virtual {v0, v4}, Lc/u0;->d(Lc/s0;)Lc/r0;

    move-result-object v0

    if-eqz v0, :cond_1a

    iget-boolean v0, v0, Lc/r0;->g:Z

    if-nez v0, :cond_1a

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/d1;->c:Lc/f1;

    invoke-virtual {v1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :goto_10
    return-void
.end method
