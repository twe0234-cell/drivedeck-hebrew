.class public final synthetic Lc/S7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Landroid/content/ServiceConnection;

.field public final synthetic c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Landroid/os/IBinder;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:I

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/I;ILjava/util/function/BooleanSupplier;Landroid/os/IBinder;ILandroid/content/Context;Lc/H;)V
    .locals 1

    .line 1
    const/4 v0, 0x2

    iput v0, p0, Lc/S7;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/S7;->b:Landroid/content/ServiceConnection;

    iput p2, p0, Lc/S7;->c:I

    iput-object p3, p0, Lc/S7;->d:Ljava/lang/Object;

    iput-object p4, p0, Lc/S7;->e:Landroid/os/IBinder;

    iput p5, p0, Lc/S7;->g:I

    iput-object p6, p0, Lc/S7;->h:Ljava/lang/Object;

    iput-object p7, p0, Lc/S7;->f:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Lc/Z7;ILjava/lang/String;Landroid/os/IBinder;Ljava/util/function/Consumer;ILjava/lang/String;I)V
    .locals 0

    .line 2
    iput p8, p0, Lc/S7;->a:I

    iput-object p1, p0, Lc/S7;->b:Landroid/content/ServiceConnection;

    iput p2, p0, Lc/S7;->c:I

    iput-object p3, p0, Lc/S7;->d:Ljava/lang/Object;

    iput-object p4, p0, Lc/S7;->e:Landroid/os/IBinder;

    iput-object p5, p0, Lc/S7;->f:Ljava/lang/Object;

    iput p6, p0, Lc/S7;->g:I

    iput-object p7, p0, Lc/S7;->h:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget v2, p0, Lc/S7;->a:I

    packed-switch v2, :pswitch_data_0

    iget-object v2, p0, Lc/S7;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/I;

    iget-boolean v3, v2, Lc/I;->a:Z

    if-nez v3, :cond_0

    sget-object v3, Lc/J;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    iget v4, p0, Lc/S7;->c:I

    if-ne v4, v3, :cond_0

    iget-object v3, p0, Lc/S7;->d:Ljava/lang/Object;

    check-cast v3, Ljava/util/function/BooleanSupplier;

    invoke-interface {v3}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result v3

    if-eqz v3, :cond_0

    move v0, v1

    :cond_0
    if-eqz v0, :cond_1

    iget-object v3, p0, Lc/S7;->e:Landroid/os/IBinder;

    iget v4, p0, Lc/S7;->g:I

    invoke-static {v3, v4}, Lc/J;->a(Landroid/os/IBinder;I)V

    :cond_1
    iget-object v3, p0, Lc/S7;->h:Ljava/lang/Object;

    check-cast v3, Landroid/content/Context;

    iget-boolean v4, v2, Lc/I;->a:Z

    if-eqz v4, :cond_2

    goto :goto_0

    :cond_2
    iput-boolean v1, v2, Lc/I;->a:Z

    :try_start_0
    invoke-virtual {v3, v2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/S7;->f:Ljava/lang/Object;

    check-cast v0, Lc/H;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lc/H;->run()V

    :cond_3
    return-void

    :pswitch_0
    iget-object v2, p0, Lc/S7;->b:Landroid/content/ServiceConnection;

    check-cast v2, Lc/Z7;

    iget v3, p0, Lc/S7;->c:I

    iget-object v4, p0, Lc/S7;->d:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    iget-object v5, p0, Lc/S7;->e:Landroid/os/IBinder;

    iget-object v6, p0, Lc/S7;->f:Ljava/lang/Object;

    check-cast v6, Ljava/util/function/Consumer;

    iget v7, p0, Lc/S7;->g:I

    iget-object v8, p0, Lc/S7;->h:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_1
    iget-boolean v9, v2, Lc/Z7;->r:Z

    if-nez v9, :cond_a

    iget v9, v2, Lc/Z7;->C:I

    if-ne v3, v9, :cond_a

    iget-object v3, v2, Lc/Z7;->a:Lc/e8;

    iget-object v3, v3, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_a

    if-eqz v5, :cond_4

    iget-object v3, v2, Lc/Z7;->k:Landroid/os/IBinder;

    if-eq v5, v3, :cond_4

    goto/16 :goto_2

    :cond_4
    if-eqz v5, :cond_5

    iget-object v3, v2, Lc/Z7;->k:Landroid/os/IBinder;

    if-ne v5, v3, :cond_5

    invoke-static {v5, v7, v8}, Lc/Z7;->p(Landroid/os/IBinder;ILjava/lang/String;)Z

    move-result v0

    goto/16 :goto_3

    :cond_5
    invoke-virtual {v2, v4}, Lc/Z7;->a(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;

    move-result-object v3

    iget-object v5, v2, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    if-eqz v3, :cond_b

    if-eqz v5, :cond_b

    invoke-virtual {v3}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4
    :try_end_1
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    if-eqz v4, :cond_b

    const/4 v4, 0x7

    const-class v9, Landroid/bluetooth/BluetoothDevice;

    if-ne v7, v4, :cond_6

    :try_start_2
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v7, "dial"

    const-class v10, Ljava/lang/String;

    filled-new-array {v9, v10}, [Ljava/lang/Class;

    move-result-object v9

    invoke-virtual {v4, v7, v9}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    filled-new-array {v3, v8}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v4, v5, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_1

    :cond_6
    const/16 v4, 0x9

    if-ne v7, v4, :cond_7

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v7, "acceptCall"

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    filled-new-array {v9, v8}, [Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v4, v7, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v3, v7}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v4, v5, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_1

    :cond_7
    const/16 v4, 0xb

    if-ne v7, v4, :cond_8

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v7, "rejectCall"

    filled-new-array {v9}, [Ljava/lang/Class;

    move-result-object v8

    invoke-virtual {v4, v7, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v4, v5, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    goto :goto_1

    :cond_8
    const-string v4, "android.bluetooth.BluetoothHeadsetClientCall"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    const-string v8, "terminateCall"

    filled-new-array {v9, v4}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v7, v8, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v7, 0x0

    filled-new-array {v3, v7}, [Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v4, v5, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    :goto_1
    instance-of v4, v3, Ljava/lang/Boolean;

    if-eqz v4, :cond_9

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    goto :goto_3

    :cond_9
    if-eqz v3, :cond_b

    move v0, v1

    goto :goto_3

    :cond_a
    :goto_2
    iget-object v3, v2, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v4, Lc/F7;

    invoke-direct {v4, v2, v6, v1}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_4

    :catch_1
    :cond_b
    :goto_3
    iget-object v1, v2, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v3, Lc/H1;

    const/4 v4, 0x4

    invoke-direct {v3, v2, v6, v0, v4}, Lc/H1;-><init>(Ljava/lang/Object;Ljava/lang/Object;ZI)V

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_4
    return-void

    :pswitch_1
    iget-object v0, p0, Lc/S7;->b:Landroid/content/ServiceConnection;

    check-cast v0, Lc/Z7;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Lc/S7;

    iget-object v1, p0, Lc/S7;->f:Ljava/lang/Object;

    move-object v6, v1

    check-cast v6, Ljava/util/function/Consumer;

    iget v7, p0, Lc/S7;->g:I

    iget-object v1, p0, Lc/S7;->h:Ljava/lang/Object;

    move-object v8, v1

    check-cast v8, Ljava/lang/String;

    iget v3, p0, Lc/S7;->c:I

    iget-object v1, p0, Lc/S7;->d:Ljava/lang/Object;

    move-object v4, v1

    check-cast v4, Ljava/lang/String;

    iget-object v5, p0, Lc/S7;->e:Landroid/os/IBinder;

    const/4 v9, 0x1

    move-object v1, v10

    move-object v2, v0

    invoke-direct/range {v1 .. v9}, Lc/S7;-><init>(Lc/Z7;ILjava/lang/String;Landroid/os/IBinder;Ljava/util/function/Consumer;ILjava/lang/String;I)V

    iget-object v0, v0, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v10}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
