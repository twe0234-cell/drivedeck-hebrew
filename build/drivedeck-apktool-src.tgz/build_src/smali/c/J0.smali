.class public final synthetic Lc/J0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/j6;

.field public final synthetic c:Lc/n1;

.field public final synthetic d:Ljava/util/LinkedHashMap;

.field public final synthetic e:Ljava/util/function/BooleanSupplier;

.field public final synthetic f:Ljava/util/LinkedHashMap;

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/io/Serializable;


# direct methods
.method public synthetic constructor <init>(Lc/T5;Lc/j6;Lc/n1;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;[ZLjava/util/LinkedHashMap;Ljava/util/LinkedHashMap;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, Lc/J0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J0;->g:Ljava/lang/Object;

    iput-object p2, p0, Lc/J0;->b:Lc/j6;

    iput-object p3, p0, Lc/J0;->c:Lc/n1;

    iput-object p4, p0, Lc/J0;->d:Ljava/util/LinkedHashMap;

    iput-object p5, p0, Lc/J0;->e:Ljava/util/function/BooleanSupplier;

    iput-object p6, p0, Lc/J0;->h:Ljava/lang/Object;

    iput-object p7, p0, Lc/J0;->f:Ljava/util/LinkedHashMap;

    iput-object p8, p0, Lc/J0;->i:Ljava/io/Serializable;

    return-void
.end method

.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;Landroid/app/Dialog;Lc/n1;Lc/j6;Ljava/lang/String;Ljava/util/LinkedHashMap;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;)V
    .locals 1

    .line 2
    const/4 v0, 0x0

    iput v0, p0, Lc/J0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/J0;->g:Ljava/lang/Object;

    iput-object p2, p0, Lc/J0;->h:Ljava/lang/Object;

    iput-object p3, p0, Lc/J0;->c:Lc/n1;

    iput-object p4, p0, Lc/J0;->b:Lc/j6;

    iput-object p5, p0, Lc/J0;->i:Ljava/io/Serializable;

    iput-object p6, p0, Lc/J0;->d:Ljava/util/LinkedHashMap;

    iput-object p7, p0, Lc/J0;->f:Ljava/util/LinkedHashMap;

    iput-object p8, p0, Lc/J0;->e:Ljava/util/function/BooleanSupplier;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 11

    iget p1, p0, Lc/J0;->a:I

    packed-switch p1, :pswitch_data_0

    iget-object p1, p0, Lc/J0;->g:Ljava/lang/Object;

    check-cast p1, Lc/T5;

    iget-object v0, p1, Lc/T5;->g:Lc/j6;

    iget-object v1, p0, Lc/J0;->b:Lc/j6;

    if-eq v0, v1, :cond_0

    goto/16 :goto_5

    :cond_0
    iget-object v0, p0, Lc/J0;->c:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->z()I

    move-result v1

    invoke-virtual {p1}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v2

    sget v3, Lc/G0;->K:I

    invoke-virtual {v0, v3}, Lc/n1;->N0(I)V

    iget-object v3, p0, Lc/J0;->d:Ljava/util/LinkedHashMap;

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v6, 0x1

    const-string v7, "sensor:"

    const/4 v8, 0x7

    if-eqz v5, :cond_2

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v5, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_1

    invoke-virtual {v5, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p1, v6, v5}, Lc/T5;->c1(ZLjava/lang/String;)V

    goto :goto_0

    :cond_2
    iget-object v4, p0, Lc/J0;->e:Ljava/util/function/BooleanSupplier;

    invoke-interface {v4}, Ljava/util/function/BooleanSupplier;->getAsBoolean()Z

    move-result v4

    if-nez v4, :cond_4

    invoke-virtual {v0, v1}, Lc/n1;->N0(I)V

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_3
    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3

    invoke-virtual {v4, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    invoke-virtual {p1, v4, v5}, Lc/T5;->c1(ZLjava/lang/String;)V

    goto :goto_1

    :cond_4
    invoke-virtual {v0}, Lc/n1;->z()I

    move-result v0

    invoke-virtual {p1}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object p1

    iget-object v1, p0, Lc/J0;->h:Ljava/lang/Object;

    check-cast v1, [Z

    const/4 v2, 0x0

    aput-boolean v6, v1, v2

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_2
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_8

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-virtual {v4, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-interface {p1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    goto :goto_3

    :cond_5
    invoke-static {v4}, Lc/F0;->valueOf(Ljava/lang/String;)Lc/F0;

    move-result-object v5

    invoke-virtual {v5}, Lc/F0;->a()I

    move-result v5

    and-int/2addr v5, v0

    if-eqz v5, :cond_6

    move v5, v6

    goto :goto_3

    :cond_6
    move v5, v2

    :goto_3
    iget-object v9, p0, Lc/J0;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v9, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/widget/Switch;

    invoke-virtual {v9, v5}, Landroid/widget/Switch;->setChecked(Z)V

    iget-object v9, p0, Lc/J0;->i:Ljava/io/Serializable;

    check-cast v9, Ljava/util/LinkedHashMap;

    invoke-virtual {v9, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    invoke-virtual {v10, v5}, Landroid/widget/TextView;->setEnabled(Z)V

    invoke-virtual {v9, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/widget/TextView;

    if-eqz v5, :cond_7

    const/high16 v5, 0x3f800000    # 1.0f

    goto :goto_4

    :cond_7
    const v5, 0x3ecccccd    # 0.4f

    :goto_4
    invoke-virtual {v4, v5}, Landroid/view/View;->setAlpha(F)V

    goto :goto_2

    :cond_8
    aput-boolean v2, v1, v2

    :goto_5
    return-void

    :pswitch_0
    iget-object p1, p0, Lc/J0;->h:Ljava/lang/Object;

    move-object v1, p1

    check-cast v1, Landroid/app/Dialog;

    iget-object v2, p0, Lc/J0;->c:Lc/n1;

    iget-object p1, p0, Lc/J0;->i:Ljava/io/Serializable;

    move-object v4, p1

    check-cast v4, Ljava/lang/String;

    iget-object v5, p0, Lc/J0;->d:Ljava/util/LinkedHashMap;

    iget-object v6, p0, Lc/J0;->f:Ljava/util/LinkedHashMap;

    iget-object v7, p0, Lc/J0;->e:Ljava/util/function/BooleanSupplier;

    iget-object p1, p0, Lc/J0;->g:Ljava/lang/Object;

    move-object v0, p1

    check-cast v0, Lru/drivedeck/launcher/MainActivity;

    iget-object v3, p0, Lc/J0;->b:Lc/j6;

    invoke-static/range {v0 .. v7}, Lc/G8;->L0(Lru/drivedeck/launcher/MainActivity;Landroid/app/Dialog;Lc/n1;Lc/j6;Ljava/lang/String;Ljava/util/LinkedHashMap;Ljava/util/LinkedHashMap;Ljava/util/function/BooleanSupplier;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
