.class public final synthetic Lc/E3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/function/Consumer;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;I)V
    .locals 0

    iput p2, p0, Lc/E3;->a:I

    iput-object p1, p0, Lc/E3;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .locals 24

    move-object/from16 v0, p0

    iget-object v3, v0, Lc/E3;->b:Ljava/lang/Object;

    iget v6, v0, Lc/E3;->a:I

    packed-switch v6, :pswitch_data_0

    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/Boolean;

    check-cast v3, Lc/Z7;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_0

    const-string v1, "Bluetooth-\u0437\u0432\u043e\u043d\u043e\u043a \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u043d\u0430 \u044d\u0442\u043e\u0439 \u043c\u0430\u0433\u043d\u0438\u0442\u043e\u043b\u0435"

    iput-object v1, v3, Lc/Z7;->K:Ljava/lang/String;

    iget-object v1, v3, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v1}, Lc/J1;->run()V

    :cond_0
    return-void

    :pswitch_0
    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    check-cast v3, Lc/O7;

    invoke-virtual {v3, v1}, Lc/O7;->o(Z)V

    return-void

    :pswitch_1
    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/String;

    check-cast v3, Lc/H6;

    iget-object v2, v3, Lc/H6;->c:Lc/T5;

    iput-object v1, v2, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {v2}, Lc/T5;->q()V

    return-void

    :pswitch_2
    check-cast v3, Lc/y;

    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v3, v1}, Lc/y;->b(Ljava/lang/String;)V

    return-void

    :pswitch_3
    move-object/from16 v6, p1

    check-cast v6, Lc/s0;

    check-cast v3, Lc/P3;

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    instance-of v7, v7, Lru/drivedeck/launcher/MainActivity;

    if-eqz v7, :cond_a

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    move-object v14, v7

    check-cast v14, Lru/drivedeck/launcher/MainActivity;

    sget-object v7, Lc/s0;->k:Lc/s0;

    const-string v8, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const-string v11, " dp"

    const-string v12, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a \u2014 "

    const-string v13, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0438\u043a\u043e\u043d\u043e\u043a"

    iget-object v2, v3, Lc/P3;->C1:Lc/n1;

    const-string v9, "\u0413\u043e\u0442\u043e\u0432\u043e"

    if-ne v6, v7, :cond_4

    const-string v21, "\u0411\u0435\u0437 \u0437\u0432\u0443\u043a\u0430 (Mute)"

    const-string v22, "\u0412\u044b\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0434\u0438\u0441\u043f\u043b\u0435\u0439"

    const-string v16, "Wi\u2011Fi"

    const-string v17, "Bluetooth"

    const-string v18, "\u0421\u043e\u0442\u043e\u0432\u0430\u044f \u0441\u0435\u0442\u044c"

    const-string v19, "\u0420\u0435\u0436\u0438\u043c \u0441\u0430\u043c\u043e\u043b\u0451\u0442\u0430"

    const-string v20, "\u0413\u0440\u043e\u043c\u043a\u043e\u0441\u0442\u044c"

    filled-new-array/range {v16 .. v22}, [Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2}, Lc/n1;->C()I

    move-result v7

    filled-new-array {v7}, [I

    move-result-object v7

    invoke-virtual {v2}, Lc/n1;->B()I

    move-result v2

    filled-new-array {v2}, [I

    move-result-object v2

    new-instance v10, Landroid/app/Dialog;

    invoke-direct {v10, v14}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v14}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v15, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v14, v15}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    const/4 v5, 0x0

    :goto_0
    const/4 v0, 0x7

    if-ge v5, v0, :cond_3

    move-object/from16 v21, v15

    const/4 v0, 0x1

    shl-int v15, v0, v5

    aget-object v0, v6, v5

    const/16 v19, 0x0

    aget v22, v7, v19

    and-int v22, v22, v15

    if-eqz v22, :cond_1

    move-object/from16 v22, v6

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    move-object/from16 v22, v6

    const/4 v6, 0x0

    :goto_1
    invoke-static {v14, v0, v6}, Lc/G8;->Y0(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/Switch;

    move-result-object v0

    new-instance v6, Lc/H3;

    invoke-direct {v6, v7, v15}, Lc/H3;-><init>([II)V

    invoke-virtual {v0, v6}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v7

    const/4 v7, -0x1

    const/4 v15, -0x2

    invoke-direct {v6, v7, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-lez v5, :cond_2

    const/high16 v7, 0x41000000    # 8.0f

    invoke-static {v14, v7}, Lc/G8;->z(Landroid/content/Context;F)I

    move-result v7

    iput v7, v6, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    :cond_2
    invoke-virtual {v4, v0, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v0, 0x1

    add-int/2addr v5, v0

    move-object/from16 v15, v21

    move-object/from16 v6, v22

    move-object/from16 v7, v23

    goto :goto_0

    :cond_3
    move-object/from16 v23, v7

    move-object/from16 v21, v15

    const/4 v0, 0x1

    invoke-static {v14, v1, v4}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v14, v13}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    invoke-static {v14}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v5

    iget v5, v5, Lc/r4;->d:I

    const/16 v6, 0x10

    invoke-static {v14, v12, v6, v0, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v14, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    aget v7, v2, v6

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v5, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v14}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v0

    const/16 v7, 0x30

    invoke-virtual {v0, v7}, Landroid/widget/ProgressBar;->setMin(I)V

    const/16 v7, 0x60

    invoke-virtual {v0, v7}, Landroid/widget/ProgressBar;->setMax(I)V

    aget v7, v2, v6

    invoke-virtual {v0, v7}, Landroid/widget/ProgressBar;->setProgress(I)V

    new-instance v7, Lc/N3;

    const/4 v11, 0x1

    invoke-direct {v7, v2, v5, v14, v11}, Lc/N3;-><init>([ILandroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v7}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    invoke-virtual {v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v14, v1, v4}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v14, v8, v6}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v0

    new-instance v4, Lc/a0;

    const/16 v5, 0x8

    invoke-direct {v4, v10, v5}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-static {v14, v9, v11}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v4

    new-instance v5, Lc/I3;

    const/4 v13, 0x0

    move-object/from16 v6, v23

    move-object v7, v5

    move-object v8, v3

    move-object v9, v6

    move-object v6, v10

    move-object v10, v14

    move-object v11, v2

    move-object v12, v6

    invoke-direct/range {v7 .. v13}, Lc/I3;-><init>(Lc/P3;[ILru/drivedeck/launcher/MainActivity;Ljava/lang/Object;Landroid/app/Dialog;I)V

    invoke-virtual {v4, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v2, 0x2

    new-array v2, v2, [Landroid/view/View;

    const/4 v5, 0x0

    aput-object v0, v2, v5

    const/4 v0, 0x1

    aput-object v4, v2, v0

    invoke-static {v14, v2}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    move-object/from16 v2, v21

    invoke-static {v6, v14, v2, v1, v0}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    move-object v10, v6

    goto/16 :goto_4

    :cond_4
    const/4 v0, 0x1

    sget-object v1, Lc/s0;->h:Lc/s0;

    if-ne v6, v1, :cond_5

    invoke-virtual {v2}, Lc/n1;->V()I

    move-result v4

    filled-new-array {v4}, [I

    move-result-object v4

    invoke-virtual {v2, v1}, Lc/n1;->s0(Lc/s0;)Z

    move-result v5

    invoke-virtual {v2, v1}, Lc/n1;->W(Lc/s0;)I

    move-result v2

    new-array v6, v0, [Z

    const/4 v0, 0x0

    aput-boolean v0, v6, v0

    new-instance v0, Landroid/app/Dialog;

    invoke-direct {v0, v14}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    new-instance v7, Lc/J3;

    invoke-direct {v7, v3, v6, v5, v2}, Lc/J3;-><init>(Lc/P3;[ZZI)V

    invoke-virtual {v0, v7}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-static {v14}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v2

    const-string v5, "\u0424\u043e\u043d"

    invoke-static {v14, v5}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v5

    new-instance v7, Lc/F3;

    const/16 v10, 0x8

    invoke-direct {v7, v3, v10}, Lc/F3;-><init>(Lc/P3;I)V

    invoke-static {v14, v5, v1, v7}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v14, v2, v5}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v14, v13}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v1

    invoke-static {v14}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v5

    iget v5, v5, Lc/r4;->d:I

    const/16 v7, 0x10

    const/4 v10, 0x1

    invoke-static {v14, v12, v7, v10, v5}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v14, v12}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    aget v12, v4, v10

    invoke-virtual {v7, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v14}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v7

    const/16 v11, 0x30

    invoke-virtual {v7, v11}, Landroid/widget/ProgressBar;->setMin(I)V

    const/16 v11, 0x60

    invoke-virtual {v7, v11}, Landroid/widget/ProgressBar;->setMax(I)V

    aget v11, v4, v10

    invoke-virtual {v7, v11}, Landroid/widget/ProgressBar;->setProgress(I)V

    new-instance v11, Lc/N3;

    invoke-direct {v11, v4, v5, v14, v10}, Lc/N3;-><init>([ILandroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v7, v11}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    invoke-virtual {v1, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    invoke-static {v14, v2, v1}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    invoke-static {v14, v8, v10}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    new-instance v5, Lc/a0;

    const/16 v7, 0x9

    invoke-direct {v5, v0, v7}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v1, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v5, 0x1

    invoke-static {v14, v9, v5}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v15

    new-instance v5, Lc/I3;

    const/4 v13, 0x1

    move-object v7, v5

    move-object v8, v3

    move-object v9, v4

    move-object v10, v14

    move-object v11, v6

    move-object v12, v0

    invoke-direct/range {v7 .. v13}, Lc/I3;-><init>(Lc/P3;[ILru/drivedeck/launcher/MainActivity;Ljava/lang/Object;Landroid/app/Dialog;I)V

    invoke-virtual {v15, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x2

    new-array v4, v4, [Landroid/view/View;

    const/4 v5, 0x0

    aput-object v1, v4, v5

    const/4 v1, 0x1

    aput-object v15, v4, v1

    invoke-static {v14, v4}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v1

    const-string v4, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v0, v14, v4, v2, v1}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    move-object v10, v0

    goto/16 :goto_4

    :cond_5
    sget-object v0, Lc/s0;->l:Lc/s0;

    if-ne v6, v0, :cond_6

    new-instance v0, Lc/K3;

    invoke-direct {v0, v3}, Lc/K3;-><init>(Lc/P3;)V

    invoke-static {v14, v0}, Lc/G8;->G0(Lru/drivedeck/launcher/MainActivity;Ljava/util/function/BooleanSupplier;)Landroid/app/Dialog;

    move-result-object v10

    goto/16 :goto_4

    :cond_6
    new-instance v0, Lc/F3;

    const/16 v1, 0x8

    invoke-direct {v0, v3, v1}, Lc/F3;-><init>(Lc/P3;I)V

    iget-object v1, v3, Lc/P3;->f:Lc/o0;

    sget-object v2, Lc/s0;->e:Lc/s0;

    const/4 v4, 0x0

    if-nez v1, :cond_7

    move-object v1, v4

    goto :goto_2

    :cond_7
    iget-object v1, v1, Lc/o0;->e:Ljava/util/EnumMap;

    invoke-virtual {v1, v2}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/m0;

    :goto_2
    if-nez v1, :cond_8

    const/16 v1, 0x64

    goto :goto_3

    :cond_8
    invoke-virtual {v1}, Lc/m0;->d()F

    move-result v5

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-virtual {v3, v7}, Lc/P3;->s(F)F

    move-result v8

    div-float/2addr v5, v8

    invoke-virtual {v1}, Lc/m0;->b()F

    move-result v1

    invoke-virtual {v3, v7}, Lc/P3;->s(F)F

    move-result v8

    div-float/2addr v1, v8

    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    const/high16 v10, 0x42400000    # 48.0f

    invoke-static {v8, v10}, Lc/G8;->a1(Landroid/content/Context;F)F

    move-result v8

    invoke-virtual {v3, v7}, Lc/P3;->s(F)F

    move-result v7

    div-float/2addr v8, v7

    invoke-static {v5, v1, v8}, Lc/G8;->V(FFF)I

    move-result v1

    :goto_3
    new-instance v10, Landroid/app/Dialog;

    invoke-direct {v10, v14}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    invoke-static {v14}, Lc/G8;->i(Landroid/app/Activity;)Landroid/widget/LinearLayout;

    move-result-object v5

    invoke-static {v14, v4}, Lc/G8;->n(Landroid/app/Activity;Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v4

    if-ne v6, v2, :cond_9

    new-instance v2, Lc/n1;

    invoke-direct {v2, v14}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-static {v14}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v7

    iget v8, v7, Lc/r4;->d:I

    const-string v11, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0442\u0435\u043a\u0441\u0442\u0430 \u0438 \u0438\u043a\u043e\u043d\u043e\u043a"

    const/16 v12, 0x10

    const/4 v13, 0x0

    invoke-static {v14, v11, v12, v13, v8}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v8

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, -0x2

    const/4 v15, -0x1

    invoke-direct {v12, v15, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v8, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    invoke-static {v14}, Lc/G8;->M0(Lru/drivedeck/launcher/MainActivity;)Landroid/widget/SeekBar;

    move-result-object v12

    const/16 v13, 0x4b

    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    sub-int/2addr v1, v13

    div-int/lit8 v1, v1, 0x5

    invoke-virtual {v12, v1}, Landroid/widget/ProgressBar;->setMax(I)V

    invoke-virtual {v2}, Lc/n1;->u()I

    move-result v1

    sub-int/2addr v1, v13

    div-int/lit8 v1, v1, 0x5

    invoke-virtual {v12, v1}, Landroid/widget/ProgressBar;->setProgress(I)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v14, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, ": "

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Lc/n1;->u()I

    move-result v13

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, "%"

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v8, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-static {v14, v11}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v12, v1}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    new-instance v1, Lc/Z0;

    invoke-direct {v1, v8, v14, v2, v0}, Lc/Z0;-><init>(Landroid/widget/TextView;Lru/drivedeck/launcher/MainActivity;Lc/n1;Lc/F3;)V

    invoke-virtual {v12, v1}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v8, -0x1

    invoke-direct {v1, v8, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v12, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget v1, v7, Lc/r4;->e:I

    const-string v7, "\u0414\u043b\u044f \u0431\u043e\u043b\u044c\u0448\u0435\u0433\u043e \u043c\u0430\u0441\u0448\u0442\u0430\u0431\u0430 \u0443\u0432\u0435\u043b\u0438\u0447\u044c\u0442\u0435 \u0440\u0430\u043c\u043a\u0443 \u0432\u0438\u0434\u0436\u0435\u0442\u0430"

    const/16 v11, 0xc

    const/4 v12, 0x0

    invoke-static {v14, v7, v11, v12, v1}, Lc/G8;->W0(Landroid/app/Activity;Ljava/lang/String;IZI)Landroid/widget/TextView;

    move-result-object v1

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v7, v8, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v1, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_9
    invoke-static {v14, v4, v6, v0}, Lc/G8;->c(Lru/drivedeck/launcher/MainActivity;Landroid/widget/LinearLayout;Lc/s0;Ljava/lang/Runnable;)V

    invoke-static {v14, v5, v4}, Lc/G8;->d(Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    const/4 v0, 0x1

    invoke-static {v14, v9, v0}, Lc/G8;->j(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Lc/a0;

    const/4 v4, 0x4

    invoke-direct {v2, v10, v4}, Lc/a0;-><init>(Landroid/app/Dialog;I)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-array v0, v0, [Landroid/view/View;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-static {v14, v0}, Lc/G8;->I(Landroid/app/Activity;[Landroid/view/View;)Landroid/widget/LinearLayout;

    move-result-object v0

    iget-object v1, v6, Lc/s0;->a:Ljava/lang/String;

    invoke-static {v10, v14, v1, v5, v0}, Lc/G8;->I0(Landroid/app/Dialog;Landroid/app/Activity;Ljava/lang/String;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V

    :goto_4
    iput-object v10, v3, Lc/P3;->P1:Landroid/app/Dialog;

    :cond_a
    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
