.class public final synthetic Lc/K4;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lru/drivedeck/launcher/MainActivity;

.field public final synthetic b:J

.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:I

.field public final synthetic f:I


# direct methods
.method public synthetic constructor <init>(Lru/drivedeck/launcher/MainActivity;JLandroid/view/View;Ljava/lang/String;II)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/K4;->a:Lru/drivedeck/launcher/MainActivity;

    iput-wide p2, p0, Lc/K4;->b:J

    iput-object p4, p0, Lc/K4;->c:Landroid/view/View;

    iput-object p5, p0, Lc/K4;->d:Ljava/lang/String;

    iput p6, p0, Lc/K4;->e:I

    iput p7, p0, Lc/K4;->f:I

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 20

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/K4;->a:Lru/drivedeck/launcher/MainActivity;

    iget-wide v2, v1, Lru/drivedeck/launcher/MainActivity;->k:J

    iget-wide v4, v0, Lc/K4;->b:J

    cmp-long v2, v4, v2

    if-nez v2, :cond_3

    iget-object v2, v1, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v3, v0, Lc/K4;->c:Landroid/view/View;

    if-eq v2, v3, :cond_0

    goto :goto_2

    :cond_0
    iget-object v9, v0, Lc/K4;->d:Ljava/lang/String;

    iget v2, v0, Lc/K4;->e:I

    invoke-static {v1, v9, v2}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v3

    iget v6, v0, Lc/K4;->f:I

    invoke-static {v1, v9, v6}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v1

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    const/4 v2, 0x1

    if-ne v3, v2, :cond_1

    if-nez v1, :cond_1

    const-string v1, "confirmed"

    :goto_0
    move-object/from16 v19, v1

    goto :goto_1

    :cond_1
    if-ne v1, v2, :cond_2

    const-string v1, "duplicate"

    goto :goto_0

    :cond_2
    const-string v1, "unconfirmed"

    goto :goto_0

    :goto_1
    const-string v12, "source_display"

    const-string v14, "target_state"

    const-string v6, "transition_id"

    const-string v8, "package"

    const-string v10, "target_display"

    const-string v16, "source_state"

    const-string v18, "result"

    filled-new-array/range {v6 .. v19}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "dashboard_task_placement"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_3
    :goto_2
    return-void
.end method
