.class public final synthetic Lc/C2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lc/H6;Landroid/widget/LinearLayout;Landroid/widget/Button;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/16 v0, 0x8

    iput v0, p0, Lc/C2;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/C2;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/C2;->d:Ljava/lang/Object;

    iput-object p3, p0, Lc/C2;->e:Ljava/lang/Object;

    iput-object p4, p0, Lc/C2;->c:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 2
    iput p5, p0, Lc/C2;->a:I

    iput-object p1, p0, Lc/C2;->b:Ljava/lang/Object;

    iput-object p2, p0, Lc/C2;->c:Ljava/lang/Object;

    iput-object p3, p0, Lc/C2;->d:Ljava/lang/Object;

    iput-object p4, p0, Lc/C2;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 24

    move-object/from16 v1, p0

    const-string v0, "dock"

    const/4 v2, 0x3

    const-string v3, ""

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v6, v1, Lc/C2;->c:Ljava/lang/Object;

    iget-object v7, v1, Lc/C2;->e:Ljava/lang/Object;

    iget-object v8, v1, Lc/C2;->d:Ljava/lang/Object;

    iget-object v9, v1, Lc/C2;->b:Ljava/lang/Object;

    const/4 v10, 0x1

    iget v11, v1, Lc/C2;->a:I

    packed-switch v11, :pswitch_data_0

    check-cast v9, Lc/H6;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v8, Landroid/widget/LinearLayout;

    invoke-virtual {v8}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_0

    move v5, v10

    :cond_0
    iget-object v0, v9, Lc/H6;->a:Lru/drivedeck/launcher/MainActivity;

    const v2, 0x7f030019

    invoke-virtual {v0, v2}, Landroid/content/Context;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    iget-object v3, v9, Lc/H6;->b:Lc/r4;

    iget v3, v3, Lc/r4;->d:I

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    if-eqz v5, :cond_1

    new-instance v3, Landroid/graphics/drawable/RotateDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/RotateDrawable;-><init>()V

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/DrawableWrapper;->setDrawable(Landroid/graphics/drawable/Drawable;)V

    const/high16 v2, 0x43340000    # 180.0f

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/RotateDrawable;->setFromDegrees(F)V

    invoke-virtual {v3, v2}, Landroid/graphics/drawable/RotateDrawable;->setToDegrees(F)V

    move-object v2, v3

    :cond_1
    check-cast v7, Landroid/widget/Button;

    invoke-virtual {v7, v4, v4, v2, v4}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    check-cast v6, Ljava/lang/String;

    invoke-static {v0, v6}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ". "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v5, :cond_2

    const-string v3, "\u0421\u0432\u0435\u0440\u043d\u0443\u0442\u044c"

    goto :goto_0

    :cond_2
    const-string v3, "\u0420\u0430\u0437\u0432\u0435\u0440\u043d\u0443\u0442\u044c"

    :goto_0
    invoke-static {v0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    invoke-virtual {v7, v5}, Landroid/view/View;->setSelected(Z)V

    return-void

    :pswitch_0
    check-cast v9, Lc/T5;

    iget-object v0, v9, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    check-cast v6, Landroid/bluetooth/BluetoothGatt;

    if-ne v6, v0, :cond_5

    iget-object v0, v9, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    check-cast v8, Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eq v8, v0, :cond_3

    goto :goto_1

    :cond_3
    iget-boolean v0, v9, Lc/T5;->T1:Z

    check-cast v7, [B

    if-eqz v0, :cond_4

    new-instance v0, Ljava/lang/String;

    sget-object v2, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v0, v7, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string v2, "\u0000"

    invoke-virtual {v0, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, v9, Lc/T5;->W1:Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/16 v2, 0x4000

    if-le v0, v2, :cond_5

    invoke-virtual {v9}, Lc/T5;->a0()V

    goto :goto_1

    :cond_4
    invoke-virtual {v9, v7}, Lc/T5;->k0([B)V

    :cond_5
    :goto_1
    return-void

    :pswitch_1
    check-cast v9, Lc/z5;

    iput-boolean v5, v9, Lc/z5;->d:Z

    check-cast v6, Ljava/lang/String;

    iput-object v6, v9, Lc/z5;->b:Ljava/lang/String;

    check-cast v8, Ljava/util/ArrayList;

    if-eqz v8, :cond_6

    iget-object v0, v9, Lc/z5;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    check-cast v7, Ljava/lang/String;

    iput-object v7, v9, Lc/z5;->c:Ljava/lang/String;

    :cond_6
    new-instance v0, Ljava/util/ArrayList;

    iget-object v2, v9, Lc/z5;->i:Ljava/util/HashSet;

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Runnable;

    invoke-interface {v2}, Ljava/lang/Runnable;->run()V

    goto :goto_2

    :cond_7
    return-void

    :pswitch_2
    check-cast v9, Lru/drivedeck/launcher/MainActivity;

    check-cast v6, Ljava/lang/String;

    check-cast v8, Lorg/json/JSONObject;

    check-cast v7, Ljava/lang/Runnable;

    :try_start_0
    invoke-static {v9}, Lc/q4;->t(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-virtual {v0, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {v9, v0}, Lc/q4;->y(Landroid/content/Context;Lorg/json/JSONObject;)V

    const-string v0, "drivedeck_presets"

    invoke-virtual {v9, v0, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "selected"

    invoke-interface {v0, v2, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v0, "\u041f\u0440\u0435\u0441\u0435\u0442 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    invoke-static {v9, v0}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    invoke-interface {v7}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_3

    :catch_0
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {v9, v0}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :goto_3
    return-void

    :pswitch_3
    check-cast v9, Landroid/content/Context;

    check-cast v6, Ljava/util/LinkedHashMap;

    check-cast v8, Lorg/json/JSONObject;

    const-string v0, "widgets"

    const-string v3, "settings"

    const-string v11, "drive_deck"

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    new-instance v13, Ljava/util/LinkedHashMap;

    invoke-direct {v13}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v14, Ljava/util/LinkedHashMap;

    invoke-direct {v14}, Ljava/util/LinkedHashMap;-><init>()V

    :try_start_1
    new-instance v15, Ljava/util/LinkedHashMap;

    invoke-direct {v15, v6}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1 .. :try_end_1} :catch_1

    sget-object v16, Lc/q4;->c:[Ljava/lang/String;

    move v4, v5

    :goto_4
    if-ge v4, v2, :cond_9

    :try_start_2
    aget-object v5, v16, v4

    invoke-interface {v15, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v19

    if-eqz v19, :cond_8

    invoke-virtual {v15, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, [B

    invoke-static/range {v19 .. v19}, Lc/X3;->g([B)[B

    move-result-object v2

    invoke-interface {v15, v5, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :catch_1
    move-exception v0

    :goto_5
    move-object/from16 v21, v7

    const/4 v4, 0x0

    goto/16 :goto_15

    :catch_2
    move-exception v0

    goto :goto_5

    :cond_8
    :goto_6
    add-int/2addr v4, v10

    const/4 v2, 0x3

    const/4 v5, 0x0

    goto :goto_4

    :cond_9
    new-instance v2, Lc/v8;

    invoke-direct {v2, v9}, Lc/v8;-><init>(Landroid/content/Context;)V

    invoke-static {v9}, Lc/q4;->t(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v4
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_2 .. :try_end_2} :catch_1

    sget-object v5, Lc/v8;->c:[Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v10, 0x0

    :goto_7
    if-ge v10, v1, :cond_a

    :try_start_3
    aget-object v1, v5, v10
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_6
    .catch Ljava/lang/OutOfMemoryError; {:try_start_3 .. :try_end_3} :catch_5

    move-object/from16 v22, v5

    move-object/from16 v21, v7

    const/4 v7, 0x0

    :try_start_4
    invoke-virtual {v2, v9, v1, v7}, Lc/v8;->b(Landroid/content/Context;Ljava/lang/String;Z)Lorg/json/JSONObject;

    move-result-object v5

    invoke-interface {v14, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    add-int/2addr v10, v1

    move-object/from16 v7, v21

    move-object/from16 v5, v22

    const/4 v1, 0x3

    goto :goto_7

    :catch_3
    move-exception v0

    goto/16 :goto_15

    :catch_4
    move-exception v0

    goto/16 :goto_15

    :catch_5
    move-exception v0

    :goto_8
    move-object/from16 v21, v7

    goto/16 :goto_15

    :catch_6
    move-exception v0

    goto :goto_8

    :cond_a
    move-object/from16 v22, v5

    move-object/from16 v21, v7

    invoke-virtual {v6}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_b
    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/high16 v6, 0x4000000

    if-eqz v5, :cond_f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Lc/q4;->b(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_b

    new-instance v7, Ljava/io/File;

    invoke-virtual {v9}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v10

    invoke-direct {v7, v10, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/io/File;->isFile()Z

    move-result v10

    if-eqz v10, :cond_c

    new-instance v10, Ljava/io/FileInputStream;

    invoke-direct {v10, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_4 .. :try_end_4} :catch_3

    goto :goto_a

    :cond_c
    const/4 v10, 0x0

    :goto_a
    if-nez v10, :cond_d

    const/4 v6, 0x0

    goto :goto_b

    :cond_d
    :try_start_5
    invoke-static {v10, v6}, Lc/q4;->d(Ljava/io/InputStream;I)[B

    move-result-object v6

    :goto_b
    invoke-interface {v13, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    if-eqz v10, :cond_b

    :try_start_6
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_6 .. :try_end_6} :catch_3

    goto :goto_9

    :catchall_0
    move-exception v0

    move-object v1, v0

    if-eqz v10, :cond_e

    :try_start_7
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    goto :goto_c

    :catchall_1
    move-exception v0

    move-object v2, v0

    :try_start_8
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_e
    :goto_c
    throw v1

    :cond_f
    const/4 v1, 0x0

    :goto_d
    const/4 v5, 0x3

    if-ge v1, v5, :cond_14

    aget-object v5, v16, v1

    invoke-interface {v13, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_12

    new-instance v7, Ljava/io/File;

    invoke-virtual {v9}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v10

    invoke-direct {v7, v10, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/io/File;->isFile()Z

    move-result v10

    if-eqz v10, :cond_10

    new-instance v10, Ljava/io/FileInputStream;

    invoke-direct {v10, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_8 .. :try_end_8} :catch_3

    goto :goto_e

    :cond_10
    const/4 v10, 0x0

    :goto_e
    if-nez v10, :cond_11

    const/4 v7, 0x0

    goto :goto_f

    :cond_11
    :try_start_9
    invoke-static {v10, v6}, Lc/q4;->d(Ljava/io/InputStream;I)[B

    move-result-object v7

    :goto_f
    invoke-interface {v13, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    if-eqz v10, :cond_12

    :try_start_a
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_a .. :try_end_a} :catch_3

    :cond_12
    const/4 v5, 0x1

    goto :goto_11

    :catchall_2
    move-exception v0

    move-object v1, v0

    if-eqz v10, :cond_13

    :try_start_b
    invoke-virtual {v10}, Ljava/io/InputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    goto :goto_10

    :catchall_3
    move-exception v0

    move-object v2, v0

    :try_start_c
    invoke-virtual {v1, v2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_13
    :goto_10
    throw v1

    :goto_11
    add-int/2addr v1, v5

    goto :goto_d

    :cond_14
    invoke-virtual {v14, v11}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/json/JSONObject;

    invoke-static {v1, v4}, Lc/q4;->B(Lorg/json/JSONObject;Lorg/json/JSONObject;)Ljava/util/HashSet;

    move-result-object v1

    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    const-string v6, "preferences"

    invoke-virtual {v8, v6}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v6

    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    invoke-virtual {v6, v11}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    invoke-virtual {v7, v3, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v7

    invoke-virtual {v8, v0}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    invoke-virtual {v7, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v9, v0, v5, v12}, Lc/q4;->v(Landroid/content/Context;Lorg/json/JSONObject;Ljava/util/HashMap;Ljava/util/ArrayList;)V

    const-string v7, "presets"

    invoke-virtual {v8, v7}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    invoke-virtual {v7}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v8

    :goto_12
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_15

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v7, v10}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v10

    invoke-static {v9, v10, v5, v12}, Lc/q4;->v(Landroid/content/Context;Lorg/json/JSONObject;Ljava/util/HashMap;Ljava/util/ArrayList;)V

    goto :goto_12

    :cond_15
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-static {v0, v7}, Lc/q4;->B(Lorg/json/JSONObject;Lorg/json/JSONObject;)Ljava/util/HashSet;

    move-result-object v0

    invoke-interface {v1, v0}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    invoke-virtual {v13}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v15, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [B

    invoke-static {v9, v3, v5}, Lc/q4;->D(Landroid/content/Context;Ljava/lang/String;[B)V

    goto :goto_13

    :cond_16
    const/4 v0, 0x0

    :goto_14
    const/4 v3, 0x3

    if-ge v0, v3, :cond_17

    aget-object v3, v22, v0

    invoke-virtual {v6, v3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v8, 0x0

    invoke-virtual {v2, v9, v3, v5, v8}, Lc/v8;->a(Landroid/content/Context;Ljava/lang/String;Lorg/json/JSONObject;Z)V

    const/4 v3, 0x1

    add-int/2addr v0, v3

    goto :goto_14

    :cond_17
    invoke-static {v9, v7}, Lc/q4;->y(Landroid/content/Context;Lorg/json/JSONObject;)V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v9, v0}, Lc/q4;->f(Landroid/content/Context;Ljava/util/ArrayList;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_4
    .catch Ljava/lang/OutOfMemoryError; {:try_start_c .. :try_end_c} :catch_3

    const/4 v5, 0x1

    goto :goto_1a

    :goto_15
    const-string v1, "Configuration restore failed"

    const-string v2, "DriveDeck"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :try_start_d
    invoke-virtual {v13}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_16
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [B

    invoke-static {v9, v3, v1}, Lc/q4;->D(Landroid/content/Context;Ljava/lang/String;[B)V

    goto :goto_16

    :catch_7
    move-exception v0

    const/4 v7, 0x0

    goto :goto_18

    :cond_18
    new-instance v0, Lc/v8;

    invoke-direct {v0, v9}, Lc/v8;-><init>(Landroid/content/Context;)V

    invoke-virtual {v14}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_17
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_19

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lorg/json/JSONObject;
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_7

    const/4 v7, 0x0

    :try_start_e
    invoke-virtual {v0, v9, v5, v3, v7}, Lc/v8;->a(Landroid/content/Context;Ljava/lang/String;Lorg/json/JSONObject;Z)V

    goto :goto_17

    :catch_8
    move-exception v0

    goto :goto_18

    :cond_19
    const/4 v7, 0x0

    if-eqz v4, :cond_1a

    invoke-static {v9, v4}, Lc/q4;->y(Landroid/content/Context;Lorg/json/JSONObject;)V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_8

    goto :goto_19

    :goto_18
    const-string v1, "Configuration rollback failed"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_1a
    :goto_19
    invoke-static {v9, v12}, Lc/q4;->f(Landroid/content/Context;Ljava/util/ArrayList;)V

    move v5, v7

    :goto_1a
    new-instance v0, Lc/H1;

    move-object/from16 v7, v21

    check-cast v7, Lru/drivedeck/launcher/MainActivity;

    const/4 v1, 0x1

    invoke-direct {v0, v7, v5, v9, v1}, Lc/H1;-><init>(Ljava/lang/Object;ZLjava/lang/Object;I)V

    invoke-virtual {v7, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :pswitch_4
    move-object/from16 v21, v7

    move v7, v5

    :goto_1b
    move-object v0, v9

    check-cast v0, [Ljava/lang/String;

    const/4 v1, 0x3

    if-ge v5, v1, :cond_1c

    aget-object v0, v0, v5

    move-object v2, v6

    check-cast v2, Lc/n1;

    const-string v3, "home_edges"

    invoke-virtual {v2, v3}, Lc/n1;->c0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "driving"

    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    move-object v2, v8

    check-cast v2, [Landroid/widget/TextView;

    aget-object v3, v2, v5

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setSelected(Z)V

    aget-object v3, v2, v5

    move-object/from16 v7, v21

    check-cast v7, Lc/r4;

    if-eqz v0, :cond_1b

    iget v4, v7, Lc/r4;->g:I

    goto :goto_1c

    :cond_1b
    iget v4, v7, Lc/r4;->d:I

    :goto_1c
    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V

    aget-object v2, v2, v5

    invoke-static {v2, v7, v0}, Lc/G8;->B0(Landroid/widget/TextView;Lc/r4;Z)V

    const/4 v2, 0x1

    add-int/2addr v5, v2

    goto :goto_1b

    :cond_1c
    return-void

    :pswitch_5
    move-object/from16 v21, v7

    move v7, v5

    check-cast v9, Lc/k3;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v6, Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "pairs"

    if-nez v1, :cond_1e

    invoke-virtual {v6, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    goto :goto_1d

    :cond_1d
    const/16 v1, 0x6c

    goto :goto_1e

    :cond_1e
    :goto_1d
    const/16 v1, 0x60

    :goto_1e
    int-to-float v1, v1

    invoke-virtual {v9, v1}, Lc/k3;->x(F)I

    move-result v1

    check-cast v8, Landroid/widget/LinearLayout;

    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    move-result v3

    invoke-virtual {v8}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    sub-int/2addr v3, v4

    invoke-virtual {v8}, Landroid/view/View;->getPaddingRight()I

    move-result v4

    sub-int/2addr v3, v4

    if-gtz v3, :cond_1f

    goto/16 :goto_25

    :cond_1f
    move-object/from16 v4, v21

    check-cast v4, Landroid/widget/GridLayout;

    invoke-virtual {v4}, Landroid/view/ViewGroup;->removeAllViews()V

    div-int v1, v3, v1

    const/4 v5, 0x1

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v4, v1}, Landroid/widget/GridLayout;->setColumnCount(I)V

    const/high16 v10, 0x40800000    # 4.0f

    invoke-virtual {v9, v10}, Lc/k3;->x(F)I

    move-result v15

    const/high16 v10, 0x40c00000    # 6.0f

    invoke-virtual {v9, v10}, Lc/k3;->x(F)I

    move-result v14

    mul-int v10, v1, v15

    const/16 v16, 0x2

    mul-int/lit8 v10, v10, 0x2

    sub-int/2addr v3, v10

    div-int/2addr v3, v1

    invoke-static {v5, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    iget-object v5, v9, Lc/k3;->b:Lc/z;

    invoke-virtual {v5}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_1f
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_26

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    move-object v13, v10

    check-cast v13, Lc/a;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_20

    iget-object v10, v9, Lc/k3;->e:Ljava/util/ArrayList;

    iget-object v11, v13, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v10

    goto :goto_21

    :cond_20
    iget-object v10, v13, Lc/a;->a:Ljava/lang/String;

    iget v11, v9, Lc/k3;->s:I

    if-nez v11, :cond_21

    iget-object v11, v9, Lc/k3;->v:Ljava/lang/String;

    goto :goto_20

    :cond_21
    iget-object v11, v9, Lc/k3;->w:Ljava/lang/String;

    :goto_20
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    :goto_21
    new-instance v12, Lc/u;

    iget-object v11, v9, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    move-object/from16 v17, v5

    invoke-virtual {v6, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    invoke-direct {v12, v11, v5}, Lc/u;-><init>(Landroid/content/Context;Z)V

    if-eqz v10, :cond_22

    move/from16 v5, v16

    goto :goto_22

    :cond_22
    const/4 v5, 0x1

    :goto_22
    invoke-virtual {v12, v13, v5}, Lc/u;->a(Lc/a;I)V

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_24

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v11, v13, Lc/a;->b:Ljava/lang/String;

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v10, :cond_23

    const-string v10, ", \u0443\u0431\u0440\u0430\u0442\u044c \u0438\u0437 \u0434\u043e\u043a\u0430"

    goto :goto_23

    :cond_23
    const-string v10, ", \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u0434\u043e\u043a"

    :goto_23
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v12, v5}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :cond_24
    new-instance v5, Lc/j0;

    const/16 v18, 0x2

    move-object v10, v5

    move-object v11, v9

    move-object/from16 v23, v12

    move-object v12, v6

    move-object/from16 v20, v0

    move v0, v14

    move-object v14, v8

    move-object/from16 v22, v8

    move v8, v15

    move/from16 v15, v18

    invoke-direct/range {v10 .. v15}, Lc/j0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    move-object/from16 v10, v23

    invoke-virtual {v10, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    new-instance v5, Landroid/widget/GridLayout$LayoutParams;

    div-int v11, v7, v1

    invoke-static {v11}, Landroid/widget/GridLayout;->spec(I)Landroid/widget/GridLayout$Spec;

    move-result-object v11

    rem-int v12, v7, v1

    invoke-static {v12}, Landroid/widget/GridLayout;->spec(I)Landroid/widget/GridLayout$Spec;

    move-result-object v12

    invoke-direct {v5, v11, v12}, Landroid/widget/GridLayout$LayoutParams;-><init>(Landroid/widget/GridLayout$Spec;Landroid/widget/GridLayout$Spec;)V

    iput v3, v5, Landroid/widget/GridLayout$LayoutParams;->width:I

    invoke-virtual {v6, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_25

    const/high16 v11, 0x42c40000    # 98.0f

    goto :goto_24

    :cond_25
    const/high16 v11, 0x42e00000    # 112.0f

    :goto_24
    invoke-virtual {v9, v11}, Lc/k3;->x(F)I

    move-result v11

    iput v11, v5, Landroid/widget/GridLayout$LayoutParams;->height:I

    invoke-virtual {v5, v8, v0, v8, v0}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    invoke-virtual {v4, v10, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x1

    add-int/2addr v7, v5

    move v14, v0

    move v15, v8

    move-object/from16 v5, v17

    move-object/from16 v0, v20

    move-object/from16 v8, v22

    goto/16 :goto_1f

    :cond_26
    if-nez v7, :cond_27

    const-string v0, "\u041d\u0438\u0447\u0435\u0433\u043e \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e"

    invoke-virtual {v9, v0}, Lc/k3;->A(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_27
    :goto_25
    return-void

    :pswitch_6
    move-object/from16 v20, v0

    move-object/from16 v21, v7

    check-cast v9, Lc/k3;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v6, Ljava/lang/String;

    move-object/from16 v0, v20

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    move-object/from16 v7, v21

    check-cast v7, Landroid/widget/LinearLayout;

    check-cast v8, Lc/a;

    if-eqz v0, :cond_2b

    iget-object v0, v9, Lc/k3;->e:Ljava/util/ArrayList;

    iget-object v1, v8, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v1

    iget-object v2, v8, Lc/a;->a:Ljava/lang/String;

    if-ltz v1, :cond_28

    invoke-static {v7, v6}, Lc/k3;->V(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    invoke-virtual {v9, v2}, Lc/k3;->W(Ljava/lang/String;)V

    goto/16 :goto_2b

    :cond_28
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    iget-object v3, v9, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    if-eqz v3, :cond_29

    invoke-virtual {v3}, Lru/drivedeck/launcher/MainActivity;->p()I

    move-result v3

    goto :goto_26

    :cond_29
    iget v3, v9, Lc/k3;->f:I

    :goto_26
    if-lt v1, v3, :cond_2a

    const-string v0, "\u0414\u043e\u043a \u0437\u0430\u043f\u043e\u043b\u043d\u0435\u043d \u2014 \u0441\u043d\u0430\u0447\u0430\u043b\u0430 \u043e\u0441\u0432\u043e\u0431\u043e\u0434\u0438\u0442\u0435 \u043c\u0435\u0441\u0442\u043e"

    invoke-virtual {v9, v0}, Lc/k3;->J(Ljava/lang/String;)V

    goto :goto_2b

    :cond_2a
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    iput v0, v9, Lc/k3;->q:I

    iput-boolean v1, v9, Lc/k3;->t:Z

    const/4 v1, 0x0

    iput-object v1, v9, Lc/k3;->A:Ljava/util/ArrayList;

    invoke-virtual {v9}, Lc/k3;->l()V

    goto :goto_2a

    :cond_2b
    const/4 v1, 0x1

    iget v0, v9, Lc/k3;->s:I

    if-nez v0, :cond_2c

    iget-object v2, v8, Lc/a;->a:Ljava/lang/String;

    goto :goto_27

    :cond_2c
    iget-object v2, v9, Lc/k3;->v:Ljava/lang/String;

    :goto_27
    if-ne v0, v1, :cond_2d

    iget-object v0, v8, Lc/a;->a:Ljava/lang/String;

    goto :goto_28

    :cond_2d
    iget-object v0, v9, Lc/k3;->w:Ljava/lang/String;

    :goto_28
    iget-object v1, v9, Lc/k3;->c:Lc/n1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v0}, Lc/n1;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_2f

    iget v1, v9, Lc/k3;->s:I

    if-nez v1, :cond_2e

    iput-object v3, v9, Lc/k3;->w:Ljava/lang/String;

    goto :goto_29

    :cond_2e
    iput-object v3, v9, Lc/k3;->v:Ljava/lang/String;

    :cond_2f
    :goto_29
    iget v1, v9, Lc/k3;->s:I

    if-nez v1, :cond_30

    iput-object v2, v9, Lc/k3;->v:Ljava/lang/String;

    iget-object v0, v9, Lc/k3;->w:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 v1, 0x1

    iput v1, v9, Lc/k3;->s:I

    goto :goto_2a

    :cond_30
    iput-object v0, v9, Lc/k3;->w:Ljava/lang/String;

    :cond_31
    :goto_2a
    invoke-static {v7, v6}, Lc/k3;->V(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    invoke-virtual {v9}, Lc/k3;->S()V

    :goto_2b
    return-void

    :pswitch_7
    move-object/from16 v21, v7

    check-cast v9, Lc/k3;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lc/J2;

    check-cast v8, Landroid/widget/TextView;

    move-object/from16 v7, v21

    check-cast v7, Ljava/lang/CharSequence;

    check-cast v6, Ljava/lang/String;

    invoke-direct {v0, v9, v8, v7, v6}, Lc/J2;-><init>(Lc/k3;Landroid/widget/TextView;Ljava/lang/CharSequence;Ljava/lang/String;)V

    sget-object v1, Lc/F8;->a:Ljava/util/concurrent/ExecutorService;

    iget-object v1, v9, Lc/k3;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    new-instance v2, Lc/U3;

    const/4 v3, 0x1

    invoke-direct {v2, v6, v1, v0, v3}, Lc/U3;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/function/Consumer;I)V

    sget-object v0, Lc/F8;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
