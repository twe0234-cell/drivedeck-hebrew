.class public final synthetic Lc/W7;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/Z7;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lc/Z7;Ljava/lang/String;I)V
    .locals 0

    iput p3, p0, Lc/W7;->a:I

    iput-object p1, p0, Lc/W7;->b:Lc/Z7;

    iput-object p2, p0, Lc/W7;->c:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    iget v0, p0, Lc/W7;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, Lc/W7;->b:Lc/Z7;

    iget-object v1, p0, Lc/W7;->c:Ljava/lang/String;

    iget-boolean v2, v0, Lc/Z7;->r:Z

    if-nez v2, :cond_0

    iget-object v2, v0, Lc/Z7;->a:Lc/e8;

    iget-object v2, v2, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget v1, v0, Lc/Z7;->D:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lc/Z7;->D:I

    iget-object v0, v0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    :cond_0
    return-void

    :pswitch_0
    iget-object v0, p0, Lc/W7;->b:Lc/Z7;

    iget-object v1, p0, Lc/W7;->c:Ljava/lang/String;

    iget-boolean v2, v0, Lc/Z7;->r:Z

    if-nez v2, :cond_1

    iget-object v2, v0, Lc/Z7;->a:Lc/e8;

    iget-object v2, v2, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget v1, v0, Lc/Z7;->D:I

    add-int/lit8 v1, v1, 0x1

    iput v1, v0, Lc/Z7;->D:I

    iget-object v0, v0, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    :cond_1
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
