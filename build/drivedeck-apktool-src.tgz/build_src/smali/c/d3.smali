.class public final Lc/d3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic a:Landroid/widget/ScrollView;

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lc/k3;


# direct methods
.method public constructor <init>(Lc/k3;Landroid/widget/ScrollView;ILjava/lang/String;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc/d3;->d:Lc/k3;

    iput-object p2, p0, Lc/d3;->a:Landroid/widget/ScrollView;

    iput p3, p0, Lc/d3;->b:I

    iput-object p4, p0, Lc/d3;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .locals 4

    iget-object v0, p0, Lc/d3;->a:Landroid/widget/ScrollView;

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 v1, 0x0

    iget v2, p0, Lc/d3;->b:I

    invoke-virtual {v0, v1, v2}, Landroid/widget/ScrollView;->scrollTo(II)V

    new-instance v1, Lc/K2;

    iget-object v2, p0, Lc/d3;->c:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-direct {v1, p0, v2, v3}, Lc/K2;-><init>(Landroid/view/ViewTreeObserver$OnPreDrawListener;Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnScrollChangeListener(Landroid/view/View$OnScrollChangeListener;)V

    const/4 v0, 0x1

    return v0
.end method
