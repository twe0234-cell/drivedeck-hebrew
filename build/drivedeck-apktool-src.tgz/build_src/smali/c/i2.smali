.class public final synthetic Lc/i2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc/t2;


# direct methods
.method public synthetic constructor <init>(Lc/t2;I)V
    .locals 0

    iput p2, p0, Lc/i2;->a:I

    iput-object p1, p0, Lc/i2;->b:Lc/t2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 36

    move-object/from16 v0, p0

    const-wide/16 v2, 0x0

    const/4 v4, 0x2

    const/4 v5, -0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v9, v0, Lc/i2;->b:Lc/t2;

    iget v10, v0, Lc/i2;->a:I

    packed-switch v10, :pswitch_data_0

    invoke-virtual {v9}, Lc/t2;->I()V

    return-void

    :pswitch_0
    iget-object v1, v9, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v1}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v9}, Lc/t2;->m()V

    goto/16 :goto_0

    :cond_0
    invoke-virtual {v9}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {v9}, Lc/t2;->e()Z

    move-result v1

    if-eqz v1, :cond_4

    iget-boolean v1, v9, Lc/t2;->t:Z

    if-nez v1, :cond_4

    iget-object v1, v9, Lc/t2;->h:Lc/v7;

    if-nez v1, :cond_4

    iget-object v1, v9, Lc/t2;->u:Ljava/lang/String;

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1

    goto :goto_0

    :cond_1
    iget-wide v10, v9, Lc/t2;->N0:J

    iget-wide v12, v9, Lc/t2;->K:J

    iget v14, v9, Lc/t2;->J0:I

    invoke-virtual {v9}, Lc/t2;->y()I

    move-result v15

    iget-wide v1, v9, Lc/t2;->K0:J

    invoke-virtual {v9}, Lc/t2;->o()J

    move-result-wide v18

    iget-object v3, v9, Lc/t2;->L0:Ljava/lang/String;

    iget-object v4, v9, Lc/t2;->u:Ljava/lang/String;

    iget-object v5, v9, Lc/t2;->M0:Lc/v7;

    iget-object v6, v9, Lc/t2;->d:Lc/v7;

    move-wide/from16 v16, v1

    move-object/from16 v20, v3

    move-object/from16 v21, v4

    move-object/from16 v22, v5

    move-object/from16 v23, v6

    invoke-static/range {v10 .. v23}, Lc/t2;->E(JJIIJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    invoke-virtual {v9}, Lc/t2;->z()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v9}, Lc/t2;->q0()V

    goto :goto_0

    :cond_2
    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, v9, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {v9}, Lc/t2;->y()I

    move-result v4

    invoke-static {v2, v3, v4}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v2

    iget-boolean v3, v9, Lc/t2;->R0:Z

    if-nez v3, :cond_3

    if-eqz v2, :cond_3

    if-gez v2, :cond_4

    if-nez v1, :cond_4

    :cond_3
    invoke-virtual {v9}, Lc/t2;->D()V

    :cond_4
    :goto_0
    return-void

    :pswitch_1
    invoke-virtual {v9}, Lc/t2;->u()V

    return-void

    :pswitch_2
    invoke-virtual {v9}, Lc/t2;->m()V

    return-void

    :pswitch_3
    iget-object v1, v9, Lc/t2;->d:Lc/v7;

    invoke-virtual {v9, v1}, Lc/t2;->R(Lc/v7;)V

    return-void

    :pswitch_4
    invoke-virtual {v9}, Lc/t2;->H()V

    return-void

    :pswitch_5
    iget-object v1, v9, Lc/t2;->b:Landroid/widget/FrameLayout;

    const-string v2, "app-grid"

    invoke-virtual {v1, v2}, Landroid/view/View;->findViewWithTag(Ljava/lang/Object;)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_5

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_5
    invoke-virtual {v9}, Lc/t2;->n0()V

    return-void

    :pswitch_6
    iput-boolean v7, v9, Lc/t2;->n0:Z

    return-void

    :pswitch_7
    invoke-virtual {v9}, Lc/t2;->a()V

    return-void

    :pswitch_8
    iget v1, v9, Lc/t2;->p0:I

    if-ne v1, v4, :cond_6

    iget-object v1, v9, Lc/t2;->m0:Landroid/view/View;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    iget-object v1, v9, Lc/t2;->l0:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v1, v2}, Landroid/view/View;->setAlpha(F)V

    invoke-virtual {v9, v7}, Lc/t2;->b0(Z)V

    :cond_6
    return-void

    :pswitch_9
    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    instance-of v2, v1, Lru/drivedeck/launcher/MainActivity;

    if-eqz v2, :cond_7

    check-cast v1, Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v1}, Lru/drivedeck/launcher/MainActivity;->v()V

    goto :goto_1

    :cond_7
    invoke-virtual {v9}, Landroid/view/View;->getRootView()Landroid/view/View;

    move-result-object v1

    sget-object v2, Lc/b4;->a:Ljava/util/WeakHashMap;

    new-instance v2, Lc/n1;

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lc/n1;->L()I

    move-result v2

    invoke-static {v1, v2}, Lc/b4;->a(Landroid/view/View;I)V

    :goto_1
    return-void

    :pswitch_a
    new-instance v1, Lc/n1;

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Lc/n1;-><init>(Landroid/content/Context;)V

    iget-boolean v2, v9, Lc/t2;->y0:Z

    const-string v3, ""

    iget v4, v9, Lc/t2;->a:I

    if-eqz v2, :cond_9

    if-ne v4, v8, :cond_8

    invoke-virtual {v1, v3}, Lc/n1;->O0(Ljava/lang/String;)Z

    goto :goto_2

    :cond_8
    invoke-virtual {v1, v3}, Lc/n1;->G0(Ljava/lang/String;)Z

    goto :goto_2

    :cond_9
    iget-boolean v2, v9, Lc/t2;->B:Z

    if-nez v2, :cond_a

    iget-object v2, v9, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {v1, v4}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a

    invoke-virtual {v1, v3, v4}, Lc/n1;->P0(Ljava/lang/String;I)V

    :cond_a
    :goto_2
    iget-object v1, v9, Lc/t2;->r:Lc/F;

    invoke-interface {v1, v4}, Lc/s2;->a(I)V

    return-void

    :pswitch_b
    invoke-virtual {v9}, Lc/t2;->D()V

    return-void

    :pswitch_c
    invoke-virtual {v9}, Lc/t2;->n0()V

    return-void

    :pswitch_d
    iget v1, v9, Lc/t2;->p0:I

    if-eq v1, v4, :cond_b

    goto :goto_3

    :cond_b
    iput-boolean v7, v9, Lc/t2;->t0:Z

    iget-object v1, v9, Lc/t2;->l0:Landroid/widget/FrameLayout;

    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const-wide/16 v3, 0x8c

    invoke-virtual {v1, v3, v4}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->start()V

    iget-object v1, v9, Lc/t2;->m0:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {v1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const/high16 v2, 0x40a00000    # 5.0f

    invoke-virtual {v9, v2}, Lc/t2;->p(F)I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1, v3, v4}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    new-instance v2, Lc/i2;

    const/16 v3, 0xe

    invoke-direct {v2, v9, v3}, Lc/i2;-><init>(Lc/t2;I)V

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->start()V

    :goto_3
    return-void

    :pswitch_e
    iget-wide v4, v9, Lc/t2;->i0:J

    cmp-long v1, v4, v2

    if-nez v1, :cond_c

    goto :goto_4

    :cond_c
    iput-wide v2, v9, Lc/t2;->i0:J

    iput-boolean v8, v9, Lc/t2;->j0:Z

    invoke-virtual {v9}, Lc/t2;->a()V

    :goto_4
    return-void

    :pswitch_f
    iget-boolean v1, v9, Lc/t2;->E:Z

    iget-object v2, v9, Lc/t2;->d0:Lc/H;

    if-eqz v2, :cond_d

    move v2, v8

    goto :goto_5

    :cond_d
    move v2, v7

    :goto_5
    iget-object v3, v9, Lc/t2;->e0:Lc/v7;

    if-eqz v3, :cond_e

    move v7, v8

    :cond_e
    if-nez v1, :cond_11

    if-eqz v2, :cond_11

    if-eqz v7, :cond_11

    iput-object v6, v9, Lc/t2;->e0:Lc/v7;

    iget-wide v1, v9, Lc/t2;->H:J

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    iget v1, v9, Lc/t2;->a:I

    if-gez v1, :cond_f

    const-string v1, "home"

    :goto_6
    move-object v13, v1

    goto :goto_7

    :cond_f
    if-nez v1, :cond_10

    const-string v1, "left"

    goto :goto_6

    :cond_10
    const-string v1, "right"

    goto :goto_6

    :goto_7
    invoke-static {v3}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const-string v16, "action"

    const-string v17, "hide"

    const-string v10, "transition_id"

    const-string v12, "pane_id"

    const-string v14, "renderer_id"

    const-string v18, "reason"

    const-string v19, "timeout"

    filled-new-array/range {v10 .. v19}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "pane_presentation_timeout"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-wide v1, v9, Lc/t2;->H:J

    const-string v4, "hide_timeout"

    invoke-virtual {v9, v3, v1, v2, v4}, Lc/t2;->M(Lc/v7;JLjava/lang/String;)V

    iget-object v1, v9, Lc/t2;->d0:Lc/H;

    iput-object v6, v9, Lc/t2;->d0:Lc/H;

    if-eqz v1, :cond_11

    invoke-virtual {v1}, Lc/H;->run()V

    :cond_11
    return-void

    :pswitch_10
    iget-object v1, v9, Lc/t2;->P:Lc/v7;

    if-nez v1, :cond_12

    goto :goto_8

    :cond_12
    iget v1, v9, Lc/t2;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    iget-object v1, v9, Lc/t2;->S:Ljava/lang/String;

    iget v2, v9, Lc/t2;->T:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    const-string v16, "package"

    const-string v18, "old_display_id"

    const-string v10, "phase"

    const-string v11, "failed"

    const-string v12, "reason"

    const-string v13, "timeout"

    const-string v14, "slot"

    move-object/from16 v17, v1

    filled-new-array/range {v10 .. v19}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "activity_view_fallback"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    const-string v1, "timeout"

    invoke-virtual {v9, v1}, Lc/t2;->g(Ljava/lang/String;)V

    :goto_8
    return-void

    :pswitch_11
    iget v1, v9, Lc/t2;->V:I

    const-string v2, "focus_retry"

    invoke-virtual {v9, v2, v1}, Lc/t2;->v(Ljava/lang/String;I)V

    return-void

    :pswitch_12
    iget-object v4, v0, Lc/i2;->b:Lc/t2;

    iput-boolean v7, v4, Lc/t2;->J:Z

    iget-wide v1, v4, Lc/t2;->L:J

    iget-object v9, v4, Lc/t2;->M:Ljava/lang/String;

    invoke-virtual {v4, v1, v2, v9}, Lc/t2;->A(JLjava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_13

    goto/16 :goto_c

    :cond_13
    iget-object v3, v4, Lc/t2;->d:Lc/v7;

    iget-object v10, v4, Lc/t2;->b:Landroid/widget/FrameLayout;

    iget-boolean v6, v3, Lc/v7;->o:Z

    if-nez v6, :cond_18

    iget-boolean v6, v3, Lc/v7;->p:Z

    if-nez v6, :cond_18

    if-eqz v10, :cond_18

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    if-ne v6, v10, :cond_14

    goto :goto_a

    :cond_14
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v6

    instance-of v11, v6, Landroid/view/ViewGroup;

    if-eqz v11, :cond_15

    check-cast v6, Landroid/view/ViewGroup;

    invoke-virtual {v6, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    goto :goto_9

    :cond_15
    if-eqz v6, :cond_17

    :cond_16
    move v3, v7

    goto :goto_b

    :cond_17
    :goto_9
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v6, v5, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v3, v7, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    if-ne v3, v10, :cond_16

    move v3, v8

    goto :goto_b

    :cond_18
    :goto_a
    iget-boolean v3, v3, Lc/v7;->o:Z

    xor-int/2addr v3, v8

    :goto_b
    if-eqz v3, :cond_19

    iget-object v5, v4, Lc/t2;->d:Lc/v7;

    invoke-virtual {v5}, Lc/v7;->p()Z

    move-result v5

    if-eqz v5, :cond_19

    move v7, v8

    :cond_19
    iget v5, v4, Lc/t2;->a:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    iget-object v5, v4, Lc/t2;->u:Ljava/lang/String;

    iget-object v6, v4, Lc/t2;->d:Lc/v7;

    invoke-static {v6}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v18

    iget-object v6, v4, Lc/t2;->d:Lc/v7;

    invoke-virtual {v6}, Lc/v7;->f()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v20

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v22

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v24

    const-string v21, "reparented"

    const-string v23, "reasserted"

    const-string v11, "phase"

    const-string v12, "attempt"

    const-string v13, "slot"

    const-string v15, "package"

    const-string v17, "renderer_id"

    const-string v19, "display_id"

    move-object/from16 v16, v5

    filled-new-array/range {v11 .. v24}, [Ljava/lang/Object;

    move-result-object v3

    const-string v5, "activity_view_reattach"

    invoke-static {v5, v3}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    if-nez v7, :cond_1a

    invoke-virtual {v4, v1, v2, v9}, Lc/t2;->p0(JLjava/lang/String;)V

    goto :goto_c

    :cond_1a
    new-instance v11, Lc/k1;

    const/4 v8, 0x2

    move-object v3, v11

    move-wide v5, v1

    move-object v7, v9

    invoke-direct/range {v3 .. v8}, Lc/k1;-><init>(Ljava/lang/Object;JLjava/lang/Object;I)V

    invoke-virtual {v10, v11}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    :goto_c
    return-void

    :pswitch_13
    iget-boolean v1, v9, Lc/t2;->l:Z

    if-eqz v1, :cond_1d

    iget-wide v1, v9, Lc/t2;->p:J

    iget-wide v3, v9, Lc/t2;->o:J

    cmp-long v1, v1, v3

    if-eqz v1, :cond_1b

    goto :goto_e

    :cond_1b
    iput-boolean v8, v9, Lc/t2;->k:Z

    iget v1, v9, Lc/t2;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v9}, Landroid/view/View;->isShown()Z

    move-result v1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v13

    invoke-virtual {v9}, Lc/t2;->y()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    iget-object v1, v9, Lc/t2;->h:Lc/v7;

    if-nez v1, :cond_1c

    goto :goto_d

    :cond_1c
    invoke-virtual {v1}, Lc/v7;->f()I

    move-result v5

    :goto_d
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    const-string v14, "current_display"

    const-string v16, "retiring_display"

    const-string v10, "slot"

    const-string v12, "visible"

    filled-new-array/range {v10 .. v17}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "renderer_migration_timeout"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const-string v3, "\u041f\u0435\u0440\u0435\u043d\u043e\u0441 \u043e\u043a\u043d\u0430 \u043d\u0435 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043b\u0441\u044f. \u041e\u0431\u0430 \u043e\u043a\u043d\u0430 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u044b."

    invoke-static {v2, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    :cond_1d
    :goto_e
    return-void

    :pswitch_14
    iget-object v4, v0, Lc/i2;->b:Lc/t2;

    iget-boolean v9, v4, Lc/t2;->t:Z

    if-nez v9, :cond_2f

    invoke-virtual {v4}, Landroid/view/View;->isShown()Z

    move-result v9

    if-eqz v9, :cond_2f

    invoke-virtual {v4}, Lc/t2;->e()Z

    move-result v9

    if-eqz v9, :cond_2f

    iget-object v9, v4, Lc/t2;->h:Lc/v7;

    if-nez v9, :cond_2f

    iget-object v9, v4, Lc/t2;->u:Ljava/lang/String;

    if-eqz v9, :cond_2f

    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_2f

    iget-wide v9, v4, Lc/t2;->N0:J

    iget-wide v11, v4, Lc/t2;->K:J

    cmp-long v9, v9, v11

    if-nez v9, :cond_2f

    iget-object v9, v4, Lc/t2;->M0:Lc/v7;

    iget-object v10, v4, Lc/t2;->d:Lc/v7;

    if-ne v9, v10, :cond_2f

    iget-wide v9, v4, Lc/t2;->O0:J

    cmp-long v9, v9, v2

    if-gtz v9, :cond_1e

    goto/16 :goto_17

    :cond_1e
    invoke-virtual {v4}, Lc/t2;->y()I

    move-result v9

    invoke-virtual {v4}, Lc/t2;->o()J

    move-result-wide v10

    if-ltz v9, :cond_2f

    iget v12, v4, Lc/t2;->J0:I

    if-ne v9, v12, :cond_2f

    iget-wide v12, v4, Lc/t2;->K0:J

    cmp-long v12, v10, v12

    if-nez v12, :cond_2f

    iget-object v12, v4, Lc/t2;->u:Ljava/lang/String;

    iget-object v13, v4, Lc/t2;->L0:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_1f

    goto/16 :goto_17

    :cond_1f
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v12

    iget-object v13, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v12, v13, v9}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v12

    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v13

    iget-object v14, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v13, v14, v9}, Lc/j8;->p(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v13

    if-nez v9, :cond_20

    move v14, v7

    goto :goto_f

    :cond_20
    invoke-virtual {v4}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v14

    iget-object v15, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v14, v15, v7}, Lc/j8;->R(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v14

    :goto_f
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v15

    iget-wide v5, v4, Lc/t2;->O0:J

    cmp-long v5, v15, v5

    if-ltz v5, :cond_21

    move v5, v8

    goto :goto_10

    :cond_21
    move v5, v7

    :goto_10
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v15, 0x4

    if-eqz v5, :cond_22

    move v5, v15

    goto :goto_11

    :cond_22
    iget v5, v4, Lc/t2;->Q0:I

    add-int/2addr v5, v8

    iput v5, v4, Lc/t2;->Q0:I

    :goto_11
    const/16 v1, 0x1d

    if-ne v12, v8, :cond_24

    if-ne v13, v8, :cond_24

    if-ge v6, v1, :cond_23

    if-nez v14, :cond_24

    :cond_23
    move v5, v8

    goto :goto_12

    :cond_24
    if-ge v5, v15, :cond_25

    move v5, v7

    goto :goto_12

    :cond_25
    const/4 v5, -0x1

    :goto_12
    const-string v15, "legacy_fresh_or_restore"

    const-string v18, "separate_task"

    const-string v1, "task_placement"

    if-ne v5, v8, :cond_27

    iput-wide v2, v4, Lc/t2;->O0:J

    iput v7, v4, Lc/t2;->Q0:I

    iget v2, v4, Lc/t2;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v21

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v25

    iget-object v2, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v29

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v31

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v33

    iget-object v3, v4, Lc/t2;->S0:Ljava/lang/String;

    const-string v32, "top_state"

    const-string v34, "pair_switch_id"

    const-string v20, "slot"

    const-string v22, "display"

    const-string v24, "display_first_seen_elapsed_ns"

    const-string v26, "package"

    const-string v28, "target_state"

    const-string v30, "default_state"

    move-object/from16 v27, v2

    move-object/from16 v35, v3

    filled-new-array/range {v20 .. v35}, [Ljava/lang/Object;

    move-result-object v2

    const-string v3, "pane_launch_confirmed"

    invoke-static {v3, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v2, v4, Lc/t2;->S0:Ljava/lang/String;

    const/16 v3, 0x1d

    if-lt v6, v3, :cond_26

    move-object/from16 v23, v18

    goto :goto_13

    :cond_26
    move-object/from16 v23, v15

    :goto_13
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v29

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v31

    iget-object v3, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v35

    const-string v32, "package"

    const-string v34, "display_id"

    const-string v20, "pair_switch_id"

    const-string v22, "strategy"

    const-string v24, "result"

    const-string v25, "confirmed"

    const-string v26, "reason"

    const-string v27, "target_top"

    const-string v28, "target_state"

    const-string v30, "top_state"

    move-object/from16 v21, v2

    move-object/from16 v33, v3

    filled-new-array/range {v20 .. v35}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v1, v4, Lc/t2;->A:Ljava/lang/Runnable;

    const/4 v2, 0x0

    iput-object v2, v4, Lc/t2;->A:Ljava/lang/Runnable;

    if-eqz v1, :cond_2f

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto/16 :goto_17

    :cond_27
    if-nez v5, :cond_29

    if-ne v12, v8, :cond_28

    if-nez v13, :cond_28

    const/16 v1, 0x1b

    if-ne v6, v1, :cond_28

    iget-object v1, v4, Lc/t2;->d:Lc/v7;

    if-eqz v1, :cond_28

    invoke-virtual {v1}, Lc/v7;->l()Z

    move-result v1

    if-eqz v1, :cond_28

    const-string v1, "launch_verify"

    iget v2, v4, Lc/t2;->V:I

    invoke-virtual {v4, v1, v2}, Lc/t2;->v(Ljava/lang/String;I)V

    :cond_28
    iget-object v1, v4, Lc/t2;->Z0:Lc/i2;

    const-wide/16 v2, 0x2ee

    invoke-virtual {v4, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_17

    :cond_29
    if-ne v12, v8, :cond_2b

    if-nez v13, :cond_2b

    const-string v2, "target_not_top"

    :cond_2a
    :goto_14
    move-object v3, v2

    goto :goto_15

    :cond_2b
    const-string v2, "uncertain"

    if-ne v12, v8, :cond_2c

    if-gez v13, :cond_2c

    goto :goto_14

    :cond_2c
    if-ne v14, v8, :cond_2d

    const-string v2, "default_display"

    goto :goto_14

    :cond_2d
    if-nez v12, :cond_2a

    if-nez v14, :cond_2a

    const-string v2, "absent"

    goto :goto_14

    :goto_15
    iget-object v2, v4, Lc/t2;->S0:Ljava/lang/String;

    const/16 v5, 0x1d

    if-lt v6, v5, :cond_2e

    move-object/from16 v23, v18

    goto :goto_16

    :cond_2e
    move-object/from16 v23, v15

    :goto_16
    iget-object v5, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v31

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v33

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v35

    const-string v32, "target_state"

    const-string v34, "top_state"

    const-string v20, "pair_switch_id"

    const-string v22, "strategy"

    const-string v24, "result"

    const-string v25, "unconfirmed"

    const-string v26, "reason"

    const-string v28, "package"

    const-string v30, "display_id"

    move-object/from16 v21, v2

    move-object/from16 v27, v3

    move-object/from16 v29, v5

    filled-new-array/range {v20 .. v35}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v1, v2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x1

    move-object v2, v4

    move v4, v12

    move v5, v14

    move v7, v13

    invoke-virtual/range {v2 .. v7}, Lc/t2;->r(Ljava/lang/String;IIZI)V

    :cond_2f
    :goto_17
    return-void

    :pswitch_15
    iget-boolean v1, v9, Lc/t2;->t:Z

    if-nez v1, :cond_34

    iget-object v1, v9, Lc/t2;->h:Lc/v7;

    if-eqz v1, :cond_34

    invoke-virtual {v9}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_34

    iget-boolean v1, v9, Lc/t2;->k:Z

    if-eqz v1, :cond_30

    goto :goto_1b

    :cond_30
    iget-object v1, v9, Lc/t2;->d:Lc/v7;

    invoke-virtual {v1}, Lc/v7;->l()Z

    move-result v2

    if-eqz v2, :cond_31

    const-string v2, "ready_timeout"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Lc/v7;->t(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_18

    :cond_31
    const/4 v3, 0x0

    :goto_18
    iget-object v2, v9, Lc/t2;->h:Lc/v7;

    iput-object v2, v9, Lc/t2;->d:Lc/v7;

    iput-object v3, v9, Lc/t2;->h:Lc/v7;

    iget-object v2, v9, Lc/t2;->b:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    invoke-static {}, Lc/t2;->V()Z

    move-result v2

    if-eqz v2, :cond_32

    iget-boolean v2, v9, Lc/t2;->j:Z

    if-eqz v2, :cond_32

    iput-object v1, v9, Lc/t2;->i:Lc/v7;

    goto :goto_19

    :cond_32
    invoke-virtual {v1}, Lc/v7;->r()V

    :goto_19
    iput-boolean v7, v9, Lc/t2;->j:Z

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v9}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v3

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v1, v1, Lc/v7;->c:Ljava/lang/String;

    invoke-static {v1, v4}, Lc/t2;->j0(Ljava/lang/String;I)Z

    move-result v1

    if-eqz v1, :cond_33

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0434\u043e\u0436\u0434\u0430\u0442\u044c\u0441\u044f \u043e\u043a\u043d\u0430. \u0421\u043e\u0445\u0440\u0430\u043d\u0451\u043d \u043f\u0440\u0435\u0436\u043d\u0438\u0439 \u0440\u0435\u0436\u0438\u043c."

    goto :goto_1a

    :cond_33
    const-string v1, "ActivityView \u043d\u0435 \u0437\u0430\u043f\u0443\u0441\u0442\u0438\u043b\u0441\u044f. \u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e \u043f\u0440\u0435\u0436\u043d\u0435\u0435 \u043e\u043a\u043d\u043e."

    :goto_1a
    invoke-static {v3, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    invoke-virtual {v9}, Lc/t2;->n0()V

    :cond_34
    :goto_1b
    return-void

    :pswitch_16
    invoke-virtual {v9}, Landroid/view/View;->isShown()Z

    move-result v1

    if-eqz v1, :cond_37

    invoke-virtual {v9}, Lc/t2;->e()Z

    move-result v1

    if-eqz v1, :cond_37

    iget-boolean v1, v9, Lc/t2;->t:Z

    if-eqz v1, :cond_35

    goto :goto_1c

    :cond_35
    invoke-virtual {v9}, Lc/t2;->J()V

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1b

    if-ne v1, v2, :cond_36

    iget-object v1, v9, Lc/t2;->d:Lc/v7;

    if-eqz v1, :cond_36

    invoke-virtual {v1}, Lc/v7;->l()Z

    move-result v1

    if-eqz v1, :cond_36

    iput-boolean v8, v9, Lc/t2;->I:Z

    const-wide/16 v1, 0x78

    invoke-virtual {v9, v1, v2}, Lc/t2;->Z(J)V

    goto :goto_1c

    :cond_36
    iget-object v1, v9, Lc/t2;->d:Lc/v7;

    if-eqz v1, :cond_37

    invoke-virtual {v1}, Lc/v7;->q()V

    :cond_37
    :goto_1c
    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
