.class public final Lc/c6;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lc/a6;

.field public final b:Lc/l6;

.field public final c:Ljava/util/ArrayList;

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public final h:I

.field public i:Z

.field public j:Z


# direct methods
.method public constructor <init>(Lc/a6;Lc/l6;)V
    .locals 12

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/c6;->c:Ljava/util/ArrayList;

    iput-object p1, p0, Lc/c6;->a:Lc/a6;

    iput-object p2, p0, Lc/c6;->b:Lc/l6;

    iget-boolean v1, p1, Lc/a6;->c:Z

    if-nez p2, :cond_0

    move v2, v1

    goto :goto_0

    :cond_0
    iget-boolean v2, p2, Lc/l6;->g:Z

    :goto_0
    if-nez p2, :cond_1

    iget v3, p1, Lc/a6;->a:I

    goto :goto_1

    :cond_1
    iget v3, p2, Lc/l6;->b:I

    :goto_1
    const/4 v4, 0x1

    const-string v5, "ATZ"

    iget v6, p1, Lc/a6;->b:I

    const/16 v7, 0xb

    if-eqz v2, :cond_4

    if-ne v6, v4, :cond_2

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    const-string v8, "ATE0"

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v9, p1, Lc/a6;->d:Ljava/lang/String;

    invoke-static {v9}, Lc/G8;->Q0(Ljava/lang/String;)Ljava/util/List;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v10}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_3

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    invoke-virtual {v9, v10}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "ATH1"

    invoke-virtual {v8, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_7

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3

    :cond_4
    if-ne v3, v7, :cond_5

    invoke-static {}, Lc/G8;->P0()Ljava/util/List;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_3

    :cond_5
    if-nez p2, :cond_6

    invoke-static {v3}, Lc/n6;->c(I)Ljava/util/List;

    move-result-object v8

    goto :goto_2

    :cond_6
    iget v8, p2, Lc/l6;->b:I

    invoke-static {v8}, Lc/n6;->c(I)Ljava/util/List;

    move-result-object v8

    :goto_2
    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_7
    :goto_3
    if-nez p2, :cond_8

    goto :goto_4

    :cond_8
    iget v6, p2, Lc/l6;->d:I

    :goto_4
    if-ne v6, v7, :cond_9

    invoke-static {v3}, Lc/G8;->h0(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_9

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_9
    const-string v6, "ATST"

    if-eqz p2, :cond_b

    if-nez v2, :cond_b

    iget-object v2, p1, Lc/a6;->f:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_a

    invoke-virtual {v6, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_a
    iget-object v2, p1, Lc/a6;->g:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_b

    const-string v8, "ATSH"

    invoke-virtual {v8, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_b
    if-eqz p2, :cond_c

    iget-boolean v2, p2, Lc/l6;->i:Z

    if-eqz v2, :cond_c

    const-string v2, "ATST96"

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_c
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    iput v2, p0, Lc/c6;->h:I

    const/4 v2, 0x0

    move v8, v2

    :goto_5
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v9

    if-ge v8, v9, :cond_e

    invoke-virtual {v0, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v9, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_d

    iput v8, p0, Lc/c6;->h:I

    :cond_d
    add-int/lit8 v8, v8, 0x1

    goto :goto_5

    :cond_e
    if-eqz p2, :cond_11

    if-eq v3, v7, :cond_10

    const/16 p2, 0x2b

    if-ne v3, p2, :cond_f

    goto :goto_6

    :cond_f
    iget-object p1, p1, Lc/a6;->e:Ljava/lang/String;

    goto :goto_7

    :cond_10
    :goto_6
    const-string p1, "221201"

    :goto_7
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_11
    if-nez v1, :cond_13

    iget-object p1, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_12

    iget-object p1, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_13

    :cond_12
    iget-object p1, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {p1, v2, v5}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget p1, p0, Lc/c6;->h:I

    add-int/2addr p1, v4

    iput p1, p0, Lc/c6;->h:I

    :cond_13
    return-void
.end method

.method public static f(Ljava/lang/String;)I
    .locals 6

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, -0x1

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v5

    sparse-switch v5, :sswitch_data_0

    :goto_0
    move p0, v4

    goto :goto_1

    :sswitch_0
    const-string v5, "96"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    move p0, v0

    goto :goto_1

    :sswitch_1
    const-string v5, "64"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_1

    goto :goto_0

    :cond_1
    move p0, v1

    goto :goto_1

    :sswitch_2
    const-string v5, "48"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2

    goto :goto_0

    :cond_2
    move p0, v2

    goto :goto_1

    :sswitch_3
    const-string v5, "32"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3

    goto :goto_0

    :cond_3
    move p0, v3

    goto :goto_1

    :sswitch_4
    const-string v5, "16"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_4

    goto :goto_0

    :cond_4
    const/4 p0, 0x1

    goto :goto_1

    :sswitch_5
    const-string v5, "08"

    invoke-virtual {p0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5

    goto :goto_0

    :cond_5
    const/4 p0, 0x0

    :goto_1
    packed-switch p0, :pswitch_data_0

    return v4

    :pswitch_0
    const/4 p0, 0x7

    return p0

    :pswitch_1
    const/4 p0, 0x6

    return p0

    :pswitch_2
    return v0

    :pswitch_3
    return v1

    :pswitch_4
    return v2

    :pswitch_5
    return v3

    :sswitch_data_0
    .sparse-switch
        0x608 -> :sswitch_5
        0x625 -> :sswitch_4
        0x65f -> :sswitch_3
        0x684 -> :sswitch_2
        0x6be -> :sswitch_1
        0x71d -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final a(Ljava/lang/String;)V
    .locals 7

    iget-boolean v0, p0, Lc/c6;->i:Z

    if-nez v0, :cond_7

    iget-boolean v0, p0, Lc/c6;->j:Z

    if-nez v0, :cond_7

    if-nez p1, :cond_0

    const-string p1, ""

    goto :goto_0

    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    :goto_0
    iget-object v0, p0, Lc/c6;->c:Ljava/util/ArrayList;

    iget-object v1, p0, Lc/c6;->b:Lc/l6;

    const/4 v2, 0x0

    const-string v3, "CAN ERROR"

    const-string v4, "UNABLE TO CONNECT"

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    iget v1, p0, Lc/c6;->d:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v5

    if-ne v1, v6, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "NO DATA"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "?"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "ERROR"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_1

    move v2, v5

    :cond_1
    invoke-virtual {p0, v2}, Lc/c6;->b(Z)V

    return-void

    :cond_2
    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_6

    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_3

    goto :goto_1

    :cond_3
    const-string v1, "BUS INIT: ERROR"

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_4

    iget p1, p0, Lc/c6;->d:I

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-string v1, "2212010401"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    iget p1, p0, Lc/c6;->e:I

    if-ge p1, v5, :cond_4

    add-int/2addr p1, v5

    iput p1, p0, Lc/c6;->e:I

    return-void

    :cond_4
    iput v2, p0, Lc/c6;->e:I

    iget p1, p0, Lc/c6;->d:I

    add-int/2addr p1, v5

    iput p1, p0, Lc/c6;->d:I

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt p1, v0, :cond_5

    iput-boolean v5, p0, Lc/c6;->j:Z

    :cond_5
    return-void

    :cond_6
    :goto_1
    iput-boolean v5, p0, Lc/c6;->i:Z

    :cond_7
    return-void
.end method

.method public final b(Z)V
    .locals 5

    iget-boolean v0, p0, Lc/c6;->i:Z

    if-nez v0, :cond_8

    iget-boolean v0, p0, Lc/c6;->j:Z

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p1, :cond_6

    const/4 p1, 0x2

    iget-object v2, p0, Lc/c6;->b:Lc/l6;

    if-nez v2, :cond_2

    :cond_1
    move v3, v1

    goto :goto_0

    :cond_2
    iget-boolean v3, v2, Lc/l6;->g:Z

    if-eqz v3, :cond_3

    move v3, p1

    goto :goto_0

    :cond_3
    iget v3, v2, Lc/l6;->d:I

    if-nez v3, :cond_1

    iget v3, v2, Lc/l6;->e:I

    :goto_0
    if-eqz v2, :cond_4

    iget v4, p0, Lc/c6;->f:I

    add-int/2addr v4, v1

    iput v4, p0, Lc/c6;->f:I

    if-ge v4, v3, :cond_4

    return-void

    :cond_4
    iput v0, p0, Lc/c6;->f:I

    if-eqz v2, :cond_5

    iget-boolean v0, v2, Lc/l6;->g:Z

    if-nez v0, :cond_5

    iget v0, p0, Lc/c6;->g:I

    add-int/2addr v0, v1

    iput v0, p0, Lc/c6;->g:I

    if-ge v0, p1, :cond_5

    iget p1, p0, Lc/c6;->h:I

    iput p1, p0, Lc/c6;->d:I

    return-void

    :cond_5
    iput-boolean v1, p0, Lc/c6;->i:Z

    return-void

    :cond_6
    iget p1, p0, Lc/c6;->d:I

    add-int/2addr p1, v1

    iput p1, p0, Lc/c6;->d:I

    iget-object v2, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lt p1, v2, :cond_7

    move v0, v1

    :cond_7
    iput-boolean v0, p0, Lc/c6;->j:Z

    :cond_8
    :goto_1
    return-void
.end method

.method public final c(IZ)Z
    .locals 2

    invoke-virtual {p0}, Lc/c6;->e()Lc/b6;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-boolean v0, v0, Lc/b6;->d:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/c6;->b:Lc/l6;

    if-eqz v0, :cond_0

    iget-boolean v1, v0, Lc/l6;->g:Z

    if-nez v1, :cond_0

    iget v0, v0, Lc/l6;->d:I

    if-nez v0, :cond_0

    if-nez p2, :cond_0

    const/16 p2, 0x800

    if-le p1, p2, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final d(Ljava/lang/String;)V
    .locals 4

    iget-object v0, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_0
    if-ltz v1, :cond_1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v3, "ATST"

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, v1, p1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_0
    add-int/lit8 v1, v1, -0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final e()Lc/b6;
    .locals 7

    iget-boolean v0, p0, Lc/c6;->i:Z

    const/4 v1, 0x1

    if-nez v0, :cond_9

    iget-boolean v0, p0, Lc/c6;->j:Z

    if-nez v0, :cond_9

    iget v0, p0, Lc/c6;->d:I

    iget-object v2, p0, Lc/c6;->c:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lt v0, v3, :cond_0

    goto/16 :goto_4

    :cond_0
    iget v0, p0, Lc/c6;->d:I

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iget-object v3, p0, Lc/c6;->b:Lc/l6;

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    iget v5, p0, Lc/c6;->d:I

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    sub-int/2addr v2, v1

    if-ne v5, v2, :cond_1

    move v2, v1

    goto :goto_0

    :cond_1
    move v2, v4

    :goto_0
    if-eqz v2, :cond_4

    iget-boolean v5, v3, Lc/l6;->g:Z

    if-nez v5, :cond_3

    iget v5, v3, Lc/l6;->d:I

    if-eqz v5, :cond_2

    goto :goto_1

    :cond_2
    iget v3, v3, Lc/l6;->f:I

    goto :goto_2

    :cond_3
    :goto_1
    const/16 v3, 0x3a98

    goto :goto_2

    :cond_4
    const-string v3, "ATZ"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5

    const/16 v3, 0x1770

    goto :goto_2

    :cond_5
    const-string v3, "2212010401"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_6

    const/16 v3, 0x2710

    goto :goto_2

    :cond_6
    const/16 v3, 0x9c4

    :goto_2
    iget-object v5, p0, Lc/c6;->a:Lc/a6;

    iget v6, v5, Lc/a6;->b:I

    if-ne v6, v1, :cond_7

    goto :goto_3

    :cond_7
    move v1, v4

    :goto_3
    iget-boolean v5, v5, Lc/a6;->c:Z

    if-eqz v5, :cond_8

    iget v5, p0, Lc/c6;->d:I

    if-lt v5, v1, :cond_8

    add-int/lit8 v1, v1, 0x2

    if-ge v5, v1, :cond_8

    const/16 v4, 0x12c

    :cond_8
    new-instance v1, Lc/b6;

    invoke-direct {v1, v3, v4, v0, v2}, Lc/b6;-><init>(IILjava/lang/String;Z)V

    return-object v1

    :cond_9
    :goto_4
    iget-boolean v0, p0, Lc/c6;->i:Z

    xor-int/2addr v0, v1

    iput-boolean v0, p0, Lc/c6;->j:Z

    const/4 v0, 0x0

    return-object v0
.end method
