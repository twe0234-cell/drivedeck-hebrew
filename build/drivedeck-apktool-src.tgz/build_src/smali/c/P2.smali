.class public final synthetic Lc/P2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Landroid/view/KeyEvent$Callback;


# direct methods
.method public synthetic constructor <init>(Landroid/view/KeyEvent$Callback;II)V
    .locals 0

    iput p3, p0, Lc/P2;->a:I

    iput-object p1, p0, Lc/P2;->c:Landroid/view/KeyEvent$Callback;

    iput p2, p0, Lc/P2;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    iget v0, p0, Lc/P2;->a:I

    packed-switch v0, :pswitch_data_0

    iget-object p1, p0, Lc/P2;->c:Landroid/view/KeyEvent$Callback;

    check-cast p1, Lc/O7;

    iget v0, p0, Lc/P2;->b:I

    invoke-virtual {p1, v0}, Lc/O7;->r(I)V

    return-void

    :pswitch_0
    iget-object p1, p0, Lc/P2;->c:Landroid/view/KeyEvent$Callback;

    check-cast p1, Lc/a5;

    iget-object v0, p1, Lc/a5;->f:Lc/Y4;

    invoke-virtual {v0}, Landroid/view/View;->getScrollX()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x40800000    # 4.0f

    invoke-static {v1, v2}, Lc/G8;->a(Landroid/content/Context;F)I

    move-result v1

    iget v2, p1, Lc/a5;->s:I

    add-int/2addr v1, v2

    int-to-float v1, v1

    div-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    iget v1, p0, Lc/P2;->b:I

    add-int/2addr v0, v1

    const/4 v1, 0x1

    invoke-virtual {p1, v0, v1}, Lc/a5;->b(IZ)V

    return-void

    :pswitch_1
    iget-object v0, p0, Lc/P2;->c:Landroid/view/KeyEvent$Callback;

    check-cast v0, Lc/k3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/N2;

    iget v2, p0, Lc/P2;->b:I

    const/4 v3, 0x2

    invoke-direct {v1, v0, v2, v3}, Lc/N2;-><init>(Lc/k3;II)V

    invoke-static {p1, v1}, Lc/k3;->p0(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
