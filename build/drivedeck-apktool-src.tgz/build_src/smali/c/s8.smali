.class public interface abstract Lc/s8;
.super Ljava/lang/Object;
.source "SourceFile"
