.class public final Lc/T5;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static E2:Lc/T5;


# instance fields
.field public volatile A:Z

.field public A0:Ljava/lang/String;

.field public final A1:Ljava/util/LinkedHashMap;

.field public A2:J

.field public B:Z

.field public final B0:Ljava/util/HashMap;

.field public final B1:Ljava/util/HashSet;

.field public B2:Ljava/lang/Double;

.field public C:Lc/S5;

.field public C0:Lc/k7;

.field public C1:Ljava/lang/String;

.field public final C2:Lc/I5;

.field public D:J

.field public D0:Lc/j7;

.field public D1:Ljava/lang/String;

.field public final D2:Lc/K5;

.field public E:J

.field public E0:I

.field public E1:Ljava/lang/String;

.field public final F:Lc/A5;

.field public F0:Lc/g6;

.field public F1:Z

.field public final G:Lc/A5;

.field public G0:Lc/f6;

.field public G1:Z

.field public final H:Lc/A5;

.field public H0:Lc/e6;

.field public H1:Z

.field public volatile I:Landroid/bluetooth/BluetoothSocket;

.field public I0:Lc/d6;

.field public I1:Z

.field public final J:Lc/M6;

.field public J0:Ljava/lang/String;

.field public J1:Landroid/bluetooth/BluetoothGatt;

.field public volatile K:Ljava/io/OutputStream;

.field public K0:Z

.field public K1:Landroid/bluetooth/BluetoothGattCharacteristic;

.field public volatile L:Lc/N6;

.field public L0:Z

.field public L1:Landroid/bluetooth/BluetoothGattCharacteristic;

.field public volatile M:Lc/P6;

.field public M0:Z

.field public M1:Landroid/bluetooth/BluetoothGattDescriptor;

.field public N:Lc/N5;

.field public final N0:Ljava/util/HashSet;

.field public final N1:Ljava/util/ArrayList;

.field public final O:Ljava/util/concurrent/ExecutorService;

.field public O0:Lc/c6;

.field public O1:I

.field public P:Ljava/lang/String;

.field public P0:Lc/b6;

.field public P1:I

.field public Q:Ljava/lang/String;

.field public final Q0:Ljava/util/LinkedHashSet;

.field public Q1:I

.field public R:Ljava/lang/String;

.field public final R0:Ljava/util/HashMap;

.field public R1:[[B

.field public S:Ljava/lang/String;

.field public final S0:Ljava/util/HashMap;

.field public S1:[[B

.field public T:I

.field public final T0:Ljava/util/HashMap;

.field public T1:Z

.field public U:I

.field public U0:I

.field public U1:Z

.field public V:I

.field public final V0:Lc/v8;

.field public V1:Z

.field public W:I

.field public final W0:Ljava/util/LinkedHashMap;

.field public final W1:Ljava/lang/StringBuilder;

.field public X:Ljava/lang/String;

.field public final X0:Ljava/util/LinkedHashMap;

.field public final X1:Lc/A5;

.field public Y:Ljava/lang/String;

.field public final Y0:Ljava/util/LinkedHashMap;

.field public final Y1:Lc/A5;

.field public Z:Ljava/lang/String;

.field public final Z0:Ljava/util/Set;

.field public Z1:Landroid/bluetooth/le/BluetoothLeScanner;

.field public final a:Landroid/content/Context;

.field public a0:I

.field public a1:Lc/R5;

.field public a2:Ljava/lang/String;

.field public final b:Landroid/content/SharedPreferences;

.field public b0:Ljava/lang/String;

.field public b1:Z

.field public final b2:Ljava/lang/StringBuilder;

.field public final c:Landroid/os/Handler;

.field public c0:Ljava/lang/String;

.field public c1:Z

.field public final c2:Ljava/util/ArrayDeque;

.field public final d:Ljava/util/HashSet;

.field public d0:Lc/b6;

.field public d1:Z

.field public d2:J

.field public final e:Ljava/util/HashMap;

.field public e0:Ljava/lang/String;

.field public e1:Z

.field public final e2:Lc/A5;

.field public final f:Ljava/util/LinkedHashMap;

.field public f0:Ljava/lang/String;

.field public final f1:Ljava/util/HashSet;

.field public final f2:Lc/A5;

.field public g:Lc/j6;

.field public g0:Ljava/lang/String;

.field public final g1:Ljava/util/ArrayDeque;

.field public final g2:Lc/A5;

.field public h:Lc/j6;

.field public h0:Z

.field public final h1:Ljava/util/HashSet;

.field public final h2:Lc/A5;

.field public i:J

.field public i0:Z

.field public final i1:Ljava/util/HashSet;

.field public final i2:Lc/A5;

.field public final j:Ljava/lang/Object;

.field public j0:Lc/b6;

.field public final j1:Ljava/util/HashSet;

.field public j2:D

.field public k:Ljava/lang/String;

.field public k0:Z

.field public k1:I

.field public k2:D

.field public l:Ljava/lang/String;

.field public l0:Z

.field public l1:I

.field public l2:D

.field public m:Ljava/lang/String;

.field public m0:I

.field public m1:I

.field public m2:Z

.field public final n:Ljava/util/LinkedHashSet;

.field public n0:Z

.field public n1:Z

.field public n2:Z

.field public final o:Ljava/util/HashSet;

.field public o0:Z

.field public o1:Z

.field public o2:Z

.field public p:Lc/j6;

.field public p0:Z

.field public p1:I

.field public p2:Z

.field public q:Lc/b;

.field public q0:Lc/n6;

.field public final q1:Lc/A5;

.field public q2:J

.field public final r:Lc/A5;

.field public r0:Lc/n6;

.field public r1:J

.field public r2:J

.field public final s:Ljava/util/ArrayList;

.field public s0:Lc/l6;

.field public s1:J

.field public final s2:Lc/Z5;

.field public volatile t:I

.field public t0:J

.field public t1:I

.field public t2:Lc/X5;

.field public u:Z

.field public u0:Z

.field public u1:I

.field public u2:J

.field public final v:Lc/s5;

.field public v0:Z

.field public v1:Z

.field public v2:J

.field public volatile w:Z

.field public w0:Z

.field public w1:Z

.field public w2:J

.field public x:Ljava/lang/Boolean;

.field public x0:Z

.field public final x1:Ljava/util/HashMap;

.field public x2:J

.field public y:Z

.field public y0:I

.field public final y1:Lc/R1;

.field public y2:I

.field public z:Z

.field public z0:Ljava/lang/String;

.field public final z1:Lc/r5;

.field public z2:J


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "fff0"

    invoke-static {v0}, Lc/T5;->X0(Ljava/lang/String;)V

    const-string v0, "fff1"

    invoke-static {v0}, Lc/T5;->X0(Ljava/lang/String;)V

    const-string v0, "fff2"

    invoke-static {v0}, Lc/T5;->X0(Ljava/lang/String;)V

    const-string v0, "2902"

    invoke-static {v0}, Lc/T5;->X0(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 11

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v4, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v4, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v4, p0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lc/T5;->d:Ljava/util/HashSet;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lc/T5;->e:Ljava/util/HashMap;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lc/T5;->j:Ljava/lang/Object;

    const-string v6, ""

    iput-object v6, p0, Lc/T5;->l:Ljava/lang/String;

    iput-object v6, p0, Lc/T5;->m:Ljava/lang/String;

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v0, p0, Lc/T5;->n:Ljava/util/LinkedHashSet;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lc/T5;->o:Ljava/util/HashSet;

    new-instance v0, Lc/A5;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v0, p0, Lc/T5;->r:Lc/A5;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lc/T5;->s:Ljava/util/ArrayList;

    new-instance v0, Lc/s5;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const-wide/16 v1, -0x1

    iput-wide v1, v0, Lc/s5;->a:J

    iput-wide v1, v0, Lc/s5;->b:J

    iput-object v0, p0, Lc/T5;->v:Lc/s5;

    const-wide/16 v7, -0x3a98

    iput-wide v7, p0, Lc/T5;->D:J

    iput-wide v1, p0, Lc/T5;->E:J

    new-instance v0, Lc/A5;

    const/16 v3, 0x8

    invoke-direct {v0, p0, v3}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v0, p0, Lc/T5;->F:Lc/A5;

    new-instance v0, Lc/A5;

    const/16 v3, 0x9

    invoke-direct {v0, p0, v3}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v0, p0, Lc/T5;->G:Lc/A5;

    new-instance v0, Lc/A5;

    const/16 v3, 0xa

    invoke-direct {v0, p0, v3}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v0, p0, Lc/T5;->H:Lc/A5;

    new-instance v0, Lc/M6;

    invoke-direct {v0}, Lc/M6;-><init>()V

    iput-object v0, p0, Lc/T5;->J:Lc/M6;

    new-instance v0, Lc/o3;

    const/4 v3, 0x3

    invoke-direct {v0, v3}, Lc/o3;-><init>(I)V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->O:Ljava/util/concurrent/ExecutorService;

    iput-object v6, p0, Lc/T5;->P:Ljava/lang/String;

    const-string v0, "7DF"

    iput-object v0, p0, Lc/T5;->Q:Ljava/lang/String;

    iput-object v6, p0, Lc/T5;->R:Ljava/lang/String;

    const-string v0, "18"

    iput-object v0, p0, Lc/T5;->S:Ljava/lang/String;

    const/4 v0, 0x6

    iput v0, p0, Lc/T5;->W:I

    const-string v0, "ATSP0"

    iput-object v0, p0, Lc/T5;->X:Ljava/lang/String;

    const-string v0, "0100"

    iput-object v0, p0, Lc/T5;->Y:Ljava/lang/String;

    const-string v0, "64"

    iput-object v0, p0, Lc/T5;->Z:Ljava/lang/String;

    const/4 v0, -0x1

    iput v0, p0, Lc/T5;->m0:I

    const/4 v7, 0x1

    iput-boolean v7, p0, Lc/T5;->v0:Z

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->B0:Ljava/util/HashMap;

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->N0:Ljava/util/HashSet;

    new-instance v3, Ljava/util/LinkedHashSet;

    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->R0:Ljava/util/HashMap;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->S0:Ljava/util/HashMap;

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->T0:Ljava/util/HashMap;

    new-instance v3, Lc/v8;

    const/4 v5, 0x7

    invoke-direct {v3, v5}, Lc/v8;-><init>(I)V

    iput-object v3, p0, Lc/T5;->V0:Lc/v8;

    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->X0:Ljava/util/LinkedHashMap;

    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->Y0:Ljava/util/LinkedHashMap;

    new-instance v3, Ljava/util/IdentityHashMap;

    invoke-direct {v3}, Ljava/util/IdentityHashMap;-><init>()V

    invoke-static {v3}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v3

    iput-object v3, p0, Lc/T5;->Z0:Ljava/util/Set;

    iput-boolean v7, p0, Lc/T5;->b1:Z

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->f1:Ljava/util/HashSet;

    new-instance v3, Ljava/util/ArrayDeque;

    invoke-direct {v3}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v3, p0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->h1:Ljava/util/HashSet;

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->i1:Ljava/util/HashSet;

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->j1:Ljava/util/HashSet;

    new-instance v3, Lc/A5;

    const/16 v5, 0xb

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->q1:Lc/A5;

    iput-boolean v7, p0, Lc/T5;->w1:Z

    new-instance v3, Ljava/util/HashMap;

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->x1:Ljava/util/HashMap;

    new-instance v3, Lc/R1;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-object v6, v3, Lc/R1;->a:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v5

    iput-object v5, v3, Lc/R1;->b:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v5

    iput-object v5, v3, Lc/R1;->c:Ljava/lang/Object;

    iput-object v3, p0, Lc/T5;->y1:Lc/R1;

    new-instance v3, Lc/r5;

    invoke-direct {v3}, Lc/r5;-><init>()V

    iput-object v3, p0, Lc/T5;->z1:Lc/r5;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v3, p0, Lc/T5;->A1:Ljava/util/LinkedHashMap;

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iput-object v3, p0, Lc/T5;->B1:Ljava/util/HashSet;

    const-string v3, "\u05dc\u05d0 \u05de\u05d7\u05d5\u05d1\u05e8"

    iput-object v3, p0, Lc/T5;->C1:Ljava/lang/String;

    iput-object v6, p0, Lc/T5;->D1:Ljava/lang/String;

    iput-object v6, p0, Lc/T5;->E1:Ljava/lang/String;

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, p0, Lc/T5;->N1:Ljava/util/ArrayList;

    const/4 v8, 0x0

    new-array v3, v8, [[B

    iput-object v3, p0, Lc/T5;->R1:[[B

    new-array v3, v8, [[B

    iput-object v3, p0, Lc/T5;->S1:[[B

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v3, p0, Lc/T5;->W1:Ljava/lang/StringBuilder;

    new-instance v3, Lc/A5;

    const/4 v5, 0x1

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->X1:Lc/A5;

    new-instance v3, Lc/A5;

    const/4 v5, 0x2

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->Y1:Lc/A5;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iput-object v3, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    new-instance v3, Ljava/util/ArrayDeque;

    invoke-direct {v3}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v3, p0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    const-wide/16 v9, 0x1388

    iput-wide v9, p0, Lc/T5;->d2:J

    new-instance v3, Lc/A5;

    const/4 v5, 0x3

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->e2:Lc/A5;

    new-instance v3, Lc/A5;

    const/4 v5, 0x4

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->f2:Lc/A5;

    new-instance v3, Lc/A5;

    const/4 v5, 0x5

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->g2:Lc/A5;

    new-instance v3, Lc/A5;

    const/4 v5, 0x6

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->h2:Lc/A5;

    new-instance v3, Lc/A5;

    const/4 v5, 0x7

    invoke-direct {v3, p0, v5}, Lc/A5;-><init>(Lc/T5;I)V

    iput-object v3, p0, Lc/T5;->i2:Lc/A5;

    new-instance v3, Lc/Z5;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    iput-object v3, p0, Lc/T5;->s2:Lc/Z5;

    iput-wide v1, p0, Lc/T5;->u2:J

    iput-wide v1, p0, Lc/T5;->v2:J

    iput-wide v1, p0, Lc/T5;->w2:J

    iput-wide v1, p0, Lc/T5;->A2:J

    new-instance v1, Lc/I5;

    invoke-direct {v1, p0}, Lc/I5;-><init>(Lc/T5;)V

    iput-object v1, p0, Lc/T5;->C2:Lc/I5;

    new-instance v1, Lc/K5;

    invoke-direct {v1, p0}, Lc/K5;-><init>(Lc/T5;)V

    iput-object v1, p0, Lc/T5;->D2:Lc/K5;

    iput-object p1, p0, Lc/T5;->a:Landroid/content/Context;

    const-string v1, "drivedeck_obd"

    invoke-virtual {p1, v1, v8}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v9

    iput-object v9, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "battery_parked"

    invoke-interface {v9, v1, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    iput-boolean v2, p0, Lc/T5;->w:Z

    const-string v2, "battery_watch"

    invoke-interface {v9, v2, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    iput-boolean v3, p0, Lc/T5;->B:Z

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const-string v5, "boot_count"

    invoke-static {v3, v5, v0}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v3

    if-ltz v3, :cond_0

    const-string v5, "battery_boot"

    invoke-interface {v9, v5, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-eq v3, v0, :cond_0

    iput-boolean v8, p0, Lc/T5;->w:Z

    iput-boolean v8, p0, Lc/T5;->B:Z

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v5, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_0
    new-instance v0, Lc/L5;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lc/L5;-><init>(Lc/T5;I)V

    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const-string v2, "android.intent.action.ACTION_SHUTDOWN"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.ACTION_POWER_DISCONNECTED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.ACTION_POWER_CONNECTED"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "android.intent.action.SCREEN_ON"

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x21

    if-lt v2, v3, :cond_1

    const/4 v5, 0x4

    invoke-virtual {p1, v0, v1, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    goto :goto_0

    :cond_1
    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    :goto_0
    new-instance v1, Lc/L5;

    const/4 v0, 0x1

    invoke-direct {v1, p0, v0}, Lc/L5;-><init>(Lc/T5;I)V

    new-instance v5, Landroid/content/IntentFilter;

    const-string v0, "com.syu.ms"

    invoke-direct {v5, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    if-lt v2, v3, :cond_2

    const/4 v10, 0x2

    const-string v3, "android.permission.DEVICE_POWER"

    move-object v0, p1

    move-object v2, v5

    move v5, v10

    invoke-virtual/range {v0 .. v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    goto :goto_1

    :cond_2
    const-string v0, "android.permission.DEVICE_POWER"

    invoke-virtual {p1, v1, v5, v0, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;

    :goto_1
    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_3

    const-string v0, "OBD \u05d1\u05d4\u05de\u05ea\u05e0\u05d4 - \u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    :cond_3
    const-string v0, "fuel_source_revision"

    invoke-interface {v9, v0}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v1

    const-string v2, "profile_id"

    if-nez v1, :cond_6

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v0, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "engine_litres"

    invoke-interface {v9, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_5

    const-string v3, "address"

    invoke-interface {v9, v3}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-interface {v9, v2}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_5

    :cond_4
    const/high16 v3, 0x40000000    # 2.0f

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    :cond_5
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_6
    const-string v0, "adapter_error"

    invoke-interface {v9, v0, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->E1:Ljava/lang/String;

    const-string v0, "trip_fuel"

    invoke-virtual {p0, v0}, Lc/T5;->S0(Ljava/lang/String;)D

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->j2:D

    const-string v0, "trip_distance"

    invoke-virtual {p0, v0}, Lc/T5;->S0(Ljava/lang/String;)D

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->k2:D

    const-string v0, "trip_paired_fuel"

    invoke-virtual {p0, v0}, Lc/T5;->S0(Ljava/lang/String;)D

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->l2:D

    const-string v0, "trip_has_fuel"

    invoke-interface {v9, v0, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lc/T5;->m2:Z

    const-string v0, "trip_has_distance"

    invoke-interface {v9, v0, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lc/T5;->n2:Z

    const-string v0, "trip_estimated"

    invoke-interface {v9, v0, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lc/T5;->o2:Z

    const-string v0, "trip_gaps"

    invoke-interface {v9, v0, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lc/T5;->p2:Z

    invoke-interface {v9, v2, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    const/4 p1, 0x0

    invoke-static {v9, p1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->g:Lc/j6;

    goto :goto_2

    :cond_7
    iget v1, p0, Lc/T5;->t:I

    invoke-static {p1}, Lc/z5;->b(Landroid/content/Context;)Lc/z5;

    move-result-object p1

    new-instance v2, Lc/H5;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v1, v0, v3}, Lc/H5;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/Z;

    const/16 v3, 0xe

    invoke-direct {v1, p1, v0, v2, v3}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object p1, p1, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_2
    return-void
.end method

.method public static declared-synchronized V(Landroid/content/Context;)Lc/T5;
    .locals 2

    const-class v0, Lc/T5;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lc/T5;->E2:Lc/T5;

    if-nez v1, :cond_0

    new-instance v1, Lc/T5;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    invoke-direct {v1, p0}, Lc/T5;-><init>(Landroid/content/Context;)V

    sput-object v1, Lc/T5;->E2:Lc/T5;

    goto :goto_0

    :catchall_0
    move-exception p0

    goto :goto_1

    :cond_0
    :goto_0
    sget-object p0, Lc/T5;->E2:Lc/T5;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v0

    return-object p0

    :goto_1
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p0
.end method

.method public static X0(Ljava/lang/String;)V
    .locals 2

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "0000"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "-0000-1000-8000-00805f9b34fb"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    return-void
.end method

.method public static a(Lc/T5;Ljava/lang/String;)D
    .locals 8

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "Vehicle speed"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8

    const-string v0, "13"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_4

    :cond_0
    const-string v0, "816"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_5

    const-string v0, "Altitude (GPS)"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_2

    :cond_1
    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v0, p1}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v1

    :goto_0
    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    if-nez v1, :cond_3

    move-object v1, p1

    goto :goto_1

    :cond_3
    iget-object v1, v1, Lc/i6;->a:Ljava/lang/String;

    :goto_1
    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/S5;

    if-eqz v0, :cond_4

    iget-wide v1, v0, Lc/S5;->a:D

    invoke-static {v1, v2}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    if-eqz v3, :cond_4

    iget-wide v3, p0, Lc/T5;->z2:J

    iget-wide v5, v0, Lc/S5;->c:J

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v3

    iput-wide v3, p0, Lc/T5;->z2:J

    goto/16 :goto_6

    :cond_4
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string v0, "\u041d\u0435\u0442 \u0441\u0432\u0435\u0436\u0435\u0433\u043e \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u044f PID "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_5
    :goto_2
    :try_start_0
    iget-object p1, p0, Lc/T5;->a:Landroid/content/Context;

    const-string v0, "location"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/location/LocationManager;

    if-nez p1, :cond_6

    goto :goto_3

    :cond_6
    const-string v0, "gps"

    invoke-virtual {p1, v0}, Landroid/location/LocationManager;->getLastKnownLocation(Ljava/lang/String;)Landroid/location/Location;

    move-result-object v1

    :goto_3
    if-eqz v1, :cond_7

    invoke-virtual {v1}, Landroid/location/Location;->hasAltitude()Z

    move-result p1

    if-eqz p1, :cond_7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtimeNanos()J

    move-result-wide v2

    invoke-virtual {v1}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const-wide v4, 0x2cb417800L

    cmp-long p1, v2, v4

    if-gez p1, :cond_7

    iget-wide v2, p0, Lc/T5;->z2:J

    invoke-virtual {v1}, Landroid/location/Location;->getElapsedRealtimeNanos()J

    move-result-wide v4

    const-wide/32 v6, 0xf4240

    div-long/2addr v4, v6

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v2

    iput-wide v2, p0, Lc/T5;->z2:J

    invoke-virtual {v1}, Landroid/location/Location;->getAltitude()D

    move-result-wide v1
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_6

    :catch_0
    :cond_7
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u041d\u0435\u0442 \u0441\u0432\u0435\u0436\u0435\u0439 \u0432\u044b\u0441\u043e\u0442\u044b GPS"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_8
    :goto_4
    const/16 p1, 0xd

    invoke-virtual {p0, p1}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object p1

    if-eqz p1, :cond_a

    iget-wide v0, p0, Lc/T5;->z2:J

    const/4 v2, 0x5

    invoke-virtual {p0, v2}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v2

    if-nez v2, :cond_9

    const-wide/16 v2, -0x1

    goto :goto_5

    :cond_9
    iget-wide v2, v2, Lc/Y5;->c:J

    :goto_5
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->z2:J

    invoke-virtual {p1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    :goto_6
    return-wide v1

    :cond_a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "\u041d\u0435\u0442 \u0441\u0432\u0435\u0436\u0435\u0439 \u0441\u043a\u043e\u0440\u043e\u0441\u0442\u0438"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static b(Lc/T5;Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p2}, Lc/M6;->b(Ljava/lang/Exception;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->E1:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "adapter_error"

    iget-object v2, p0, Lc/T5;->E1:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v0, "DriveDeckOBD"

    invoke-static {v0, p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-virtual {p0, p1}, Lc/T5;->Q0(Ljava/lang/String;)V

    return-void
.end method

.method public static d(Ljava/lang/String;)D
    .locals 7

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2e

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/16 v1, 0x56

    invoke-virtual {p0, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v2, 0x1

    const-string v3, "Invalid adapter voltage"

    if-lt v0, v2, :cond_2

    add-int/lit8 v2, v0, 0x1

    if-le v1, v2, :cond_2

    const/4 v4, 0x0

    invoke-virtual {p0, v4, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v6, 0xa

    invoke-static {v2, v6}, Ljava/lang/Character;->digit(CI)I

    move-result v2

    add-int/lit8 v0, v0, 0x2

    if-le v1, v0, :cond_0

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    invoke-static {p0, v6}, Ljava/lang/Character;->digit(CI)I

    move-result v4

    :cond_0
    if-ltz v5, :cond_1

    const/16 p0, 0xff

    if-gt v5, p0, :cond_1

    if-ltz v2, :cond_1

    if-ltz v4, :cond_1

    int-to-double v0, v5

    int-to-double v2, v2

    const-wide/high16 v5, 0x4024000000000000L    # 10.0

    div-double/2addr v2, v5

    add-double/2addr v2, v0

    int-to-double v0, v4

    const-wide/high16 v4, 0x4059000000000000L    # 100.0

    div-double/2addr v0, v4

    add-double/2addr v0, v2

    return-wide v0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-direct {p0, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static k(Lc/S5;J)Ljava/lang/Double;
    .locals 4

    const/4 v0, 0x0

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    iget-wide v1, p0, Lc/S5;->a:D

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    invoke-static {v1}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v2

    if-eqz v2, :cond_1

    iget-wide v2, p0, Lc/S5;->c:J

    cmp-long p0, p1, v2

    if-ltz p0, :cond_1

    sub-long/2addr p1, v2

    const-wide/16 v2, 0x3a98

    cmp-long p0, p1, v2

    if-gtz p0, :cond_1

    move-object v0, v1

    :cond_1
    :goto_0
    return-object v0
.end method

.method public static w0(I)I
    .locals 3

    const/16 v0, 0x24

    if-lt p0, v0, :cond_0

    const/16 v0, 0x2b

    if-le p0, v0, :cond_2

    :cond_0
    const/16 v0, 0x34

    if-lt p0, v0, :cond_1

    const/16 v0, 0x3b

    if-le p0, v0, :cond_2

    :cond_1
    const/16 v0, 0x44

    if-ne p0, v0, :cond_3

    :cond_2
    const/16 p0, 0xd

    return p0

    :cond_3
    const/4 v0, 0x4

    if-eq p0, v0, :cond_c

    const/4 v1, 0x5

    if-eq p0, v1, :cond_b

    const/16 v2, 0x2f

    if-eq p0, v2, :cond_a

    const/16 v2, 0x33

    if-eq p0, v2, :cond_9

    const/16 v2, 0x5e

    if-eq p0, v2, :cond_8

    const/16 v2, 0x42

    if-eq p0, v2, :cond_7

    const/16 v2, 0x43

    if-eq p0, v2, :cond_6

    const/16 v2, 0x45

    if-eq p0, v2, :cond_5

    const/16 v2, 0x46

    if-eq p0, v2, :cond_4

    packed-switch p0, :pswitch_data_0

    packed-switch p0, :pswitch_data_1

    const/4 p0, -0x1

    return p0

    :pswitch_0
    const/16 p0, 0x8

    return p0

    :pswitch_1
    const/4 p0, 0x2

    return p0

    :pswitch_2
    return v0

    :pswitch_3
    return v1

    :pswitch_4
    const/4 p0, 0x1

    return p0

    :pswitch_5
    const/4 p0, 0x3

    return p0

    :cond_4
    const/16 p0, 0xc

    return p0

    :cond_5
    const/16 p0, 0x14

    return p0

    :cond_6
    const/16 p0, 0xa

    return p0

    :cond_7
    const/16 p0, 0x273a

    return p0

    :cond_8
    const/16 p0, 0x10

    return p0

    :cond_9
    const/16 p0, 0xb

    return p0

    :cond_a
    const/16 p0, 0x12

    return p0

    :cond_b
    const/4 p0, 0x7

    return p0

    :cond_c
    const/16 p0, 0x9

    return p0

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xf
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final A(IID)Ljava/lang/Double;
    .locals 16

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    invoke-static/range {p3 .. p4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    const/4 v4, 0x0

    if-nez v3, :cond_0

    return-object v4

    :cond_0
    const/16 v3, 0x273a

    const/16 v5, 0xa

    if-ne v1, v3, :cond_2

    if-ne v2, v5, :cond_1

    invoke-static/range {p3 .. p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_1
    return-object v4

    :cond_2
    const/4 v3, 0x1

    if-ne v1, v3, :cond_4

    const/4 v1, 0x6

    if-ne v2, v1, :cond_3

    invoke-static/range {p3 .. p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_3
    return-object v4

    :cond_4
    const-wide/high16 v6, 0x404e000000000000L    # 60.0

    const/16 v8, 0x9

    const/16 v9, 0x21

    const/4 v10, 0x2

    const-wide v11, 0x408f400000000000L    # 1000.0

    const-wide v13, 0x400ccccccccccccdL    # 3.6

    const/16 v15, 0x8

    if-ne v1, v10, :cond_8

    if-ne v2, v15, :cond_5

    move-wide/from16 v1, p3

    goto :goto_0

    :cond_5
    if-ne v2, v9, :cond_6

    div-double v1, p3, v13

    goto :goto_0

    :cond_6
    if-ne v2, v8, :cond_7

    mul-double v1, p3, v11

    div-double/2addr v1, v6

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_7
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    :goto_0
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_8
    const/4 v11, 0x3

    const/4 v12, 0x5

    const/16 v9, 0xb

    if-eq v1, v11, :cond_1d

    if-ne v1, v9, :cond_9

    goto/16 :goto_6

    :cond_9
    const/4 v9, 0x4

    const/16 v11, 0x10

    if-eq v1, v9, :cond_19

    const/4 v9, 0x7

    if-eq v1, v9, :cond_19

    const/16 v9, 0xc

    if-eq v1, v9, :cond_19

    const/16 v6, 0x39

    if-eq v1, v6, :cond_19

    const/16 v6, 0x3a

    if-ne v1, v6, :cond_a

    goto/16 :goto_4

    :cond_a
    if-ne v1, v12, :cond_e

    if-ne v2, v3, :cond_b

    invoke-static/range {p3 .. p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_b
    if-ne v2, v10, :cond_c

    const-wide v1, 0x3ff9bfdf7e8038a0L    # 1.609344

    mul-double v1, v1, p3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_c
    const/16 v1, 0x54

    if-ne v2, v1, :cond_d

    mul-double v1, p3, v13

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_d
    return-object v4

    :cond_e
    if-eq v1, v15, :cond_17

    if-eq v1, v8, :cond_17

    if-eq v1, v5, :cond_17

    const/16 v5, 0x12

    if-ne v1, v5, :cond_f

    goto :goto_3

    :cond_f
    if-ne v1, v11, :cond_16

    invoke-virtual/range {p0 .. p0}, Lc/T5;->R()Lc/W5;

    move-result-object v1

    const/16 v5, 0x51

    invoke-virtual {v0, v5}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v6

    if-nez v6, :cond_10

    move-object v5, v4

    goto :goto_1

    :cond_10
    invoke-virtual {v0, v5}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Double;->intValue()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    :goto_1
    invoke-static {v1, v5}, Lc/Z5;->c(Lc/W5;Ljava/lang/Integer;)[D

    move-result-object v1

    aget-wide v5, v1, v3

    if-ne v2, v9, :cond_11

    move-wide/from16 v1, p3

    goto :goto_2

    :cond_11
    const/16 v1, 0x6b

    if-ne v2, v1, :cond_12

    const-wide v1, 0x40ac200000000000L    # 3600.0

    mul-double v1, v1, p3

    goto :goto_2

    :cond_12
    const/16 v1, 0x6c

    if-ne v2, v1, :cond_13

    const-wide/high16 v7, 0x404e000000000000L    # 60.0

    mul-double v1, p3, v7

    goto :goto_2

    :cond_13
    if-ne v2, v15, :cond_14

    mul-double v1, p3, v13

    div-double/2addr v1, v5

    goto :goto_2

    :cond_14
    const/16 v1, 0x21

    if-ne v2, v1, :cond_15

    div-double v1, p3, v5

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_15
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    :goto_2
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_16
    return-object v4

    :cond_17
    :goto_3
    const/16 v1, 0xe

    if-ne v2, v1, :cond_18

    invoke-static/range {p3 .. p4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_18
    return-object v4

    :cond_19
    :goto_4
    const/16 v1, 0xf

    if-ne v2, v1, :cond_1a

    move-wide/from16 v1, p3

    goto :goto_5

    :cond_1a
    if-ne v2, v11, :cond_1b

    const-wide/high16 v1, 0x4040000000000000L    # 32.0

    sub-double v1, p3, v1

    const-wide/high16 v3, 0x4014000000000000L    # 5.0

    mul-double/2addr v1, v3

    const-wide/high16 v3, 0x4022000000000000L    # 9.0

    div-double/2addr v1, v3

    goto :goto_5

    :cond_1b
    const/16 v1, 0x55

    if-ne v2, v1, :cond_1c

    const-wide v1, 0x4071126666666666L    # 273.15

    sub-double v1, p3, v1

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_1c
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    :goto_5
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1

    :cond_1d
    :goto_6
    if-ne v2, v12, :cond_1e

    move-wide/from16 v1, p3

    goto :goto_8

    :cond_1e
    if-ne v2, v9, :cond_1f

    const-wide v5, 0x408f400000000000L    # 1000.0

    div-double v1, p3, v5

    goto :goto_8

    :cond_1f
    const/16 v1, 0x30

    if-ne v2, v1, :cond_20

    const-wide/high16 v1, 0x4059000000000000L    # 100.0

    mul-double v1, v1, p3

    goto :goto_8

    :cond_20
    const/16 v1, 0x34

    if-eq v2, v1, :cond_23

    const/16 v1, 0x45

    if-ne v2, v1, :cond_21

    goto :goto_7

    :cond_21
    const/16 v1, 0x4a

    if-ne v2, v1, :cond_22

    const-wide v1, 0x408f400000000000L    # 1000.0

    mul-double v1, v1, p3

    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    :cond_22
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    goto :goto_8

    :cond_23
    :goto_7
    const-wide/high16 v1, 0x4024000000000000L    # 10.0

    div-double v1, p3, v1

    :goto_8
    invoke-static {v1, v2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v1

    return-object v1
.end method

.method public final A0()V
    .locals 5

    iget-object v0, p0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v1, Lc/j6;->y:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    iget-boolean v3, v2, Lc/i6;->v:Z

    if-eqz v3, :cond_1

    iget-boolean v3, v2, Lc/i6;->w:Z

    if-nez v3, :cond_4

    iget-boolean v3, v2, Lc/i6;->x:Z

    if-nez v3, :cond_4

    const/4 v3, 0x1

    iget v4, v2, Lc/i6;->j:I

    if-lt v4, v3, :cond_2

    const/16 v3, 0xd

    if-le v4, v3, :cond_4

    :cond_2
    const/16 v3, 0x10

    if-lt v4, v3, :cond_3

    const/16 v3, 0x15

    if-le v4, v3, :cond_4

    :cond_3
    const/16 v3, 0x39

    if-eq v4, v3, :cond_4

    const/16 v3, 0x3a

    if-eq v4, v3, :cond_4

    const/16 v3, 0x273a

    if-ne v4, v3, :cond_1

    :cond_4
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_5
    return-void
.end method

.method public final B([B[B)Z
    .locals 11

    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v1, p0, Lc/T5;->a1:Lc/R5;

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    :cond_0
    iget-object v1, v1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i6;

    iget-object v4, p0, Lc/T5;->g:Lc/j6;

    if-eqz v4, :cond_1

    iget-object v4, v4, Lc/j6;->v:Ljava/util/LinkedHashMap;

    iget-object v5, v3, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eq v4, v3, :cond_2

    goto :goto_0

    :cond_2
    :try_start_0
    iget-boolean v4, p0, Lc/T5;->e1:Z

    if-eqz v4, :cond_3

    iget-boolean v4, p0, Lc/T5;->n1:Z

    if-eqz v4, :cond_3

    if-eqz p1, :cond_3

    iget-object v4, p0, Lc/T5;->j1:Ljava/util/HashSet;

    invoke-virtual {v4, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    iget-object v4, p0, Lc/T5;->T0:Ljava/util/HashMap;

    iget-object v6, p0, Lc/T5;->R0:Ljava/util/HashMap;

    iget-object v7, p0, Lc/T5;->S0:Ljava/util/HashMap;

    if-eqz p1, :cond_7

    :try_start_1
    iget-object v8, v3, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {v8}, Ljava/util/Set;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_5

    invoke-virtual {p1}, [B->clone()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [B

    invoke-virtual {v6, v5, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-nez p2, :cond_4

    invoke-virtual {v7, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_4
    invoke-virtual {p2}, [B->clone()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [B

    invoke-virtual {v7, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-virtual {v4, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_5
    iget v4, v3, Lc/i6;->k:I

    const/4 v6, 0x5

    if-ne v4, v6, :cond_6

    invoke-virtual {v3, p1}, Lc/i6;->d([B)Lc/J6;

    move-result-object v4

    new-instance v6, Lc/S5;

    iget-wide v7, v4, Lc/J6;->a:D

    invoke-virtual {p0}, Lc/T5;->H0()D

    move-result-wide v9

    invoke-virtual {v3, v7, v8, v9, v10}, Lc/i6;->a(DD)D

    move-result-wide v7

    iget v3, v4, Lc/J6;->b:I

    invoke-direct {v6, v7, v8, v3}, Lc/S5;-><init>(DI)V

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_6
    new-instance v4, Lc/S5;

    new-instance v6, Lc/B5;

    const/4 v7, 0x0

    invoke-direct {v6, p0, v7}, Lc/B5;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v3, p1, p2, v6}, Lc/i6;->b([B[BLjava/util/function/ToDoubleFunction;)D

    move-result-wide v6

    invoke-virtual {p0}, Lc/T5;->H0()D

    move-result-wide v8

    invoke-virtual {v3, v6, v7, v8, v9}, Lc/i6;->a(DD)D

    move-result-wide v6

    const/4 v3, -0x1

    invoke-direct {v4, v6, v7, v3}, Lc/S5;-><init>(DI)V

    invoke-interface {v0, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    const/4 v2, 0x1

    goto/16 :goto_0

    :cond_7
    invoke-virtual {v6, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v7, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v3, Ljava/lang/IllegalArgumentException;

    const-string v4, "No ECU data"

    invoke-direct {v3, v4}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v3
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    invoke-interface {v0, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_0

    :cond_8
    if-eqz v2, :cond_9

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide p1

    iput-wide p1, p0, Lc/T5;->E:J

    :cond_9
    return v2
.end method

.method public final B0()V
    .locals 6

    iget-object v0, p0, Lc/T5;->G0:Lc/f6;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lc/f6;->a:Ljava/lang/String;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/T5;->I0:Lc/d6;

    iget-object v0, v0, Lc/d6;->a:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    :goto_0
    iget-object v1, p0, Lc/T5;->I0:Lc/d6;

    if-nez v1, :cond_1

    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    iget v1, v1, Lc/d6;->b:I

    :goto_1
    if-lez v1, :cond_2

    iget v2, p0, Lc/T5;->t:I

    iget-object v3, p0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v4, Lc/x;

    const/4 v5, 0x2

    invoke-direct {v4, p0, v2, v0, v5}, Lc/x;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    int-to-long v0, v1

    invoke-virtual {v3, v4, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_2

    :cond_2
    invoke-virtual {p0, v0}, Lc/T5;->O0(Ljava/lang/String;)V

    :goto_2
    return-void
.end method

.method public final C(IZ)Ljava/lang/String;
    .locals 1

    if-eqz p2, :cond_0

    iget-object p2, p0, Lc/T5;->g:Lc/j6;

    if-eqz p2, :cond_0

    iget-object p2, p2, Lc/j6;->c:Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_0

    iget-object p1, p0, Lc/T5;->g:Lc/j6;

    iget-object p1, p1, Lc/j6;->c:Ljava/lang/String;

    return-object p1

    :cond_0
    invoke-static {p1}, Lc/G8;->i0(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    const/16 v0, 0xb

    if-ne p1, v0, :cond_1

    const-string p1, "8110FC"

    return-object p1

    :cond_1
    return-object p2
.end method

.method public final C0()V
    .locals 4

    iget-object v0, p0, Lc/T5;->D0:Lc/j7;

    iget-object v0, v0, Lc/j7;->a:Ljava/lang/String;

    if-eqz v0, :cond_0

    invoke-virtual {p0, v0}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_0
    const-string v0, "VWTP_RX"

    iput-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    iput-boolean v1, p0, Lc/T5;->c1:Z

    iput-boolean v1, p0, Lc/T5;->v1:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->s1:J

    iput-wide v0, p0, Lc/T5;->r1:J

    iget-object v0, p0, Lc/T5;->D0:Lc/j7;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->e2:Lc/A5;

    const-wide/16 v2, 0x9c4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final D(Ljava/lang/String;)V
    .locals 8

    invoke-virtual {p0}, Lc/T5;->s0()V

    invoke-virtual {p0}, Lc/T5;->p()V

    iget-object v0, p0, Lc/T5;->h:Lc/j6;

    new-instance v1, Lc/d7;

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, p1, v3}, Lc/d7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Ljava/lang/String;I)V

    invoke-static {v1}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->h:Lc/j6;

    if-nez v0, :cond_0

    const-string v0, "000000000000000000000000"

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/j6;->a:Ljava/lang/String;

    :goto_0
    new-instance v1, Ljava/util/LinkedHashSet;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "widget_sensors_"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    new-instance v3, Ljava/util/LinkedHashSet;

    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "widget_bindings_"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v2, v5, v7}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    new-instance v5, Lc/F2;

    const/4 v7, 0x3

    invoke-direct {v5, p1, v7}, Lc/F2;-><init>(Ljava/lang/String;I)V

    invoke-interface {v3, v5}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v4, v1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x0

    iget-object v2, p0, Lc/T5;->a:Landroid/content/Context;

    const-string v3, "drive_deck"

    invoke-virtual {v2, v3, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    new-instance v2, Lc/I1;

    const/4 v3, 0x2

    invoke-direct {v2, v1, v0, p1, v3}, Lc/I1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/io/Serializable;I)V

    invoke-static {v2}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    iget-object v1, p0, Lc/T5;->X0:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, ":"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lc/T5;->o0()V

    return-void
.end method

.method public final D0()Lc/I6;
    .locals 6

    iget v0, p0, Lc/T5;->T:I

    invoke-static {v0}, Lc/k6;->I(I)I

    move-result v0

    new-instance v1, Lc/I6;

    const/4 v2, 0x6

    if-ne v0, v2, :cond_0

    const/4 v0, 0x2

    goto :goto_0

    :cond_0
    const/16 v2, 0x8

    if-ne v0, v2, :cond_1

    const/4 v0, 0x4

    goto :goto_0

    :cond_1
    const/4 v0, 0x3

    :goto_0
    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    if-nez v2, :cond_2

    const-string v3, ""

    goto :goto_1

    :cond_2
    iget-object v3, v2, Lc/j6;->e:Ljava/lang/String;

    :goto_1
    const/4 v4, 0x0

    if-eqz v2, :cond_3

    iget-object v2, v2, Lc/j6;->t:Lorg/json/JSONObject;

    if-eqz v2, :cond_3

    const-string v5, "DaihatsuMode"

    invoke-virtual {v2, v5, v4}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_3

    const/4 v4, 0x1

    :cond_3
    invoke-direct {v1, v0, v3, v4}, Lc/I6;-><init>(ILjava/lang/String;Z)V

    return-object v1
.end method

.method public final E()V
    .locals 3

    invoke-virtual {p0}, Lc/T5;->r()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->o1:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc/T5;->r0:Lc/n6;

    invoke-virtual {p0}, Lc/T5;->L0()V

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "enabled"

    invoke-static {v1, v2, v0}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lc/T5;->s()V

    const-string v0, "\u05de\u05e0\u05d5\u05ea\u05e7"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final E0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)[B
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    const/4 v8, 0x0

    if-nez v4, :cond_0

    return-object v8

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lc/T5;->D0()Lc/I6;

    move-result-object v5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v6, v5, Lc/I6;->a:I

    if-eq v6, v2, :cond_3

    iget v2, v0, Lc/T5;->T:I

    iget-object v6, v0, Lc/T5;->R:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    xor-int/2addr v6, v1

    iget-object v7, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v9, "service_response_marker"

    invoke-interface {v7, v9, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    move-object/from16 v1, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    invoke-static/range {v1 .. v7}, Lc/G8;->C0(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lc/I6;ZZ)Lc/R1;

    move-result-object v1

    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    if-eqz p4, :cond_2

    iget-object v1, v1, Lc/R1;->c:Ljava/lang/Object;

    :goto_0
    move-object v8, v1

    check-cast v8, [B

    goto :goto_1

    :cond_2
    iget-object v1, v1, Lc/R1;->b:Ljava/lang/Object;

    goto :goto_0

    :goto_1
    return-object v8

    :cond_3
    invoke-static {v3, v5}, Lc/k6;->R(Ljava/lang/String;Lc/I6;)[B

    move-result-object v5

    new-instance v7, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v7}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iget v9, v0, Lc/T5;->T:I

    invoke-static {v9}, Lc/k6;->I(I)I

    move-result v10

    const/4 v11, 0x6

    if-ne v10, v11, :cond_4

    const/4 v10, 0x3

    move-object/from16 v12, p1

    goto :goto_2

    :cond_4
    move-object/from16 v12, p1

    move v10, v1

    :goto_2
    invoke-static {v12, v9, v10, v8, v8}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    const/4 v12, 0x0

    :goto_3
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_10

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lc/n7;

    iget v14, v0, Lc/T5;->T:I

    invoke-static {v14}, Lc/k6;->I(I)I

    move-result v14

    if-ne v14, v11, :cond_5

    iget-object v14, v13, Lc/n7;->a:Ljava/lang/String;

    const/4 v15, 0x4

    invoke-virtual {v14, v15}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v14

    goto :goto_4

    :cond_5
    iget-object v14, v13, Lc/n7;->a:Ljava/lang/String;

    :goto_4
    const-string v15, "??"

    invoke-virtual {v4, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_6

    invoke-virtual {v4, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_6

    iget-object v14, v13, Lc/n7;->a:Ljava/lang/String;

    invoke-virtual {v4, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_f

    :cond_6
    iget-object v14, v13, Lc/n7;->b:[B

    array-length v14, v14

    array-length v15, v5

    if-lt v14, v15, :cond_f

    invoke-virtual {v13}, Lc/n7;->a()I

    move-result v14

    if-ltz v14, :cond_7

    goto :goto_9

    :cond_7
    move v15, v1

    const/4 v14, 0x0

    :goto_5
    array-length v1, v5

    iget-object v10, v13, Lc/n7;->b:[B

    if-ge v14, v1, :cond_9

    aget-byte v1, v5, v14

    aget-byte v10, v10, v14

    if-ne v1, v10, :cond_8

    const/4 v1, 0x1

    goto :goto_6

    :cond_8
    const/4 v1, 0x0

    :goto_6
    and-int/2addr v15, v1

    add-int/lit8 v14, v14, 0x1

    goto :goto_5

    :cond_9
    if-nez v15, :cond_a

    goto :goto_9

    :cond_a
    array-length v1, v5

    array-length v13, v10

    invoke-static {v3, v1, v13, v6}, Lc/k6;->o0(Ljava/lang/String;III)I

    move-result v1

    array-length v13, v10

    if-gt v1, v13, :cond_e

    if-eqz v12, :cond_b

    if-eq v6, v2, :cond_b

    goto :goto_8

    :cond_b
    if-eqz p4, :cond_c

    const/4 v12, 0x0

    goto :goto_7

    :cond_c
    move v12, v1

    :goto_7
    array-length v13, v10

    if-eqz p4, :cond_d

    const/4 v1, 0x0

    :cond_d
    sub-int/2addr v13, v1

    invoke-virtual {v7, v10, v12, v13}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v1, 0x1

    const/4 v12, 0x1

    goto :goto_3

    :cond_e
    :goto_8
    return-object v8

    :cond_f
    :goto_9
    const/4 v1, 0x1

    goto :goto_3

    :cond_10
    if-eqz v12, :cond_11

    invoke-virtual {v7}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v8

    :cond_11
    return-object v8
.end method

.method public final F()V
    .locals 10

    iget-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v0, :cond_13

    iget-boolean v0, p0, Lc/T5;->c1:Z

    if-eqz v0, :cond_0

    goto/16 :goto_9

    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lc/T5;->r1:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    const/4 v5, 0x0

    if-gtz v4, :cond_1

    move v4, v5

    goto :goto_0

    :cond_1
    const-wide/16 v6, 0xa

    sub-long/2addr v6, v0

    invoke-static {v2, v3, v6, v7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v6

    long-to-int v4, v6

    :goto_0
    iget-object v6, p0, Lc/T5;->P0:Lc/b6;

    if-nez v6, :cond_2

    move v0, v5

    goto :goto_1

    :cond_2
    iget v6, v6, Lc/b6;->c:I

    int-to-long v6, v6

    sub-long/2addr v6, v0

    invoke-static {v2, v3, v6, v7}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v0

    long-to-int v0, v0

    :goto_1
    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iget-object v1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, p0, Lc/T5;->f2:Lc/A5;

    if-lez v0, :cond_3

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    int-to-long v3, v0

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_3
    iget-object v0, p0, Lc/T5;->O0:Lc/c6;

    const-string v3, ">"

    iget-object v4, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    if-eqz v0, :cond_c

    iget-object v6, p0, Lc/T5;->P0:Lc/b6;

    if-eqz v6, :cond_c

    iget-boolean v6, v6, Lc/b6;->d:Z

    if-eqz v6, :cond_c

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v7

    const/4 v8, 0x1

    if-ltz v7, :cond_4

    move v7, v8

    goto :goto_2

    :cond_4
    move v7, v5

    :goto_2
    invoke-virtual {v0, v6, v7}, Lc/c6;->c(IZ)Z

    move-result v0

    if-eqz v0, :cond_c

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "long_responses_safe_mode"

    invoke-static {v0, v3, v8}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    iget-object v0, p0, Lc/T5;->Z:Ljava/lang/String;

    if-nez v0, :cond_5

    const-string v3, ""

    goto :goto_3

    :cond_5
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    :goto_3
    const-string v6, "[0-9A-Fa-f]{1,8}"

    invoke-virtual {v3, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    const/4 v7, 0x0

    if-nez v6, :cond_6

    move-object v0, v7

    goto :goto_4

    :cond_6
    const/16 v6, 0x10

    invoke-static {v3, v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    move-result-wide v8

    long-to-int v3, v8

    const/16 v6, 0x16

    if-eq v3, v6, :cond_a

    const/16 v6, 0x32

    if-eq v3, v6, :cond_a

    const/16 v6, 0x64

    if-eq v3, v6, :cond_9

    const/16 v6, 0x96

    if-eq v3, v6, :cond_8

    const/16 v6, 0xff

    if-eq v3, v6, :cond_7

    goto :goto_4

    :cond_7
    const-string v0, "96"

    goto :goto_4

    :cond_8
    const-string v0, "32"

    goto :goto_4

    :cond_9
    const-string v0, "16"

    goto :goto_4

    :cond_a
    const-string v0, "08"

    :goto_4
    if-nez v0, :cond_b

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v5, v0}, Lc/T5;->M(ZLjava/lang/String;)V

    goto :goto_5

    :cond_b
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, p0, Lc/T5;->b0:Ljava/lang/String;

    iget-object v3, p0, Lc/T5;->a2:Ljava/lang/String;

    iput-object v3, p0, Lc/T5;->c0:Ljava/lang/String;

    iget-object v3, p0, Lc/T5;->P0:Lc/b6;

    iput-object v3, p0, Lc/T5;->d0:Lc/b6;

    iput-object v7, p0, Lc/T5;->P0:Lc/b6;

    const/4 v3, 0x2

    iput v3, p0, Lc/T5;->a0:I

    iput-object v0, p0, Lc/T5;->Z:Ljava/lang/String;

    iput-object v7, p0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v3, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-string v1, "ATST"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lc/T5;->O0(Ljava/lang/String;)V

    :goto_5
    return-void

    :cond_c
    iget-object v0, p0, Lc/T5;->G0:Lc/f6;

    if-nez v0, :cond_d

    const/4 v0, -0x1

    goto :goto_6

    :cond_d
    iget v0, v0, Lc/f6;->b:I

    :goto_6
    if-ltz v0, :cond_f

    move v1, v5

    move v2, v1

    :goto_7
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->length()I

    move-result v6

    if-ge v1, v6, :cond_10

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v6

    const/16 v7, 0xd

    if-eq v6, v7, :cond_e

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->charAt(I)C

    move-result v6

    const/16 v7, 0xa

    if-eq v6, v7, :cond_e

    goto :goto_8

    :cond_e
    add-int/lit8 v2, v2, 0x1

    :goto_8
    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_f
    move v2, v5

    :cond_10
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v1

    if-gez v1, :cond_12

    if-ltz v0, :cond_11

    if-gt v2, v0, :cond_12

    :cond_11
    return-void

    :cond_12
    iput v5, p0, Lc/T5;->t1:I

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v5, v0}, Lc/T5;->M(ZLjava/lang/String;)V

    :cond_13
    :goto_9
    return-void
.end method

.method public final F0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    iget v0, p0, Lc/T5;->T:I

    invoke-virtual {p0}, Lc/T5;->D0()Lc/I6;

    move-result-object v1

    const/4 v2, 0x0

    :try_start_0
    invoke-static {p2, v1}, Lc/k6;->R(Ljava/lang/String;Lc/I6;)[B

    move-result-object p2
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-static {v0}, Lc/k6;->I(I)I

    move-result v1

    const/4 v3, 0x6

    if-ne v1, v3, :cond_0

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    invoke-static {p1, v0, v1, v2, v2}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/n7;

    invoke-static {v1, p2}, Lc/G8;->S(Lc/n7;[B)Z

    move-result v4

    if-nez v4, :cond_2

    goto :goto_1

    :cond_2
    invoke-static {v0}, Lc/k6;->I(I)I

    move-result v4

    iget-object v1, v1, Lc/n7;->a:Ljava/lang/String;

    if-ne v4, v3, :cond_3

    const/4 v4, 0x4

    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    :cond_3
    if-eqz v2, :cond_4

    invoke-virtual {v1, v2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v4

    if-gez v4, :cond_1

    :cond_4
    move-object v2, v1

    goto :goto_1

    :catch_0
    :cond_5
    return-object v2
.end method

.method public final G(Lc/R5;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget-object v2, v1, Lc/R5;->c:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    iget-object v3, v0, Lc/T5;->Q:Ljava/lang/String;

    goto :goto_0

    :cond_0
    move-object v3, v2

    :goto_0
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    const-string v5, ""

    const/4 v6, 0x6

    if-lt v4, v6, :cond_1

    iget-object v4, v0, Lc/T5;->S:Ljava/lang/String;

    iget-object v7, v1, Lc/R5;->f:Ljava/util/List;

    invoke-static {v2, v4, v7}, Lc/k6;->j0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v4

    goto :goto_2

    :cond_1
    iget-object v4, v0, Lc/T5;->g:Lc/j6;

    if-nez v4, :cond_2

    move-object v4, v5

    goto :goto_1

    :cond_2
    iget-object v4, v4, Lc/j6;->e:Ljava/lang/String;

    :goto_1
    iget-object v7, v1, Lc/R5;->f:Ljava/util/List;

    invoke-static {v2, v4, v7}, Lc/k6;->i0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v4

    :goto_2
    iget-object v7, v1, Lc/R5;->f:Ljava/util/List;

    if-nez v4, :cond_3

    move-object v4, v5

    :cond_3
    const/4 v10, 0x0

    if-eqz v7, :cond_8

    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move-object v11, v5

    move-object v12, v10

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    :goto_3
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_9

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    move-object/from16 v9, v16

    check-cast v9, Ljava/lang/String;

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v8}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    if-nez v12, :cond_4

    const-string v9, "ATFCSH"

    invoke-virtual {v8, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_4

    invoke-virtual {v8, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    :cond_4
    const/4 v9, 0x5

    if-nez v13, :cond_5

    const-string v6, "ATCEA"

    invoke-virtual {v8, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v17

    if-eqz v17, :cond_5

    invoke-virtual {v8, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_5

    invoke-virtual {v8, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x1

    :cond_5
    if-nez v14, :cond_6

    const-string v6, "ATTA"

    invoke-virtual {v8, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_6

    const/4 v6, 0x4

    invoke-virtual {v8, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    move-object v11, v6

    const/4 v14, 0x1

    :cond_6
    if-nez v15, :cond_7

    const-string v6, "ATCRA"

    invoke-virtual {v8, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_7

    invoke-virtual {v8, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const/4 v15, 0x1

    :cond_7
    const/4 v6, 0x6

    goto :goto_3

    :cond_8
    move-object v11, v5

    move-object v12, v10

    :cond_9
    const/4 v6, 0x2

    if-nez v12, :cond_a

    new-array v4, v6, [Ljava/lang/String;

    const/4 v7, 0x0

    aput-object v10, v4, v7

    const/4 v5, 0x1

    aput-object v10, v4, v5

    goto :goto_4

    :cond_a
    const/4 v7, 0x0

    new-array v6, v6, [Ljava/lang/String;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v6, v7

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    aput-object v4, v6, v5

    move-object v4, v6

    :goto_4
    iput-object v4, v1, Lc/R5;->h:[Ljava/lang/String;

    iget-object v4, v1, Lc/R5;->f:Ljava/util/List;

    iget-object v6, v1, Lc/R5;->g:Ljava/util/List;

    iget-object v8, v0, Lc/T5;->y1:Lc/R1;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v4, :cond_c

    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_b

    goto :goto_5

    :cond_b
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v9}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v4

    goto :goto_6

    :cond_c
    :goto_5
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v4

    :goto_6
    if-eqz v6, :cond_e

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_d

    goto :goto_7

    :cond_d
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v9}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v6

    goto :goto_8

    :cond_e
    :goto_7
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v6

    :goto_8
    iget-object v9, v8, Lc/R1;->a:Ljava/lang/Object;

    check-cast v9, Ljava/lang/String;

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    iget-object v10, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v10, Ljava/util/List;

    const-string v11, "ATCAF1"

    invoke-interface {v10, v11}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_f

    const-string v10, "ATCAF0"

    invoke-interface {v4, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_f

    iget-object v12, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v12, Ljava/util/List;

    invoke-interface {v12, v10}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v10

    iget-object v12, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v12, Ljava/util/List;

    invoke-interface {v12, v11}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v11

    if-gt v10, v11, :cond_f

    move v10, v5

    goto :goto_9

    :cond_f
    move v10, v7

    :goto_9
    iget-object v11, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v11, Ljava/util/List;

    const-string v12, "ATAR"

    invoke-interface {v11, v12}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_10

    iget-object v11, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v11, Ljava/util/List;

    invoke-interface {v11, v6}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_10

    move v11, v5

    goto :goto_a

    :cond_10
    move v11, v7

    :goto_a
    if-eqz v9, :cond_12

    if-nez v10, :cond_12

    if-eqz v11, :cond_11

    goto :goto_b

    :cond_11
    move v5, v7

    :cond_12
    :goto_b
    if-eqz v5, :cond_13

    iget-object v7, v8, Lc/R1;->c:Ljava/lang/Object;

    check-cast v7, Ljava/util/List;

    goto :goto_c

    :cond_13
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v7

    :goto_c
    if-eqz v5, :cond_14

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v9

    iput-object v9, v8, Lc/R1;->c:Ljava/lang/Object;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v9

    iput-object v9, v8, Lc/R1;->b:Ljava/lang/Object;

    iput-object v2, v8, Lc/R1;->a:Ljava/lang/Object;

    :cond_14
    iget-object v2, v8, Lc/R1;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    invoke-interface {v2, v4}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_15

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    goto :goto_d

    :cond_15
    iget-object v2, v8, Lc/R1;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/List;

    if-eqz v2, :cond_16

    if-eqz v4, :cond_16

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_16

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v9

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v10

    if-gt v9, v10, :cond_16

    invoke-interface {v4, v2}, Ljava/util/List;->containsAll(Ljava/util/Collection;)Z

    move-result v2

    if-eqz v2, :cond_16

    new-instance v2, Ljava/util/LinkedHashSet;

    invoke-direct {v2, v4}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    iget-object v9, v8, Lc/R1;->b:Ljava/lang/Object;

    check-cast v9, Ljava/util/List;

    invoke-virtual {v2, v9}, Ljava/util/AbstractCollection;->removeAll(Ljava/util/Collection;)Z

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-static {v9}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    goto :goto_d

    :cond_16
    move-object v2, v4

    :goto_d
    iput-object v4, v8, Lc/R1;->b:Ljava/lang/Object;

    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_17

    iput-object v6, v8, Lc/R1;->c:Ljava/lang/Object;

    :cond_17
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    iget-object v7, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    if-eqz v6, :cond_18

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "AFTER:"

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v6}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_e

    :cond_18
    if-nez v5, :cond_19

    iget-object v4, v0, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1a

    :cond_19
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_1a

    const-string v4, "ATSH"

    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    :cond_1a
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1b

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "BEFORE:"

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_f

    :cond_1b
    iget-object v1, v1, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v7, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public final G0()Ljava/lang/String;
    .locals 8

    iget-object v0, p0, Lc/T5;->R:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/T5;->R:Ljava/lang/String;

    return-object v0

    :cond_0
    iget v0, p0, Lc/T5;->T:I

    invoke-static {v0}, Lc/k6;->I(I)I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lc/T5;->P:Ljava/lang/String;

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    if-nez v1, :cond_1

    const-string v1, ""

    goto :goto_0

    :cond_1
    iget-object v1, v1, Lc/j6;->e:Ljava/lang/String;

    :goto_0
    iget-object v2, p0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->f:Ljava/util/List;

    invoke-static {v0, v1, v2}, Lc/k6;->i0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :cond_2
    const/16 v2, 0x8

    if-ne v0, v2, :cond_3

    iget-object v0, p0, Lc/T5;->P:Ljava/lang/String;

    iget-object v1, p0, Lc/T5;->S:Ljava/lang/String;

    iget-object v2, p0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->f:Ljava/util/List;

    invoke-static {v0, v1, v2}, Lc/k6;->j0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_2

    :cond_3
    iget-object v0, p0, Lc/T5;->P:Ljava/lang/String;

    iget v3, p0, Lc/T5;->T:I

    const/4 v4, 0x0

    if-nez v0, :cond_5

    :cond_4
    :goto_1
    move-object v0, v4

    goto :goto_2

    :cond_5
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v5}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3}, Lc/k6;->I(I)I

    move-result v3

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-ne v3, v7, :cond_6

    const-string v1, "[0-9A-F]{6}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    const/4 v1, 0x2

    invoke-virtual {v0, v1, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_6
    if-ne v3, v1, :cond_8

    const-string v1, "[0-7][0-9A-F]{2}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_8

    const/16 v1, 0x10

    invoke-static {v0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    const/16 v1, 0x7df

    if-eq v0, v1, :cond_4

    const/16 v1, 0x7f7

    if-le v0, v1, :cond_7

    goto :goto_1

    :cond_7
    add-int/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "%03X"

    invoke-static {v5, v1, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_8
    if-ne v3, v2, :cond_4

    const-string v1, "18DA[0-9A-F]{4}"

    invoke-virtual {v0, v1}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "18DA"

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v7, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_2
    if-eqz v0, :cond_9

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_9

    iget-object v1, p0, Lc/T5;->P:Ljava/lang/String;

    iget-object v2, p0, Lc/T5;->Q:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    :cond_9
    iget-object v0, p0, Lc/T5;->D1:Ljava/lang/String;

    :cond_a
    return-object v0
.end method

.method public final H()V
    .locals 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "address"

    const-string v3, ""

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "profile_id"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "trip_vehicle"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    invoke-virtual {p0}, Lc/T5;->t0()V

    :cond_0
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public final H0()D
    .locals 6

    const-wide/high16 v0, 0x3ff0000000000000L    # 1.0

    :try_start_0
    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "speed_factor"

    const-string v4, "1"

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz v4, :cond_0

    const-wide/16 v4, 0x0

    cmpl-double v4, v2, v4

    if-lez v4, :cond_0

    move-wide v0, v2

    :catch_0
    :cond_0
    return-wide v0
.end method

.method public final I(Ljava/lang/String;)V
    .locals 1

    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void
.end method

.method public final I0([BI)D
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    const/4 v3, 0x5

    const/16 v4, 0x10

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ne v2, v7, :cond_c

    array-length v2, v1

    if-lt v2, v9, :cond_b

    iget-object v2, v0, Lc/T5;->e:Ljava/util/HashMap;

    const/16 v10, 0x103

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    new-instance v11, Lc/S5;

    array-length v12, v1

    const/16 v13, 0x8

    if-le v12, v9, :cond_5

    aget-byte v12, v1, v9

    and-int/lit16 v12, v12, 0xff

    if-eq v12, v9, :cond_4

    if-eq v12, v6, :cond_3

    if-eq v12, v5, :cond_2

    if-eq v12, v13, :cond_1

    if-eq v12, v4, :cond_0

    move v12, v3

    goto :goto_0

    :cond_0
    move v12, v5

    goto :goto_0

    :cond_1
    move v12, v7

    goto :goto_0

    :cond_2
    move v12, v6

    goto :goto_0

    :cond_3
    move v12, v9

    goto :goto_0

    :cond_4
    move v12, v8

    :goto_0
    int-to-double v14, v12

    goto :goto_1

    :cond_5
    const-wide/high16 v14, 0x4014000000000000L    # 5.0

    :goto_1
    const/4 v12, -0x1

    invoke-direct {v11, v14, v15, v12}, Lc/S5;-><init>(DI)V

    invoke-virtual {v2, v10, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    aget-byte v1, v1, v8

    and-int/lit16 v1, v1, 0xff

    if-eq v1, v9, :cond_a

    if-eq v1, v6, :cond_9

    if-eq v1, v5, :cond_8

    if-eq v1, v13, :cond_7

    if-eq v1, v4, :cond_6

    goto :goto_2

    :cond_6
    move v3, v5

    goto :goto_2

    :cond_7
    move v3, v7

    goto :goto_2

    :cond_8
    move v3, v6

    goto :goto_2

    :cond_9
    move v3, v9

    goto :goto_2

    :cond_a
    move v3, v8

    :goto_2
    int-to-double v1, v3

    return-wide v1

    :cond_b
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing fuel status bank"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_c
    const/16 v7, 0x45

    const-wide v10, 0x406fe00000000000L    # 255.0

    const-wide/high16 v12, 0x4059000000000000L    # 100.0

    if-ne v2, v7, :cond_e

    array-length v2, v1

    if-eqz v2, :cond_d

    aget-byte v1, v1, v8

    and-int/lit16 v1, v1, 0xff

    int-to-double v1, v1

    mul-double/2addr v1, v12

    div-double/2addr v1, v10

    return-wide v1

    :cond_d
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing relative throttle"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_e
    const/16 v7, 0x43

    if-ne v2, v7, :cond_10

    array-length v2, v1

    if-lt v2, v6, :cond_f

    aget-byte v2, v1, v8

    and-int/lit16 v2, v2, 0xff

    mul-int/lit16 v2, v2, 0x100

    aget-byte v1, v1, v9

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v2, v1

    int-to-double v1, v2

    mul-double/2addr v1, v12

    div-double/2addr v1, v10

    return-wide v1

    :cond_f
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing load"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_10
    const/16 v7, 0x51

    if-eq v2, v7, :cond_29

    const/16 v7, 0x33

    if-ne v2, v7, :cond_11

    goto/16 :goto_e

    :cond_11
    const/16 v7, 0x24

    iget-object v14, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/16 v15, 0x44

    if-lt v2, v7, :cond_12

    const/16 v7, 0x2b

    if-le v2, v7, :cond_14

    :cond_12
    const/16 v7, 0x34

    if-lt v2, v7, :cond_13

    const/16 v7, 0x3b

    if-le v2, v7, :cond_14

    :cond_13
    if-ne v2, v15, :cond_19

    :cond_14
    array-length v3, v1

    if-ne v2, v15, :cond_15

    move v5, v6

    :cond_15
    if-lt v3, v5, :cond_18

    aget-byte v3, v1, v8

    and-int/lit16 v3, v3, 0xff

    mul-int/lit16 v3, v3, 0x100

    aget-byte v1, v1, v9

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v3, v1

    int-to-double v3, v3

    const-wide v5, 0x3efffb480a5accd5L    # 3.05E-5

    mul-double/2addr v3, v5

    const-string v1, "fuel_type"

    invoke-interface {v14, v1, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    if-nez v1, :cond_17

    const-string v1, "fuel_af_stoichiometric"

    invoke-interface {v14, v1, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_17

    if-ne v2, v15, :cond_16

    const-wide v1, 0x402d47ae147ae148L    # 14.64

    goto :goto_3

    :cond_16
    const-wide v1, 0x402d666666666666L    # 14.7

    :goto_3
    mul-double/2addr v3, v1

    :cond_17
    return-wide v3

    :cond_18
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing air/fuel ratio"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_19
    const/16 v7, 0xd

    if-ne v2, v7, :cond_1c

    array-length v2, v1

    if-eqz v2, :cond_1b

    const-string v2, "speed_pid_two_bytes"

    invoke-interface {v14, v2, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_1a

    array-length v2, v1

    if-lt v2, v6, :cond_1a

    aget-byte v2, v1, v8

    and-int/lit16 v2, v2, 0xff

    mul-int/lit16 v2, v2, 0x100

    aget-byte v1, v1, v9

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v2, v1

    goto :goto_4

    :cond_1a
    aget-byte v1, v1, v8

    and-int/lit16 v2, v1, 0xff

    :goto_4
    int-to-double v1, v2

    invoke-virtual/range {p0 .. p0}, Lc/T5;->H0()D

    move-result-wide v3

    mul-double/2addr v3, v1

    return-wide v3

    :cond_1b
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing speed"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_1c
    iget v7, v0, Lc/T5;->T:I

    invoke-static {v7}, Lc/k6;->I(I)I

    move-result v7

    const/4 v14, 0x6

    const/16 v15, 0x5e

    const/16 v10, 0x42

    const/16 v11, 0xc

    if-eq v7, v14, :cond_1d

    goto :goto_7

    :cond_1d
    if-eq v2, v11, :cond_1f

    if-eq v2, v4, :cond_1f

    if-eq v2, v10, :cond_1f

    if-ne v2, v15, :cond_1e

    goto :goto_5

    :cond_1e
    move v7, v9

    goto :goto_6

    :cond_1f
    :goto_5
    move v7, v6

    :goto_6
    array-length v14, v1

    if-lt v14, v7, :cond_20

    invoke-static {v1, v7}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v1

    :cond_20
    :goto_7
    if-eq v2, v11, :cond_22

    if-eq v2, v10, :cond_22

    if-eq v2, v15, :cond_22

    if-ne v2, v4, :cond_21

    goto :goto_8

    :cond_21
    move v4, v9

    goto :goto_9

    :cond_22
    :goto_8
    move v4, v6

    :goto_9
    if-eqz v1, :cond_28

    array-length v7, v1

    if-ne v7, v4, :cond_28

    aget-byte v7, v1, v8

    and-int/lit16 v7, v7, 0xff

    if-ne v4, v6, :cond_23

    mul-int/lit16 v4, v7, 0x100

    aget-byte v1, v1, v9

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v4, v1

    goto :goto_a

    :cond_23
    move v4, v7

    :goto_a
    if-eq v2, v5, :cond_27

    if-eq v2, v3, :cond_26

    const/16 v1, 0x2f

    if-eq v2, v1, :cond_27

    if-eq v2, v10, :cond_25

    const/16 v1, 0x46

    if-eq v2, v1, :cond_26

    if-eq v2, v15, :cond_24

    packed-switch v2, :pswitch_data_0

    packed-switch v2, :pswitch_data_1

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Unknown PID"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :pswitch_0
    int-to-double v1, v4

    div-double/2addr v1, v12

    goto :goto_d

    :pswitch_1
    int-to-double v1, v4

    const-wide/high16 v3, 0x4010000000000000L    # 4.0

    :goto_b
    div-double/2addr v1, v3

    goto :goto_d

    :goto_c
    :pswitch_2
    int-to-double v1, v7

    goto :goto_d

    :cond_24
    int-to-double v1, v4

    const-wide/high16 v3, 0x4034000000000000L    # 20.0

    goto :goto_b

    :cond_25
    int-to-double v1, v4

    const-wide v3, 0x408f400000000000L    # 1000.0

    goto :goto_b

    :cond_26
    :pswitch_3
    add-int/lit8 v7, v7, -0x28

    goto :goto_c

    :cond_27
    :pswitch_4
    int-to-double v1, v7

    mul-double/2addr v1, v12

    const-wide v3, 0x406fe00000000000L    # 255.0

    goto :goto_b

    :goto_d
    return-wide v1

    :cond_28
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid PID length"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_29
    :goto_e
    array-length v2, v1

    if-eqz v2, :cond_2a

    aget-byte v1, v1, v8

    and-int/lit16 v1, v1, 0xff

    int-to-double v1, v1

    return-wide v1

    :cond_2a
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Missing fuel input"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    nop

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_2
        :pswitch_1
        :pswitch_2
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xf
        :pswitch_3
        :pswitch_0
        :pswitch_4
    .end packed-switch
.end method

.method public final J(ZLjava/lang/String;)V
    .locals 9

    iget-boolean v0, p0, Lc/T5;->w:Z

    const/4 v1, 0x2

    const-string v2, "enabled"

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    iget-boolean p1, p0, Lc/T5;->A:Z

    if-nez p1, :cond_1

    iget-boolean p1, p0, Lc/T5;->B:Z

    if-eqz p1, :cond_1

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result p1

    if-ne p1, v1, :cond_1

    invoke-virtual {p0}, Lc/T5;->s()V

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean p1, p0, Lc/T5;->u:Z

    if-nez p1, :cond_0

    iget-object p1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {p1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_0

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    const-wide/32 v0, 0xea60

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    const-string p1, "\u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8 \u00b7 \u05de\u05de\u05ea\u05d9\u05df \u05dc-ELM, \u05d1\u05dc\u05d9 \u05ea\u05e9\u05d0\u05d5\u05dc \u05de\u05d7\u05e9\u05d1 \u05d4\u05e8\u05db\u05d1"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    goto :goto_0

    :cond_1
    invoke-virtual {p0, v3}, Lc/T5;->K(Z)V

    :goto_0
    return-void

    :cond_2
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    const/4 v4, 0x1

    if-eqz v0, :cond_4

    iget-wide v5, p0, Lc/T5;->E:J

    const-wide/16 v7, 0x0

    cmp-long v0, v5, v7

    if-ltz v0, :cond_4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    iget-wide v7, p0, Lc/T5;->E:J

    sub-long/2addr v5, v7

    const-wide/32 v7, 0x1d4c0

    cmp-long v0, v5, v7

    if-ltz v0, :cond_4

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result p1

    if-ne p1, v1, :cond_3

    move v3, v4

    :cond_3
    invoke-virtual {p0, v3}, Lc/T5;->c0(Z)V

    const-string p1, "OBD \u05d1\u05d4\u05de\u05ea\u05e0\u05d4 \u00b7 \u05d0\u05d9\u05df \u05ea\u05d2\u05d5\u05d1\u05d4 \u05de\u05de\u05d7\u05e9\u05d1 \u05d4\u05e8\u05db\u05d1 (\u05de\u05e0\u05d5\u05e2 \u05db\u05d1\u05d5\u05d9)"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void

    :cond_4
    if-nez p1, :cond_5

    iget-boolean p1, p0, Lc/T5;->e1:Z

    if-eqz p1, :cond_5

    iput-boolean v3, p0, Lc/T5;->o1:Z

    :cond_5
    iget-boolean p1, p0, Lc/T5;->u:Z

    if-nez p1, :cond_8

    iget-object p1, p0, Lc/T5;->q0:Lc/n6;

    if-eqz p1, :cond_8

    iget-boolean p1, p1, Lc/n6;->h:Z

    if-nez p1, :cond_8

    iget-object p1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {p1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_8

    iget-object p1, p0, Lc/T5;->q0:Lc/n6;

    invoke-virtual {p1}, Lc/n6;->d()Lc/l6;

    move-result-object v0

    iget v0, v0, Lc/l6;->a:I

    if-ne v0, v1, :cond_6

    invoke-virtual {p1, v3}, Lc/n6;->e(Z)V

    goto :goto_1

    :cond_6
    iget-boolean v0, p1, Lc/n6;->h:Z

    if-nez v0, :cond_7

    iget-boolean v0, p1, Lc/n6;->i:Z

    if-nez v0, :cond_7

    iput-boolean v4, p1, Lc/n6;->i:Z

    :goto_1
    invoke-virtual {p0}, Lc/T5;->s()V

    iput-object p1, p0, Lc/T5;->r0:Lc/n6;

    iput-object p2, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    const-wide/16 v0, 0x12c

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "No initialization awaiting result"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_8
    invoke-virtual {p0}, Lc/T5;->s()V

    const/4 p1, 0x0

    iput-object p1, p0, Lc/T5;->r0:Lc/n6;

    iput-object p2, p0, Lc/T5;->C1:Ljava/lang/String;

    const-string p1, "DriveDeckOBD"

    invoke-static {p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {p0}, Lc/T5;->q()V

    iget-boolean p1, p0, Lc/T5;->u:Z

    if-nez p1, :cond_9

    iget-object p1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {p1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_9

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->g2:Lc/A5;

    iget-wide v0, p0, Lc/T5;->d2:J

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-wide p1, p0, Lc/T5;->d2:J

    const-wide/16 v0, 0x2

    mul-long/2addr p1, v0

    const-wide/16 v0, 0x7530

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p1

    iput-wide p1, p0, Lc/T5;->d2:J

    :cond_9
    return-void
.end method

.method public final J0(Ljava/lang/String;)V
    .locals 3

    const/4 v0, 0x0

    iput-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->c1:Z

    iget-object v1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    iput-object p1, p0, Lc/T5;->J0:Ljava/lang/String;

    new-instance v0, Lc/g6;

    iget v1, p0, Lc/T5;->T:I

    iget-object v2, p0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->f:Ljava/util/List;

    invoke-direct {v0, p1, v1, v2}, Lc/g6;-><init>(Ljava/lang/String;ILjava/util/List;)V

    iput-object v0, p0, Lc/T5;->F0:Lc/g6;

    invoke-virtual {v0}, Lc/g6;->e()Lc/f6;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->G0:Lc/f6;

    invoke-virtual {p0}, Lc/T5;->B0()V

    return-void
.end method

.method public final K(Z)V
    .locals 3

    iget-boolean v0, p0, Lc/T5;->w:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->G:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->H:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->c1:Z

    iget-object v1, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    iput-boolean v0, p0, Lc/T5;->A:Z

    if-eqz p1, :cond_1

    iget-boolean v1, p0, Lc/T5;->B:Z

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v1

    const/4 v2, 0x2

    if-ne v1, v2, :cond_1

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->D:J

    const-string p1, "\u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8 \u00b7 \u05de\u05ea\u05d7 ELM \u05d1\u05dc\u05d1\u05d3"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v0, p0, Lc/T5;->F:Lc/A5;

    const-wide/16 v1, 0x3a98

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1

    :cond_1
    iput-boolean v0, p0, Lc/T5;->B:Z

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "battery_watch"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0}, Lc/T5;->s()V

    if-eqz p1, :cond_2

    const-string p1, "OBD \u05d1\u05d4\u05de\u05ea\u05e0\u05d4 - \u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8"

    goto :goto_0

    :cond_2
    const-string p1, "OBD \u05de\u05e0\u05d5\u05ea\u05e7 \u00b7 \u05d1\u05d3\u05d5\u05e7 \u05de\u05e6\u05d1 \u05e9\u05d9\u05e0\u05d4 \u05e9\u05dc \u05d4\u05de\u05ea\u05d0\u05dd"

    :goto_0
    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    :goto_1
    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final K0(Ljava/io/InputStream;Ljava/io/OutputStream;I)V
    .locals 8

    monitor-enter p0

    :try_start_0
    iget v0, p0, Lc/T5;->t:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eq p3, v0, :cond_0

    :try_start_1
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_1

    :catch_0
    :goto_0
    :try_start_2
    monitor-exit p0

    return-void

    :cond_0
    iput-object p2, p0, Lc/T5;->K:Ljava/io/OutputStream;

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    new-instance v1, Lc/E5;

    const/4 v2, 0x1

    invoke-direct {v1, p0, p3, p2, v2}, Lc/E5;-><init>(Lc/T5;ILjava/io/OutputStream;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    new-instance v0, Ljava/lang/Thread;

    new-instance v7, Lc/N;

    const/4 v6, 0x5

    move-object v1, v7

    move-object v2, p0

    move v3, p3

    move-object v4, p2

    move-object v5, p1

    invoke-direct/range {v1 .. v6}, Lc/N;-><init>(Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V

    const-string p1, "DriveDeck-OBD-RX"

    invoke-direct {v0, v7, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void

    :goto_1
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1
.end method

.method public final L(Z)V
    .locals 5

    const/4 v0, 0x0

    iput-object v0, p0, Lc/T5;->P0:Lc/b6;

    iput-object v0, p0, Lc/T5;->O0:Lc/c6;

    iget-boolean v0, p0, Lc/T5;->i0:Z

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    iput-boolean v2, p0, Lc/T5;->i0:Z

    if-nez p1, :cond_0

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u0441\u043e\u0435\u0434\u0438\u043d\u0435\u043d\u0438\u0435 \u0441 \u042d\u0411\u0423"

    invoke-virtual {p0, v2, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :cond_0
    const-string p1, ""

    iput-object p1, p0, Lc/T5;->P:Ljava/lang/String;

    iget-object p1, p0, Lc/T5;->y1:Lc/R1;

    invoke-virtual {p1}, Lc/R1;->c()V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    invoke-virtual {p0}, Lc/T5;->Y()V

    iput-boolean v1, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->q()V

    invoke-virtual {p0}, Lc/T5;->Z()V

    return-void

    :cond_1
    iget-object v0, p0, Lc/T5;->q0:Lc/n6;

    if-eqz v0, :cond_7

    iget-boolean v3, v0, Lc/n6;->h:Z

    if-eqz v3, :cond_2

    goto :goto_2

    :cond_2
    if-nez v3, :cond_6

    iget-boolean v3, v0, Lc/n6;->i:Z

    if-nez v3, :cond_6

    iget-boolean v3, v0, Lc/n6;->g:Z

    if-nez v3, :cond_5

    if-eqz p1, :cond_4

    iget-object p1, v0, Lc/n6;->a:Lc/m6;

    iget-boolean v3, p1, Lc/m6;->d:Z

    if-nez v3, :cond_3

    iget-boolean v3, p1, Lc/m6;->e:Z

    if-nez v3, :cond_3

    iget v3, v0, Lc/n6;->c:I

    iget v4, p1, Lc/m6;->b:I

    if-ne v3, v4, :cond_3

    goto :goto_0

    :cond_3
    iget v2, p1, Lc/m6;->a:I

    :goto_0
    iput v2, v0, Lc/n6;->f:I

    iput-boolean v1, v0, Lc/n6;->h:Z

    goto :goto_1

    :cond_4
    invoke-virtual {v0}, Lc/n6;->a()V

    goto :goto_1

    :cond_5
    iput-boolean p1, v0, Lc/n6;->j:Z

    invoke-virtual {v0}, Lc/n6;->b()V

    :goto_1
    invoke-virtual {p0}, Lc/T5;->o()V

    return-void

    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "No initialization awaiting result"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_7
    :goto_2
    if-nez p1, :cond_8

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043f\u043e\u0432\u0442\u043e\u0440\u043d\u043e \u0438\u043d\u0438\u0446\u0438\u0430\u043b\u0438\u0437\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0430\u0434\u0430\u043f\u0442\u0435\u0440"

    invoke-virtual {p0, v2, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    goto :goto_3

    :cond_8
    invoke-virtual {p0}, Lc/T5;->Z()V

    :goto_3
    return-void
.end method

.method public final L0()V
    .locals 4

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->i2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->Z1:Landroid/bluetooth/le/BluetoothLeScanner;

    if-eqz v0, :cond_0

    iget-boolean v1, p0, Lc/T5;->G1:Z

    if-eqz v1, :cond_0

    :try_start_0
    iget-object v1, p0, Lc/T5;->C2:Lc/I5;

    invoke-virtual {v0, v1}, Landroid/bluetooth/le/BluetoothLeScanner;->stopScan(Landroid/bluetooth/le/ScanCallback;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->G1:Z

    iget-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    const-string v1, "\u041f\u043e\u0438\u0441\u043a \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u043e\u0432\u2026"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lc/T5;->F1:Z

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u00b7 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "OBD"

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "name"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lc/T5;->A1:Ljava/util/LinkedHashMap;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440\u044b \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u044b"

    goto :goto_0

    :cond_2
    const-string v0, "\u05d1\u05d7\u05e8 \u05de\u05ea\u05d0\u05dd OBD"

    :goto_0
    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    :cond_3
    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final M(ZLjava/lang/String;)V
    .locals 27

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v9, p2

    iget-boolean v2, v0, Lc/T5;->w:Z

    const-string v3, "OK"

    const-string v4, ""

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v2, :cond_2

    iget-boolean v2, v0, Lc/T5;->A:Z

    if-eqz v2, :cond_2

    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    const-string v5, "ATPC"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    if-nez v1, :cond_0

    invoke-virtual {v9, v5, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    const-string v6, "[\\s>]"

    invoke-virtual {v2, v6, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    move v10, v11

    :goto_0
    if-nez v10, :cond_1

    invoke-virtual {v0, v5, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_1
    invoke-virtual {v0, v10}, Lc/T5;->K(Z)V

    return-void

    :cond_2
    iget-boolean v2, v0, Lc/T5;->z:Z

    const-string v5, "ATRV"

    if-eqz v2, :cond_3

    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v5, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-virtual/range {p0 .. p2}, Lc/T5;->n(ZLjava/lang/String;)V

    return-void

    :cond_3
    iget-boolean v2, v0, Lc/T5;->w:Z

    if-eqz v2, :cond_4

    return-void

    :cond_4
    const-string v2, "ERROR"

    const-string v6, "?"

    if-nez v1, :cond_5

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_5

    sget-object v7, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v7}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_6

    :cond_5
    iget-object v7, v0, Lc/T5;->z1:Lc/r5;

    iget-object v8, v7, Lc/r5;->a:Ljava/lang/Object;

    check-cast v8, Ljava/util/HashMap;

    invoke-virtual {v8}, Ljava/util/HashMap;->clear()V

    iget-object v7, v7, Lc/r5;->b:Ljava/lang/Object;

    check-cast v7, Ljava/util/HashMap;

    invoke-virtual {v7}, Ljava/util/HashMap;->clear()V

    :cond_6
    iget v7, v0, Lc/T5;->a0:I

    const/4 v12, 0x0

    if-lez v7, :cond_c

    iget-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-object v12, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-boolean v11, v0, Lc/T5;->c1:Z

    iget-object v4, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v4, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v5, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v4, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v5, v0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_7

    invoke-virtual {v9, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8

    :cond_7
    invoke-virtual {v0, v3, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_8
    iget v1, v0, Lc/T5;->a0:I

    sub-int/2addr v1, v10

    iput v1, v0, Lc/T5;->a0:I

    if-lez v1, :cond_9

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "ATST"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v0, Lc/T5;->Z:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_9
    iget-object v1, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "recovered_atst"

    iget-object v3, v0, Lc/T5;->Z:Ljava/lang/String;

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    iget-object v2, v0, Lc/T5;->Z:Ljava/lang/String;

    invoke-static {v2}, Lc/c6;->f(Ljava/lang/String;)I

    move-result v2

    if-ltz v2, :cond_a

    const-string v3, "source_atst_idx"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :cond_a
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    if-eqz v1, :cond_b

    iget-object v2, v0, Lc/T5;->Z:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lc/c6;->d(Ljava/lang/String;)V

    :cond_b
    iget-object v1, v0, Lc/T5;->b0:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->c0:Ljava/lang/String;

    iput-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->d0:Lc/b6;

    iput-object v2, v0, Lc/T5;->P0:Lc/b6;

    iput-object v12, v0, Lc/T5;->c0:Ljava/lang/String;

    iput-object v12, v0, Lc/T5;->b0:Ljava/lang/String;

    iput-object v12, v0, Lc/T5;->d0:Lc/b6;

    invoke-virtual {v0, v11, v1}, Lc/T5;->M(ZLjava/lang/String;)V

    return-void

    :cond_c
    iget v7, v0, Lc/T5;->y0:I

    const-string v8, "ATS0"

    const/4 v13, 0x3

    const/4 v14, 0x2

    if-lez v7, :cond_11

    iget-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-object v12, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-boolean v11, v0, Lc/T5;->c1:Z

    iget-object v4, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v4, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v5, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v4, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v5, v0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_d

    invoke-virtual {v9, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_e

    :cond_d
    invoke-virtual {v0, v3, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_e
    iget v1, v0, Lc/T5;->y0:I

    if-ge v1, v13, :cond_10

    add-int/2addr v1, v10

    iput v1, v0, Lc/T5;->y0:I

    if-ne v1, v14, :cond_f

    goto :goto_1

    :cond_f
    const-string v8, "ATH1"

    :goto_1
    invoke-virtual {v0, v8}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_10
    iput v11, v0, Lc/T5;->y0:I

    iget-object v1, v0, Lc/T5;->z0:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->A0:Ljava/lang/String;

    iget-boolean v3, v0, Lc/T5;->x0:Z

    iput-object v12, v0, Lc/T5;->A0:Ljava/lang/String;

    iput-object v12, v0, Lc/T5;->z0:Ljava/lang/String;

    iput-boolean v10, v0, Lc/T5;->w0:Z

    iput-object v1, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v3, v2}, Lc/T5;->M(ZLjava/lang/String;)V

    iput-boolean v11, v0, Lc/T5;->w0:Z

    return-void

    :cond_11
    iget-object v7, v0, Lc/T5;->F0:Lc/g6;

    if-nez v7, :cond_12

    iget-object v7, v0, Lc/T5;->H0:Lc/e6;

    if-eqz v7, :cond_13

    :cond_12
    move-object v2, v12

    goto/16 :goto_3d

    :cond_13
    iget-boolean v3, v0, Lc/T5;->K0:Z

    const/16 v7, 0x9

    const/4 v15, 0x6

    if-nez v3, :cond_14

    iget-boolean v3, v0, Lc/T5;->e1:Z

    if-nez v3, :cond_14

    iget-object v3, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v3, :cond_14

    iget-object v14, v0, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v14, :cond_14

    iget-object v3, v3, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v14, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_14

    iget v3, v0, Lc/T5;->T:I

    if-lt v3, v15, :cond_14

    if-gt v3, v7, :cond_14

    iget-object v3, v0, Lc/T5;->a1:Lc/R5;

    iget-object v3, v3, Lc/R5;->c:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_14

    const-string v3, "BUFFER FULL"

    invoke-virtual {v9, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_14

    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v2, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    iget-object v1, v0, Lc/T5;->N0:Ljava/util/HashSet;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->X()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    iget-object v1, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/T5;->J0(Ljava/lang/String;)V

    return-void

    :cond_14
    iget-boolean v3, v0, Lc/T5;->w0:Z

    const-string v14, "(?:03|07|0A)|(?:01|02|06|09|18|19|1A|21|22|23|2C|A8)(?:[0-9A-F]{2}){1,255}"

    const-string v15, "DriveDeckOBD"

    const-string v13, " "

    if-nez v3, :cond_15

    iget-boolean v3, v0, Lc/T5;->v0:Z

    if-eqz v3, :cond_15

    iget-object v3, v0, Lc/T5;->P0:Lc/b6;

    if-nez v3, :cond_15

    iget-boolean v3, v0, Lc/T5;->e1:Z

    if-nez v3, :cond_15

    iget-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v3, :cond_15

    invoke-static {v3}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v14}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_15

    iget-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v9, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_15

    invoke-virtual {v9, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_15

    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-object v2, v0, Lc/T5;->z0:Ljava/lang/String;

    iput-object v9, v0, Lc/T5;->A0:Ljava/lang/String;

    iput-boolean v1, v0, Lc/T5;->x0:Z

    iput v10, v0, Lc/T5;->y0:I

    iput-object v12, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-boolean v11, v0, Lc/T5;->c1:Z

    iget-object v1, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-string v1, "Adapter reset detected; restoring echo/spacing/headers"

    invoke-static {v15, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const-string v1, "ATE0"

    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_15
    iget-boolean v3, v0, Lc/T5;->K0:Z

    const/16 v12, 0xa

    if-nez v3, :cond_1a

    iget-boolean v3, v0, Lc/T5;->e1:Z

    if-eqz v3, :cond_1a

    iget-boolean v3, v0, Lc/T5;->n1:Z

    if-eqz v3, :cond_1a

    iget-object v3, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    if-eqz v1, :cond_16

    iget v7, v0, Lc/T5;->l1:I

    add-int/2addr v7, v10

    iput v7, v0, Lc/T5;->l1:I

    :cond_16
    const-string v7, "\r\r>"

    invoke-virtual {v3, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_17

    const-string v7, "\r\r\r"

    invoke-virtual {v3, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_18

    :cond_17
    iget v7, v0, Lc/T5;->m1:I

    add-int/2addr v7, v10

    iput v7, v0, Lc/T5;->m1:I

    :cond_18
    iget v7, v0, Lc/T5;->l1:I

    if-gt v7, v12, :cond_19

    iget v7, v0, Lc/T5;->m1:I

    if-le v7, v12, :cond_1a

    :cond_19
    iget-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v2, v3, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v1, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0430\u0440\u0443\u0448\u0430\u0435\u0442 \u0444\u043e\u0440\u043c\u0430\u0442 \u043e\u0442\u0432\u0435\u0442\u0430 \u043f\u0440\u0438 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0435 \u043f\u0440\u043e\u0444\u0438\u043b\u044f"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_1a
    iget-object v7, v0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v3, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v3, 0x0

    iput-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    iput-boolean v11, v0, Lc/T5;->c1:Z

    const-string v3, "ATST[0-9A-F]{2}"

    invoke-virtual {v7, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x4

    if-eqz v3, :cond_1b

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1b

    invoke-virtual {v9, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1b

    invoke-virtual {v7, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->Z:Ljava/lang/String;

    :cond_1b
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1d

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1c

    invoke-virtual {v9, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1c

    move v3, v10

    goto :goto_2

    :cond_1c
    move v3, v11

    :goto_2
    iput-boolean v3, v0, Lc/T5;->v0:Z

    :cond_1d
    iget-object v3, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v8, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v3, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v8, v0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v3, v8}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v3, v0, Lc/T5;->D0:Lc/j7;

    const-string v8, "\u042d\u0411\u0423 \u043d\u0435 \u0432\u0435\u0440\u043d\u0443\u043b \u0434\u0430\u043d\u043d\u044b\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0433\u043e PID"

    const-string v10, "ATSPDEF"

    if-eqz v3, :cond_2b

    invoke-virtual/range {p0 .. p0}, Lc/T5;->V0()Z

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v9, v3}, Lc/T5;->W0(Ljava/lang/String;[B)V

    iget-object v3, v0, Lc/T5;->C0:Lc/k7;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6, v9}, Lc/k7;->a(JLjava/lang/String;)Lc/j7;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->D0:Lc/j7;

    if-eqz v3, :cond_1e

    invoke-virtual/range {p0 .. p0}, Lc/T5;->C0()V

    return-void

    :cond_1e
    iget-object v3, v0, Lc/T5;->C0:Lc/k7;

    invoke-virtual {v3}, Lc/k7;->f()[B

    move-result-object v3

    if-eqz v2, :cond_1f

    invoke-virtual {v0, v4, v3}, Lc/T5;->W0(Ljava/lang/String;[B)V

    :cond_1f
    iget-boolean v5, v0, Lc/T5;->e1:Z

    if-nez v5, :cond_22

    iget-object v5, v0, Lc/T5;->C0:Lc/k7;

    invoke-virtual {v5}, Lc/k7;->h()[B

    move-result-object v5

    if-eqz v5, :cond_21

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    array-length v7, v5

    const/4 v13, 0x0

    :goto_3
    if-ge v13, v7, :cond_20

    aget-byte v14, v5, v13

    sget-object v15, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    and-int/lit16 v14, v14, 0xff

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    filled-new-array {v14}, [Ljava/lang/Object;

    move-result-object v14

    const-string v11, "%02X"

    invoke-static {v15, v11, v14}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v13, v13, 0x1

    goto :goto_3

    :cond_20
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_4

    :cond_21
    move-object v5, v9

    :goto_4
    iget v6, v0, Lc/T5;->u1:I

    const/16 v7, 0x14

    invoke-static {v6, v7, v5}, Lc/k6;->T(IILjava/lang/String;)I

    move-result v5

    iput v5, v0, Lc/T5;->u1:I

    :cond_22
    if-eqz v3, :cond_23

    iget-object v5, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v5, :cond_23

    const/4 v5, 0x0

    invoke-virtual {v0, v3, v5}, Lc/T5;->B([B[B)Z

    move-result v3

    if-eqz v3, :cond_24

    const/16 v16, 0x1

    goto :goto_5

    :cond_23
    const/4 v5, 0x0

    :cond_24
    const/16 v16, 0x0

    :goto_5
    if-eqz v16, :cond_25

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Y()V

    goto :goto_7

    :cond_25
    invoke-virtual {v0, v5, v5}, Lc/T5;->B([B[B)Z

    iget-object v3, v0, Lc/T5;->a1:Lc/R5;

    if-nez v3, :cond_26

    const-string v3, "VWTP"

    goto :goto_6

    :cond_26
    iget-object v3, v3, Lc/R5;->b:Ljava/lang/String;

    :goto_6
    invoke-virtual {v0, v3, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :goto_7
    iget v1, v0, Lc/T5;->E0:I

    iput v1, v0, Lc/T5;->T:I

    sget-object v1, Lc/k7;->v:[Ljava/lang/String;

    const/4 v11, 0x0

    :goto_8
    if-ge v11, v12, :cond_28

    aget-object v3, v1, v11

    iget-object v5, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v3, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_27

    iget-object v3, v0, Lc/T5;->X:Ljava/lang/String;

    :cond_27
    invoke-virtual {v5, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    add-int/lit8 v11, v11, 0x1

    goto :goto_8

    :cond_28
    iput-object v4, v0, Lc/T5;->P:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object v1, v0, Lc/T5;->C0:Lc/k7;

    if-eqz v2, :cond_29

    if-nez v16, :cond_29

    invoke-virtual {v0, v8}, Lc/T5;->N(Ljava/lang/String;)V

    :cond_29
    invoke-virtual/range {p0 .. p0}, Lc/T5;->u()V

    iget-boolean v1, v0, Lc/T5;->e1:Z

    if-nez v1, :cond_2a

    iget v1, v0, Lc/T5;->u1:I

    const/16 v2, 0x28

    if-le v1, v2, :cond_2a

    invoke-virtual/range {p0 .. p0}, Lc/T5;->m0()V

    return-void

    :cond_2a
    invoke-virtual/range {p0 .. p0}, Lc/T5;->T0()V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_2b
    iget-boolean v3, v0, Lc/T5;->p0:Z

    const-string v11, "10[0-9A-F]{2}"

    const-string v12, "ATDPN"

    if-nez v3, :cond_2d

    iget v3, v0, Lc/T5;->T:I

    if-nez v3, :cond_2d

    iget-object v3, v0, Lc/T5;->Y:Ljava/lang/String;

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2c

    const/4 v3, 0x0

    :try_start_0
    invoke-static {v7, v3}, Lc/k6;->u0(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_9

    :catch_0
    invoke-static {v7}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_2d

    :cond_2c
    :goto_9
    iput-object v9, v0, Lc/T5;->e0:Ljava/lang/String;

    iput-boolean v1, v0, Lc/T5;->k0:Z

    iput-object v7, v0, Lc/T5;->f0:Ljava/lang/String;

    iget-object v1, v0, Lc/T5;->P:Ljava/lang/String;

    iput-object v1, v0, Lc/T5;->g0:Ljava/lang/String;

    iget-object v1, v0, Lc/T5;->P0:Lc/b6;

    iput-object v1, v0, Lc/T5;->j0:Lc/b6;

    const/4 v1, 0x0

    iput-object v1, v0, Lc/T5;->P0:Lc/b6;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/T5;->h0:Z

    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1, v12}, Ljava/util/ArrayDeque;->remove(Ljava/lang/Object;)Z

    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1, v12}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_2d
    iget-object v3, v0, Lc/T5;->P0:Lc/b6;

    move-object/from16 v17, v14

    const-string v14, "RX "

    move-object/from16 v18, v10

    if-eqz v3, :cond_41

    iget-boolean v3, v3, Lc/b6;->d:Z

    if-eqz v3, :cond_41

    invoke-virtual {v0, v9, v7}, Lc/T5;->F0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget v2, v0, Lc/T5;->T:I

    invoke-static {v2}, Lc/k6;->I(I)I

    move-result v2

    if-nez v11, :cond_2e

    const/4 v3, 0x3

    if-eq v2, v3, :cond_2f

    const/16 v3, 0x8

    if-ne v2, v3, :cond_2e

    goto :goto_a

    :cond_2e
    move-object v10, v7

    goto/16 :goto_e

    :cond_2f
    :goto_a
    iget v3, v0, Lc/T5;->T:I

    if-eqz v3, :cond_2e

    iget-object v3, v0, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_2e

    iget-object v3, v0, Lc/T5;->P:Ljava/lang/String;

    iget-object v5, v0, Lc/T5;->Q:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2e

    iget-object v3, v0, Lc/T5;->R:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_30

    iget-object v2, v0, Lc/T5;->R:Ljava/lang/String;

    :goto_b
    move-object v5, v2

    goto :goto_d

    :cond_30
    const/4 v3, 0x3

    if-ne v2, v3, :cond_32

    iget-object v2, v0, Lc/T5;->P:Ljava/lang/String;

    iget-object v3, v0, Lc/T5;->g:Lc/j6;

    if-nez v3, :cond_31

    goto :goto_c

    :cond_31
    iget-object v4, v3, Lc/j6;->e:Ljava/lang/String;

    :goto_c
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v3

    invoke-static {v2, v4, v3}, Lc/k6;->i0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v2

    goto :goto_b

    :cond_32
    iget-object v2, v0, Lc/T5;->P:Ljava/lang/String;

    iget-object v3, v0, Lc/T5;->S:Ljava/lang/String;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v4

    invoke-static {v2, v3, v4}, Lc/k6;->j0(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v2

    goto :goto_b

    :goto_d
    if-eqz v5, :cond_2e

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2e

    iget v3, v0, Lc/T5;->T:I

    invoke-virtual/range {p0 .. p0}, Lc/T5;->D0()Lc/I6;

    move-result-object v6

    iget-object v2, v0, Lc/T5;->R:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v4, 0x1

    xor-int/lit8 v8, v2, 0x1

    iget-object v2, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v12, "service_response_marker"

    invoke-interface {v2, v12, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    move-object/from16 v2, p2

    move-object v4, v7

    move-object v10, v7

    move v7, v8

    move v8, v12

    invoke-static/range {v2 .. v8}, Lc/G8;->C0(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lc/I6;ZZ)Lc/R1;

    move-result-object v2

    if-eqz v2, :cond_33

    iget-object v3, v2, Lc/R1;->a:Ljava/lang/Object;

    move-object v11, v3

    check-cast v11, Ljava/lang/String;

    goto :goto_f

    :goto_e
    const/4 v2, 0x0

    :cond_33
    :goto_f
    if-eqz v11, :cond_34

    if-nez v1, :cond_34

    const/4 v3, 0x1

    goto :goto_10

    :cond_34
    const/4 v3, 0x0

    :goto_10
    if-eqz v3, :cond_3a

    iget-object v3, v0, Lc/T5;->g:Lc/j6;

    if-eqz v3, :cond_35

    iget-boolean v3, v3, Lc/j6;->g:Z

    if-eqz v3, :cond_36

    :cond_35
    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-static {v3, v4}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_36

    const/4 v3, 0x1

    goto :goto_11

    :cond_36
    const/4 v3, 0x0

    :goto_11
    if-eqz v2, :cond_37

    iget-object v2, v2, Lc/R1;->b:Ljava/lang/Object;

    check-cast v2, [B

    goto :goto_12

    :cond_37
    if-eqz v3, :cond_38

    iget v2, v0, Lc/T5;->T:I

    invoke-static {v2, v9, v10, v11}, Lc/k6;->F(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v2

    goto :goto_12

    :cond_38
    const/4 v2, 0x0

    invoke-virtual {v0, v9, v10, v11, v2}, Lc/T5;->E0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)[B

    move-result-object v3

    move-object v2, v3

    :goto_12
    if-eqz v2, :cond_39

    array-length v2, v2

    if-lez v2, :cond_39

    const/4 v2, 0x1

    goto :goto_13

    :cond_39
    const/4 v2, 0x0

    :goto_13
    move v3, v2

    :cond_3a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0xd

    const/16 v5, 0x20

    invoke-virtual {v9, v4, v5}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0xa

    invoke-virtual {v4, v6, v5}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v15, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v10, v9}, Lru/drivedeck/launcher/HeObd;->onRx(Ljava/lang/String;Ljava/lang/String;)V

    if-nez v3, :cond_3b

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_3b
    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    invoke-virtual {v1, v3}, Lc/c6;->b(Z)V

    if-eqz v11, :cond_3c

    iput-object v11, v0, Lc/T5;->D1:Ljava/lang/String;

    :cond_3c
    const/4 v1, 0x0

    iput-object v1, v0, Lc/T5;->P0:Lc/b6;

    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    iget-boolean v2, v1, Lc/c6;->j:Z

    if-nez v2, :cond_3e

    iget-boolean v1, v1, Lc/c6;->i:Z

    if-eqz v1, :cond_3d

    goto :goto_14

    :cond_3d
    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_17

    :cond_3e
    :goto_14
    iget-boolean v1, v0, Lc/T5;->i0:Z

    if-nez v1, :cond_40

    if-eqz v2, :cond_3f

    goto :goto_15

    :cond_3f
    const/4 v10, 0x0

    goto :goto_16

    :cond_40
    :goto_15
    const/4 v10, 0x1

    :goto_16
    invoke-virtual {v0, v10}, Lc/T5;->L(Z)V

    :goto_17
    return-void

    :cond_41
    move-object v10, v7

    const/4 v3, 0x3

    const-string v7, "AT"

    invoke-virtual {v10, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_42

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v19

    if-eqz v19, :cond_42

    iget-object v3, v0, Lc/T5;->f1:Ljava/util/HashSet;

    invoke-virtual {v3, v10}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_42
    iget-boolean v3, v0, Lc/T5;->e1:Z

    if-eqz v3, :cond_43

    iget-object v3, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v3, :cond_43

    iget-object v3, v3, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_43

    move-object/from16 v20, v4

    const/4 v3, 0x1

    goto :goto_18

    :cond_43
    move-object/from16 v20, v4

    const/4 v3, 0x0

    :goto_18
    const-string v4, "ATCP"

    move-object/from16 v21, v12

    const-string v12, "ATSH"

    move-object/from16 v22, v2

    const-string v2, "ATSP"

    move/from16 v23, v3

    if-eqz v3, :cond_45

    iget-boolean v3, v0, Lc/T5;->n1:Z

    if-eqz v3, :cond_45

    iget-object v3, v0, Lc/T5;->f1:Ljava/util/HashSet;

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_19
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v24

    if-eqz v24, :cond_45

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    move-object/from16 v25, v3

    move-object/from16 v3, v24

    check-cast v3, Ljava/lang/String;

    move-object/from16 v24, v7

    const-string v7, "ATFC"

    invoke-virtual {v3, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_44

    invoke-virtual {v3, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_44

    invoke-virtual {v3, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_44

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_44

    move-object/from16 v7, v24

    move-object/from16 v3, v25

    goto :goto_19

    :cond_44
    const-string v1, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u0443 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f: "

    invoke-virtual {v1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_45
    move-object/from16 v24, v7

    iget-boolean v3, v0, Lc/T5;->w1:Z

    const-string v7, "@"

    if-eqz v3, :cond_46

    iget-object v3, v0, Lc/T5;->x1:Ljava/util/HashMap;

    move-object/from16 v25, v2

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v26, v4

    iget-object v4, v0, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_47

    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_47

    const/4 v2, 0x0

    iput-boolean v2, v0, Lc/T5;->w1:Z

    iget-object v2, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    goto :goto_1a

    :cond_46
    move-object/from16 v25, v2

    move-object/from16 v26, v4

    :cond_47
    :goto_1a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0xd

    const/16 v4, 0x20

    invoke-virtual {v9, v3, v4}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v3

    const/16 v13, 0xa

    invoke-virtual {v3, v13, v4}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v15, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {v10, v9}, Lru/drivedeck/launcher/HeObd;->onRx(Ljava/lang/String;Ljava/lang/String;)V

    iget-boolean v2, v0, Lc/T5;->l0:Z

    if-eqz v2, :cond_49

    const/4 v2, 0x0

    iput-boolean v2, v0, Lc/T5;->l0:Z

    iget v1, v0, Lc/T5;->u1:I

    iget v2, v0, Lc/T5;->T:I

    invoke-static {v1, v2, v9}, Lc/k6;->T(IILjava/lang/String;)I

    move-result v1

    iput v1, v0, Lc/T5;->u1:I

    const/16 v2, 0x28

    if-le v1, v2, :cond_48

    invoke-virtual/range {p0 .. p0}, Lc/T5;->m0()V

    return-void

    :cond_48
    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_49
    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v2, :cond_4a

    iget-object v2, v2, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_4a

    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4a

    const/4 v2, 0x0

    invoke-virtual {v0, v9, v2}, Lc/T5;->W0(Ljava/lang/String;[B)V

    :cond_4a
    invoke-static {v10}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v11}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    const/16 v3, 0x10

    if-eqz v2, :cond_4f

    iget v2, v0, Lc/T5;->T:I

    invoke-static {v2}, Lc/k6;->I(I)I

    move-result v4

    const/4 v11, 0x6

    if-ne v4, v11, :cond_4b

    const/4 v4, 0x0

    const/4 v13, 0x3

    goto :goto_1b

    :cond_4b
    const/4 v4, 0x0

    const/4 v13, 0x1

    :goto_1b
    invoke-static {v9, v2, v13, v4, v4}, Lc/k6;->X(Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v4, 0x0

    :cond_4c
    :goto_1c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_4e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/n7;

    iget-object v11, v11, Lc/n7;->b:[B

    array-length v13, v11

    const/4 v14, 0x2

    if-lt v13, v14, :cond_4c

    const/4 v13, 0x0

    aget-byte v15, v11, v13

    and-int/lit16 v13, v15, 0xff

    const/16 v15, 0x50

    if-ne v13, v15, :cond_4c

    const/4 v13, 0x1

    aget-byte v11, v11, v13

    and-int/lit16 v11, v11, 0xff

    invoke-virtual {v10, v14}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v13

    if-eq v11, v13, :cond_4d

    goto :goto_1c

    :cond_4d
    const/4 v4, 0x1

    goto :goto_1c

    :cond_4e
    if-nez v4, :cond_4f

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_4f
    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v2, :cond_55

    iget-object v2, v2, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_55

    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_55

    invoke-virtual/range {p0 .. p0}, Lc/T5;->V0()Z

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lc/T5;->G0()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x0

    :try_start_1
    invoke-virtual {v0, v9, v10, v4, v11}, Lc/T5;->E0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)[B

    move-result-object v13
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1d

    :catch_1
    const/4 v13, 0x0

    :goto_1d
    if-eqz v2, :cond_50

    invoke-virtual {v0, v9, v13}, Lc/T5;->W0(Ljava/lang/String;[B)V

    :cond_50
    if-eqz v13, :cond_51

    iget-object v11, v0, Lc/T5;->a1:Lc/R5;

    iget-object v11, v11, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-interface {v11}, Ljava/util/Collection;->stream()Ljava/util/stream/Stream;

    move-result-object v11

    new-instance v14, Lc/C5;

    const/4 v15, 0x0

    invoke-direct {v14, v15}, Lc/C5;-><init>(I)V

    invoke-interface {v11, v14}, Ljava/util/stream/Stream;->anyMatch(Ljava/util/function/Predicate;)Z

    move-result v11

    if-eqz v11, :cond_51

    const/4 v11, 0x1

    invoke-virtual {v0, v9, v10, v4, v11}, Lc/T5;->E0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)[B

    move-result-object v4

    goto :goto_1e

    :cond_51
    const/4 v4, 0x0

    :goto_1e
    invoke-virtual {v0, v13, v4}, Lc/T5;->B([B[B)Z

    move-result v4

    if-eqz v2, :cond_52

    if-nez v13, :cond_52

    invoke-virtual {v0, v8}, Lc/T5;->N(Ljava/lang/String;)V

    goto :goto_1f

    :cond_52
    if-eqz v2, :cond_53

    if-nez v4, :cond_53

    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-interface {v2}, Ljava/util/Collection;->stream()Ljava/util/stream/Stream;

    move-result-object v2

    new-instance v8, Lc/C5;

    const/4 v11, 0x1

    invoke-direct {v8, v11}, Lc/C5;-><init>(I)V

    invoke-interface {v2, v8}, Ljava/util/stream/Stream;->allMatch(Ljava/util/function/Predicate;)Z

    move-result v2

    if-eqz v2, :cond_53

    const-string v2, "\u041e\u0442\u0432\u0435\u0442 \u043f\u043e\u043b\u0443\u0447\u0435\u043d, \u043d\u043e \u0444\u043e\u0440\u043c\u0443\u043b\u0430 \u0438\u043b\u0438 \u0433\u0440\u0430\u043d\u0438\u0446\u044b \u0434\u0430\u043d\u043d\u044b\u0445 \u043d\u0435 \u043f\u043e\u0434\u043e\u0448\u043b\u0438"

    invoke-virtual {v0, v2}, Lc/T5;->N(Ljava/lang/String;)V

    :cond_53
    :goto_1f
    if-eqz v4, :cond_54

    const/4 v2, 0x0

    iput v2, v0, Lc/T5;->U0:I

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Y()V

    goto :goto_20

    :cond_54
    iget v2, v0, Lc/T5;->U0:I

    const/4 v8, 0x1

    add-int/2addr v2, v8

    iput v2, v0, Lc/T5;->U0:I

    :goto_20
    iget-boolean v2, v0, Lc/T5;->F1:Z

    if-nez v2, :cond_56

    iget-boolean v2, v0, Lc/T5;->d1:Z

    if-nez v2, :cond_56

    iget v2, v0, Lc/T5;->U0:I

    iget-object v8, v0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lt v2, v8, :cond_56

    const-string v1, "\u042d\u0411\u0423 \u043d\u0435 \u043e\u0442\u0432\u0435\u0447\u0430\u0435\u0442 \u043d\u0430 \u0434\u0430\u0442\u0447\u0438\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_55
    const/4 v4, 0x0

    :cond_56
    iget-object v2, v0, Lc/T5;->P0:Lc/b6;

    const-string v8, "7DF"

    const-string v11, "18DB33F1"

    const/4 v13, 0x7

    if-nez v2, :cond_63

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v10, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_63

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    const/4 v15, 0x2

    add-int/2addr v14, v15

    if-ne v2, v14, :cond_63

    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v2, :cond_57

    iget-object v2, v2, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_57

    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    iget v14, v2, Lc/R5;->a:I

    if-gez v14, :cond_57

    iget-object v2, v2, Lc/R5;->e:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_63

    :cond_57
    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    invoke-virtual {v10, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    if-nez v2, :cond_5d

    iget-object v5, v0, Lc/T5;->D1:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_5d

    iget v5, v0, Lc/T5;->T:I

    if-nez v5, :cond_58

    invoke-static/range {p2 .. p2}, Lc/k6;->d0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_21

    :cond_58
    invoke-static {v5, v9, v10}, Lc/k6;->c0(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_21
    if-nez v5, :cond_5a

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    iget-object v1, v0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_59

    const-string v1, "\u042d\u0411\u0423 \u043d\u0435 \u043e\u0442\u0432\u0435\u0447\u0430\u0435\u0442 \u043d\u0430 OBD"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_59
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/T5;->H1:Z

    const-string v2, "\u05de\u05ea\u05d0\u05dd \u05de\u05d7\u05d5\u05d1\u05e8 \u00b7 \u05d1\u05d5\u05d3\u05e7 \u05d7\u05d9\u05d9\u05e9\u05e0\u05d9\u05dd..."

    iput-object v2, v0, Lc/T5;->C1:Ljava/lang/String;

    iput-boolean v1, v0, Lc/T5;->b1:Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_5a
    iput-object v5, v0, Lc/T5;->D1:Ljava/lang/String;

    iget v6, v0, Lc/T5;->T:I

    if-nez v6, :cond_5d

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v6, 0x8

    if-ne v5, v6, :cond_5b

    move v15, v13

    goto :goto_22

    :cond_5b
    const/4 v15, 0x6

    :goto_22
    iput v15, v0, Lc/T5;->T:I

    if-ne v15, v13, :cond_5c

    move-object v8, v11

    :cond_5c
    iput-object v8, v0, Lc/T5;->Q:Ljava/lang/String;

    :cond_5d
    iget-object v5, v0, Lc/T5;->D1:Ljava/lang/String;

    invoke-virtual {v0, v9, v10, v5}, Lc/T5;->d0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object v5

    iget-object v6, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v6, :cond_5e

    iget-object v6, v6, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5e

    iget-object v6, v0, Lc/T5;->a1:Lc/R5;

    iget-object v6, v6, Lc/R5;->e:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_23
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_5e

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/v5;

    :try_start_2
    iget-object v11, v0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v12, v8, Lc/v5;->a:Ljava/lang/String;

    new-instance v13, Lc/S5;

    invoke-virtual {v8, v5}, Lc/v5;->a([B)D

    move-result-wide v14

    iget v3, v8, Lc/v5;->c:I

    invoke-direct {v13, v14, v15, v3}, Lc/S5;-><init>(DI)V

    invoke-interface {v11, v12, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v4, 0x1

    goto :goto_24

    :catch_2
    iget-object v3, v0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v8, v8, Lc/v5;->a:Ljava/lang/String;

    invoke-interface {v3, v8}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_24
    const/16 v3, 0x10

    goto :goto_23

    :cond_5e
    rem-int/lit8 v3, v2, 0x20

    if-nez v3, :cond_61

    if-nez v5, :cond_5f

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u0442\u044c \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u043a\u0443 \u0434\u0430\u0442\u0447\u0438\u043a\u043e\u0432"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_5f
    :try_start_3
    iget-object v3, v0, Lc/T5;->d:Ljava/util/HashSet;

    invoke-static {v3, v2, v5}, Lc/k6;->b(Ljava/util/HashSet;I[B)V

    const/4 v3, 0x1

    iput-boolean v3, v0, Lc/T5;->b1:Z
    :try_end_3
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_3

    const/16 v3, 0xe0

    if-ge v2, v3, :cond_60

    iget-object v3, v0, Lc/T5;->d:Ljava/util/HashSet;

    const/16 v4, 0x20

    add-int/2addr v2, v4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_60

    iget-object v3, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v2}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_25

    :cond_60
    const/4 v2, 0x1

    iput-boolean v2, v0, Lc/T5;->H1:Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Y()V

    :goto_25
    const/4 v4, 0x1

    goto :goto_26

    :catch_3
    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v1, "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u042d\u0411\u0423"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_61
    if-eqz v5, :cond_62

    :try_start_4
    iget-object v3, v0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    new-instance v8, Lc/S5;

    invoke-virtual {v0, v5, v2}, Lc/T5;->I0([BI)D

    move-result-wide v11

    invoke-direct {v8, v11, v12}, Lc/S5;-><init>(D)V

    invoke-virtual {v3, v6, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_4

    goto :goto_25

    :catch_4
    iget-object v3, v0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_26

    :cond_62
    iget-object v3, v0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_26
    move-object/from16 v5, v20

    move-object/from16 v2, v24

    goto/16 :goto_33

    :cond_63
    invoke-virtual {v10, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_64

    :try_start_5
    iget-object v2, v0, Lc/T5;->e:Ljava/util/HashMap;

    const/16 v3, 0x42

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    new-instance v5, Lc/S5;

    invoke-static/range {p2 .. p2}, Lc/T5;->d(Ljava/lang/String;)D

    move-result-wide v11

    invoke-direct {v5, v11, v12}, Lc/S5;-><init>(D)V

    invoke-virtual {v2, v3, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_5
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_5} :catch_5

    move-object/from16 v5, v20

    move-object/from16 v2, v24

    const/4 v4, 0x1

    goto/16 :goto_33

    :catch_5
    iget-object v2, v0, Lc/T5;->e:Ljava/util/HashMap;

    const/16 v3, 0x42

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    goto :goto_26

    :cond_64
    move-object/from16 v2, v24

    invoke-virtual {v10, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_66

    const-string v3, "ST"

    invoke-virtual {v10, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_66

    const-string v3, "VT"

    invoke-virtual {v10, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_65

    goto :goto_27

    :cond_65
    move-object/from16 v3, v21

    goto :goto_28

    :cond_66
    :goto_27
    invoke-virtual {v9, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_67

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v5, v22

    invoke-virtual {v3, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_65

    :cond_67
    move-object/from16 v3, v21

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_68

    iget-object v5, v0, Lc/T5;->e0:Ljava/lang/String;

    if-nez v5, :cond_69

    :cond_68
    move-object/from16 v5, v20

    goto/16 :goto_32

    :cond_69
    :goto_28
    invoke-virtual {v10, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6a

    const/4 v5, 0x4

    invoke-virtual {v10, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->P:Ljava/lang/String;

    :goto_29
    move-object/from16 v5, v20

    goto/16 :goto_33

    :cond_6a
    const-string v5, "ATD"

    invoke-virtual {v10, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_6b

    const-string v5, "ATZ"

    invoke-virtual {v10, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6c

    :cond_6b
    move-object/from16 v5, v20

    const/4 v8, 0x0

    goto/16 :goto_31

    :cond_6c
    const-string v5, "ATCRA"

    invoke-virtual {v10, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6d

    const/4 v3, 0x5

    invoke-virtual {v10, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->R:Ljava/lang/String;

    goto :goto_29

    :cond_6d
    const-string v5, "ATCM"

    invoke-virtual {v10, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_6e

    const/4 v5, 0x4

    invoke-virtual {v10, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-object/from16 v5, v20

    iput-object v5, v0, Lc/T5;->R:Ljava/lang/String;

    goto/16 :goto_33

    :cond_6e
    move-object/from16 v5, v20

    const-string v6, "ATCF(?:[0-9A-F]{3}|[0-9A-F]{8})"

    invoke-virtual {v10, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_6f

    iput-object v5, v0, Lc/T5;->R:Ljava/lang/String;

    goto/16 :goto_33

    :cond_6f
    const-string v6, "ATAR"

    invoke-virtual {v10, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_70

    iput-object v5, v0, Lc/T5;->R:Ljava/lang/String;

    goto/16 :goto_33

    :cond_70
    move-object/from16 v6, v26

    invoke-virtual {v10, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_71

    const/4 v6, 0x4

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->S:Ljava/lang/String;

    goto/16 :goto_33

    :cond_71
    const/4 v6, 0x4

    const-string v12, "ATPB"

    invoke-virtual {v10, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_73

    const/4 v12, 0x6

    invoke-virtual {v10, v6, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/16 v6, 0x10

    invoke-static {v3, v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    and-int/lit16 v3, v3, 0x80

    if-nez v3, :cond_72

    move v15, v13

    goto :goto_2a

    :cond_72
    const/4 v15, 0x6

    :goto_2a
    iput v15, v0, Lc/T5;->W:I

    goto/16 :goto_33

    :cond_73
    move-object/from16 v6, v25

    invoke-virtual {v10, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_77

    move-object/from16 v12, v18

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_77

    const/4 v12, 0x4

    invoke-virtual {v10, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const-string v8, "A"

    invoke-virtual {v3, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_74

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v11, 0x1

    if-le v8, v11, :cond_74

    invoke-virtual {v3, v11}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    :cond_74
    :try_start_6
    const-string v8, "B"

    invoke-virtual {v3, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_75

    iget v8, v0, Lc/T5;->W:I

    goto :goto_2b

    :cond_75
    const/16 v8, 0x10

    invoke-static {v3, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v11

    move v8, v11

    :goto_2b
    iput v8, v0, Lc/T5;->T:I

    iget-boolean v8, v0, Lc/T5;->n0:Z

    if-eqz v8, :cond_76

    iput-object v5, v0, Lc/T5;->R:Ljava/lang/String;

    :cond_76
    iget-object v8, v0, Lc/T5;->q0:Lc/n6;

    if-eqz v8, :cond_89

    iget-boolean v8, v8, Lc/n6;->h:Z

    if-nez v8, :cond_89

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v0, Lc/T5;->X:Ljava/lang/String;
    :try_end_6
    .catch Ljava/lang/NumberFormatException; {:try_start_6 .. :try_end_6} :catch_6

    goto/16 :goto_33

    :cond_77
    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_86

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v12}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12, v3, v5}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v3

    const-string v12, "[\\r\\n >]"

    invoke-virtual {v3, v12, v5}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v12, "A?[1-9AB]"

    invoke-virtual {v3, v12}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_79

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v12

    const/4 v14, 0x1

    sub-int/2addr v12, v14

    invoke-virtual {v3, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v12

    const-string v14, "B"

    invoke-virtual {v12, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_78

    iget v14, v0, Lc/T5;->W:I

    goto :goto_2c

    :cond_78
    const/16 v14, 0x10

    invoke-static {v12, v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v15

    move v14, v15

    :goto_2c
    invoke-virtual {v6, v12}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_2d

    :cond_79
    iget-object v6, v0, Lc/T5;->e0:Ljava/lang/String;

    if-eqz v6, :cond_7a

    iget-object v12, v0, Lc/T5;->f0:Ljava/lang/String;

    invoke-static {v12, v6}, Lc/k6;->d(Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    invoke-static {v6}, Lc/G8;->h0(I)Ljava/lang/String;

    move-result-object v12

    move v14, v6

    move-object v6, v12

    goto :goto_2d

    :cond_7a
    move-object v6, v5

    const/4 v14, 0x0

    :goto_2d
    if-eqz v14, :cond_81

    iput v14, v0, Lc/T5;->T:I

    iget-object v12, v0, Lc/T5;->z1:Lc/r5;

    const-string v15, "A?[1-9AB]"

    invoke-virtual {v3, v15}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v15

    if-eqz v15, :cond_7b

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v14

    const/4 v15, 0x1

    sub-int/2addr v14, v15

    invoke-virtual {v3, v14}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const/16 v14, 0x10

    invoke-static {v3, v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    move v14, v3

    :cond_7b
    invoke-virtual {v12, v14}, Lc/r5;->a(I)V

    iget-boolean v3, v0, Lc/T5;->F1:Z

    if-eqz v3, :cond_7c

    iget v3, v0, Lc/T5;->U:I

    if-eqz v3, :cond_7c

    iget-object v3, v0, Lc/T5;->X:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_80

    :cond_7c
    iget v3, v0, Lc/T5;->T:I

    iput v3, v0, Lc/T5;->U:I

    iput-object v6, v0, Lc/T5;->X:Ljava/lang/String;

    if-eq v3, v13, :cond_7e

    const/16 v6, 0x9

    if-ne v3, v6, :cond_7d

    goto :goto_2e

    :cond_7d
    if-lez v3, :cond_7f

    const/4 v6, 0x6

    if-ge v3, v6, :cond_7f

    invoke-static {v3}, Lc/G8;->i0(I)Ljava/lang/String;

    move-result-object v8

    goto :goto_2f

    :cond_7e
    :goto_2e
    move-object v8, v11

    :cond_7f
    :goto_2f
    iput-object v8, v0, Lc/T5;->Q:Ljava/lang/String;

    :cond_80
    iput-object v5, v0, Lc/T5;->P:Ljava/lang/String;

    :cond_81
    iget-object v3, v0, Lc/T5;->e0:Ljava/lang/String;

    if-eqz v3, :cond_89

    iget-object v1, v0, Lc/T5;->f0:Ljava/lang/String;

    iget-boolean v2, v0, Lc/T5;->k0:Z

    const/4 v4, 0x0

    iput-object v4, v0, Lc/T5;->e0:Ljava/lang/String;

    iput-object v4, v0, Lc/T5;->f0:Ljava/lang/String;

    const/4 v5, 0x0

    iput-boolean v5, v0, Lc/T5;->h0:Z

    iget v5, v0, Lc/T5;->T:I

    if-nez v5, :cond_85

    invoke-virtual {v0, v1, v3, v2}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    iput-object v4, v0, Lc/T5;->g0:Ljava/lang/String;

    iget-object v1, v0, Lc/T5;->j0:Lc/b6;

    iput-object v1, v0, Lc/T5;->P0:Lc/b6;

    iput-object v4, v0, Lc/T5;->j0:Lc/b6;

    if-eqz v1, :cond_83

    iget-boolean v1, v1, Lc/b6;->d:Z

    if-eqz v1, :cond_83

    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lc/c6;->b(Z)V

    iput-object v4, v0, Lc/T5;->P0:Lc/b6;

    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    iget-boolean v1, v1, Lc/c6;->i:Z

    if-eqz v1, :cond_82

    invoke-virtual {v0, v2}, Lc/T5;->L(Z)V

    goto :goto_30

    :cond_82
    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_30

    :cond_83
    iget-object v1, v0, Lc/T5;->q0:Lc/n6;

    if-eqz v1, :cond_84

    iget-boolean v1, v1, Lc/n6;->h:Z

    if-nez v1, :cond_84

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/T5;->L(Z)V

    goto :goto_30

    :cond_84
    const-string v1, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u043b \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u042d\u0411\u0423"

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    :goto_30
    return-void

    :cond_85
    iget-object v4, v0, Lc/T5;->g0:Ljava/lang/String;

    iput-object v4, v0, Lc/T5;->P:Ljava/lang/String;

    const/4 v4, 0x0

    iput-object v4, v0, Lc/T5;->g0:Ljava/lang/String;

    iget-object v5, v0, Lc/T5;->j0:Lc/b6;

    iput-object v5, v0, Lc/T5;->P0:Lc/b6;

    iput-object v4, v0, Lc/T5;->j0:Lc/b6;

    const/4 v4, 0x1

    iput-boolean v4, v0, Lc/T5;->p0:Z

    iput-object v1, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v2, v3}, Lc/T5;->M(ZLjava/lang/String;)V

    const/4 v3, 0x0

    iput-boolean v3, v0, Lc/T5;->p0:Z

    return-void

    :cond_86
    const/4 v3, 0x0

    iget-object v6, v0, Lc/T5;->Y:Ljava/lang/String;

    invoke-virtual {v10, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_89

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v3}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_89

    invoke-virtual {v0, v9, v10}, Lc/T5;->F0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_87

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    const-string v1, "\u042d\u0411\u0423 \u043e\u0442\u043a\u043b\u043e\u043d\u0438\u043b \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0443 \u043f\u0440\u043e\u0444\u0438\u043b\u044f "

    invoke-virtual {v1, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->I(Ljava/lang/String;)V

    return-void

    :cond_87
    iput-object v3, v0, Lc/T5;->D1:Ljava/lang/String;

    iget-object v3, v0, Lc/T5;->g:Lc/j6;

    if-eqz v3, :cond_88

    iget-boolean v3, v3, Lc/j6;->g:Z

    if-nez v3, :cond_88

    const/4 v3, 0x1

    iput-boolean v3, v0, Lc/T5;->H1:Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Y()V

    goto :goto_33

    :cond_88
    iget-object v3, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    invoke-static {v6, v8}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_33

    :goto_31
    iput-object v5, v0, Lc/T5;->P:Ljava/lang/String;

    iput-object v5, v0, Lc/T5;->R:Ljava/lang/String;

    const-string v3, "18"

    iput-object v3, v0, Lc/T5;->S:Ljava/lang/String;

    iput v8, v0, Lc/T5;->T:I

    iget-object v3, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v3}, Ljava/util/HashMap;->clear()V

    goto :goto_33

    :goto_32
    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :catch_6
    :cond_89
    :goto_33
    invoke-static {v10}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v6, v17

    invoke-virtual {v3, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_8b

    if-nez v23, :cond_8b

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v8, v0, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget v7, v0, Lc/T5;->T:I

    invoke-static {v7, v9, v10}, Lc/k6;->h0(ILjava/lang/String;Ljava/lang/String;)I

    move-result v7

    if-eqz v4, :cond_8a

    if-nez v1, :cond_8a

    if-lez v7, :cond_8a

    const/16 v8, 0x10

    if-ge v7, v8, :cond_8a

    iget-object v8, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v8, v3, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_34

    :cond_8a
    iget-object v7, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v7, v3}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8b
    :goto_34
    if-nez v23, :cond_8e

    invoke-static {v10}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3, v6}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8c

    iget-object v3, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v3, :cond_8e

    iget-object v3, v3, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8e

    :cond_8c
    if-eqz v1, :cond_8d

    invoke-virtual/range {p2 .. p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_8d

    iget v3, v0, Lc/T5;->u1:I

    const/4 v6, 0x1

    add-int/2addr v3, v6

    goto :goto_35

    :cond_8d
    iget v3, v0, Lc/T5;->u1:I

    iget v6, v0, Lc/T5;->T:I

    invoke-static {v3, v6, v9}, Lc/k6;->T(IILjava/lang/String;)I

    move-result v3

    :goto_35
    iput v3, v0, Lc/T5;->u1:I

    const/16 v6, 0x28

    if-le v3, v6, :cond_8e

    invoke-virtual/range {p0 .. p0}, Lc/T5;->m0()V

    return-void

    :cond_8e
    if-eqz v23, :cond_8f

    invoke-virtual/range {p0 .. p0}, Lc/T5;->u()V

    :cond_8f
    const-string v3, "STI"

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_95

    const-string v3, "VTI"

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_90

    goto/16 :goto_37

    :cond_90
    iget-object v3, v0, Lc/T5;->P0:Lc/b6;

    if-eqz v3, :cond_92

    iget-object v3, v0, Lc/T5;->O0:Lc/c6;

    invoke-virtual {v3, v9}, Lc/c6;->a(Ljava/lang/String;)V

    const/4 v3, 0x0

    iput-object v3, v0, Lc/T5;->P0:Lc/b6;

    const-string v3, "ATZ"

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_91

    const/4 v3, 0x0

    iput v3, v0, Lc/T5;->m0:I

    goto :goto_36

    :cond_91
    const/4 v3, 0x0

    :goto_36
    iget-object v5, v0, Lc/T5;->O0:Lc/c6;

    iget-boolean v5, v5, Lc/c6;->i:Z

    if-eqz v5, :cond_92

    invoke-virtual {v0, v10, v9, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {v0, v3}, Lc/T5;->L(Z)V

    return-void

    :cond_92
    if-eqz v4, :cond_93

    invoke-virtual {v10, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_93

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, v0, Lc/T5;->E:J

    :cond_93
    invoke-virtual/range {p0 .. p0}, Lc/T5;->T0()V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->x0()V

    if-nez v23, :cond_94

    iget-boolean v1, v0, Lc/T5;->d1:Z

    if-nez v1, :cond_94

    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v1, :cond_94

    iget-object v1, v1, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v10, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_94

    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_94

    iget-object v1, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_94

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_94

    iget-boolean v1, v1, Lc/j6;->i:Z

    if-eqz v1, :cond_94

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/T5;->i0(Z)Z

    :cond_94
    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_95
    :goto_37
    iget-object v1, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "name"

    invoke-interface {v1, v2, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "STI"

    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_98

    invoke-static {v1}, Lc/n6;->f(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_97

    invoke-static/range {p2 .. p2}, Lc/n6;->g(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_96

    goto :goto_38

    :cond_96
    const/4 v10, 0x0

    goto :goto_39

    :cond_97
    :goto_38
    const/4 v10, 0x1

    :goto_39
    iput-boolean v10, v0, Lc/T5;->n0:Z

    goto :goto_3c

    :cond_98
    invoke-static {v1}, Lc/n6;->h(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_9a

    invoke-static/range {p2 .. p2}, Lc/n6;->i(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_99

    goto :goto_3a

    :cond_99
    const/4 v10, 0x0

    goto :goto_3b

    :cond_9a
    :goto_3a
    const/4 v10, 0x1

    :goto_3b
    iput-boolean v10, v0, Lc/T5;->o0:Z

    :goto_3c
    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :goto_3d
    iput-object v2, v0, Lc/T5;->a2:Ljava/lang/String;

    const/4 v2, 0x0

    iput-boolean v2, v0, Lc/T5;->c1:Z

    iget-object v4, v0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v2, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, v0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v2, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, v0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v2, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, v0, Lc/T5;->F0:Lc/g6;

    if-eqz v2, :cond_9b

    iget-boolean v3, v0, Lc/T5;->L0:Z

    invoke-virtual {v2, v3, v9}, Lc/g6;->a(ZLjava/lang/String;)V

    iget-object v2, v0, Lc/T5;->F0:Lc/g6;

    invoke-virtual {v2}, Lc/g6;->e()Lc/f6;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->G0:Lc/f6;

    :goto_3e
    const/4 v2, 0x0

    goto :goto_3f

    :cond_9b
    iget-object v2, v0, Lc/T5;->I0:Lc/d6;

    iget-object v2, v2, Lc/d6;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    const-string v4, "STCSEGT1"

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_9c

    invoke-virtual {v9, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    iput-boolean v2, v0, Lc/T5;->M0:Z

    :cond_9c
    iget-object v2, v0, Lc/T5;->H0:Lc/e6;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4, v9}, Lc/e6;->a(JLjava/lang/String;)V

    iget-object v2, v0, Lc/T5;->H0:Lc/e6;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Lc/e6;->b(J)Lc/d6;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->I0:Lc/d6;

    goto :goto_3e

    :goto_3f
    iput-boolean v2, v0, Lc/T5;->L0:Z

    iget-object v2, v0, Lc/T5;->G0:Lc/f6;

    if-nez v2, :cond_a0

    iget-object v2, v0, Lc/T5;->I0:Lc/d6;

    if-eqz v2, :cond_9d

    goto :goto_41

    :cond_9d
    iget-object v2, v0, Lc/T5;->F0:Lc/g6;

    if-eqz v2, :cond_9e

    invoke-virtual {v2}, Lc/g6;->f()Ljava/lang/String;

    move-result-object v2

    goto :goto_40

    :cond_9e
    iget-object v2, v0, Lc/T5;->H0:Lc/e6;

    invoke-virtual {v2}, Lc/e6;->c()Ljava/lang/String;

    move-result-object v2

    :goto_40
    iget-object v3, v0, Lc/T5;->F0:Lc/g6;

    if-eqz v3, :cond_9f

    invoke-virtual {v3}, Lc/g6;->c()Z

    move-result v3

    if-eqz v3, :cond_9f

    iget-object v3, v0, Lc/T5;->N0:Ljava/util/HashSet;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->X()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    :cond_9f
    iget-object v3, v0, Lc/T5;->J0:Ljava/lang/String;

    const/4 v4, 0x0

    iput-object v4, v0, Lc/T5;->F0:Lc/g6;

    iput-object v4, v0, Lc/T5;->H0:Lc/e6;

    iput-object v4, v0, Lc/T5;->J0:Ljava/lang/String;

    const/4 v4, 0x1

    iput-boolean v4, v0, Lc/T5;->K0:Z

    iput-object v3, v0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lc/T5;->M(ZLjava/lang/String;)V

    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/T5;->K0:Z

    return-void

    :cond_a0
    :goto_41
    invoke-virtual/range {p0 .. p0}, Lc/T5;->B0()V

    return-void
.end method

.method public final M0()V
    .locals 15

    iget-boolean v0, p0, Lc/T5;->b1:Z

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Lc/T5;->Y0:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->addAll(Ljava/util/Collection;)Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v1

    const/16 v2, 0xc

    const/4 v3, 0x3

    const/16 v4, 0xd

    if-eq v1, v3, :cond_2

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v1

    const/4 v5, 0x2

    if-ne v1, v5, :cond_3

    :cond_2
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v1, -0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v1, :cond_5

    const/4 v1, -0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5

    const/4 v1, -0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_1

    :cond_4
    move v1, v6

    goto :goto_2

    :cond_5
    :goto_1
    move v1, v5

    :goto_2
    if-eqz v1, :cond_6

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v7, 0x5e

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v7, 0x10

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v7, 0xb

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0xf

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x45

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x11

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x43

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x33

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x46

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/16 v2, 0x51

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    invoke-virtual {p0}, Lc/T5;->g()I

    move-result v2

    if-ltz v2, :cond_6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    :cond_6
    iget-object v2, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v3, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v3}, Ljava/util/Set;->clear()V

    iget-object v3, p0, Lc/T5;->o:Ljava/util/HashSet;

    invoke-virtual {v3}, Ljava/util/HashSet;->clear()V

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_7
    :goto_3
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    iget-object v8, p0, Lc/T5;->d:Ljava/util/HashSet;

    iget-object v9, p0, Lc/T5;->s:Ljava/util/ArrayList;

    const/4 v10, 0x0

    const-string v11, ""

    if-eqz v7, :cond_11

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v12

    const/4 v13, -0x4

    if-eq v12, v13, :cond_d

    const/4 v14, -0x5

    if-ne v12, v14, :cond_8

    goto :goto_6

    :cond_8
    if-gez v12, :cond_9

    goto :goto_3

    :cond_9
    invoke-virtual {v8, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_b

    new-instance v7, Lc/R5;

    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v12}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x5

    if-ne v12, v9, :cond_a

    move v9, v5

    goto :goto_4

    :cond_a
    move v9, v6

    :goto_4
    invoke-direct {v7, v12, v8, v11, v9}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v7, v10}, Lc/T5;->e(Lc/R5;Lc/i6;)V

    goto :goto_3

    :cond_b
    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/i6;

    invoke-static {v12}, Lc/T5;->w0(I)I

    move-result v9

    iget v10, v8, Lc/i6;->j:I

    if-eq v9, v10, :cond_c

    goto :goto_5

    :cond_c
    new-instance v9, Ljava/util/HashSet;

    invoke-direct {v9}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v8, v9}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_5

    :cond_d
    :goto_6
    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_e
    :goto_7
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_7

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lc/i6;

    if-ne v12, v13, :cond_f

    iget-boolean v9, v8, Lc/i6;->w:Z

    if-eqz v9, :cond_e

    goto :goto_8

    :cond_f
    iget-boolean v9, v8, Lc/i6;->x:Z

    if-nez v9, :cond_10

    goto :goto_7

    :cond_10
    :goto_8
    new-instance v9, Ljava/util/HashSet;

    invoke-direct {v9}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v8, v9}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_7

    :cond_11
    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    if-eqz v3, :cond_15

    iget-object v3, p0, Lc/T5;->X0:Ljava/util/LinkedHashMap;

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_12
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_15

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/Set;

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :cond_13
    :goto_9
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_12

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v13, p0, Lc/T5;->g:Lc/j6;

    iget-object v13, v13, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, ":"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v7, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v13

    if-nez v13, :cond_14

    goto :goto_9

    :cond_14
    iget-object v13, p0, Lc/T5;->g:Lc/j6;

    iget-object v13, v13, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    invoke-virtual {v7, v12}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v13, v7}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/i6;

    if-eqz v7, :cond_13

    new-instance v12, Ljava/util/HashSet;

    invoke-direct {v12}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v7, v12}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_9

    :cond_15
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v3

    if-eqz v3, :cond_16

    invoke-virtual {p0}, Lc/T5;->h()Lc/i6;

    move-result-object v3

    if-eqz v3, :cond_16

    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v3, v5}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    :cond_16
    if-eqz v1, :cond_18

    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_18

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i6;

    iget v5, v3, Lc/i6;->j:I

    const/4 v7, 0x6

    if-eq v5, v7, :cond_17

    if-eq v5, v4, :cond_17

    const/16 v7, 0x15

    if-eq v5, v7, :cond_17

    goto :goto_a

    :cond_17
    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p0, v3, v5}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_a

    :cond_18
    const/16 v1, 0x42

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/AbstractCollection;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v8, v0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_19

    new-instance v0, Lc/R5;

    const-string v3, "ATRV"

    invoke-direct {v0, v1, v3, v11, v6}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v0, v10}, Lc/T5;->e(Lc/R5;Lc/i6;)V

    :cond_19
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/R5;

    iget v2, v2, Lc/R5;->i:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_b

    :cond_1a
    iget-object v1, p0, Lc/T5;->V0:Lc/v8;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iget-object v1, v1, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/h6;

    iget-object v5, v4, Lc/h6;->a:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    if-nez v5, :cond_1b

    invoke-interface {v3}, Ljava/util/Iterator;->remove()V

    goto :goto_c

    :cond_1b
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iput v5, v4, Lc/h6;->b:I

    iget-object v4, v4, Lc/h6;->a:Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_c

    :cond_1c
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1d
    :goto_d
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v2, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1d

    new-instance v4, Lc/h6;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-direct {v4, v5, v3}, Lc/h6;-><init>(Ljava/lang/String;I)V

    invoke-virtual {v1, v4}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_d

    :cond_1e
    iput-boolean v6, p0, Lc/T5;->b1:Z

    return-void
.end method

.method public final N(Ljava/lang/String;)V
    .locals 8

    iget-object v0, p0, Lc/T5;->q:Lc/b;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    if-nez v1, :cond_1

    const/4 v1, 0x0

    :goto_0
    move-object v7, v1

    goto :goto_1

    :cond_1
    iget-object v1, v1, Lc/j6;->v:Ljava/util/LinkedHashMap;

    iget-object v2, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    goto :goto_0

    :goto_1
    iget-object v1, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {p0, v1}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v6

    new-instance v1, Lc/Q5;

    iget-object v3, p0, Lc/T5;->l:Ljava/lang/String;

    iget-object v4, p0, Lc/T5;->m:Ljava/lang/String;

    move-object v2, v1

    move-object v5, p1

    invoke-direct/range {v2 .. v7}, Lc/Q5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lc/S5;Lc/i6;)V

    invoke-virtual {p0}, Lc/T5;->p()V

    invoke-virtual {v0, v1}, Lc/b;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public final N0(Lorg/json/JSONObject;Lc/b;)V
    .locals 6

    invoke-virtual {p0}, Lc/T5;->s0()V

    invoke-virtual {p0}, Lc/T5;->p()V

    iget-boolean v0, p0, Lc/T5;->F1:Z

    if-eqz v0, :cond_5

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-eqz v0, :cond_0

    goto/16 :goto_1

    :cond_0
    iget-object v0, p0, Lc/T5;->h:Lc/j6;

    new-instance v1, Lc/f7;

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, p1, v3}, Lc/f7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONObject;I)V

    invoke-static {v1}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/j6;

    const-string v1, "Id"

    const-string v2, ""

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_3

    iget-object v1, v0, Lc/j6;->y:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i6;

    iget-boolean v4, v3, Lc/i6;->z:Z

    if-eqz v4, :cond_1

    iget-object v4, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v3, Lc/i6;->a:Ljava/lang/String;

    if-eqz v4, :cond_2

    iget-object v4, v4, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-interface {v4, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    :cond_2
    move-object p1, v3

    goto :goto_0

    :cond_3
    iget-object v1, v0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    if-eqz v1, :cond_4

    iget-boolean v3, v1, Lc/i6;->v:Z

    if-eqz v3, :cond_4

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    iput-object v3, p0, Lc/T5;->p:Lc/j6;

    iput-object v0, p0, Lc/T5;->g:Lc/j6;

    iput-object p1, p0, Lc/T5;->k:Ljava/lang/String;

    iput-object v2, p0, Lc/T5;->l:Ljava/lang/String;

    iput-object v2, p0, Lc/T5;->m:Ljava/lang/String;

    iput-object p2, p0, Lc/T5;->q:Lc/b;

    :try_start_0
    invoke-virtual {p0}, Lc/T5;->A0()V

    iget-object p2, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-interface {p2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, Lc/T5;->R0:Ljava/util/HashMap;

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, Lc/T5;->S0:Ljava/util/HashMap;

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p0, Lc/T5;->T0:Ljava/util/HashMap;

    invoke-virtual {p2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0, v1}, Lc/T5;->v0(Lc/i6;)V

    invoke-virtual {p0, v1}, Lc/T5;->t(Lc/i6;)V

    iget-object p2, p0, Lc/T5;->j:Ljava/lang/Object;

    invoke-static {p1}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Lc/T5;->q0(Ljava/lang/Object;Ljava/util/Set;)V

    invoke-virtual {p0}, Lc/T5;->M0()V

    invoke-virtual {p0}, Lc/T5;->T0()V

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->r:Lc/A5;

    const-wide/32 v0, 0xafc8

    invoke-virtual {p1, p2, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {p0}, Lc/T5;->q()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    invoke-virtual {p0}, Lc/T5;->p()V

    throw p1

    :cond_4
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "PID \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d \u0434\u043b\u044f \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_5
    :goto_1
    new-instance p1, Lc/Q5;

    const-string v2, ""

    const-string v3, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0438\u0442\u0435\u0441\u044c \u043a \u0430\u0432\u0442\u043e\u043c\u043e\u0431\u0438\u043b\u044e"

    const-string v1, ""

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p1

    invoke-direct/range {v0 .. v5}, Lc/Q5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lc/S5;Lc/i6;)V

    invoke-virtual {p2, p1}, Lc/b;->accept(Ljava/lang/Object;)V

    return-void
.end method

.method public final O(I)Ljava/lang/Double;
    .locals 11

    iget-boolean v0, p0, Lc/T5;->F1:Z

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v2, p0, Lc/T5;->s:Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v4, -0x5

    const/4 v5, -0x4

    if-eq p1, v5, :cond_c

    if-ne p1, v4, :cond_1

    goto/16 :goto_2

    :cond_1
    iget-object v4, p0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/S5;

    if-eqz v4, :cond_2

    iget-wide v4, v4, Lc/S5;->a:D

    invoke-static {v4, v5}, Ljava/lang/Double;->isFinite(D)Z

    move-result v6

    if-eqz v6, :cond_2

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    return-object p1

    :cond_2
    const/4 v4, 0x4

    if-eq p1, v4, :cond_7

    const/4 v5, 0x5

    if-eq p1, v5, :cond_8

    const/16 v3, 0x2f

    if-eq p1, v3, :cond_6

    const/16 v3, 0x42

    if-eq p1, v3, :cond_5

    const/16 v3, 0x46

    if-eq p1, v3, :cond_4

    const/16 v3, 0x5e

    if-eq p1, v3, :cond_3

    packed-switch p1, :pswitch_data_0

    packed-switch p1, :pswitch_data_1

    return-object v1

    :pswitch_0
    const/16 v3, 0x8

    goto :goto_0

    :pswitch_1
    const/4 v3, 0x2

    goto :goto_0

    :pswitch_2
    move v3, v4

    goto :goto_0

    :pswitch_3
    move v3, v5

    goto :goto_0

    :pswitch_4
    const/4 v3, 0x1

    goto :goto_0

    :pswitch_5
    const/4 v3, 0x3

    goto :goto_0

    :cond_3
    const/16 v3, 0x10

    goto :goto_0

    :cond_4
    const/16 v3, 0xc

    goto :goto_0

    :cond_5
    const/16 v3, 0x273a

    goto :goto_0

    :cond_6
    const/16 v3, 0x12

    goto :goto_0

    :cond_7
    const/16 v3, 0x9

    :cond_8
    :goto_0
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_9
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_b

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    iget-object v4, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/S5;

    iget v5, v2, Lc/i6;->j:I

    if-ne v5, v3, :cond_9

    if-eqz v4, :cond_9

    iget-wide v6, v4, Lc/S5;->a:D

    invoke-static {v6, v7}, Ljava/lang/Double;->isFinite(D)Z

    move-result v8

    if-eqz v8, :cond_9

    invoke-virtual {v4, v2}, Lc/S5;->a(Lc/i6;)I

    move-result v2

    invoke-virtual {p0, v5, v2, v6, v7}, Lc/T5;->A(IID)Ljava/lang/Double;

    move-result-object v2

    if-nez v2, :cond_a

    goto :goto_1

    :cond_a
    return-object v2

    :cond_b
    return-object v1

    :cond_c
    :goto_2
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_d
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_13

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/i6;

    if-ne p1, v5, :cond_e

    iget-boolean v7, v6, Lc/i6;->w:Z

    if-eqz v7, :cond_d

    goto :goto_4

    :cond_e
    iget-boolean v7, v6, Lc/i6;->x:Z

    if-eqz v7, :cond_d

    :goto_4
    iget-object v7, v6, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v7}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/S5;

    if-eqz v7, :cond_d

    iget-wide v8, v7, Lc/S5;->a:D

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v10

    if-nez v10, :cond_f

    goto :goto_3

    :cond_f
    invoke-virtual {v7, v6}, Lc/S5;->a(Lc/i6;)I

    move-result v6

    if-ne p1, v4, :cond_11

    if-nez v6, :cond_10

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v6

    if-eqz v6, :cond_10

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    goto :goto_5

    :cond_10
    move-object v6, v1

    goto :goto_5

    :cond_11
    invoke-virtual {p0, v3, v6, v8, v9}, Lc/T5;->A(IID)Ljava/lang/Double;

    move-result-object v6

    :goto_5
    if-nez v6, :cond_12

    goto :goto_3

    :cond_12
    return-object v6

    :cond_13
    return-object v1

    nop

    :pswitch_data_0
    .packed-switch 0xb
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0xf
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final O0(Ljava/lang/String;)V
    .locals 25

    move-object/from16 v7, p0

    move-object/from16 v4, p1

    iget-boolean v0, v7, Lc/T5;->u:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-boolean v0, v7, Lc/T5;->w:Z

    const/4 v1, 0x2

    if-eqz v0, :cond_3

    iget-boolean v0, v7, Lc/T5;->A:Z

    if-eqz v0, :cond_1

    const-string v0, "ATPC"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_1
    invoke-virtual/range {p0 .. p0}, Lc/T5;->j()I

    move-result v0

    if-ne v0, v1, :cond_2

    iget-boolean v0, v7, Lc/T5;->z:Z

    if-eqz v0, :cond_2

    const-string v0, "ATRV"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    :cond_2
    return-void

    :cond_3
    const-string v0, "ATSPDEF"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-object v0, v7, Lc/T5;->X:Ljava/lang/String;

    :goto_0
    move-object v6, v0

    goto :goto_1

    :cond_4
    const-string v0, "ATSTDEF"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "ATST"

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->v()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_5
    move-object v6, v4

    :goto_1
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    const-string v0, "\u041d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u0432\u043e\u0441\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u044f"

    invoke-virtual {v7, v2, v0}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :cond_6
    iput-object v6, v7, Lc/T5;->a2:Ljava/lang/String;

    iget-object v0, v7, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v0, 0x1

    iput-boolean v0, v7, Lc/T5;->c1:Z

    iput-boolean v2, v7, Lc/T5;->v1:Z

    iget-object v3, v7, Lc/T5;->x1:Ljava/util/HashMap;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v8, v7, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "@"

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    iget-object v5, v7, Lc/T5;->F0:Lc/g6;

    const-string v8, "1"

    if-nez v5, :cond_9

    iget-object v5, v7, Lc/T5;->H0:Lc/e6;

    if-nez v5, :cond_9

    iget-boolean v5, v7, Lc/T5;->w1:Z

    if-eqz v5, :cond_7

    invoke-static {v6}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v9, "(?:03|07|0A)|(?:01|02|06|09|18|19|1A|21|22|23|2C|A8)(?:[0-9A-F]{2}){1,255}"

    invoke-virtual {v5, v9}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_7

    if-eqz v3, :cond_7

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v3, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :cond_7
    iget-object v3, v7, Lc/T5;->P0:Lc/b6;

    if-nez v3, :cond_9

    iget-boolean v3, v7, Lc/T5;->l0:Z

    if-nez v3, :cond_9

    iget-boolean v3, v7, Lc/T5;->w1:Z

    if-eqz v3, :cond_9

    const-string v3, "10[0-9A-F]{2}"

    invoke-virtual {v6, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_8

    const-string v3, "20"

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    :cond_8
    invoke-virtual {v6, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_2

    :cond_9
    move-object v3, v6

    :goto_2
    iget-object v5, v7, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v9, "long_responses_safe_mode"

    invoke-interface {v5, v9, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_c

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_c

    const-string v5, "AT"

    invoke-virtual {v3, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_c

    const-string v5, "ST"

    invoke-virtual {v3, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_c

    const-string v5, "VT"

    invoke-virtual {v3, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_a

    goto :goto_3

    :cond_a
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    rem-int/2addr v5, v1

    const-string v9, "F"

    if-nez v5, :cond_b

    invoke-virtual {v3, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_3

    :cond_b
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v10

    sub-int/2addr v10, v0

    invoke-virtual {v3, v2, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_c
    :goto_3
    iget-object v5, v7, Lc/T5;->z1:Lc/r5;

    iget-boolean v9, v7, Lc/T5;->n0:Z

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v10, " "

    const-string v11, ""

    invoke-virtual {v3, v10, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v10

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v10, v12}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v10

    const-string v12, "ATD"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    iget-object v13, v5, Lc/r5;->a:Ljava/lang/Object;

    check-cast v13, Ljava/util/HashMap;

    const-string v14, "CP"

    const-string v15, "FCSM"

    const-string v0, "0"

    const-string v2, "SP"

    if-nez v12, :cond_d

    const-string v12, "ATZ"

    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_e

    :cond_d
    move-object/from16 v16, v6

    goto/16 :goto_8

    :cond_e
    const-string v8, "ATSPA"

    invoke-virtual {v10, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_f

    invoke-virtual {v13, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v16, v6

    goto/16 :goto_a

    :cond_f
    const-string v8, "ATSP[0-9A-F]"

    invoke-virtual {v10, v8}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    iget-object v5, v5, Lc/r5;->b:Ljava/lang/Object;

    check-cast v5, Ljava/util/HashMap;

    const-string v12, "FCSH"

    const-string v1, "CF"

    const-string v4, "CM"

    const-string v7, "CRA"

    move-object/from16 v16, v6

    const/4 v6, 0x4

    if-eqz v8, :cond_12

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const/16 v8, 0x10

    invoke-static {v6, v8}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v6

    if-lez v6, :cond_10

    const/16 v8, 0xc

    if-gt v6, v8, :cond_10

    goto :goto_4

    :cond_10
    const/4 v6, 0x0

    :goto_4
    invoke-static {v6}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v13, v2, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz v9, :cond_25

    invoke-virtual {v5}, Ljava/util/HashMap;->clear()V

    filled-new-array {v12, v7, v4, v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_11

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v13, v2, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5

    :cond_11
    invoke-virtual {v13, v15, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_12
    const-string v0, "STP[0-9A-F]{2}"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_13

    const/4 v0, 0x3

    invoke-virtual {v10, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x10

    invoke-static {v0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_13
    const-string v0, "AT(?:CAF|CFC)[01]"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    if-eqz v0, :cond_14

    const/4 v0, 0x2

    invoke-virtual {v10, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v10, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v13, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_14
    const-string v0, "ATFCSM[012]"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x6

    if-eqz v0, :cond_15

    invoke-virtual {v10, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v15, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_15
    const-string v0, "ATFCSH"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_16

    invoke-virtual {v10, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v12, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_16
    const-string v0, "ATFCSD"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_17

    invoke-virtual {v10, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "FCSD"

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_17
    const-string v0, "ATCRA"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-virtual {v10, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    filled-new-array {v7, v4, v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_6
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_25

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v13, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :cond_18
    const-string v0, "ATCM"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v13, v7, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_19
    const-string v0, "ATCF(?:[0-9A-F]{3}|[0-9A-F]{8})"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v13, v7, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_1a
    const-string v0, "ATAR"

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1b

    filled-new-array {v7, v4, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_25

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v13, v1, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_7

    :cond_1b
    const-string v0, "ATCEA"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const-string v1, "CEA"

    if-eqz v0, :cond_1c

    invoke-virtual {v10, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_1c
    const-string v0, "STCAF1,"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x7

    if-eqz v0, :cond_1d

    invoke-virtual {v10, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_1d
    const-string v0, "STCAF0"

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    invoke-virtual {v13, v1, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_1e
    const-string v0, "ATCP"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1f

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v14, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_1f
    const-string v0, "ATSH"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, "SH"

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_20
    const-string v0, "ATTA[0-9A-F]{2}"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const-string v1, "TA"

    if-eqz v0, :cond_21

    invoke-virtual {v10, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_21
    const-string v0, "ATCER[0-9A-F]{2}"

    invoke-virtual {v10, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-virtual {v10, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_a

    :cond_22
    const-string v0, "STCFCPA"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_23

    const-string v0, "VTFCTRA"

    invoke-virtual {v10, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25

    :cond_23
    invoke-virtual {v10, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const-string v1, ","

    const/4 v2, -0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v0

    array-length v1, v0

    const/4 v2, 0x2

    if-ne v1, v2, :cond_25

    const/4 v1, 0x0

    aget-object v2, v0, v1

    const/4 v1, 0x1

    aget-object v0, v0, v1

    invoke-virtual {v5, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_a

    :goto_8
    iget-object v1, v5, Lc/r5;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    iget-object v1, v5, Lc/r5;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    const-string v1, "CAF"

    invoke-virtual {v13, v1, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "CFC"

    invoke-virtual {v13, v1, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v13, v15, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v21, "CF"

    const-string v22, "CEA"

    const-string v17, "FCSH"

    const-string v18, "FCSD"

    const-string v19, "CRA"

    const-string v20, "CM"

    const-string v23, "TA"

    const-string v24, "SH"

    filled-new-array/range {v17 .. v24}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_9
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_24

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v13, v4, v11}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_9

    :cond_24
    const-string v1, "18"

    invoke-virtual {v13, v14, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v13, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_25
    :goto_a
    const-string v0, "\r"

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v1, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    const-string v0, "TX "

    move-object/from16 v6, v16

    invoke-virtual {v0, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "DriveDeckOBD"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-object/from16 v7, p0

    iget-object v0, v7, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, v7, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v2

    const/16 v3, 0x11

    if-le v2, v3, :cond_26

    const/16 v2, 0x3a98

    goto :goto_b

    :cond_26
    const/16 v2, 0x1388

    :goto_b
    int-to-long v2, v2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v3, v7, Lc/T5;->K:Ljava/io/OutputStream;

    if-eqz v3, :cond_27

    iget v2, v7, Lc/T5;->t:I

    iget-object v8, v7, Lc/T5;->O:Ljava/util/concurrent/ExecutorService;

    new-instance v9, Lc/c5;

    move-object v0, v9

    move-object/from16 v1, p0

    move-object/from16 v4, p1

    invoke-direct/range {v0 .. v6}, Lc/c5;-><init>(Lc/T5;ILjava/io/OutputStream;Ljava/lang/String;[BLjava/lang/String;)V

    invoke-interface {v8, v9}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_c

    :cond_27
    iget-object v0, v7, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-eqz v0, :cond_28

    iget-object v0, v7, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-nez v0, :cond_29

    :cond_28
    const/4 v0, 0x0

    goto :goto_d

    :cond_29
    invoke-static {v5}, Lc/t5;->a([B)[[B

    move-result-object v0

    iput-object v0, v7, Lc/T5;->S1:[[B

    const/4 v0, 0x0

    iput v0, v7, Lc/T5;->Q1:I

    invoke-virtual/range {p0 .. p0}, Lc/T5;->g1()V

    :goto_c
    return-void

    :goto_d
    const-string v1, "\u041d\u0435\u0442 \u043a\u0430\u043d\u0430\u043b\u0430 BLE"

    invoke-virtual {v7, v0, v1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void
.end method

.method public final P(Ljava/lang/String;)Lc/S5;
    .locals 4

    iget-boolean v0, p0, Lc/T5;->F1:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/S5;

    if-eqz p1, :cond_1

    iget-wide v2, p1, Lc/S5;->a:D

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v0

    if-eqz v0, :cond_1

    move-object v1, p1

    :cond_1
    :goto_0
    return-object v1
.end method

.method public final P0()Ljava/lang/String;
    .locals 3

    const-string v0, "transport"

    const-string v1, "spp"

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v2, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final Q(Ljava/lang/String;D)D
    .locals 4

    :try_start_0
    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->isFinite(D)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p1, :cond_0

    const-wide/16 v2, 0x0

    cmpl-double p1, v0, v2

    if-lez p1, :cond_0

    move-wide p2, v0

    :catch_0
    :cond_0
    return-wide p2
.end method

.method public final Q0(Ljava/lang/String;)V
    .locals 3

    iget-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-object v2, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v0, v2, v1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_0
    iget-boolean v0, p0, Lc/T5;->d1:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->n1:Z

    if-eqz v0, :cond_2

    iget v0, p0, Lc/T5;->p1:I

    add-int/2addr v0, v1

    iput v0, p0, Lc/T5;->p1:I

    const/4 v2, 0x3

    if-gt v0, v2, :cond_1

    move v0, v1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    iput-boolean v0, p0, Lc/T5;->o1:Z

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->e1:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lc/T5;->a1:Lc/R5;

    if-eqz v0, :cond_2

    iget-object v2, p0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v2, v0}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    :cond_2
    invoke-virtual {p0, v1, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void
.end method

.method public final R()Lc/W5;
    .locals 16

    move-object/from16 v0, p0

    const/16 v1, 0x8

    const/4 v2, 0x1

    new-instance v3, Lc/W5;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    iput v4, v3, Lc/W5;->a:I

    iput v4, v3, Lc/W5;->b:I

    const/4 v5, 0x4

    iput v5, v3, Lc/W5;->c:I

    const-wide v6, 0x3ff999999999999aL    # 1.6

    iput-wide v6, v3, Lc/W5;->d:D

    const-wide v6, 0x406f400000000000L    # 250.0

    iput-wide v6, v3, Lc/W5;->e:D

    const-wide/high16 v8, 0x3ff0000000000000L    # 1.0

    iput-wide v8, v3, Lc/W5;->f:D

    const-wide v10, 0x402d666666666666L    # 14.7

    iput-wide v10, v3, Lc/W5;->g:D

    const-wide v12, 0x3fe75c28f5c28f5cL    # 0.73

    iput-wide v12, v3, Lc/W5;->h:D

    iput-boolean v4, v3, Lc/W5;->i:Z

    iput-boolean v2, v3, Lc/W5;->j:Z

    iput-boolean v2, v3, Lc/W5;->k:Z

    iput-boolean v2, v3, Lc/W5;->l:Z

    iput-boolean v4, v3, Lc/W5;->m:Z

    new-array v14, v1, [I

    fill-array-data v14, :array_0

    iput-object v14, v3, Lc/W5;->n:[I

    const-string v14, "engine_litres"

    const v15, 0x3fcccccd    # 1.6f

    iget-object v1, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1, v14, v15}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v14

    float-to-double v14, v14

    iput-wide v14, v3, Lc/W5;->d:D

    const-string v14, "fuel_type"

    invoke-interface {v1, v14, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v14

    iput v14, v3, Lc/W5;->b:I

    const-string v14, "fuel_scheme"

    invoke-interface {v1, v14, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v14

    iput v14, v3, Lc/W5;->a:I

    const-string v14, "engine_cylinders"

    invoke-interface {v1, v14, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v14

    iput v14, v3, Lc/W5;->c:I

    if-gtz v14, :cond_0

    iput v5, v3, Lc/W5;->c:I

    :cond_0
    const-string v5, "injector_flow"

    invoke-virtual {v0, v5, v6, v7}, Lc/T5;->Q(Ljava/lang/String;D)D

    move-result-wide v5

    iput-wide v5, v3, Lc/W5;->e:D

    const-string v5, "fuel_correction"

    invoke-virtual {v0, v5, v8, v9}, Lc/T5;->Q(Ljava/lang/String;D)D

    move-result-wide v5

    iput-wide v5, v3, Lc/W5;->f:D

    const-string v5, "fuel_custom_af"

    invoke-virtual {v0, v5, v10, v11}, Lc/T5;->Q(Ljava/lang/String;D)D

    move-result-wide v5

    iput-wide v5, v3, Lc/W5;->g:D

    const-string v5, "fuel_custom_density"

    invoke-virtual {v0, v5, v12, v13}, Lc/T5;->Q(Ljava/lang/String;D)D

    move-result-wide v5

    iput-wide v5, v3, Lc/W5;->h:D

    const-string v5, "fuel_fixed_afr"

    invoke-interface {v1, v5, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    iput-boolean v5, v3, Lc/W5;->i:Z

    const-string v5, "fuel_detect_zero"

    invoke-interface {v1, v5, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    iput-boolean v5, v3, Lc/W5;->j:Z

    const-string v5, "fuel_filter_afr"

    invoke-interface {v1, v5, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    iput-boolean v5, v3, Lc/W5;->k:Z

    const-string v5, "fuel_af_stoichiometric"

    invoke-interface {v1, v5, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    iput-boolean v5, v3, Lc/W5;->l:Z

    const-string v5, "fuel_filter_rpm"

    invoke-interface {v1, v5, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    iput-boolean v5, v3, Lc/W5;->m:Z

    const/16 v5, 0x8

    :goto_0
    if-ge v4, v5, :cond_1

    iget-object v6, v3, Lc/W5;->n:[I

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "fuel_ve_"

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    add-int/lit8 v8, v4, 0x1

    mul-int/lit16 v9, v8, 0x3e8

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    iget-object v9, v3, Lc/W5;->n:[I

    aget v9, v9, v4

    invoke-interface {v1, v7, v9}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v7

    aput v7, v6, v4

    move v4, v8

    goto :goto_0

    :cond_1
    return-object v3

    :array_0
    .array-data 4
        0x46
        0x4b
        0x50
        0x55
        0x55
        0x55
        0x50
        0x4b
    .end array-data
.end method

.method public final R0()Ljava/lang/Double;
    .locals 6

    iget-boolean v0, p0, Lc/T5;->m2:Z

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lc/T5;->n2:Z

    if-eqz v0, :cond_0

    iget-wide v0, p0, Lc/T5;->k2:D

    const-wide/16 v2, 0x0

    cmpl-double v2, v0, v2

    if-lez v2, :cond_0

    iget-wide v2, p0, Lc/T5;->j2:D

    const-wide/high16 v4, 0x4059000000000000L    # 100.0

    mul-double/2addr v2, v4

    div-double/2addr v2, v0

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public final S()Ljava/lang/Double;
    .locals 40

    move-object/from16 v0, p0

    iget-boolean v1, v0, Lc/T5;->F1:Z

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return-object v2

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lc/T5;->R()Lc/W5;

    move-result-object v1

    new-instance v3, Lc/V5;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    const/16 v4, 0x10

    invoke-virtual {v0, v4}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v4

    iput-object v4, v3, Lc/V5;->a:Lc/Y5;

    const/16 v4, 0x15

    invoke-virtual {v0, v4}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v4

    iput-object v4, v3, Lc/V5;->b:Lc/Y5;

    const/4 v4, 0x2

    invoke-virtual {v0, v4}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v5

    iput-object v5, v3, Lc/V5;->c:Lc/Y5;

    const/4 v5, 0x3

    invoke-virtual {v0, v5}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v6

    iput-object v6, v3, Lc/V5;->d:Lc/Y5;

    const/4 v6, 0x4

    invoke-virtual {v0, v6}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v7

    iput-object v7, v3, Lc/V5;->e:Lc/Y5;

    const/4 v7, 0x1

    invoke-virtual {v0, v7}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v8

    iput-object v8, v3, Lc/V5;->f:Lc/Y5;

    const/16 v8, 0xa

    invoke-virtual {v0, v8}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v8

    iput-object v8, v3, Lc/V5;->g:Lc/Y5;

    const/16 v8, 0x9

    invoke-virtual {v0, v8}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v8

    iput-object v8, v3, Lc/V5;->h:Lc/Y5;

    const/16 v8, 0xb

    invoke-virtual {v0, v8}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v9

    iput-object v9, v3, Lc/V5;->i:Lc/Y5;

    const/16 v9, 0xc

    invoke-virtual {v0, v9}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v10

    iput-object v10, v3, Lc/V5;->j:Lc/Y5;

    const/4 v10, 0x6

    invoke-virtual {v0, v10}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v11

    iput-object v11, v3, Lc/V5;->k:Lc/Y5;

    const/16 v11, 0xd

    invoke-virtual {v0, v11}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v11

    iput-object v11, v3, Lc/V5;->l:Lc/Y5;

    const/16 v11, 0x51

    invoke-virtual {v0, v11}, Lc/T5;->O(I)Ljava/lang/Double;

    move-result-object v11

    if-nez v11, :cond_1

    move-object v11, v2

    goto :goto_0

    :cond_1
    invoke-virtual {v11}, Ljava/lang/Double;->intValue()I

    move-result v11

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    :goto_0
    iput-object v11, v3, Lc/V5;->o:Ljava/lang/Integer;

    iget-object v11, v0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/S5;

    const/16 v13, 0x103

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    invoke-virtual {v11, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lc/S5;

    iget-object v13, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v14, "fuel_scheme"

    const/4 v15, 0x0

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v14

    if-ne v14, v4, :cond_2

    iget-object v14, v3, Lc/V5;->g:Lc/Y5;

    goto :goto_1

    :cond_2
    move-object v14, v2

    :goto_1
    const/16 v2, 0x8

    if-nez v14, :cond_3

    invoke-virtual {v0, v2}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v14

    :cond_3
    if-nez v14, :cond_4

    iget-object v14, v3, Lc/V5;->h:Lc/Y5;

    :cond_4
    if-nez v14, :cond_5

    iget-object v14, v3, Lc/V5;->g:Lc/Y5;

    :cond_5
    if-nez v14, :cond_6

    const/16 v14, 0x14

    invoke-virtual {v0, v14}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v14

    :cond_6
    const-wide/high16 v16, 0x4000000000000000L    # 2.0

    const-wide/high16 v18, 0x3ff0000000000000L    # 1.0

    const-wide/16 v20, 0x0

    if-eqz v12, :cond_12

    move-object/from16 v22, v3

    iget-wide v2, v12, Lc/S5;->a:D

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v12

    if-eqz v12, :cond_11

    if-eqz v14, :cond_11

    iget-wide v8, v0, Lc/T5;->A2:J

    iget-wide v6, v14, Lc/Y5;->c:J

    cmp-long v8, v8, v6

    if-eqz v8, :cond_10

    double-to-int v2, v2

    if-eqz v11, :cond_8

    iget-wide v8, v11, Lc/S5;->a:D

    invoke-static {v8, v9}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    if-nez v3, :cond_7

    goto :goto_2

    :cond_7
    double-to-int v3, v8

    goto :goto_3

    :cond_8
    :goto_2
    const/4 v3, 0x5

    :goto_3
    const-string v8, "fuel_status_ecu"

    invoke-interface {v13, v8, v15}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    if-nez v8, :cond_9

    move v8, v2

    goto :goto_4

    :cond_9
    move v8, v3

    :goto_4
    if-eqz v8, :cond_f

    if-ne v8, v5, :cond_a

    goto :goto_7

    :cond_a
    const/4 v9, 0x1

    if-eq v8, v9, :cond_c

    const/4 v11, 0x4

    if-ne v8, v11, :cond_b

    goto :goto_5

    :cond_b
    if-ne v2, v4, :cond_c

    if-eq v3, v9, :cond_c

    if-eq v3, v4, :cond_d

    const/4 v2, 0x5

    if-ne v3, v2, :cond_c

    goto :goto_6

    :cond_c
    :goto_5
    move-wide/from16 v2, v18

    goto :goto_8

    :cond_d
    :goto_6
    const-wide/high16 v2, 0x4034000000000000L    # 20.0

    iget-wide v8, v14, Lc/Y5;->a:D

    cmpg-double v2, v8, v2

    if-gez v2, :cond_e

    move-wide/from16 v2, v20

    goto :goto_8

    :cond_e
    move-wide/from16 v2, v16

    goto :goto_8

    :cond_f
    :goto_7
    const-wide/high16 v2, -0x4010000000000000L    # -1.0

    :goto_8
    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->B2:Ljava/lang/Double;

    iput-wide v6, v0, Lc/T5;->A2:J

    :cond_10
    iget-object v2, v0, Lc/T5;->B2:Ljava/lang/Double;

    move-object/from16 v3, v22

    iput-object v2, v3, Lc/V5;->m:Ljava/lang/Double;

    iput-wide v6, v3, Lc/V5;->n:J

    goto :goto_9

    :cond_11
    move-object/from16 v3, v22

    :cond_12
    :goto_9
    iget v2, v1, Lc/W5;->a:I

    if-nez v2, :cond_13

    invoke-static {v3}, Lc/Z5;->a(Lc/V5;)I

    move-result v2

    :cond_13
    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v6

    iget v8, v1, Lc/W5;->a:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v25

    iget v8, v1, Lc/W5;->b:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v26

    iget-wide v8, v1, Lc/W5;->d:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v27

    iget v8, v1, Lc/W5;->c:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v28

    iget-wide v8, v1, Lc/W5;->e:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v29

    iget-wide v8, v1, Lc/W5;->f:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v30

    iget-wide v8, v1, Lc/W5;->g:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v31

    iget-wide v8, v1, Lc/W5;->h:D

    invoke-static {v8, v9}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v32

    iget-boolean v8, v1, Lc/W5;->i:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v33

    iget-boolean v8, v1, Lc/W5;->j:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v34

    iget-boolean v8, v1, Lc/W5;->k:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v35

    iget-boolean v8, v1, Lc/W5;->l:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v36

    iget-boolean v8, v1, Lc/W5;->m:Z

    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v37

    iget-object v8, v1, Lc/W5;->n:[I

    invoke-static {v8}, Ljava/util/Arrays;->hashCode([I)I

    move-result v9

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v38

    iget-object v9, v3, Lc/V5;->o:Ljava/lang/Integer;

    move-object/from16 v39, v9

    filled-new-array/range {v25 .. v39}, [Ljava/lang/Object;

    move-result-object v9

    invoke-static {v9}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    move-result v9

    iget-object v11, v0, Lc/T5;->t2:Lc/X5;

    if-eqz v11, :cond_14

    iget-wide v13, v0, Lc/T5;->u2:J

    cmp-long v13, v13, v6

    if-nez v13, :cond_14

    iget v11, v11, Lc/X5;->a:I

    if-ne v11, v2, :cond_14

    iget v2, v0, Lc/T5;->y2:I

    if-eq v9, v2, :cond_53

    :cond_14
    iget v2, v0, Lc/T5;->y2:I

    iget-object v11, v0, Lc/T5;->s2:Lc/Z5;

    if-eq v9, v2, :cond_15

    iput-boolean v15, v11, Lc/Z5;->a:Z

    :cond_15
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v2, v1, Lc/W5;->a:I

    if-nez v2, :cond_16

    invoke-static {v3}, Lc/Z5;->a(Lc/V5;)I

    move-result v2

    :cond_16
    if-eqz v2, :cond_52

    const/4 v13, 0x4

    if-ne v2, v13, :cond_17

    iget-object v13, v3, Lc/V5;->a:Lc/Y5;

    if-eqz v13, :cond_52

    goto :goto_a

    :cond_17
    if-ne v2, v10, :cond_18

    iget-object v13, v3, Lc/V5;->b:Lc/Y5;

    if-eqz v13, :cond_52

    iget-object v13, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v13, :cond_52

    goto :goto_a

    :cond_18
    const/4 v13, 0x1

    if-ne v2, v13, :cond_19

    iget-object v13, v3, Lc/V5;->c:Lc/Y5;

    if-eqz v13, :cond_52

    goto :goto_a

    :cond_19
    if-ne v2, v5, :cond_1a

    iget-object v13, v3, Lc/V5;->d:Lc/Y5;

    if-eqz v13, :cond_52

    iget-object v13, v3, Lc/V5;->e:Lc/Y5;

    if-eqz v13, :cond_52

    iget-object v13, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v13, :cond_52

    goto :goto_a

    :cond_1a
    if-ne v2, v4, :cond_1b

    iget-object v13, v3, Lc/V5;->g:Lc/Y5;

    if-eqz v13, :cond_52

    iget-object v13, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v13, :cond_52

    goto :goto_a

    :cond_1b
    const/4 v13, 0x5

    if-ne v2, v13, :cond_52

    iget-object v13, v3, Lc/V5;->k:Lc/Y5;

    if-eqz v13, :cond_52

    iget-object v13, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v13, :cond_52

    :goto_a
    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v13

    const-wide/16 v25, 0x0

    cmp-long v22, v13, v25

    if-gtz v22, :cond_1c

    move v10, v9

    goto/16 :goto_10

    :cond_1c
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    const/4 v15, 0x4

    if-ne v2, v15, :cond_1e

    iget-object v15, v3, Lc/V5;->a:Lc/Y5;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1d
    :goto_b
    move v4, v9

    goto/16 :goto_d

    :cond_1e
    if-ne v2, v10, :cond_1f

    iget-object v15, v3, Lc/V5;->f:Lc/Y5;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v15, v3, Lc/V5;->b:Lc/Y5;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b

    :cond_1f
    const/4 v15, 0x5

    if-ne v2, v15, :cond_20

    iget-object v15, v3, Lc/V5;->k:Lc/Y5;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v15, v3, Lc/V5;->f:Lc/Y5;

    invoke-virtual {v12, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean v15, v1, Lc/W5;->j:Z

    if-eqz v15, :cond_1d

    iget-object v15, v3, Lc/V5;->m:Ljava/lang/Double;

    if-eqz v15, :cond_1d

    new-instance v10, Lc/Y5;

    invoke-virtual {v15}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v29

    const/16 v31, 0x0

    iget-wide v4, v3, Lc/V5;->n:J

    move-object/from16 v28, v10

    move-wide/from16 v32, v4

    invoke-direct/range {v28 .. v33}, Lc/Y5;-><init>(DIJ)V

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b

    :cond_20
    move v4, v5

    if-ne v2, v4, :cond_21

    iget-object v4, v3, Lc/V5;->d:Lc/Y5;

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_21
    const/4 v4, 0x2

    if-ne v2, v4, :cond_22

    iget-object v4, v3, Lc/V5;->f:Lc/Y5;

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_22
    iget-boolean v4, v1, Lc/W5;->i:Z

    if-nez v4, :cond_23

    iget-object v4, v3, Lc/V5;->l:Lc/Y5;

    if-eqz v4, :cond_23

    invoke-virtual {v12, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_23
    iget-boolean v4, v1, Lc/W5;->j:Z

    if-eqz v4, :cond_24

    iget-object v4, v3, Lc/V5;->m:Ljava/lang/Double;

    if-eqz v4, :cond_24

    new-instance v5, Lc/Y5;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v29

    const/16 v31, 0x0

    move v4, v9

    iget-wide v9, v3, Lc/V5;->n:J

    move-object/from16 v28, v5

    move-wide/from16 v32, v9

    invoke-direct/range {v28 .. v33}, Lc/Y5;-><init>(DIJ)V

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_c

    :cond_24
    move v4, v9

    :goto_c
    iget v5, v1, Lc/W5;->b:I

    const/4 v9, 0x1

    if-ne v5, v9, :cond_25

    iget-object v5, v3, Lc/V5;->h:Lc/Y5;

    if-eqz v5, :cond_25

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_25
    if-ne v2, v9, :cond_26

    iget-object v5, v3, Lc/V5;->c:Lc/Y5;

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-boolean v5, v1, Lc/W5;->m:Z

    if-eqz v5, :cond_26

    iget-object v5, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v5, :cond_26

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_26
    const/4 v5, 0x3

    if-ne v2, v5, :cond_27

    iget-object v5, v3, Lc/V5;->f:Lc/Y5;

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_27
    const/4 v5, 0x2

    if-ne v2, v5, :cond_28

    iget-object v5, v3, Lc/V5;->g:Lc/Y5;

    invoke-virtual {v12, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_28
    :goto_d
    invoke-virtual {v12}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_e
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_2c

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/Y5;

    if-nez v9, :cond_29

    move v10, v4

    goto :goto_f

    :cond_29
    move v10, v4

    move-object v12, v5

    iget-wide v4, v9, Lc/Y5;->c:J

    cmp-long v28, v4, v25

    if-lez v28, :cond_2b

    sub-long v4, v13, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->abs(J)J

    move-result-wide v4

    const-wide/16 v28, 0x1388

    cmp-long v4, v4, v28

    if-lez v4, :cond_2b

    iget-object v4, v3, Lc/V5;->l:Lc/Y5;

    if-ne v9, v4, :cond_2a

    goto :goto_10

    :cond_2a
    :goto_f
    move-wide/from16 v34, v6

    move v15, v10

    goto/16 :goto_20

    :cond_2b
    move v4, v10

    move-object v5, v12

    goto :goto_e

    :cond_2c
    move v10, v4

    :goto_10
    iget-boolean v4, v1, Lc/W5;->m:Z

    if-eqz v4, :cond_2e

    const/4 v4, 0x1

    if-eq v2, v4, :cond_2d

    const/4 v4, 0x3

    if-eq v2, v4, :cond_2d

    const/4 v4, 0x2

    if-eq v2, v4, :cond_2d

    const/4 v4, 0x6

    if-eq v2, v4, :cond_2d

    const/4 v4, 0x5

    if-ne v2, v4, :cond_2f

    :cond_2d
    iget-object v4, v3, Lc/V5;->f:Lc/Y5;

    if-eqz v4, :cond_2e

    iget-wide v4, v4, Lc/Y5;->a:D

    const-wide v12, 0x4072c00000000000L    # 300.0

    cmpg-double v4, v4, v12

    if-gtz v4, :cond_2e

    new-instance v1, Lc/X5;

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    const-wide/16 v27, 0x0

    const/16 v29, 0x1

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    :goto_11
    move-wide/from16 v34, v6

    move v15, v10

    goto/16 :goto_21

    :cond_2e
    const/4 v4, 0x5

    :cond_2f
    if-ne v2, v4, :cond_30

    iget-boolean v4, v11, Lc/Z5;->a:Z

    if-nez v4, :cond_30

    const/4 v4, 0x1

    iput-boolean v4, v11, Lc/Z5;->a:Z

    new-instance v1, Lc/X5;

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    goto :goto_11

    :cond_30
    iget-boolean v4, v1, Lc/W5;->j:Z

    if-eqz v4, :cond_32

    const/4 v4, 0x1

    if-eq v2, v4, :cond_31

    const/4 v4, 0x3

    if-eq v2, v4, :cond_31

    const/4 v4, 0x2

    if-eq v2, v4, :cond_31

    const/4 v4, 0x5

    if-ne v2, v4, :cond_32

    :cond_31
    iget-object v4, v3, Lc/V5;->m:Ljava/lang/Double;

    if-eqz v4, :cond_32

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    cmpl-double v4, v4, v20

    if-nez v4, :cond_32

    new-instance v1, Lc/X5;

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    const-wide/16 v27, 0x0

    const/16 v29, 0x1

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    goto :goto_11

    :cond_32
    iget-object v4, v3, Lc/V5;->o:Ljava/lang/Integer;

    invoke-static {v1, v4}, Lc/Z5;->c(Lc/W5;Ljava/lang/Integer;)[D

    move-result-object v4

    const/4 v5, 0x1

    aget-wide v11, v4, v5

    const/16 v9, 0x21

    const/4 v15, 0x4

    if-eq v2, v15, :cond_4d

    const-wide/high16 v25, 0x404e000000000000L    # 60.0

    const-wide v28, 0x408f400000000000L    # 1000.0

    const/4 v15, 0x5

    if-eq v2, v15, :cond_4c

    const/4 v15, 0x6

    if-eq v2, v15, :cond_47

    const-wide/high16 v23, 0x4059000000000000L    # 100.0

    if-ne v2, v5, :cond_34

    iget-object v5, v3, Lc/V5;->c:Lc/Y5;

    iget-wide v13, v5, Lc/Y5;->a:D

    iget v5, v5, Lc/Y5;->b:I

    if-ne v5, v9, :cond_33

    goto :goto_12

    :cond_33
    const-wide v18, 0x400ccccccccccccdL    # 3.6

    :goto_12
    mul-double v13, v13, v18

    move-wide/from16 v34, v6

    move v15, v10

    goto/16 :goto_17

    :cond_34
    const-wide v30, 0x3fb999999999999aL    # 0.1

    const/16 v9, 0x30

    const/4 v15, 0x3

    if-ne v2, v15, :cond_3b

    iget-object v15, v3, Lc/V5;->f:Lc/Y5;

    iget-wide v13, v15, Lc/Y5;->a:D

    iget-object v15, v3, Lc/V5;->d:Lc/Y5;

    iget v5, v15, Lc/Y5;->b:I

    move-wide/from16 v34, v6

    iget-wide v6, v15, Lc/Y5;->a:D

    const/16 v15, 0xb

    if-eq v5, v15, :cond_38

    if-eq v5, v9, :cond_37

    const/16 v9, 0x34

    if-eq v5, v9, :cond_36

    const/16 v9, 0x45

    if-eq v5, v9, :cond_36

    const/16 v9, 0x4a

    if-eq v5, v9, :cond_35

    goto :goto_13

    :cond_35
    mul-double v6, v6, v28

    goto :goto_13

    :cond_36
    mul-double v6, v6, v30

    goto :goto_13

    :cond_37
    mul-double v6, v6, v23

    goto :goto_13

    :cond_38
    const-wide v18, 0x3f50624dd2f1a9fcL    # 0.001

    mul-double v6, v6, v18

    :goto_13
    mul-double/2addr v6, v13

    iget-object v5, v3, Lc/V5;->e:Lc/Y5;

    move v15, v10

    iget-wide v9, v5, Lc/Y5;->a:D

    const-wide v18, 0x4071126666666666L    # 273.15

    add-double v9, v9, v18

    div-double/2addr v6, v9

    mul-double v6, v6, v16

    div-double v6, v6, v25

    if-eqz v8, :cond_3a

    array-length v5, v8

    const/16 v9, 0x8

    if-ne v5, v9, :cond_3a

    cmpg-double v5, v13, v28

    if-gtz v5, :cond_39

    const/4 v5, 0x0

    aget v8, v8, v5

    int-to-double v8, v8

    goto :goto_14

    :cond_39
    const/4 v5, 0x7

    aget v5, v8, v5

    int-to-double v8, v5

    :goto_14
    mul-double/2addr v6, v8

    div-double v6, v6, v23

    iget-wide v8, v1, Lc/W5;->d:D

    mul-double/2addr v6, v8

    const-wide v8, 0x403cf851eb851eb8L    # 28.97

    mul-double/2addr v6, v8

    const-wide v8, 0x4020a100dff9d03bL    # 8.3144598

    div-double v13, v6, v8

    goto :goto_17

    :cond_3a
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Eight source VE points required"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_3b
    move-wide/from16 v34, v6

    move v15, v10

    iget-object v5, v3, Lc/V5;->i:Lc/Y5;

    const-wide v6, 0x3ff2f1a9fbe76c8bL    # 1.184

    if-eqz v5, :cond_3f

    iget-object v8, v3, Lc/V5;->j:Lc/Y5;

    if-eqz v8, :cond_3f

    iget v10, v5, Lc/Y5;->b:I

    const/16 v13, 0x34

    if-ne v10, v13, :cond_3c

    move-wide/from16 v18, v30

    goto :goto_15

    :cond_3c
    if-ne v10, v9, :cond_3d

    move-wide/from16 v18, v23

    :cond_3d
    :goto_15
    iget-wide v9, v5, Lc/Y5;->a:D

    mul-double v9, v9, v18

    mul-double v9, v9, v28

    iget-wide v13, v8, Lc/Y5;->a:D

    const-wide v18, 0x4071126666666666L    # 273.15

    add-double v13, v13, v18

    const-wide v18, 0x4071f0ed916872b0L    # 287.058

    mul-double v13, v13, v18

    div-double/2addr v9, v13

    cmpl-double v5, v9, v20

    if-nez v5, :cond_3e

    goto :goto_16

    :cond_3e
    move-wide v6, v9

    :cond_3f
    :goto_16
    iget-object v5, v3, Lc/V5;->g:Lc/Y5;

    iget-wide v8, v5, Lc/Y5;->a:D

    div-double v8, v8, v23

    mul-double/2addr v8, v6

    iget-wide v5, v1, Lc/W5;->d:D

    iget v7, v1, Lc/W5;->c:I

    int-to-double v13, v7

    div-double/2addr v5, v13

    div-double/2addr v8, v5

    mul-double/2addr v8, v13

    div-double v8, v8, v16

    iget-object v5, v3, Lc/V5;->f:Lc/Y5;

    iget-wide v5, v5, Lc/Y5;->a:D

    mul-double/2addr v8, v5

    div-double v13, v8, v25

    :goto_17
    iget v5, v1, Lc/W5;->b:I

    const/4 v6, 0x1

    if-ne v5, v6, :cond_41

    iget-object v5, v3, Lc/V5;->h:Lc/Y5;

    if-nez v5, :cond_40

    new-instance v1, Lc/X5;

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    const-wide/high16 v27, 0x7ff8000000000000L    # Double.NaN

    const/16 v29, 0x0

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    goto/16 :goto_21

    :cond_40
    iget-wide v5, v5, Lc/Y5;->a:D

    div-double v5, v5, v23

    mul-double/2addr v13, v5

    :cond_41
    const/4 v5, 0x0

    aget-wide v5, v4, v5

    iget-boolean v4, v1, Lc/W5;->i:Z

    if-nez v4, :cond_46

    iget-object v4, v3, Lc/V5;->l:Lc/Y5;

    if-eqz v4, :cond_46

    iget-wide v7, v4, Lc/Y5;->a:D

    cmpl-double v4, v7, v20

    if-eqz v4, :cond_46

    invoke-static {v7, v8}, Ljava/lang/Double;->isFinite(D)Z

    move-result v4

    if-nez v4, :cond_42

    goto :goto_18

    :cond_42
    iget-object v4, v3, Lc/V5;->l:Lc/Y5;

    iget-wide v7, v4, Lc/Y5;->a:D

    iget v4, v1, Lc/W5;->b:I

    if-nez v4, :cond_43

    iget-boolean v4, v1, Lc/W5;->l:Z

    if-nez v4, :cond_44

    :cond_43
    mul-double/2addr v7, v5

    :cond_44
    iget-boolean v4, v1, Lc/W5;->k:Z

    if-eqz v4, :cond_45

    const-wide v9, 0x403d666666666666L    # 29.4

    cmpl-double v4, v7, v9

    if-gtz v4, :cond_46

    const-wide v9, 0x3ff7851eb851eb85L    # 1.47

    cmpg-double v4, v7, v9

    if-gez v4, :cond_45

    goto :goto_18

    :cond_45
    move-wide v5, v7

    :cond_46
    :goto_18
    div-double/2addr v13, v5

    div-double/2addr v13, v11

    goto/16 :goto_1f

    :cond_47
    move-wide/from16 v34, v6

    move v15, v10

    iget-object v4, v3, Lc/V5;->b:Lc/Y5;

    iget-wide v5, v4, Lc/Y5;->a:D

    iget v4, v4, Lc/Y5;->b:I

    const/16 v7, 0x48

    const-wide v8, 0x412e848000000000L    # 1000000.0

    if-ne v4, v7, :cond_48

    div-double/2addr v5, v8

    goto :goto_1b

    :cond_48
    const/16 v7, 0x44

    if-eq v4, v7, :cond_4a

    const/16 v7, 0x38

    if-ne v4, v7, :cond_49

    goto :goto_1a

    :cond_49
    const/16 v7, 0x23

    if-ne v4, v7, :cond_4b

    div-double v5, v5, v28

    :goto_19
    div-double/2addr v5, v11

    goto :goto_1b

    :cond_4a
    :goto_1a
    div-double/2addr v5, v8

    goto :goto_19

    :cond_4b
    :goto_1b
    mul-double v5, v5, v16

    iget-object v4, v3, Lc/V5;->f:Lc/Y5;

    iget-wide v7, v4, Lc/Y5;->a:D

    mul-double/2addr v5, v7

    mul-double v13, v5, v25

    goto/16 :goto_1f

    :cond_4c
    move-wide/from16 v34, v6

    move v15, v10

    iget-object v4, v3, Lc/V5;->f:Lc/Y5;

    iget-wide v4, v4, Lc/Y5;->a:D

    div-double v4, v4, v25

    iget v6, v1, Lc/W5;->c:I

    const/4 v7, 0x2

    div-int/2addr v6, v7

    int-to-double v6, v6

    mul-double/2addr v4, v6

    iget-object v6, v3, Lc/V5;->k:Lc/Y5;

    iget-wide v6, v6, Lc/Y5;->a:D

    mul-double/2addr v4, v6

    div-double v4, v4, v28

    iget-wide v6, v1, Lc/W5;->e:D

    div-double v6, v6, v28

    div-double v6, v6, v25

    mul-double/2addr v6, v4

    const-wide v4, 0x40ac200000000000L    # 3600.0

    mul-double v13, v6, v4

    goto :goto_1f

    :cond_4d
    move-wide/from16 v34, v6

    move v15, v10

    iget-object v4, v3, Lc/V5;->a:Lc/Y5;

    iget v5, v4, Lc/Y5;->b:I

    iget-wide v6, v4, Lc/Y5;->a:D

    const/16 v4, 0xc

    if-ne v5, v4, :cond_4e

    move-wide/from16 v27, v6

    const/16 v8, 0x8

    goto :goto_1e

    :cond_4e
    const/16 v8, 0x8

    if-ne v5, v8, :cond_4f

    const-wide v13, 0x400ccccccccccccdL    # 3.6

    mul-double/2addr v6, v13

    :goto_1c
    div-double/2addr v6, v11

    :goto_1d
    move-wide/from16 v27, v6

    goto :goto_1e

    :cond_4f
    if-ne v5, v9, :cond_50

    goto :goto_1c

    :cond_50
    const-wide/high16 v6, 0x7ff8000000000000L    # Double.NaN

    goto :goto_1d

    :goto_1e
    if-eq v5, v4, :cond_51

    if-eq v5, v8, :cond_51

    if-eq v5, v9, :cond_51

    new-instance v1, Lc/X5;

    const/16 v29, 0x0

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    goto :goto_21

    :cond_51
    move-wide/from16 v13, v27

    :goto_1f
    new-instance v4, Lc/X5;

    iget-wide v5, v1, Lc/W5;->f:D

    mul-double v27, v13, v5

    const/16 v29, 0x1

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    move-object/from16 v25, v4

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    move-object v1, v4

    goto :goto_21

    :cond_52
    move-wide/from16 v34, v6

    move v15, v9

    :goto_20
    new-instance v1, Lc/X5;

    invoke-static {v3, v2}, Lc/Z5;->b(Lc/V5;I)J

    move-result-wide v30

    const-wide/high16 v27, 0x7ff8000000000000L    # Double.NaN

    const/16 v29, 0x0

    move-object/from16 v25, v1

    move/from16 v26, v2

    invoke-direct/range {v25 .. v31}, Lc/X5;-><init>(IDZJ)V

    :goto_21
    iput-object v1, v0, Lc/T5;->t2:Lc/X5;

    move-wide/from16 v1, v34

    iput-wide v1, v0, Lc/T5;->u2:J

    move v1, v15

    iput v1, v0, Lc/T5;->y2:I

    :cond_53
    iget-object v1, v0, Lc/T5;->t2:Lc/X5;

    iget-wide v2, v1, Lc/X5;->b:D

    iget-boolean v1, v1, Lc/X5;->c:Z

    if-eqz v1, :cond_54

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v1

    if-eqz v1, :cond_54

    cmpl-double v1, v2, v20

    if-ltz v1, :cond_54

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    goto :goto_22

    :cond_54
    const/4 v2, 0x0

    :goto_22
    return-object v2
.end method

.method public final S0(Ljava/lang/String;)D
    .locals 4

    const-wide/16 v0, 0x0

    :try_start_0
    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "0"

    invoke-interface {v2, p1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p1, :cond_0

    cmpl-double p1, v2, v0

    if-ltz p1, :cond_0

    move-wide v0, v2

    :catch_0
    :cond_0
    return-wide v0
.end method

.method public final T()Ljava/lang/String;
    .locals 2

    invoke-virtual {p0}, Lc/T5;->S()Ljava/lang/Double;

    iget-object v0, p0, Lc/T5;->t2:Lc/X5;

    const-string v1, ""

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    iget v0, v0, Lc/X5;->a:I

    packed-switch v0, :pswitch_data_0

    return-object v1

    :pswitch_0
    const-string v0, "\u0440\u0430\u0441\u0445\u043e\u0434 \u0437\u0430 \u0446\u0438\u043a\u043b"

    return-object v0

    :pswitch_1
    const-string v0, "\u0440\u0430\u0441\u0447\u0451\u0442 \u043f\u043e \u0434\u043b\u0438\u0442\u0435\u043b\u044c\u043d\u043e\u0441\u0442\u0438 \u0432\u043f\u0440\u044b\u0441\u043a\u0430"

    return-object v0

    :pswitch_2
    const-string v0, "\u042d\u0411\u0423"

    return-object v0

    :pswitch_3
    const-string v0, "\u043e\u0446\u0435\u043d\u043a\u0430 \u043f\u043e \u0434\u0430\u0432\u043b\u0435\u043d\u0438\u044e"

    return-object v0

    :pswitch_4
    const-string v0, "\u0440\u0430\u0441\u0447\u0451\u0442 \u043f\u043e \u043d\u0430\u0433\u0440\u0443\u0437\u043a\u0435"

    return-object v0

    :pswitch_5
    const-string v0, "\u0440\u0430\u0441\u0447\u0451\u0442 \u043f\u043e \u0432\u043e\u0437\u0434\u0443\u0445\u0443"

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final T0()V
    .locals 21

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v2, v0, Lc/T5;->g:Lc/j6;

    if-nez v2, :cond_0

    return-void

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    :goto_0
    iget-object v4, v0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v4}, Ljava/util/Set;->size()I

    move-result v5

    if-ge v3, v5, :cond_d

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    move v5, v2

    :cond_1
    :goto_1
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_b

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    iget-object v7, v0, Lc/T5;->g:Lc/j6;

    iget-object v7, v7, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v7, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lc/i6;

    if-eqz v7, :cond_1

    iget-boolean v8, v7, Lc/i6;->v:Z

    if-nez v8, :cond_2

    goto :goto_1

    :cond_2
    iget-boolean v8, v7, Lc/i6;->y:Z

    if-eqz v8, :cond_3

    :try_start_0
    new-array v9, v2, [B

    goto :goto_2

    :cond_3
    iget-object v9, v0, Lc/T5;->R0:Ljava/util/HashMap;

    invoke-virtual {v9, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, [B

    :goto_2
    iget-object v10, v0, Lc/T5;->T0:Ljava/util/HashMap;

    invoke-virtual {v10, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Long;

    if-eqz v9, :cond_9

    if-nez v8, :cond_4

    if-eqz v10, :cond_9

    :cond_4
    const-wide/16 v11, 0x0

    if-nez v10, :cond_5

    move-wide v13, v11

    goto :goto_3

    :cond_5
    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v13

    :goto_3
    iput-wide v13, v0, Lc/T5;->z2:J

    iget-object v8, v0, Lc/T5;->S0:Ljava/util/HashMap;

    invoke-virtual {v8, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, [B

    new-instance v10, Lc/B5;

    const/4 v13, 0x0

    invoke-direct {v10, v0, v13}, Lc/B5;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v7, v9, v8, v10}, Lc/i6;->b([B[BLjava/util/function/ToDoubleFunction;)D

    move-result-wide v8

    invoke-virtual/range {p0 .. p0}, Lc/T5;->H0()D

    move-result-wide v13

    invoke-virtual {v7, v8, v9, v13, v14}, Lc/i6;->a(DD)D

    move-result-wide v7

    invoke-virtual {v1, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lc/S5;

    iget-wide v13, v0, Lc/T5;->z2:J

    cmp-long v10, v13, v11

    if-lez v10, :cond_6

    move-wide/from16 v19, v13

    goto :goto_5

    :cond_6
    if-nez v9, :cond_7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    :goto_4
    move-wide/from16 v19, v10

    goto :goto_5

    :cond_7
    iget-wide v10, v9, Lc/S5;->c:J

    goto :goto_4

    :goto_5
    if-eqz v9, :cond_8

    iget-wide v10, v9, Lc/S5;->c:J

    cmp-long v10, v10, v19

    if-nez v10, :cond_8

    iget-wide v9, v9, Lc/S5;->a:D

    invoke-static {v9, v10, v7, v8}, Ljava/lang/Double;->compare(DD)I

    move-result v9

    if-nez v9, :cond_8

    goto/16 :goto_1

    :cond_8
    new-instance v9, Lc/S5;

    const/16 v18, -0x1

    move-object v15, v9

    move-wide/from16 v16, v7

    invoke-direct/range {v15 .. v20}, Lc/S5;-><init>(DIJ)V

    invoke-interface {v1, v6, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :cond_9
    new-instance v7, Ljava/lang/IllegalArgumentException;

    const-string v8, "\u041d\u0435\u0442 \u0441\u0432\u0435\u0436\u0438\u0445 \u0431\u0430\u0439\u0442\u043e\u0432 \u0434\u0430\u0442\u0447\u0438\u043a\u0430"

    invoke-direct {v7, v8}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v7
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    invoke-interface {v1, v6}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_a

    goto/16 :goto_1

    :cond_a
    :goto_6
    const/4 v5, 0x1

    goto/16 :goto_1

    :cond_b
    if-nez v5, :cond_c

    goto :goto_7

    :cond_c
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :cond_d
    :goto_7
    return-void
.end method

.method public final U(I)Lc/Y5;
    .locals 14

    iget-object v0, p0, Lc/T5;->e:Ljava/util/HashMap;

    const/16 v1, 0xb

    const/16 v2, 0x14

    const/4 v3, 0x3

    const/16 v4, 0x10

    const/4 v5, 0x2

    const/16 v6, 0xf

    const/4 v7, 0x4

    const/16 v8, 0xc

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eq p1, v9, :cond_6

    if-eq p1, v5, :cond_5

    if-eq p1, v3, :cond_4

    if-eq p1, v7, :cond_3

    if-eq p1, v10, :cond_2

    if-eq p1, v4, :cond_1

    if-eq p1, v2, :cond_0

    packed-switch p1, :pswitch_data_0

    const/4 v11, -0x1

    goto :goto_0

    :pswitch_0
    invoke-virtual {p0}, Lc/T5;->g()I

    move-result v11

    goto :goto_0

    :pswitch_1
    const/16 v11, 0x46

    goto :goto_0

    :pswitch_2
    const/16 v11, 0x33

    goto :goto_0

    :pswitch_3
    const/16 v11, 0x43

    goto :goto_0

    :pswitch_4
    move v11, v7

    goto :goto_0

    :pswitch_5
    const/16 v11, 0x11

    goto :goto_0

    :cond_0
    const/16 v11, 0x45

    goto :goto_0

    :cond_1
    const/16 v11, 0x5e

    goto :goto_0

    :cond_2
    const/16 v11, 0xd

    goto :goto_0

    :cond_3
    move v11, v6

    goto :goto_0

    :cond_4
    move v11, v1

    goto :goto_0

    :cond_5
    move v11, v4

    goto :goto_0

    :cond_6
    move v11, v8

    :goto_0
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/S5;

    iget-boolean v11, p0, Lc/T5;->F1:Z

    if-eqz v11, :cond_11

    if-eqz v0, :cond_11

    iget-wide v11, v0, Lc/S5;->a:D

    invoke-static {v11, v12}, Ljava/lang/Double;->isFinite(D)Z

    move-result v13

    if-eqz v13, :cond_11

    invoke-static {v11, v12}, Ljava/lang/Double;->isFinite(D)Z

    move-result v11

    if-eqz v11, :cond_11

    if-ne p1, v9, :cond_8

    const/4 v6, 0x6

    :cond_7
    :goto_1
    move v10, v6

    goto :goto_3

    :cond_8
    const/16 v11, 0x8

    if-ne p1, v5, :cond_9

    move v10, v11

    goto :goto_3

    :cond_9
    if-eq p1, v3, :cond_10

    if-ne p1, v1, :cond_a

    goto :goto_3

    :cond_a
    if-eq p1, v7, :cond_7

    if-ne p1, v8, :cond_b

    goto :goto_1

    :cond_b
    if-ne p1, v10, :cond_c

    move v10, v9

    goto :goto_3

    :cond_c
    if-eq p1, v11, :cond_f

    const/16 v1, 0x9

    if-eq p1, v1, :cond_f

    const/16 v1, 0xa

    if-eq p1, v1, :cond_f

    if-ne p1, v2, :cond_d

    goto :goto_2

    :cond_d
    if-ne p1, v4, :cond_e

    move v10, v8

    goto :goto_3

    :cond_e
    const/4 v6, 0x0

    goto :goto_1

    :cond_f
    :goto_2
    const/16 v6, 0xe

    goto :goto_1

    :cond_10
    :goto_3
    new-instance p1, Lc/Y5;

    iget-wide v8, v0, Lc/S5;->a:D

    iget-wide v11, v0, Lc/S5;->c:J

    move-object v7, p1

    invoke-direct/range {v7 .. v12}, Lc/Y5;-><init>(DIJ)V

    return-object p1

    :cond_11
    iget-boolean v0, p0, Lc/T5;->F1:Z

    if-eqz v0, :cond_18

    iget-object v0, p0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_12
    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    iget v2, v1, Lc/i6;->j:I

    if-ne v2, p1, :cond_12

    iget-object v2, p0, Lc/T5;->h1:Ljava/util/HashSet;

    iget-object v3, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_12

    iget-object v2, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v2, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/S5;

    if-eqz v2, :cond_12

    iget-wide v3, v2, Lc/S5;->a:D

    invoke-static {v3, v4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v5

    if-eqz v5, :cond_12

    invoke-static {v3, v4}, Ljava/lang/Double;->isFinite(D)Z

    move-result v5

    if-nez v5, :cond_13

    goto :goto_4

    :cond_13
    invoke-virtual {v2, v1}, Lc/S5;->a(Lc/i6;)I

    move-result v1

    if-eq p1, v7, :cond_15

    if-eq p1, v8, :cond_15

    if-ne p1, v10, :cond_14

    goto :goto_5

    :cond_14
    move v10, v1

    move-wide v8, v3

    goto :goto_6

    :cond_15
    :goto_5
    invoke-virtual {p0, p1, v1, v3, v4}, Lc/T5;->A(IID)Ljava/lang/Double;

    move-result-object v1

    if-nez v1, :cond_16

    goto :goto_4

    :cond_16
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    if-ne p1, v10, :cond_17

    move v6, v9

    :cond_17
    move-wide v8, v3

    move v10, v6

    :goto_6
    new-instance p1, Lc/Y5;

    iget-wide v11, v2, Lc/S5;->c:J

    move-object v7, p1

    invoke-direct/range {v7 .. v12}, Lc/Y5;-><init>(DIJ)V

    return-object p1

    :cond_18
    const/4 p1, 0x0

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final U0()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "profile_id"

    const-string v2, ""

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_0

    const-string v0, "000000000000000000000000"

    goto :goto_0

    :cond_0
    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public final V0()Z
    .locals 6

    iget-object v0, p0, Lc/T5;->q:Lc/b;

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/T5;->a1:Lc/R5;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    iget-object v4, p0, Lc/T5;->n:Ljava/util/LinkedHashSet;

    iget-object v5, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v4, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    iget-object v4, p0, Lc/T5;->g:Lc/j6;

    iget-object v4, v4, Lc/j6;->v:Ljava/util/LinkedHashMap;

    iget-object v5, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v2, :cond_1

    return v3

    :cond_2
    iget-object v0, p0, Lc/T5;->a1:Lc/R5;

    iget-object v0, v0, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    iget-object v2, p0, Lc/T5;->a1:Lc/R5;

    invoke-virtual {v0, v2}, Ljava/util/LinkedHashMap;->containsValue(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    move v1, v3

    :cond_3
    :goto_0
    return v1
.end method

.method public final W()V
    .locals 10

    iget-boolean v0, p0, Lc/T5;->w:Z

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    if-ne v0, v1, :cond_0

    iget-boolean v0, p0, Lc/T5;->B:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0, v2}, Lc/T5;->c0(Z)V

    :cond_0
    return-void

    :cond_1
    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const-string v0, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0451\u043d \u00b7 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u042d\u0411\u0423\u2026"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->q0:Lc/n6;

    if-nez v0, :cond_5

    invoke-virtual {p0}, Lc/T5;->g0()I

    move-result v4

    iput v4, p0, Lc/T5;->V:I

    new-instance v0, Lc/n6;

    new-instance v1, Lc/m6;

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    iget-boolean v6, v3, Lc/j6;->h:Z

    if-eqz v6, :cond_2

    move v6, v2

    goto :goto_0

    :cond_2
    move v6, v5

    :goto_0
    if-eqz v3, :cond_3

    iget-boolean v7, v3, Lc/j6;->j:Z

    if-eqz v7, :cond_3

    move v7, v2

    goto :goto_1

    :cond_3
    move v7, v5

    :goto_1
    if-nez v3, :cond_4

    const-string v2, ""

    :goto_2
    move-object v9, v2

    goto :goto_3

    :cond_4
    iget-object v2, v3, Lc/j6;->e:Ljava/lang/String;

    goto :goto_2

    :goto_3
    const/4 v5, 0x3

    const/4 v8, 0x0

    move-object v3, v1

    invoke-direct/range {v3 .. v9}, Lc/m6;-><init>(IIZZILjava/lang/String;)V

    invoke-direct {v0, v1}, Lc/n6;-><init>(Lc/m6;)V

    iput-object v0, p0, Lc/T5;->q0:Lc/n6;

    goto :goto_4

    :cond_5
    invoke-virtual {v0}, Lc/n6;->d()Lc/l6;

    move-result-object v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lc/T5;->q0:Lc/n6;

    invoke-virtual {v0}, Lc/n6;->d()Lc/l6;

    move-result-object v0

    iget v0, v0, Lc/l6;->a:I

    if-ne v0, v1, :cond_6

    iget-object v0, p0, Lc/T5;->q0:Lc/n6;

    invoke-virtual {v0, v2}, Lc/n6;->e(Z)V

    :cond_6
    :goto_4
    invoke-virtual {p0}, Lc/T5;->o()V

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final W0(Ljava/lang/String;[B)V
    .locals 5

    invoke-virtual {p0}, Lc/T5;->V0()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_2

    iget-object v0, p0, Lc/T5;->l:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const v2, 0xffff

    if-ge v0, v2, :cond_2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lc/T5;->l:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Lc/T5;->l:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v3, ""

    goto :goto_0

    :cond_1
    const-string v3, "\n"

    :goto_0
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    iget-object v4, p0, Lc/T5;->l:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    sub-int/2addr v2, v4

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->l:Ljava/lang/String;

    :cond_2
    if-eqz p2, :cond_4

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    array-length v0, p2

    :goto_1
    if-ge v1, v0, :cond_3

    aget-byte v2, p2, v1

    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    and-int/lit16 v2, v2, 0xff

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const-string v4, "%02X"

    invoke-static {v3, v4, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_3
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->m:Ljava/lang/String;

    :cond_4
    return-void
.end method

.method public final X()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lc/T5;->a1:Lc/R5;

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/T5;->a1:Lc/R5;

    iget-object v1, v1, Lc/R5;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "@"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lc/T5;->a1:Lc/R5;

    iget-object v1, v1, Lc/R5;->f:Ljava/util/List;

    const-string v2, ";"

    invoke-static {v2, v1}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public final Y()V
    .locals 4

    iget-boolean v0, p0, Lc/T5;->d1:Z

    if-eqz v0, :cond_0

    const-string v0, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0434\u0430\u0442\u0447\u0438\u043a\u043e\u0432 \u043f\u0440\u043e\u0444\u0438\u043b\u044f\u2026"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    return-void

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->F1:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->E:J

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->F:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const-wide/16 v0, 0x1388

    iput-wide v0, p0, Lc/T5;->d2:J

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u043e \u043a \u042d\u0411\u0423 \u00b7 "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "OBD"

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v3, "name"

    invoke-interface {v2, v3, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    return-void
.end method

.method public final Y0()V
    .locals 3

    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-nez v0, :cond_3

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "enabled"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v1, p0, Lc/T5;->x:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_2

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "battery_screen"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->y:Z

    if-eqz v0, :cond_2

    :cond_1
    return-void

    :cond_2
    invoke-virtual {p0}, Lc/T5;->r()V

    const-wide/16 v0, 0x1388

    iput-wide v0, p0, Lc/T5;->d2:J

    invoke-virtual {p0}, Lc/T5;->s()V

    invoke-virtual {p0}, Lc/T5;->u0()V

    :cond_3
    :goto_0
    return-void
.end method

.method public final Z()V
    .locals 26

    move-object/from16 v0, p0

    iget-boolean v1, v0, Lc/T5;->u:Z

    if-eqz v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v0, Lc/T5;->K:Ljava/io/OutputStream;

    if-nez v1, :cond_1

    iget-object v1, v0, Lc/T5;->I:Landroid/bluetooth/BluetoothSocket;

    if-nez v1, :cond_1

    iget-object v1, v0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-eqz v1, :cond_2

    iget-object v1, v0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eqz v1, :cond_2

    :cond_1
    iget-object v1, v0, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v1, :cond_3

    :cond_2
    return-void

    :cond_3
    iget-boolean v1, v0, Lc/T5;->w:Z

    const/4 v2, 0x1

    const-string v3, "ATRV"

    const-wide/16 v4, 0x3a98

    const/4 v6, 0x2

    if-eqz v1, :cond_5

    iget-boolean v1, v0, Lc/T5;->A:Z

    if-nez v1, :cond_4

    invoke-virtual/range {p0 .. p0}, Lc/T5;->j()I

    move-result v1

    if-ne v1, v6, :cond_4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-wide v8, v0, Lc/T5;->D:J

    sub-long/2addr v6, v8

    cmp-long v1, v6, v4

    if-ltz v1, :cond_4

    iput-boolean v2, v0, Lc/T5;->z:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, v0, Lc/T5;->D:J

    invoke-virtual {v0, v3}, Lc/T5;->O0(Ljava/lang/String;)V

    :cond_4
    return-void

    :cond_5
    iget-object v1, v0, Lc/T5;->F0:Lc/g6;

    if-nez v1, :cond_6d

    iget-object v1, v0, Lc/T5;->H0:Lc/e6;

    if-eqz v1, :cond_6

    goto/16 :goto_2a

    :cond_6
    iget-boolean v1, v0, Lc/T5;->F1:Z

    if-eqz v1, :cond_7

    iget-boolean v1, v0, Lc/T5;->d1:Z

    if-nez v1, :cond_7

    invoke-virtual/range {p0 .. p0}, Lc/T5;->j()I

    move-result v1

    if-ne v1, v6, :cond_7

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    iget-wide v9, v0, Lc/T5;->D:J

    sub-long/2addr v7, v9

    cmp-long v1, v7, v4

    if-ltz v1, :cond_7

    iget-object v1, v0, Lc/T5;->D0:Lc/j7;

    if-nez v1, :cond_7

    iget-object v1, v0, Lc/T5;->P0:Lc/b6;

    if-nez v1, :cond_7

    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    iget-boolean v1, v0, Lc/T5;->e1:Z

    if-nez v1, :cond_7

    iput-boolean v2, v0, Lc/T5;->z:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, v0, Lc/T5;->D:J

    invoke-virtual {v0, v3}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_7
    iget-object v1, v0, Lc/T5;->D0:Lc/j7;

    if-eqz v1, :cond_8

    invoke-virtual/range {p0 .. p0}, Lc/T5;->C0()V

    return-void

    :cond_8
    iget-boolean v1, v0, Lc/T5;->h0:Z

    if-nez v1, :cond_a

    iget v3, v0, Lc/T5;->m0:I

    if-ltz v3, :cond_a

    if-ge v3, v6, :cond_a

    add-int/lit8 v1, v3, 0x1

    iput v1, v0, Lc/T5;->m0:I

    if-nez v3, :cond_9

    const-string v1, "STI"

    goto :goto_0

    :cond_9
    const-string v1, "VTI"

    :goto_0
    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_a
    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v1, :cond_11

    iget-object v1, v0, Lc/T5;->O0:Lc/c6;

    if-eqz v1, :cond_11

    iget-boolean v5, v1, Lc/c6;->j:Z

    if-nez v5, :cond_11

    invoke-virtual {v1}, Lc/c6;->e()Lc/b6;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->P0:Lc/b6;

    if-eqz v1, :cond_11

    iget-boolean v1, v1, Lc/b6;->d:Z

    if-eqz v1, :cond_10

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_b

    iget-object v1, v1, Lc/j6;->s:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    iget-object v1, v1, Lc/j6;->s:Ljava/lang/String;

    goto :goto_3

    :cond_b
    iget-object v1, v0, Lc/T5;->s0:Lc/l6;

    if-nez v1, :cond_c

    iget v5, v0, Lc/T5;->V:I

    goto :goto_1

    :cond_c
    iget v5, v1, Lc/l6;->b:I

    :goto_1
    if-nez v1, :cond_e

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_d

    iget-boolean v1, v1, Lc/j6;->h:Z

    if-eqz v1, :cond_d

    goto :goto_2

    :cond_d
    move v2, v3

    goto :goto_2

    :cond_e
    iget-boolean v2, v1, Lc/l6;->g:Z

    :goto_2
    invoke-virtual {v0, v5, v2}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v1

    :goto_3
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_f

    iget v1, v0, Lc/T5;->T:I

    invoke-virtual {v0, v1, v3}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v1

    :cond_f
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_10

    iget-object v2, v0, Lc/T5;->P:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_10

    iput-object v4, v0, Lc/T5;->P0:Lc/b6;

    const-string v2, "ATSH"

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_10
    iget-object v1, v0, Lc/T5;->P0:Lc/b6;

    iget-object v1, v1, Lc/b6;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_11
    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-nez v1, :cond_23

    iget-boolean v1, v0, Lc/T5;->H1:Z

    if-nez v1, :cond_12

    return-void

    :cond_12
    iget-object v1, v0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_14

    iget-object v1, v0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/R5;

    iput-object v1, v0, Lc/T5;->a1:Lc/R5;

    iget-object v1, v1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_13

    goto :goto_4

    :cond_13
    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    iget-object v1, v1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    :goto_4
    iput-boolean v2, v0, Lc/T5;->e1:Z

    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    invoke-virtual {v0, v1}, Lc/T5;->G(Lc/R5;)V

    goto/16 :goto_b

    :cond_14
    iget-boolean v1, v0, Lc/T5;->d1:Z

    if-eqz v1, :cond_15

    return-void

    :cond_15
    invoke-virtual/range {p0 .. p0}, Lc/T5;->M0()V

    iget-object v1, v0, Lc/T5;->V0:Lc/v8;

    iget-object v1, v1, Lc/v8;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->size()I

    move-result v5

    :goto_5
    add-int/lit8 v7, v5, -0x1

    if-lez v5, :cond_19

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/h6;

    invoke-virtual {v1, v5}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    iget v8, v5, Lc/h6;->b:I

    iget-object v9, v5, Lc/h6;->a:Ljava/lang/String;

    if-lez v8, :cond_1a

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->size()I

    move-result v8

    if-ne v8, v2, :cond_16

    goto :goto_6

    :cond_16
    iget v8, v5, Lc/h6;->c:I

    if-nez v8, :cond_17

    iput v2, v5, Lc/h6;->c:I

    goto :goto_6

    :cond_17
    add-int/lit8 v8, v8, 0x1

    iput v8, v5, Lc/h6;->c:I

    iget v9, v5, Lc/h6;->b:I

    if-le v8, v9, :cond_18

    iput v3, v5, Lc/h6;->c:I

    :cond_18
    move v5, v7

    goto :goto_5

    :cond_19
    move-object v9, v4

    :cond_1a
    :goto_6
    if-nez v9, :cond_1b

    move-object v1, v4

    goto :goto_7

    :cond_1b
    iget-object v1, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, v9}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/R5;

    :goto_7
    iput-object v1, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v1, :cond_1d

    iget-object v1, v1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_1c

    goto :goto_8

    :cond_1c
    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    iget-object v1, v1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    :cond_1d
    :goto_8
    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    if-nez v1, :cond_1e

    move-object v1, v4

    goto :goto_9

    :cond_1e
    iget-object v1, v1, Lc/R5;->b:Ljava/lang/String;

    :goto_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    if-nez v1, :cond_1f

    iget-object v5, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-interface {v5}, Ljava/util/Map;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_1f

    iget-boolean v5, v0, Lc/T5;->u0:Z

    if-nez v5, :cond_1f

    iput-boolean v2, v0, Lc/T5;->u0:Z

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    const-wide/16 v3, 0x96

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_1f
    if-nez v1, :cond_20

    iget-object v5, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-interface {v5}, Ljava/util/Map;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_20

    iget-boolean v5, v0, Lc/T5;->F1:Z

    if-eqz v5, :cond_20

    iget-object v5, v0, Lc/T5;->g:Lc/j6;

    if-eqz v5, :cond_20

    iget-boolean v5, v5, Lc/j6;->i:Z

    iget-object v9, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v10, "allow_ping"

    invoke-interface {v9, v10, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    iget-wide v10, v0, Lc/T5;->t0:J

    if-eqz v5, :cond_20

    if-eqz v9, :cond_20

    sub-long/2addr v7, v10

    const-wide/16 v9, 0xc8

    cmp-long v5, v7, v9

    if-lez v5, :cond_20

    invoke-virtual {v0, v2}, Lc/T5;->i0(Z)Z

    move-result v5

    if-eqz v5, :cond_20

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_20
    if-nez v1, :cond_22

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    iget-object v3, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-interface {v3}, Ljava/util/Map;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_21

    const-wide/16 v3, 0x32

    goto :goto_a

    :cond_21
    const-wide/16 v3, 0x1

    :goto_a
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_22
    iput-boolean v3, v0, Lc/T5;->u0:Z

    iget-object v1, v0, Lc/T5;->a1:Lc/R5;

    invoke-virtual {v0, v1}, Lc/T5;->G(Lc/R5;)V

    :goto_b
    iget-object v1, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    :cond_23
    const-string v5, "PING:"

    invoke-virtual {v1, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x5

    if-eqz v5, :cond_24

    iput-object v4, v0, Lc/T5;->a1:Lc/R5;

    iput-boolean v2, v0, Lc/T5;->l0:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iput-wide v2, v0, Lc/T5;->t0:J

    invoke-virtual {v1, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    return-void

    :cond_24
    const-string v5, "BEFORE:"

    invoke-virtual {v1, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    const-string v9, ""

    const-string v11, "ATCEA"

    if-nez v8, :cond_26

    const-string v8, "AFTER:"

    invoke-virtual {v1, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_25

    goto :goto_c

    :cond_25
    move-object/from16 v16, v9

    goto/16 :goto_1f

    :cond_26
    :goto_c
    invoke-virtual {v1, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_27

    const/4 v8, 0x7

    goto :goto_d

    :cond_27
    const/4 v8, 0x6

    :goto_d
    invoke-virtual {v1, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const-string v8, "ATSPDEF"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_28

    iget-object v1, v0, Lc/T5;->X:Ljava/lang/String;

    goto :goto_e

    :cond_28
    const-string v8, "ATSTDEF"

    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_29

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v8, "ATST"

    invoke-direct {v1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->v()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_29
    :goto_e
    iget-object v8, v0, Lc/T5;->a1:Lc/R5;

    if-nez v8, :cond_2a

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v8

    goto :goto_f

    :cond_2a
    iget-object v8, v8, Lc/R5;->f:Ljava/util/List;

    :goto_f
    iget-object v13, v0, Lc/T5;->a1:Lc/R5;

    if-nez v13, :cond_2b

    new-array v13, v6, [Ljava/lang/String;

    aput-object v4, v13, v3

    aput-object v4, v13, v2

    goto :goto_10

    :cond_2b
    iget-object v13, v13, Lc/R5;->h:[Ljava/lang/String;

    :goto_10
    iget-object v14, v0, Lc/T5;->z1:Lc/r5;

    iget-object v15, v0, Lc/T5;->g:Lc/j6;

    if-eqz v15, :cond_2d

    iget-boolean v10, v15, Lc/j6;->m:Z

    if-eqz v10, :cond_2c

    goto :goto_11

    :cond_2c
    move v10, v3

    goto :goto_12

    :cond_2d
    :goto_11
    move v10, v2

    :goto_12
    if-eqz v15, :cond_2e

    iget-boolean v4, v15, Lc/j6;->l:Z

    if-eqz v4, :cond_2e

    move v4, v2

    goto :goto_13

    :cond_2e
    move v4, v3

    :goto_13
    iget-boolean v6, v0, Lc/T5;->n0:Z

    iget-boolean v12, v0, Lc/T5;->o0:Z

    if-eqz v15, :cond_2f

    iget-boolean v15, v15, Lc/j6;->n:Z

    if-eqz v15, :cond_2f

    move v15, v2

    goto :goto_14

    :cond_2f
    move v15, v3

    :goto_14
    aget-object v7, v13, v3

    aget-object v13, v13, v2

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, " "

    invoke-virtual {v1, v2, v9}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    if-eqz v6, :cond_31

    if-nez v12, :cond_31

    invoke-virtual {v1, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_31

    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_30

    const-string v1, "STCAF0"

    goto :goto_15

    :cond_30
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "STCAF1,"

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_15
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    :goto_16
    move-object/from16 v16, v9

    goto/16 :goto_1d

    :cond_31
    const-string v2, "FCSH"

    const-string v3, "ATFCSH"

    if-eqz v6, :cond_38

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v16

    if-eqz v16, :cond_38

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {v1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    if-eqz v7, :cond_32

    invoke-virtual {v14, v2, v5}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_33

    :cond_32
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_33
    if-eqz v7, :cond_34

    if-eqz v13, :cond_34

    iget-object v1, v14, Lc/r5;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/HashMap;

    invoke-virtual {v1, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v13, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_34

    const/4 v1, 0x1

    goto :goto_17

    :cond_34
    const/4 v1, 0x0

    :goto_17
    if-nez v12, :cond_37

    if-nez v1, :cond_37

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "STCFCPA"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-nez v7, :cond_35

    move-object v7, v9

    :cond_35
    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ","

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v13, :cond_36

    move-object v13, v9

    :cond_36
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_37
    move-object v1, v3

    goto :goto_16

    :cond_38
    if-eqz v10, :cond_4e

    const-string v13, "AT(?:CAF|CFC)[01]"

    invoke-virtual {v1, v13}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_39

    const/4 v7, 0x5

    const/4 v13, 0x2

    invoke-virtual {v1, v13, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v16, v9

    invoke-virtual {v1, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v14, v13, v9}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3a

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_39
    move-object/from16 v16, v9

    :cond_3a
    const-string v7, "ATFCSM[012]"

    invoke-virtual {v1, v7}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3c

    const-string v7, "FCSM"

    const/4 v9, 0x6

    invoke-virtual {v1, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v14, v7, v13}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_3b

    const-string v7, "ATFCSM0"

    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_3c

    if-nez v5, :cond_3c

    if-eqz v8, :cond_3c

    const-string v5, "ATFCSM1"

    invoke-interface {v8, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3c

    :cond_3b
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_3c
    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3d

    const/4 v3, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v2, v5}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3e

    goto :goto_18

    :cond_3d
    const/4 v3, 0x6

    :goto_18
    const-string v2, "ATFCSD"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3f

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-le v2, v3, :cond_3f

    const-string v2, "FCSD"

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v14, v2, v5}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_3f

    :cond_3e
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_3f
    const-string v2, "ATCRA"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    const-string v5, "ATAR"

    const-string v7, "00000000"

    const-string v8, "000"

    const-string v9, "CM"

    if-eqz v3, :cond_48

    const-string v3, "CRA"

    const/4 v6, 0x5

    invoke-virtual {v1, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v14, v3, v10}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_40

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_40
    iget-object v3, v14, Lc/r5;->a:Ljava/lang/Object;

    check-cast v3, Ljava/util/HashMap;

    invoke-virtual {v3, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    if-nez v4, :cond_41

    goto :goto_1c

    :cond_41
    invoke-virtual {v8, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_43

    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_42

    goto :goto_19

    :cond_42
    const/4 v3, 0x0

    goto :goto_1a

    :cond_43
    :goto_19
    const/4 v3, 0x1

    :goto_1a
    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_45

    if-eqz v3, :cond_44

    :goto_1b
    move-object/from16 v1, v16

    goto :goto_1c

    :cond_44
    const-string v1, "ATCM000"

    goto :goto_1c

    :cond_45
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_46

    if-eqz v3, :cond_46

    goto :goto_1b

    :cond_46
    :goto_1c
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_47

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_47
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_48
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4a

    if-eqz v4, :cond_4a

    invoke-virtual {v14, v9, v8}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_49

    invoke-virtual {v14, v9, v7}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4a

    :cond_49
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_4a
    invoke-virtual {v1, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4b

    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_4b

    const-string v2, "CEA"

    const/4 v3, 0x5

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v2, v4}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4b

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_4b
    const-string v2, "ATCP"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4c

    const-string v2, "CP"

    const/4 v3, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v2, v4}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4c

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_4c
    const-string v2, "ATSP[1-9B-F]"

    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    const/16 v3, 0x10

    const-string v4, "SP"

    if-eqz v2, :cond_4d

    const/4 v2, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v14, v4, v2}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4d

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto/16 :goto_1d

    :cond_4d
    const-string v2, "STP[0-9A-F]{2}"

    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4f

    const/4 v2, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v14, v4, v2}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4f

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto :goto_1d

    :cond_4e
    move-object/from16 v16, v9

    :cond_4f
    const-string v2, "ATTA[0-9A-F]{2}"

    invoke-virtual {v1, v2}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_54

    if-eqz v10, :cond_50

    const-string v2, "TA"

    const/4 v3, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v14, v2, v4}, Lc/r5;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_51

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    goto :goto_1d

    :cond_50
    const/4 v3, 0x4

    :cond_51
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "ATCER"

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    if-eqz v15, :cond_52

    invoke-static {v2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto :goto_1d

    :cond_52
    if-eqz v6, :cond_53

    if-eqz v12, :cond_53

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto :goto_1d

    :cond_53
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    goto :goto_1d

    :cond_54
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    :goto_1d
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_55

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_55
    const/4 v2, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    move-object v2, v3

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v3

    const/4 v4, 0x1

    sub-int/2addr v3, v4

    :goto_1e
    if-lez v3, :cond_56

    iget-object v4, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    add-int/lit8 v3, v3, -0x1

    goto :goto_1e

    :cond_56
    move-object v1, v2

    :goto_1f
    const-string v2, "REINIT"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_5e

    const/4 v2, 0x0

    iput-object v2, v0, Lc/T5;->q0:Lc/n6;

    iput-object v2, v0, Lc/T5;->s0:Lc/l6;

    iget v1, v0, Lc/T5;->U:I

    iput v1, v0, Lc/T5;->T:I

    new-instance v1, Ljava/util/ArrayDeque;

    iget-object v2, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-direct {v1, v2}, Ljava/util/ArrayDeque;-><init>(Ljava/util/Collection;)V

    iget-object v2, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iget-object v2, v0, Lc/T5;->X:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_57

    iget-object v2, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    iget-object v3, v0, Lc/T5;->X:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    :cond_57
    iget-object v2, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v2, v1}, Ljava/util/ArrayDeque;->addAll(Ljava/util/Collection;)Z

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_58

    iget-boolean v2, v1, Lc/j6;->h:Z

    if-eqz v2, :cond_58

    const/4 v2, 0x1

    goto :goto_20

    :cond_58
    const/4 v2, 0x0

    :goto_20
    iget v5, v0, Lc/T5;->V:I

    if-nez v1, :cond_59

    move-object/from16 v1, v16

    goto :goto_21

    :cond_59
    iget-object v1, v1, Lc/j6;->e:Ljava/lang/String;

    :goto_21
    if-ltz v5, :cond_5d

    const/16 v3, 0x2d

    if-gt v5, v3, :cond_5d

    if-nez v1, :cond_5a

    move-object/from16 v1, v16

    :cond_5a
    const-string v3, "Toyota"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_5b

    const-string v3, "Lexus"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    :cond_5b
    new-instance v1, Lc/l6;

    const/4 v8, 0x0

    const/4 v3, 0x1

    xor-int/lit8 v9, v8, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x1

    move-object v3, v1

    move v7, v2

    invoke-direct/range {v3 .. v9}, Lc/l6;-><init>(IIIZZI)V

    new-instance v11, Lc/a6;

    iget v4, v0, Lc/T5;->V:I

    iget-object v3, v0, Lc/T5;->g:Lc/j6;

    if-nez v3, :cond_5c

    move-object/from16 v7, v16

    goto :goto_22

    :cond_5c
    iget-object v3, v3, Lc/j6;->x:Ljava/util/ArrayList;

    const-string v5, ";"

    invoke-static {v5, v3}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    move-object v7, v3

    :goto_22
    iget-object v8, v0, Lc/T5;->Y:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->v()Ljava/lang/String;

    move-result-object v9

    iget v3, v0, Lc/T5;->V:I

    invoke-virtual {v0, v3, v2}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v10

    const/4 v5, 0x1

    move-object v3, v11

    move v6, v2

    invoke-direct/range {v3 .. v10}, Lc/a6;-><init>(IIZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lc/c6;

    invoke-direct {v2, v11, v1}, Lc/c6;-><init>(Lc/a6;Lc/l6;)V

    iput-object v2, v0, Lc/T5;->O0:Lc/c6;

    move-object/from16 v2, v16

    iput-object v2, v0, Lc/T5;->P:Ljava/lang/String;

    iput-object v2, v0, Lc/T5;->R:Ljava/lang/String;

    iget-object v1, v0, Lc/T5;->y1:Lc/R1;

    invoke-virtual {v1}, Lc/R1;->c()V

    iget-object v1, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Z()V

    return-void

    :cond_5d
    new-instance v1, Ljava/lang/IllegalArgumentException;

    const-string v2, "Invalid search parameters"

    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_5e
    move-object/from16 v2, v16

    const-string v3, "VWTP:"

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_64

    const/4 v3, 0x0

    :try_start_0
    invoke-static {v1, v3}, Lc/k6;->u0(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    iget v3, v0, Lc/T5;->T:I

    iput v3, v0, Lc/T5;->E0:I

    iget-object v3, v0, Lc/T5;->B0:Ljava/util/HashMap;

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/k7;

    iput-object v3, v0, Lc/T5;->C0:Lc/k7;

    if-nez v3, :cond_62

    new-instance v3, Ljava/util/HashSet;

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    iget-object v4, v0, Lc/T5;->B0:Ljava/util/HashMap;

    invoke-virtual {v4}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_5f
    :goto_23
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_60

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/k7;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-boolean v8, v5, Lc/k7;->q:Z

    if-eqz v8, :cond_5f

    iget-boolean v8, v5, Lc/k7;->s:Z

    if-nez v8, :cond_5f

    iget-wide v8, v5, Lc/k7;->t:J

    sub-long/2addr v6, v8

    const-wide/16 v8, 0x802

    cmp-long v6, v6, v8

    if-gtz v6, :cond_5f

    iget-object v5, v5, Lc/k7;->i:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_23

    :cond_60
    const/16 v4, 0x300

    :goto_24
    const/16 v5, 0x3ff

    if-ge v4, v5, :cond_61

    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    filled-new-array {v6}, [Ljava/lang/Object;

    move-result-object v6

    const-string v7, "%03X"

    invoke-static {v5, v7, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_61

    add-int/lit8 v4, v4, 0x1

    goto :goto_24

    :cond_61
    new-instance v3, Lc/k7;

    invoke-direct {v3, v2, v4}, Lc/k7;-><init>(Ljava/lang/String;I)V

    iput-object v3, v0, Lc/T5;->C0:Lc/k7;

    iget-object v4, v0, Lc/T5;->B0:Ljava/util/HashMap;

    invoke-virtual {v4, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_62
    :try_start_1
    iget-object v2, v0, Lc/T5;->C0:Lc/k7;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4, v1}, Lc/k7;->c(JLjava/lang/String;)Lc/j7;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->D0:Lc/j7;
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    invoke-virtual/range {p0 .. p0}, Lc/T5;->C0()V

    return-void

    :catch_0
    const/4 v2, 0x0

    iput-object v2, v0, Lc/T5;->C0:Lc/k7;

    invoke-virtual {v0, v2, v2}, Lc/T5;->B([B[B)Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->T0()V

    const-string v2, "Unsupported VWTP query"

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->V0()Z

    move-result v1

    if-eqz v1, :cond_63

    const-string v1, "\u041d\u0435\u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043c\u044b\u0439 \u0437\u0430\u043f\u0440\u043e\u0441 VWTP"

    invoke-virtual {v0, v1}, Lc/T5;->N(Ljava/lang/String;)V

    :cond_63
    invoke-virtual/range {p0 .. p0}, Lc/T5;->u()V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    iget-object v1, v0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, v0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_64
    const/4 v3, 0x0

    :catch_1
    iget-object v4, v0, Lc/T5;->P0:Lc/b6;

    if-nez v4, :cond_6c

    iget-object v4, v0, Lc/T5;->a1:Lc/R5;

    if-eqz v4, :cond_6c

    iget-object v4, v4, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6c

    iget v4, v0, Lc/T5;->T:I

    const/4 v5, 0x6

    if-lt v4, v5, :cond_6c

    const/16 v5, 0x9

    if-gt v4, v5, :cond_6c

    iget-object v4, v0, Lc/T5;->a1:Lc/R5;

    iget-object v4, v4, Lc/R5;->f:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_65
    :goto_25
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_67

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-virtual {v5, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_65

    invoke-virtual {v5, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_66

    goto :goto_25

    :cond_66
    const/4 v3, 0x1

    goto :goto_25

    :cond_67
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    if-eqz v3, :cond_68

    const/16 v3, 0xc

    goto :goto_26

    :cond_68
    const/16 v3, 0xe

    :goto_26
    if-le v4, v3, :cond_6b

    iput-object v1, v0, Lc/T5;->J0:Ljava/lang/String;

    new-instance v3, Lc/e6;

    iget v4, v0, Lc/T5;->T:I

    iget-object v5, v0, Lc/T5;->a1:Lc/R5;

    iget-object v5, v5, Lc/R5;->f:Ljava/util/List;

    iget-object v6, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v7, "can_upload_atr0"

    const/4 v8, 0x1

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v21

    iget-boolean v6, v0, Lc/T5;->n0:Z

    iget-object v7, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    iget-object v8, v0, Lc/T5;->g:Lc/j6;

    if-nez v8, :cond_69

    move-object v9, v2

    goto :goto_27

    :cond_69
    iget-object v9, v8, Lc/j6;->e:Ljava/lang/String;

    :goto_27
    const-string v2, "Tank"

    const-string v8, "WEY"

    const-string v10, "Haval"

    const-string v11, "Great Wall"

    filled-new-array {v10, v11, v2, v8}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2, v9}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x1

    xor-int/2addr v2, v8

    const-string v8, "stn_segmentation"

    invoke-interface {v7, v8, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v23

    iget-boolean v2, v0, Lc/T5;->M0:Z

    iget-object v7, v0, Lc/T5;->g:Lc/j6;

    if-nez v7, :cond_6a

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v7

    :goto_28
    move-object/from16 v25, v7

    goto :goto_29

    :cond_6a
    iget-object v7, v7, Lc/j6;->q:Ljava/lang/String;

    invoke-static {v7}, Lc/G8;->Q0(Ljava/lang/String;)Ljava/util/List;

    move-result-object v7

    goto :goto_28

    :goto_29
    move-object/from16 v17, v3

    move-object/from16 v18, v1

    move/from16 v19, v4

    move-object/from16 v20, v5

    move/from16 v22, v6

    move/from16 v24, v2

    invoke-direct/range {v17 .. v25}, Lc/e6;-><init>(Ljava/lang/String;ILjava/util/List;ZZZZLjava/util/List;)V

    iput-object v3, v0, Lc/T5;->H0:Lc/e6;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v3, v1, v2}, Lc/e6;->b(J)Lc/d6;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->I0:Lc/d6;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->B0()V

    return-void

    :cond_6b
    iget-object v2, v0, Lc/T5;->a1:Lc/R5;

    iget-object v2, v2, Lc/R5;->c:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_6c

    iget-object v2, v0, Lc/T5;->N0:Ljava/util/HashSet;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->X()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6c

    invoke-virtual {v0, v1}, Lc/T5;->J0(Ljava/lang/String;)V

    return-void

    :cond_6c
    invoke-virtual {v0, v1}, Lc/T5;->O0(Ljava/lang/String;)V

    :cond_6d
    :goto_2a
    return-void
.end method

.method public final Z0()V
    .locals 2

    iget-boolean v0, p0, Lc/T5;->F1:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    if-nez v0, :cond_0

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method

.method public final a0()V
    .locals 9

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string v2, "\u041d\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f Bluetooth"

    iget-object v3, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-nez v3, :cond_0

    return-void

    :cond_0
    iget-object v3, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->X1:Lc/A5;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v5, p0, Lc/T5;->Y1:Lc/A5;

    invoke-virtual {v3, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v5, 0x0

    :try_start_0
    iget-object v6, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eqz v6, :cond_1

    iget-object v7, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    invoke-virtual {v7, v6, v5}, Landroid/bluetooth/BluetoothGatt;->setCharacteristicNotification(Landroid/bluetooth/BluetoothGattCharacteristic;Z)Z
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_1

    :cond_1
    const/4 v6, 0x0

    iput-object v6, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iput-object v6, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iput-object v6, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    iput-boolean v5, p0, Lc/T5;->V1:Z

    iput-boolean v5, p0, Lc/T5;->U1:Z

    new-array v6, v5, [[B

    iput-object v6, p0, Lc/T5;->S1:[[B

    iget v6, p0, Lc/T5;->O1:I

    iget-object v7, p0, Lc/T5;->N1:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-lt v6, v8, :cond_2

    iput-boolean v5, p0, Lc/T5;->T1:Z

    const-string v0, "\u041d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u043a\u0430\u043d\u0430\u043b ELM \u0432 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0435 BLE"

    invoke-virtual {p0, v5, v0}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :cond_2
    iget v6, p0, Lc/T5;->O1:I

    add-int/lit8 v8, v6, 0x1

    iput v8, p0, Lc/T5;->O1:I

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lc/t5;

    iget-object v7, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v8, v6, Lc/t5;->a:Ljava/util/UUID;

    invoke-virtual {v7, v8}, Landroid/bluetooth/BluetoothGatt;->getService(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattService;

    move-result-object v7

    if-nez v7, :cond_3

    invoke-virtual {p0}, Lc/T5;->a0()V

    return-void

    :cond_3
    iget-object v8, v6, Lc/t5;->b:Ljava/util/UUID;

    invoke-virtual {v7, v8}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object v8

    iput-object v8, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v6, v6, Lc/t5;->c:Ljava/util/UUID;

    invoke-virtual {v7, v6}, Landroid/bluetooth/BluetoothGattService;->getCharacteristic(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattCharacteristic;

    move-result-object v6

    iput-object v6, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v7, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eqz v7, :cond_a

    if-nez v6, :cond_4

    goto/16 :goto_3

    :cond_4
    iput-boolean v0, p0, Lc/T5;->T1:Z

    iget-object v6, p0, Lc/T5;->W1:Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    iput v5, p0, Lc/T5;->P1:I

    iget-object v6, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v6}, Landroid/bluetooth/BluetoothGattCharacteristic;->getProperties()I

    move-result v6

    and-int/lit8 v7, v6, 0x30

    if-eqz v7, :cond_9

    and-int/lit8 v7, v6, 0x20

    if-eqz v7, :cond_5

    and-int/lit8 v7, v6, 0x10

    if-eqz v7, :cond_5

    new-array v6, v1, [B

    fill-array-data v6, :array_0

    new-array v1, v1, [B

    fill-array-data v1, :array_1

    filled-new-array {v6, v1}, [[B

    move-result-object v1

    goto :goto_1

    :cond_5
    and-int/lit8 v6, v6, 0x10

    if-eqz v6, :cond_6

    new-array v1, v1, [B

    aput-byte v0, v1, v5

    aput-byte v5, v1, v0

    goto :goto_0

    :cond_6
    new-array v6, v1, [B

    aput-byte v1, v6, v5

    aput-byte v5, v6, v0

    move-object v1, v6

    :goto_0
    filled-new-array {v1}, [[B

    move-result-object v1

    :goto_1
    iput-object v1, p0, Lc/T5;->R1:[[B

    iget-object v1, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    sget-object v6, Lc/t5;->d:Ljava/util/UUID;

    invoke-virtual {v1, v6}, Landroid/bluetooth/BluetoothGattCharacteristic;->getDescriptor(Ljava/util/UUID;)Landroid/bluetooth/BluetoothGattDescriptor;

    move-result-object v1

    iput-object v1, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    if-nez v1, :cond_7

    iget-object v1, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothGattCharacteristic;->getDescriptors()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothGattCharacteristic;->getDescriptors()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/bluetooth/BluetoothGattDescriptor;

    iput-object v1, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    :cond_7
    const-string v1, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430 BLE"

    iput-object v1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    const-wide/16 v6, 0x1388

    invoke-virtual {v3, v4, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :try_start_1
    iget-object v1, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v3, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v1, v3, v0}, Landroid/bluetooth/BluetoothGatt;->setCharacteristicNotification(Landroid/bluetooth/BluetoothGattCharacteristic;Z)Z

    move-result v0

    if-nez v0, :cond_8

    invoke-virtual {p0}, Lc/T5;->a0()V

    return-void

    :cond_8
    invoke-virtual {p0}, Lc/T5;->h1()V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_2

    :catch_0
    invoke-virtual {p0, v5, v2}, Lc/T5;->J(ZLjava/lang/String;)V

    :goto_2
    return-void

    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "BLE channel cannot update"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    :goto_3
    invoke-virtual {p0}, Lc/T5;->a0()V

    return-void

    :catch_1
    invoke-virtual {p0, v5, v2}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :array_0
    .array-data 1
        0x2t
        0x0t
    .end array-data

    nop

    :array_1
    .array-data 1
        0x1t
        0x0t
    .end array-data
.end method

.method public final a1(I)Lc/i6;
    .locals 5

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "="

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lc/T5;->b1()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_2

    goto :goto_0

    :cond_2
    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v3, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    if-eqz v2, :cond_1

    iget-boolean v3, v2, Lc/i6;->v:Z

    if-eqz v3, :cond_1

    return-object v2

    :cond_3
    return-object v1
.end method

.method public final b0()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    const-string v0, "01"

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/j6;->o:Ljava/lang/String;

    :goto_0
    return-object v0
.end method

.method public final b1()Ljava/util/Set;
    .locals 4

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/util/LinkedHashSet;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "widget_bindings_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    iget-object v2, v2, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v2

    iget-object v3, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    :goto_0
    return-object v0
.end method

.method public final c()Landroid/bluetooth/BluetoothAdapter;
    .locals 2

    iget-object v0, p0, Lc/T5;->a:Landroid/content/Context;

    const-class v1, Landroid/bluetooth/BluetoothManager;

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/bluetooth/BluetoothManager;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public final c0(Z)V
    .locals 6

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-nez v0, :cond_5

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "enabled"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_0

    goto/16 :goto_3

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->w:Z

    iget-object v1, p0, Lc/T5;->v:Lc/s5;

    invoke-virtual {v1}, Lc/s5;->a()V

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "battery_parked"

    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "battery_watch"

    invoke-interface {v1, v3, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x0

    iput-object v1, p0, Lc/T5;->r0:Lc/n6;

    iput-boolean v2, p0, Lc/T5;->o1:Z

    iget-object v3, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lc/T5;->L0()V

    iget-object v3, p0, Lc/T5;->K:Ljava/io/OutputStream;

    if-nez v3, :cond_2

    iget-object v3, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-eqz v3, :cond_1

    iget-object v3, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-eqz v3, :cond_1

    goto :goto_0

    :cond_1
    move v3, v2

    goto :goto_1

    :cond_2
    :goto_0
    move v3, v0

    :goto_1
    iput-boolean p1, p0, Lc/T5;->B:Z

    if-nez v3, :cond_3

    invoke-virtual {p0}, Lc/T5;->s()V

    goto/16 :goto_2

    :cond_3
    iput-boolean v0, p0, Lc/T5;->A:Z

    const-string v0, "\u05d4\u05d1\u05d3\u05d9\u05e7\u05d4 \u05e0\u05e2\u05e6\u05e8\u05d4: \u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8"

    invoke-virtual {p0, v0}, Lc/T5;->N(Ljava/lang/String;)V

    invoke-virtual {p0}, Lc/T5;->z0()V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->q1:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->Y1:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->X1:Lc/A5;

    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v2, p0, Lc/T5;->V1:Z

    iput-boolean v2, p0, Lc/T5;->U1:Z

    iput-boolean v2, p0, Lc/T5;->T1:Z

    iget-object v0, p0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    iget-object v0, p0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    iget-object v0, p0, Lc/T5;->V0:Lc/v8;

    iget-object v0, v0, Lc/v8;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    iget-object v0, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v0, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    iget-object v0, p0, Lc/T5;->R0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lc/T5;->S0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lc/T5;->T0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iput-object v1, p0, Lc/T5;->a1:Lc/R5;

    iput-object v1, p0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    iput-boolean v2, p0, Lc/T5;->c1:Z

    iput-boolean v2, p0, Lc/T5;->z:Z

    new-array v0, v2, [[B

    iput-object v0, p0, Lc/T5;->S1:[[B

    iput-object v1, p0, Lc/T5;->F0:Lc/g6;

    iput-object v1, p0, Lc/T5;->G0:Lc/f6;

    iput-object v1, p0, Lc/T5;->H0:Lc/e6;

    iput-object v1, p0, Lc/T5;->I0:Lc/d6;

    iput-object v1, p0, Lc/T5;->C0:Lc/k7;

    iput-object v1, p0, Lc/T5;->D0:Lc/j7;

    iget-object v0, p0, Lc/T5;->B0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iput-object v1, p0, Lc/T5;->O0:Lc/c6;

    iput-object v1, p0, Lc/T5;->P0:Lc/b6;

    iput-object v1, p0, Lc/T5;->q0:Lc/n6;

    iput-boolean v2, p0, Lc/T5;->l0:Z

    iput-boolean v2, p0, Lc/T5;->i0:Z

    iput-boolean v2, p0, Lc/T5;->e1:Z

    iput-boolean v2, p0, Lc/T5;->d1:Z

    iput-boolean v2, p0, Lc/T5;->F1:Z

    iget-object v0, p0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    const-wide/16 v4, 0x0

    iput-wide v4, p0, Lc/T5;->x2:J

    iput-wide v4, p0, Lc/T5;->q2:J

    iput-object v1, p0, Lc/T5;->t2:Lc/X5;

    const-string v0, "\u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8 \u00b7 \u05e1\u05d5\u05d2\u05e8 \u05d0\u05ea \u05d7\u05d9\u05d1\u05d5\u05e8 \u05d4-ELM"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->F:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->G:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->H:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->G:Lc/A5;

    const-wide/16 v4, 0x1f4

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->H:Lc/A5;

    const-wide/16 v4, 0x1388

    invoke-virtual {v0, v1, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_2
    if-nez v3, :cond_4

    const-string v0, "OBD \u05d1\u05d4\u05de\u05ea\u05e0\u05d4 - \u05d4\u05d2\u05e0\u05ea \u05de\u05e6\u05d1\u05e8"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    if-eqz p1, :cond_4

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v0, p0, Lc/T5;->g2:Lc/A5;

    const-wide/32 v1, 0xea60

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    invoke-virtual {p0}, Lc/T5;->q()V

    :cond_5
    :goto_3
    return-void
.end method

.method public final c1(ZLjava/lang/String;)V
    .locals 4

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, v0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/i6;

    if-eqz v0, :cond_6

    if-eqz p1, :cond_1

    iget-boolean v1, v0, Lc/i6;->v:Z

    if-nez v1, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v1

    if-eqz p1, :cond_2

    invoke-interface {v1, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_3

    goto :goto_0

    :cond_2
    invoke-interface {v1, p2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_4

    :cond_3
    return-void

    :cond_4
    :goto_0
    iget-object p2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {p2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "widget_sensors_"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v3, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {p2, v2, v1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    if-eqz p1, :cond_5

    invoke-virtual {p0, v0}, Lc/T5;->v0(Lc/i6;)V

    new-instance p1, Ljava/util/HashSet;

    iget-object v0, p0, Lc/T5;->h1:Ljava/util/HashSet;

    invoke-direct {p1, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const-string v0, "disabled_sensor_ids"

    invoke-interface {p2, v0, p1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    :cond_5
    invoke-interface {p2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->q()V

    :cond_6
    :goto_1
    return-void
.end method

.method public final d0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    .locals 2

    iget v0, p0, Lc/T5;->T:I

    if-nez v0, :cond_0

    invoke-static {p1, p2, p3}, Lc/k6;->Y(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    return-object p1

    :cond_0
    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, 0x2

    if-ne v0, v1, :cond_1

    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x10

    invoke-static {v0, v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v0

    rem-int/lit8 v0, v0, 0x20

    if-nez v0, :cond_1

    iget v0, p0, Lc/T5;->T:I

    invoke-static {v0, p1, p2, p3}, Lc/k6;->F(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    goto :goto_0

    :cond_1
    iget v0, p0, Lc/T5;->T:I

    invoke-static {v0, p1, p2, p3}, Lc/k6;->Z(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B

    move-result-object p1

    :goto_0
    return-object p1
.end method

.method public final d1()Ljava/util/Set;
    .locals 4

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v0

    return-object v0

    :cond_0
    new-instance v0, Ljava/util/LinkedHashSet;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "widget_sensors_"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    iget-object v2, v2, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v2

    iget-object v3, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v3, v1, v2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    return-object v0
.end method

.method public final e(Lc/R5;Lc/i6;)V
    .locals 5

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p1, Lc/R5;->c:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v1, p0, Lc/T5;->Q:Ljava/lang/String;

    :cond_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "@"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p1, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p1, Lc/R5;->f:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    iget-object v2, p1, Lc/R5;->g:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    const-string v1, ""

    goto :goto_0

    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p1, Lc/R5;->f:Ljava/util/List;

    const-string v4, ";"

    invoke-static {v4, v3}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p1, Lc/R5;->g:Ljava/util/List;

    invoke-static {v4, v1}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/R5;

    if-nez v2, :cond_2

    invoke-interface {v1, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    iget v0, v2, Lc/R5;->i:I

    iget p1, p1, Lc/R5;->i:I

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    iput p1, v2, Lc/R5;->i:I

    move-object p1, v2

    :goto_1
    if-eqz p2, :cond_3

    iget-object p1, p1, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    return-void
.end method

.method public final e0()Z
    .locals 6

    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v0

    const-string v1, "wifi"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_6

    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v0

    const-string v2, "usb"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v0

    const-string v2, "spp"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v2, "android.permission.BLUETOOTH_CONNECT"

    const/16 v3, 0x1f

    const/4 v4, 0x0

    iget-object v5, p0, Lc/T5;->a:Landroid/content/Context;

    if-eqz v0, :cond_3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v3, :cond_2

    invoke-virtual {v5, v2}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    move v1, v4

    :cond_2
    :goto_0
    return v1

    :cond_3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v3, :cond_5

    invoke-virtual {v5, v2}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_4

    const-string v0, "android.permission.BLUETOOTH_SCAN"

    invoke-virtual {v5, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_4

    goto :goto_1

    :cond_4
    move v1, v4

    goto :goto_1

    :cond_5
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {v5, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_4

    :cond_6
    :goto_1
    return v1
.end method

.method public final e1()Ljava/util/ArrayList;
    .locals 5

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    if-nez v1, :cond_0

    return-object v0

    :cond_0
    invoke-virtual {p0}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v1

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    iget-object v2, v2, Lc/j6;->y:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc/i6;

    iget-object v4, v3, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method public final f(Lc/i6;Ljava/util/HashSet;)V
    .locals 12

    iget-object v0, p0, Lc/T5;->o:Ljava/util/HashSet;

    iget-object v1, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    iget-boolean v1, p1, Lc/i6;->v:Z

    if-eqz v1, :cond_10

    iget-object v1, p0, Lc/T5;->h1:Ljava/util/HashSet;

    iget-object v2, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10

    invoke-virtual {p2, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_10

    invoke-virtual {p2}, Ljava/util/HashSet;->size()I

    move-result v1

    const/16 v3, 0x40

    if-le v1, v3, :cond_0

    goto/16 :goto_5

    :cond_0
    iget-object v1, p1, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x0

    iget v6, p1, Lc/i6;->p:I

    if-eqz v4, :cond_b

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v7, p0, Lc/T5;->g:Lc/j6;

    invoke-virtual {v7, v4}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v7

    if-eqz v7, :cond_2

    invoke-virtual {p0, v7, p2}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_0

    :cond_2
    invoke-static {v4}, Lc/G8;->F(Ljava/lang/String;)Lc/v5;

    move-result-object v7

    const/4 v8, 0x0

    if-nez v7, :cond_5

    const-string v7, "Vehicle speed"

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_3

    sget-object v4, Lc/G8;->v:Lc/v5;

    :goto_1
    move-object v7, v4

    goto :goto_2

    :cond_3
    const-string v7, "Altitude (GPS)"

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4

    sget-object v4, Lc/G8;->s:Lc/v5;

    goto :goto_1

    :cond_4
    move-object v7, v8

    :cond_5
    :goto_2
    iget-object v4, p0, Lc/T5;->d:Ljava/util/HashSet;

    const-string v9, ""

    if-eqz v7, :cond_8

    const/4 v10, 0x3

    iget v11, v7, Lc/v5;->b:I

    if-ne v11, v10, :cond_8

    const/16 v6, 0xd

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v4, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_6

    new-instance v4, Lc/R5;

    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v6}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v4, v6, v7, v9, v5}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v4, v8}, Lc/T5;->e(Lc/R5;Lc/i6;)V

    goto :goto_0

    :cond_6
    iget-object v4, p0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_7
    :goto_3
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lc/i6;

    iget v6, v5, Lc/i6;->j:I

    const/4 v7, 0x5

    if-ne v6, v7, :cond_7

    invoke-virtual {p0, v5, p2}, Lc/T5;->f(Lc/i6;Ljava/util/HashSet;)V

    goto :goto_3

    :cond_8
    if-eqz v7, :cond_1

    const/4 v5, 0x1

    iget v10, v7, Lc/v5;->b:I

    if-ne v10, v5, :cond_1

    const/16 v5, 0xb9

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-virtual {v4, v10}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_9

    goto/16 :goto_0

    :cond_9
    new-instance v4, Lc/R5;

    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v5}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v4, v5, v10, v9, v6}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, v4, v8}, Lc/T5;->e(Lc/R5;Lc/i6;)V

    iget-object v5, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v8, p0, Lc/T5;->Q:Ljava/lang/String;

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "@"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v4, Lc/R5;->b:Ljava/lang/String;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/R5;

    iget-object v5, v4, Lc/R5;->e:Ljava/util/ArrayList;

    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a

    goto/16 :goto_0

    :cond_a
    iget-object v4, v4, Lc/R5;->e:Ljava/util/ArrayList;

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_0

    :cond_b
    iget-boolean v3, p1, Lc/i6;->y:Z

    if-nez v3, :cond_c

    invoke-interface {v1}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d

    :cond_c
    iget-object v1, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_d
    if-nez v3, :cond_f

    new-instance v1, Lc/R5;

    iget-object v3, p0, Lc/T5;->n:Ljava/util/LinkedHashSet;

    invoke-interface {v3, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e

    goto :goto_4

    :cond_e
    move v5, v6

    :goto_4
    iget-object v3, p1, Lc/i6;->f:Ljava/lang/String;

    iget-object v4, p1, Lc/i6;->g:Ljava/lang/String;

    const/4 v6, -0x1

    invoke-direct {v1, v6, v3, v4, v5}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    iget-object v3, p1, Lc/i6;->A:Ljava/util/List;

    iput-object v3, v1, Lc/R5;->f:Ljava/util/List;

    iget-object v3, p1, Lc/i6;->B:Ljava/util/List;

    iput-object v3, v1, Lc/R5;->g:Ljava/util/List;

    invoke-virtual {p0, v1, p1}, Lc/T5;->e(Lc/R5;Lc/i6;)V

    :cond_f
    invoke-virtual {p2, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_10
    :goto_5
    return-void
.end method

.method public final f0(Lorg/json/JSONObject;)Lc/i6;
    .locals 4

    invoke-virtual {p0}, Lc/T5;->s0()V

    iget-object v0, p0, Lc/T5;->h:Lc/j6;

    new-instance v1, Lc/f7;

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x0

    invoke-direct {v1, v2, v0, p1, v3}, Lc/f7;-><init>(Landroid/content/SharedPreferences;Lc/j6;Lorg/json/JSONObject;I)V

    invoke-static {v1}, Lc/k6;->i(Lc/h7;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/j6;

    const-string v1, "Id"

    const-string v2, ""

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object v1, v0, Lc/j6;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/i6;

    if-nez p1, :cond_2

    iget-object v0, v0, Lc/j6;->y:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    iget-boolean v2, v1, Lc/i6;->z:Z

    if-eqz v2, :cond_0

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    if-eqz v2, :cond_1

    iget-object v2, v2, Lc/j6;->v:Ljava/util/LinkedHashMap;

    iget-object v3, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_0

    :cond_1
    move-object p1, v1

    goto :goto_0

    :cond_2
    if-eqz p1, :cond_3

    return-object p1

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "PID \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final f1()Ljava/lang/String;
    .locals 4

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    const-string v0, ""

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    iget-object v1, v1, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    iget-object v2, v2, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lc/T5;->i:J

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v2, Ljava/util/TreeSet;

    invoke-virtual {p0}, Lc/T5;->d1()Ljava/util/Set;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/util/TreeSet;

    invoke-virtual {p0}, Lc/T5;->b1()Ljava/util/Set;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/util/TreeSet;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_0
    return-object v0
.end method

.method public final g()I
    .locals 3

    const/16 v0, 0x24

    :goto_0
    iget-object v1, p0, Lc/T5;->d:Ljava/util/HashSet;

    const/16 v2, 0x2b

    if-gt v0, v2, :cond_1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_0

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return v0

    :cond_1
    const/16 v0, 0x34

    :goto_1
    const/16 v2, 0x3b

    if-gt v0, v2, :cond_3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_2
    return v0

    :cond_3
    const/16 v0, 0x44

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    goto :goto_2

    :cond_4
    const/4 v0, -0x1

    :goto_2
    return v0
.end method

.method public final g0()I
    .locals 3

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    iget v0, v0, Lc/j6;->f:I

    :goto_0
    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "protocol"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    return v0
.end method

.method public final g1()V
    .locals 6

    iget-boolean v0, p0, Lc/T5;->w:Z

    const/4 v1, 0x2

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->z:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->A:Z

    if-eqz v0, :cond_0

    const-string v0, "ATPC"

    iget-object v2, p0, Lc/T5;->a2:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    :cond_0
    iget-boolean v0, p0, Lc/T5;->T1:Z

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    if-eq v0, v1, :cond_2

    :cond_1
    return-void

    :cond_2
    iget-object v0, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-eqz v0, :cond_a

    iget-object v0, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    if-nez v0, :cond_3

    goto/16 :goto_3

    :cond_3
    iget v2, p0, Lc/T5;->Q1:I

    iget-object v3, p0, Lc/T5;->S1:[[B

    array-length v3, v3

    const/4 v4, 0x0

    if-lt v2, v3, :cond_5

    new-array v0, v4, [[B

    iput-object v0, p0, Lc/T5;->S1:[[B

    iget-boolean v0, p0, Lc/T5;->T1:Z

    if-eqz v0, :cond_4

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->Y1:Lc/A5;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_0

    :cond_4
    invoke-virtual {p0}, Lc/T5;->i1()V

    :goto_0
    return-void

    :cond_5
    :try_start_0
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGattCharacteristic;->getProperties()I

    move-result v2

    sget-object v3, Lc/t5;->d:Ljava/util/UUID;

    and-int/lit8 v3, v2, 0xc

    const/4 v5, 0x1

    if-eqz v3, :cond_6

    move v3, v5

    goto :goto_1

    :cond_6
    move v3, v4

    :goto_1
    if-eqz v3, :cond_9

    and-int/lit8 v2, v2, 0x8

    if-eqz v2, :cond_7

    goto :goto_2

    :cond_7
    move v1, v5

    :goto_2
    invoke-virtual {v0, v1}, Landroid/bluetooth/BluetoothGattCharacteristic;->setWriteType(I)V

    iget-object v0, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v1, p0, Lc/T5;->S1:[[B

    iget v2, p0, Lc/T5;->Q1:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Landroid/bluetooth/BluetoothGattCharacteristic;->setValue([B)Z

    iput-boolean v5, p0, Lc/T5;->U1:Z

    iget-object v0, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v1, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    invoke-virtual {v0, v1}, Landroid/bluetooth/BluetoothGatt;->writeCharacteristic(Landroid/bluetooth/BluetoothGattCharacteristic;)Z

    move-result v0

    if-nez v0, :cond_a

    iput-boolean v4, p0, Lc/T5;->U1:Z

    iget-boolean v0, p0, Lc/T5;->T1:Z

    if-eqz v0, :cond_8

    invoke-virtual {p0}, Lc/T5;->a0()V

    goto :goto_3

    :cond_8
    const-string v0, "\u0410\u0434\u0430\u043f\u0442\u0435\u0440 \u0437\u0430\u043d\u044f\u0442"

    invoke-virtual {p0, v4, v0}, Lc/T5;->J(ZLjava/lang/String;)V

    goto :goto_3

    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "BLE channel is not writable"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const-string v0, "\u041d\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f Bluetooth"

    invoke-virtual {p0, v4, v0}, Lc/T5;->J(ZLjava/lang/String;)V

    :cond_a
    :goto_3
    return-void
.end method

.method public final h()Lc/i6;
    .locals 4

    const-string v0, ""

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "battery_ignition_sensor"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v3, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v1, Lc/j6;->v:Ljava/util/LinkedHashMap;

    iget-object v1, v1, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/i6;

    goto :goto_0

    :cond_0
    move-object v0, v2

    :goto_0
    if-eqz v0, :cond_1

    iget-boolean v1, v0, Lc/i6;->v:Z

    if-eqz v1, :cond_1

    move-object v2, v0

    :cond_1
    return-object v2
.end method

.method public final h0(I)V
    .locals 2

    invoke-static {p1}, Lc/j6;->c(I)Z

    move-result v0

    if-nez v0, :cond_0

    const-string p1, "\u041f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u043d\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void

    :cond_0
    invoke-virtual {p0}, Lc/T5;->E()V

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "protocol"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final h1()V
    .locals 5

    iget-boolean v0, p0, Lc/T5;->T1:Z

    if-eqz v0, :cond_5

    iget-object v0, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    if-nez v0, :cond_0

    goto :goto_3

    :cond_0
    iget-object v0, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    const/4 v1, 0x0

    if-eqz v0, :cond_3

    iget v2, p0, Lc/T5;->P1:I

    iget-object v3, p0, Lc/T5;->R1:[[B

    array-length v4, v3

    if-lt v2, v4, :cond_1

    goto :goto_1

    :cond_1
    :try_start_0
    aget-object v2, v3, v2

    invoke-virtual {v0, v2}, Landroid/bluetooth/BluetoothGattDescriptor;->setValue([B)Z

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->V1:Z

    iget-object v0, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iget-object v2, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    invoke-virtual {v0, v2}, Landroid/bluetooth/BluetoothGatt;->writeDescriptor(Landroid/bluetooth/BluetoothGattDescriptor;)Z

    move-result v0

    if-nez v0, :cond_2

    iput-boolean v1, p0, Lc/T5;->V1:Z

    invoke-virtual {p0}, Lc/T5;->a0()V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string v0, "\u041d\u0435\u0442 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f Bluetooth"

    invoke-virtual {p0, v1, v0}, Lc/T5;->J(ZLjava/lang/String;)V

    :cond_2
    :goto_0
    return-void

    :cond_3
    :goto_1
    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_4

    const-string v0, "ATRV\r"

    goto :goto_2

    :cond_4
    const-string v0, "ATZ\r"

    :goto_2
    sget-object v2, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-virtual {v0, v2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-static {v0}, Lc/t5;->a([B)[[B

    move-result-object v0

    iput-object v0, p0, Lc/T5;->S1:[[B

    iput v1, p0, Lc/T5;->Q1:I

    invoke-virtual {p0}, Lc/T5;->g1()V

    :cond_5
    :goto_3
    return-void
.end method

.method public final i(IJ)Ljava/lang/Double;
    .locals 4

    iget-object v0, p0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/S5;

    invoke-static {v0, p2, p3}, Lc/T5;->k(Lc/S5;J)Ljava/lang/Double;

    move-result-object v0

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    invoke-static {p1}, Lc/T5;->w0(I)I

    move-result p1

    iget-object v0, p0, Lc/T5;->s:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    iget v2, v1, Lc/i6;->j:I

    if-eq v2, p1, :cond_2

    goto :goto_0

    :cond_2
    iget-object v2, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v3, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/S5;

    invoke-static {v2, p2, p3}, Lc/T5;->k(Lc/S5;J)Ljava/lang/Double;

    move-result-object v3

    if-eqz v3, :cond_1

    invoke-virtual {v2, v1}, Lc/S5;->a(Lc/i6;)I

    move-result v1

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    invoke-virtual {p0, p1, v1, v2, v3}, Lc/T5;->A(IID)Ljava/lang/Double;

    move-result-object v1

    if-eqz v1, :cond_1

    return-object v1

    :cond_3
    const/4 p1, 0x0

    return-object p1
.end method

.method public final i0(Z)Z
    .locals 4

    iget v0, p0, Lc/T5;->V:I

    const/16 v1, 0xb

    const/4 v2, 0x0

    if-eq v0, v1, :cond_2

    const/16 v1, 0x2b

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-eqz v0, :cond_1

    iget-boolean v1, v0, Lc/j6;->h:Z

    if-eqz v1, :cond_1

    iget-object v0, v0, Lc/j6;->q:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    iget-object v0, v0, Lc/j6;->q:Ljava/lang/String;

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_2
    :goto_0
    const-string v0, "221201"

    :goto_1
    invoke-static {v0}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "(?:03|07|0A)|(?:01|02|06|09|18|19|1A|21|22|23|2C|A8)(?:[0-9A-F]{2}){1,255}"

    invoke-virtual {v1, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_4

    invoke-static {v0}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "3E(?:00|80)"

    invoke-virtual {v1, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_4

    invoke-static {v0}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v3, "10[0-9A-F]{2}"

    invoke-virtual {v1, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_3

    goto :goto_2

    :cond_3
    :try_start_0
    invoke-static {v0, v2}, Lc/k6;->u0(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    return v2

    :cond_4
    :goto_2
    const-string v1, "PING:"

    if-eqz p1, :cond_5

    const/4 p1, 0x0

    iput-object p1, p0, Lc/T5;->a1:Lc/R5;

    new-instance p1, Lc/R5;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    const/4 v3, -0x1

    invoke-direct {p1, v3, v0, v1, v2}, Lc/R5;-><init>(ILjava/lang/String;Ljava/lang/String;I)V

    invoke-virtual {p0, p1}, Lc/T5;->G(Lc/R5;)V

    goto :goto_3

    :cond_5
    iget-object p1, p0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    :goto_3
    const/4 p1, 0x1

    return p1
.end method

.method public final i1()V
    .locals 5

    iget-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->c1:Z

    if-nez v0, :cond_0

    goto :goto_1

    :cond_0
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->c1:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, p0, Lc/T5;->r1:J

    iget-object v3, p0, Lc/T5;->P0:Lc/b6;

    if-nez v3, :cond_1

    goto :goto_0

    :cond_1
    iget v0, v3, Lc/b6;->c:I

    :goto_0
    int-to-long v3, v0

    add-long/2addr v1, v3

    iput-wide v1, p0, Lc/T5;->s1:J

    iget-object v1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v2, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lc/T5;->j0()I

    move-result v3

    add-int/2addr v3, v0

    int-to-long v3, v3

    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {p0}, Lc/T5;->F()V

    :cond_2
    :goto_1
    return-void
.end method

.method public final j()I
    .locals 3

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "battery_mode"

    const/4 v2, 0x1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v0

    if-ltz v0, :cond_0

    const/4 v1, 0x3

    if-gt v0, v1, :cond_0

    move v2, v0

    :cond_0
    return v2
.end method

.method public final j0()I
    .locals 2

    iget v0, p0, Lc/T5;->a0:I

    const/16 v1, 0x9c4

    if-lez v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lc/T5;->G0:Lc/f6;

    if-eqz v0, :cond_1

    :goto_0
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_1
    iget-object v0, p0, Lc/T5;->I0:Lc/d6;

    if-eqz v0, :cond_2

    goto :goto_0

    :cond_2
    iget-object v0, p0, Lc/T5;->P0:Lc/b6;

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    iget v1, v0, Lc/b6;->b:I

    :goto_1
    return v1
.end method

.method public final k0([B)V
    .locals 6

    iget-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/lang/String;

    sget-object v1, Ljava/nio/charset/StandardCharsets;->US_ASCII:Ljava/nio/charset/Charset;

    invoke-direct {v0, p1, v1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string p1, "\u0000"

    const-string v1, ""

    invoke-virtual {v0, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    iget-object v0, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lc/T5;->c1:Z

    if-nez v1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iget-wide v3, p0, Lc/T5;->s1:J

    cmp-long p1, v1, v3

    if-ltz p1, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    iput-wide v1, p0, Lc/T5;->s1:J

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {p1, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v2, p0, Lc/T5;->v1:Z

    if-eqz v2, :cond_1

    const-wide/16 v2, 0x1d4c

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lc/T5;->j0()I

    move-result v2

    int-to-long v2, v2

    :goto_0
    invoke-virtual {p1, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    iget-object p1, p0, Lc/T5;->G0:Lc/f6;

    if-eqz p1, :cond_3

    iget p1, p1, Lc/f6;->c:I

    goto :goto_1

    :cond_3
    iget-object p1, p0, Lc/T5;->I0:Lc/d6;

    if-eqz p1, :cond_4

    const/16 p1, 0x800

    goto :goto_1

    :cond_4
    const/16 p1, 0x4000

    :goto_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-le v1, p1, :cond_6

    iget-object v1, p0, Lc/T5;->O0:Lc/c6;

    if-eqz v1, :cond_6

    iget-object v4, p0, Lc/T5;->P0:Lc/b6;

    if-eqz v4, :cond_6

    iget-boolean v4, v4, Lc/b6;->d:Z

    if-eqz v4, :cond_6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v4

    const-string v5, ">"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->indexOf(Ljava/lang/String;)I

    move-result v5

    if-ltz v5, :cond_5

    move v5, v2

    goto :goto_2

    :cond_5
    move v5, v3

    :goto_2
    invoke-virtual {v1, v4, v5}, Lc/c6;->c(IZ)Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-virtual {p0}, Lc/T5;->F()V

    return-void

    :cond_6
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    if-le v1, p1, :cond_9

    iget-object p1, p0, Lc/T5;->F0:Lc/g6;

    if-nez p1, :cond_8

    iget-object p1, p0, Lc/T5;->H0:Lc/e6;

    if-eqz p1, :cond_7

    goto :goto_3

    :cond_7
    const-string p1, "\u0421\u043b\u0438\u0448\u043a\u043e\u043c \u0434\u043b\u0438\u043d\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u0430\u0434\u0430\u043f\u0442\u0435\u0440\u0430"

    invoke-virtual {p0, v3, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :cond_8
    :goto_3
    iput-boolean v2, p0, Lc/T5;->L0:Z

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v3, p1}, Lc/T5;->M(ZLjava/lang/String;)V

    return-void

    :cond_9
    invoke-virtual {p0}, Lc/T5;->F()V

    return-void
.end method

.method public final l()V
    .locals 4

    iget-object v0, p0, Lc/T5;->v:Lc/s5;

    invoke-virtual {v0}, Lc/s5;->a()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v1

    const/4 v2, 0x2

    if-nez v1, :cond_0

    iget-boolean v1, p0, Lc/T5;->w:Z

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lc/T5;->Y0()V

    goto :goto_0

    :cond_0
    iget-boolean v1, p0, Lc/T5;->w:Z

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Lc/T5;->s()V

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v1

    if-ne v1, v2, :cond_1

    iput-boolean v0, p0, Lc/T5;->B:Z

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v3, "battery_watch"

    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0}, Lc/T5;->u0()V

    :cond_1
    :goto_0
    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->F:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lc/T5;->F1:Z

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    if-ne v0, v2, :cond_3

    :cond_2
    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->F:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3
    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final l0(Ljava/lang/String;Ljava/lang/String;Z)V
    .locals 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\n\u041e\u0442\u0432\u0435\u0442:\n"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\r"

    const-string v1, "\\r"

    invoke-virtual {p2, p1, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "\n"

    const-string v2, "\\n\n"

    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p3, :cond_0

    const-string p1, "\n[\u0431\u0435\u0437 > \u00b7 \u0442\u0430\u0439\u043c\u0430\u0443\u0442]"

    goto :goto_0

    :cond_0
    const-string p1, ">"

    invoke-virtual {p2, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-eqz p2, :cond_1

    const-string p1, ""

    :cond_1
    :goto_0
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->E1:Ljava/lang/String;

    iget-object p1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string p2, "adapter_error"

    iget-object p3, p0, Lc/T5;->E1:Ljava/lang/String;

    invoke-interface {p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public final m(Ljava/lang/String;F)D
    .locals 2

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->isFinite(F)Z

    move-result v0

    if-eqz v0, :cond_0

    const/high16 v0, 0x41200000    # 10.0f

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_0

    const/high16 v0, 0x41800000    # 16.0f

    cmpg-float v0, p1, v0

    if-gtz v0, :cond_0

    float-to-double p1, p1

    const-wide/high16 v0, 0x4059000000000000L    # 100.0

    mul-double/2addr p1, v0

    invoke-static {p1, p2}, Ljava/lang/Math;->round(D)J

    move-result-wide p1

    long-to-double p1, p1

    div-double/2addr p1, v0

    goto :goto_0

    :cond_0
    float-to-double p1, p2

    :goto_0
    return-wide p1
.end method

.method public final m0()V
    .locals 6

    invoke-virtual {p0}, Lc/T5;->z0()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->p2:Z

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lc/T5;->x2:J

    iput-wide v1, p0, Lc/T5;->q2:J

    const-wide/16 v1, -0x1

    iput-wide v1, p0, Lc/T5;->w2:J

    iput-wide v1, p0, Lc/T5;->v2:J

    const/4 v3, 0x0

    iput-object v3, p0, Lc/T5;->t2:Lc/X5;

    iput-wide v1, p0, Lc/T5;->u2:J

    iget-object v4, p0, Lc/T5;->s2:Lc/Z5;

    const/4 v5, 0x0

    iput-boolean v5, v4, Lc/Z5;->a:Z

    iput-wide v1, p0, Lc/T5;->A2:J

    iput-object v3, p0, Lc/T5;->B2:Ljava/lang/Double;

    iput-boolean v5, p0, Lc/T5;->F1:Z

    iput-boolean v0, p0, Lc/T5;->i0:Z

    iput v5, p0, Lc/T5;->u1:I

    iput-object v3, p0, Lc/T5;->a1:Lc/R5;

    iput-boolean v5, p0, Lc/T5;->l0:Z

    iget-object v0, p0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const-string v1, "REINIT"

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    const-string v0, "\u05de\u05ea\u05d0\u05dd \u05de\u05d7\u05d5\u05d1\u05e8 \u00b7 \u05de\u05e9\u05d7\u05d6\u05e8 \u05ea\u05e7\u05e9\u05d5\u05e8\u05ea \u05e2\u05dd \u05de\u05d7\u05e9\u05d1 \u05d4\u05e8\u05db\u05d1..."

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final n(ZLjava/lang/String;)V
    .locals 8

    const/4 v0, 0x0

    iput-object v0, p0, Lc/T5;->a2:Ljava/lang/String;

    const/4 v1, 0x0

    iput-boolean v1, p0, Lc/T5;->c1:Z

    iget-object v2, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, p0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v1, p0, Lc/T5;->z:Z

    if-nez p1, :cond_5

    :try_start_0
    invoke-static {p2}, Lc/T5;->d(Ljava/lang/String;)D

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Double;->isFinite(D)Z

    move-result v4

    if-eqz v4, :cond_4

    const-wide/high16 v4, 0x4014000000000000L    # 5.0

    cmpg-double v4, v2, v4

    if-ltz v4, :cond_4

    const-wide/high16 v4, 0x4040000000000000L    # 32.0

    cmpl-double v4, v2, v4

    if-gtz v4, :cond_4

    new-instance v4, Lc/S5;

    const/4 v5, -0x1

    invoke-direct {v4, v2, v3, v5}, Lc/S5;-><init>(DI)V

    iput-object v4, p0, Lc/T5;->C:Lc/S5;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    iget-boolean p1, p0, Lc/T5;->w:Z

    if-eqz p1, :cond_3

    iget-object p1, p0, Lc/T5;->v:Lc/s5;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-object p2, p0, Lc/T5;->C:Lc/S5;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-static {p2, v2, v3}, Lc/T5;->k(Lc/S5;J)Ljava/lang/Double;

    move-result-object p2

    const-string v2, "battery_wake_volts"

    const v3, 0x4154cccd    # 13.3f

    invoke-virtual {p0, v2, v3}, Lc/T5;->m(Ljava/lang/String;F)D

    move-result-wide v2

    const-string v4, "battery_stop_volts"

    const v5, 0x414ccccd    # 12.8f

    invoke-virtual {p0, v4, v5}, Lc/T5;->m(Ljava/lang/String;F)D

    move-result-wide v4

    const-wide v6, 0x3fd3333333333333L    # 0.3

    add-double/2addr v4, v6

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(DD)D

    move-result-wide v2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2}, Lc/s5;->b(Ljava/lang/Double;)Z

    move-result v4

    if-eqz v4, :cond_2

    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    cmpg-double p2, v4, v2

    if-gez p2, :cond_0

    goto :goto_0

    :cond_0
    iget-wide v2, p1, Lc/s5;->b:J

    const-wide/16 v4, 0x0

    cmp-long p2, v2, v4

    if-gez p2, :cond_1

    iput-wide v0, p1, Lc/s5;->b:J

    :cond_1
    iget-wide p1, p1, Lc/s5;->b:J

    sub-long/2addr v0, p1

    const-wide/16 p1, 0x3a98

    cmp-long p1, v0, p1

    if-ltz p1, :cond_3

    invoke-virtual {p0}, Lc/T5;->Y0()V

    return-void

    :cond_2
    :goto_0
    const-wide/16 v0, -0x1

    iput-wide v0, p1, Lc/s5;->b:J

    :cond_3
    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_4
    :try_start_1
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "Invalid voltage"

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_5
    new-instance v2, Ljava/lang/IllegalArgumentException;

    const-string v3, "Incomplete voltage response"

    invoke-direct {v2, v3}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    iput-object v0, p0, Lc/T5;->C:Lc/S5;

    const-string v0, "ATRV"

    invoke-virtual {p0, v0, p2, p1}, Lc/T5;->l0(Ljava/lang/String;Ljava/lang/String;Z)V

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result p1

    const/4 p2, 0x2

    if-eq p1, p2, :cond_6

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object p2, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_6
    invoke-virtual {p0, v1}, Lc/T5;->c0(Z)V

    const-string p1, "OBD \u05d1\u05d4\u05de\u05ea\u05e0\u05d4 \u00b7 \u05d0\u05d9\u05df \u05de\u05ea\u05d7 \u05de-ELM; \u05d4\u05ea\u05d7\u05d1\u05e8 \u05d9\u05d3\u05e0\u05d9\u05ea"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final n0(Ljava/lang/Object;)V
    .locals 4

    iget-object v0, p0, Lc/T5;->Y0:Ljava/util/LinkedHashMap;

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    move v0, v2

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    iget-object v3, p0, Lc/T5;->Z0:Ljava/util/Set;

    invoke-interface {v3, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v0, v3

    iget-object v3, p0, Lc/T5;->X0:Ljava/util/LinkedHashMap;

    invoke-interface {v3, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-eqz p1, :cond_1

    move v1, v2

    :cond_1
    or-int p1, v0, v1

    if-eqz p1, :cond_2

    iput-boolean v2, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->Z0()V

    :cond_2
    return-void
.end method

.method public final o()V
    .locals 17

    move-object/from16 v0, p0

    iget-object v1, v0, Lc/T5;->q0:Lc/n6;

    iget-boolean v2, v1, Lc/n6;->h:Z

    iget-object v3, v0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    iget-object v4, v0, Lc/T5;->c:Landroid/os/Handler;

    const/16 v5, 0x2b

    const/16 v6, 0xb

    const/4 v7, 0x0

    const-string v8, ""

    const/4 v9, 0x0

    if-eqz v2, :cond_11

    if-eqz v2, :cond_10

    iget v1, v1, Lc/n6;->f:I

    if-ltz v1, :cond_10

    iput v1, v0, Lc/T5;->V:I

    iget v1, v0, Lc/T5;->T:I

    iput v1, v0, Lc/T5;->U:I

    iget-object v1, v0, Lc/T5;->X:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    iget v1, v0, Lc/T5;->U:I

    invoke-static {v1}, Lc/G8;->h0(I)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->X:Ljava/lang/String;

    :cond_0
    iget v1, v0, Lc/T5;->V:I

    iget-object v2, v0, Lc/T5;->g:Lc/j6;

    const/4 v10, 0x1

    if-eqz v2, :cond_1

    iget-boolean v2, v2, Lc/j6;->h:Z

    if-eqz v2, :cond_1

    move v2, v10

    goto :goto_0

    :cond_1
    move v2, v9

    :goto_0
    invoke-virtual {v0, v1, v2}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->Q:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_2

    iget v1, v0, Lc/T5;->T:I

    invoke-virtual {v0, v1, v9}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->Q:Ljava/lang/String;

    :cond_2
    iget-boolean v1, v0, Lc/T5;->o1:Z

    iget-object v2, v0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    if-eqz v1, :cond_3

    iget-boolean v1, v0, Lc/T5;->d1:Z

    if-eqz v1, :cond_3

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_c

    iget-object v1, v0, Lc/T5;->q1:Lc/A5;

    const-wide/16 v5, 0x7d0

    invoke-virtual {v4, v1, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto/16 :goto_4

    :cond_3
    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iget-object v1, v0, Lc/T5;->i1:Ljava/util/HashSet;

    invoke-virtual {v1}, Ljava/util/HashSet;->clear()V

    iget-object v1, v0, Lc/T5;->j1:Ljava/util/HashSet;

    invoke-virtual {v1}, Ljava/util/HashSet;->clear()V

    iput v9, v0, Lc/T5;->p1:I

    iput v9, v0, Lc/T5;->m1:I

    iput v9, v0, Lc/T5;->l1:I

    iput v9, v0, Lc/T5;->k1:I

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-nez v1, :cond_4

    goto/16 :goto_4

    :cond_4
    iget v4, v0, Lc/T5;->V:I

    if-eq v4, v6, :cond_6

    if-ne v4, v5, :cond_5

    iget-boolean v1, v1, Lc/j6;->g:Z

    if-nez v1, :cond_5

    goto :goto_1

    :cond_5
    move v1, v9

    goto :goto_2

    :cond_6
    :goto_1
    move v1, v10

    :goto_2
    iget v4, v0, Lc/T5;->T:I

    invoke-static {v4}, Lc/k6;->I(I)I

    move-result v4

    iget-object v5, v0, Lc/T5;->g:Lc/j6;

    iget-boolean v6, v5, Lc/j6;->k:Z

    if-eqz v6, :cond_8

    const/4 v6, 0x3

    if-eq v4, v6, :cond_7

    const/16 v6, 0x8

    if-ne v4, v6, :cond_8

    :cond_7
    move v4, v10

    goto :goto_3

    :cond_8
    move v4, v9

    :goto_3
    iput-boolean v4, v0, Lc/T5;->n1:Z

    const-string v6, "checked_widget_profile_sha"

    iget-object v11, v0, Lc/T5;->b:Landroid/content/SharedPreferences;

    if-eqz v4, :cond_9

    iget-object v4, v5, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_9

    iget-object v4, v0, Lc/T5;->g:Lc/j6;

    iget-object v4, v4, Lc/j6;->d:Ljava/lang/String;

    invoke-interface {v11, v6, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_9

    iget-object v4, v0, Lc/T5;->h1:Ljava/util/HashSet;

    const-string v5, "disabled_sensor_ids"

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object v8

    invoke-interface {v11, v5, v8}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    iput-boolean v9, v0, Lc/T5;->n1:Z

    :cond_9
    iget-boolean v4, v0, Lc/T5;->n1:Z

    if-nez v4, :cond_a

    if-nez v1, :cond_a

    goto :goto_4

    :cond_a
    iget-object v1, v0, Lc/T5;->f1:Ljava/util/HashSet;

    invoke-virtual {v1}, Ljava/util/HashSet;->clear()V

    iget-boolean v1, v0, Lc/T5;->n1:Z

    if-eqz v1, :cond_b

    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    iget-object v1, v1, Lc/j6;->d:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    iget-object v4, v0, Lc/T5;->g:Lc/j6;

    iget-object v4, v4, Lc/j6;->d:Ljava/lang/String;

    invoke-interface {v1, v6, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_b
    iput-boolean v10, v0, Lc/T5;->b1:Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->M0()V

    iget-object v1, v0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    new-instance v5, Lc/C5;

    const/4 v6, 0x2

    invoke-direct {v5, v6}, Lc/C5;-><init>(I)V

    invoke-interface {v4, v5}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/util/ArrayDeque;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->clear()V

    iput-boolean v10, v0, Lc/T5;->b1:Z

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v1

    xor-int/2addr v1, v10

    iput-boolean v1, v0, Lc/T5;->d1:Z

    :cond_c
    :goto_4
    iget-object v1, v0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_e

    iget-boolean v1, v1, Lc/j6;->g:Z

    if-eqz v1, :cond_d

    goto :goto_5

    :cond_d
    move v1, v9

    goto :goto_6

    :cond_e
    :goto_5
    move v1, v10

    :goto_6
    iput-object v7, v0, Lc/T5;->O0:Lc/c6;

    iput-object v7, v0, Lc/T5;->P0:Lc/b6;

    iput-object v7, v0, Lc/T5;->s0:Lc/l6;

    if-eqz v1, :cond_f

    invoke-virtual/range {p0 .. p0}, Lc/T5;->b0()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v9}, Lc/k6;->a0(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_7

    :cond_f
    iput-boolean v10, v0, Lc/T5;->H1:Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Y()V

    :goto_7
    invoke-virtual/range {p0 .. p0}, Lc/T5;->Z()V

    return-void

    :cond_10
    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u0442\u044c \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b \u042d\u0411\u0423"

    invoke-virtual {v0, v9, v1}, Lc/T5;->J(ZLjava/lang/String;)V

    return-void

    :cond_11
    invoke-virtual {v1}, Lc/n6;->d()Lc/l6;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->s0:Lc/l6;

    iget v2, v1, Lc/l6;->a:I

    const/4 v10, 0x2

    if-ne v2, v10, :cond_12

    iget-object v1, v0, Lc/T5;->q0:Lc/n6;

    iput-object v1, v0, Lc/T5;->r0:Lc/n6;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->s()V

    const-string v1, "\u05de\u05ea\u05d7\u05d1\u05e8 \u05de\u05d7\u05d3\u05e9 \u05dc\u05de\u05ea\u05d0\u05dd..."

    iput-object v1, v0, Lc/T5;->C1:Ljava/lang/String;

    iget-object v1, v0, Lc/T5;->g2:Lc/A5;

    const-wide/16 v2, 0x12c

    invoke-virtual {v4, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    return-void

    :cond_12
    iget v1, v1, Lc/l6;->b:I

    if-le v1, v6, :cond_14

    if-ne v1, v5, :cond_13

    goto :goto_8

    :cond_13
    move v2, v9

    goto :goto_9

    :cond_14
    :goto_8
    move v2, v1

    :goto_9
    iput v2, v0, Lc/T5;->T:I

    iput v2, v0, Lc/T5;->U:I

    invoke-static {v2}, Lc/G8;->h0(I)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->X:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->s0:Lc/l6;

    iget-boolean v2, v2, Lc/l6;->g:Z

    invoke-virtual {v0, v1, v2}, Lc/T5;->C(IZ)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->Q:Ljava/lang/String;

    iput-object v8, v0, Lc/T5;->P:Ljava/lang/String;

    iput-object v8, v0, Lc/T5;->R:Ljava/lang/String;

    const-string v2, "18"

    iput-object v2, v0, Lc/T5;->S:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, v0, Lc/T5;->y1:Lc/R1;

    invoke-virtual {v2}, Lc/R1;->c()V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    invoke-virtual {v3}, Ljava/util/ArrayDeque;->clear()V

    iput-object v8, v0, Lc/T5;->D1:Ljava/lang/String;

    iput-boolean v9, v0, Lc/T5;->F1:Z

    iput-boolean v9, v0, Lc/T5;->H1:Z

    iput v9, v0, Lc/T5;->u1:I

    if-eq v1, v6, :cond_17

    if-ne v1, v5, :cond_15

    goto :goto_a

    :cond_15
    iget-object v2, v0, Lc/T5;->g:Lc/j6;

    if-nez v2, :cond_16

    const-string v2, "0100"

    goto :goto_b

    :cond_16
    iget-object v2, v2, Lc/j6;->p:Ljava/lang/String;

    goto :goto_b

    :cond_17
    :goto_a
    const-string v2, "221201"

    :goto_b
    iput-object v2, v0, Lc/T5;->Y:Ljava/lang/String;

    iget-object v2, v0, Lc/T5;->s0:Lc/l6;

    new-instance v3, Lc/a6;

    iget v11, v2, Lc/l6;->d:I

    iget-object v4, v0, Lc/T5;->g:Lc/j6;

    if-nez v4, :cond_18

    move-object v13, v8

    goto :goto_c

    :cond_18
    iget-object v4, v4, Lc/j6;->x:Ljava/util/ArrayList;

    const-string v5, ";"

    invoke-static {v5, v4}, Ljava/lang/String;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v4

    move-object v13, v4

    :goto_c
    iget-object v14, v0, Lc/T5;->Y:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->v()Ljava/lang/String;

    move-result-object v15

    iget-object v4, v0, Lc/T5;->Q:Ljava/lang/String;

    iget-boolean v12, v2, Lc/l6;->g:Z

    move-object v9, v3

    move v10, v1

    move-object/from16 v16, v4

    invoke-direct/range {v9 .. v16}, Lc/a6;-><init>(IIZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Lc/c6;

    invoke-direct {v4, v3, v2}, Lc/c6;-><init>(Lc/a6;Lc/l6;)V

    iput-object v4, v0, Lc/T5;->O0:Lc/c6;

    iput-object v7, v0, Lc/T5;->P0:Lc/b6;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->v()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v0, Lc/T5;->Z:Ljava/lang/String;

    const/4 v2, -0x1

    iput v2, v0, Lc/T5;->m0:I

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u042d\u0411\u0423 \u00b7 \u043f\u043e\u043f\u044b\u0442\u043a\u0430 "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lc/T5;->s0:Lc/l6;

    iget v3, v3, Lc/l6;->c:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget-object v3, v0, Lc/T5;->s0:Lc/l6;

    iget-boolean v3, v3, Lc/l6;->h:Z

    if-eqz v3, :cond_19

    const-string v3, " \u00b7 \u043f\u0440\u043e\u0442\u043e\u043a\u043e\u043b "

    invoke-static {v3, v1}, Lcom/hoho/android/usbserial/driver/a;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v8

    :cond_19
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lc/T5;->Z()V

    invoke-virtual/range {p0 .. p0}, Lc/T5;->q()V

    return-void
.end method

.method public final o0()V
    .locals 4

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    iget-object v1, p0, Lc/T5;->h:Lc/j6;

    invoke-static {v0, v1}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->g:Lc/j6;

    iget-wide v0, p0, Lc/T5;->i:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lc/T5;->i:J

    iget-object v0, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    new-instance v1, Lc/C5;

    const/4 v2, 0x3

    invoke-direct {v1, v2}, Lc/C5;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    iget-object v0, p0, Lc/T5;->R0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    new-instance v1, Lc/C5;

    const/4 v2, 0x4

    invoke-direct {v1, v2}, Lc/C5;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    iget-object v0, p0, Lc/T5;->S0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    new-instance v1, Lc/C5;

    const/4 v2, 0x5

    invoke-direct {v1, v2}, Lc/C5;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    iget-object v0, p0, Lc/T5;->T0:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    new-instance v1, Lc/C5;

    const/4 v2, 0x6

    invoke-direct {v1, v2}, Lc/C5;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    iget-object v0, p0, Lc/T5;->h1:Ljava/util/HashSet;

    new-instance v1, Lc/C5;

    const/4 v2, 0x7

    invoke-direct {v1, v2}, Lc/C5;-><init>(I)V

    invoke-interface {v0, v1}, Ljava/util/Collection;->removeIf(Ljava/util/function/Predicate;)Z

    invoke-virtual {p0}, Lc/T5;->A0()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->q()V

    invoke-virtual {p0}, Lc/T5;->Z0()V

    return-void
.end method

.method public final p()V
    .locals 2

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->r:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->k:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v1, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->R0:Ljava/util/HashMap;

    iget-object v1, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->S0:Ljava/util/HashMap;

    iget-object v1, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->T0:Ljava/util/HashMap;

    iget-object v1, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lc/T5;->p:Lc/j6;

    iput-object v0, p0, Lc/T5;->g:Lc/j6;

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, Lc/T5;->p:Lc/j6;

    iput-object v0, p0, Lc/T5;->k:Ljava/lang/String;

    const-string v1, ""

    iput-object v1, p0, Lc/T5;->l:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->m:Ljava/lang/String;

    iput-object v0, p0, Lc/T5;->q:Lc/b;

    iget-object v0, p0, Lc/T5;->n:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    iget-object v0, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lc/T5;->b1:Z

    iget-object v0, p0, Lc/T5;->j:Ljava/lang/Object;

    invoke-virtual {p0, v0}, Lc/T5;->n0(Ljava/lang/Object;)V

    invoke-virtual {p0}, Lc/T5;->A0()V

    return-void
.end method

.method public final p0(Ljava/lang/Object;Ljava/util/Set;)V
    .locals 3

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0, p2}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    iget-object p2, p0, Lc/T5;->Y0:Ljava/util/LinkedHashMap;

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/util/Set;

    iget-object v1, p0, Lc/T5;->Z0:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    if-eqz v2, :cond_1

    :cond_0
    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->Z0()V

    :cond_1
    return-void
.end method

.method public final q()V
    .locals 2

    iget-object v0, p0, Lc/T5;->q:Lc/b;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lc/T5;->k:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lc/T5;->P(Ljava/lang/String;)Lc/S5;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v0, ""

    invoke-virtual {p0, v0}, Lc/T5;->N(Ljava/lang/String;)V

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lc/T5;->B1:Ljava/util/HashSet;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final q0(Ljava/lang/Object;Ljava/util/Set;)V
    .locals 4

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    if-eqz v1, :cond_0

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    iget-object v3, v3, Lc/j6;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ":"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object p2, p0, Lc/T5;->X0:Ljava/util/LinkedHashMap;

    invoke-interface {p2, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-interface {v0, p1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_1

    const/4 p1, 0x1

    iput-boolean p1, p0, Lc/T5;->b1:Z

    invoke-virtual {p0}, Lc/T5;->Z0()V

    :cond_1
    return-void
.end method

.method public final r()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->w:Z

    iput-boolean v0, p0, Lc/T5;->B:Z

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc/T5;->E:J

    iget-object v0, p0, Lc/T5;->v:Lc/s5;

    invoke-virtual {v0}, Lc/s5;->a()V

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "battery_parked"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "battery_watch"

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public final r0(Ljava/lang/Object;Ljava/util/LinkedHashSet;)V
    .locals 4

    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    invoke-virtual {p0, v3}, Lc/T5;->a1(I)Lc/i6;

    move-result-object v3

    if-nez v3, :cond_0

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    iget-object v2, v3, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lc/T5;->e1()Ljava/util/ArrayList;

    move-result-object p2

    invoke-virtual {p2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_2
    :goto_1
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/i6;

    iget-boolean v3, v2, Lc/i6;->v:Z

    if-eqz v3, :cond_2

    iget-object v2, v2, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    invoke-virtual {p0, p1, v0}, Lc/T5;->p0(Ljava/lang/Object;Ljava/util/Set;)V

    invoke-virtual {p0, p1, v1}, Lc/T5;->q0(Ljava/lang/Object;Ljava/util/Set;)V

    return-void
.end method

.method public final declared-synchronized s()V
    .locals 8

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lc/T5;->v:Lc/s5;

    invoke-virtual {v0}, Lc/s5;->a()V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->F:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->G:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->H:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->A:Z

    iput-boolean v0, p0, Lc/T5;->z:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lc/T5;->C:Lc/S5;

    const-wide/16 v2, -0x3a98

    iput-wide v2, p0, Lc/T5;->D:J

    iget-object v2, p0, Lc/T5;->z1:Lc/r5;

    iget-object v3, v2, Lc/r5;->a:Ljava/lang/Object;

    check-cast v3, Ljava/util/HashMap;

    invoke-virtual {v3}, Ljava/util/HashMap;->clear()V

    iget-object v2, v2, Lc/r5;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    const-string v2, "\u041f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u043e\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0430: \u0441\u043e\u0435\u0434\u0438\u043d\u0435\u043d\u0438\u0435 \u0437\u0430\u043a\u0440\u044b\u0442\u043e"

    invoke-virtual {p0, v2}, Lc/T5;->N(Ljava/lang/String;)V

    iget-boolean v2, p0, Lc/T5;->F1:Z

    const/4 v3, 0x1

    if-eqz v2, :cond_0

    iget-boolean v2, p0, Lc/T5;->m2:Z

    if-eqz v2, :cond_0

    iput-boolean v3, p0, Lc/T5;->p2:Z

    goto :goto_0

    :catchall_0
    move-exception v0

    goto/16 :goto_1

    :cond_0
    :goto_0
    invoke-virtual {p0}, Lc/T5;->z0()V

    const-wide/16 v4, 0x0

    iput-wide v4, p0, Lc/T5;->x2:J

    iput-wide v4, p0, Lc/T5;->q2:J

    const-wide/16 v6, -0x1

    iput-wide v6, p0, Lc/T5;->w2:J

    iput-wide v6, p0, Lc/T5;->v2:J

    iput-object v1, p0, Lc/T5;->t2:Lc/X5;

    iput-wide v6, p0, Lc/T5;->u2:J

    iget-object v2, p0, Lc/T5;->s2:Lc/Z5;

    iput-boolean v0, v2, Lc/Z5;->a:Z

    iput-wide v6, p0, Lc/T5;->A2:J

    iput-object v1, p0, Lc/T5;->B2:Ljava/lang/Double;

    iget v2, p0, Lc/T5;->t:I

    add-int/2addr v2, v3

    iput v2, p0, Lc/T5;->t:I

    iput-boolean v0, p0, Lc/T5;->u0:Z

    iput v0, p0, Lc/T5;->y0:I

    iput-object v1, p0, Lc/T5;->A0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->z0:Ljava/lang/String;

    iput-boolean v0, p0, Lc/T5;->w0:Z

    iput-boolean v3, p0, Lc/T5;->v0:Z

    iput-object v1, p0, Lc/T5;->F0:Lc/g6;

    iput-object v1, p0, Lc/T5;->G0:Lc/f6;

    iput-object v1, p0, Lc/T5;->H0:Lc/e6;

    iput-object v1, p0, Lc/T5;->I0:Lc/d6;

    iput-object v1, p0, Lc/T5;->J0:Ljava/lang/String;

    iput-boolean v0, p0, Lc/T5;->M0:Z

    iput-boolean v0, p0, Lc/T5;->L0:Z

    iput-boolean v0, p0, Lc/T5;->K0:Z

    iget-object v2, p0, Lc/T5;->N0:Ljava/util/HashSet;

    invoke-virtual {v2}, Ljava/util/HashSet;->clear()V

    iput-object v1, p0, Lc/T5;->K:Ljava/io/OutputStream;

    iget-object v2, p0, Lc/T5;->J:Lc/M6;

    invoke-virtual {v2}, Lc/M6;->a()V

    iget-object v2, p0, Lc/T5;->L:Lc/N6;

    iput-object v1, p0, Lc/T5;->L:Lc/N6;

    if-eqz v2, :cond_1

    invoke-virtual {v2}, Lc/N6;->close()V

    :cond_1
    iget-object v2, p0, Lc/T5;->M:Lc/P6;

    iput-object v1, p0, Lc/T5;->M:Lc/P6;

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Lc/P6;->close()V

    :cond_2
    iget-object v2, p0, Lc/T5;->N:Lc/N5;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_3

    :try_start_1
    iget-object v6, p0, Lc/T5;->a:Landroid/content/Context;

    invoke-virtual {v6, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :try_start_2
    iput-object v1, p0, Lc/T5;->N:Lc/N5;

    :cond_3
    iget-object v2, p0, Lc/T5;->I:Landroid/bluetooth/BluetoothSocket;

    iput-object v1, p0, Lc/T5;->I:Landroid/bluetooth/BluetoothSocket;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    if-eqz v2, :cond_4

    :try_start_3
    invoke-virtual {v2}, Landroid/bluetooth/BluetoothSocket;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catch_1
    :cond_4
    :try_start_4
    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v6, p0, Lc/T5;->e2:Lc/A5;

    invoke-virtual {v2, v6}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v6, p0, Lc/T5;->h2:Lc/A5;

    invoke-virtual {v2, v6}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v6, p0, Lc/T5;->f2:Lc/A5;

    invoke-virtual {v2, v6}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v6, p0, Lc/T5;->q1:Lc/A5;

    invoke-virtual {v2, v6}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-object v1, p0, Lc/T5;->a1:Lc/R5;

    iput-boolean v0, p0, Lc/T5;->c1:Z

    iput-boolean v0, p0, Lc/T5;->i0:Z

    iput v0, p0, Lc/T5;->t1:I

    iput-wide v4, p0, Lc/T5;->s1:J

    iput-wide v4, p0, Lc/T5;->r1:J

    iget-boolean v2, p0, Lc/T5;->o1:Z

    if-nez v2, :cond_5

    iget-object v2, p0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iget-object v2, p0, Lc/T5;->h1:Ljava/util/HashSet;

    invoke-virtual {v2}, Ljava/util/HashSet;->clear()V

    iget-object v2, p0, Lc/T5;->i1:Ljava/util/HashSet;

    invoke-virtual {v2}, Ljava/util/HashSet;->clear()V

    iget-object v2, p0, Lc/T5;->j1:Ljava/util/HashSet;

    invoke-virtual {v2}, Ljava/util/HashSet;->clear()V

    iput v0, p0, Lc/T5;->p1:I

    iput v0, p0, Lc/T5;->m1:I

    iput v0, p0, Lc/T5;->l1:I

    iput v0, p0, Lc/T5;->k1:I

    iput-boolean v0, p0, Lc/T5;->d1:Z

    :cond_5
    iput-boolean v0, p0, Lc/T5;->e1:Z

    iget-object v2, p0, Lc/T5;->V0:Lc/v8;

    iget-object v2, v2, Lc/v8;->b:Ljava/lang/Object;

    check-cast v2, Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iget-object v2, p0, Lc/T5;->W0:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    iget-object v2, p0, Lc/T5;->Q0:Ljava/util/LinkedHashSet;

    invoke-interface {v2}, Ljava/util/Set;->clear()V

    iget-object v2, p0, Lc/T5;->R0:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, p0, Lc/T5;->S0:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, p0, Lc/T5;->T0:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, p0, Lc/T5;->x1:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, p0, Lc/T5;->y1:Lc/R1;

    invoke-virtual {v2}, Lc/R1;->c()V

    iput v0, p0, Lc/T5;->u1:I

    iput-boolean v3, p0, Lc/T5;->w1:Z

    iput-boolean v3, p0, Lc/T5;->b1:Z

    const-string v2, ""

    iput-object v2, p0, Lc/T5;->P:Ljava/lang/String;

    const-string v2, ""

    iput-object v2, p0, Lc/T5;->R:Ljava/lang/String;

    const-string v2, "18"

    iput-object v2, p0, Lc/T5;->S:Ljava/lang/String;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    const/4 v2, -0x1

    iput v2, p0, Lc/T5;->m0:I

    iput-boolean v0, p0, Lc/T5;->o0:Z

    iput-boolean v0, p0, Lc/T5;->n0:Z

    iput-boolean v0, p0, Lc/T5;->p0:Z

    iget-object v2, p0, Lc/T5;->B0:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iput-object v1, p0, Lc/T5;->C0:Lc/k7;

    iput-object v1, p0, Lc/T5;->D0:Lc/j7;

    iput-object v1, p0, Lc/T5;->O0:Lc/c6;

    iput-object v1, p0, Lc/T5;->P0:Lc/b6;

    iput-object v1, p0, Lc/T5;->q0:Lc/n6;

    iput-object v1, p0, Lc/T5;->s0:Lc/l6;

    iput v0, p0, Lc/T5;->a0:I

    iput-object v1, p0, Lc/T5;->c0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->b0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->d0:Lc/b6;

    iput-object v1, p0, Lc/T5;->e0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->f0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->g0:Ljava/lang/String;

    iput-object v1, p0, Lc/T5;->j0:Lc/b6;

    iput-boolean v0, p0, Lc/T5;->h0:Z

    iput-boolean v0, p0, Lc/T5;->l0:Z

    iput-wide v4, p0, Lc/T5;->t0:J

    iget-object v2, p0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-virtual {v2}, Ljava/util/HashMap;->clear()V

    iget-object v2, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    iput-boolean v0, p0, Lc/T5;->F1:Z

    iput-boolean v0, p0, Lc/T5;->H1:Z

    iput-object v1, p0, Lc/T5;->a2:Ljava/lang/String;

    iget-object v2, p0, Lc/T5;->b2:Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v2, p0, Lc/T5;->c2:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iput-object v1, p0, Lc/T5;->K1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, p0, Lc/T5;->X1:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v2, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v3, p0, Lc/T5;->Y1:Lc/A5;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iput-boolean v0, p0, Lc/T5;->V1:Z

    iput-boolean v0, p0, Lc/T5;->U1:Z

    iput-boolean v0, p0, Lc/T5;->T1:Z

    iput-object v1, p0, Lc/T5;->L1:Landroid/bluetooth/BluetoothGattCharacteristic;

    iput-object v1, p0, Lc/T5;->M1:Landroid/bluetooth/BluetoothGattDescriptor;

    iget-object v2, p0, Lc/T5;->N1:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    new-array v2, v0, [[B

    iput-object v2, p0, Lc/T5;->S1:[[B

    new-array v2, v0, [[B

    iput-object v2, p0, Lc/T5;->R1:[[B

    iget-object v2, p0, Lc/T5;->W1:Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    iget-object v0, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    iput-object v1, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    if-eqz v0, :cond_6

    :try_start_5
    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGatt;->disconnect()V

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothGatt;->close()V
    :try_end_5
    .catch Ljava/lang/SecurityException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :catch_2
    :cond_6
    monitor-exit p0

    return-void

    :goto_1
    :try_start_6
    monitor-exit p0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    throw v0
.end method

.method public final s0()V
    .locals 3

    iget-object v0, p0, Lc/T5;->h:Lc/j6;

    if-nez v0, :cond_1

    const-string v0, "profile_id"

    const-string v1, ""

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v2, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "\u0414\u043e\u0436\u0434\u0438\u0442\u0435\u0441\u044c \u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438 \u043f\u0440\u043e\u0444\u0438\u043b\u044f \u0438\u043b\u0438 \u0441\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u0435 \u0435\u0433\u043e \u0441\u043d\u043e\u0432\u0430"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    return-void
.end method

.method public final t(Lc/i6;)V
    .locals 2

    iget-object v0, p0, Lc/T5;->n:Ljava/util/LinkedHashSet;

    iget-object v1, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object p1, p1, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Lc/T5;->g:Lc/j6;

    invoke-virtual {v1, v0}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v0

    if-eqz v0, :cond_1

    invoke-virtual {p0, v0}, Lc/T5;->t(Lc/i6;)V

    goto :goto_0

    :cond_2
    return-void
.end method

.method public final t0()V
    .locals 2

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/T5;->l2:D

    iput-wide v0, p0, Lc/T5;->k2:D

    iput-wide v0, p0, Lc/T5;->j2:D

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->p2:Z

    iput-boolean v0, p0, Lc/T5;->o2:Z

    iput-boolean v0, p0, Lc/T5;->n2:Z

    iput-boolean v0, p0, Lc/T5;->m2:Z

    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lc/T5;->x2:J

    iput-wide v0, p0, Lc/T5;->q2:J

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lc/T5;->w2:J

    iput-wide v0, p0, Lc/T5;->v2:J

    invoke-virtual {p0}, Lc/T5;->z0()V

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final u()V
    .locals 6

    iget-boolean v0, p0, Lc/T5;->e1:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lc/T5;->a1:Lc/R5;

    if-nez v0, :cond_0

    goto :goto_3

    :cond_0
    iget-object v0, v0, Lc/R5;->d:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc/i6;

    iget-object v4, p0, Lc/T5;->f:Ljava/util/LinkedHashMap;

    iget-object v5, v1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc/S5;

    iget-boolean v5, p0, Lc/T5;->n1:Z

    iget-object v1, v1, Lc/i6;->a:Ljava/lang/String;

    if-eqz v5, :cond_1

    iget-object v2, p0, Lc/T5;->j1:Ljava/util/HashSet;

    invoke-virtual {v2, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    goto :goto_1

    :cond_1
    if-eqz v4, :cond_2

    iget-wide v4, v4, Lc/S5;->a:D

    invoke-static {v4, v5}, Ljava/lang/Double;->isFinite(D)Z

    move-result v4

    if-eqz v4, :cond_2

    move v2, v3

    :cond_2
    :goto_1
    if-nez v2, :cond_3

    iget-object v2, p0, Lc/T5;->i1:Ljava/util/HashSet;

    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    iget v1, p0, Lc/T5;->k1:I

    add-int/2addr v1, v3

    iput v1, p0, Lc/T5;->k1:I

    goto :goto_0

    :cond_4
    iput-boolean v2, p0, Lc/T5;->e1:Z

    iput v2, p0, Lc/T5;->u1:I

    iput-boolean v3, p0, Lc/T5;->b1:Z

    iget-object v0, p0, Lc/T5;->g1:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-boolean v1, p0, Lc/T5;->n1:Z

    if-eqz v1, :cond_5

    const-wide/16 v1, 0x7d0

    goto :goto_2

    :cond_5
    const-wide/16 v1, 0x3e8

    :goto_2
    iget-object v3, p0, Lc/T5;->q1:Lc/A5;

    invoke-virtual {v0, v3, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_6
    :goto_3
    return-void
.end method

.method public final u0()V
    .locals 3

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_1

    iget-boolean v0, p0, Lc/T5;->B:Z

    if-eqz v0, :cond_1

    :cond_0
    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "enabled"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v1, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    return-void
.end method

.method public final v()Ljava/lang/String;
    .locals 3

    iget-object v0, p0, Lc/T5;->g:Lc/j6;

    if-nez v0, :cond_0

    const-string v0, "64"

    goto :goto_0

    :cond_0
    iget-object v0, v0, Lc/j6;->r:Ljava/lang/String;

    :goto_0
    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v2, "recovered_atst"

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final v0(Lc/i6;)V
    .locals 4

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    new-instance v1, Ljava/util/ArrayDeque;

    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    invoke-virtual {v1, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    :cond_0
    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_3

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result p1

    const/16 v2, 0x40

    if-ge p1, v2, :cond_3

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc/i6;

    iget-object v2, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    iget-object v2, p0, Lc/T5;->h1:Ljava/util/HashSet;

    iget-object v3, p1, Lc/i6;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    iget-object p1, p1, Lc/i6;->C:Ljava/util/Set;

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_2
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v3, p0, Lc/T5;->g:Lc/j6;

    invoke-virtual {v3, v2}, Lc/j6;->b(Ljava/lang/String;)Lc/i6;

    move-result-object v2

    if-eqz v2, :cond_2

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_3
    return-void
.end method

.method public final w(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    invoke-virtual {p0}, Lc/T5;->r()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lc/T5;->I1:Z

    const-string v0, ""

    iput-object v0, p0, Lc/T5;->E1:Ljava/lang/String;

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "adapter_error"

    invoke-interface {v1, v2}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "address"

    invoke-interface {v0, v1, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "name"

    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string p2, "enabled"

    const/4 v0, 0x1

    invoke-interface {p1, p2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-wide/16 p1, 0x1388

    iput-wide p1, p0, Lc/T5;->d2:J

    invoke-virtual {p0}, Lc/T5;->x()V

    return-void
.end method

.method public final x()V
    .locals 6

    iget-boolean v0, p0, Lc/T5;->u:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v2, p0, Lc/T5;->x:Ljava/lang/Boolean;

    invoke-virtual {v0, v2}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0, v1}, Lc/T5;->c0(Z)V

    return-void

    :cond_1
    iget-boolean v0, p0, Lc/T5;->w:Z

    if-eqz v0, :cond_3

    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    const/4 v2, 0x2

    if-ne v0, v2, :cond_2

    iget-boolean v0, p0, Lc/T5;->B:Z

    if-nez v0, :cond_3

    :cond_2
    return-void

    :cond_3
    invoke-virtual {p0}, Lc/T5;->j()I

    move-result v0

    if-eqz v0, :cond_4

    iget-wide v2, p0, Lc/T5;->E:J

    const-wide/16 v4, 0x0

    cmp-long v0, v2, v4

    if-gez v0, :cond_4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    iput-wide v2, p0, Lc/T5;->E:J

    :cond_4
    iget-object v0, p0, Lc/T5;->r0:Lc/n6;

    const/4 v2, 0x0

    iput-object v2, p0, Lc/T5;->r0:Lc/n6;

    iget-object v3, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v4, p0, Lc/T5;->g2:Lc/A5;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    invoke-virtual {p0}, Lc/T5;->L0()V

    invoke-virtual {p0}, Lc/T5;->s()V

    iput-object v0, p0, Lc/T5;->q0:Lc/n6;

    iget-object v0, p0, Lc/T5;->e:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, p0, Lc/T5;->d:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    const-string v0, ""

    iput-object v0, p0, Lc/T5;->D1:Ljava/lang/String;

    iput v1, p0, Lc/T5;->U0:I

    iget-object v3, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v4, "enabled"

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0}, Lc/T5;->H()V

    iget v1, p0, Lc/T5;->t:I

    iget-object v3, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v4, "profile_id"

    invoke-interface {v3, v4, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_6

    const-string v2, "\u05d1\u05d5\u05d3\u05e7 \u05e4\u05e8\u05d5\u05e4\u05d9\u05dc \u05e9\u05de\u05d5\u05e8..."

    iput-object v2, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    iget-object v2, p0, Lc/T5;->a:Landroid/content/Context;

    invoke-static {v2}, Lc/z5;->b(Landroid/content/Context;)Lc/z5;

    move-result-object v2

    new-instance v3, Lc/D5;

    invoke-direct {v3, p0, v1}, Lc/D5;-><init>(Lc/T5;I)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lc/Z;

    const/16 v4, 0xe

    invoke-direct {v1, v2, v0, v3, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object v0, v2, Lc/z5;->g:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_6
    iput-object v2, p0, Lc/T5;->h:Lc/j6;

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-static {v0, v2}, Lc/k6;->P(Landroid/content/SharedPreferences;Lc/j6;)Lc/j6;

    move-result-object v0

    iput-object v0, p0, Lc/T5;->g:Lc/j6;

    invoke-virtual {p0, v1}, Lc/T5;->z(I)V

    :goto_0
    return-void
.end method

.method public final x0()V
    .locals 18

    move-object/from16 v0, p0

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual/range {p0 .. p0}, Lc/T5;->S()Ljava/lang/Double;

    move-result-object v3

    const/4 v4, 0x5

    invoke-virtual {v0, v4}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v5

    if-nez v5, :cond_0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    iget-wide v5, v5, Lc/Y5;->a:D

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    :goto_0
    const-wide v8, 0x40cd4c0000000000L    # 15000.0

    const-wide/16 v10, 0x0

    const-wide/16 v14, 0x0

    if-eqz v3, :cond_6

    iget-object v12, v0, Lc/T5;->t2:Lc/X5;

    if-eqz v12, :cond_6

    move-object v13, v5

    iget-wide v4, v0, Lc/T5;->v2:J

    iget-wide v6, v12, Lc/X5;->d:J

    cmp-long v4, v4, v6

    if-eqz v4, :cond_5

    iget-wide v4, v0, Lc/T5;->q2:J

    cmp-long v6, v4, v14

    if-lez v6, :cond_3

    sub-long v4, v1, v4

    iget-wide v6, v0, Lc/T5;->j2:D

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v16

    long-to-double v14, v4

    cmpg-double v3, v14, v10

    if-ltz v3, :cond_2

    cmpl-double v3, v14, v8

    if-lez v3, :cond_1

    goto :goto_1

    :cond_1
    mul-double v16, v16, v14

    const-wide v14, 0x414b774000000000L    # 3600000.0

    div-double v16, v16, v14

    invoke-static/range {v16 .. v17}, Ljava/lang/Double;->isFinite(D)Z

    move-result v3

    if-eqz v3, :cond_2

    goto :goto_2

    :cond_2
    :goto_1
    move-wide/from16 v16, v10

    :goto_2
    add-double v6, v16, v6

    iput-wide v6, v0, Lc/T5;->j2:D

    iput-wide v6, v0, Lc/T5;->l2:D

    const/4 v3, 0x1

    iput-boolean v3, v0, Lc/T5;->m2:Z

    const-wide/16 v6, 0x3a98

    cmp-long v4, v4, v6

    if-lez v4, :cond_4

    iput-boolean v3, v0, Lc/T5;->p2:Z

    goto :goto_3

    :cond_3
    const/4 v3, 0x1

    :cond_4
    :goto_3
    iput-wide v1, v0, Lc/T5;->q2:J

    iget-object v4, v0, Lc/T5;->t2:Lc/X5;

    iget-wide v5, v4, Lc/X5;->d:J

    iput-wide v5, v0, Lc/T5;->v2:J

    iget v4, v4, Lc/X5;->a:I

    const/4 v5, 0x4

    if-eq v4, v5, :cond_5

    iput-boolean v3, v0, Lc/T5;->o2:Z

    :cond_5
    :goto_4
    const/4 v3, 0x5

    goto :goto_5

    :cond_6
    move-object v13, v5

    goto :goto_4

    :goto_5
    invoke-virtual {v0, v3}, Lc/T5;->U(I)Lc/Y5;

    move-result-object v3

    if-nez v3, :cond_7

    const-wide/16 v3, -0x1

    goto :goto_6

    :cond_7
    iget-wide v3, v3, Lc/Y5;->c:J

    :goto_6
    if-eqz v13, :cond_b

    iget-wide v5, v0, Lc/T5;->w2:J

    cmp-long v5, v5, v3

    if-eqz v5, :cond_b

    iget-wide v5, v0, Lc/T5;->x2:J

    const-wide/16 v14, 0x0

    cmp-long v7, v5, v14

    if-lez v7, :cond_a

    sub-long v5, v1, v5

    iget-wide v14, v0, Lc/T5;->k2:D

    invoke-virtual {v13}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v12

    long-to-double v8, v5

    cmpg-double v7, v8, v10

    if-ltz v7, :cond_9

    const-wide v16, 0x40cd4c0000000000L    # 15000.0

    cmpl-double v7, v8, v16

    if-lez v7, :cond_8

    goto :goto_7

    :cond_8
    mul-double/2addr v12, v8

    const-wide v7, 0x414b774000000000L    # 3600000.0

    div-double/2addr v12, v7

    invoke-static {v12, v13}, Ljava/lang/Double;->isFinite(D)Z

    move-result v7

    if-eqz v7, :cond_9

    move-wide v10, v12

    :cond_9
    :goto_7
    add-double/2addr v10, v14

    iput-wide v10, v0, Lc/T5;->k2:D

    const/4 v7, 0x1

    iput-boolean v7, v0, Lc/T5;->n2:Z

    const-wide/16 v8, 0x3a98

    cmp-long v5, v5, v8

    if-lez v5, :cond_a

    iput-boolean v7, v0, Lc/T5;->p2:Z

    :cond_a
    iput-wide v1, v0, Lc/T5;->x2:J

    iput-wide v3, v0, Lc/T5;->w2:J

    :cond_b
    iget-wide v3, v0, Lc/T5;->r2:J

    sub-long/2addr v1, v3

    const-wide/16 v3, 0x7530

    cmp-long v1, v1, v3

    if-ltz v1, :cond_c

    invoke-virtual/range {p0 .. p0}, Lc/T5;->z0()V

    :cond_c
    return-void
.end method

.method public final y(Landroid/bluetooth/BluetoothDevice;I)V
    .locals 10

    iget-object v8, p0, Lc/T5;->J:Lc/M6;

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v1, "spp_method"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    new-instance v7, Lc/d6;

    invoke-direct {v7, p0, p2}, Lc/d6;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p1, :cond_0

    invoke-virtual {v8}, Lc/M6;->a()V

    iget-object p2, v8, Lc/M6;->c:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicLong;->incrementAndGet()J

    move-result-wide v3

    iget-object p2, v8, Lc/M6;->a:Ljava/util/concurrent/ExecutorService;

    new-instance v9, Lc/L6;

    const/16 v6, 0x1388

    move-object v0, v9

    move-object v1, v8

    move-object v5, p1

    invoke-direct/range {v0 .. v7}, Lc/L6;-><init>(Lc/M6;IJLandroid/bluetooth/BluetoothDevice;ILc/d6;)V

    invoke-interface {p2, v9}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    move-result-object p1

    iput-object p1, v8, Lc/M6;->d:Ljava/util/concurrent/Future;

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1
.end method

.method public final y0(Lorg/json/JSONObject;Ljava/lang/String;)Lc/Q5;
    .locals 9

    invoke-virtual {p0, p1}, Lc/T5;->f0(Lorg/json/JSONObject;)Lc/i6;

    move-result-object v5

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const-string v0, "\\s+"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/16 v1, 0x1ffe

    if-gt v0, v1, :cond_6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    and-int/lit8 v0, v0, 0x1

    if-nez v0, :cond_6

    const-string v0, "[0-9a-fA-F]*"

    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    new-array v1, v0, [B

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    if-ge v3, v0, :cond_0

    mul-int/lit8 v4, v3, 0x2

    add-int/lit8 v6, v4, 0x2

    invoke-virtual {p1, v4, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x10

    invoke-static {v4, v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v4

    int-to-byte v4, v4

    aput-byte v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    const-string v3, "(?s).*\\b[rR][0-9]+\\b.*"

    iget-object v4, v5, Lc/i6;->h:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {v1}, [B->clone()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [B

    invoke-virtual {p0}, Lc/T5;->D0()Lc/I6;

    move-result-object v4

    iget-object v6, v5, Lc/i6;->f:Ljava/lang/String;

    invoke-static {v6, v4}, Lc/k6;->R(Ljava/lang/String;Lc/I6;)[B

    move-result-object v4

    array-length v7, v4

    if-lt v0, v7, :cond_3

    :goto_1
    array-length v7, v4

    if-ge v2, v7, :cond_2

    aget-byte v7, v1, v2

    aget-byte v8, v4, v2

    if-ne v7, v8, :cond_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "\u041e\u0442\u0432\u0435\u0442 \u043d\u0435 \u0441\u043e\u043e\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u0435 PID"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_2
    array-length v2, v4

    invoke-virtual {p0}, Lc/T5;->D0()Lc/I6;

    move-result-object v4

    iget v4, v4, Lc/I6;->a:I

    invoke-static {v6, v2, v0, v4}, Lc/k6;->o0(Ljava/lang/String;III)I

    move-result v2

    invoke-static {v1, v2, v0}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v1

    goto :goto_2

    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "\u041d\u0435\u043f\u043e\u043b\u043d\u044b\u0439 \u043e\u0442\u0432\u0435\u0442 \u042d\u0411\u0423"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    const/4 v3, 0x0

    :goto_2
    iget v0, v5, Lc/i6;->k:I

    const/4 v2, 0x5

    if-ne v0, v2, :cond_5

    invoke-virtual {v5, v1}, Lc/i6;->d([B)Lc/J6;

    move-result-object v0

    new-instance v1, Lc/S5;

    iget-wide v2, v0, Lc/J6;->a:D

    invoke-virtual {p0}, Lc/T5;->H0()D

    move-result-wide v6

    invoke-virtual {v5, v2, v3, v6, v7}, Lc/i6;->a(DD)D

    move-result-wide v2

    iget v0, v0, Lc/J6;->b:I

    invoke-direct {v1, v2, v3, v0}, Lc/S5;-><init>(DI)V

    move-object v4, v1

    goto :goto_3

    :cond_5
    new-instance v0, Lc/S5;

    new-instance v2, Lc/B5;

    const/4 v4, 0x0

    invoke-direct {v2, p0, v4}, Lc/B5;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v5, v1, v3, v2}, Lc/i6;->b([B[BLjava/util/function/ToDoubleFunction;)D

    move-result-wide v1

    invoke-virtual {p0}, Lc/T5;->H0()D

    move-result-wide v3

    invoke-virtual {v5, v1, v2, v3, v4}, Lc/i6;->a(DD)D

    move-result-wide v1

    const/4 v3, -0x1

    invoke-direct {v0, v1, v2, v3}, Lc/S5;-><init>(DI)V

    move-object v4, v0

    :goto_3
    new-instance v6, Lc/Q5;

    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {p1, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    move-object v0, v6

    move-object v1, p2

    invoke-direct/range {v0 .. v5}, Lc/Q5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lc/S5;Lc/i6;)V

    return-object v6

    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0434\u0430\u043d\u043d\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u0430 \u043f\u0430\u0440\u0430\u043c\u0438 HEX-\u0446\u0438\u0444\u0440, \u0431\u0435\u0437 \u0437\u0430\u0433\u043e\u043b\u043e\u0432\u043a\u0430 \u0438 \u043d\u043e\u043c\u0435\u0440\u0430 PID"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final z(I)V
    .locals 13

    const-string v0, "spp"

    const-string v1, "\u05de\u05ea\u05d7\u05d1\u05e8 \u05d0\u05dc "

    invoke-virtual {p0}, Lc/T5;->g0()I

    move-result v2

    invoke-static {v2}, Lc/j6;->c(I)Z

    move-result v2

    if-eqz v2, :cond_d

    iget-object v2, p0, Lc/T5;->g:Lc/j6;

    if-eqz v2, :cond_1

    iget v3, v2, Lc/j6;->f:I

    invoke-static {v3}, Lc/j6;->c(I)Z

    move-result v3

    if-eqz v3, :cond_d

    iget-object v3, v2, Lc/j6;->c:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_0

    invoke-static {v3}, Lc/j6;->e(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_d

    :cond_0
    iget-object v2, v2, Lc/j6;->p:Ljava/lang/String;

    invoke-static {v2}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "(?:03|07|0A)|(?:01|02|06|09|18|19|1A|21|22|23|2C|A8)(?:[0-9A-F]{2}){1,255}"

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-static {v2}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "3E(?:00|80)"

    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-static {v2}, Lc/G8;->o(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "10[0-9A-F]{2}"

    invoke-virtual {v2, v3}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_d

    :cond_1
    invoke-virtual {p0}, Lc/T5;->A0()V

    invoke-virtual {p0}, Lc/T5;->e0()Z

    move-result v2

    if-nez v2, :cond_2

    const-string p1, "\u05e0\u05d3\u05e8\u05e9\u05ea \u05d2\u05d9\u05e9\u05d4 \u05dc\u05d1\u05dc\u05d5\u05d8\u05d5\u05e1"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void

    :cond_2
    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v2

    const-string v3, "wifi"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    const-string v0, "\u05de\u05ea\u05d7\u05d1\u05e8 \u05dc\u05de\u05ea\u05d0\u05dd Wi-Fi\u2026"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    new-instance v0, Lc/N6;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lc/T5;->L:Lc/N6;

    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lc/x;

    const/4 v3, 0x3

    invoke-direct {v2, p0, v0, p1, v3}, Lc/x;-><init>(Ljava/lang/Object;Ljava/lang/Object;II)V

    const-string p1, "DriveDeck-OBD-TCP"

    invoke-direct {v1, v2, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    return-void

    :cond_3
    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v2

    const-string v3, "usb"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const-string v3, ""

    const-string v4, "address"

    const/4 v5, 0x0

    if-eqz v2, :cond_7

    const-string v0, "\u05de\u05ea\u05d7\u05d1\u05e8 \u05dc\u05de\u05ea\u05d0\u05dd USB\u2026"

    iput-object v0, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    const-string v0, "ru.drivedeck.launcher.USB_PERMISSION"

    :try_start_0
    new-instance v1, Lc/P6;

    iget-object v2, p0, Lc/T5;->a:Landroid/content/Context;

    invoke-direct {v1, v2}, Lc/P6;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lc/T5;->M:Lc/P6;

    iget-object v2, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v2, v4, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/u0;->m(Ljava/lang/String;)Lc/u0;

    move-result-object v11

    invoke-virtual {v1, v11}, Lc/P6;->b(Lc/u0;)Landroid/hardware/usb/UsbDevice;

    move-result-object v2

    if-nez v2, :cond_4

    const-string p1, "USB-\u0430\u0434\u0430\u043f\u0442\u0435\u0440 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d"

    invoke-virtual {p0, v5, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    goto/16 :goto_2

    :catch_0
    move-exception p1

    goto/16 :goto_1

    :catch_1
    move-exception p1

    goto/16 :goto_1

    :catch_2
    move-exception p1

    goto/16 :goto_1

    :cond_4
    iget-object v3, v1, Lc/P6;->a:Landroid/hardware/usb/UsbManager;

    invoke-virtual {v3, v2}, Landroid/hardware/usb/UsbManager;->hasPermission(Landroid/hardware/usb/UsbDevice;)Z

    move-result v3

    if-eqz v3, :cond_5

    new-instance v0, Ljava/lang/Thread;

    new-instance v3, Lc/F5;

    const/4 v12, 0x0

    move-object v6, v3

    move-object v7, p0

    move-object v8, v1

    move-object v9, v2

    move-object v10, v11

    move v11, p1

    invoke-direct/range {v6 .. v12}, Lc/F5;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    const-string p1, "DriveDeck-OBD-USB"

    invoke-direct {v0, v3, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto :goto_2

    :cond_5
    new-instance v3, Lc/N5;

    move-object v6, v3

    move-object v7, p0

    move v8, p1

    move-object v9, v1

    move-object v10, v2

    invoke-direct/range {v6 .. v11}, Lc/N5;-><init>(Lc/T5;ILc/P6;Landroid/hardware/usb/UsbDevice;Lc/u0;)V

    iput-object v3, p0, Lc/T5;->N:Lc/N5;

    new-instance v3, Landroid/content/IntentFilter;

    invoke-direct {v3, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Lc/T5;->a:Landroid/content/Context;

    iget-object v6, p0, Lc/T5;->N:Lc/N5;

    const/4 v7, 0x4

    invoke-virtual {v4, v6, v3, v7}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    new-instance v3, Landroid/content/Intent;

    invoke-direct {v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lc/T5;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1f

    if-lt v3, v4, :cond_6

    const/high16 v3, 0x2000000

    goto :goto_0

    :cond_6
    move v3, v5

    :goto_0
    const/high16 v4, 0x8000000

    or-int/2addr v3, v4

    iget-object v4, p0, Lc/T5;->a:Landroid/content/Context;

    invoke-static {v4, p1, v0, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    invoke-virtual {v1, v2, p1}, Lc/P6;->d(Landroid/hardware/usb/UsbDevice;Landroid/app/PendingIntent;)V

    const-string p1, "\u05d0\u05e9\u05e8 \u05d2\u05d9\u05e9\u05d4 \u05dc\u05de\u05ea\u05d0\u05dd USB"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :goto_1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c USB: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v5, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    :goto_2
    return-void

    :cond_7
    :try_start_1
    invoke-virtual {p0}, Lc/T5;->c()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v2

    if-eqz v2, :cond_b

    invoke-virtual {v2}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z

    move-result v6

    if-nez v6, :cond_8

    goto :goto_4

    :cond_8
    iget-object v6, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v6, v4, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/bluetooth/BluetoothAdapter;->checkBluetoothAddress(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_9

    const-string p1, "\u05d1\u05d7\u05e8 \u05de\u05ea\u05d0\u05dd OBD"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void

    :cond_9
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    const-string v6, "name"

    invoke-interface {v1, v6, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\u2026"

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    invoke-virtual {v2, v3}, Landroid/bluetooth/BluetoothAdapter;->getRemoteDevice(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;

    move-result-object v1

    invoke-virtual {p0, v1, p1}, Lc/T5;->y(Landroid/bluetooth/BluetoothDevice;I)V

    goto :goto_3

    :cond_a
    invoke-virtual {v2, v3}, Landroid/bluetooth/BluetoothAdapter;->getRemoteDevice(Ljava/lang/String;)Landroid/bluetooth/BluetoothDevice;

    move-result-object p1

    iget-object v1, p0, Lc/T5;->a:Landroid/content/Context;

    iget-object v2, p0, Lc/T5;->D2:Lc/K5;

    const/4 v3, 0x2

    invoke-virtual {p1, v1, v5, v2, v3}, Landroid/bluetooth/BluetoothDevice;->connectGatt(Landroid/content/Context;ZLandroid/bluetooth/BluetoothGattCallback;I)Landroid/bluetooth/BluetoothGatt;

    move-result-object p1

    iput-object p1, p0, Lc/T5;->J1:Landroid/bluetooth/BluetoothGatt;

    :goto_3
    invoke-virtual {p0}, Lc/T5;->P0()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_c

    iget-object p1, p0, Lc/T5;->c:Landroid/os/Handler;

    iget-object v0, p0, Lc/T5;->e2:Lc/A5;

    const-wide/16 v1, 0x1388

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_5

    :cond_b
    :goto_4
    const-string p1, "\u05d1\u05dc\u05d5\u05d8\u05d5\u05e1 \u05db\u05d1\u05d5\u05d9"

    invoke-virtual {p0, v5, p1}, Lc/T5;->J(ZLjava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_3

    return-void

    :catch_3
    const-string p1, "\u05e9\u05d2\u05d9\u05d0\u05ea \u05d7\u05d9\u05d1\u05d5\u05e8 OBD"

    invoke-virtual {p0, v5, p1}, Lc/T5;->J(ZLjava/lang/String;)V

    :cond_c
    :goto_5
    return-void

    :cond_d
    const-string p1, "\u05d4\u05e4\u05e8\u05d5\u05e4\u05d9\u05dc \u05d0\u05d5 \u05d4\u05e4\u05e8\u05d5\u05d8\u05d5\u05e7\u05d5\u05dc \u05e9\u05e0\u05d1\u05d7\u05e8 \u05d0\u05d9\u05e0\u05d5 \u05e0\u05ea\u05de\u05da \u05e2\u05d3\u05d9\u05d9\u05df"

    iput-object p1, p0, Lc/T5;->C1:Ljava/lang/String;

    invoke-virtual {p0}, Lc/T5;->q()V

    return-void
.end method

.method public final z0()V
    .locals 3

    iget-object v0, p0, Lc/T5;->b:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-wide v1, p0, Lc/T5;->j2:D

    invoke-static {v1, v2}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object v1

    const-string v2, "trip_fuel"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-wide v1, p0, Lc/T5;->k2:D

    invoke-static {v1, v2}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object v1

    const-string v2, "trip_distance"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-wide v1, p0, Lc/T5;->l2:D

    invoke-static {v1, v2}, Ljava/lang/Double;->toString(D)Ljava/lang/String;

    move-result-object v1

    const-string v2, "trip_paired_fuel"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "trip_has_fuel"

    iget-boolean v2, p0, Lc/T5;->m2:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "trip_has_distance"

    iget-boolean v2, p0, Lc/T5;->n2:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "trip_estimated"

    iget-boolean v2, p0, Lc/T5;->o2:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "trip_gaps"

    iget-boolean v2, p0, Lc/T5;->p2:Z

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iput-wide v0, p0, Lc/T5;->r2:J

    return-void
.end method
