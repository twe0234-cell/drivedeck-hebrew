.class public final Lru/drivedeck/launcher/MainActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field public static final synthetic F0:I


# instance fields
.field public A:Z

.field public A0:Z

.field public B:Lc/P4;

.field public B0:I

.field public C:Lc/P4;

.field public final C0:Lc/J1;

.field public D:Z

.field public D0:Lc/t8;

.field public E:Ljava/lang/String;

.field public final E0:Lc/P4;

.field public F:J

.field public G:Z

.field public H:J

.field public I:J

.field public J:Lc/P;

.field public K:Lc/m5;

.field public L:Z

.field public M:J

.field public final N:Lc/J1;

.field public O:Lc/J8;

.field public final P:Lc/N4;

.field public Q:Z

.field public R:J

.field public S:Lc/j;

.field public T:Lc/D3;

.field public U:Lc/k3;

.field public V:Lc/g9;

.field public W:Lc/l9;

.field public X:Lc/u0;

.field public Y:Lc/Z7;

.field public Z:Lc/d8;

.field public a:Lc/z;

.field public a0:Lc/Q0;

.field public b:Lc/n1;

.field public final b0:Ljava/util/HashSet;

.field public c:Z

.field public c0:Z

.field public d:Lc/e0;

.field public d0:Ljava/lang/String;

.field public e:Lc/s4;

.field public e0:Ljava/lang/String;

.field public f:Lc/m2;

.field public f0:Lc/Q;

.field public g:Lc/Q3;

.field public g0:Ljava/util/List;

.field public h:Landroid/widget/FrameLayout;

.field public h0:Ljava/lang/String;

.field public i:Landroid/view/View;

.field public i0:J

.field public j:Landroid/view/View;

.field public j0:J

.field public k:J

.field public k0:I

.field public l:Lc/b2;

.field public l0:I

.field public m:Lc/b2;

.field public m0:Ljava/lang/String;

.field public n:Lc/F;

.field public n0:Z

.field public o:Lc/F;

.field public o0:Z

.field public p:Landroid/view/ViewGroup;

.field public p0:Z

.field public q:Lc/b2;

.field public q0:Z

.field public r:Landroid/view/ViewGroup$LayoutParams;

.field public r0:Z

.field public s:I

.field public s0:Z

.field public t:I

.field public t0:Ljava/lang/String;

.field public u:Z

.field public final u0:Landroid/os/Handler;

.field public v:Lc/n3;

.field public v0:Z

.field public w:Landroid/view/View;

.field public final w0:Lc/O4;

.field public x:Z

.field public final x0:Lc/N4;

.field public y:Z

.field public y0:J

.field public z:Z

.field public z0:J


# direct methods
.method public constructor <init>()V
    .locals 4

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->c:Z

    const/4 v1, -0x1

    iput v1, p0, Lru/drivedeck/launcher/MainActivity;->t:I

    const-string v1, ""

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    new-instance v2, Lc/J1;

    const/16 v3, 0xf

    invoke-direct {v2, p0, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->N:Lc/J1;

    new-instance v2, Lc/N4;

    const/4 v3, 0x0

    invoke-direct {v2, p0, v3}, Lc/N4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->P:Lc/N4;

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b0:Ljava/util/HashSet;

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->e0:Ljava/lang/String;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->g0:Ljava/util/List;

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->h0:Ljava/lang/String;

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->p0:Z

    const-string v0, "home"

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->t0:Ljava/lang/String;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    new-instance v1, Lc/O4;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v0, v2}, Lc/O4;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->w0:Lc/O4;

    new-instance v0, Lc/N4;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lc/N4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->x0:Lc/N4;

    new-instance v0, Lc/J1;

    const/16 v1, 0x10

    invoke-direct {v0, p0, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->C0:Lc/J1;

    new-instance v0, Lc/P4;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lc/P4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->E0:Lc/P4;

    return-void
.end method

.method public static E(Landroid/view/View;)Lc/b2;
    .locals 1

    instance-of v0, p0, Lc/Q3;

    if-eqz v0, :cond_0

    check-cast p0, Lc/Q3;

    iget-object p0, p0, Lc/Q3;->D:Lc/b2;

    return-object p0

    :cond_0
    instance-of v0, p0, Lc/m2;

    if-eqz v0, :cond_1

    check-cast p0, Lc/m2;

    iget-object p0, p0, Lc/m2;->u:Lc/b2;

    return-object p0

    :cond_1
    const/4 p0, 0x0

    return-object p0
.end method

.method public static G(Landroid/content/Intent;)V
    .locals 2

    if-eqz p0, :cond_2

    invoke-virtual {p0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v0

    if-eqz v0, :cond_2

    const-string v0, "android.intent.action.MAIN"

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "ru.drivedeck.launcher.PhoneEntry"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, "ru.drivedeck.launcher.PHONE"

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_0

    :cond_1
    const-string v1, "ru.drivedeck.launcher.MusicEntry"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "ru.drivedeck.launcher.MUSIC"

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    :cond_2
    :goto_0
    return-void
.end method

.method public static a(Lru/drivedeck/launcher/MainActivity;)V
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->n0()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->j0()Z

    move-result v0

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->v0:Z

    if-eq v0, v1, :cond_1

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->v0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->e()V

    :cond_1
    :goto_0
    return-void
.end method

.method public static e0(Landroid/view/View;Z)V
    .locals 1

    instance-of v0, p0, Lc/F;

    if-eqz v0, :cond_1

    check-cast p0, Lc/F;

    iput-boolean p1, p0, Lc/F;->c:Z

    if-eqz p1, :cond_0

    iget-object p1, p0, Lc/F;->s:Lc/D;

    invoke-virtual {p0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    iget-boolean p1, p0, Lc/F;->a:Z

    if-eqz p1, :cond_1

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lc/F;->s(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lc/F;->d()V

    :cond_1
    :goto_0
    return-void
.end method


# virtual methods
.method public final A()V
    .locals 4

    iget-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    const/4 v1, 0x0

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/j;->dismiss()V

    :cond_0
    return-void
.end method

.method public final B()Z
    .locals 4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lt v0, v1, :cond_1

    const-string v0, "role"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lc/A1;->b(Ljava/lang/Object;)Landroid/app/role/RoleManager;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Lc/A1;->g(Landroid/app/role/RoleManager;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    move v2, v3

    :goto_0
    return v2

    :cond_1
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.MAIN"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.intent.category.HOME"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    invoke-virtual {v1, v0, v3}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v0

    if-eqz v0, :cond_2

    iget-object v1, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v0, v0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_1

    :cond_2
    move v2, v3

    :goto_1
    return v2
.end method

.method public final C(Z)V
    .locals 2

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->p0:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    if-nez v0, :cond_5

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    if-nez v0, :cond_5

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_1

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->h0()V

    return-void

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_5

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    goto :goto_1

    :cond_2
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v0

    if-nez v0, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->D()V

    return-void

    :cond_4
    :goto_0
    if-eqz p1, :cond_5

    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->o0:Z

    if-nez p1, :cond_5

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->o0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k0()V

    :cond_5
    :goto_1
    return-void
.end method

.method public final D()V
    .locals 5

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "\u0421\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0441 \u0434\u0432\u0443\u043c\u044f \u043e\u043a\u043d\u0430\u043c\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0430"

    invoke-static {p0, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->h0()V

    return-void

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_4

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_1

    goto :goto_1

    :cond_1
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v1

    if-nez v1, :cond_2

    goto :goto_0

    :cond_2
    iput-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    const-string v1, "split"

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v1, v3}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v1

    invoke-static {p0, v0, v2, v1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->f(Landroid/content/ContextWrapper;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    return-void

    :cond_3
    :goto_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k0()V

    return-void

    :cond_4
    :goto_1
    const-string v2, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043e\u0431\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {p0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {p0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    xor-int/2addr v0, v3

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->g(I)V

    return-void
.end method

.method public final F(Landroid/view/View;)Lc/t2;
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    const-string v1, "ru.yandex.yandexnavi"

    if-ne p1, v0, :cond_0

    if-eqz v0, :cond_0

    invoke-virtual {v0, v1}, Lc/Q3;->H(Ljava/lang/String;)Lc/t2;

    move-result-object p1

    return-object p1

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne p1, v0, :cond_1

    if-eqz v0, :cond_1

    invoke-virtual {v0, v1}, Lc/m2;->B(Ljava/lang/String;)Lc/t2;

    move-result-object p1

    return-object p1

    :cond_1
    const/4 p1, 0x0

    return-object p1
.end method

.method public final H()V
    .locals 1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    invoke-virtual {v0}, Lc/j;->dismiss()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->g0()V

    :goto_0
    return-void
.end method

.method public final I(Ljava/lang/String;)V
    .locals 5

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    const-string v0, ""

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, "dock_single_fullscreen"

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const/4 v3, 0x0

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_7

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->o0()Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_0

    :cond_0
    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    const-string v2, "single"

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->o0()Z

    move-result v1

    if-nez v1, :cond_2

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v1, :cond_8

    invoke-virtual {v1}, Lc/Q3;->f()Z

    if-nez p1, :cond_1

    move-object p1, v0

    :cond_1
    iput-object p1, v1, Lc/Q3;->G:Ljava/lang/String;

    iget-object v0, v1, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0, p1}, Lc/t2;->e0(Ljava/lang/String;)V

    iget-object p1, v1, Lc/Q3;->F:Lc/n1;

    iget-object v0, v1, Lc/Q3;->G:Ljava/lang/String;

    invoke-virtual {p1, v0}, Lc/n1;->x0(Ljava/lang/String;)V

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iput-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    iput-boolean v4, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    iput-boolean v4, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v4, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->o()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->t(Landroid/view/View;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v0, p1}, Lc/m2;->K(Ljava/lang/String;)V

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v2, p1}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    goto :goto_1

    :cond_3
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_6

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-boolean v1, v0, Lc/m2;->I:Z

    if-eqz v1, :cond_4

    if-eqz p1, :cond_4

    iget-object v0, v0, Lc/m2;->t:[Lc/t2;

    aget-object v0, v0, v3

    iget-object v0, v0, Lc/t2;->u:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    return-void

    :cond_4
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-boolean v1, v0, Lc/m2;->I:Z

    if-eqz v1, :cond_5

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    if-eqz v1, :cond_5

    move v3, v4

    :cond_5
    invoke-virtual {v0, p1}, Lc/m2;->K(Ljava/lang/String;)V

    iput-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, v2, p1}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    goto :goto_1

    :cond_6
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v0, p1}, Lc/z;->h(Ljava/lang/String;)Z

    goto :goto_1

    :cond_7
    :goto_0
    invoke-virtual {p0, v3, p1}, Lru/drivedeck/launcher/MainActivity;->N(ZLjava/lang/String;)V

    :cond_8
    :goto_1
    return-void
.end method

.method public final J(Ljava/lang/String;Ljava/lang/String;F)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-object v5, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->o0()Z

    move-result v5

    if-nez v5, :cond_0

    return-void

    :cond_0
    const/high16 v5, 0x3f000000    # 0.5f

    invoke-static {v1, v2, v5}, Lc/G8;->a0(Ljava/lang/String;Ljava/lang/String;F)Ljava/lang/String;

    move-result-object v5

    iget-boolean v6, v0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v6, :cond_3

    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v6, :cond_3

    iget-boolean v6, v6, Lc/m2;->I:Z

    if-nez v6, :cond_3

    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    invoke-virtual/range {p1 .. p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v6, v8}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1

    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v6, v7}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    :cond_1
    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v6, v8}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v6, v7}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3

    :cond_2
    move v6, v7

    goto :goto_0

    :cond_3
    move v6, v8

    :goto_0
    if-eqz v6, :cond_4

    iget-wide v9, v0, Lru/drivedeck/launcher/MainActivity;->F:J

    cmp-long v9, v3, v9

    if-gez v9, :cond_4

    return-void

    :cond_4
    if-eqz v6, :cond_5

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v1, v7}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v1

    :cond_5
    move-object v14, v1

    if-eqz v6, :cond_6

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v1, v8}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    :cond_6
    move-object v1, v2

    :goto_1
    if-eqz v6, :cond_7

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->I()F

    move-result v2

    goto :goto_2

    :cond_7
    move/from16 v2, p3

    :goto_2
    iget-object v6, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v6, v14, v1, v2}, Lc/n1;->Q0(Ljava/lang/String;Ljava/lang/String;F)Z

    move-result v2

    if-nez v2, :cond_8

    const-string v1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0443\u0436\u0435 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u0432 \u0434\u0440\u0443\u0433\u043e\u043c \u043e\u043a\u043d\u0435"

    invoke-static {v0, v1, v0, v8}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :cond_8
    iput-object v5, v0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    const-wide/16 v5, 0x1388

    add-long/2addr v5, v3

    iput-wide v5, v0, Lru/drivedeck/launcher/MainActivity;->F:J

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-boolean v2, v0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v2, :cond_9

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v5, "windows"

    invoke-virtual {v2, v5}, Lc/n1;->C0(Ljava/lang/String;)V

    iput-boolean v8, v0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->u()V

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v2, :cond_b

    invoke-virtual {v2, v3, v4}, Lc/m2;->I(J)V

    goto :goto_3

    :cond_9
    iget-boolean v2, v0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v2, :cond_a

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v2, :cond_a

    invoke-virtual {v2, v3, v4}, Lc/m2;->I(J)V

    iput-boolean v8, v0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    const-string v2, "split"

    filled-new-array {v14, v1}, [Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    goto :goto_3

    :cond_a
    iput-boolean v8, v0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->D()V

    :cond_b
    :goto_3
    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v2, :cond_c

    iget-object v2, v2, Lc/m2;->K:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_c

    iget-object v2, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-object v12, v2, Lc/m2;->K:Ljava/lang/String;

    const-string v10, "pair"

    const-string v11, "pair_switch_id"

    const-string v9, "action"

    const-string v13, "left"

    const-string v15, "right"

    move-object/from16 v16, v1

    filled-new-array/range {v9 .. v16}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "dock_action"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_c
    return-void
.end method

.method public final K()V
    .locals 0

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->h()V

    return-void
.end method

.method public final L(I)V
    .locals 1

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/F;->f()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_1

    invoke-virtual {v0, p1}, Lc/m2;->z(I)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, p1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object p1

    :goto_0
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2

    return-void

    :cond_2
    const/4 v0, 0x1

    invoke-virtual {p0, v0, p1}, Lru/drivedeck/launcher/MainActivity;->N(ZLjava/lang/String;)V

    return-void
.end method

.method public final M(I)V
    .locals 8

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lc/F;->f()Z

    const/4 v1, 0x0

    if-ltz p1, :cond_5

    iget-object v2, v0, Lc/m2;->t:[Lc/t2;

    array-length v3, v2

    if-lt p1, v3, :cond_0

    goto :goto_3

    :cond_0
    aget-object v3, v2, p1

    invoke-virtual {v3}, Lc/t2;->k()V

    iget-boolean v3, v0, Lc/m2;->I:Z

    if-eqz v3, :cond_1

    const-string v4, "single"

    goto :goto_0

    :cond_1
    const-string v4, "split"

    :goto_0
    const-string v5, ""

    if-nez p1, :cond_2

    move-object v6, v5

    goto :goto_1

    :cond_2
    aget-object v6, v2, v1

    iget-object v6, v6, Lc/t2;->u:Ljava/lang/String;

    :goto_1
    const/4 v7, 0x1

    if-nez v3, :cond_4

    if-ne p1, v7, :cond_3

    goto :goto_2

    :cond_3
    aget-object p1, v2, v7

    iget-object v5, p1, Lc/t2;->u:Ljava/lang/String;

    :cond_4
    :goto_2
    iget-object p1, v0, Lc/m2;->y:Lc/n1;

    iget-object v0, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v2, "startup_single_from_home"

    invoke-interface {v0, v2, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    invoke-virtual {p1, v4, v6, v5, v0}, Lc/n1;->y0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    :cond_5
    :goto_3
    const-string p1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0437\u0430\u043a\u0440\u044b\u0442\u043e"

    invoke-static {p0, p1, p0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :cond_6
    return-void
.end method

.method public final N(ZLjava/lang/String;)V
    .locals 7

    invoke-virtual {p0, p2}, Lru/drivedeck/launcher/MainActivity;->f(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_0

    :cond_0
    const-string v0, "package"

    if-eqz p1, :cond_3

    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz p1, :cond_1

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz p1, :cond_1

    invoke-virtual {p1, p2}, Lc/Q3;->y(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_2

    :cond_1
    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz p1, :cond_3

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_3

    invoke-virtual {p1, p2}, Lc/m2;->B(Ljava/lang/String;)Lc/t2;

    move-result-object v1

    invoke-virtual {p1, v1}, Lc/F;->i(Lc/t2;)Z

    move-result p1

    if-eqz p1, :cond_3

    :cond_2
    const-string p1, "embedded_app_expand"

    filled-new-array {v0, p2}, [Ljava/lang/Object;

    move-result-object p2

    invoke-static {p1, p2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void

    :cond_3
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    const-string p1, "__launcher_phone__"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->P()V

    return-void

    :cond_4
    const-string p1, "__launcher_music__"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->O()V

    return-void

    :cond_5
    const-string p1, "external_app_launch"

    filled-new-array {v0, p2}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {p1, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move-object v1, p0

    move-object v2, p2

    invoke-static/range {v1 .. v6}, Lc/j8;->w(Landroid/content/Context;Ljava/lang/String;ILc/v7;ZZ)Z

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_6

    const-string p1, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0430\u043a\u0442\u0438\u0432\u043d\u043e\u0441\u0442\u044c"

    invoke-static {p0, p1, p0, v0}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :cond_6
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1, p2}, Lc/n1;->w0(Ljava/lang/String;)V

    const-wide/16 p1, 0x0

    iput-wide p1, p0, Lru/drivedeck/launcher/MainActivity;->H:J

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz p1, :cond_7

    invoke-virtual {p1, v0}, Lc/Q3;->P(Z)V

    :cond_7
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_8

    invoke-virtual {p1, v0}, Lc/m2;->G(Z)V

    :cond_8
    :goto_0
    return-void
.end method

.method public final O()V
    .locals 6

    const/4 v0, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_3

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-nez v1, :cond_3

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_0

    :cond_0
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Landroid/app/Dialog;->dismiss()V

    :cond_1
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v3, Lc/y;

    const/4 v4, 0x0

    invoke-direct {v3, p0, v4}, Lc/y;-><init>(Ljava/lang/Object;Z)V

    sget v4, Lc/Q3;->c0:I

    new-instance v4, Lc/D3;

    const v5, 0x103022e

    invoke-direct {v4, p0, v5}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v5, 0x1

    invoke-virtual {v4, v5}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    invoke-static {p0, v1, v2, v3}, Lc/Q3;->G(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;)Lc/C3;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    invoke-virtual {v4}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-virtual {v1, v0}, Landroid/view/Window;->clearFlags(I)V

    const/4 v2, -0x1

    invoke-virtual {v1, v2, v2}, Landroid/view/Window;->setLayout(II)V

    invoke-static {v1}, Lc/b4;->b(Landroid/view/Window;)V

    :cond_2
    iput-object v4, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    new-instance v1, Lc/g;

    invoke-direct {v1, p0, v0}, Lc/g;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v4, v1}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    :cond_3
    :goto_0
    return-void
.end method

.method public final P()V
    .locals 2

    # he-16: the unit's phone app instead of DriveDeck's
    invoke-static {p0}, Lru/drivedeck/launcher/HeCall;->openPhone(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :he16_own_dialler

    return-void

    :he16_own_dialler

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->hasWindowFocus()Z

    move-result v0

    if-eqz v0, :cond_2

    return-void

    :cond_2
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_3
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->s()V

    new-instance v0, Lc/Q0;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    invoke-direct {v0, p0, v1}, Lc/Q0;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    invoke-virtual {v0}, Lc/Q0;->show()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->Y()V

    :cond_4
    :goto_0
    return-void
.end method

.method public final Q(I)V
    .locals 3

    const/4 v0, 0x0

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->o0:Z

    if-nez p1, :cond_0

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->X()V

    :cond_0
    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "package:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_1
    const/4 v0, 0x2

    if-ne p1, v0, :cond_2

    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.settings.ACCESSIBILITY_SETTINGS"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_2
    return-void
.end method

.method public final R()V
    .locals 2

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_1

    const/4 v1, 0x1

    iget-object v0, v0, Lc/Q3;->t:Lc/P3;

    iput-boolean v1, v0, Lc/P3;->K1:Z

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_1
    return-void
.end method

.method public final S()V
    .locals 3

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const-string v0, "\u0421\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0441 \u0434\u0432\u0443\u043c\u044f \u043e\u043a\u043d\u0430\u043c\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0430"

    invoke-static {p0, v0, p0, v1}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :cond_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, "windows"

    invoke-virtual {v0, v2}, Lc/n1;->C0(Ljava/lang/String;)V

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->u()V

    return-void
.end method

.method public final varargs T(Ljava/lang/String;[Ljava/lang/String;)V
    .locals 10

    const/4 v0, 0x1

    const-string v1, "home"

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, ""

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v1, :cond_0

    iget-object v1, v1, Lc/Q3;->G:Ljava/lang/String;

    goto :goto_0

    :cond_0
    array-length v1, p2

    if-lez v1, :cond_1

    aget-object v1, p2, v3

    goto :goto_0

    :cond_1
    move-object v1, v2

    :goto_0
    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    array-length v5, p2

    if-le v5, v0, :cond_2

    aget-object v5, p2, v0

    goto :goto_1

    :cond_2
    move-object v5, v2

    :goto_1
    const-string v6, "single"

    invoke-virtual {v6, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4

    iget-boolean v6, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    if-eqz v6, :cond_3

    goto :goto_2

    :cond_3
    move v6, v3

    goto :goto_3

    :cond_4
    :goto_2
    move v6, v0

    :goto_3
    invoke-virtual {v4, p1, v1, v5, v6}, Lc/n1;->y0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->t0:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    return-void

    :cond_5
    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->t0:Ljava/lang/String;

    sget-object v1, Lc/N1;->W:Landroid/os/Handler;

    new-instance v9, Lorg/json/JSONArray;

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    :goto_4
    array-length v1, p2

    if-ge v3, v1, :cond_8

    const/4 v1, 0x2

    if-ge v3, v1, :cond_8

    aget-object v1, p2, v3

    if-eqz v1, :cond_6

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v6, 0x80

    if-le v4, v6, :cond_7

    :cond_6
    move-object v1, v2

    :cond_7
    invoke-virtual {v9, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    add-int/2addr v3, v0

    goto :goto_4

    :cond_8
    const-string v4, "from"

    const-string v6, "to"

    const-string v8, "visible_slots"

    move-object v7, p1

    filled-new-array/range {v4 .. v9}, [Ljava/lang/Object;

    move-result-object p2

    const-string v0, "dashboard_switch"

    invoke-static {v0, p2}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->t0:Ljava/lang/String;

    return-void
.end method

.method public final U()V
    .locals 5

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/Q3;->I()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0}, Lc/Q3;->K()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_3

    iget-object v1, v0, Lc/m2;->t:[Lc/t2;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v2, :cond_1

    aget-object v4, v1, v3

    invoke-virtual {v4}, Lc/t2;->b()V

    invoke-virtual {v4}, Landroid/view/View;->requestLayout()V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v0}, Lc/F;->d()V

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    if-eqz v0, :cond_3

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-eqz v1, :cond_2

    invoke-virtual {v0}, Lc/b2;->j()V

    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->invalidateOutline()V

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_3
    return-void
.end method

.method public final V()V
    .locals 7

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-boolean v0, v0, Lc/l9;->n:Z

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_0

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    iget-object v0, v0, Lc/l9;->a:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    if-eqz v2, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const/16 v2, 0x7f6

    if-ne v0, v2, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-virtual {v0}, Lc/l9;->b()V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_1
    :goto_0
    return-void

    :cond_2
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-nez v0, :cond_3

    const-string v2, "disabled"

    goto :goto_1

    :cond_3
    iget-object v2, v0, Lc/g9;->q:Ljava/lang/String;

    :goto_1
    const-string v3, "recognizing"

    const-string v4, "listening"

    if-eqz v0, :cond_6

    iget-boolean v5, v0, Lc/g9;->o:Z

    if-nez v5, :cond_6

    iget-boolean v5, v0, Lc/g9;->n:Z

    if-eqz v5, :cond_4

    iget-object v5, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    :cond_4
    iget-object v5, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    const-string v5, "music_query"

    iget-object v6, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    const-string v5, "call_query"

    iget-object v6, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    const-string v5, "call_lookup"

    iget-object v6, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_5

    const-string v5, "confirm"

    iget-object v0, v0, Lc/g9;->q:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    :cond_5
    const/4 v0, 0x1

    goto :goto_2

    :cond_6
    const/4 v0, 0x0

    :goto_2
    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v5, :cond_c

    iget-boolean v5, v5, Lc/g9;->n:Z

    if-nez v5, :cond_7

    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->r0()Z

    move-result v5

    if-eqz v5, :cond_c

    :cond_7
    if-eqz v0, :cond_c

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-eqz v0, :cond_c

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_8

    goto :goto_5

    :cond_8
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-nez v0, :cond_9

    new-instance v0, Lc/l9;

    invoke-direct {v0, p0}, Lc/l9;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_9
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    goto :goto_3

    :cond_a
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    invoke-virtual {v1}, Lc/g9;->p()Ljava/lang/String;

    move-result-object v1

    goto :goto_4

    :cond_b
    :goto_3
    const-string v1, "\u0421\u043b\u0443\u0448\u0430\u044e\u2026"

    :goto_4
    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lc/l9;->f(Ljava/lang/String;)V

    return-void

    :cond_c
    :goto_5
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v0, :cond_f

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_6

    :cond_d
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    iget-object v0, v0, Lc/l9;->q:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_f

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-virtual {v0}, Lc/l9;->c()V

    goto :goto_7

    :cond_e
    :goto_6
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-virtual {v0}, Lc/l9;->b()V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_f
    :goto_7
    return-void
.end method

.method public final W()V
    .locals 6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lru/drivedeck/launcher/MainActivity;->x(Landroid/view/View;Z)V

    iget-wide v2, p0, Lru/drivedeck/launcher/MainActivity;->k:J

    const-wide/16 v4, 0x1

    add-long/2addr v2, v4

    iput-wide v2, p0, Lru/drivedeck/launcher/MainActivity;->k:J

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    if-nez v2, :cond_0

    return-void

    :cond_0
    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-ne v3, v2, :cond_1

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    :cond_1
    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-ne v3, v2, :cond_2

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    :cond_2
    invoke-virtual {v2, v1}, Lc/m2;->G(Z)V

    invoke-virtual {v2}, Lc/m2;->F()V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    if-eqz v1, :cond_3

    invoke-virtual {v1, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_3
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v1, v2, :cond_4

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    :cond_4
    return-void
.end method

.method public final X()V
    .locals 2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-lt v0, v1, :cond_0

    const-string v0, "role"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lc/A1;->b(Ljava/lang/Object;)Landroid/app/role/RoleManager;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {v0}, Lc/A1;->j(Landroid/app/role/RoleManager;)Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {v0}, Lc/A1;->d(Landroid/app/role/RoleManager;)Landroid/content/Intent;

    move-result-object v0

    const/16 v1, 0x2a

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void

    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.settings.HOME_SETTINGS"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public final Y()V
    .locals 3

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const-string v1, "android.permission.READ_CONTACTS"

    invoke-virtual {p0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1f

    if-lt v1, v2, :cond_1

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_1

    const-string v2, "android.permission.BLUETOOTH_CONNECT"

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/16 v2, 0x21

    if-lt v1, v2, :cond_2

    const-string v1, "android.permission.POST_NOTIFICATIONS"

    invoke-virtual {p0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3

    const/4 v1, 0x0

    new-array v1, v1, [Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    const/16 v1, 0x1f92

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    goto :goto_0

    :cond_3
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    invoke-virtual {v0}, Lc/Z7;->g()V

    :goto_0
    return-void
.end method

.method public final Z()V
    .locals 4

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lc/Q3;->O()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0, v1}, Lc/Q3;->P(Z)V

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    :goto_0
    return-void

    :cond_2
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, ""

    invoke-virtual {v0, v2}, Lc/n1;->w0(Ljava/lang/String;)V

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_5

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_5

    invoke-virtual {v0, v1}, Lc/m2;->G(Z)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-boolean v1, v0, Lc/m2;->I:Z

    if-eqz v1, :cond_4

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    if-eqz v1, :cond_3

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Lc/m2;->H()V

    goto :goto_1

    :cond_4
    invoke-virtual {v0}, Lc/m2;->D()V

    :goto_1
    return-void

    :cond_5
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v0, :cond_6

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lc/Q3;->O()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0, v1}, Lc/Q3;->P(Z)V

    return-void

    :cond_6
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, "cards"

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v3, "dashboard_mode"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "windows"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->u()V

    goto :goto_2

    :cond_7
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->h0()V

    :goto_2
    return-void
.end method

.method public final a0(Ljava/lang/Runnable;)V
    .locals 8

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_4

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    iget-wide v3, v0, Lc/g9;->t:J

    iget-boolean v5, v0, Lc/g9;->n:Z

    new-instance v7, Lc/f9;

    move-object v1, v7

    move-object v2, v0

    move-object v6, p1

    invoke-direct/range {v1 .. v6}, Lc/f9;-><init>(Lc/g9;JZLjava/lang/Runnable;)V

    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-nez p1, :cond_1

    const/4 p1, 0x1

    iput-boolean p1, v0, Lc/g9;->o:Z

    invoke-virtual {v7}, Lc/f9;->run()V

    return-void

    :cond_1
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-nez p1, :cond_2

    new-instance p1, Lc/l9;

    invoke-direct {p1, p0}, Lc/l9;-><init>(Landroid/app/Activity;)V

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_2
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    const-string v0, "\u0421\u043b\u0443\u0448\u0430\u044e\u2026"

    invoke-static {p0, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lc/l9;->f(Ljava/lang/String;)V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    new-instance v0, Lc/H;

    const/16 v1, 0x14

    invoke-direct {v0, p0, v7, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-boolean v1, p1, Lc/l9;->l:Z

    if-nez v1, :cond_3

    goto :goto_0

    :cond_3
    iget-object v1, p1, Lc/l9;->q:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p1, Lc/l9;->b:Lc/k9;

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_4
    :goto_0
    return-void
.end method

.method public final attachBaseContext(Landroid/content/Context;)V
    .locals 3

    new-instance v0, Lc/n1;

    invoke-direct {v0, p1}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/content/res/Configuration;

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    invoke-virtual {p1, v1}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object p1

    invoke-super {p0, p1}, Landroid/app/Activity;->attachBaseContext(Landroid/content/Context;)V

    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .locals 1

    invoke-static {}, Lc/G8;->l()V

    invoke-static {p0, p1}, Lc/G8;->c0(Landroid/content/Context;Ljava/lang/String;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l0()Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "com.syu.radio"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x1

    invoke-static {p0, p1}, Lc/J;->f(Landroid/content/Context;I)Z

    goto :goto_0

    :cond_0
    invoke-static {p0, p1}, Lc/J;->c(Landroid/content/Context;Ljava/lang/String;)Z

    invoke-static {p0, p1}, Lc/G8;->p0(Landroid/content/Context;Ljava/lang/String;)Z

    invoke-static {p0, p1}, Lc/G8;->Z(Landroid/content/Context;Ljava/lang/String;)V

    :goto_0
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lc/P3;->X1:Landroid/graphics/Typeface;

    iget-object p1, p1, Lc/Q3;->t:Lc/P3;

    invoke-virtual {p1}, Lc/P3;->Y()V

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    :cond_1
    return-void
.end method

.method public final b0(Ljava/util/ArrayList;)V
    .locals 1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, p1}, Lc/n1;->D0(Ljava/util/List;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0, p1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_2

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0, p1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    :cond_2
    invoke-static {p1}, Lru/drivedeck/launcher/LauncherAccessibilityService;->i(Ljava/util/ArrayList;)V

    return-void
.end method

.method public final c()V
    .locals 4

    invoke-static {p0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->launch(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :he_voice_c

    return-void

    :he_voice_c

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->p0()Z

    move-result v0

    if-nez v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u041f\u043e\u043c\u043e\u0449\u043d\u0438\u043a \u043f\u043e \u043a\u043d\u043e\u043f\u043a\u0435"

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\u0412\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    invoke-static {p0, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    return-void

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    iget-boolean v1, v0, Lc/g9;->m:Z

    if-nez v1, :cond_6

    iget-boolean v1, v0, Lc/g9;->p:Z

    if-nez v1, :cond_6

    iget-object v1, v0, Lc/g9;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->p0()Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_0

    :cond_2
    iget-boolean v2, v0, Lc/g9;->n:Z

    if-eqz v2, :cond_3

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/g9;->q(Z)V

    goto :goto_0

    :cond_3
    iget-object v2, v0, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v2}, Lc/g9;->b(Landroid/app/Activity;)Z

    move-result v3

    if-nez v3, :cond_4

    const-string v1, "missing"

    invoke-virtual {v0, v1}, Lc/g9;->o(Ljava/lang/String;)V

    goto :goto_0

    :cond_4
    invoke-virtual {v1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lc/g9;->g(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_5

    const-string v1, "language_missing"

    invoke-virtual {v0, v1}, Lc/g9;->o(Ljava/lang/String;)V

    goto :goto_0

    :cond_5
    const/4 v1, 0x1

    iput-boolean v1, v0, Lc/g9;->n:Z

    invoke-virtual {v0}, Lc/g9;->i()V

    iget-object v1, v0, Lc/g9;->u:Landroid/os/Handler;

    iget-object v0, v0, Lc/g9;->v:Lc/e9;

    const-wide/32 v2, 0x9c40

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_6
    :goto_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->V()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    iget-boolean v1, v0, Lc/g9;->n:Z

    if-nez v1, :cond_7

    invoke-virtual {v0}, Lc/g9;->p()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    :cond_7
    return-void
.end method

.method public final c0(Z)V
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    const-string v1, "auto_bluetooth_audio"

    invoke-static {v0, v1, p1}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-eqz p1, :cond_1

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-nez p1, :cond_0

    new-instance p1, Lc/P;

    new-instance v0, Lc/J1;

    const/16 v1, 0x1a

    invoke-direct {v0, p0, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-direct {p1, p0, v0}, Lc/P;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/Runnable;)V

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    :cond_0
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    invoke-virtual {p1}, Lc/P;->c()V

    goto :goto_0

    :cond_1
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->N:Lc/J1;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Lc/P;->d()V

    const/4 p1, 0x0

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    :cond_2
    invoke-virtual {v0}, Lc/J1;->run()V

    :goto_0
    return-void
.end method

.method public final d(Landroid/view/View;FJLc/E4;)V
    .locals 6

    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0x104

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    new-instance p2, Landroid/view/animation/PathInterpolator;

    const v0, 0x3ecccccd    # 0.4f

    const/4 v1, 0x0

    const v2, 0x3e4ccccd    # 0.2f

    const/high16 v3, 0x3f800000    # 1.0f

    invoke-direct {p2, v0, v1, v2, v3}, Landroid/view/animation/PathInterpolator;-><init>(FFFF)V

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    new-instance p2, Lc/k1;

    const/4 v5, 0x5

    move-object v0, p2

    move-object v1, p0

    move-wide v2, p3

    move-object v4, p5

    invoke-direct/range {v0 .. v5}, Lc/k1;-><init>(Ljava/lang/Object;JLjava/lang/Object;I)V

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public final d0(Landroid/view/View;ZJLjava/lang/Runnable;)V
    .locals 7

    iget-object v6, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-ne p1, v6, :cond_2

    iput-boolean p2, v6, Lc/Q3;->T:Z

    if-eqz p2, :cond_0

    invoke-virtual {v6}, Landroid/view/View;->isShown()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-virtual {v6}, Lc/Q3;->A()Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    move v1, v0

    :goto_0
    iget-object p1, v6, Lc/Q3;->w:Lc/e0;

    invoke-virtual {p1, v1}, Lc/e0;->q(Z)V

    if-nez p2, :cond_1

    invoke-virtual {v6}, Lc/Q3;->w()V

    iget-object p1, v6, Lc/Q3;->t:Lc/P3;

    invoke-virtual {p1}, Lc/P3;->k()V

    invoke-virtual {v6}, Lc/Q3;->B()V

    invoke-virtual {p1, v0}, Lc/P3;->f0(Z)V

    :cond_1
    const/4 p1, 0x2

    filled-new-array {p1}, [I

    move-result-object v2

    new-instance p1, Lc/u3;

    const/4 v5, 0x0

    move-object v0, p1

    move-object v1, v6

    move v3, p2

    move-object v4, p5

    invoke-direct/range {v0 .. v5}, Lc/u3;-><init>(Ljava/lang/Object;Ljava/io/Serializable;ZLjava/lang/Object;I)V

    iget-object p5, v6, Lc/Q3;->y:Lc/t2;

    invoke-virtual {p5, p2, p3, p4, p1}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    iget-object p5, v6, Lc/Q3;->z:Lc/t2;

    invoke-virtual {p5, p2, p3, p4, p1}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    goto :goto_2

    :cond_2
    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne p1, v2, :cond_4

    iput-boolean p2, v2, Lc/m2;->J:Z

    iget-object p1, v2, Lc/m2;->t:[Lc/t2;

    if-nez p2, :cond_3

    aget-object v2, p1, v0

    invoke-virtual {v2}, Lc/t2;->i()V

    aget-object v2, p1, v1

    invoke-virtual {v2}, Lc/t2;->i()V

    :cond_3
    array-length v2, p1

    filled-new-array {v2}, [I

    move-result-object v2

    new-array v3, v1, [Z

    aput-boolean v0, v3, v0

    new-instance v4, Lc/Z;

    const/4 v5, 0x5

    invoke-direct {v4, v3, v2, p5, v5}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    array-length p5, p1

    :goto_1
    if-ge v0, p5, :cond_5

    aget-object v2, p1, v0

    invoke-virtual {v2, p2, p3, p4, v4}, Lc/t2;->f0(ZJLjava/lang/Runnable;)V

    add-int/2addr v0, v1

    goto :goto_1

    :cond_4
    if-eqz p5, :cond_5

    invoke-interface {p5}, Ljava/lang/Runnable;->run()V

    :cond_5
    :goto_2
    return-void
.end method

.method public final dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-nez v0, :cond_0

    new-instance v0, Lc/t8;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-direct {v0, v1}, Lc/t8;-><init>(Landroid/view/View;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    invoke-virtual {v0, p1}, Lc/t8;->i(Landroid/view/MotionEvent;)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    invoke-static {p0, p1}, Lru/drivedeck/launcher/HebrewVoiceBridge;->onKey(Landroid/content/Context;Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :he_voice_k

    return v0

    :he_voice_k

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lc/Z7;->e(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Lc/n1;->p0()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v2, 0xdb

    if-eq v0, v2, :cond_1

    const/16 v2, 0xe7

    if-ne v0, v2, :cond_3

    :cond_1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_2

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->c()V

    :cond_2
    return v1

    :cond_3
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-nez v0, :cond_4

    new-instance v0, Lc/t8;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    invoke-direct {v0, v2}, Lc/t8;-><init>(Landroid/view/View;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    :cond_4
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    invoke-virtual {v0, p1}, Lc/t8;->g(Landroid/view/KeyEvent;)Z

    move-result v0

    if-nez v0, :cond_6

    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    if-eqz p1, :cond_5

    goto :goto_0

    :cond_5
    const/4 v1, 0x0

    :cond_6
    :goto_0
    return v1
.end method

.method public final dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/t8;->d()V

    :cond_0
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public final e()V
    .locals 3

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->n0()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    sget v1, Lc/Q3;->c0:I

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Lc/Q3;->L(Landroid/view/View;)V

    :cond_1
    :goto_0
    invoke-static {p0}, Lc/R1;->b(Landroid/content/Context;)V

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    iget v2, v0, Lc/r4;->a:I

    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    iget v0, v0, Lc/r4;->a:I

    invoke-virtual {v1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Lc/b4;->d(Landroid/view/View;)V

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Lc/Q3;->N()V

    goto :goto_1

    :cond_2
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Lc/m2;->E()V

    goto :goto_1

    :cond_3
    new-instance v0, Lc/s4;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-direct {v0, p0, v1, v2, p0}, Lc/s4;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lru/drivedeck/launcher/MainActivity;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    :cond_4
    :goto_1
    return-void
.end method

.method public final f(Ljava/lang/String;)Z
    .locals 1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {p1}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {p0, p1}, Lc/z;->l(Landroid/content/Context;Ljava/lang/String;)Lc/y;

    move-result-object p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p1, 0x1

    :goto_1
    return p1
.end method

.method public final f0(Z)V
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    invoke-static {p0}, Lc/g9;->h(Landroid/content/Context;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    move p1, v0

    :goto_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "voice_calls_enabled"

    invoke-static {v1, v2, p1}, Lc/t;->d(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V

    if-eqz p1, :cond_2

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_2

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object p1, p1, Lc/n1;->b:Ljava/lang/Object;

    check-cast p1, Landroid/content/SharedPreferences;

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const-string v1, "android.permission.READ_CONTACTS"

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1f

    if-lt v1, v2, :cond_1

    const-string v1, "android.permission.BLUETOOTH_CONNECT"

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    new-array v0, v0, [Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    const/16 v0, 0x1f91

    invoke-virtual {p0, p1, v0}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    goto :goto_1

    :cond_2
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->l()V

    :goto_1
    return-void
.end method

.method public final g(I)V
    .locals 11

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v0}, Lc/z;->n()Ljava/util/ArrayList;

    move-result-object v2

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iget-wide v6, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    new-array v0, v0, [Landroid/app/Dialog;

    new-instance v9, Lc/z4;

    invoke-direct {v9, p0, v6, v7, p1}, Lc/z4;-><init>(Lru/drivedeck/launcher/MainActivity;JI)V

    new-instance v10, Lc/k1;

    const/4 v8, 0x4

    move-object v3, v10

    move-object v4, p0

    move-object v5, v0

    invoke-direct/range {v3 .. v8}, Lc/k1;-><init>(Ljava/lang/Object;Ljava/lang/Object;JI)V

    if-gez p1, :cond_0

    const-string p1, "\u0412\u0441\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    :goto_0
    move-object v3, p1

    goto :goto_1

    :cond_0
    if-nez p1, :cond_1

    const-string p1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0441\u043b\u0435\u0432\u0430"

    goto :goto_0

    :cond_1
    const-string p1, "\u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0441\u043f\u0440\u0430\u0432\u0430"

    goto :goto_0

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    move-object v1, p0

    move-object v4, v9

    move-object v5, v10

    invoke-static/range {v1 .. v7}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    move-result-object p1

    const/4 v1, 0x0

    aput-object p1, v0, v1

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    return-void
.end method

.method public final g0()V
    .locals 16

    move-object/from16 v7, p0

    iget-boolean v0, v7, Lru/drivedeck/launcher/MainActivity;->Q:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-boolean v0, v7, Lru/drivedeck/launcher/MainActivity;->p0:Z

    if-nez v0, :cond_17

    iget-object v0, v7, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-nez v0, :cond_17

    iget-object v0, v7, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    if-nez v0, :cond_1

    goto/16 :goto_b

    :cond_1
    iget-object v0, v7, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    instance-of v1, v0, Lc/F;

    if-eqz v1, :cond_2

    check-cast v0, Lc/F;

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    if-eqz v0, :cond_3

    invoke-virtual {v0, v1}, Lc/F;->r(Z)V

    :cond_3
    iput-boolean v1, v7, Lru/drivedeck/launcher/MainActivity;->Q:Z

    new-instance v3, Ljava/util/ArrayList;

    iget-object v4, v7, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    new-instance v5, Lc/n1;

    iget-object v6, v4, Lc/z;->a:Landroid/content/Context;

    invoke-direct {v5, v6}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5}, Lc/n1;->b0()Ljava/util/HashSet;

    move-result-object v5

    new-instance v8, Ljava/util/ArrayList;

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v4}, Lc/z;->c()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_4
    :goto_1
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_5

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lc/a;

    iget-object v11, v10, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v5, v11}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_4

    invoke-virtual {v8, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_5
    new-instance v5, Lc/n1;

    invoke-direct {v5, v6}, Lc/n1;-><init>(Landroid/content/Context;)V

    const-string v9, "all_apps_activities"

    iget-object v10, v5, Lc/n1;->b:Ljava/lang/Object;

    check-cast v10, Landroid/content/SharedPreferences;

    invoke-interface {v10, v9, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    if-nez v9, :cond_6

    goto/16 :goto_9

    :cond_6
    invoke-virtual {v5}, Lc/n1;->b0()Ljava/util/HashSet;

    move-result-object v5

    new-instance v9, Ljava/util/HashSet;

    invoke-direct {v9}, Ljava/util/HashSet;-><init>()V

    :try_start_0
    invoke-virtual {v8}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_7
    :goto_2
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1

    iget-object v13, v4, Lc/z;->b:Landroid/content/pm/PackageManager;

    if-eqz v12, :cond_8

    :try_start_1
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lc/a;

    iget-object v12, v12, Lc/a;->a:Ljava/lang/String;

    invoke-virtual {v13, v12}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v12

    if-eqz v12, :cond_7

    invoke-virtual {v12}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v13

    if-eqz v13, :cond_7

    invoke-virtual {v12}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v12

    invoke-virtual {v9, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_2

    :cond_8
    new-instance v11, Landroid/content/Intent;

    const-string v12, "android.intent.action.MAIN"

    invoke-direct {v11, v12}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v12, "android.intent.category.LAUNCHER"

    invoke-virtual {v11, v12}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v11

    const/high16 v12, 0x20000

    invoke-virtual {v13, v11, v12}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v11

    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :cond_9
    :goto_3
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_13

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/content/pm/ResolveInfo;

    iget-object v14, v12, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-eqz v14, :cond_9

    iget-object v15, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-static {v15, v1}, Lc/z;->e(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_c

    iget-object v1, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v5, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c

    iget-object v1, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-static {v14, v1}, Lc/z;->g(Landroid/content/pm/ActivityInfo;Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_b

    iget-object v1, v14, Landroid/content/pm/ActivityInfo;->permission:Ljava/lang/String;

    if-eqz v1, :cond_a

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_a

    iget-object v1, v14, Landroid/content/pm/ActivityInfo;->permission:Ljava/lang/String;

    invoke-virtual {v6, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_b

    :cond_a
    const/4 v1, 0x1

    goto :goto_4

    :cond_b
    const/4 v1, 0x0

    :goto_4
    if-nez v1, :cond_d

    :catch_0
    :cond_c
    :goto_5
    const/4 v1, 0x1

    goto :goto_3

    :cond_d
    new-instance v1, Landroid/content/ComponentName;

    iget-object v15, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v10, v14, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {v1, v15, v10}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v9, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result v10
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    if-nez v10, :cond_e

    goto :goto_5

    :cond_e
    :try_start_2
    invoke-virtual {v12, v13}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v10

    if-eqz v10, :cond_10

    invoke-interface {v10}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-eqz v15, :cond_f

    goto :goto_6

    :cond_f
    invoke-interface {v10}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v10

    goto :goto_7

    :cond_10
    :goto_6
    invoke-virtual {v1}, Landroid/content/ComponentName;->getShortClassName()Ljava/lang/String;

    move-result-object v10

    :goto_7
    iget-object v15, v14, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    invoke-virtual {v14}, Landroid/content/pm/ComponentInfo;->getIconResource()I

    move-result v2

    invoke-virtual {v12, v13}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v4, v15, v2, v12}, Lc/z;->i(Landroid/content/pm/ApplicationInfo;ILandroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    iget-object v12, v4, Lc/z;->j:Lc/Y3;

    if-nez v12, :cond_11

    const/4 v12, 0x0

    goto :goto_8

    :cond_11
    iget-object v15, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v12, v15, v1}, Lc/Y3;->a(Ljava/lang/String;Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    :goto_8
    new-instance v15, Lc/a;

    iget-object v14, v14, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    if-nez v12, :cond_12

    invoke-static {v6, v2}, Lc/s;->f(Landroid/content/Context;Landroid/graphics/drawable/Drawable;)Lc/q;

    move-result-object v12

    :cond_12
    invoke-direct {v15, v14, v10, v12, v1}, Lc/a;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;Landroid/content/ComponentName;)V

    invoke-virtual {v8, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    goto :goto_5

    :catch_1
    :cond_13
    new-instance v1, Lc/v;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Lc/v;-><init>(I)V

    invoke-static {v1}, Ljava/util/Comparator;->comparing(Ljava/util/function/Function;)Ljava/util/Comparator;

    move-result-object v1

    invoke-virtual {v8, v1}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    :goto_9
    invoke-direct {v3, v8}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v1, Lc/a;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v4, 0x7f030020

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v5

    invoke-virtual {v2, v4, v5}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const-string v4, "__launcher_settings__"

    const-string v5, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043b\u0430\u0443\u043d\u0447\u0435\u0440\u0430"

    const/4 v6, 0x0

    invoke-direct {v1, v4, v5, v2, v6}, Lc/a;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/graphics/drawable/Drawable;Landroid/content/ComponentName;)V

    const/4 v2, 0x0

    invoke-virtual {v3, v2, v1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-static/range {p0 .. p0}, Lc/G8;->Q(Landroid/content/Context;)Lc/a;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v3, v2, v1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    invoke-static/range {p0 .. p0}, Lc/G8;->P(Landroid/content/Context;)Lc/a;

    move-result-object v1

    const/4 v4, 0x2

    invoke-virtual {v3, v4, v1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    iget-wide v8, v7, Lru/drivedeck/launcher/MainActivity;->R:J

    const-wide/16 v10, 0x1

    add-long/2addr v8, v10

    iput-wide v8, v7, Lru/drivedeck/launcher/MainActivity;->R:J

    new-array v10, v2, [Landroid/app/Dialog;

    const-string v1, "\u0412\u0441\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f"

    invoke-static {v7, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v5, Lc/B4;

    const/4 v1, 0x0

    invoke-direct {v5, v7, v8, v9, v1}, Lc/B4;-><init>(Ljava/lang/Object;JI)V

    new-instance v8, Lc/Z;

    invoke-direct {v8, v7, v0, v10}, Lc/Z;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/F;[Landroid/app/Dialog;)V

    if-nez v0, :cond_14

    goto :goto_a

    :cond_14
    new-array v1, v4, [I

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    new-instance v6, Landroid/graphics/Rect;

    const/4 v9, 0x0

    aget v11, v1, v9

    const/4 v12, 0x1

    aget v13, v1, v12

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v14

    add-int/2addr v14, v11

    aget v1, v1, v12

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v12

    add-int/2addr v12, v1

    invoke-direct {v6, v11, v13, v14, v12}, Landroid/graphics/Rect;-><init>(IIII)V

    new-array v1, v4, [I

    iget-object v4, v0, Lc/F;->l:Landroid/view/View;

    invoke-virtual {v4, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    aget v4, v1, v9

    iget-object v11, v0, Lc/F;->l:Landroid/view/View;

    invoke-virtual {v11}, Landroid/view/View;->getTranslationX()F

    move-result v11

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    sub-int/2addr v4, v11

    aput v4, v1, v9

    const/4 v4, 0x1

    aget v9, v1, v4

    iget-object v11, v0, Lc/F;->l:Landroid/view/View;

    invoke-virtual {v11}, Landroid/view/View;->getTranslationY()F

    move-result v11

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v11

    sub-int/2addr v9, v11

    aput v9, v1, v4

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    const/high16 v11, 0x41400000    # 12.0f

    invoke-static {v9, v11}, Lc/G8;->y0(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v0}, Lc/F;->q()Z

    move-result v11

    if-eqz v11, :cond_15

    aget v0, v1, v4

    sub-int/2addr v0, v9

    iput v0, v6, Landroid/graphics/Rect;->bottom:I

    goto :goto_a

    :cond_15
    invoke-virtual {v0}, Lc/F;->g()Lc/Q1;

    move-result-object v4

    sget-object v11, Lc/Q1;->a:Lc/Q1;

    if-ne v4, v11, :cond_16

    const/4 v4, 0x0

    aget v1, v1, v4

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    add-int/2addr v0, v1

    add-int/2addr v0, v9

    iput v0, v6, Landroid/graphics/Rect;->left:I

    goto :goto_a

    :cond_16
    const/4 v4, 0x0

    aget v0, v1, v4

    sub-int/2addr v0, v9

    iput v0, v6, Landroid/graphics/Rect;->right:I

    :goto_a
    const/4 v9, 0x1

    move-object/from16 v0, p0

    move-object v1, v3

    move-object v3, v5

    move-object v4, v8

    move v5, v9

    invoke-static/range {v0 .. v6}, Lc/G8;->H0(Landroid/content/Context;Ljava/util/List;Ljava/lang/String;Lc/n;Ljava/lang/Runnable;ZLandroid/graphics/Rect;)Lc/j;

    move-result-object v0

    const/4 v1, 0x0

    aput-object v0, v10, v1

    iput-object v0, v7, Lru/drivedeck/launcher/MainActivity;->S:Lc/j;

    return-void

    :cond_17
    :goto_b
    iget-wide v0, v7, Lru/drivedeck/launcher/MainActivity;->R:J

    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    new-instance v3, Lc/x4;

    const/4 v4, 0x2

    invoke-direct {v3, v7, v0, v1, v4}, Lc/x4;-><init>(Lru/drivedeck/launcher/MainActivity;JI)V

    const-wide/16 v0, 0x32

    invoke-virtual {v2, v3, v0, v1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final h()V
    .locals 9

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lc/n1;->E()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->i0()Z

    move-result v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->m0:Ljava/lang/String;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v5

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->p()I

    move-result v6

    const/4 v1, 0x1

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->Q:Z

    iget v2, p0, Lru/drivedeck/launcher/MainActivity;->l0:I

    add-int/2addr v2, v1

    iput v2, p0, Lru/drivedeck/launcher/MainActivity;->l0:I

    new-array v1, v1, [Lc/k3;

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    new-instance v8, Lc/u0;

    invoke-direct {v8, p0, v1, v2, v0}, Lc/u0;-><init>(Lru/drivedeck/launcher/MainActivity;[Lc/k3;ILjava/lang/String;)V

    new-instance v0, Lc/k3;

    move-object v2, v0

    move-object v3, p0

    move-object v7, v8

    invoke-direct/range {v2 .. v7}, Lc/k3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Ljava/util/ArrayList;ILc/u0;)V

    new-instance v2, Lc/g;

    const/4 v3, 0x1

    invoke-direct {v2, v8, v3}, Lc/g;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v2}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    if-eqz v2, :cond_1

    const v3, 0x106000d

    invoke-virtual {v2, v3}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    const/4 v3, 0x2

    invoke-virtual {v2, v3}, Landroid/view/Window;->clearFlags(I)V

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/Window;->setDimAmount(F)V

    const/4 v3, -0x1

    invoke-virtual {v2, v3, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v3, 0x10

    invoke-virtual {v2, v3}, Landroid/view/Window;->setSoftInputMode(I)V

    invoke-static {v2}, Lc/b4;->b(Landroid/view/Window;)V

    iget-object v2, v0, Lc/k3;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/view/View;->requestApplyInsets()V

    :cond_1
    const/4 v2, 0x0

    aput-object v0, v1, v2

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    return-void
.end method

.method public final h0()V
    .locals 9

    const-string v0, ""

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-virtual {p0, v0}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    invoke-virtual {p0, v2}, Landroid/app/Activity;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v4, "gps_permission_requested"

    invoke-interface {v1, v4, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_0

    invoke-virtual {p0, v2}, Landroid/app/Activity;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1, v4, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v1, "android.permission.ACCESS_COARSE_LOCATION"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x2bd

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    :cond_0
    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    iput-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lc/P;->c()V

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-nez v0, :cond_2

    new-instance v0, Lc/Q3;

    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    iget-object v6, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v7, Lc/y;

    invoke-direct {v7, p0, v2}, Lc/y;-><init>(Ljava/lang/Object;Z)V

    iget-object v8, p0, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    move-object v3, v0

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lc/Q3;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/y;Lc/e0;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    :cond_2
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->t(Landroid/view/View;)V

    const-string v0, "home"

    new-array v1, v2, [Ljava/lang/String;

    invoke-virtual {p0, v0, v1}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    return-void
.end method

.method public final i(Ljava/lang/Boolean;)V
    .locals 4

    if-nez p1, :cond_0

    const/16 p1, 0x1ce9

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1

    const/16 p1, 0x1cec

    goto :goto_0

    :cond_1
    const/16 p1, 0x1ced

    :goto_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.GET_CONTENT"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "image/*"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.intent.action.PICK"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    sget-object v3, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :catch_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x1

    if-eqz v1, :cond_4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Intent;

    :try_start_0
    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {p0, v1, p1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    const/4 v2, 0x0

    if-eqz v1, :cond_2

    invoke-virtual {v1, v2}, Lc/Q3;->P(Z)V

    :cond_2
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v1, :cond_3

    invoke-virtual {v1, v2}, Lc/m2;->G(Z)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    return-void

    :cond_4
    const-string p1, "\u041d\u0430 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0435 \u043d\u0435\u0442 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f \u0434\u043b\u044f \u0432\u044b\u0431\u043e\u0440\u0430 \u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0439"

    invoke-static {p0, p1, p0, v2}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void
.end method

.method public final i0()V
    .locals 3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v1, "windows"

    invoke-virtual {v0, v1}, Lc/n1;->C0(Ljava/lang/String;)V

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v0, :cond_2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lc/m2;->I(J)V

    goto :goto_0

    :cond_2
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->u()V

    :goto_0
    return-void
.end method

.method public final j()V
    .locals 4

    const/4 v0, 0x0

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f0:Lc/Q;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g0:Ljava/util/List;

    const-string v0, ""

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->h0:Ljava/lang/String;

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lru/drivedeck/launcher/MainActivity;->i0:J

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->j0:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->j0:J

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v0, :cond_0

    iget-boolean v1, v0, Lc/l9;->n:Z

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/l9;->a()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-virtual {v0}, Lc/l9;->c()V

    :cond_0
    return-void
.end method

.method public final j0(Landroid/view/View;)V
    .locals 4

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->w:Landroid/view/View;

    if-eq v0, p1, :cond_0

    invoke-static {v0, v2}, Lru/drivedeck/launcher/MainActivity;->e0(Landroid/view/View;Z)V

    iput-object p1, p0, Lru/drivedeck/launcher/MainActivity;->w:Landroid/view/View;

    invoke-static {p1, v1}, Lru/drivedeck/launcher/MainActivity;->e0(Landroid/view/View;Z)V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    invoke-virtual {v0, p1}, Lc/n3;->d(Landroid/view/View;)V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    return-void

    :cond_1
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->x:Z

    if-nez v0, :cond_3

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->p0:Z

    if-nez v0, :cond_3

    invoke-virtual {p0, v2}, Landroid/app/Activity;->getPreferences(I)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v3, "first_run_tutorial_complete"

    invoke-interface {v0, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->y:Z

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->y:Z

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->x:Z

    new-instance v1, Lc/H1;

    const/4 v2, 0x2

    invoke-direct {v1, p0, p1, v0, v2}, Lc/H1;-><init>(Ljava/lang/Object;Ljava/lang/Object;ZI)V

    invoke-virtual {p1, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_3
    :goto_0
    return-void
.end method

.method public final k()Z
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    instance-of v1, v0, Lc/F;

    if-eqz v1, :cond_0

    check-cast v0, Lc/F;

    invoke-virtual {v0}, Lc/F;->f()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final k0()V
    .locals 7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->B()Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_0

    const-string v2, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c DriveDeck \u0434\u043e\u043c\u0430\u0448\u043d\u0438\u043c \u044d\u043a\u0440\u0430\u043d\u043e\u043c"

    invoke-static {p0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v2

    const/4 v4, 0x1

    if-nez v2, :cond_1

    const-string v2, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044c \u043f\u043e\u043a\u0430\u0437 \u0434\u043e\u043a\u0430 \u043f\u043e\u0432\u0435\u0440\u0445 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0439"

    invoke-static {p0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->d()Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0441\u043b\u0443\u0436\u0431\u0443 \u00abDriveDeck: \u0434\u0432\u0430 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f\u00bb"

    invoke-static {p0, v2}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_3

    const-string v0, "\u0412\u0441\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043d\u0438\u044f \u0443\u0436\u0435 \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u044b"

    invoke-static {p0, v0, p0, v3}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    return-void

    :cond_3
    new-instance v2, Landroid/app/AlertDialog$Builder;

    invoke-direct {v2, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v5, "\u0417\u0430\u0432\u0435\u0440\u0448\u0438\u0442\u0435 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0443"

    invoke-static {p0, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const-string v5, "\u041f\u043e\u0437\u0436\u0435"

    invoke-static {p0, v5}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    invoke-virtual {v2, v5, v6}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-ne v5, v4, :cond_4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-virtual {v2, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v3, "\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    invoke-static {p0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Lc/C4;

    invoke-direct {v4, p0, v1}, Lc/C4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v0, v3, v4}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    goto :goto_0

    :cond_4
    new-array v3, v3, [Ljava/lang/CharSequence;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/CharSequence;

    new-instance v3, Lc/D4;

    const/4 v4, 0x0

    invoke-direct {v3, p0, v1, v4}, Lc/D4;-><init>(Landroid/view/KeyEvent$Callback;Ljava/util/ArrayList;I)V

    invoke-virtual {v2, v0, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    :goto_0
    invoke-virtual {v2}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method public final l()V
    .locals 1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/g9;->j()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    invoke-virtual {v0}, Lc/g9;->c()V

    :cond_0
    return-void
.end method

.method public final l0(Ljava/lang/String;)V
    .locals 8

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-nez v0, :cond_1

    new-instance v0, Lc/l9;

    invoke-direct {v0, p0}, Lc/l9;-><init>(Landroid/app/Activity;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_1
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    invoke-static {p0, p1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 p1, 0x0

    new-array v3, p1, [Ljava/lang/String;

    new-instance v4, Lc/L4;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    new-instance v5, Lc/a1;

    const/4 p1, 0x4

    invoke-direct {v5, p1}, Lc/a1;-><init>(I)V

    const-wide/16 v6, 0xbb8

    invoke-virtual/range {v1 .. v7}, Lc/l9;->g(Ljava/lang/String;[Ljava/lang/String;Ljava/util/function/IntConsumer;Ljava/lang/Runnable;J)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final m(Landroid/content/Intent;)Z
    .locals 3

    const/4 v0, 0x0

    if-eqz p1, :cond_2

    const-string v1, "ru.drivedeck.launcher.extra.HOME_MODE"

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    const-string v1, "ru.drivedeck.launcher.extra.WIDGET_EDITOR"

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v0, Lc/J1;

    const/16 v1, 0x11

    invoke-direct {v0, p0, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_1
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->s()V

    const/4 p1, 0x1

    return p1

    :cond_2
    :goto_0
    return v0
.end method

.method public final m0()V
    .locals 2

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_1
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v1, "cards"

    invoke-virtual {v0, v1}, Lc/n1;->C0(Ljava/lang/String;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    const/4 v0, 0x1

    goto :goto_0

    :cond_2
    move v0, v1

    :goto_0
    if-nez v0, :cond_3

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->W()V

    :cond_3
    if-eqz v0, :cond_4

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    :cond_4
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Lc/Q3;->O()V

    :cond_5
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->h0()V

    return-void
.end method

.method public final n()V
    .locals 6

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->c0:Z

    if-eqz v0, :cond_3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v0, v0, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->c()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_3

    const/4 v0, 0x0

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->c0:Z

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v2, v1, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v2}, Lc/e8;->c()Z

    move-result v2

    if-eqz v2, :cond_3

    iget-boolean v2, v1, Lc/Z7;->q:Z

    if-eqz v2, :cond_0

    goto :goto_1

    :cond_0
    iget-object v2, v1, Lc/Z7;->b:Landroid/content/Context;

    const-string v3, "android.permission.READ_CONTACTS"

    invoke-virtual {v2, v3}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_1

    const-string v0, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0430\u043c"

    iput-object v0, v1, Lc/Z7;->K:Ljava/lang/String;

    iget-object v0, v1, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    goto :goto_1

    :cond_1
    iget v2, v1, Lc/Z7;->B:I

    const/4 v3, 0x1

    add-int/2addr v2, v3

    iput v2, v1, Lc/Z7;->B:I

    const-string v4, ""

    iput-object v4, v1, Lc/Z7;->K:Ljava/lang/String;

    iput-boolean v3, v1, Lc/Z7;->q:Z

    iput-boolean v0, v1, Lc/Z7;->n:Z

    iget-object v3, v1, Lc/Z7;->x:Ljava/util/LinkedHashMap;

    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->clear()V

    iput-boolean v0, v1, Lc/Z7;->y:Z

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iput-wide v3, v1, Lc/Z7;->z:J

    const-wide/16 v3, 0x0

    iput-wide v3, v1, Lc/Z7;->A:J

    iget-object v0, v1, Lc/Z7;->g:Lc/J1;

    invoke-virtual {v0}, Lc/J1;->run()V

    iget-object v0, v1, Lc/Z7;->a:Lc/e8;

    iget-object v3, v0, Lc/e8;->a:Ljava/lang/String;

    iget-object v0, v0, Lc/e8;->d:Ljava/lang/String;

    const-string v4, "TEYES / FYT"

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, v1, Lc/Z7;->k:Landroid/os/IBinder;

    if-eqz v0, :cond_2

    iget-object v0, v1, Lc/Z7;->k:Landroid/os/IBinder;

    iget-object v4, v1, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v5, Lc/N;

    invoke-direct {v5, v1, v0, v2, v3}, Lc/N;-><init>(Lc/Z7;Landroid/os/IBinder;ILjava/lang/String;)V

    invoke-interface {v4, v5}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    goto :goto_0

    :cond_2
    iget-object v0, v1, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lc/R7;

    const/4 v5, 0x3

    invoke-direct {v4, v1, v3, v2, v5}, Lc/R7;-><init>(Lc/Z7;Ljava/lang/String;II)V

    invoke-interface {v0, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_0
    iget-object v0, v1, Lc/Z7;->c:Landroid/os/Handler;

    new-instance v4, Lc/R7;

    const/4 v5, 0x4

    invoke-direct {v4, v1, v3, v2, v5}, Lc/R7;-><init>(Lc/Z7;Ljava/lang/String;II)V

    const-wide/32 v1, 0xafc8

    invoke-virtual {v0, v4, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_3
    :goto_1
    return-void
.end method

.method public final n0()V
    .locals 3

    const-string v0, "uimode"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/UiModeManager;

    if-eqz v0, :cond_2

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    if-nez v1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {v1}, Lc/n1;->j0()Z

    move-result v1

    if-eqz v1, :cond_1

    const/4 v1, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x2

    :goto_0
    :try_start_0
    invoke-virtual {v0}, Landroid/app/UiModeManager;->getNightMode()I

    move-result v2

    if-eq v2, v1, :cond_2

    invoke-virtual {v0, v1}, Landroid/app/UiModeManager;->setNightMode(I)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    const-string v1, "DriveDeck"

    const-string v2, "Firmware denied system night mode"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2
    :goto_1
    return-void
.end method

.method public final o()V
    .locals 4

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Lc/m2;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v3, Lc/M4;

    invoke-direct {v3, p0}, Lc/M4;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    invoke-direct {v0, p0, v1, v2, v3}, Lc/m2;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lc/M4;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    return-void
.end method

.method public final o0()Z
    .locals 1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->r0()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v0, :cond_0

    iget-boolean v0, v0, Lc/g9;->n:Z

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 15

    move-object v6, p0

    move/from16 v1, p1

    move/from16 v0, p2

    move-object/from16 v2, p3

    invoke-super/range {p0 .. p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    iget-object v3, v6, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v7, -0x1

    if-eqz v3, :cond_8

    const/16 v8, 0x1f90

    if-ne v1, v8, :cond_8

    iput-boolean v5, v3, Lc/g9;->l:Z

    iget-boolean v1, v3, Lc/g9;->m:Z

    if-nez v1, :cond_6

    invoke-virtual {v3}, Lc/g9;->a()Z

    move-result v1

    if-nez v1, :cond_0

    goto/16 :goto_0

    :cond_0
    const-string v1, "ru.drivedeck.voice"

    if-eq v0, v7, :cond_2

    iget-object v0, v3, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const-string v2, "android.permission.RECORD_AUDIO"

    invoke-virtual {v0, v2, v1}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {v3}, Lc/g9;->e()V

    goto :goto_1

    :cond_1
    iget-object v0, v3, Lc/g9;->b:Lc/n1;

    iget-object v0, v0, Lc/n1;->b:Ljava/lang/Object;

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v1, "voice_enabled"

    invoke-interface {v0, v1, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {v3, v5}, Lc/g9;->q(Z)V

    goto :goto_1

    :cond_2
    iget-boolean v0, v3, Lc/g9;->m:Z

    if-nez v0, :cond_7

    iget-boolean v0, v3, Lc/g9;->k:Z

    if-eqz v0, :cond_3

    goto :goto_1

    :cond_3
    iget-object v0, v3, Lc/g9;->a:Lru/drivedeck/launcher/MainActivity;

    invoke-static {v0}, Lc/g9;->f(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_4

    const-string v0, "missing"

    invoke-virtual {v3, v0}, Lc/g9;->r(Ljava/lang/String;)V

    goto :goto_1

    :cond_4
    :try_start_0
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v1, v5}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    iput v2, v3, Lc/g9;->r:I

    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    new-instance v5, Landroid/content/ComponentName;

    const-string v7, "ru.drivedeck.voice.VoiceService"

    invoke-direct {v5, v1, v7}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2, v5}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v0, v1, v3, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    iput-boolean v0, v3, Lc/g9;->k:Z

    if-eqz v0, :cond_5

    const-string v0, "starting"

    invoke-virtual {v3, v0}, Lc/g9;->o(Ljava/lang/String;)V

    goto :goto_1

    :cond_5
    invoke-virtual {v3}, Lc/g9;->e()V
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    invoke-virtual {v3}, Lc/g9;->e()V

    goto :goto_1

    :cond_6
    :goto_0
    invoke-virtual {v3}, Lc/g9;->j()V

    :cond_7
    :goto_1
    return-void

    :cond_8
    const/16 v3, 0x1d60

    if-eq v1, v3, :cond_2a

    sget-object v3, Lc/q4;->a:[B

    const/16 v3, 0x1d5b

    if-ne v1, v3, :cond_9

    if-ne v0, v7, :cond_29

    if-eqz v2, :cond_29

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_29

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    invoke-static {p0, v0}, Lc/q4;->l(Lru/drivedeck/launcher/MainActivity;Landroid/net/Uri;)V

    goto/16 :goto_d

    :cond_9
    sget-object v3, Lc/q4;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x0

    const/16 v9, 0x1d5a

    const-string v10, "\u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u0443\u0436\u0435 \u0432\u044b\u043f\u043e\u043b\u043d\u044f\u0435\u0442\u0441\u044f"

    if-ne v1, v9, :cond_c

    sget-object v1, Lc/q4;->a:[B

    sput-object v8, Lc/q4;->a:[B

    if-ne v0, v7, :cond_29

    if-eqz v2, :cond_29

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_a

    goto/16 :goto_d

    :cond_a
    invoke-virtual {v3, v5, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_b

    invoke-static {p0, v10}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto/16 :goto_d

    :cond_b
    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    new-instance v2, Ljava/lang/Thread;

    new-instance v3, Lc/Z;

    const/16 v4, 0xb

    invoke-direct {v3, p0, v0, v1, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string v0, "DriveDeckLayoutExport"

    invoke-direct {v2, v3, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    goto/16 :goto_d

    :cond_c
    const/16 v9, 0x1d57

    if-eq v1, v9, :cond_26

    const/16 v9, 0x1d58

    if-eq v1, v9, :cond_26

    sget-object v3, Lc/b7;->a:Lc/B0;

    const/16 v3, 0x1cf2

    if-eq v1, v3, :cond_21

    const/16 v3, 0x1cf3

    if-eq v1, v3, :cond_21

    iget-object v3, v6, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x1ced

    if-ne v1, v9, :cond_d

    if-ne v0, v7, :cond_20

    invoke-virtual {v3}, Lc/e0;->n()V

    goto/16 :goto_b

    :cond_d
    const/16 v10, 0x1ceb

    if-eq v1, v10, :cond_1b

    const/16 v11, 0x1cec

    if-eq v1, v11, :cond_1b

    if-ne v1, v10, :cond_10

    if-ne v0, v7, :cond_f

    if-eqz v2, :cond_f

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_f

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    sget-object v1, Lc/N1;->X:Lc/N1;

    if-nez v1, :cond_e

    goto :goto_2

    :cond_e
    iget-object v2, v1, Lc/N1;->c:Ljava/util/concurrent/ScheduledExecutorService;

    new-instance v3, Lc/Z;

    const/4 v4, 0x2

    invoke-direct {v3, v1, p0, v0, v4}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v2, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_f
    :goto_2
    return-void

    :cond_10
    const/16 v3, 0x1cea

    if-ne v1, v3, :cond_13

    if-ne v0, v7, :cond_12

    if-eqz v2, :cond_12

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_12

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    new-instance v1, Lc/y4;

    invoke-direct {v1, p0, v5}, Lc/y4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    sget-object v2, Lc/N1;->X:Lc/N1;

    if-nez v2, :cond_11

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v0}, Lc/y4;->accept(Ljava/lang/Object;)V

    goto :goto_3

    :cond_11
    iget-object v3, v2, Lc/N1;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v4, Lc/Z;

    const/4 v5, 0x3

    invoke-direct {v4, v2, v0, v1, v5}, Lc/Z;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-interface {v3, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_12
    :goto_3
    return-void

    :cond_13
    const/16 v3, 0x1ce9

    if-eq v1, v3, :cond_14

    if-eq v1, v11, :cond_14

    if-ne v1, v9, :cond_1a

    :cond_14
    if-ne v0, v7, :cond_1a

    if-eqz v2, :cond_1a

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_15

    goto :goto_9

    :cond_15
    if-ne v1, v3, :cond_16

    :goto_4
    move-object v13, v8

    goto :goto_6

    :cond_16
    if-ne v1, v11, :cond_17

    move v0, v4

    goto :goto_5

    :cond_17
    move v0, v5

    :goto_5
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v8

    goto :goto_4

    :goto_6
    const-string v0, "\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u043c \u043e\u0431\u043e\u0438\u2026"

    invoke-static {p0, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p0, v0, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v12

    new-instance v14, Lc/y4;

    invoke-direct {v14, p0, v4}, Lc/y4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    sget-object v0, Lc/X3;->a:Ljava/util/concurrent/ExecutorService;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    if-nez v13, :cond_18

    const-string v0, "photo"

    :goto_7
    move-object v11, v0

    goto :goto_8

    :cond_18
    invoke-virtual {v13}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_19

    const-string v0, "photo_day"

    goto :goto_7

    :cond_19
    const-string v0, "photo_night"

    goto :goto_7

    :goto_8
    new-instance v0, Lc/V3;

    move-object v9, v0

    invoke-direct/range {v9 .. v14}, Lc/V3;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/net/Uri;Ljava/lang/Boolean;Lc/y4;)V

    sget-object v1, Lc/X3;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_1a
    :goto_9
    return-void

    :cond_1b
    iget-object v4, v3, Lc/e0;->b:Lc/n1;

    const-string v8, "pending_home_android_widget_id"

    iget-object v4, v4, Lc/n1;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    invoke-interface {v4, v8, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    if-gtz v4, :cond_1c

    goto :goto_b

    :cond_1c
    if-ne v0, v7, :cond_1f

    if-eqz v2, :cond_1d

    const-string v0, "appWidgetId"

    invoke-virtual {v2, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1d

    invoke-virtual {v2, v0, v7}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    if-eq v0, v4, :cond_1d

    goto :goto_a

    :cond_1d
    if-ne v1, v10, :cond_1e

    invoke-virtual {v3, v4}, Lc/e0;->e(I)V

    goto :goto_b

    :cond_1e
    invoke-virtual {v3, v4}, Lc/e0;->p(I)V

    goto :goto_b

    :cond_1f
    :goto_a
    invoke-virtual {v3}, Lc/e0;->c()V

    :cond_20
    :goto_b
    return-void

    :cond_21
    sget-object v4, Lc/b7;->a:Lc/B0;

    sput-object v8, Lc/b7;->a:Lc/B0;

    if-ne v0, v7, :cond_25

    if-eqz v2, :cond_25

    if-nez v4, :cond_22

    goto :goto_c

    :cond_22
    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    if-nez v3, :cond_23

    goto :goto_c

    :cond_23
    iget-object v0, v4, Lc/B0;->c:Ljava/lang/Object;

    check-cast v0, Lc/T5;

    invoke-virtual {v0}, Lc/T5;->U0()Ljava/lang/String;

    move-result-object v0

    iget-object v2, v4, Lc/B0;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_24

    const-string v0, "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u0438\u0437\u043c\u0435\u043d\u0438\u043b\u0441\u044f. \u041e\u043f\u0435\u0440\u0430\u0446\u0438\u044f \u043e\u0442\u043c\u0435\u043d\u0435\u043d\u0430"

    invoke-static {p0, v0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v1, v4, Lc/B0;->d:Ljava/lang/Object;

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_c

    :cond_24
    new-instance v7, Ljava/lang/Thread;

    new-instance v8, Lc/N;

    const/16 v5, 0x9

    move-object v0, v8

    move/from16 v1, p1

    move-object v2, p0

    invoke-direct/range {v0 .. v5}, Lc/N;-><init>(ILandroid/content/Context;Landroid/net/Uri;Ljava/lang/Object;I)V

    const-string v0, "OBD-PID-file"

    invoke-direct {v7, v8, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    :cond_25
    :goto_c
    return-void

    :cond_26
    if-ne v0, v7, :cond_29

    if-eqz v2, :cond_29

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-nez v0, :cond_27

    goto :goto_d

    :cond_27
    invoke-virtual {v3, v5, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-nez v0, :cond_28

    invoke-static {p0, v10}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    goto :goto_d

    :cond_28
    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    new-instance v7, Ljava/lang/Thread;

    new-instance v8, Lc/N;

    const/4 v5, 0x3

    move-object v0, v8

    move/from16 v1, p1

    move-object v4, p0

    invoke-direct/range {v0 .. v5}, Lc/N;-><init>(ILandroid/content/Context;Landroid/net/Uri;Ljava/lang/Object;I)V

    const-string v0, "DriveDeckSettingsFile"

    invoke-direct {v7, v8, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v7}, Ljava/lang/Thread;->start()V

    :cond_29
    :goto_d
    return-void

    :cond_2a
    if-ne v0, v7, :cond_2b

    if-eqz v2, :cond_2b

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_2b

    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p3 .. p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    const-string v2, "application/vnd.android.package-archive"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    :try_start_1
    invoke-virtual {p0, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Landroid/content/ActivityNotFoundException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_e

    :catch_1
    const-string v0, "\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u0442\u043a\u0440\u044b\u0442\u044c \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0449\u0438\u043a Android."

    invoke-static {p0, v0, p0, v4}, Lc/t;->e(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;Lru/drivedeck/launcher/MainActivity;I)V

    :cond_2b
    :goto_e
    return-void
.end method

.method public final onBackPressed()V
    .locals 0

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 12

    const/4 v7, 0x1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-static {v0}, Lru/drivedeck/launcher/MainActivity;->G(Landroid/content/Intent;)V

    new-instance v3, Landroid/content/IntentFilter;

    const-string v0, "ru.drivedeck.launcher.ROTARY_TEST"

    invoke-direct {v3, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/16 v10, 0x21

    if-lt v0, v10, :cond_0

    move v6, v8

    goto :goto_0

    :cond_0
    move v6, v9

    :goto_0
    const-string v4, "ru.drivedeck.launcher.permission.ROTARY_TEST"

    const/4 v5, 0x0

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->E0:Lc/P4;

    move-object v1, p0

    invoke-virtual/range {v1 .. v6}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    invoke-virtual {p0, v7}, Landroid/app/Activity;->requestWindowFeature(I)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v9}, Landroid/view/Window;->setStatusBarColor(I)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v2

    iget v2, v2, Lc/r4;->a:I

    invoke-virtual {v1, v2}, Landroid/view/Window;->setNavigationBarColor(I)V

    new-instance v1, Lc/z;

    invoke-direct {v1, p0}, Lc/z;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-static {p0}, Lc/G8;->q0(Lru/drivedeck/launcher/MainActivity;)V

    new-instance v1, Lc/n1;

    invoke-direct {v1, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v1, Lc/Z7;

    new-instance v2, Lc/J1;

    const/16 v3, 0x13

    invoke-direct {v2, p0, v3}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-direct {v1, p0, v2}, Lc/Z7;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/J1;)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    new-instance v2, Lc/d8;

    invoke-direct {v2, p0, v1}, Lc/d8;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/Z7;)V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->Z:Lc/d8;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->g()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Lc/F8;->a:Ljava/util/concurrent/ExecutorService;

    const-string v2, "ru"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_1

    :cond_1
    :try_start_0
    invoke-static {p0, v1}, Lc/F8;->c(Landroid/content/Context;Ljava/lang/String;)Ljava/util/zip/GZIPInputStream;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    new-instance v2, Lc/b;

    invoke-direct {v2, p0, v1, v8}, Lc/b;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    new-instance v4, Lc/U3;

    invoke-direct {v4, v1, v3, v2, v7}, Lc/U3;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/function/Consumer;I)V

    sget-object v1, Lc/F8;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v4}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_1
    new-instance v11, Lc/g9;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    new-instance v4, Lc/x3;

    invoke-direct {v4, p0, v8}, Lc/x3;-><init>(Landroid/view/KeyEvent$Callback;I)V

    new-instance v5, Lc/u4;

    invoke-direct {v5, p0}, Lc/u4;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    new-instance v6, Lc/J1;

    const/16 v1, 0x14

    invoke-direct {v6, p0, v1}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    move-object v1, v11

    move-object v2, p0

    invoke-direct/range {v1 .. v6}, Lc/g9;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/n1;Lc/x3;Lc/u4;Lc/J1;)V

    iput-object v11, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget v1, v1, Lc/e8;->e:I

    const/4 v2, 0x4

    if-eq v1, v2, :cond_3

    if-ne v1, v8, :cond_2

    goto :goto_2

    :cond_2
    move v1, v9

    goto :goto_3

    :cond_3
    :goto_2
    move v1, v7

    :goto_3
    invoke-virtual {v11, v1}, Lc/g9;->m(Z)V

    new-instance v1, Lc/e0;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-direct {v1, p0, v3}, Lc/e0;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/n1;)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v3, "auto_bluetooth_audio"

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1, v3, v9}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_4

    invoke-virtual {p0, v7}, Lru/drivedeck/launcher/MainActivity;->c0(Z)V

    :cond_4
    new-instance v1, Lc/P4;

    invoke-direct {v1, p0, v9}, Lc/P4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->B:Lc/P4;

    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const-string v3, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v1, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v3, "android.intent.action.SCREEN_ON"

    invoke-virtual {v1, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v3, "android.intent.action.TIMEZONE_CHANGED"

    invoke-virtual {v1, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v3, "android.intent.action.TIME_SET"

    invoke-virtual {v1, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    if-lt v0, v10, :cond_5

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->B:Lc/P4;

    invoke-virtual {p0, v3, v1, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    goto :goto_4

    :cond_5
    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->B:Lc/P4;

    invoke-virtual {p0, v3, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    :goto_4
    invoke-static {p0}, Lc/R1;->b(Landroid/content/Context;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->j0()Z

    move-result v1

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->v0:Z

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v3, "car_mode"

    invoke-static {v3}, Landroid/provider/Settings$System;->getUriFor(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->w0:Lc/O4;

    invoke-virtual {v1, v3, v9, v4}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->x0:Lc/N4;

    invoke-virtual {v1, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v3

    new-instance v4, Lc/t4;

    invoke-direct {v4, p0, v7}, Lc/t4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->removeIf(Ljava/util/function/Predicate;)Z

    move-result v4

    if-eqz v4, :cond_6

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v4, v3}, Lc/n1;->D0(Ljava/util/List;)V

    :cond_6
    new-instance v3, Lc/P4;

    invoke-direct {v3, p0, v7}, Lc/P4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    iput-object v3, p0, Lru/drivedeck/launcher/MainActivity;->C:Lc/P4;

    new-instance v3, Landroid/content/IntentFilter;

    invoke-direct {v3}, Landroid/content/IntentFilter;-><init>()V

    const-string v4, "android.intent.action.PACKAGE_ADDED"

    invoke-virtual {v3, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v4, "android.intent.action.PACKAGE_REMOVED"

    invoke-virtual {v3, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v4, "android.intent.action.PACKAGE_CHANGED"

    invoke-virtual {v3, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v4, "package"

    invoke-virtual {v3, v4}, Landroid/content/IntentFilter;->addDataScheme(Ljava/lang/String;)V

    if-lt v0, v10, :cond_7

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->C:Lc/P4;

    invoke-virtual {p0, v4, v3, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    goto :goto_5

    :cond_7
    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->C:Lc/P4;

    invoke-virtual {p0, v2, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    :goto_5
    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v2}, Lc/n1;->p()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v9}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v7}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v5

    invoke-static {v0}, Lc/n1;->Z0(I)Z

    move-result v0

    if-nez v0, :cond_b

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    const-string v6, ""

    if-nez v0, :cond_8

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    move-object v0, v6

    goto :goto_6

    :cond_8
    move-object v0, v4

    :goto_6
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_9

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_9

    move-object v3, v6

    goto :goto_7

    :cond_9
    move-object v3, v5

    :goto_7
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_a

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_a

    goto :goto_8

    :cond_a
    move-object v6, v3

    goto :goto_8

    :cond_b
    move-object v0, v4

    move-object v6, v5

    :goto_8
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_c

    goto :goto_9

    :cond_c
    iget-object v2, v2, Lc/n1;->b:Ljava/lang/Object;

    check-cast v2, Landroid/content/SharedPreferences;

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "slot_0"

    invoke-interface {v2, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const-string v2, "slot_1"

    invoke-interface {v0, v2, v6}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :goto_9
    new-instance v0, Lc/m5;

    invoke-direct {v0, p0}, Lc/m5;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->K:Lc/m5;

    iget-object v2, v0, Lc/m5;->c:Landroid/media/session/MediaSessionManager;

    if-eqz v2, :cond_e

    iget-boolean v3, v0, Lc/m5;->g:Z

    if-eqz v3, :cond_d

    goto :goto_a

    :cond_d
    :try_start_1
    iget-object v3, v0, Lc/m5;->a:Landroid/content/Context;

    iget-object v4, v0, Lc/m5;->i:Lc/L;

    iget-object v5, v0, Lc/m5;->d:Landroid/os/Handler;

    invoke-static {v3, v2, v4, v5}, Lc/G8;->W(Landroid/content/Context;Landroid/media/session/MediaSessionManager;Landroid/media/session/MediaSessionManager$OnActiveSessionsChangedListener;Landroid/os/Handler;)V

    iput-boolean v7, v0, Lc/m5;->g:Z

    invoke-virtual {v0}, Lc/m5;->a()V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_a

    :catch_1
    move-exception v0

    const-string v2, "DriveDeckMusic"

    const-string v3, "Navigator music sessions unavailable"

    invoke-static {v2, v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_e
    :goto_a
    new-instance v0, Lc/s4;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-direct {v0, p0, v2, v3, p0}, Lc/s4;-><init>(Lru/drivedeck/launcher/MainActivity;Lc/z;Lc/n1;Lru/drivedeck/launcher/MainActivity;)V

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->m(Landroid/content/Intent;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    goto :goto_b

    :cond_f
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->y(Landroid/content/Intent;)V

    :goto_b
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const-string v2, "ru.drivedeck.launcher.NATIVE_SPLIT"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ru.drivedeck.launcher.PHONE"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_11

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    const-string v3, "ru.drivedeck.launcher.MUSIC"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_10

    goto :goto_c

    :cond_10
    move v2, v9

    goto :goto_d

    :cond_11
    :goto_c
    move v2, v7

    :goto_d
    new-instance v3, Lc/v4;

    invoke-direct {v3, p0, v0, v2}, Lc/v4;-><init>(Lru/drivedeck/launcher/MainActivity;ZZ)V

    invoke-static {}, Lc/j8;->v()Z

    move-result v0

    if-eqz v0, :cond_12

    sget-object v0, Lc/j8;->b:Landroid/os/Handler;

    new-instance v2, Lc/h8;

    invoke-direct {v2, v3, v9}, Lc/h8;-><init>(Lc/v4;I)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_e

    :cond_12
    new-instance v0, Lc/h8;

    invoke-direct {v0, v3, v7}, Lc/h8;-><init>(Lc/v4;I)V

    sget-object v2, Lc/j8;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :goto_e
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->P:Lc/N4;

    const-wide/16 v2, 0xbb8

    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final onDestroy()V
    .locals 8

    const/4 v0, 0x0

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A0:Z

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->C0:Lc/J1;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->E0:Lc/P4;

    invoke-virtual {p0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lc/t8;->d()V

    :cond_0
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Z:Lc/d8;

    if-eqz v1, :cond_1

    invoke-virtual {v1}, Lc/d8;->f()V

    :cond_1
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Landroid/app/Dialog;->dismiss()V

    :cond_2
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->T:Lc/D3;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Landroid/app/Dialog;->dismiss()V

    :cond_3
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_a

    iget-boolean v4, v1, Lc/Z7;->r:Z

    if-eqz v4, :cond_4

    goto :goto_1

    :cond_4
    sget-object v4, Lc/Z7;->Q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v1, :cond_5

    sget-object v4, Lc/Z7;->Q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->clear()V

    :cond_5
    invoke-virtual {v1, v0}, Lc/Z7;->r(Z)V

    iput-boolean v3, v1, Lc/Z7;->r:Z

    iget-object v4, v1, Lc/Z7;->c:Landroid/os/Handler;

    invoke-virtual {v4, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    invoke-virtual {v1, v0, v2}, Lc/Z7;->s(ZLc/b;)V

    sget-object v4, Lc/Z7;->R:[I

    array-length v5, v4

    move v6, v0

    :goto_0
    if-ge v6, v5, :cond_6

    aget v7, v4, v6

    invoke-virtual {v1, v7, v0}, Lc/Z7;->q(IZ)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_6
    iput-object v2, v1, Lc/Z7;->k:Landroid/os/IBinder;

    iget-boolean v4, v1, Lc/Z7;->l:Z

    if-eqz v4, :cond_7

    iget-object v4, v1, Lc/Z7;->b:Landroid/content/Context;

    invoke-virtual {v4, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_7
    iget-object v4, v1, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    if-eqz v4, :cond_9

    :try_start_0
    iget-object v4, v1, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    if-eqz v4, :cond_8

    iget-object v4, v1, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    iget-object v5, v1, Lc/Z7;->i:Landroid/bluetooth/BluetoothProfile;

    const/16 v6, 0x10

    invoke-virtual {v4, v6, v5}, Landroid/bluetooth/BluetoothAdapter;->closeProfileProxy(ILandroid/bluetooth/BluetoothProfile;)V

    :cond_8
    iget-object v4, v1, Lc/Z7;->j:Landroid/bluetooth/BluetoothProfile;

    if-eqz v4, :cond_9

    iget-object v4, v1, Lc/Z7;->h:Landroid/bluetooth/BluetoothAdapter;

    iget-object v5, v1, Lc/Z7;->j:Landroid/bluetooth/BluetoothProfile;

    const/16 v6, 0x11

    invoke-virtual {v4, v6, v5}, Landroid/bluetooth/BluetoothAdapter;->closeProfileProxy(ILandroid/bluetooth/BluetoothProfile;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_9
    iget-object v4, v1, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    new-instance v5, Lc/P7;

    const/4 v6, 0x4

    invoke-direct {v5, v1, v6}, Lc/P7;-><init>(Lc/Z7;I)V

    invoke-interface {v4, v5}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    iget-object v4, v1, Lc/Z7;->d:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v4}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    const-string v4, ""

    iput-object v4, v1, Lc/e8;->d:Ljava/lang/String;

    iput-object v4, v1, Lc/e8;->c:Ljava/lang/String;

    iput-object v4, v1, Lc/e8;->b:Ljava/lang/String;

    iput-object v4, v1, Lc/e8;->a:Ljava/lang/String;

    iput v0, v1, Lc/e8;->e:I

    :cond_a
    :goto_1
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v1, :cond_b

    iput-boolean v3, v1, Lc/g9;->m:Z

    invoke-virtual {v1, v0}, Lc/g9;->q(Z)V

    :cond_b
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    if-eqz v1, :cond_c

    invoke-virtual {v1}, Lc/u0;->b()V

    :cond_c
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->w0:Lc/O4;

    invoke-virtual {v1, v4}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->N:Lc/J1;

    invoke-virtual {v1, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-eqz v1, :cond_d

    invoke-virtual {v1}, Lc/P;->d()V

    :cond_d
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->K:Lc/m5;

    if-eqz v1, :cond_e

    invoke-virtual {v1}, Lc/m5;->close()V

    :cond_e
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->B:Lc/P4;

    if-eqz v1, :cond_f

    :try_start_1
    invoke-virtual {p0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->B:Lc/P4;

    :cond_f
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->C:Lc/P4;

    if-eqz v1, :cond_10

    :try_start_2
    invoke-virtual {p0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->C:Lc/P4;

    :cond_10
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    if-eqz v1, :cond_11

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    if-eqz v4, :cond_11

    invoke-virtual {v4, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_11
    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->v:Lc/n3;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->w:Landroid/view/View;

    invoke-static {v1, v0}, Lru/drivedeck/launcher/MainActivity;->e0(Landroid/view/View;Z)V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->w:Landroid/view/View;

    invoke-virtual {p0, v2, v0}, Lru/drivedeck/launcher/MainActivity;->x(Landroid/view/View;Z)V

    iget-wide v4, p0, Lru/drivedeck/launcher/MainActivity;->k:J

    const-wide/16 v6, 0x1

    add-long/2addr v4, v6

    iput-wide v4, p0, Lru/drivedeck/launcher/MainActivity;->k:J

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v4, p0, Lru/drivedeck/launcher/MainActivity;->x0:Lc/N4;

    invoke-virtual {v1, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v1, :cond_12

    invoke-virtual {v1}, Lc/m2;->F()V

    :cond_12
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v1, :cond_13

    invoke-virtual {v1}, Lc/Q3;->w()V

    iget-object v4, v1, Lc/Q3;->w:Lc/e0;

    invoke-virtual {v4, v0}, Lc/e0;->q(Z)V

    iget-object v4, v1, Lc/Q3;->t:Lc/P3;

    invoke-virtual {v4}, Lc/P3;->k()V

    invoke-virtual {v1}, Lc/Q3;->B()V

    iget-object v4, v1, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v4}, Lc/t2;->L()V

    iget-object v1, v1, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v1}, Lc/t2;->L()V

    :cond_13
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    iput-boolean v0, v1, Lc/e0;->i:Z

    invoke-virtual {v1}, Lc/e0;->w()V

    iget-object v0, v1, Lc/e0;->f:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v0, v1, Lc/e0;->g:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    iget-object v0, v1, Lc/e0;->h:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    new-instance v0, Lc/a1;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lc/a1;-><init>(I)V

    sget-object v1, Lc/j8;->a:Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->u0:Landroid/os/Handler;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->P:Lc/N4;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->O:Lc/J8;

    if-eqz v0, :cond_15

    iput-boolean v3, v0, Lc/J8;->i:Z

    iget-object v1, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_14

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    instance-of v1, v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_14

    iget-object v1, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    iget-object v3, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_14
    iput-object v2, v0, Lc/J8;->c:Landroid/widget/LinearLayout;

    :cond_15
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 5

    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    invoke-static {p1}, Lru/drivedeck/launcher/MainActivity;->G(Landroid/content/Intent;)V

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    invoke-static {p0, p1}, Lru/drivedeck/launcher/HebrewVoiceBridge;->onIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v0

    if-eqz v0, :he_voice_n

    return-void

    :he_voice_n

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const-string v1, "ru.drivedeck.launcher.VOICE_STARTUP"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lc/g9;->j()V

    :cond_0
    return-void

    :cond_1
    invoke-static {p1}, Lc/k6;->N(Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_1a

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->D:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->G:Z

    :cond_2
    const-string v0, "ru.drivedeck.launcher.PHONE"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->P()V

    return-void

    :cond_3
    const-string v0, "ru.drivedeck.launcher.MUSIC"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->O()V

    return-void

    :cond_4
    const-string v0, "ru.drivedeck.launcher.NATIVE_SPLIT"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->i0()V

    return-void

    :cond_5
    const-string v0, "ru.drivedeck.launcher.VOICE_SCREEN"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_14

    iget v0, p0, Lru/drivedeck/launcher/MainActivity;->k0:I

    if-eqz v0, :cond_14

    iput v1, p0, Lru/drivedeck/launcher/MainActivity;->k0:I

    const/16 p1, 0x13

    if-eq v0, p1, :cond_e

    invoke-static {v0}, Ld/a;->d(I)Z

    move-result v3

    if-eqz v3, :cond_6

    goto/16 :goto_2

    :cond_6
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->s()V

    const/16 p1, 0x7d0

    if-le v0, p1, :cond_c

    const/16 v3, 0x834

    if-gt v0, v3, :cond_c

    sub-int/2addr v0, p1

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->o0()Z

    move-result p1

    if-nez p1, :cond_7

    const-string p1, "\u0421\u0442\u0440\u0430\u043d\u0438\u0446\u0430 \u0441 \u0434\u0432\u0443\u043c\u044f \u043e\u043a\u043d\u0430\u043c\u0438 \u043e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0430"

    invoke-virtual {p0, p1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    goto :goto_1

    :cond_7
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object p1

    new-instance v1, Lc/t4;

    const/4 v3, 0x0

    invoke-direct {v1, p0, v3}, Lc/t4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->removeIf(Ljava/util/function/Predicate;)Z

    const-string v1, ""

    if-ge v0, v2, :cond_9

    :cond_8
    move-object v3, v1

    goto :goto_0

    :cond_9
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v2, v0

    :cond_a
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_8

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->L(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_a

    add-int/lit8 v2, v2, -0x1

    if-nez v2, :cond_a

    :goto_0
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_b

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "\u0421\u043f\u043b\u0438\u0442 "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " \u043e\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0432 \u0434\u043e\u043a\u0435"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    goto :goto_1

    :cond_b
    iput-object v1, p0, Lru/drivedeck/launcher/MainActivity;->E:Ljava/lang/String;

    invoke-static {v3}, Lc/G8;->R(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v3}, Lc/G8;->w0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v3}, Lc/G8;->l0(Ljava/lang/String;)F

    move-result v1

    invoke-virtual {p0, p1, v0, v1}, Lru/drivedeck/launcher/MainActivity;->J(Ljava/lang/String;Ljava/lang/String;F)V

    :goto_1
    return-void

    :cond_c
    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->S()V

    if-eqz p1, :cond_d

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz p1, :cond_d

    invoke-virtual {p1}, Lc/m2;->H()V

    :cond_d
    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    goto :goto_4

    :cond_e
    :goto_2
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v1, :cond_f

    invoke-virtual {v1}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-nez v1, :cond_10

    :cond_f
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->K()V

    :cond_10
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v1, :cond_13

    if-ne v0, p1, :cond_11

    const-string p1, "updates"

    goto :goto_3

    :cond_11
    invoke-static {v0}, Ld/a;->d(I)Z

    move-result p1

    if-eqz p1, :cond_12

    sget-object p1, Ld/a;->j:[Ljava/lang/String;

    add-int/lit16 v0, v0, -0xbb9

    aget-object p1, p1, v0

    :goto_3
    invoke-virtual {v1, p1}, Lc/k3;->u0(Ljava/lang/String;)V

    goto :goto_4

    :cond_12
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Invalid settings page"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_13
    :goto_4
    return-void

    :cond_14
    invoke-virtual {p0, p1}, Lru/drivedeck/launcher/MainActivity;->m(Landroid/content/Intent;)Z

    move-result v0

    if-eqz v0, :cond_15

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->m0()V

    return-void

    :cond_15
    const-string v0, "android.intent.action.MAIN"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_19

    const-string v0, "android.intent.category.HOME"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->hasCategory(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_19

    sget-object p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez p1, :cond_16

    goto :goto_5

    :cond_16
    iget-boolean v0, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->d:Z

    iput-boolean v1, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->d:Z

    move v1, v0

    :goto_5
    if-nez v1, :cond_17

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    :cond_17
    sget-object p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz p1, :cond_18

    iget-object p1, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz p1, :cond_18

    invoke-virtual {p1}, Lc/S1;->c()V

    :cond_18
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->s()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->Z()V

    return-void

    :cond_19
    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    invoke-virtual {p0, p1}, Lru/drivedeck/launcher/MainActivity;->y(Landroid/content/Intent;)V

    return-void

    :cond_1a
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-nez v0, :cond_1b

    goto :goto_6

    :cond_1b
    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->c()V

    :goto_6
    return-void
.end method

.method public final onPause()V
    .locals 2

    const/4 v0, 0x0

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/l9;->b()V

    const/4 v0, 0x0

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x80

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    return-void
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .locals 2

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    sget-object p2, Lc/q4;->a:[B

    const/16 p2, 0x1d59

    const/4 v0, 0x0

    if-eq p1, p2, :cond_0

    goto :goto_0

    :cond_0
    array-length p2, p3

    if-lez p2, :cond_1

    aget p2, p3, v0

    if-nez p2, :cond_1

    sget-object p2, Lc/q4;->b:[B

    const/4 p3, 0x0

    sput-object p3, Lc/q4;->b:[B

    invoke-static {p0, p2}, Lc/q4;->w(Lru/drivedeck/launcher/MainActivity;[B)V

    goto :goto_0

    :cond_1
    const-string p2, "\u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u0435 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0445\u0440\u0430\u043d\u0438\u043b\u0438\u0449\u0443 \u0434\u043b\u044f \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f \u0432 \u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0438"

    invoke-static {p0, p2}, Lc/q4;->p(Landroid/app/Activity;Ljava/lang/String;)V

    :goto_0
    const/16 p2, 0x1f91

    if-ne p1, p2, :cond_2

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result p2

    invoke-virtual {p0, p2}, Lru/drivedeck/launcher/MainActivity;->f0(Z)V

    iget-object p2, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz p2, :cond_2

    invoke-virtual {p2}, Landroid/app/Dialog;->isShowing()Z

    move-result p2

    if-eqz p2, :cond_2

    iget-object p2, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    iget-object p3, p2, Lc/k3;->h:Ljava/lang/String;

    const-string v1, "voice"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_2

    invoke-virtual {p2}, Lc/k3;->S()V

    :cond_2
    const/16 p2, 0x1f92

    if-ne p1, p2, :cond_5

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    invoke-virtual {p1}, Lc/Z7;->g()V

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_3

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->c0:Z

    :cond_3
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->n()V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {p1}, Lc/n1;->q0()Z

    move-result p1

    if-eqz p1, :cond_4

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->l()V

    :cond_4
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->a0:Lc/Q0;

    if-eqz p1, :cond_5

    iget-object p1, p1, Lc/Q0;->b:Ljava/lang/Object;

    check-cast p1, Lc/O7;

    invoke-virtual {p1}, Lc/O7;->n()V

    :cond_5
    return-void
.end method

.method public final onResume()V
    .locals 8

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-static {p0, v0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->onIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    invoke-static {p0}, Lru/drivedeck/launcher/RootBootEnforcer;->enforceQuiet(Landroid/content/Context;)V

    invoke-static {p0}, Lru/drivedeck/launcher/KeepAliveService;->start(Landroid/content/Context;)V

    invoke-static {p0}, Lru/drivedeck/launcher/RootBootEnforcer;->startObdWakeupRetry(Landroid/content/Context;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const-string v2, "ru.drivedeck.launcher.PHONE"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    new-instance v3, Lc/J1;

    const/16 v4, 0x15

    invoke-direct {v3, p0, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v1, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const-string v3, "ru.drivedeck.launcher.MUSIC"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    new-instance v3, Lc/J1;

    const/16 v4, 0x16

    invoke-direct {v3, p0, v4}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v1, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_1
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    if-eqz v1, :cond_4

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    invoke-static {v1}, Lc/k6;->N(Landroid/content/Intent;)Z

    move-result v3

    if-nez v3, :cond_2

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->V:Lc/g9;

    invoke-virtual {v1}, Lc/g9;->j()V

    goto :goto_0

    :cond_2
    iget-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->A:Z

    if-nez v3, :cond_3

    goto :goto_0

    :cond_3
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->c()V

    :goto_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->V()V

    :cond_4
    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->p0:Z

    if-nez v1, :cond_5

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const-string v2, ""

    invoke-virtual {v1, v2}, Lc/n1;->w0(Ljava/lang/String;)V

    :cond_5
    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->z:Z

    if-nez v1, :cond_6

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/16 v2, 0x80

    invoke-virtual {v1, v2}, Landroid/view/Window;->addFlags(I)V

    :cond_6
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    iput-boolean v0, v1, Lc/e0;->i:Z

    const/4 v2, 0x0

    iput-boolean v2, v1, Lc/e0;->l:Z

    invoke-virtual {v1}, Lc/e0;->w()V

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->D:Z

    if-eqz v1, :cond_7

    iget-boolean v3, p0, Lru/drivedeck/launcher/MainActivity;->G:Z

    if-nez v3, :cond_7

    move v3, v0

    goto :goto_1

    :cond_7
    move v3, v2

    :goto_1
    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->G:Z

    if-eqz v1, :cond_8

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    iget-wide v6, p0, Lru/drivedeck/launcher/MainActivity;->I:J

    sub-long/2addr v4, v6

    const-wide/16 v6, 0x2710

    cmp-long v1, v4, v6

    if-lez v1, :cond_8

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    const-wide/16 v6, 0x9c4

    add-long/2addr v4, v6

    iput-wide v4, p0, Lru/drivedeck/launcher/MainActivity;->H:J

    :cond_8
    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->D:Z

    invoke-static {p0}, Lc/R1;->b(Landroid/content/Context;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    if-eqz v3, :cond_a

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->p0:Z

    if-nez v1, :cond_a

    iget-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-eqz v1, :cond_9

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eqz v1, :cond_9

    iget-boolean v1, v1, Lc/m2;->I:Z

    if-eqz v1, :cond_a

    :cond_9
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->Z()V

    :cond_a
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-eqz v1, :cond_b

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-eq v1, v3, :cond_b

    return-void

    :cond_b
    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v1, v3, :cond_10

    if-eqz v3, :cond_10

    invoke-virtual {v3, v0}, Lc/m2;->G(Z)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v3

    iget-object v1, v1, Lc/F;->l:Landroid/view/View;

    check-cast v1, Lc/b2;

    invoke-virtual {v1, v3}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v1}, Lc/m2;->D()V

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    iget-object v1, v1, Lc/m2;->t:[Lc/t2;

    array-length v3, v1

    :goto_2
    if-ge v2, v3, :cond_f

    aget-object v4, v1, v2

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v5

    if-nez v5, :cond_e

    iget-object v5, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v5}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_c

    invoke-virtual {v4}, Lc/t2;->m()V

    goto :goto_3

    :cond_c
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x1b

    if-ne v5, v6, :cond_e

    iget-object v5, v4, Lc/t2;->d:Lc/v7;

    if-eqz v5, :cond_e

    invoke-virtual {v5}, Lc/v7;->l()Z

    move-result v5

    if-nez v5, :cond_d

    goto :goto_3

    :cond_d
    iput-boolean v0, v4, Lc/t2;->I:Z

    const-wide/16 v5, 0xdc

    invoke-virtual {v4, v5, v6}, Lc/t2;->Z(J)V

    :cond_e
    :goto_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :cond_f
    return-void

    :cond_10
    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v1, v2, :cond_12

    if-eqz v2, :cond_12

    invoke-virtual {v2, v0}, Lc/Q3;->P(Z)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v1

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0, v1}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    invoke-virtual {v0}, Lc/Q3;->M()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->J:Lc/P;

    if-eqz v0, :cond_11

    invoke-virtual {v0}, Lc/P;->c()V

    :cond_11
    return-void

    :cond_12
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->e:Lc/s4;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v0

    invoke-static {v0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->i(Ljava/util/ArrayList;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/J1;

    const/16 v2, 0x17

    invoke-direct {v1, p0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v2, 0x118

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/J1;

    const/16 v2, 0x18

    invoke-direct {v1, p0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v2, 0x44c

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/J1;

    const/16 v2, 0x19

    invoke-direct {v1, p0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v2, 0x960

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final onStop()V
    .locals 7

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/t8;->d()V

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Lc/l9;->b()V

    const/4 v0, 0x0

    iput-object v0, p0, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->d:Lc/e0;

    const/4 v1, 0x0

    iput-boolean v1, v0, Lc/e0;->i:Z

    invoke-virtual {v0}, Lc/e0;->w()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->D:Z

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v2, v3, :cond_6

    if-eqz v3, :cond_6

    invoke-virtual {v3}, Landroid/view/View;->isShown()Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_2

    :cond_2
    iget-object v2, v3, Lc/m2;->t:[Lc/t2;

    array-length v3, v2

    :goto_0
    if-ge v1, v3, :cond_6

    aget-object v4, v2, v1

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v5

    if-nez v5, :cond_5

    iget-object v5, v4, Lc/t2;->u:Ljava/lang/String;

    invoke-static {v5}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_1

    :cond_3
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x1b

    if-ne v5, v6, :cond_5

    invoke-virtual {v4}, Landroid/view/View;->isShown()Z

    move-result v5

    if-eqz v5, :cond_5

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v5

    if-nez v5, :cond_5

    iget-object v5, v4, Lc/t2;->d:Lc/v7;

    if-eqz v5, :cond_5

    invoke-virtual {v5}, Lc/v7;->l()Z

    move-result v5

    if-nez v5, :cond_4

    goto :goto_1

    :cond_4
    iput-boolean v0, v4, Lc/t2;->I:Z

    invoke-virtual {v4}, Lc/t2;->O()V

    const-string v5, "host_stopped"

    invoke-virtual {v4, v5}, Lc/t2;->g(Ljava/lang/String;)V

    :cond_5
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_6
    :goto_2
    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    return-void
.end method

.method public final onWindowFocusChanged(Z)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->D0:Lc/t8;

    if-eqz v0, :cond_1

    if-nez p1, :cond_0

    iget-object v1, v0, Lc/t8;->c:Lc/r8;

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lc/t8;->f()Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {v0}, Lc/t8;->d()V

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_1
    :goto_0
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const-string v1, "focused"

    filled-new-array {v1, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "window_focus_changed"

    invoke-static {v1, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getWindowVisibility()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const-string v2, "visibility"

    const-string v3, "is_shown"

    filled-new-array {v2, v1, v3, v0}, [Ljava/lang/Object;

    move-result-object v0

    const-string v1, "root_window_visibility"

    invoke-static {v1, v0}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    if-nez p1, :cond_2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iget-wide v2, p0, Lru/drivedeck/launcher/MainActivity;->H:J

    cmp-long v0, v0, v2

    if-gez v0, :cond_2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/J1;

    const/16 v2, 0x12

    invoke-direct {v1, p0, v2}, Lc/J1;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v0, v1, :cond_3

    if-eqz v1, :cond_3

    iget-object v0, v1, Lc/m2;->t:[Lc/t2;

    array-length v1, v0

    const/4 v2, 0x0

    :goto_1
    if-ge v2, v1, :cond_3

    aget-object v3, v0, v2

    invoke-virtual {v3, p1}, Lc/t2;->G(Z)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_3
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v0, v1, :cond_4

    if-eqz v1, :cond_4

    iget-object v0, v1, Lc/Q3;->y:Lc/t2;

    invoke-virtual {v0, p1}, Lc/t2;->G(Z)V

    iget-object v0, v1, Lc/Q3;->z:Lc/t2;

    invoke-virtual {v0, p1}, Lc/t2;->G(Z)V

    :cond_4
    if-eqz p1, :cond_5

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    :cond_5
    return-void
.end method

.method public final p()I
    .locals 3

    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    if-nez v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-eqz v0, :cond_1

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Lc/b2;->g(FF)I

    move-result v0

    return v0

    :cond_1
    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-nez v0, :cond_2

    const/4 v0, 0x6

    goto :goto_0

    :cond_2
    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v0, v1, v2}, Lc/b2;->g(FF)I

    move-result v0

    :goto_0
    return v0
.end method

.method public final q(JLjava/lang/String;Landroid/view/View;Landroid/view/View;J)V
    .locals 12

    move-object v0, p0

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    iget-object v4, v0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    const-string v5, "none"

    const-string v6, "split"

    const-string v7, "home"

    if-ne v1, v4, :cond_0

    move-object v8, v7

    goto :goto_0

    :cond_0
    iget-object v8, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v1, v8, :cond_1

    move-object v8, v6

    goto :goto_0

    :cond_1
    move-object v8, v5

    :goto_0
    if-ne v2, v4, :cond_2

    move-object v9, v7

    goto :goto_1

    :cond_2
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v2, v1, :cond_3

    move-object v9, v6

    goto :goto_1

    :cond_3
    move-object v9, v5

    :goto_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    sub-long v1, v1, p6

    const-wide/16 v4, 0x0

    invoke-static {v4, v5, v1, v2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v10

    const-string v7, "to"

    const-string v11, "duration_ms"

    const-string v1, "transition_id"

    const-string v4, "phase"

    const-string v5, "from"

    move-object v2, v3

    move-object v3, v4

    move-object v4, p3

    move-object v6, v8

    move-object v8, v9

    move-object v9, v11

    filled-new-array/range {v1 .. v10}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "dashboard_transition"

    invoke-static {v2, v1}, Lc/N1;->h(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method

.method public final r(Lc/Q;)V
    .locals 4

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->o0()Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->q0()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v2, p0, Lru/drivedeck/launcher/MainActivity;->i0:J

    cmp-long v0, v0, v2

    if-lez v0, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->l()V

    iget-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->j0:J

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u041f\u043e\u0437\u0432\u043e\u043d\u0438\u0442\u044c"

    invoke-static {p0, v3}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p1, Lc/Q;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    iget-object v2, p0, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    new-instance v3, Lc/J4;

    invoke-direct {v3, p0, v0, v1}, Lc/J4;-><init>(Lru/drivedeck/launcher/MainActivity;J)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Lc/Q;->b:Ljava/lang/String;

    invoke-static {p1}, Lc/k6;->W(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, v2, Lc/Z7;->a:Lc/e8;

    invoke-virtual {v0}, Lc/e8;->b()Z

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x7

    invoke-virtual {v2, v0, p1, v3}, Lc/Z7;->f(ILjava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_1

    :cond_2
    :goto_0
    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, p1}, Lc/J4;->accept(Ljava/lang/Object;)V

    :cond_3
    :goto_1
    return-void
.end method

.method public final s()V
    .locals 2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->U:Lc/k3;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Lc/k3;->dismiss()V

    :cond_0
    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    return-void
.end method

.method public final t(Landroid/view/View;)V
    .locals 26

    move-object/from16 v13, p0

    move-object/from16 v14, p1

    if-nez v14, :cond_0

    return-void

    :cond_0
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-eq v0, v14, :cond_1

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->k()Z

    :cond_1
    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v13, v8, v9}, Lru/drivedeck/launcher/MainActivity;->x(Landroid/view/View;Z)V

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    const/4 v10, 0x0

    if-nez v0, :cond_2

    goto :goto_0

    :cond_2
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {v0, v10}, Landroid/view/View;->setTranslationX(F)V

    :goto_0
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-nez v0, :cond_3

    goto :goto_1

    :cond_3
    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->cancel()V

    invoke-virtual {v0, v10}, Landroid/view/View;->setTranslationX(F)V

    :goto_1
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    if-nez v0, :cond_4

    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {v0, v13}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    invoke-virtual {v13, v0}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    :cond_4
    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v11, 0x4

    if-nez v0, :cond_5

    invoke-virtual {v14, v11}, Landroid/view/View;->setVisibility(I)V

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v14, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_5
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->i:Landroid/view/View;

    if-nez v0, :cond_7

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    if-eqz v1, :cond_7

    move v1, v9

    :goto_2
    iget-object v2, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_7

    iget-object v2, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    if-eq v2, v14, :cond_6

    iget-object v3, v13, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    if-eq v2, v3, :cond_6

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-nez v3, :cond_6

    move-object v15, v2

    goto :goto_3

    :cond_6
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_7
    move-object v15, v0

    :goto_3
    const/4 v12, 0x1

    if-ne v15, v14, :cond_a

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    if-nez v0, :cond_a

    invoke-virtual/range {p1 .. p1}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_a

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v14, v0, :cond_8

    invoke-virtual {v0, v12}, Lc/Q3;->P(Z)V

    goto :goto_4

    :cond_8
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v14, v0, :cond_9

    invoke-virtual {v0, v12}, Lc/m2;->G(Z)V

    :cond_9
    :goto_4
    invoke-virtual/range {p0 .. p1}, Lru/drivedeck/launcher/MainActivity;->j0(Landroid/view/View;)V

    return-void

    :cond_a
    iget-wide v0, v13, Lru/drivedeck/launcher/MainActivity;->k:J

    const-wide/16 v2, 0x1

    add-long v6, v0, v2

    iput-wide v6, v13, Lru/drivedeck/launcher/MainActivity;->k:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v16

    invoke-virtual {v13, v15}, Lru/drivedeck/launcher/MainActivity;->F(Landroid/view/View;)Lc/t2;

    move-result-object v0

    if-nez v0, :cond_b

    move/from16 v18, v9

    goto :goto_6

    :cond_b
    iget-object v1, v0, Lc/t2;->d:Lc/v7;

    if-nez v1, :cond_c

    move v1, v9

    goto :goto_5

    :cond_c
    iget v1, v1, Lc/v7;->v:I

    :goto_5
    move/from16 v18, v1

    :goto_6
    if-nez v0, :cond_d

    move/from16 v19, v9

    goto :goto_8

    :cond_d
    iget-object v0, v0, Lc/t2;->d:Lc/v7;

    if-nez v0, :cond_e

    move v0, v9

    goto :goto_7

    :cond_e
    iget v0, v0, Lc/v7;->w:I

    :goto_7
    move/from16 v19, v0

    :goto_8
    iget-object v5, v13, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    iput-object v14, v13, Lru/drivedeck/launcher/MainActivity;->j:Landroid/view/View;

    const-string v3, "requested"

    move-object/from16 v0, p0

    move-wide v1, v6

    move-object v4, v15

    move-object v8, v5

    move-object/from16 v5, p1

    move-wide/from16 v21, v6

    move-wide/from16 v6, v16

    invoke-virtual/range {v0 .. v7}, Lru/drivedeck/launcher/MainActivity;->q(JLjava/lang/String;Landroid/view/View;Landroid/view/View;J)V

    if-eqz v8, :cond_f

    if-eq v8, v14, :cond_f

    if-eq v8, v15, :cond_f

    const/4 v2, 0x0

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object v1, v8

    move-wide/from16 v3, v21

    invoke-virtual/range {v0 .. v5}, Lru/drivedeck/launcher/MainActivity;->d0(Landroid/view/View;ZJLjava/lang/Runnable;)V

    :cond_f
    if-eqz v15, :cond_12

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v15, v0, :cond_10

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-eq v14, v1, :cond_11

    :cond_10
    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    if-ne v15, v1, :cond_12

    if-ne v14, v0, :cond_12

    :cond_11
    move/from16 v23, v12

    goto :goto_9

    :cond_12
    move/from16 v23, v9

    :goto_9
    if-eqz v23, :cond_13

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    move/from16 v24, v0

    goto :goto_a

    :cond_13
    move/from16 v24, v10

    :goto_a
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne v15, v0, :cond_14

    const/high16 v0, -0x40800000    # -1.0f

    :goto_b
    move/from16 v25, v0

    goto :goto_c

    :cond_14
    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_b

    :goto_c
    if-nez v23, :cond_15

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    if-eqz v0, :cond_22

    :cond_15
    instance-of v0, v15, Lc/Q3;

    if-eqz v0, :cond_16

    move-object v1, v15

    check-cast v1, Lc/Q3;

    goto :goto_d

    :cond_16
    instance-of v1, v15, Lc/m2;

    if-eqz v1, :cond_17

    move-object v1, v15

    check-cast v1, Lc/m2;

    goto :goto_d

    :cond_17
    const/4 v1, 0x0

    :goto_d
    iput-object v1, v13, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-eqz v1, :cond_18

    invoke-virtual {v1, v12}, Lc/F;->t(Z)V

    :cond_18
    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    iput-object v1, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    if-nez v1, :cond_1b

    if-eqz v0, :cond_19

    move-object v0, v15

    check-cast v0, Lc/Q3;

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    goto :goto_e

    :cond_19
    instance-of v0, v15, Lc/m2;

    if-eqz v0, :cond_1a

    move-object v0, v15

    check-cast v0, Lc/m2;

    iget-object v0, v0, Lc/F;->l:Landroid/view/View;

    check-cast v0, Lc/b2;

    goto :goto_e

    :cond_1a
    const/4 v0, 0x0

    :goto_e
    iput-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    :cond_1b
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    if-eqz v0, :cond_1d

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-ne v0, v1, :cond_1d

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    if-nez v0, :cond_1d

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    iput-object v0, v13, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v0

    iput v0, v13, Lru/drivedeck/launcher/MainActivity;->s:I

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    iput-object v0, v13, Lru/drivedeck/launcher/MainActivity;->r:Landroid/view/ViewGroup$LayoutParams;

    const/4 v0, 0x2

    new-array v1, v0, [I

    new-array v0, v0, [I

    iget-object v2, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v2, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    iget-object v2, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    invoke-virtual {v2, v0}, Landroid/view/View;->getLocationOnScreen([I)V

    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    iget-object v3, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v3

    iget-object v4, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    aget v3, v1, v9

    aget v4, v0, v9

    sub-int/2addr v3, v4

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    aget v1, v1, v12

    aget v0, v0, v12

    sub-int/2addr v1, v0

    iput v1, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    instance-of v1, v0, Lc/F;

    if-eqz v1, :cond_1c

    check-cast v0, Lc/F;

    invoke-virtual {v0, v12}, Lc/F;->t(Z)V

    :cond_1c
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->h:Landroid/widget/FrameLayout;

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    const/high16 v1, 0x40c00000    # 6.0f

    invoke-static {v13, v1}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v1

    invoke-virtual {v0, v1}, Landroid/view/View;->setElevation(F)V

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    iput-boolean v12, v13, Lru/drivedeck/launcher/MainActivity;->u:Z

    goto :goto_f

    :cond_1d
    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-eqz v0, :cond_1e

    invoke-virtual {v0, v12}, Lc/F;->t(Z)V

    :cond_1e
    :goto_f
    instance-of v0, v14, Lc/Q3;

    if-eqz v0, :cond_1f

    move-object v8, v14

    check-cast v8, Lc/Q3;

    goto :goto_10

    :cond_1f
    instance-of v0, v14, Lc/m2;

    if-eqz v0, :cond_20

    move-object v8, v14

    check-cast v8, Lc/m2;

    goto :goto_10

    :cond_20
    const/4 v8, 0x0

    :goto_10
    iput-object v8, v13, Lru/drivedeck/launcher/MainActivity;->o:Lc/F;

    if-eqz v8, :cond_21

    invoke-virtual {v8, v12}, Lc/F;->t(Z)V

    :cond_21
    invoke-static/range {p1 .. p1}, Lru/drivedeck/launcher/MainActivity;->E(Landroid/view/View;)Lc/b2;

    move-result-object v0

    iput-object v0, v13, Lru/drivedeck/launcher/MainActivity;->q:Lc/b2;

    if-eqz v0, :cond_22

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    iput v0, v13, Lru/drivedeck/launcher/MainActivity;->t:I

    iget-object v0, v13, Lru/drivedeck/launcher/MainActivity;->q:Lc/b2;

    iget-object v1, v13, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    if-eq v0, v1, :cond_22

    invoke-virtual {v0, v11}, Landroid/view/View;->setVisibility(I)V

    :cond_22
    new-instance v20, Lc/w4;

    move-object/from16 v0, v20

    move-object/from16 v1, p0

    move-wide/from16 v2, v21

    move-object v4, v15

    move-object/from16 v5, p1

    move-wide/from16 v6, v16

    move/from16 v8, v18

    move/from16 v9, v19

    move/from16 v10, v23

    move/from16 v11, v25

    move/from16 v12, v24

    invoke-direct/range {v0 .. v12}, Lc/w4;-><init>(Lru/drivedeck/launcher/MainActivity;JLandroid/view/View;Landroid/view/View;JIIZFF)V

    if-eqz v15, :cond_23

    if-eq v15, v14, :cond_23

    const/4 v2, 0x0

    move-object/from16 v0, p0

    move-object v1, v15

    move-wide/from16 v3, v21

    move-object/from16 v5, v20

    invoke-virtual/range {v0 .. v5}, Lru/drivedeck/launcher/MainActivity;->d0(Landroid/view/View;ZJLjava/lang/Runnable;)V

    goto :goto_11

    :cond_23
    invoke-virtual/range {v20 .. v20}, Lc/w4;->run()V

    :goto_11
    return-void
.end method

.method public final u()V
    .locals 3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    if-nez v0, :cond_2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_2

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->r0:Z

    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->q0:Z

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->s0:Z

    iput-boolean v2, p0, Lru/drivedeck/launcher/MainActivity;->n0:Z

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->o()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/MainActivity;->t(Landroid/view/View;)V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->f:Lc/m2;

    invoke-virtual {v0}, Lc/m2;->H()V

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const-string v1, "split"

    invoke-virtual {p0, v1, v0}, Lru/drivedeck/launcher/MainActivity;->T(Ljava/lang/String;[Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->v()V

    :cond_2
    :goto_0
    return-void
.end method

.method public final v()V
    .locals 2

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-static {p0}, Lc/r4;->b(Landroid/content/Context;)Lc/r4;

    move-result-object v1

    iget v1, v1, Lc/r4;->a:I

    invoke-virtual {v0, v1}, Landroid/view/Window;->setStatusBarColor(I)V

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-static {v0}, Lc/b4;->b(Landroid/view/Window;)V

    return-void
.end method

.method public final w(Ljava/lang/String;I)V
    .locals 21

    move-object/from16 v0, p0

    move-object/from16 v11, p1

    move/from16 v1, p2

    if-nez v1, :cond_1

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Lc/u0;->b()V

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    return-void

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual/range {p0 .. p0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->o0()Z

    move-result v2

    if-nez v2, :cond_3

    :cond_2
    move-object v2, v0

    goto/16 :goto_d

    :cond_3
    const/16 v2, 0x1e

    if-ne v1, v2, :cond_5

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_5

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Lc/u0;->b()V

    :cond_4
    return-void

    :cond_5
    const-string v3, ""

    const/4 v4, 0x0

    if-ne v1, v2, :cond_11

    invoke-static/range {p1 .. p1}, Ld/a;->i(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_6

    return-void

    :cond_6
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    const-string v2, "voice_music_app"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_7

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->r()Ljava/lang/String;

    move-result-object v1

    :goto_0
    move-object v12, v1

    goto :goto_1

    :cond_7
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    iget-object v1, v1, Lc/n1;->b:Ljava/lang/Object;

    check-cast v1, Landroid/content/SharedPreferences;

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :goto_1
    invoke-virtual {v12}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_10

    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->a:Lc/z;

    invoke-virtual {v1, v12}, Lc/z;->d(Ljava/lang/String;)Lc/a;

    move-result-object v1

    if-eqz v1, :cond_10

    invoke-virtual {v0, v12}, Lru/drivedeck/launcher/MainActivity;->f(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_8

    goto/16 :goto_6

    :cond_8
    iget-object v1, v0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    if-nez v1, :cond_9

    new-instance v1, Lc/u0;

    invoke-direct {v1, v0}, Lc/u0;-><init>(Lru/drivedeck/launcher/MainActivity;)V

    iput-object v1, v0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    :cond_9
    iget-object v13, v0, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    new-instance v14, Lc/y4;

    const/4 v1, 0x2

    invoke-direct {v14, v0, v1}, Lc/y4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    invoke-virtual {v13}, Lc/u0;->b()V

    invoke-virtual {v13}, Lc/u0;->g()Z

    move-result v1

    if-eqz v1, :cond_a

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v14, v1}, Lc/y4;->accept(Ljava/lang/Object;)V

    goto/16 :goto_5

    :cond_a
    iget v15, v13, Lc/u0;->a:I

    sget v16, Lc/G8;->B:I

    new-instance v1, Lc/n1;

    iget-object v2, v13, Lc/u0;->b:Ljava/lang/Object;

    move-object v10, v2

    check-cast v10, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v1, v10}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v1}, Lc/n1;->t0()J

    move-result-wide v17

    sget-object v9, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    :try_start_0
    const-class v1, Landroid/media/session/MediaSessionManager;

    invoke-virtual {v10, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/media/session/MediaSessionManager;

    if-eqz v1, :cond_c

    invoke-static {v10, v1}, Lc/G8;->b(Landroid/content/Context;Landroid/media/session/MediaSessionManager;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_b
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/session/MediaController;

    invoke-virtual {v2}, Landroid/media/session/MediaController;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v12, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_b

    invoke-virtual {v13, v2, v11, v9}, Lc/u0;->t(Landroid/media/session/MediaController;Ljava/lang/String;Landroid/os/Bundle;)Z

    move-result v2

    if-eqz v2, :cond_b

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v14, v1}, Lc/y4;->accept(Ljava/lang/Object;)V

    goto/16 :goto_5

    :catch_0
    move-object/from16 v20, v12

    move-object/from16 p2, v14

    goto/16 :goto_3

    :cond_c
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.media.browse.MediaBrowserService"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v12}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    invoke-virtual {v10}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v2, v1, v4}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_f

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ResolveInfo;

    iget-object v2, v2, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    if-eqz v2, :cond_e

    iget-boolean v3, v2, Landroid/content/pm/ServiceInfo;->enabled:Z

    if-eqz v3, :cond_e

    iget-boolean v3, v2, Landroid/content/pm/ServiceInfo;->exported:Z

    if-eqz v3, :cond_e

    iget-object v3, v2, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v12, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_e

    iget-object v3, v2, Landroid/content/pm/ServiceInfo;->permission:Ljava/lang/String;

    if-eqz v3, :cond_d

    invoke-virtual {v10, v3}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v3

    if-eqz v3, :cond_d

    goto :goto_2

    :cond_d
    new-instance v8, Landroid/media/browse/MediaBrowser;

    new-instance v7, Landroid/content/ComponentName;

    iget-object v1, v2, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-direct {v7, v12, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v5, Lc/i5;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v1, v5

    move-object v2, v13

    move v3, v15

    move/from16 v4, v16

    move-object v0, v5

    move-wide/from16 v5, v17

    move-object v11, v7

    move-object v7, v14

    move-object/from16 p2, v14

    move-object v14, v8

    move-object v8, v12

    move-object/from16 v19, v9

    move-object/from16 v9, p1

    move-object/from16 v20, v12

    move-object v12, v10

    move-object/from16 v10, v19

    :try_start_1
    invoke-direct/range {v1 .. v10}, Lc/i5;-><init>(Lc/u0;IIJLc/y4;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v1, 0x0

    invoke-direct {v14, v12, v11, v0, v1}, Landroid/media/browse/MediaBrowser;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/media/browse/MediaBrowser$ConnectionCallback;Landroid/os/Bundle;)V

    iput-object v14, v13, Lc/u0;->d:Ljava/lang/Object;

    iget-object v0, v13, Lc/u0;->c:Ljava/lang/Object;

    check-cast v0, Landroid/os/Handler;

    new-instance v10, Lc/h5;

    move-object v1, v10

    move-object v2, v13

    move v3, v15

    move/from16 v4, v16

    move-wide/from16 v5, v17

    move-object/from16 v7, p2

    move-object/from16 v8, v20

    move-object/from16 v9, p1

    invoke-direct/range {v1 .. v9}, Lc/h5;-><init>(Lc/u0;IIJLc/y4;Ljava/lang/String;Ljava/lang/String;)V

    const-wide/16 v1, 0x2710

    invoke-virtual {v0, v10, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object v0, v13, Lc/u0;->d:Ljava/lang/Object;

    check-cast v0, Landroid/media/browse/MediaBrowser;

    invoke-virtual {v0}, Landroid/media/browse/MediaBrowser;->connect()V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_5

    :cond_e
    move-object/from16 v20, v12

    move-object/from16 v0, p0

    move-object/from16 v11, p1

    goto :goto_2

    :cond_f
    move-object/from16 p2, v14

    move-object/from16 v0, p1

    move-object v1, v12

    goto :goto_4

    :catch_1
    :goto_3
    invoke-virtual {v13}, Lc/u0;->b()V

    move-object/from16 v0, p1

    move-object/from16 v1, v20

    :goto_4
    invoke-virtual {v13, v1, v0}, Lc/u0;->h(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    move-object/from16 v1, p2

    invoke-virtual {v1, v0}, Lc/y4;->accept(Ljava/lang/Object;)V

    :goto_5
    return-void

    :cond_10
    :goto_6
    const-string v0, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u0434\u043b\u044f \u044d\u0442\u043e\u0439 \u043a\u043e\u043c\u0430\u043d\u0434\u044b \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430\u0445 \u0433\u043e\u043b\u043e\u0441\u0430"

    move-object/from16 v2, p0

    invoke-virtual {v2, v0}, Lru/drivedeck/launcher/MainActivity;->l0(Ljava/lang/String;)V

    return-void

    :cond_11
    move-object v2, v0

    move-object v0, v11

    invoke-static/range {p2 .. p2}, Ljava/lang/Math;->abs(I)I

    move-result v5

    const/16 v6, 0x1f

    if-ne v5, v6, :cond_21

    iget-object v5, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v5}, Lc/n1;->q0()Z

    move-result v5

    if-eqz v5, :cond_21

    invoke-static/range {p0 .. p0}, Lc/Z7;->d(Landroid/content/Context;)Z

    move-result v5

    if-eqz v5, :cond_21

    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_12

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->X:Lc/u0;

    if-eqz v0, :cond_21

    invoke-virtual {v0}, Lc/u0;->b()V

    goto/16 :goto_d

    :cond_12
    if-gez v1, :cond_20

    invoke-virtual/range {p0 .. p0}, Lru/drivedeck/launcher/MainActivity;->j()V

    iput-object v0, v2, Lru/drivedeck/launcher/MainActivity;->h0:Ljava/lang/String;

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    iput-object v1, v2, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-wide v5, v2, Lru/drivedeck/launcher/MainActivity;->j0:J

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    const-wide/16 v9, 0x2ee0

    add-long/2addr v7, v9

    iput-wide v7, v2, Lru/drivedeck/launcher/MainActivity;->i0:J

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v1}, Lc/n1;->R()Ljava/lang/String;

    move-result-object v1

    invoke-static/range {p1 .. p1}, Ld/a;->i(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_14

    :cond_13
    :goto_7
    move-object v8, v3

    goto/16 :goto_b

    :cond_14
    invoke-virtual/range {p1 .. p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    sget-object v8, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v7, v8}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x451

    const/16 v9, 0x435

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v7

    const-string v8, "\\s+"

    const-string v9, " "

    invoke-virtual {v7, v8, v9}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "\\+?[0-9 ()-]{3,64}"

    invoke-virtual {v7, v8}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v8

    const-string v10, "\\+?[0-9]{3,20}"

    if-eqz v8, :cond_15

    const-string v1, "[ ()-]"

    invoke-virtual {v7, v1, v3}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_13

    move-object v3, v1

    goto :goto_7

    :cond_15
    sget-object v8, Ld/a;->h:[[Ljava/lang/String;

    invoke-static {v1}, Ld/a;->b(Ljava/lang/String;)I

    move-result v11

    aget-object v8, v8, v11

    const-string v11, "zh_tw"

    invoke-virtual {v11, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    invoke-virtual {v7, v9, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v7, "(.)"

    const-string v9, "$1 "

    invoke-virtual {v1, v7, v9}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    :cond_16
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, " +"

    invoke-virtual {v7, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    array-length v9, v7

    move v11, v4

    :goto_8
    if-ge v11, v9, :cond_1c

    aget-object v12, v7, v11

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->length()I

    move-result v13

    if-nez v13, :cond_18

    const-string v13, "\u043f\u043b\u044e\u0441"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_17

    const-string v13, "plus"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_17

    const-string v13, "m\u00e1s"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_17

    const-string v13, "pi\u00f9"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_17

    const-string v13, "c\u1ed9ng"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-nez v13, :cond_17

    const-string v13, "\u52a0"

    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_18

    :cond_17
    const/16 v12, 0x2b

    invoke-virtual {v1, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_a

    :cond_18
    const/4 v13, -0x1

    move v14, v4

    :goto_9
    array-length v15, v8

    if-ge v14, v15, :cond_1a

    aget-object v15, v8, v14

    invoke-virtual {v12, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_19

    move v13, v14

    :cond_19
    add-int/lit8 v14, v14, 0x1

    goto :goto_9

    :cond_1a
    if-gez v13, :cond_1b

    goto/16 :goto_7

    :cond_1b
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :goto_a
    add-int/lit8 v11, v11, 0x1

    goto :goto_8

    :cond_1c
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_13

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto/16 :goto_7

    :goto_b
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1f

    new-instance v0, Lc/Q;

    invoke-direct {v0, v8, v8}, Lc/Q;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    iget-wide v5, v2, Lru/drivedeck/launcher/MainActivity;->i0:J

    cmp-long v1, v3, v5

    if-lez v1, :cond_1d

    goto :goto_c

    :cond_1d
    iput-object v0, v2, Lru/drivedeck/launcher/MainActivity;->f0:Lc/Q;

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    if-nez v1, :cond_1e

    new-instance v1, Lc/l9;

    invoke-direct {v1, v2}, Lc/l9;-><init>(Landroid/app/Activity;)V

    iput-object v1, v2, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    :cond_1e
    iget-object v7, v2, Lru/drivedeck/launcher/MainActivity;->W:Lc/l9;

    const-string v1, "\u041f\u043e\u0437\u0432\u043e\u043d\u0438\u0442\u044c"

    invoke-static {v2, v1}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v9

    new-instance v10, Lc/y0;

    const/4 v1, 0x2

    invoke-direct {v10, v2, v0, v1}, Lc/y0;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    new-instance v11, Lc/I4;

    const/4 v0, 0x2

    invoke-direct {v11, v2, v0}, Lc/I4;-><init>(Lru/drivedeck/launcher/MainActivity;I)V

    const-wide/16 v12, 0x2ee0

    invoke-virtual/range {v7 .. v13}, Lc/l9;->g(Ljava/lang/String;[Ljava/lang/String;Ljava/util/function/IntConsumer;Ljava/lang/Runnable;J)V

    :goto_c
    return-void

    :cond_1f
    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    new-instance v3, Lc/F4;

    invoke-direct {v3, v2, v0, v5, v6}, Lc/F4;-><init>(Lru/drivedeck/launcher/MainActivity;Ljava/lang/String;J)V

    invoke-virtual {v1, v0, v3}, Lc/Z7;->h(Ljava/lang/String;Ljava/util/function/Consumer;)V

    goto :goto_d

    :cond_20
    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->f0:Lc/Q;

    if-eqz v1, :cond_21

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->h0:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->d0:Ljava/lang/String;

    iget-object v1, v2, Lru/drivedeck/launcher/MainActivity;->Y:Lc/Z7;

    iget-object v1, v1, Lc/Z7;->a:Lc/e8;

    iget-object v1, v1, Lc/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    iget-wide v3, v2, Lru/drivedeck/launcher/MainActivity;->i0:J

    cmp-long v0, v0, v3

    if-gtz v0, :cond_21

    iget-object v0, v2, Lru/drivedeck/launcher/MainActivity;->f0:Lc/Q;

    invoke-virtual {v2, v0}, Lru/drivedeck/launcher/MainActivity;->r(Lc/Q;)V

    :cond_21
    :goto_d
    return-void
.end method

.method public final x(Landroid/view/View;Z)V
    .locals 7

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p2, :cond_5

    if-eqz p1, :cond_5

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    if-eqz v3, :cond_5

    iput-object v3, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    instance-of v3, p1, Lc/Q3;

    if-eqz v3, :cond_0

    move-object v3, p1

    check-cast v3, Lc/Q3;

    goto :goto_0

    :cond_0
    instance-of v3, p1, Lc/m2;

    if-eqz v3, :cond_1

    move-object v3, p1

    check-cast v3, Lc/m2;

    goto :goto_0

    :cond_1
    move-object v3, v2

    :goto_0
    invoke-static {p1}, Lru/drivedeck/launcher/MainActivity;->E(Landroid/view/View;)Lc/b2;

    move-result-object v4

    if-eqz v3, :cond_7

    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-eqz v5, :cond_2

    if-eq v5, v3, :cond_2

    invoke-static {v5}, Lru/drivedeck/launcher/MainActivity;->E(Landroid/view/View;)Lc/b2;

    move-result-object v6

    invoke-virtual {v5, v6}, Lc/F;->u(Landroid/view/View;)V

    :cond_2
    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    invoke-virtual {v3, v5}, Lc/F;->u(Landroid/view/View;)V

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->g:Lc/Q3;

    if-ne p1, v5, :cond_3

    const/4 p1, 0x1

    goto :goto_1

    :cond_3
    move p1, v1

    :goto_1
    iput-boolean p1, v3, Lc/b2;->p0:Z

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v3}, Lc/n1;->l()Ljava/util/ArrayList;

    move-result-object v3

    invoke-virtual {p1, v3}, Lc/b2;->D(Ljava/util/ArrayList;)V

    if-eqz v4, :cond_4

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    if-eq v4, p1, :cond_4

    invoke-virtual {v4, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_4
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    invoke-virtual {p1}, Landroid/view/View;->bringToFront()V

    goto :goto_2

    :cond_5
    iget-boolean p1, p0, Lru/drivedeck/launcher/MainActivity;->u:Z

    if-eqz p1, :cond_7

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    if-eqz p1, :cond_7

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    if-eqz v3, :cond_7

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    instance-of p1, p1, Landroid/view/ViewGroup;

    if-eqz p1, :cond_6

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_6
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    iget-object v3, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    iget v4, p0, Lru/drivedeck/launcher/MainActivity;->s:I

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v5

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    iget-object v5, p0, Lru/drivedeck/launcher/MainActivity;->r:Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {p1, v3, v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    const/high16 v3, 0x40c00000    # 6.0f

    invoke-static {p0, v3}, Lc/G8;->j0(Landroid/content/Context;F)F

    move-result v3

    invoke-virtual {p1, v3}, Landroid/view/View;->setElevation(F)V

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    :cond_7
    :goto_2
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->q:Lc/b2;

    if-eqz p1, :cond_b

    iget v3, p0, Lru/drivedeck/launcher/MainActivity;->t:I

    if-ltz v3, :cond_b

    if-nez p2, :cond_b

    iget-object p2, p0, Lru/drivedeck/launcher/MainActivity;->l:Lc/b2;

    if-nez p2, :cond_b

    if-eqz v3, :cond_a

    if-eq v3, v0, :cond_9

    const/16 p2, 0x8

    if-eq v3, p2, :cond_8

    goto :goto_3

    :cond_8
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_3

    :cond_9
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    goto :goto_3

    :cond_a
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_b
    :goto_3
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-eqz p1, :cond_c

    invoke-virtual {p1, v1}, Lc/F;->t(Z)V

    :cond_c
    iget-object p1, p0, Lru/drivedeck/launcher/MainActivity;->o:Lc/F;

    if-eqz p1, :cond_d

    iget-object p2, p0, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    if-eq p1, p2, :cond_d

    invoke-virtual {p1, v1}, Lc/F;->t(Z)V

    :cond_d
    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->m:Lc/b2;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->n:Lc/F;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->o:Lc/F;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->q:Lc/b2;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->p:Landroid/view/ViewGroup;

    iput-object v2, p0, Lru/drivedeck/launcher/MainActivity;->r:Landroid/view/ViewGroup$LayoutParams;

    const/4 p1, -0x1

    iput p1, p0, Lru/drivedeck/launcher/MainActivity;->t:I

    iput-boolean v1, p0, Lru/drivedeck/launcher/MainActivity;->u:Z

    return-void
.end method

.method public final y(Landroid/content/Intent;)V
    .locals 9

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-void

    :cond_0
    sget-object v1, Lc/q4;->a:[B

    const-string v1, "android.intent.action.VIEW"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    if-nez v1, :cond_1

    goto :goto_0

    :cond_1
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v2

    const-string v3, "content"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "file"

    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    goto :goto_0

    :cond_2
    const-string v0, "android.intent.action.MAIN"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-static {p0, v1}, Lc/q4;->l(Lru/drivedeck/launcher/MainActivity;Landroid/net/Uri;)V

    return-void

    :cond_3
    :goto_0
    const-string v1, "ru.drivedeck.launcher.ALL_APPS"

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_4

    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-wide v1, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v3, Lc/x4;

    invoke-direct {v3, p0, v1, v2, v0}, Lc/x4;-><init>(Lru/drivedeck/launcher/MainActivity;JI)V

    invoke-virtual {p1, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_4
    const-string v1, "ru.drivedeck.launcher.DOCK_SETTINGS"

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_5

    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-wide v0, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v2, Lc/x4;

    const/4 v3, 0x1

    invoke-direct {v2, p0, v0, v1, v3}, Lc/x4;-><init>(Lru/drivedeck/launcher/MainActivity;JI)V

    invoke-virtual {p1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_5
    const-string v1, "ru.drivedeck.launcher.PICK_SLOT"

    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_6

    return-void

    :cond_6
    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v7

    invoke-virtual {p1, v1}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    invoke-virtual {p0}, Lru/drivedeck/launcher/MainActivity;->A()V

    iget-wide v5, p0, Lru/drivedeck/launcher/MainActivity;->R:J

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    new-instance v0, Lc/p3;

    const/4 v8, 0x1

    move-object v3, v0

    move-object v4, p0

    invoke-direct/range {v3 .. v8}, Lc/p3;-><init>(Ljava/lang/Object;JII)V

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public final z()Z
    .locals 3

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0}, Lc/n1;->o0()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    invoke-virtual {v0, v1}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p0, Lru/drivedeck/launcher/MainActivity;->b:Lc/n1;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Lc/n1;->H(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    move v1, v2

    :cond_0
    return v1
.end method
