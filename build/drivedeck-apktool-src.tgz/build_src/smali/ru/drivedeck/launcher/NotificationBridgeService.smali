.class public final Lru/drivedeck/launcher/NotificationBridgeService;
.super Landroid/service/notification/NotificationListenerService;
.source "SourceFile"


# static fields
.field public static final a:Ljava/util/concurrent/CopyOnWriteArraySet;

.field public static final b:Landroid/os/Handler;

.field public static volatile c:Lru/drivedeck/launcher/NotificationBridgeService;

.field public static volatile d:Ljava/util/List;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    sput-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->a:Ljava/util/concurrent/CopyOnWriteArraySet;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->b:Landroid/os/Handler;

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    sput-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->d:Ljava/util/List;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/service/notification/NotificationListenerService;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 3

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "enabled_notification_listeners"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    const-class v2, Lru/drivedeck/launcher/NotificationBridgeService;

    invoke-direct {v1, p0, v2}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v1}, Landroid/content/ComponentName;->flattenToString()Ljava/lang/String;

    move-result-object p0

    if-eqz v0, :cond_0

    invoke-virtual {v0, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static b([Landroid/service/notification/StatusBarNotification;)V
    .locals 15

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p0, :cond_6

    array-length v1, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_6

    aget-object v3, p0, v2

    invoke-virtual {v3}, Landroid/service/notification/StatusBarNotification;->getNotification()Landroid/app/Notification;

    move-result-object v10

    if-eqz v10, :cond_5

    iget v4, v10, Landroid/app/Notification;->flags:I

    and-int/lit16 v4, v4, 0x200

    if-eqz v4, :cond_0

    goto/16 :goto_3

    :cond_0
    iget-object v4, v10, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const-string v5, "android.title"

    invoke-virtual {v4, v5}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v4

    iget-object v5, v10, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const-string v6, "android.bigText"

    invoke-virtual {v5, v6}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    if-nez v5, :cond_1

    iget-object v5, v10, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const-string v6, "android.text"

    invoke-virtual {v5, v6}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    :cond_1
    const-string v6, ""

    if-nez v4, :cond_2

    move-object v7, v6

    goto :goto_1

    :cond_2
    invoke-interface {v4}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v7, v4

    :goto_1
    if-nez v5, :cond_3

    move-object v8, v6

    goto :goto_2

    :cond_3
    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    move-object v8, v4

    :goto_2
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_4

    goto :goto_3

    :cond_4
    new-instance v13, Lc/q5;

    invoke-virtual {v3}, Landroid/service/notification/StatusBarNotification;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3}, Landroid/service/notification/StatusBarNotification;->getPostTime()J

    move-result-wide v11

    invoke-virtual {v3}, Landroid/service/notification/StatusBarNotification;->getKey()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v3}, Landroid/service/notification/StatusBarNotification;->isClearable()Z

    move-result v3

    move-object v4, v13

    move-object v6, v7

    move-object v7, v8

    move-wide v8, v11

    move-object v11, v14

    move v12, v3

    invoke-direct/range {v4 .. v12}, Lc/q5;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLandroid/app/Notification;Ljava/lang/String;Z)V

    invoke-virtual {v0, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5
    :goto_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_6
    new-instance p0, Lc/p5;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p0}, Ljava/util/Comparator;->comparingLong(Ljava/util/function/ToLongFunction;)Ljava/util/Comparator;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Comparator;->reversed()Ljava/util/Comparator;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->sort(Ljava/util/Comparator;)V

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    sput-object p0, Lru/drivedeck/launcher/NotificationBridgeService;->d:Ljava/util/List;

    sget-object p0, Lru/drivedeck/launcher/NotificationBridgeService;->b:Landroid/os/Handler;

    new-instance v0, Lc/a1;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lc/a1;-><init>(I)V

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method


# virtual methods
.method public final onDestroy()V
    .locals 1

    sget-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    if-eq v0, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    sput-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    invoke-static {v0}, Lru/drivedeck/launcher/NotificationBridgeService;->b([Landroid/service/notification/StatusBarNotification;)V

    :goto_0
    invoke-super {p0}, Landroid/service/notification/NotificationListenerService;->onDestroy()V

    return-void
.end method

.method public final onListenerConnected()V
    .locals 1

    invoke-super {p0}, Landroid/service/notification/NotificationListenerService;->onListenerConnected()V

    sput-object p0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    sget-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    if-eq v0, p0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/service/notification/NotificationListenerService;->getActiveNotifications()[Landroid/service/notification/StatusBarNotification;

    move-result-object v0

    invoke-static {v0}, Lru/drivedeck/launcher/NotificationBridgeService;->b([Landroid/service/notification/StatusBarNotification;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    return-void
.end method

.method public final onListenerDisconnected()V
    .locals 1

    sget-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    if-eq v0, p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    sput-object v0, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    invoke-static {v0}, Lru/drivedeck/launcher/NotificationBridgeService;->b([Landroid/service/notification/StatusBarNotification;)V

    :goto_0
    invoke-super {p0}, Landroid/service/notification/NotificationListenerService;->onListenerDisconnected()V

    return-void
.end method

.method public final onNotificationPosted(Landroid/service/notification/StatusBarNotification;)V
    .locals 0

    sget-object p1, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    if-eq p1, p0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/service/notification/NotificationListenerService;->getActiveNotifications()[Landroid/service/notification/StatusBarNotification;

    move-result-object p1

    invoke-static {p1}, Lru/drivedeck/launcher/NotificationBridgeService;->b([Landroid/service/notification/StatusBarNotification;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    return-void
.end method

.method public final onNotificationRemoved(Landroid/service/notification/StatusBarNotification;)V
    .locals 0

    sget-object p1, Lru/drivedeck/launcher/NotificationBridgeService;->c:Lru/drivedeck/launcher/NotificationBridgeService;

    if-eq p1, p0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    invoke-virtual {p0}, Landroid/service/notification/NotificationListenerService;->getActiveNotifications()[Landroid/service/notification/StatusBarNotification;

    move-result-object p1

    invoke-static {p1}, Lru/drivedeck/launcher/NotificationBridgeService;->b([Landroid/service/notification/StatusBarNotification;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :goto_0
    return-void
.end method
