.class Lru/drivedeck/launcher/RootBootEnforcer$4;
.super Ljava/lang/Object;
.source "RootBootEnforcer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/RootBootEnforcer;->onCarWake(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 102
    iput-object p1, p0, Lru/drivedeck/launcher/RootBootEnforcer$4;->val$app:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 105
    const-string v0, "RootBootEnforcer"

    :try_start_0
    iget-object v1, p0, Lru/drivedeck/launcher/RootBootEnforcer$4;->val$app:Landroid/content/Context;

    invoke-static {v1}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 106
    invoke-static {v1}, Lru/drivedeck/launcher/RootBootEnforcer;->isIdle(Lc/T5;)Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    .line 107
    :cond_0
    iget-object v2, p0, Lru/drivedeck/launcher/RootBootEnforcer$4;->val$app:Landroid/content/Context;

    const-string v3, "drivedeck_obd"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const-string v3, "adapter_error"

    const-string v4, ""

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_2

    .line 108
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    .line 109
    :cond_1
    invoke-virtual {v1}, Lc/T5;->u0()V

    .line 110
    const-string v1, "car wake: OBD safety retry"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :cond_2
    :goto_0
    return-void

    :catchall_0
    move-exception v1

    .line 112
    const-string v2, "car wake retry failed"

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    return-void
.end method
