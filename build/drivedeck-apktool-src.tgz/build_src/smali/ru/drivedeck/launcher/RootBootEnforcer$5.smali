.class Lru/drivedeck/launcher/RootBootEnforcer$5;
.super Ljava/lang/Object;
.source "RootBootEnforcer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/RootBootEnforcer;->enforce(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 224
    iput-object p1, p0, Lru/drivedeck/launcher/RootBootEnforcer$5;->val$app:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 226
    iget-object v0, p0, Lru/drivedeck/launcher/RootBootEnforcer$5;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lru/drivedeck/launcher/RootBootEnforcer;->access$200(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 227
    const-string v0, "RootBootEnforcer"

    const-string v1, "system settings applied via Settings API"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    .line 230
    :cond_0
    iget-object v0, p0, Lru/drivedeck/launcher/RootBootEnforcer$5;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lru/drivedeck/launcher/RootBootEnforcer;->access$300(Landroid/content/Context;)V

    return-void
.end method
