.class Lru/drivedeck/launcher/HeRemote$2;
.super Ljava/lang/Object;
.source "HeRemote.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/HeRemote;->command(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$a:Ljava/lang/String;

.field final synthetic val$app:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 116
    iput-object p1, p0, Lru/drivedeck/launcher/HeRemote$2;->val$a:Ljava/lang/String;

    iput-object p2, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    .line 118
    const-string v0, "ru.drivedeck.he.CHECK_UPDATE"

    iget-object v1, p0, Lru/drivedeck/launcher/HeRemote$2;->val$a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    const-string v2, "DriveDeck: "

    if-eqz v0, :cond_0

    .line 119
    iget-object v0, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    const-string v3, "DriveDeck: \u05d1\u05d5\u05d3\u05e7 \u05e2\u05d3\u05db\u05d5\u05e0\u05d9\u05dd\u2026"

    invoke-static {v0, v3}, Lru/drivedeck/launcher/HeRemote;->access$100(Landroid/content/Context;Ljava/lang/String;)V

    .line 120
    iget-object v0, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    invoke-static {v2, v1}, Lru/drivedeck/launcher/HeRemote;->checkUpdate(Landroid/content/Context;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lru/drivedeck/launcher/HeRemote;->access$100(Landroid/content/Context;Ljava/lang/String;)V

    goto :goto_0

    .line 121
    :cond_0
    const-string v0, "ru.drivedeck.he.SEND_LOG"

    iget-object v3, p0, Lru/drivedeck/launcher/HeRemote$2;->val$a:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 122
    iget-object v0, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    const-string v3, "DriveDeck: \u05e9\u05d5\u05dc\u05d7 \u05dc\u05d5\u05d2\u2026"

    invoke-static {v0, v3}, Lru/drivedeck/launcher/HeRemote;->access$100(Landroid/content/Context;Ljava/lang/String;)V

    .line 123
    iget-object v0, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lru/drivedeck/launcher/HeRemote$2;->val$app:Landroid/content/Context;

    invoke-static {v2, v1}, Lru/drivedeck/launcher/HeRemote;->uploadLog(Landroid/content/Context;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lru/drivedeck/launcher/HeRemote;->access$100(Landroid/content/Context;Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method
