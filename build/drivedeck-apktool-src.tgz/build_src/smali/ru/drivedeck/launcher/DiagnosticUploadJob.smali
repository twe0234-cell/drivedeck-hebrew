.class public final Lru/drivedeck/launcher/DiagnosticUploadJob;
.super Landroid/app/job/JobService;
.source "SourceFile"


# instance fields
.field public volatile a:Landroid/app/job/JobParameters;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    return-void
.end method


# virtual methods
.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 2

    iput-object p1, p0, Lru/drivedeck/launcher/DiagnosticUploadJob;->a:Landroid/app/job/JobParameters;

    new-instance v0, Lc/H;

    const/4 v1, 0x2

    invoke-direct {v0, p0, p1, v1}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    const/4 p1, 0x0

    invoke-static {v0, p1}, Lc/N1;->D(Lc/H;Z)V

    const/4 p1, 0x1

    return p1
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 0

    const/4 p1, 0x0

    iput-object p1, p0, Lru/drivedeck/launcher/DiagnosticUploadJob;->a:Landroid/app/job/JobParameters;

    const/4 p1, 0x1

    return p1
.end method
