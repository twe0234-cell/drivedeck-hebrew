.class public final Lru/drivedeck/launcher/HebrewVoiceBridge;
.super Ljava/lang/Object;
.source "HebrewVoiceBridge.java"


# static fields
.field static final CLS:Ljava/lang/String; = "il.carvoice.he.VoiceActivity"

.field static final PKG:Ljava/lang/String; = "il.carvoice.he"

.field private static final TAG:Ljava/lang/String; = "HebrewVoiceBridge"

.field private static volatile sLast:J


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static isInstalled(Landroid/content/Context;)Z
    .locals 2

    const/4 v0, 0x0

    if-eqz p0, :cond_0

    .line 22
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string v1, "il.carvoice.he"

    invoke-virtual {p0, v1}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz p0, :cond_0

    const/4 v0, 0x1

    nop

    :catchall_0
    :cond_0
    return v0
.end method

.method public static launch(Landroid/content/Context;)Z
    .locals 10

    .line 30
    const-string v0, "HebrewVoiceBridge"

    invoke-static {p0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->isInstalled(Landroid/content/Context;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    return v2

    .line 31
    :cond_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v3

    .line 32
    sget-wide v5, Lru/drivedeck/launcher/HebrewVoiceBridge;->sLast:J

    const-wide/16 v7, 0x0

    cmp-long v1, v5, v7

    const/4 v5, 0x1

    if-lez v1, :cond_1

    sget-wide v6, Lru/drivedeck/launcher/HebrewVoiceBridge;->sLast:J

    sub-long v6, v3, v6

    const-wide/16 v8, 0x5dc

    cmp-long v1, v6, v8

    if-gez v1, :cond_1

    return v5

    .line 33
    :cond_1
    sput-wide v3, Lru/drivedeck/launcher/HebrewVoiceBridge;->sLast:J

    .line 35
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const-string v3, "android.intent.action.MAIN"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 36
    const-string v3, "il.carvoice.he"

    const-string v4, "il.carvoice.he.VoiceActivity"

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const v3, 0x10008000

    .line 37
    invoke-virtual {v1, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 38
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 39
    const-string p0, "Hebrew voice assistant started"

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return v5

    :catchall_0
    move-exception p0

    .line 42
    const-string v1, "start failed"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v2
.end method

.method public static onIntent(Landroid/content/Context;Landroid/content/Intent;)Z
    .locals 3

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 60
    :cond_0
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_1

    return v0

    .line 62
    :cond_1
    const-string v2, "android.intent.action.ASSIST"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "android.intent.action.VOICE_ASSIST"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "android.intent.action.VOICE_COMMAND"

    .line 63
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, "android.intent.action.SEARCH_LONG_PRESS"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    return v0

    .line 64
    :cond_2
    invoke-static {p0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->launch(Landroid/content/Context;)Z

    move-result p0

    if-nez p0, :cond_3

    return v0

    :cond_3
    const/4 p0, 0x0

    .line 65
    invoke-virtual {p1, p0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 p0, 0x1

    return p0
.end method

.method public static onKey(Landroid/content/Context;Landroid/view/KeyEvent;)Z
    .locals 3

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return v0

    .line 50
    :cond_0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v1

    const/16 v2, 0xdb

    if-eq v1, v2, :cond_1

    const/16 v2, 0xe7

    if-eq v1, v2, :cond_1

    const/16 v2, 0x54

    if-eq v1, v2, :cond_1

    return v0

    .line 52
    :cond_1
    invoke-static {p0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->isInstalled(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_2

    return v0

    .line 53
    :cond_2
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_3

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_3

    invoke-static {p0}, Lru/drivedeck/launcher/HebrewVoiceBridge;->launch(Landroid/content/Context;)Z

    :cond_3
    const/4 p0, 0x1

    return p0
.end method
