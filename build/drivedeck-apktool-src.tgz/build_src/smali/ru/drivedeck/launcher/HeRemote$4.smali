.class Lru/drivedeck/launcher/HeRemote$4;
.super Ljava/lang/Object;
.source "HeRemote.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/HeRemote;->run([Ljava/lang/String;J)Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$fp:Ljava/lang/Process;

.field final synthetic val$out:Ljava/io/ByteArrayOutputStream;


# direct methods
.method constructor <init>(Ljava/lang/Process;Ljava/io/ByteArrayOutputStream;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 663
    iput-object p1, p0, Lru/drivedeck/launcher/HeRemote$4;->val$fp:Ljava/lang/Process;

    iput-object p2, p0, Lru/drivedeck/launcher/HeRemote$4;->val$out:Ljava/io/ByteArrayOutputStream;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    .line 666
    :try_start_0
    iget-object v0, p0, Lru/drivedeck/launcher/HeRemote$4;->val$fp:Ljava/lang/Process;

    invoke-virtual {v0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const/16 v1, 0x4000

    .line 667
    new-array v1, v1, [B

    .line 669
    :goto_0
    invoke-virtual {v0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    if-lez v2, :cond_1

    .line 670
    iget-object v3, p0, Lru/drivedeck/launcher/HeRemote$4;->val$out:Ljava/io/ByteArrayOutputStream;

    monitor-enter v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v4, p0, Lru/drivedeck/launcher/HeRemote$4;->val$out:Ljava/io/ByteArrayOutputStream;

    invoke-virtual {v4}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v4

    const v5, 0x3d0900

    if-ge v4, v5, :cond_0

    iget-object v4, p0, Lru/drivedeck/launcher/HeRemote$4;->val$out:Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x0

    invoke-virtual {v4, v1, v5, v2}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    :cond_0
    monitor-exit v3

    goto :goto_0

    :catchall_0
    move-exception v0

    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    :cond_1
    return-void
.end method
