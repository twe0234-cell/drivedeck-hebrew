.class Lru/drivedeck/launcher/RootBootEnforcer$2;
.super Ljava/lang/Object;
.source "RootBootEnforcer.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/RootBootEnforcer;->onCarWake(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$app:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 77
    iput-object p1, p0, Lru/drivedeck/launcher/RootBootEnforcer$2;->val$app:Landroid/content/Context;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 79
    iget-object v0, p0, Lru/drivedeck/launcher/RootBootEnforcer$2;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lru/drivedeck/launcher/HeRemote;->installPendingSelf(Landroid/content/Context;)Z

    const-wide/16 v0, -0x1

    .line 81
    invoke-static {v0, v1}, Lru/drivedeck/launcher/RootBootEnforcer;->access$102(J)J

    .line 82
    iget-object v0, p0, Lru/drivedeck/launcher/RootBootEnforcer$2;->val$app:Landroid/content/Context;

    invoke-static {v0}, Lru/drivedeck/launcher/RootBootEnforcer;->onCarWake(Landroid/content/Context;)V

    return-void
.end method
