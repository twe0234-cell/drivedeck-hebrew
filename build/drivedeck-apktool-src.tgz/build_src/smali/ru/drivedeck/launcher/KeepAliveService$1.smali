.class Lru/drivedeck/launcher/KeepAliveService$1;
.super Landroid/content/BroadcastReceiver;
.source "KeepAliveService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lru/drivedeck/launcher/KeepAliveService;->onCreate()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lru/drivedeck/launcher/KeepAliveService;


# direct methods
.method constructor <init>(Lru/drivedeck/launcher/KeepAliveService;)V
    .locals 0
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 49
    iput-object p1, p0, Lru/drivedeck/launcher/KeepAliveService$1;->this$0:Lru/drivedeck/launcher/KeepAliveService;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    if-nez p2, :cond_0

    const/4 p2, 0x0

    goto :goto_0

    .line 51
    :cond_0
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    .line 52
    :goto_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 53
    const-string v2, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    .line 54
    invoke-static {v0, v1}, Lru/drivedeck/launcher/KeepAliveService;->access$002(J)J

    goto :goto_1

    .line 55
    :cond_1
    const-string v2, "android.intent.action.SCREEN_ON"

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_3

    .line 56
    invoke-static {}, Lru/drivedeck/launcher/KeepAliveService;->access$000()J

    move-result-wide v2

    const-wide/16 v4, -0x1

    .line 57
    invoke-static {v4, v5}, Lru/drivedeck/launcher/KeepAliveService;->access$002(J)J

    const-wide/16 v4, 0x0

    cmp-long p2, v2, v4

    if-ltz p2, :cond_2

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x7530

    cmp-long p2, v0, v2

    if-ltz p2, :cond_3

    .line 59
    :cond_2
    invoke-static {p1}, Lru/drivedeck/launcher/RootBootEnforcer;->onCarWake(Landroid/content/Context;)V

    :cond_3
    :goto_1
    return-void
.end method
