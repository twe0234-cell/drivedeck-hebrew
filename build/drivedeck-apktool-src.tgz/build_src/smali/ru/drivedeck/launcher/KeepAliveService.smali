.class public Lru/drivedeck/launcher/KeepAliveService;
.super Landroid/app/Service;
.source "KeepAliveService.java"


# static fields
.field private static volatile sScreenOffAt:J = -0x1L


# instance fields
.field private screenReceiver:Landroid/content/BroadcastReceiver;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 19
    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method static synthetic access$000()J
    .locals 2

    .line 15
    sget-wide v0, Lru/drivedeck/launcher/KeepAliveService;->sScreenOffAt:J

    return-wide v0
.end method

.method static synthetic access$002(J)J
    .locals 0

    .line 15
    sput-wide p0, Lru/drivedeck/launcher/KeepAliveService;->sScreenOffAt:J

    return-wide p0
.end method

.method public static start(Landroid/content/Context;)V
    .locals 2

    if-nez p0, :cond_0

    return-void

    .line 24
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/drivedeck/launcher/KeepAliveService;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public onCreate()V
    .locals 5

    .line 31
    const-string v0, "drivedeck_keepalive"

    const-string v1, "DriveDeck"

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v2, 0x1

    .line 33
    :try_start_0
    const-string v3, "notification"

    invoke-virtual {p0, v3}, Lru/drivedeck/launcher/KeepAliveService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/NotificationManager;

    if-eqz v3, :cond_0

    .line 35
    new-instance v4, Landroid/app/NotificationChannel;

    invoke-direct {v4, v0, v1, v2}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    .line 36
    invoke-virtual {v4, v1}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 37
    invoke-virtual {v3, v4}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 41
    :catchall_0
    :cond_0
    :try_start_1
    new-instance v3, Landroid/app/Notification$Builder;

    invoke-direct {v3, p0, v0}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 42
    invoke-virtual {v3, v1}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v0

    const-string v1, "\u05e4\u05d5\u05e2\u05dc \u05d1\u05e8\u05e7\u05e2"

    .line 43
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v0

    const v1, 0x1080041

    .line 44
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v0

    .line 45
    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v0

    .line 46
    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/16 v1, 0x1e15

    .line 41
    invoke-virtual {p0, v1, v0}, Lru/drivedeck/launcher/KeepAliveService;->startForeground(ILandroid/app/Notification;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 49
    :catchall_1
    :try_start_2
    new-instance v0, Lru/drivedeck/launcher/KeepAliveService$1;

    invoke-direct {v0, p0}, Lru/drivedeck/launcher/KeepAliveService$1;-><init>(Lru/drivedeck/launcher/KeepAliveService;)V

    iput-object v0, p0, Lru/drivedeck/launcher/KeepAliveService;->screenReceiver:Landroid/content/BroadcastReceiver;

    .line 63
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 64
    const-string v1, "android.intent.action.SCREEN_ON"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 65
    const-string v1, "android.intent.action.SCREEN_OFF"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 66
    iget-object v1, p0, Lru/drivedeck/launcher/KeepAliveService;->screenReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p0, v1, v0}, Lru/drivedeck/launcher/KeepAliveService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :catchall_2
    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 73
    :try_start_0
    iget-object v0, p0, Lru/drivedeck/launcher/KeepAliveService;->screenReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_0

    invoke-virtual {p0, v0}, Lru/drivedeck/launcher/KeepAliveService;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 74
    :catchall_0
    :cond_0
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 0

    const/4 p1, 0x1

    return p1
.end method
