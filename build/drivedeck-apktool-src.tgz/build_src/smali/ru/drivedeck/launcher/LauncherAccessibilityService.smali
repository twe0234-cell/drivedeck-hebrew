.class public final Lru/drivedeck/launcher/LauncherAccessibilityService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "SourceFile"


# static fields
.field public static p:Ljava/lang/ref/WeakReference;

.field public static q:Z

.field public static final r:Ljava/util/HashSet;


# instance fields
.field public final a:Landroid/os/Handler;

.field public b:J

.field public c:J

.field public d:Z

.field public e:Lc/S1;

.field public f:Landroid/os/HandlerThread;

.field public g:Landroid/os/Handler;

.field public h:Lc/l8;

.field public volatile i:Z

.field public volatile j:I

.field public final k:Ljava/lang/Object;

.field public l:Landroid/view/accessibility/AccessibilityEvent;

.field public m:Z

.field public n:Landroid/view/accessibility/AccessibilityNodeInfo;

.field public final o:Lc/e1;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->r:Ljava/util/HashSet;

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    const/4 v0, -0x1

    iput v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->j:I

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->k:Ljava/lang/Object;

    new-instance v0, Lc/e1;

    const/4 v1, 0x4

    invoke-direct {v0, p0, v1}, Lc/e1;-><init>(Ljava/lang/Object;I)V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->o:Lc/e1;

    return-void
.end method

.method public static a(Lru/drivedeck/launcher/LauncherAccessibilityService;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 4

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->k:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    const/4 v2, 0x0

    iput-object v2, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v0, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    move v3, v0

    :goto_0
    iput-boolean v3, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->m:Z

    if-nez v1, :cond_1

    goto :goto_5

    :cond_1
    :try_start_1
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityRecord;->getSource()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object p0
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    if-eqz p0, :cond_3

    const/16 v3, 0x40

    if-ge v0, v3, :cond_3

    :try_start_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->getParent()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    if-nez v3, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V
    :try_end_2
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    add-int/lit8 v0, v0, 0x1

    move-object p0, v3

    goto :goto_1

    :catchall_0
    move-exception p0

    goto :goto_3

    :cond_3
    :goto_2
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    move-object v2, p0

    goto :goto_5

    :catch_0
    move-object p0, v2

    :catch_1
    if-eqz p0, :cond_4

    :try_start_3
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_4

    :goto_3
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    throw p0

    :cond_4
    :goto_4
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    :goto_5
    return-object v2

    :catchall_1
    move-exception p0

    :try_start_4
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p0
.end method

.method public static b()V
    .locals 5

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v0, :cond_0

    iget-wide v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->b:J

    const-wide/16 v3, 0x1

    add-long/2addr v1, v3

    iput-wide v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->b:J

    iget-wide v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->c:J

    add-long/2addr v1, v3

    iput-wide v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->c:J

    const/4 v1, 0x0

    iput-boolean v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->d:Z

    :cond_0
    return-void
.end method

.method public static d()Z
    .locals 1

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static f(Landroid/content/ContextWrapper;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 9

    invoke-static {p1}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3

    invoke-static {p2}, Lc/G8;->N(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-nez v2, :cond_1

    new-instance p2, Lc/z;

    invoke-direct {p2, p0}, Lc/z;-><init>(Landroid/content/Context;)V

    invoke-virtual {p2, p1}, Lc/z;->h(Ljava/lang/String;)Z

    return-void

    :cond_1
    iget-wide v0, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->b:J

    const-wide/16 v3, 0x1

    add-long/2addr v3, v0

    iput-wide v3, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->b:J

    new-instance v5, Lc/z;

    invoke-direct {v5, v2}, Lc/z;-><init>(Landroid/content/Context;)V

    invoke-virtual {v5, p2}, Lc/z;->h(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_2

    const-string p0, "\u0412\u0442\u043e\u0440\u043e\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e"

    invoke-static {v2, p0}, Lc/G8;->J(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {v2, p0, p1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_2
    iget-object p0, v2, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v0, Lc/j4;

    move-object v1, v0

    move-object v6, p1

    move-object v7, p2

    move-object v8, p3

    invoke-direct/range {v1 .. v8}, Lc/j4;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;JLc/z;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    const-wide/16 p1, 0x3e8

    invoke-virtual {p0, v0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_3
    :goto_0
    new-instance p3, Lc/n1;

    invoke-direct {p3, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {p3}, Lc/n1;->o0()Z

    move-result v0

    if-eqz v0, :cond_6

    invoke-virtual {p3}, Lc/n1;->I()F

    move-result v0

    invoke-virtual {p3, p1, p2, v0}, Lc/n1;->Q0(Ljava/lang/String;Ljava/lang/String;F)Z

    move-result p1

    if-nez p1, :cond_4

    goto :goto_1

    :cond_4
    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    sget-object p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz p1, :cond_5

    iget-object p1, p1, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz p1, :cond_5

    invoke-virtual {p1}, Lc/S1;->c()V

    :cond_5
    new-instance p1, Landroid/content/Intent;

    const-class p2, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p1, p0, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string p2, "ru.drivedeck.launcher.NATIVE_SPLIT"

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/high16 p2, 0x34000000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_6
    :goto_1
    return-void
.end method

.method public static i(Ljava/util/ArrayList;)V
    .locals 3

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v0, :cond_0

    iget-object v0, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_0

    iget-object v1, v0, Lc/S1;->d:Lc/b2;

    if-eqz v1, :cond_0

    invoke-virtual {v1, p0}, Lc/b2;->D(Ljava/util/ArrayList;)V

    iget-object p0, v0, Lc/S1;->d:Lc/b2;

    invoke-virtual {v0}, Lc/S1;->g()Z

    move-result v1

    invoke-virtual {p0, v1}, Lc/b2;->E(Z)V

    invoke-virtual {v0}, Lc/S1;->a()Lc/Q1;

    move-result-object p0

    :try_start_0
    iget-object v1, v0, Lc/S1;->b:Landroid/view/WindowManager;

    iget-object v2, v0, Lc/S1;->d:Lc/b2;

    invoke-virtual {v0, p0}, Lc/S1;->b(Lc/Q1;)Landroid/view/WindowManager$LayoutParams;

    move-result-object p0

    invoke-interface {v1, v2, p0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method


# virtual methods
.method public final c()V
    .locals 1

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    const/4 v0, 0x0

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->n:Landroid/view/accessibility/AccessibilityNodeInfo;

    :cond_0
    invoke-static {}, Lc/k5;->a()V

    return-void
.end method

.method public final e(J)Z
    .locals 2

    iget-wide v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->b:J

    cmp-long p1, p1, v0

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final g(Ljava/lang/String;)V
    .locals 10

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    iget-wide v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->c:J

    const-wide/16 v2, 0x1

    add-long v6, v0, v2

    iput-wide v6, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->c:J

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lru/drivedeck/launcher/LauncherAccessibilityService;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    iput-boolean v1, v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->d:Z

    :cond_0
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Landroid/accessibilityservice/AccessibilityService;->performGlobalAction(I)Z

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    new-instance v1, Lc/k1;

    const/4 v9, 0x3

    move-object v4, v1

    move-object v5, p0

    move-object v8, p1

    invoke-direct/range {v4 .. v9}, Lc/k1;-><init>(Ljava/lang/Object;JLjava/lang/Object;I)V

    const-wide/16 v2, 0x15e

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final h(Ljava/lang/String;)V
    .locals 2

    invoke-static {}, Lru/drivedeck/launcher/LauncherAccessibilityService;->b()V

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lc/S1;->c()V

    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v1, 0x34000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public final j()V
    .locals 5

    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getWindows()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityWindowInfo;

    :try_start_0
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityWindowInfo;->getType()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_0

    new-instance v3, Landroid/graphics/Rect;

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    invoke-virtual {v2, v3}, Landroid/view/accessibility/AccessibilityWindowInfo;->getBoundsInScreen(Landroid/graphics/Rect;)V

    invoke-virtual {v3}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    xor-int/lit8 v3, v3, 0x1

    or-int/2addr v1, v3

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_2

    :cond_0
    :goto_1
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    goto :goto_0

    :goto_2
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    throw v0

    :cond_1
    sget-boolean v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->q:Z

    if-ne v0, v1, :cond_2

    return-void

    :cond_2
    sput-boolean v1, Lru/drivedeck/launcher/LauncherAccessibilityService;->q:Z

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->r:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_3

    :cond_3
    return-void
.end method

.method public final k()V
    .locals 3

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_2

    iget-object v0, v0, Lc/S1;->e:Lc/p7;

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getWindows()Ljava/util/List;

    move-result-object v0

    :try_start_0
    iget-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    invoke-virtual {v1, v0}, Lc/S1;->f(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/accessibility/AccessibilityWindowInfo;

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    goto :goto_0

    :cond_0
    return-void

    :catchall_0
    move-exception v1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/view/accessibility/AccessibilityWindowInfo;

    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityWindowInfo;->recycle()V

    goto :goto_1

    :cond_1
    throw v1

    :cond_2
    return-void
.end method

.method public final onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 8

    invoke-static {p0, p1}, Lru/drivedeck/launcher/HeHome;->onA11yEvent(Landroid/content/Context;Landroid/view/accessibility/AccessibilityEvent;)V

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->h:Lc/l8;

    const/16 v1, 0x800

    const/16 v2, 0x20

    if-eqz v0, :cond_7

    monitor-enter v0

    :try_start_0
    sget-object v3, Lc/m8;->b:Lc/n1;

    iget-boolean v4, v0, Lc/l8;->f:Z

    if-nez v4, :cond_6

    if-nez v3, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/16 v5, 0x8

    if-eq v4, v5, :cond_1

    const/16 v5, 0x1000

    if-eq v4, v5, :cond_1

    if-eq v4, v1, :cond_1

    if-eq v4, v2, :cond_1

    monitor-exit v0

    goto :goto_3

    :cond_1
    :try_start_1
    iget-object v5, v3, Lc/n1;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v6

    if-nez v6, :cond_2

    const-string v6, ""

    goto :goto_0

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_2
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v6

    :goto_0
    invoke-virtual {v5, v6}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_4

    if-ne v4, v2, :cond_3

    sget-object v4, Lc/m8;->a:Landroid/os/Handler;

    new-instance v5, Lc/F7;

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v5, v3, v6, v7}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_3
    monitor-exit v0

    goto :goto_3

    :cond_4
    :try_start_2
    iget-object v4, v0, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    if-eqz v4, :cond_5

    invoke-virtual {v4}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    :cond_5
    invoke-static {p1}, Landroid/view/accessibility/AccessibilityEvent;->obtain(Landroid/view/accessibility/AccessibilityEvent;)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object v4

    iput-object v4, v0, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    iput-object v3, v0, Lc/l8;->c:Lc/n1;

    iget-object v3, v0, Lc/l8;->a:Landroid/os/Handler;

    iget-object v4, v0, Lc/l8;->g:Lc/k8;

    invoke-virtual {v3, v4}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v3, v0, Lc/l8;->a:Landroid/os/Handler;

    iget-object v4, v0, Lc/l8;->g:Lc/k8;

    const-wide/16 v5, 0x10

    invoke-virtual {v3, v4, v5, v6}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    monitor-exit v0

    goto :goto_3

    :cond_6
    :goto_1
    monitor-exit v0

    goto :goto_3

    :goto_2
    :try_start_3
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw p1

    :cond_7
    :goto_3
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v0

    const/high16 v3, 0x400000

    if-eq v0, v3, :cond_8

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v0

    if-ne v0, v2, :cond_9

    :cond_8
    invoke-virtual {p0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->j()V

    :cond_9
    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_a

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getEventType()I

    move-result v0

    if-eq v0, v1, :cond_a

    invoke-virtual {p0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->k()V

    :cond_a
    const-string v0, "ru.yandex.yandexnavi"

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    if-nez v1, :cond_b

    const-string v1, ""

    goto :goto_4

    :cond_b
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v1

    :goto_4
    invoke-virtual {v0, v1}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityRecord;->getWindowId()I

    move-result v0

    iput v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->j:I

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->k:Ljava/lang/Object;

    monitor-enter v0

    :try_start_4
    iget-boolean v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->i:Z

    if-nez v1, :cond_d

    iget-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    if-eqz v1, :cond_c

    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    goto :goto_5

    :catchall_1
    move-exception p1

    goto :goto_6

    :cond_c
    :goto_5
    invoke-static {p1}, Landroid/view/accessibility/AccessibilityEvent;->obtain(Landroid/view/accessibility/AccessibilityEvent;)Landroid/view/accessibility/AccessibilityEvent;

    move-result-object p1

    iput-object p1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    :cond_d
    monitor-exit v0

    goto :goto_7

    :goto_6
    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p1

    :cond_e
    :goto_7
    return-void
.end method

.method public final onDestroy()V
    .locals 6

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->a:Landroid/os/Handler;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->i:Z

    sget-object v2, Lc/m8;->b:Lc/n1;

    if-eqz v2, :cond_0

    sget-object v3, Lc/m8;->a:Landroid/os/Handler;

    new-instance v4, Lc/F7;

    const/4 v5, 0x2

    invoke-direct {v4, v2, v1, v5}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    iget-object v2, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->k:Ljava/lang/Object;

    monitor-enter v2

    :try_start_0
    iget-object v3, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    if-eqz v3, :cond_1

    invoke-virtual {v3}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    iput-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->l:Landroid/view/accessibility/AccessibilityEvent;

    goto :goto_0

    :catchall_0
    move-exception v0

    goto/16 :goto_5

    :cond_1
    :goto_0
    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget-object v2, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->g:Landroid/os/Handler;

    if-eqz v2, :cond_5

    invoke-virtual {v2, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    iget-object v2, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->h:Lc/l8;

    if-eqz v2, :cond_4

    monitor-enter v2

    :try_start_1
    iput-boolean v0, v2, Lc/l8;->f:Z

    iget-object v0, v2, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityEvent;->recycle()V

    iput-object v1, v2, Lc/l8;->b:Landroid/view/accessibility/AccessibilityEvent;

    iput-object v1, v2, Lc/l8;->c:Lc/n1;

    goto :goto_1

    :catchall_1
    move-exception v0

    goto :goto_2

    :cond_2
    :goto_1
    iget-object v0, v2, Lc/l8;->a:Landroid/os/Handler;

    iget-object v3, v2, Lc/l8;->g:Lc/k8;

    invoke-virtual {v0, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    iget-object v0, v2, Lc/l8;->a:Landroid/os/Handler;

    new-instance v3, Lc/k8;

    const/4 v4, 0x1

    invoke-direct {v3, v2, v4}, Lc/k8;-><init>(Lc/l8;I)V

    invoke-virtual {v0, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object v0, Lc/m8;->b:Lc/n1;

    if-eqz v0, :cond_3

    sget-object v3, Lc/m8;->a:Landroid/os/Handler;

    new-instance v4, Lc/F7;

    const/4 v5, 0x2

    invoke-direct {v4, v0, v1, v5}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_3
    monitor-exit v2

    goto :goto_3

    :goto_2
    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0

    :cond_4
    :goto_3
    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->g:Landroid/os/Handler;

    new-instance v1, Lc/i;

    const/16 v2, 0x9

    invoke-direct {v1, p0, v2}, Lc/i;-><init>(Ljava/lang/Object;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_5
    invoke-static {}, Lc/k5;->a()V

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    if-eqz v0, :cond_6

    invoke-virtual {v0}, Lc/S1;->c()V

    :cond_6
    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->clear()V

    const/4 v0, 0x0

    sput-boolean v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->q:Z

    sget-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->r:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Runnable;

    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    goto :goto_4

    :cond_7
    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void

    :goto_5
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v0
.end method

.method public final onInterrupt()V
    .locals 5

    sget-object v0, Lc/m8;->b:Lc/n1;

    if-eqz v0, :cond_0

    sget-object v1, Lc/m8;->a:Landroid/os/Handler;

    new-instance v2, Lc/F7;

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v2, v0, v3, v4}, Lc/F7;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method

.method public final onKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4

    invoke-static {p0, p1}, Lru/drivedeck/launcher/HebrewVoiceBridge;->onKey(Landroid/content/Context;Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :he_voice_a

    return v0

    :he_voice_a

    sget-object v0, Lc/Z7;->Q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc/Z7;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lc/Z7;->e(Landroid/view/KeyEvent;)Z

    move-result v0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    new-instance v0, Lc/n1;

    invoke-direct {v0, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0}, Lc/n1;->p0()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v3, 0xdb

    if-eq v0, v3, :cond_1

    const/16 v3, 0xe7

    if-ne v0, v3, :cond_3

    :cond_1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result p1

    if-nez p1, :cond_2

    :try_start_0
    new-instance p1, Landroid/content/Intent;

    const-class v0, Lru/drivedeck/launcher/MainActivity;

    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v0, "android.intent.action.VOICE_COMMAND"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/high16 v0, 0x30000000

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    return v2

    :cond_2
    :goto_0
    return v1

    :cond_3
    return v2
.end method

.method public final onServiceConnected()V
    .locals 2

    invoke-super {p0}, Landroid/accessibilityservice/AccessibilityService;->onServiceConnected()V

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lru/drivedeck/launcher/LauncherAccessibilityService;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {p0}, Lru/drivedeck/launcher/LauncherAccessibilityService;->j()V

    invoke-virtual {p0}, Landroid/accessibilityservice/AccessibilityService;->getServiceInfo()Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-result-object v0

    iget v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->eventTypes:I

    or-int/lit16 v1, v1, 0x800

    iput v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->eventTypes:I

    iget v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    or-int/lit8 v1, v1, 0x30

    iput v1, v0, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    invoke-virtual {p0, v0}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    new-instance v0, Lc/S1;

    invoke-direct {v0, p0}, Lc/S1;-><init>(Lru/drivedeck/launcher/LauncherAccessibilityService;)V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->e:Lc/S1;

    invoke-static {p0}, Lc/R1;->b(Landroid/content/Context;)V

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->f:Landroid/os/HandlerThread;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->i:Z

    new-instance v0, Landroid/os/HandlerThread;

    const-string v1, "DriveDeck-NavigatorCue"

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->f:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    new-instance v0, Landroid/os/Handler;

    iget-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->f:Landroid/os/HandlerThread;

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->g:Landroid/os/Handler;

    new-instance v1, Lc/l8;

    invoke-direct {v1, v0}, Lc/l8;-><init>(Landroid/os/Handler;)V

    iput-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->h:Lc/l8;

    iget-object v0, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->g:Landroid/os/Handler;

    iget-object v1, p0, Lru/drivedeck/launcher/LauncherAccessibilityService;->o:Lc/e1;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_0
    return-void
.end method
