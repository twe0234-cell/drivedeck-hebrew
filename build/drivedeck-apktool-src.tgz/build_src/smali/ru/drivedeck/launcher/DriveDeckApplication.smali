.class public final Lru/drivedeck/launcher/DriveDeckApplication;
.super Landroid/app/Application;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCreate()V
    .locals 9

    invoke-super {p0}, Landroid/app/Application;->onCreate()V

    invoke-static {p0}, Lru/drivedeck/launcher/RootBootEnforcer;->initAndEnforce(Landroid/content/Context;)V

    invoke-static {p0}, Lru/drivedeck/launcher/KeepAliveService;->start(Landroid/content/Context;)V

    invoke-static {}, Lc/j8;->u()Z

    move-result v0

    if-nez v0, :cond_0

    :try_start_0
    invoke-static {}, Lc/G8;->C()Ljava/net/URI;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    new-instance v0, Lc/o3;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lc/o3;-><init>(I)V

    invoke-static {v0}, Ljava/util/concurrent/Executors;->newSingleThreadScheduledExecutor(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ScheduledExecutorService;

    move-result-object v2

    new-instance v3, Lc/H;

    const/16 v0, 0xe

    invoke-direct {v3, p0, v2, v0}, Lc/H;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    sget-object v8, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v4, 0xa

    const-wide/16 v6, 0xe10

    invoke-interface/range {v2 .. v8}, Ljava/util/concurrent/ScheduledExecutorService;->scheduleWithFixedDelay(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    :catch_0
    :cond_0
    invoke-static {p0}, Lc/T5;->V(Landroid/content/Context;)Lc/T5;

    move-result-object v0

    invoke-virtual {v0}, Lc/T5;->u0()V

    sget-object v0, Lc/N1;->X:Lc/N1;

    if-eqz v0, :cond_1

    goto :goto_0

    :cond_1
    :try_start_1
    new-instance v0, Lc/N1;

    invoke-direct {v0, p0}, Lc/N1;-><init>(Lru/drivedeck/launcher/DriveDeckApplication;)V

    sput-object v0, Lc/N1;->X:Lc/N1;

    sget-object v0, Lc/N1;->X:Lc/N1;

    invoke-virtual {v0}, Lc/N1;->c()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/LinkageError; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_0

    :catch_1
    const-string v0, "DriveDeckDiagnostics"

    const-string v1, "Diagnostics initialization unavailable"

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method
