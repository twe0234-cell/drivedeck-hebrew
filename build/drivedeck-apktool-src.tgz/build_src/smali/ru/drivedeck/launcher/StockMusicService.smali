.class public final Lru/drivedeck/launcher/StockMusicService;
.super Landroid/app/Service;
.source "SourceFile"


# static fields
.field public static volatile a:Lc/w8;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4

    const-string v0, "com.syu.music."

    const/4 v1, 0x0

    :try_start_0
    new-instance v2, Landroid/content/Intent;

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    new-instance p1, Landroid/content/ComponentName;

    const-string v0, "com.syu.music"

    const-string v3, "com.syu.music.MService"

    invoke-direct {p1, v0, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    :catch_0
    :cond_0
    return v1
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 0

    const/4 p1, 0x0

    return-object p1
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .locals 5

    const-string p2, "com.syu.music"

    if-eqz p1, :cond_2

    :try_start_0
    const-string v0, "com.fyt.launcher.music"

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "play_state"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    sget-object v0, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    new-instance v1, Lc/w8;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-direct {v1, p1, v2, v3, v0}, Lc/w8;-><init>(Landroid/content/Intent;JLc/w8;)V

    sput-object v1, Lru/drivedeck/launcher/StockMusicService;->a:Lc/w8;

    iget-object p1, v1, Lc/w8;->a:Ljava/lang/String;

    iget-object v2, v1, Lc/w8;->b:Ljava/lang/String;

    invoke-static {p0, p2, p1, v2}, Lc/G8;->o0(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iget-boolean p1, v1, Lc/w8;->h:Z

    if-eqz p1, :cond_2

    if-eqz v0, :cond_0

    iget-wide v1, v1, Lc/w8;->g:J

    iget-wide v3, v0, Lc/w8;->g:J

    cmp-long p1, v1, v3

    if-eqz p1, :cond_2

    :cond_0
    new-instance p1, Lc/n1;

    invoke-direct {p1, p0}, Lc/n1;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p1}, Lc/n1;->A()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lc/n1;->A0(Z)V

    invoke-virtual {p1, p2}, Lc/n1;->I0(Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Lc/n1;->J0(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    invoke-virtual {p0, p3}, Landroid/app/Service;->stopSelf(I)V

    const/4 p1, 0x2

    return p1
.end method
